# Revyse

Remix Project for the Revyse Product

- [Remix Docs](https://remix.run/docs)

## Development

1. Start your postgres instance with Docker: `docker compose up`
2. Run the DB migrations: `npx prisma migrate dev`
3. Start the app: `npm run dev`. This starts your app in development mode, rebuilding assets on file changes.

## Deployment

Should mostly depend on the CI/CD pipeline for deployments but if you need to deploy manually, you'll want to run

`./build-container.sh`

That script will:

1. Build the docker image
2. Ask you if you want to push and then push
3. Ask you if you want to deploy and then deploy (to whatever terraform workspace you have currently selected)

## Database Migrations

Again, we should rely on our CI/CD pipelines to run migrations for deployments but if you need to manually
apply migrations to a specific environment you'll need to update your `.env` file to have a
`DATABASE_URL` that matches the database of the environment you want to run migrations on. Then run
`npx prisma migrate dev` this will run all migrations that you have locally (so be careful).

You can also use the `dotenv` CLI to setup different .env files for different environment. This makes running
migrations and seeding much easier:

```
npx dotenv -e .env.dev -- prisma migrate dev
npx dotenv -e .env.dev -- prisma db seed
```

## Stripe

In order to allow your local environment to receive webhooks from stripe you must install the
stripe cli and login with the stripe CLI: https://stripe.com/docs/stripe-cli

Then you can run `stripe listen --forward-to localhost:3000/stripe_webhook` This will setup a local proxy
that will listen for webhook events and forward them to your local server.

This command will spit out a "signing secret" that you'll need to paste into your .env file along side your stripe secret key like so:

```
STRIPE_SECRET_KEY=<SECRET_KEY> // get this from logging into stripe
STRIPE_WEBHOOK_SECRET=<SIGNING_SECRET> // get this from the stripe CLI after running `stripe listen`
```

## Playwright Tests

In order to run the E2E tests for the stack intelligence module, do:

```bash
# Install browsers
npx playwright install
npx playwright test
```

Add the `RECAPTCHA_E2E_TOKEN` env variable with any value to avoid recaptcha issues when signing up, for example

```
RECAPTCHA_E2E_TOKEN=e2e-test-beep-boop
```

We want to have "Happy Path" E2E tests for all of the pages and workflows that we build into the app. The purpose is to be able to have some confidence that the app still works as expected after we make changes. We don't want to have to manually test every page and workflow every time we make a change.

In order to make e2e tests easier to write and maintain we should write every test to be atomic. This means that each test should be able to run in isolation and not depend on any other tests. This will make it easier to debug and maintain tests as the app changes. In addition, each test should clean up after itself and not leave any straggling data behind. This can be the cause of flaky tests and can make it hard to debug when tests fail.

In order to make writing tests easier follow this pattern:

```ts
import { test, expect } from "@playwright/test";
import { registerNewUser, withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";

// This defines what code will run before and after each test. Anything you return in the function from
// the setup function will be available in test functions and the cleanup function will run after each
// test.
const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    return { user, account };
  },
  cleanup: async ({ db, user, account, vendor }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.managerAccount.delete({ where: { id: account.id } });
  },
});

test.describe("Intelligence Vendor Info Page", () => {
  test(
    "Update vendor info",
    withFixture(async ({ page, accountVendor }) => {
      await page.goto(`/some-page`);
      // ... test some stuff
    })
  );
});
```

## Feature Flags

We user features flags to control the release of our features. Our feature flags are controlled by environment variables and they area all either on or off. If we want to support more granular control in the future we can expand it.

### Create a Feature Flag

To create a new feature flag, you should:

1. Add the appropriate flag in `app/services/feature-flags.service.server.ts`
2. Add the new local variable to our terraform config in `infrastructure/env/env.module.tf`. Add it to each of the environments as is appropriate.
3. Add the param to the app task definition template in `infrastructure/master.tf`
4. Add the environment variable in `infrastructure/templates/app.taskdef.tpl.json` under `environment`.

This will update the environment the next time the app is deployed to each environment.

### Use a Feature Flag

To use a feature flag in code simple pull the `FeatureFlagsService` from the container and use it like so:

```ts
// in a server route, or a service can just import and use the FeatureFlagService. On the client,
// you'll have to send the feature flag value down in the loader
import { WebDIContainer } from "app/di-containers/web.di-container.server";
import { FeatureFlag } from "app/services/feature-flags.service.server";
const { featureFlagService } = await WebDIContainer();

if (featureFlagService.isEnabled(FeatureFlag.VendorPages)) {
  // do something
}
```
