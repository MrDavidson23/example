# !/bin/bash -x

# vars
reset=`tput sgr0`
green=`tput setaf 2`
ecr=485727431821.dkr.ecr.us-west-2.amazonaws.com/revyse

echo 'Logging in to ECR: '
aws ecr get-login-password --region us-west-2 --profile revyse | docker login --username AWS --password-stdin $ecr


# arg passed from other script
image=$1

if [ "$image" != "" ];
then
  echo "Pushing the ${green}${image}${reset} build now!"
else
  echo "${green}Enter the image name manually (branch-commit):${reset}" && read image
fi

docker tag revyse:${image} $ecr:${image} && docker push $ecr:${image}

echo "Pushed ${green}$ecr:${image}${reset} to ECR"
