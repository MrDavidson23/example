import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { createAccount } from "prisma/seed/intelligence.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    return { user, account };
  },
  cleanup: async ({ db, user, account }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.managerAccount.delete({ where: { id: account.id } });
  },
});

test.describe("Logout from different portals", () => {
  test(
    "Logout from vendor intelligence",
    withFixture(async ({ page, account }) => {
      await page.goto(`/intelligence/${account.id}/`);
      const response = await page.request.get(`/intelligence/${account.id}/`);
      await expect(response).toBeOK();
      await page.locator("#logout-link").click();
      await expect(page).toHaveURL("login");
      await page.locator("#intelligence-link").click();
      await expect(page).toHaveURL("login?redirectTo=%2Fintelligence");
    })
  );

  test(
    "Logout from vendor portal",
    withFixture(async ({ page }) => {
      await page.goto(`/vendor/`);
      const response = await page.request.get(`/vendor/`);
      await expect(response).toBeOK();
      await page.locator("#logout-link").click();
      await expect(page).toHaveURL("login");
      await page.locator("#vendor-portal-link").click();
      await expect(page).toHaveURL("login?redirectTo=%2Fvendor");
    })
  );
});
