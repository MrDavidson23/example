import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { VendorState } from "@prisma/client";
import { slugify } from "~/utils/string.utils";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "~/di-containers/test.di-container.server";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const { db } = TestDIContainer();

    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();

    // Insert 4 vendors
    const vendors = await Promise.all(
      Array.from({ length: 4 }).map(async (_, index) => {
        const vendorName = `Integration ${index}`;
        return await db.vendor.create({
          data: {
            slug: slugify(vendorName),
            name: vendorName,
            website: faker.internet.url(),
            state: VendorState.ApprovedForPublishing,
          },
        });
      })
    );

    const accountVendors = await Promise.all(
      vendors.map(v =>
        db.managerAccountVendor.create({
          data: {
            manager_account: { connect: { id: account.id } },
            vendor: { connect: { id: v.id } },
          },
          include: {
            vendor: true,
          },
        })
      )
    );

    const accountVendor = await createAccountVendor(account, vendor.id);
    return { user, account, vendor, accountVendor, accountVendors, db };
  },
  cleanup: async ({ db, user, account, vendor }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
  },
});

test.describe.parallel("Intelligence Vendor Integration Map Page", () => {
  test(
    "Update vendor integrations",
    withFixture(
      async ({ page, accountVendor, account, accountVendors, db }) => {
        await page.goto(
          `/intelligence/${account.id}/vendors/${accountVendor.id}/integration-map`
        );
        // Submit empty form
        await page.locator("#save-button").click();
        await expect(page.locator(".Toastify").first()).toContainText(
          "Vendor integration map updated successfully"
        );

        // Submit form with integration
        await page.locator("#vendor_product").fill("Integration");
        await page
          .locator(`#vendor_product-option-${accountVendors[0].id}`)
          .click();
        await page.locator("#status").selectOption("Pending");
        await page.locator("#notes").fill(faker.lorem.paragraph());
        await page.locator("#add-intelligence-integration").click();
        await expect(
          page.locator('*[id*="integration-card-"]').first()
        ).toContainText(accountVendors[0].vendor.name);
        await page.locator("#save-button").click();
        await expect(page.locator(".Toastify").first()).toContainText(
          "Vendor integration map updated successfully"
        );
        await page.goto(
          `/intelligence/${account.id}/vendors/${accountVendor.id}/integration-map`
        );

        const integration = await db.intelligenceVendorIntegration.findFirst({
          where: {
            vendor_id: accountVendor.id,
            integrated_vendor_id: accountVendors[0].id,
          },
        });
        // Edit created integration
        await page.locator('*[id*="integration-card-"]').first().click();
        await page.locator("#status-modal").selectOption("Active");
        await page.locator("#save-integration-button").click();
        await expect(page.locator("#status-chip").first()).toContainText(
          "Active"
        );

        // Delete created integration
        await page.locator('*[id*="integration-card-"]').first().click();
        await page.locator(`#delete-${integration?.id}`).click();
        await page.locator("#delete-button").click();
        await expect(
          page.locator('*[id*="integration-card-"]')
        ).not.toBeVisible();
      }
    )
  );
});
