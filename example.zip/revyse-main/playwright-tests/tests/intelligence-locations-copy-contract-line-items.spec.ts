import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import {
  createContract,
  createContractLineItem,
  createTestLocation,
  createTestLocations,
} from "./db-helpers/intelligence.helper";
import { faker } from "@faker-js/faker";
import { map } from "lodash";
import {
  createTestCategory,
  createTestProducts,
} from "./db-helpers/general.helper";
import { LocationStatus } from "@prisma/client";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);

    const category = await createTestCategory();

    const products = await createTestProducts({ category_id: category.id });

    const contracts = await Promise.all(
      Array.from({ length: 5 }).map(() => createContract(accountVendor.id))
    );

    const locations = await createTestLocations({
      manager_account_id: account.id,
      status: LocationStatus.Active,
    });

    const locationWithMoreLineItems = await createTestLocation({
      manager_account_id: account.id,
      status: LocationStatus.Active,
    });

    const contractLineItems = await Promise.all(
      contracts.map(contract => {
        return createContractLineItem(contract, map(products, "id"), [
          locationWithMoreLineItems.id,
        ]);
      })
    );

    return {
      user,
      account,
      vendor,
      accountVendor,
      category,
      products,
      contracts,
      locations,
      locationWithMoreLineItems,
      contractLineItems,
    };
  },
  cleanup: async ({
    db,
    user,
    account,
    vendor,
    accountVendor,
    category,
    products,
    contracts,
    locations,
    locationWithMoreLineItems,
    contractLineItems,
  }) => {
    await db.contractLineItemProduct.deleteMany({
      where: { contract_line_item_id: { in: map(contractLineItems, "id") } },
    });
    await db.contractLineItemLocation.deleteMany({
      where: { contract_line_item_id: { in: map(contractLineItems, "id") } },
    });
    await db.contractLineItem.deleteMany({
      where: { id: { in: map(contractLineItems, "id") } },
    });
    await db.location.deleteMany({
      where: {
        id: { in: [...map(locations, "id"), locationWithMoreLineItems.id] },
      },
    });
    await db.contract.deleteMany({
      where: { id: { in: map(contracts, "id") } },
    });
    await db.product.deleteMany({ where: { id: { in: map(products, "id") } } });
    await db.productCategory.delete({ where: { id: category.id } });
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccountVendor.delete({ where: { id: accountVendor.id } });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe
  .parallel("Intelligence Locations > Copy Contract Line Items", () => {
  test(
    "Copy specific contract line items to specific location",
    withFixture(
      async ({
        page,
        account,
        locationWithMoreLineItems,
        contractLineItems,
        locations,
      }) => {
        await page.goto("/intelligence");
        await page.locator("#locations-link").click();

        await page.locator("#search-bar").click();
        await page.locator("#search-bar").fill(locationWithMoreLineItems.name);
        await page.locator("#search-bar").press("Enter");

        await page
          .locator(`#row_${locationWithMoreLineItems.id}`)
          .first()
          .click();
        await page.locator("#assigned-vendors").click();
        await page.locator("#ellipsis-menu").click();
        await page
          .getByRole("button", { name: "Copy assignments to new location(s)" })
          .first()
          .click();

        // Copy screen
        await expect(page).toHaveURL(
          `/intelligence/${account.id}/locations/${locationWithMoreLineItems.id}/assigned-vendors/copy`
        );

        const contractLineItemsToCopy = faker.helpers.arrayElements(
          contractLineItems,
          faker.number.int({ min: 2, max: contractLineItems.length })
        );
        for (const contractLineItem of contractLineItemsToCopy) {
          await page
            .locator(
              `#contract-line-item-location_${contractLineItem.contract_line_item_locations[0].id}_checkbox`
            )
            .click();
        }

        await page.locator("#copy-button").click();
        await page.locator("#continue").click();

        // Copy To screen
        await expect(page.locator("h1").first()).toHaveText(
          `Copy ${contractLineItemsToCopy.length} line items`
        );

        await page.locator("#search-bar").click();
        await page.locator("#search-bar").fill(locations[0].name);
        await page.locator("#search-bar").press("Enter");

        await page.locator(`#row_${locations[0].id}_checkbox`).first().click();
        await page.locator("#copy-to-locations-button").first().click();

        await page.waitForLoadState("networkidle");

        // Check if the contract line items are copied
        await page.goto("/intelligence");
        await page.locator("#locations-link").click();

        await page.locator("#search-bar").click();
        await page.locator("#search-bar").fill(locations[0].name);
        await page.locator("#search-bar").press("Enter");

        await page.locator(`#row_${locations[0].id}`).first().click();
        await page.locator("#assigned-vendors").click();

        for (const contractLineItem of contractLineItemsToCopy) {
          await expect(
            page.getByRole("cell", { name: contractLineItem.name || "" })
          ).toBeVisible();
        }
      }
    )
  );

  test(
    "Copy all contract line items to all locations",
    withFixture(
      async ({
        page,
        account,
        locationWithMoreLineItems,
        contractLineItems,
        locations,
      }) => {
        await page.goto("/intelligence");
        await page.locator("#locations-link").click();

        await page.locator("#search-bar").click();
        await page.locator("#search-bar").fill(locationWithMoreLineItems.name);
        await page.locator("#search-bar").press("Enter");

        await page
          .locator(`#row_${locationWithMoreLineItems.id}`)
          .first()
          .click();
        await page.locator("#assigned-vendors").click();
        await page.locator("#ellipsis-menu").click();
        await page
          .getByRole("button", { name: "Copy assignments to new location(s)" })
          .first()
          .click();

        // Copy screen
        await expect(page).toHaveURL(
          `/intelligence/${account.id}/locations/${locationWithMoreLineItems.id}/assigned-vendors/copy`
        );

        await page.locator("#select-all-checkbox").click();

        await page.locator("#copy-button").click();
        await page.locator("#continue").click();

        // Copy To screen
        await expect(page.locator("h1").first()).toHaveText(
          `Copy ${contractLineItems.length} line items`
        );

        await page.locator("#select-all-checkbox").click();

        await page.locator("#copy-to-locations-button").first().click();

        await page.waitForLoadState("networkidle");

        // Check if the contract line items are copied to every location
        await page.goto("/intelligence");
        for (const location of locations) {
          await page.locator("#locations-link").click();
          await page.locator("#search-bar").click();
          await page.locator("#search-bar").fill(location.name);
          await page.locator("#search-bar").press("Enter");

          await page.locator(`#row_${location.id}`).first().click();
          await page.locator("#assigned-vendors").click();

          for (const contractLineItem of contractLineItems) {
            await expect(
              page.getByRole("cell", {
                name: contractLineItem.name || "",
                exact: true,
              })
            ).toBeVisible();
          }
        }
      }
    )
  );
});
