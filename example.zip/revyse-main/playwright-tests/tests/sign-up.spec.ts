import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  fillRegistrationForm,
  registerNewUser,
} from "./page-helpers/sign-up.spec.helper";
import { faker } from "@faker-js/faker";

const FORM_ERROR_MESSAGE = "There were problems registering. Please try again.";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    await page.goto("/logout");
    const user2Email = faker.internet.email({ provider: "example.com" });
    return { user, user2Email };
  },
  cleanup: async ({ db, user, user2Email }) => {
    await db.user.delete({ where: { id: user.id } });
    await db.user.deleteMany({ where: { email: user2Email } });
  },
});

test.describe.parallel("Signup", () => {
  test(
    "Sign up with used email, not matching passwords, and empty fields",
    withFixture(async ({ page, user, user2Email }) => {
      // Fill in the registration form with used email
      await page.goto("/sign-up");
      await fillRegistrationForm(page, user.email);
      await page.getByRole("button", { name: "Sign Up" }).click();

      // Check error message
      await expect(page.locator("#toast")).toHaveText(FORM_ERROR_MESSAGE);
      await expect(page.locator("#errors-email")).toHaveText(
        `User with email ${user.email} already exists`
      );

      // Fill in the registration form with new email and not matching passwords
      await fillRegistrationForm(page, user2Email);
      await page.locator("[id='password-confirmation']").fill("notMatching");
      await page.getByRole("button", { name: "Sign Up" }).click();

      // Check error message
      await expect(page.locator("#toast")).toHaveText(FORM_ERROR_MESSAGE);
      await expect(page.locator("#errors-password-confirmation")).toHaveText(
        "Passwords do not match"
      );

      // Fill in the registration form with empty fields
      await fillRegistrationForm(page, user2Email);
      await page.locator("[id='first_name']").fill("");
      await page.locator("[id='last_name']").fill("");
      await page.getByRole("button", { name: "Sign Up" }).click();

      // Check error message
      await expect(page.locator("#toast")).toHaveText(FORM_ERROR_MESSAGE);
      await expect(page.locator("#errors-first_name")).toHaveText("Required");
      await expect(page.locator("#errors-last_name")).toHaveText("Required");
    })
  );

  test(
    "Sign up with valid data",
    withFixture(async ({ page, user2Email }) => {
      // Fill in the registration form with new email
      await page.goto("/sign-up");
      await fillRegistrationForm(page, user2Email);
      await page.getByRole("button", { name: "Sign Up" }).click();

      // Check success message
      await page.waitForURL("/sign-up-success");
    })
  );
});
