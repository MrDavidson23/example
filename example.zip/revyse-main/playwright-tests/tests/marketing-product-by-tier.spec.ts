import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { faker } from "@faker-js/faker";
import { createProductWithSubscription } from "./db-helpers/product-subscription.spec.helper";
import {
  createTestCategories,
  createTestIndustries,
  createTestGoodForTags,
} from "./db-helpers/general.helper";
import { Tier } from "@prisma/client";
import { sortBy } from "lodash";
import { tierHasPermission } from "../../app/utils/permission.utils";

const withFixture = withE2EFixtureFactory({
  setup: async ({ db }) => {
    const user = await db.user.create({
      data: {
        email: faker.internet.email({ provider: "example.com" }),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
      },
    });

    const categories = await createTestCategories({}, { count: 2 });
    const industries = await createTestIndustries({}, { count: 3 });
    const goodForTags = await createTestGoodForTags({}, { count: 3 });

    const productSubscription = await createProductWithSubscription(user.id, {
      title: faker.commerce.productName(),
      description: faker.commerce.productDescription(),
      positioning: faker.commerce.productDescription(),
      secondary_category: { connect: { id: categories[0].id } },
      tertiary_category: { connect: { id: categories[1].id } },
      demo_scheduling_url: "https://example.com",
      brand_video_urls: [
        {
          title: faker.commerce.productName(),
          url: "https://www.youtube.com/watch?v=9xwazD5SyVg",
          type: "youtube",
          embedUrl: "https://www.youtube.com/embed/9xwazD5SyVg",
        },
      ],
      demo_storylane_url: "https://www.storylane.com/demo",
      features: {
        createMany: {
          data: Array.from({ length: 2 }).map((_, i) => ({
            name: faker.commerce.productName(),
            description: faker.commerce.productDescription(),
            order: i,
          })),
        },
      },
      industries: {
        connect: industries.map(industry => ({ id: industry.id })),
      },
      good_for_tags: {
        connect: goodForTags.map(tag => ({ id: tag.id })),
      },
      packages: {
        createMany: {
          data: [
            {
              name: faker.commerce.productName(),
              description: faker.commerce.productDescription(),
              price: Number(faker.commerce.price()),
              order: 0,
            },
            {
              name: faker.commerce.productName(),
              description: faker.commerce.productDescription(),
              price: Number(faker.commerce.price()),
              order: 1,
            },
          ],
        },
      },
      promo_text: `${faker.number.int({
        min: 10,
        max: 50,
      })}% off for ${faker.number.int({ min: 2, max: 10 })} months`,
    });

    return {
      user,
      categories,
      industries,
      goodForTags,
      ...productSubscription,
    };
  },
  cleanup: async ({
    db,
    user,
    categories,
    industries,
    goodForTags,
    category,
    vendor,
    product,
    stripeProduct,
    stripePrice,
    productSubscription,
  }) => {
    await db.userRole.deleteMany({
      where: { user_id: { in: [user.id] } },
    });
    await db.productSubscription.delete({
      where: { id: productSubscription.id },
    });
    await db.stripePrice.delete({ where: { id: stripePrice.id } });
    await db.stripeProduct.delete({ where: { id: stripeProduct.id } });
    await db.product.delete({
      where: {
        id: product.id,
      },
    });
    await db.vendor.delete({
      where: {
        id: vendor.id,
      },
    });
    await db.productCategory.deleteMany({
      where: {
        id: { in: [...categories.map(category => category.id), category.id] },
      },
    });
    await db.industry.deleteMany({
      where: { id: { in: industries.map(industry => industry.id) } },
    });
    await db.goodForTag.deleteMany({
      where: { id: { in: goodForTags.map(tag => tag.id) } },
    });
    await db.userCredential.deleteMany({
      where: { user_id: { in: [user.id] } },
    });
    await db.user.deleteMany({
      where: { id: { in: [user.id] } },
    });
  },
});

test.describe("Discovery > Product > Conditional renders", () => {
  test(
    "Check sections/fields displayed by tier",
    withFixture(
      async ({ page, product, vendor, goodForTags, stripeProduct, db }) => {
        for (const tier of Object.values(Tier)) {
          await db.stripeProduct.update({
            where: { id: stripeProduct.id },
            data: { tier },
          });

          await page.goto(`/products/${product.slug}`);
          await page.reload();

          // Check product basic info header //
          // Title
          await expect(page.locator("#product-title")).toHaveText(
            product.title
          );
          // Vendor
          await expect(page.locator("#product-vendor")).toHaveText(vendor.name);

          // Check product header CTAs //
          // Schedule Demo
          await expect(page.locator("#cta-schedule-a-demo")).toBeVisible({
            visible: tierHasPermission(tier, "schedule_demo"),
          });

          // Contact Vendor
          await expect(page.locator("#cta-contact-vendor")).toBeVisible({
            visible: tierHasPermission(tier, "contact_vendor"),
          });
          // Write a Review
          await expect(page.locator("#cta-write-a-review")).toBeVisible({
            visible: !tierHasPermission(tier, "contact_vendor"), // showed if Contact Vendor is not visible
          });

          // Check product sidebar links //
          // Sections
          // Pricing
          await expect(page.locator("#pricing-link")).toBeVisible({
            visible: tierHasPermission(tier, "show_pricing"),
          });
          // Product Demos
          await expect(page.locator("#product-demos-link")).toBeVisible({
            visible: tierHasPermission(tier, "show_demos"),
          });
          // TODO uploads related sections
          // // Product images
          // await expect(page.locator("#product-images-link")).toBeVisible({
          //   visible: tierHasPermission(tier, "show_product_images"),
          // });
          // // Brand Videos
          // await expect(page.locator("#brand-videos-link")).toBeVisible({
          //   visible: tierHasPermission(tier, "show_brand_videos"),
          // });
          // // Downloads
          // await expect(page.locator("#downloads-link")).toBeVisible({
          //   visible: tierHasPermission(tier, "show_downloads"),
          // });

          // Actions
          await expect(page.locator("#schedule-a-demo-link")).toBeVisible({
            visible: tierHasPermission(tier, "schedule_demo"),
          });
          await expect(page.locator("#contact-vendor-link")).toBeVisible({
            visible: tierHasPermission(tier, "contact_vendor"),
          });
          await expect(page.locator("#write-a-review-link")).toBeVisible();

          // Check product offer //
          await expect(page.locator("#promo-text")).toBeVisible({
            visible: tierHasPermission(tier, "show_promo"),
          });
          if (tierHasPermission(tier, "show_promo")) {
            await expect(page.locator("#promo-text")).toHaveText(
              product.promo_text ?? "--"
            );
          }

          // Check Product Overview //
          // Positioning
          await expect(page.locator("#product-positioning")).toBeVisible({
            visible: tierHasPermission(tier, "show_positioning"),
          });
          // Features
          await expect(page.locator("#product-features")).toBeVisible({
            visible: tierHasPermission(tier, "show_features"),
          });
          // Product Categories
          await expect(page.locator("#product-primary-category")).toBeVisible();
          await expect(page.locator("#product-secondary-category")).toBeVisible(
            {
              visible: tierHasPermission(tier, "show_product_categories"),
            }
          );
          await expect(page.locator("#product-tertiary-category")).toBeVisible({
            visible: tierHasPermission(tier, "show_product_categories"),
          });
          // Good For Tags
          for (const tag of sortBy(goodForTags, "order")) {
            await expect(
              page.locator(`#product-good-for-tag-${tag.id}`)
            ).toBeVisible({
              visible: tierHasPermission(tier, "show_good_for_tags"),
            });
          }

          // Check Pricing Section //
          // Packages
          await expect(page.locator("#pricing-heading")).toBeVisible({
            visible: tierHasPermission(tier, "show_pricing"),
          });

          // Check Product Demos Section //
          await expect(page.locator("#product-demos-heading")).toBeVisible({
            visible: tierHasPermission(tier, "show_demos"),
          });
        }
      }
    )
  );
});
