import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { TestDIContainer } from "~/di-containers/test.di-container.server";
import { faker } from "@faker-js/faker";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import {
  ProductState,
  Role,
  SubscriptionStatus,
  Tier,
  UserRoleType,
  VendorState,
} from "@prisma/client";
import { slugify } from "~/utils/string.utils";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const { db } = TestDIContainer();

    const user = await registerNewUser(page);

    // Insert category
    const categoryName =
      faker.commerce.department() +
      " " +
      faker.number.int({ min: 1, max: 1000 });
    const category = await db.productCategory.create({
      data: {
        name: categoryName,
        description: faker.commerce.productDescription(),
        slug: slugify(categoryName),
        faq_1: "faq",
        faq_2: "faq",
        faq_3: "faq",
        faq_1_answer: "faq",
        faq_2_answer: "faq",
        faq_3_answer: "faq",
        page_title: categoryName,
        meta_description: categoryName,
      },
    });

    // Insert vendor
    const vendor = await db.vendor.create({
      data: {
        slug: faker.internet.url(),
        name: faker.company.name(),
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
      },
    });

    const productName = faker.commerce.productName();

    // Insert product
    const product = await db.product.create({
      data: {
        title: productName,
        slug: slugify(productName),
        description: faker.commerce.productDescription(),
        positioning: "",
        approved_at: new Date(),
        primary_category: { connect: { id: category.id } },
        vendor: { connect: { id: vendor.id } },
        page_title: productName,
        meta_description: productName,
        state: ProductState.discovery,
      },
    });

    // Stripe setup
    const stripeProduct = await db.stripeProduct.create({
      data: {
        id: `prod_${faker.string.uuid()}`,
        name: "product",
        active: true,
        tier: Tier.tier_3,
        description: "product",
      },
    });

    const stripePrice = await db.stripePrice.create({
      data: {
        id: `price_${faker.string.uuid()}`,
        product: { connect: { id: stripeProduct.id } },
        active: true,
        cadence: "monthly",
        price: 1000,
      },
    });

    // Insert subscription
    const productSubscription = await db.productSubscription.create({
      data: {
        stripe_id: `sub_${faker.string.uuid()}`,
        status: SubscriptionStatus.active,
        product: { connect: { id: product.id } },
        stripe_price: { connect: { id: stripePrice.id } },
      },
    });

    const userRole = await db.userRole.create({
      data: {
        user_id: user.id,
        resource_id: productSubscription.id,
        type: UserRoleType.PRODUCT_SUBSCRIPTION,
        role: Role.OWNER,
      },
    });

    const reviewers = await Promise.all(
      Array.from("_".repeat(faker.number.int({ min: 2, max: 10 }))).map(
        async _ =>
          await db.user.create({
            data: {
              email: faker.internet.email(),
              first_name: faker.person.firstName(),
              last_name: faker.person.lastName(),
            },
          })
      )
    );

    // Insert reviews
    const reviews = await Promise.all(
      reviewers.map(
        async reviewer =>
          await db.productReview.create({
            data: {
              approved_at: faker.date.past(),
              product: { connect: { id: product.id } },
              compatibility_score: faker.number.int({ min: 2, max: 5 }),
              customer_service_score: faker.number.int({ min: 2, max: 5 }),
              onboarding_score: faker.number.int({ min: 2, max: 5 }),
              value_score: faker.number.int({ min: 2, max: 5 }),
              compatibility_desc: faker.lorem.sentence(),
              customer_service_desc: faker.lorem.sentence(),
              decision_maker: faker.person.firstName(),
              dislike_most: faker.lorem.sentence(),
              like_most: faker.lorem.sentence(),
              onboarding_desc: faker.lorem.sentence(),
              primary_use_case: faker.lorem.sentence(),
              recommend_to: faker.lorem.sentence(),
              show_company: faker.datatype.boolean(),
              show_job_title: faker.datatype.boolean(),
              show_last_name: faker.datatype.boolean(),
              user: { connect: { id: reviewer.id } },
              value_desc: faker.lorem.sentence(),
            },
          })
      )
    );

    return {
      user,
      category,
      vendor,
      product,
      stripeProduct,
      stripePrice,
      productSubscription,
      userRole,
      reviewers,
      reviews,
    };
  },
  cleanup: async ({
    user,
    category,
    vendor,
    product,
    stripeProduct,
    stripePrice,
    productSubscription,
    userRole,
    reviewers,
    reviews,
  }) => {
    const { db } = TestDIContainer();

    await db.productReview.deleteMany({
      where: { id: { in: reviews.map(r => r.id) } },
    });
    await db.user.deleteMany({
      where: { id: { in: reviewers.map(r => r.id) } },
    });
    await db.userRole.delete({ where: { id: userRole.id } });
    await db.productSubscription.delete({
      where: { id: productSubscription.id },
    });
    await db.stripePrice.delete({ where: { id: stripePrice.id } });
    await db.stripeProduct.delete({ where: { id: stripeProduct.id } });
    await db.product.delete({ where: { id: product.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.productCategory.delete({ where: { id: category.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe("Vendor > Reviews", () => {
  test(
    "Navigation to reviews",
    withFixture(async ({ page, baseURL, reviews }) => {
      await page.click(`#vendor-portal-link`);

      await page.click(`#vendor-reviews-link`);

      // Check title
      await expect(page.locator(`h1`)).toHaveText("Reviews");

      // Check reviews table rows
      const rows = await page.locator(`tbody tr`);
      await expect(rows).toHaveCount(reviews.length);

      // Navigate to first review
      await page.locator(`#row-${reviews[0].id}`).click();
      await expect(page).toHaveURL(`/vendor/reviews/${reviews[0].id}`);

      // Navigate back
      await page.click(`#vendor-reviews-link`);

      // Navigate to last review
      await page.locator(`#row-${reviews[reviews.length - 1].id}`).click();
      await expect(page).toHaveURL(
        `/vendor/reviews/${reviews[reviews.length - 1].id}`
      );
    })
  );
});
