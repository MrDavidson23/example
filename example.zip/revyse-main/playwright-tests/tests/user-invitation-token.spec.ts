import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { createAccount } from "prisma/seed/intelligence.seed";
import { faker } from "@faker-js/faker";
import {
  fillRegistrationForm,
  registerNewUser,
} from "./page-helpers/sign-up.spec.helper";
import { ManagerAccountRoleType, UserRoleType } from "@prisma/client";
import { createProductWithSubscription } from "./db-helpers/product-subscription.spec.helper";

const invitedUserEmail = faker.internet.email({ provider: "test.com" });
const withFixture = withE2EFixtureFactory({
  setup: async ({ page, db }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const productSubscription = await createProductWithSubscription(user.id);

    const intelligenceInvitation = await db.userInvitation.create({
      data: {
        email: invitedUserEmail,
        role: {
          role: ManagerAccountRoleType.Viewer,
          manager_account_id: account.id,
        },
      },
    });
    const productInvitation = await db.userInvitation.create({
      data: {
        email: invitedUserEmail,
        role: {
          role: UserRoleType.PRODUCT_SUBSCRIPTION,
          resource_id: productSubscription.productSubscription.id,
        },
      },
    });
    await page.goto(`/logout`);
    return {
      user,
      account,
      intelligenceInvitation,
      productInvitation,
      ...productSubscription,
    };
  },
  cleanup: async ({
    db,
    user,
    account,
    category,
    vendor,
    product,
    stripeProduct,
    stripePrice,
    productSubscription,
    userRole,
    intelligenceInvitation,
    productInvitation,
  }) => {
    await db.userRole.delete({ where: { id: userRole.id } });
    await db.productSubscription.delete({
      where: { id: productSubscription.id },
    });
    await db.stripePrice.delete({ where: { id: stripePrice.id } });
    await db.stripeProduct.delete({ where: { id: stripeProduct.id } });
    await db.product.delete({ where: { id: product.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.productCategory.delete({ where: { id: category.id } });
    const invitedUser = await db.user.findFirstOrThrow({
      where: { email: invitedUserEmail.toLowerCase() },
    });
    await db.managerAccountRole.deleteMany({
      where: { user_id: { in: [user.id, invitedUser.id] } },
    });
    await db.userInvitation.deleteMany({
      where: { id: { in: [intelligenceInvitation.id, productInvitation.id] } },
    });
    await db.userCredential.deleteMany({
      where: { user_id: user.id },
    });
    await db.user.delete({ where: { id: user.id } });
    await db.userCredential.deleteMany({
      where: { user_id: invitedUser?.id },
    });
    await db.user.deleteMany({ where: { id: invitedUser?.id } });
    await db.managerAccount.delete({ where: { id: account.id } });
  },
});

test.describe("User Invitation Token page", () => {
  test(
    "Accept vendor intelligence invitation logged in as the invited user",
    withFixture(async ({ page, baseURL, account, intelligenceInvitation }) => {
      await page.goto(`/user-invitation/${intelligenceInvitation?.id}`);
      await expect(page).toHaveURL(
        `login?redirectTo=%2Fuser-invitation%2F${intelligenceInvitation?.id}`
      );
      await page.locator("#or-sign-up-link").click();
      await expect(page).toHaveURL(
        `sign-up?redirectTo=%2Fuser-invitation%2F${intelligenceInvitation?.id}`
      );
      await fillRegistrationForm(page, invitedUserEmail);
      await page.getByRole("button", { name: "Sign Up" }).click();
      await page.locator("#user-invitation-redirect").click();
      const response = await page.request.get(
        `${baseURL}/intelligence/${account.id}`
      );
      await expect(response).toBeOK();
    })
  );

  test(
    "Accept product subscription invitation logged in as the invited user",
    withFixture(async ({ page, baseURL, intelligenceInvitation }) => {
      await page.goto(`/user-invitation/${intelligenceInvitation?.id}`);
      await expect(page).toHaveURL(
        `login?redirectTo=%2Fuser-invitation%2F${intelligenceInvitation?.id}`
      );
      await page.locator("#or-sign-up-link").click();
      await expect(page).toHaveURL(
        `sign-up?redirectTo=%2Fuser-invitation%2F${intelligenceInvitation?.id}`
      );
      await fillRegistrationForm(page, invitedUserEmail);
      await page.getByRole("button", { name: "Sign Up" }).click();
      await page.locator("#user-invitation-redirect").click();
      const response = await page.request.get(`${baseURL}/vendor`);
      await expect(response).toBeOK();
    })
  );
});
