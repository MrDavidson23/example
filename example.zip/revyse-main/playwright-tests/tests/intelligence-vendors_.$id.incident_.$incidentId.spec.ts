import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);
    return { user, account, vendor, accountVendor };
  },
  cleanup: async ({ db, user, account, vendor }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
  },
});

test.describe("Intelligence Vendor Incident Page", () => {
  test(
    "Create new vendor incident",
    withFixture(async ({ page, accountVendor, account }) => {
      await page.goto(
        `/intelligence/${account.id}/vendors/${accountVendor.id}/incident/new`
      );
      // Submit empty form
      await page.locator("#save-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        DEFAULT_FORM_ERROR_MESSAGE
      );

      // Add incident
      await page.locator("#name").fill("New incident");
      await page.locator("#save-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Incident created successfully"
      );

      // Edit incidient
      await page.locator('*[id*="incident_"]').first().click();
      await page.locator("#name").fill("New incident name");
      await page.locator("#status").selectOption("InProgress");
      await page.locator("#created_date").fill("2021-01-01");
      await page.locator("#resolved_date").fill("2022-01-01");
      await page.locator("#nature_scope_timing").fill("A");
      await page.locator("#save-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Incident updated successfully"
      );
    })
  );
});
