import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { TestDIContainer } from "~/di-containers/test.di-container.server";
import { faker } from "@faker-js/faker";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import {
  ProductState,
  Role,
  SubscriptionStatus,
  Tier,
  UserRoleType,
  VendorState,
} from "@prisma/client";
import { slugify } from "~/utils/string.utils";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const { db } = TestDIContainer();

    const user = await registerNewUser(page);

    // Insert category
    const categoryName =
      faker.commerce.department() +
      " " +
      faker.number.int({ min: 1, max: 1000 });
    const category = await db.productCategory.create({
      data: {
        name: categoryName,
        description: faker.commerce.productDescription(),
        slug: slugify(categoryName),
        faq_1: "faq",
        faq_2: "faq",
        faq_3: "faq",
        faq_1_answer: "faq",
        faq_2_answer: "faq",
        faq_3_answer: "faq",
        page_title: categoryName,
        meta_description: categoryName,
      },
    });

    // Insert 4 vendors
    const vendors = await Promise.all(
      Array.from({ length: 4 }).map(async () => {
        const vendorName = faker.company.name();
        return await db.vendor.create({
          data: {
            slug: slugify(vendorName),
            name: vendorName,
            website: faker.internet.url(),
            state: VendorState.ApprovedForPublishing,
          },
        });
      })
    );

    // Insert 4 products
    const products = await Promise.all(
      vendors.map(async vendor => {
        const productName = faker.commerce.productName();
        return await db.product.create({
          data: {
            title: productName,
            slug: slugify(productName),
            description: faker.commerce.productDescription(),
            positioning: "",
            approved_at: new Date(),
            primary_category: { connect: { id: category.id } },
            vendor: { connect: { id: vendor.id } },
            page_title: productName,
            meta_description: productName,
            state: ProductState.discovery,
          },
        });
      })
    );

    // Stripe setup
    const stripeProducts = await Promise.all(
      Object.values(Tier).map(async tier => {
        return await db.stripeProduct.create({
          data: {
            id: `prod_${faker.string.uuid()}`,
            name: "product",
            active: true,
            tier: tier,
            description: "product",
          },
        });
      })
    );

    const stripePrices = await Promise.all(
      stripeProducts.map(async stripeProduct => {
        return await db.stripePrice.create({
          data: {
            id: `price_${faker.string.uuid()}`,
            product: { connect: { id: stripeProduct.id } },
            active: true,
            cadence: "monthly",
            price: 1000,
          },
        });
      })
    );

    // Insert 4 subscription
    const productSubscriptions = await Promise.all(
      products.map(async (product, index) => {
        return await db.productSubscription.create({
          data: {
            product: { connect: { id: product.id } },
            stripe_price: { connect: { id: stripePrices[index].id } },
            status: SubscriptionStatus.active,
            stripe_id: `sub_${faker.string.uuid()}`,
          },
        });
      })
    );

    // Insert user roles
    await Promise.all(
      productSubscriptions.map(async productSubscription => {
        await db.userRole.create({
          data: {
            user_id: user.id,
            resource_id: productSubscription.id,
            type: UserRoleType.PRODUCT_SUBSCRIPTION,
            role: Role.OWNER,
          },
        });
      })
    );

    return {
      user,
      category,
      vendors,
      products,
      stripeProducts,
      stripePrices,
      productSubscriptions,
    };
  },
  cleanup: async ({
    user,
    category,
    vendors,
    products,
    stripeProducts,
    stripePrices,
    productSubscriptions,
  }) => {
    const { db } = TestDIContainer();

    await db.userRole.deleteMany({ where: { user_id: user.id } });
    await db.productSubscription.deleteMany({
      where: { id: { in: productSubscriptions.map(ps => ps.id) } },
    });
    await db.stripePrice.deleteMany({
      where: { id: { in: stripePrices.map(sp => sp.id) } },
    });
    await db.stripeProduct.deleteMany({
      where: { id: { in: stripeProducts.map(sp => sp.id) } },
    });
    await db.product.deleteMany({
      where: { id: { in: products.map(p => p.id) } },
    });
    await db.vendor.deleteMany({
      where: { id: { in: vendors.map(v => v.id) } },
    });
    await db.productCategory.delete({ where: { id: category.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe("Vendor > Products", () => {
  test(
    "Check products table and navigate to product details",
    withFixture(async ({ page, productSubscriptions }) => {
      await page.click(`#vendor-portal-link`);
      await page.click(`#vendor-products-link`);

      // Check title
      await expect(page.locator(`h1`)).toHaveText("Product Listings");

      // Check products table rows
      const rows = await page.locator(`tbody tr`);
      await expect(rows).toHaveCount(productSubscriptions.length);

      // Navigate to first product
      await page
        .locator(`#row-${productSubscriptions[0].id}`)
        .locator("td")
        .first()
        .click();
      await expect(page).toHaveURL(
        `/vendor/products/${productSubscriptions[0].product_id}`
      );

      // Navigate back
      await page.click(`#vendor-products-link`);

      // Navigate to last product
      await page
        .locator(
          `#row-${productSubscriptions[productSubscriptions.length - 1].id}`
        )
        .locator("td")
        .first()
        .click();
      await expect(page).toHaveURL(
        `/vendor/products/${
          productSubscriptions[productSubscriptions.length - 1].product_id
        }`
      );
    })
  );

  test(
    "Check product listing edit screen and save changes",
    withFixture(async ({ page, products, productSubscriptions }) => {
      await page.click(`#vendor-portal-link`);
      await page.click(`#vendor-products-link`);

      // Navigate to first product
      await page
        .locator(`#row-${productSubscriptions[2].id}`)
        .locator("td")
        .first()
        .click();

      // Check product title
      await expect(page.locator(`[name='title']`)).toHaveValue(
        products[2].title
      );

      // Check product description
      await expect(page.locator(`[name='description']`)).toHaveValue(
        products[2].description
      );

      // Edit product description
      const newDescription = faker.commerce.productDescription();
      await page.fill(`[name='description']`, newDescription);

      // Save changes
      await page.click(`#save-button`);

      // Go back to product listing
      await page.click(`#vendor-products-link`);

      // Check product description
      await page
        .locator(`#row-${productSubscriptions[2].id}`)
        .locator("td")
        .first()
        .click();
      await expect(page.locator(`[name='description']`)).toHaveValue(
        newDescription
      );
    })
  );

  test(
    "Product View Listing link",
    withFixture(async ({ page, productSubscriptions, products }) => {
      await page.click(`#vendor-portal-link`);
      await page.click(`#vendor-products-link`);

      // Navigate to first product
      await page
        .locator(`#row-${productSubscriptions[1].id}`)
        .locator("td")
        .first()
        .click();

      // Click on View Listing link
      await page.click(`#view-listing`);

      // Check url
      await expect(page).toHaveURL(`/products/${products[1].slug}`);
    })
  );
});
