import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { faker } from "@faker-js/faker";
import { loginWithUser } from "./page-helpers/login.spec.helper";

const FORM_ERROR_MESSAGE =
  "There were problems submitting your form. Please try again.";
const FORM_SUCCESS_MESSAGE = "Success!";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page, db }) => {
    const userX = await db.user.create({
      data: {
        email: faker.internet.email({ provider: "example.com" }),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
      },
    });
    const user = await registerNewUser(page);
    return { user, userX };
  },
  cleanup: async ({ db, user, userX }) => {
    await db.user.delete({ where: { id: user.id } });
    await db.user.delete({ where: { id: userX.id } });
  },
});

test.describe.parallel("Profile", () => {
  test(
    "Change profile data with used email, empty fields and  not matching passwords",
    withFixture(async ({ page, user, userX }) => {
      await page.click("#profile-link");

      // Fill in the form with used email
      await page.fill("#email", userX.email);
      await page.click("#save-profile");

      // Check error message
      await expect(page.locator("#toast")).toHaveText(FORM_ERROR_MESSAGE);
      await expect(page.locator("#errors-email")).toHaveText(
        `User with email ${userX.email} already exists`
      );

      // Fill in the form with empty fields
      await page.fill("#first_name", "");
      await page.fill("#last_name", "");
      await page.click("#save-profile");

      // Check error message
      await expect(page.locator("#toast")).toHaveText(FORM_ERROR_MESSAGE);
      await expect(page.locator("#errors-first_name")).toHaveText("Required");
      await expect(page.locator("#errors-last_name")).toHaveText("Required");

      // Fill in the form with not matching passwords
      await page.fill("#password", "password");
      await page.fill("#password-confirmation", "notMatching");
      await page.click("#save-password");

      // Check error message
      await expect(page.locator("#toast")).toHaveText(FORM_ERROR_MESSAGE);
      await expect(page.locator("#errors-password-confirmation")).toHaveText(
        "Passwords do not match"
      );
    })
  );

  test(
    "Change profile data with valid data",
    withFixture(async ({ page, user }) => {
      await page.click("#profile-link");

      // Fill in the form with new data
      await page.fill("#first_name", "New");
      await page.fill("#last_name", "Name");
      await page.fill(
        "#email",
        faker.internet.email({ provider: "example.com" })
      );
      await page.click("#save-profile");

      // Check success message
      await expect(page.locator("#toast")).toHaveText(FORM_SUCCESS_MESSAGE);

      // Check the user data
      await page.reload();

      await expect(page.locator("#first_name")).toHaveValue("New");
      await expect(page.locator("#last_name")).toHaveValue("Name");
    })
  );

  test(
    "Change password and log in with new password",
    withFixture(async ({ page, user }) => {
      await page.click("#profile-link");

      const password = "newPassword";

      // Fill in the form with new password
      await page.fill("#password", password);
      await page.fill("#password-confirmation", password);
      await page.click("#save-password");

      // Check success message
      await expect(page.locator("#toast")).toHaveText(FORM_SUCCESS_MESSAGE);

      // Log out
      await page.goto("/logout");

      // Log in with new password
      await loginWithUser(page, "/", user.email, password);

      // Check the user data
      await page.click("#profile-link");
      await expect(page.locator("#email")).toHaveValue(user.email);
    })
  );
});
