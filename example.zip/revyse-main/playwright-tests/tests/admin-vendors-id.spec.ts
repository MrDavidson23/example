import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { TestDIContainer } from "~/di-containers/test.di-container.server";
import { ProductState, Role, UserRoleType, VendorState } from "@prisma/client";
import {
  createTestCategory,
  createTestProduct,
  createTestVendors,
} from "./db-helpers/general.helper";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { faker } from "@faker-js/faker";
import { slugify } from "~/utils/string.utils";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page, db }) => {
    const userGod = await registerNewUser(page);

    await db.userRole.create({
      data: {
        user_id: userGod.id,
        role: Role.GOD_MODE,
        type: UserRoleType.GLOBAL,
      },
    });

    // Insert vendors
    const vendors = await createTestVendors(
      {
        state: VendorState.ApprovedForPublishing,
      },
      { count: 2 }
    );

    // Insert category
    const category = await createTestCategory();

    // Insert published product
    const product = await createTestProduct({
      category_id: category.id,
      vendor_id: vendors[0].id,
      state: ProductState.discovery,
    });

    return { userGod, vendors, category, product };
  },
  cleanup: async ({ userGod, vendors, category, product }) => {
    const { db } = TestDIContainer();

    await db.product.delete({ where: { id: product.id } });
    await db.productCategory.delete({ where: { id: category.id } });
    await db.vendor.deleteMany({
      where: { id: { in: vendors.map(vendor => vendor.id) } },
    });
    await db.userRole.deleteMany({ where: { user_id: userGod.id } });
    await db.user.delete({ where: { id: userGod.id } });
  },
});

test.describe.parallel("Admin > Vendors > Vendor", () => {
  test(
    "Edit vendor",
    withFixture(async ({ page, vendors }) => {
      await page.goto("/");
      await page.click(`#admin-link`);
      await page.click(`#vendors-link`);

      await page.click(`#search-bar`);
      await page.locator("#search-bar").fill(vendors[1].name);
      await page.locator("#search-bar").press("Enter");
      await page.click(`#row-${vendors[1].id}`);

      const newVendor = {
        name: faker.company.name(),
        description: faker.company.catchPhrase(),
      };

      // Fill form
      await page.locator("[name=name]").fill(newVendor.name);
      await page.locator("[name=description]").fill(newVendor.description);
      await page.locator("[name=slug]").fill(slugify(newVendor.name));
      await page
        .locator(`[name=state][value=${VendorState.RevyseIntelligenceOnly}]`)
        .setChecked(true);

      await page.click(`#save-button`);

      // Check success
      await expect(page.locator(".Toastify").first()).toContainText(
        "Vendor updated successfully"
      );

      await expect(page.locator("[name=name]")).toHaveValue(newVendor.name);
      await expect(page.locator("[name=description]")).toHaveValue(
        newVendor.description!
      );
      await expect(page.locator("[name=slug]")).toHaveValue(
        slugify(newVendor.name)
      );
      await expect(page.locator("[name=state][checked]")).toHaveValue(
        VendorState.RevyseIntelligenceOnly
      );
    })
  );

  test(
    "Delete vendor",
    withFixture(async ({ page, vendors }) => {
      await page.goto("/");
      await page.click(`#admin-link`);
      await page.click(`#vendors-link`);

      // Try deleting one with a published product
      await page.click(`#search-bar`);
      await page.locator("#search-bar").fill(vendors[0].name);
      await page.locator("#search-bar").press("Enter");
      await page.click(`#row-${vendors[0].id}`);
      await page.click(`#delete-button`);
      await page.click(`#confirm-delete-button`);

      // Check error message
      await expect(page.locator(".Toastify").first()).toContainText(
        "This vendor is associated with a published product or is part of an intelligence account"
      );

      // Try deleting one without a published product
      await page.goBack();
      await page.click(`#search-bar`);
      await page.locator("#search-bar").fill(vendors[1].name);
      await page.locator("#search-bar").press("Enter");
      await page.click(`#row-${vendors[1].id}`);
      await page.click(`#delete-button`);
      await page.click(`#confirm-delete-button`);

      // Check success
      await expect(page.locator(".Toastify").first()).toContainText(
        "Vendor deleted successfully"
      );

      // Check row is not visible
      await page.click(`#search-bar`);
      await page.locator("#search-bar").fill(vendors[1].name);
      await page.locator("#search-bar").press("Enter");
      await page.waitForLoadState("networkidle");
      await expect(page.locator(`#row-${vendors[0].id}`)).not.toBeVisible();
    })
  );
});
