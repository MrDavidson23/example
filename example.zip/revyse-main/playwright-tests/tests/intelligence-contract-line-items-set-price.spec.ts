import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import {
  createContract,
  createContractLineItem,
} from "./db-helpers/intelligence.helper";
import { map } from "lodash";
import {
  createTestCategory,
  createTestProducts,
} from "./db-helpers/general.helper";
import {
  ContractLineItemPriceCadence,
  ContractPricingType,
} from "@prisma/client";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);

    const category = await createTestCategory();

    const products = await createTestProducts(
      { category_id: category.id },
      { count: 3 }
    );

    const contract = await createContract(accountVendor.id);

    const contractLineItemSingleProduct = await createContractLineItem(
      contract,
      [products[0].id],
      []
    );

    const contractLineItemMultipleProducts = await await createContractLineItem(
      contract,
      map(products, "id"),
      []
    );

    return {
      user,
      account,
      vendor,
      accountVendor,
      category,
      products,
      contract,
      contractLineItemSingleProduct,
      contractLineItemMultipleProducts,
    };
  },
  cleanup: async ({
    db,
    user,
    account,
    vendor,
    accountVendor,
    category,
    products,
    contract,
    contractLineItemSingleProduct,
    contractLineItemMultipleProducts,
  }) => {
    await db.contractLineItemProduct.deleteMany({
      where: {
        contract_line_item_id: {
          in: [
            contractLineItemSingleProduct.id,
            contractLineItemMultipleProducts.id,
          ],
        },
      },
    });
    await db.contractLineItem.deleteMany({
      where: {
        id: {
          in: [
            contractLineItemSingleProduct.id,
            contractLineItemMultipleProducts.id,
          ],
        },
      },
    });
    await db.contract.delete({
      where: { id: contract.id },
    });
    await db.product.deleteMany({ where: { id: { in: map(products, "id") } } });
    await db.productCategory.delete({ where: { id: category.id } });
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccountVendor.delete({ where: { id: accountVendor.id } });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe
  .parallel("Intelligence Contract Line Item Set Price Screen", () => {
  test(
    "Set price to a single product contract line item",
    withFixture(
      async ({ page, account, contract, contractLineItemSingleProduct }) => {
        await page.goto("/intelligence");
        await page.locator("#contracts-link").click();

        await page.locator("#search-bar").click();
        await page.locator("#search-bar").fill(contract.name);
        await page.locator("#search-bar").press("Enter");

        await page.locator(`#row_${contract.id}`).first().click();

        await page.locator("#contract-line-items-tab").click();

        await page.locator(`#row_${contractLineItemSingleProduct.id}`).click();
        await page.locator("#primary-edit-pricing-button").click();

        // Check correct contract line item name is displayed
        await expect(page.locator("[name=name]")).toHaveValue(
          contractLineItemSingleProduct.contract_line_item_products[0].product
            .title!
        );

        // Edit form

        await page
          .locator(
            `[name=is_corporate_only][value=${String(
              !contractLineItemSingleProduct.is_corporate_only
            )}]`
          )
          .click();
        await page
          .locator("[name='contract_line_item.cadence']")
          .selectOption(ContractLineItemPriceCadence.Quarterly);
        await page
          .locator("[name='contract_line_item.pricing_type']")
          .selectOption(ContractPricingType.PerSeat);
        await page
          .locator("[name='contract_line_item.seats_number']")
          .fill("100");
        await page.locator("[name='contract_line_item.price']").fill("1000");

        await page.locator("#save-button").first().click();

        await expect(page.locator(".Toastify").first()).toContainText(
          "Pricing updated successfully"
        );

        // Check if the updated values are displayed
        await page.locator("#primary-edit-pricing-button").click();

        await expect(
          page.locator(
            `[name=is_corporate_only][value=${String(
              !contractLineItemSingleProduct.is_corporate_only
            )}]`
          )
        ).toBeChecked();
        await expect(
          page.locator("[name='contract_line_item.cadence']")
        ).toHaveValue(ContractLineItemPriceCadence.Quarterly);
        await expect(
          page.locator("[name='contract_line_item.pricing_type']")
        ).toHaveValue(ContractPricingType.PerSeat);
        await expect(
          page.locator("[name='contract_line_item.seats_number']")
        ).toHaveValue("100");
        await expect(
          page.locator("[name='contract_line_item.price']")
        ).toHaveValue("$1,000");
      }
    )
  );

  test(
    "Set price to a multiple products contract line item",
    withFixture(
      async ({
        page,
        account,
        contract,
        products,
        contractLineItemMultipleProducts,
      }) => {
        await page.goto("/intelligence");
        await page.locator("#contracts-link").click();

        await page.locator("#search-bar").click();
        await page.locator("#search-bar").fill(contract.name);
        await page.locator("#search-bar").press("Enter");

        await page.locator(`#row_${contract.id}`).first().click();

        await page.locator("#contract-line-items-tab").click();

        await page
          .locator(`#row_${contractLineItemMultipleProducts.id}`)
          .click();
        await page.locator("#primary-edit-pricing-button").click();

        // Check correct contract line item name is displayed
        await expect(page.locator("[name=name]")).toHaveValue(
          contractLineItemMultipleProducts.name!
        );

        // Edit form
        await page
          .locator(
            `[name=is_corporate_only][value=${String(
              !contractLineItemMultipleProducts.is_corporate_only
            )}]`
          )
          .click();
        await page
          .locator("[name='contract_line_item.cadence']")
          .selectOption(ContractLineItemPriceCadence.Annual);
        await page
          .locator("[name='contract_line_item.pricing_type']")
          .selectOption(ContractPricingType.PerLocation);

        await page.waitForLoadState("domcontentloaded");

        // Edit price for each product
        for (let i = 0; i < products.length; i++) {
          await page
            .locator(
              `[name='contract_line_item.${contractLineItemMultipleProducts.id}.contract_line_item_products.price']`
            )
            .nth(i)
            .fill(`${i + 1}000`);
        }

        await page.locator("#save-button").first().click();

        await expect(page.locator(".Toastify").first()).toContainText(
          "Pricing updated successfully"
        );

        // Check if the updated values are displayed
        await page.locator("#primary-edit-pricing-button").click();

        await expect(
          page.locator(
            `[name=is_corporate_only][value=${String(
              !contractLineItemMultipleProducts.is_corporate_only
            )}]`
          )
        ).toBeChecked();
        await expect(
          page.locator("[name='contract_line_item.cadence']")
        ).toHaveValue(ContractLineItemPriceCadence.Annual);
        await expect(
          page.locator("[name='contract_line_item.pricing_type']")
        ).toHaveValue(ContractPricingType.PerLocation);

        // Check if the updated prices are displayed
        for (let i = 0; i < products.length; i++) {
          await expect(
            page
              .locator(
                `[name='contract_line_item.${contractLineItemMultipleProducts.id}.contract_line_item_products.price']`
              )
              .nth(i)
          ).toHaveValue(`$${i + 1},000`);
        }
      }
    )
  );
});
