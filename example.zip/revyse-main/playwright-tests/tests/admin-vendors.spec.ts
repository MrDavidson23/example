import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { TestDIContainer } from "~/di-containers/test.di-container.server";
import { Role, UserRoleType, VendorState } from "@prisma/client";
import { createTestVendors } from "./db-helpers/general.helper";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { faker } from "@faker-js/faker";
import { slugify } from "~/utils/string.utils";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page, db }) => {
    const userGod = await registerNewUser(page);

    await db.userRole.create({
      data: {
        user_id: userGod.id,
        role: Role.GOD_MODE,
        type: UserRoleType.GLOBAL,
      },
    });

    // Insert vendors
    const vendors = await createTestVendors(
      { state: VendorState.ApprovedForPublishing },
      { count: 23 }
    );

    return { userGod, vendors };
  },
  cleanup: async ({ userGod, vendors }) => {
    const { db } = TestDIContainer();

    await db.vendor.deleteMany({
      where: { id: { in: vendors.map(vendor => vendor.id) } },
    });
    await db.userRole.deleteMany({ where: { user_id: userGod.id } });
    await db.user.delete({ where: { id: userGod.id } });
  },
});

test.describe("Admin > Vendors", () => {
  test(
    "Navigation to vendors, check table display, navigate to edit vendor and check fields",
    withFixture(async ({ page, vendors }) => {
      await page.goto("/");
      await page.click(`#admin-link`);
      await page.click(`#vendors-link`);

      // Check table rows data
      for (const vendor of faker.helpers.arrayElements(vendors, 3)) {
        await page.locator("#search-bar").click();
        await page.locator("#search-bar").fill(vendor.name);
        await page.locator("#search-bar").press("Enter");
        await expect(page.locator(`#row-${vendor.id}`)).toBeVisible();
        await expect(
          page
            .locator(`#row-${vendor.id}`)
            .getByRole("cell", { name: vendor.name })
        ).toBeVisible();
      }

      // Navigate to edit vendor
      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(vendors[0].name);
      await page.locator("#search-bar").press("Enter");
      await page.click(`#row-${vendors[0].id}`);

      // Check vendor fields
      await expect(page.locator("[name=name]")).toHaveValue(vendors[0].name);
      await expect(page.locator("[name=description]")).toHaveValue(
        vendors[0].description!
      );
      await expect(page.locator("[name=slug]")).toHaveValue(vendors[0].slug!);
      await expect(page.locator("[name=state][checked]")).toHaveValue(
        vendors[0].state
      );
    })
  );

  test(
    "Create new vendor",
    withFixture(async ({ page }) => {
      await page.goto("/");
      await page.click(`#admin-link`);
      await page.click(`#vendors-link`);

      await page.click(`#add-button`);

      const newVendor = {
        name: faker.company.name(),
        description: faker.company.catchPhrase(),
      };

      // Fill form
      await page.locator("[name=name]").fill(newVendor.name);
      await page.locator("[name=description]").fill(newVendor.description);
      await page.locator("[name=slug]").fill(slugify(newVendor.name));

      await page.click(`#save-button`);

      // Check success
      await expect(page.locator(".Toastify").first()).toContainText(
        "Vendor created successfully"
      );

      await expect(page.locator("[name=name]")).toHaveValue(newVendor.name);
      await expect(page.locator("[name=description]")).toHaveValue(
        newVendor.description!
      );
      await expect(page.locator("[name=slug]")).toHaveValue(
        slugify(newVendor.name)
      );
    })
  );
});
