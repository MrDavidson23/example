import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { faker } from "@faker-js/faker";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    return {
      user,
    };
  },
  cleanup: async ({ db, user }) => {
    await db.userCredential.delete({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe("Vendor Intelligence Page", () => {
  test(
    "Test Interested in learning more? Form",
    withFixture(async ({ page }) => {
      await page.locator("#intelligence-link").click();
      await page.locator("#first_name").fill(faker.person.firstName());
      await page.locator("#last_name").fill(faker.person.lastName());
      await page.locator("#email").fill(faker.internet.email());
      await page.locator("#company").fill(faker.company.name());
      await page.locator("#message").fill(faker.lorem.paragraph());
      await page.locator("#submit-intelligence-form").click();

      await expect(page).toHaveURL("/connect-success");
    })
  );
});
