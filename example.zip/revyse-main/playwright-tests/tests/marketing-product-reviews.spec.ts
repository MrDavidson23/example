import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { createProductWithSubscription } from "./db-helpers/product-subscription.spec.helper";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "~/di-containers/test.di-container.server";
import { fillReviewForm } from "./page-helpers/review-form.spec.helper";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const { db } = TestDIContainer();

    const user = await registerNewUser(page);
    const productSubscription = await createProductWithSubscription(user.id);
    const reviewers = await Promise.all(
      Array.from("_".repeat(5)).map(
        async _ =>
          await db.user.create({
            data: {
              email: faker.internet.email(),
              first_name: faker.person.firstName(),
              last_name: faker.person.lastName(),
            },
          })
      )
    );

    const reviews = await Promise.all(
      reviewers.map(
        async reviewer =>
          await db.productReview.create({
            data: {
              approved_at: faker.date.past(),
              approved_by: {
                connect: {
                  id: user.id,
                },
              },
              product: { connect: { id: productSubscription.product.id } },
              compatibility_score: faker.number.int({ min: 2, max: 5 }),
              customer_service_score: faker.number.int({ min: 2, max: 5 }),
              onboarding_score: faker.number.int({ min: 2, max: 5 }),
              value_score: faker.number.int({ min: 2, max: 5 }),
              compatibility_desc: faker.lorem.sentence(),
              customer_service_desc: faker.lorem.sentence(),
              decision_maker: faker.person.firstName(),
              dislike_most: faker.lorem.sentence(),
              like_most: faker.lorem.sentence(),
              onboarding_desc: faker.lorem.sentence(),
              primary_use_case: faker.lorem.sentence(),
              recommend_to: faker.lorem.sentence(),
              show_company: faker.datatype.boolean(),
              show_job_title: faker.datatype.boolean(),
              show_last_name: faker.datatype.boolean(),
              user: { connect: { id: reviewer.id } },
              value_desc: faker.lorem.sentence(),
            },
          })
      )
    );
    return {
      user,
      reviews,
      ...productSubscription,
    };
  },
  cleanup: async ({
    db,
    user,
    category,
    vendor,
    product,
    stripeProduct,
    stripePrice,
    productSubscription,
    userRole,
    reviews,
  }) => {
    await db.productReview.deleteMany({
      where: { id: { in: reviews.map(r => r.id) } },
    });
    await db.userRole.delete({ where: { id: userRole.id } });
    await db.productSubscription.delete({
      where: { id: productSubscription.id },
    });
    await db.stripePrice.delete({ where: { id: stripePrice.id } });
    await db.stripeProduct.delete({ where: { id: stripeProduct.id } });
    await db.productReview.deleteMany({ where: { product_id: product.id } });
    await db.product.delete({ where: { id: product.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.productCategory.delete({ where: { id: category.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe("Product Reviews Page", () => {
  test(
    "Test product reviews page actions",
    withFixture(async ({ page, product, reviews }) => {
      await page.goto(`/products/${product.slug}/reviews`);

      // Mark and unmark reviews as helpful
      await page.locator(`#mark-helpful-${reviews[2].id}`).click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Review marked as helpful. Thank you for your feedback!"
      );
      await page.locator(`#mark-helpful-${reviews[2].id}`).click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Review unmarked as helpful"
      );

      // Submit empty create review form
      await page.locator("#write-review-button").click();
      await expect(page).toHaveURL(`/products/${product.slug}/reviews/new`);
      await page.locator("#submit-review-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        DEFAULT_FORM_ERROR_MESSAGE
      );

      // Create a new product review
      await fillReviewForm(page);
      await page.locator("#submit-review-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Review submitted"
      );
    })
  );
});
