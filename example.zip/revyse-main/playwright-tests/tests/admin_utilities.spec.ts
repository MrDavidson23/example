import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { createAdminUser } from "./db-helpers/general.helper";
import { login } from "./page-helpers/login.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page, baseURL }) => {
    const user = await registerNewUser(page);
    const userRole = await createAdminUser(user.id);
    await page.goto("/logout");
    await login(page, baseURL, user.email);
    return {
      user,
      userRole,
    };
  },
  cleanup: async ({ db, user, userRole }) => {
    await db.userRole.delete({ where: { id: userRole.id } });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe("Admin User Utilities Page", () => {
  test(
    "Trigger admin utilities CTAs",
    withFixture(async ({ page }) => {
      await page.locator("#admin-link").click();
      await page.locator("#utilities-link").click();
      await page.locator("#sync-posts-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Syncing blog posts from Circle"
      );
      await page.locator("#sync-contracts-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Syncing contracts and sending renewal reminders"
      );
    })
  );
});
