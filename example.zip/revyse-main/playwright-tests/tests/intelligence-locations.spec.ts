import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import {
  addLocation,
  fillLocationForm,
} from "./page-helpers/location.spec.helper";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);
    return { user, account, vendor, accountVendor };
  },
  cleanup: async ({ db, user, account, vendor }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.location.deleteMany({ where: { manager_account_id: account.id } });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
  },
});

test.describe.parallel("Intelligence Locations", () => {
  test(
    "Add a new location manually",
    withFixture(async ({ page, db, account }) => {
      const location = await addLocation(page, db, account);
      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(location.name);
      await page.locator("#search-bar").press("Enter");
      await expect(page.locator("td:nth-child(1)").first()).toContainText(
        location.name
      );
    })
  );

  test(
    "Edit location",
    withFixture(async ({ page, db, account }) => {
      const location = await addLocation(page, db, account);
      await page.locator("[id='locations-link']").click();
      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(location.name);
      await page.locator("#search-bar").press("Enter");
      await page.locator("[id='locations-link']").click();
      await page.locator("td:nth-child(2)").first().click();
      await page.getByRole("button", { name: "Edit Location" }).click();
      await page.locator("[id='name']").click();
      await page.locator("[id='name']").fill(`${location.name} - 2`);
      await page.locator("[id='clear-owner-name']").click();
      await page.locator("[id='owner_name']").dblclick();
      await page.locator("[id='owner_name']").fill("432");
      await page.locator("[id='class']").selectOption("D");
      await page.locator("#save-button").click();
      await page.locator("[id='locations-link']").click();
      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(`${location.name} - 2`);
      await page.locator("#search-bar").press("Enter");
      await expect(page.locator("td:nth-child(1)").first()).toContainText(
        `${location.name} - 2`
      );
    })
  );

  test(
    "Delete location",
    withFixture(async ({ page, db, account }) => {
      const location = await addLocation(page, db, account);
      await page.locator("[id='locations-link']").click();
      await page.locator("[id='add-location-button']").click();
      await fillLocationForm(page, `${location.name} - For Delete`);
      await page.locator("[id='locations-link']").click();
      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(`${location.name} - For Delete`);
      await page.locator("#search-bar").press("Enter");
      await page.locator("td:nth-child(2)").first().click();
      await page.getByRole("button", { name: "Delete" }).click();
      await page.getByRole("button", { name: "Yep!" }).click();
      await expect(page.locator("td:nth-child(2)").first()).not.toContainText(
        `${location.name} - For Delete`
      );
    })
  );
});
