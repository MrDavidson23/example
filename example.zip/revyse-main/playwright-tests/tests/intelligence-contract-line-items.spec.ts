import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import {
  createContract,
  createContractLineItem,
} from "./db-helpers/intelligence.helper";
import { map } from "lodash";
import {
  createTestCategory,
  createTestProducts,
} from "./db-helpers/general.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);

    const category = await createTestCategory();

    const products = await createTestProducts(
      { category_id: category.id },
      { count: 3 }
    );

    const contract = await createContract(accountVendor.id);

    const contractLineItemSingleProduct = await createContractLineItem(
      contract,
      [products[0].id],
      []
    );

    const contractLineItemMultipleProducts = await createContractLineItem(
      contract,
      map(products, "id"),
      []
    );

    return {
      user,
      account,
      vendor,
      accountVendor,
      category,
      products,
      contract,
      contractLineItemSingleProduct,
      contractLineItemMultipleProducts,
    };
  },
  cleanup: async ({
    db,
    user,
    account,
    vendor,
    accountVendor,
    category,
    products,
    contract,
    contractLineItemSingleProduct,
    contractLineItemMultipleProducts,
  }) => {
    await db.contractLineItemProduct.deleteMany({
      where: {
        contract_line_item_id: {
          in: [
            contractLineItemSingleProduct.id,
            contractLineItemMultipleProducts.id,
          ],
        },
      },
    });
    await db.contractLineItem.deleteMany({
      where: {
        id: {
          in: [
            contractLineItemSingleProduct.id,
            contractLineItemMultipleProducts.id,
          ],
        },
      },
    });
    await db.contract.delete({
      where: { id: contract.id },
    });
    await db.product.deleteMany({ where: { id: { in: map(products, "id") } } });
    await db.productCategory.delete({ where: { id: category.id } });
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccountVendor.delete({ where: { id: accountVendor.id } });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe("Intelligence Contract Line Items", () => {
  test(
    "Check navigation and display of contract line items table",
    withFixture(
      async ({
        page,
        account,
        contract,
        contractLineItemSingleProduct,
        contractLineItemMultipleProducts,
      }) => {
        await page.goto("/intelligence");
        await page.locator("#contracts-link").click();

        await page.locator("#search-bar").click();
        await page.locator("#search-bar").fill(contract.name);
        await page.locator("#search-bar").press("Enter");

        await page.locator(`#row_${contract.id}`).first().click();
        await page.locator("#contract-line-items-tab").click();

        // Check if the contract line items table is displayed
        await expect(
          page
            .locator(`#row_${contractLineItemSingleProduct.id}`)
            .getByRole("cell", { name: contractLineItemSingleProduct.name! })
        ).toBeVisible();
        await expect(
          page
            .locator(`#row_${contractLineItemMultipleProducts.id}`)
            .getByRole("cell", { name: contractLineItemMultipleProducts.name! })
        ).toBeVisible();

        // Check correct contract line item name is displayed
        await page.locator(`#row_${contractLineItemSingleProduct.id}`).click();
        await expect(page.locator("#intelligence-header-title")).toHaveText(
          `Line item summary: ${contractLineItemSingleProduct.name!}`
        );

        // Go back
        await page.goBack();

        // Check add line item button redirects to create line item screen
        await page.locator("#add-line-item-button").click();
        await expect(page.locator("#intelligence-header-title")).toHaveText(
          `Create a new line item`
        );
      }
    )
  );
});
