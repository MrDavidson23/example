import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { faker } from "@faker-js/faker";
import { createProductWithSubscription } from "./db-helpers/product-subscription.spec.helper";
import {
  createTestCategories,
  createTestIndustries,
  createTestGoodForTags,
  createTestReview,
  createTestVendors,
  createTestProducts,
} from "./db-helpers/general.helper";
import { IntegrationProvider, Role, UserRoleType } from "@prisma/client";
import { sortBy } from "lodash";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page, db }) => {
    const user = await db.user.create({
      data: {
        email: faker.internet.email({ provider: "example.com" }),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
      },
    });

    const categories = await createTestCategories({}, { count: 2 });
    const industries = await createTestIndustries({}, { count: 3 });
    const goodForTags = await createTestGoodForTags({}, { count: 3 });

    const productSubscription = await createProductWithSubscription(user.id, {
      title: faker.commerce.productName(),
      description: faker.commerce.productDescription(),
      positioning: faker.commerce.productDescription(),
      secondary_category: { connect: { id: categories[0].id } },
      tertiary_category: { connect: { id: categories[1].id } },
      demo_scheduling_url: "https://example.com",
      brand_video_urls: [
        {
          title: faker.commerce.productName(),
          url: "https://www.youtube.com/watch?v=9xwazD5SyVg",
          type: "youtube",
          embedUrl: "https://www.youtube.com/embed/9xwazD5SyVg",
        },
      ],
      demo_storylane_url: "https://www.storylane.com/demo",
      features: {
        createMany: {
          data: Array.from({ length: 2 }).map((_, i) => ({
            name: faker.commerce.productName(),
            description: faker.commerce.productDescription(),
            order: i,
          })),
        },
      },
      industries: {
        connect: industries.map(industry => ({ id: industry.id })),
      },
      good_for_tags: {
        connect: goodForTags.map(tag => ({ id: tag.id })),
      },
      packages: {
        createMany: {
          data: [
            {
              name: faker.commerce.productName(),
              description: faker.commerce.productDescription(),
              price: Number(faker.commerce.price()),
              order: 0,
              price_type: "monthly",
            },
            {
              name: faker.commerce.productName(),
              description: faker.commerce.productDescription(),
              price: Number(faker.commerce.price()),
              order: 1,
              price_type: "unit",
            },
          ],
        },
      },
      promo_text: `${faker.number.int({
        min: 10,
        max: 50,
      })}% off for ${faker.number.int({ min: 2, max: 10 })} months`,
    });

    await Promise.all(
      Array.from({ length: 5 }).map(() =>
        createTestReview({
          product_id: productSubscription.product.id,
          user_id: user.id,
        })
      )
    );

    const aggregates = await db.productReview.aggregate({
      _avg: {
        compatibility_score: true,
        customer_service_score: true,
        onboarding_score: true,
        value_score: true,
      },
      where: {
        product_id: productSubscription.product.id,
        approved_by_id: { not: null },
      },
    });

    const productRating =
      ((aggregates._avg.compatibility_score ?? 0) +
        (aggregates._avg.customer_service_score ?? 0) +
        (aggregates._avg.onboarding_score ?? 0) +
        (aggregates._avg.value_score ?? 0)) /
      4.0;

    const integratedVendors = await createTestVendors({}, { count: 3 });
    const integratedProducts = await createTestProducts(
      { category_id: categories[0].id },
      { count: 3 }
    );

    await db.vendorIntegration.createMany({
      data: [
        ...integratedVendors.map(({ id }) => ({
          integration_provider: faker.helpers.enumValue(IntegrationProvider),
          integrated_vendor_id: id,
          vendor_id: productSubscription.vendor.id,
        })),
        ...integratedProducts.map(({ id }) => ({
          integration_provider: faker.helpers.enumValue(IntegrationProvider),
          integrated_product_id: id,
          vendor_id: productSubscription.vendor.id,
        })),
      ],
    });

    const integrations = await db.vendorIntegration.findMany({
      where: {
        vendor_id: productSubscription.vendor.id,
      },
      include: {
        integrated_vendor: true,
        integrated_product: true,
      },
    });

    const buyerUser = await registerNewUser(page);
    await db.user.update({
      where: { id: buyerUser.id },
      data: {
        user_roles: {
          create: {
            type: UserRoleType.GLOBAL,
            role: Role.BUYER,
          },
        },
      },
    });

    return {
      user,
      buyerUser,
      categories,
      industries,
      goodForTags,
      ...productSubscription,
      productRating,
      integratedVendors,
      integratedProducts,
      integrations,
    };
  },
  cleanup: async ({
    db,
    user,
    buyerUser,
    categories,
    industries,
    goodForTags,
    category,
    vendor,
    product,
    stripeProduct,
    stripePrice,
    productSubscription,
    userRole,
    integratedVendors,
    integratedProducts,
    integrations,
  }) => {
    await db.userRole.deleteMany({
      where: { user_id: { in: [user.id, buyerUser.id] } },
    });
    await db.productSubscription.delete({
      where: { id: productSubscription.id },
    });
    await db.stripePrice.delete({ where: { id: stripePrice.id } });
    await db.stripeProduct.delete({ where: { id: stripeProduct.id } });
    await db.productReview.deleteMany({ where: { product_id: product.id } });
    await db.buyerContactRequest.deleteMany({
      where: { product_id: product.id },
    });
    await db.product.deleteMany({
      where: {
        id: {
          in: [product.id, ...integratedProducts.map(product => product.id)],
        },
      },
    });
    await db.vendor.deleteMany({
      where: {
        id: {
          in: [vendor.id, ...integratedVendors.map(vendor => vendor.id)],
        },
      },
    });
    await db.productCategory.deleteMany({
      where: {
        id: { in: [...categories.map(category => category.id), category.id] },
      },
    });
    await db.industry.deleteMany({
      where: { id: { in: industries.map(industry => industry.id) } },
    });
    await db.goodForTag.deleteMany({
      where: { id: { in: goodForTags.map(tag => tag.id) } },
    });
    await db.userCredential.deleteMany({
      where: { user_id: { in: [user.id, buyerUser.id] } },
    });
    await db.user.deleteMany({
      where: { id: { in: [user.id, buyerUser.id] } },
    });
    await db.vendorIntegration.deleteMany({
      where: {
        id: { in: integrations.map(integration => integration.id) },
      },
    });
  },
});

test.describe
  .parallel("Discovery > Product > Basic info displayed and CTAS", () => {
  test(
    "Check basic info displayed",
    withFixture(
      async ({
        page,
        product,
        vendor,
        productRating,
        category,
        industries,
        categories,
        goodForTags,
        integrations,
      }) => {
        await page.goto(`/products/${product.slug}`);

        // Check product basic info header //

        // Title
        await expect(page.locator("#product-title")).toHaveText(product.title);
        // Vendor
        await expect(page.locator("#product-vendor")).toHaveText(vendor.name);
        // Rating
        await expect(page.locator("#product-rating")).toHaveText(
          productRating.toFixed(1)
        );
        // Claimed
        await expect(page.locator("#claimed-listing")).toHaveText(
          "Claimed Listing"
        );

        // Check product sidebar links //
        // Sections
        await page.click("#product-overview-link");
        await expect(
          page.locator("#product-overview-heading")
        ).toBeInViewport();
        await page.click("#company-info-link");
        await expect(page.locator("#company-info-heading")).toBeInViewport();
        await page.click("#integrations-link");
        await expect(page.locator("#integrations-heading")).toBeInViewport();
        await page.click("#pricing-link");
        await expect(page.locator("#pricing-heading")).toBeInViewport();
        await page.click("#product-demos-link");
        await expect(page.locator("#product-demos-heading")).toBeInViewport();
        await page.click("#reviews-link");
        await expect(page.locator("#reviews")).toBeInViewport();

        // Check product offer //
        await expect(page.locator("#promo-text")).toHaveText(
          product.promo_text ?? "--"
        );

        // Check Product Overview //
        // Description
        await expect(page.locator("#product-description")).toHaveText(
          product.description
        );
        // Positioning
        await expect(page.locator("#product-positioning")).toHaveText(
          product.positioning
        );
        // Features
        for (const feature of product.features) {
          await expect(
            page.locator(`#product-feature-${feature.id} #product-feature-name`)
          ).toHaveText(feature.name);
          await expect(
            page.locator(
              `#product-feature-${feature.id} #product-feature-description`
            )
          ).toHaveText(feature.description);
        }
        // Product Categories
        await expect(page.locator("#product-primary-category")).toHaveText(
          category.name
        );
        await expect(page.locator("#product-primary-category")).toHaveAttribute(
          "href",
          `/categories/${category.slug}`
        );
        await expect(page.locator("#product-secondary-category")).toHaveText(
          categories[0].name
        );
        await expect(
          page.locator("#product-secondary-category")
        ).toHaveAttribute("href", `/categories/${categories[0].slug}`);
        await expect(page.locator("#product-tertiary-category")).toHaveText(
          categories[1].name
        );
        await expect(
          page.locator("#product-tertiary-category")
        ).toHaveAttribute("href", `/categories/${categories[1].slug}`);
        // Industries
        await expect(page.locator("#product-industries")).toHaveText(
          sortBy(industries, "name")
            .map(industry => industry.name)
            .join(", ")
        );
        // Good For Tags
        for (const tag of sortBy(goodForTags, "order")) {
          await expect(
            page.locator(`#product-good-for-tag-${tag.id}`)
          ).toHaveText(tag.name);
        }

        // Check Company Info //
        // Company Name
        await expect(page.locator("#company-name")).toHaveText(vendor.name);
        // Company HQ Location
        await expect(page.locator("#company-hq-location")).toHaveText(
          vendor.hq_location ?? "--"
        );
        // Company Founded Year
        await expect(page.locator("#company-founded-year")).toHaveText(
          vendor.founded_year ?? "--"
        );
        // Company Number of Employees
        await expect(page.locator("#company-number-employees")).toHaveText(
          vendor.number_employees ?? "--"
        );
        // Company Website
        await expect(page.locator("#company-website")).toHaveText(
          (vendor.website ?? "--").replace(/https?:\/\//, "") ?? "--"
        );
        await expect(page.locator("#company-website")).toHaveAttribute(
          "href",
          vendor.website ?? "#"
        );
        // Company LinkedIn Profile
        await expect(page.locator("#company-linkedin-profile")).toHaveText(
          (vendor.linkedin_profile_url ?? "--").replace(/https?:\/\//, "") ??
            "--"
        );
        await expect(page.locator("#company-linkedin-profile")).toHaveAttribute(
          "href",
          vendor.linkedin_profile_url ?? "#"
        );

        // // Check Integrations //
        // // Integrated Vendors
        // for (const integration of integrations) {
        //   await expect(
        //     page
        //       .locator(`#integration-${integration.id} #integration-name`)
        //   ).toHaveText(
        //     integration.integrated_vendor?.name ??
        //       integration.integrated_product?.title ??
        //       "--"
        //   );
        // }
      }
    )
  );

  test(
    "Check CTA",
    withFixture(async ({ page, product, vendor }) => {
      await page.goto(`/products/${product.slug}`);
      // Check product header CTAs //
      // Schedule Demo
      await expect(page.locator("#cta-schedule-a-demo")).toHaveText(
        "Schedule a Demo"
      );
      const [newPageCTA] = await Promise.all([
        page.context().waitForEvent("page"),
        page.click("#cta-schedule-a-demo"), // Opens a new tab
      ]);
      await expect(newPageCTA).toHaveURL(product.demo_scheduling_url!);

      // Contact Vendor
      await expect(page.locator("#cta-contact-vendor")).toHaveText(
        `Contact ${vendor.name}`
      );
      await page.click("#cta-contact-vendor");
      await page
        .locator("#contact-modal-form [name=description]")
        .fill(faker.lorem.sentence());
      await page.click("#contact-modal-submit");
      await page.waitForSelector("#contact-modal-form h2:has-text('Nice!')");
      await page.click("#contact-modal-form #ok-button");

      // Check product sidebar actions //
      // Schedule Demo
      await expect(page.locator("#schedule-a-demo-link")).toHaveText(
        "Schedule a Demo"
      );
      const [newPageLink] = await Promise.all([
        page.context().waitForEvent("page"),
        page.click("#schedule-a-demo-link"), // Opens a new tab
      ]);
      await expect(newPageLink).toHaveURL(product.demo_scheduling_url!);

      // Contact Vendor
      await expect(page.locator("#contact-vendor-link")).toHaveText(
        `Contact ${vendor.name}`
      );
      await page.click("#cta-contact-vendor");
      await page
        .locator("#contact-modal-form [name=description]")
        .fill(faker.lorem.sentence());
      await page.click("#contact-modal-submit");
      await page.waitForSelector("#contact-modal-form h2:has-text('Nice!')");
      await page.click("#contact-modal-form #ok-button");

      // Write a Review
      await expect(page.locator("#write-a-review-link")).toHaveText(
        "Write a Review"
      );
      await expect(page.locator("#write-a-review-link")).toHaveAttribute(
        "href",
        `/products/${product.slug}/reviews/new`
      );
    })
  );
});
