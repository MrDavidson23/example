import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import {
  createTestCategory,
  createTestProducts,
} from "./db-helpers/general.helper";
import { map } from "lodash";
import { ProductState, Tier } from "@prisma/client";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "~/di-containers/test.di-container.server";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const { db } = TestDIContainer();

    const user = await registerNewUser(page);
    const vendor = await createVendor();
    const category = await createTestCategory();
    const products = await createTestProducts(
      {
        category_id: category.id,
        vendor_id: vendor.id,
        state: ProductState.discovery,
      },
      { count: 3 }
    );

    const stripeProduct = await db.stripeProduct.create({
      data: {
        id: `prod_${faker.string.uuid()}`,
        name: "product",
        active: true,
        tier: Tier.tier_3,
        description: "product",
      },
    });

    const stripePrice = await db.stripePrice.create({
      data: {
        id: `price_${faker.string.uuid()}`,
        product: { connect: { id: stripeProduct.id } },
        active: true,
        cadence: "monthly",
        price: 1000,
      },
    });
    return {
      user,
      vendor,
      category,
      products,
      stripePrice,
      stripeProduct,
    };
  },
  cleanup: async ({
    db,
    user,
    vendor,
    category,
    products,
    stripePrice,
    stripeProduct,
  }) => {
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.stripePrice.delete({ where: { id: stripePrice.id } });
    await db.stripeProduct.delete({ where: { id: stripeProduct.id } });
    await db.product.deleteMany({ where: { id: { in: map(products, "id") } } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.productCategory.delete({ where: { id: category.id } });
  },
});

test.describe("Marketing Category Page", () => {
  test(
    "Testing CTAs in the category page",
    withFixture(async ({ page, category, products, stripeProduct }) => {
      // Testing product details page redirects
      await page.goto(`/categories/${category.slug}`);
      await page.locator(`#view-product-button-${products[0].id}`).click();
      await expect(page).toHaveURL(`/products/${products[0].slug}`);
      await page.goBack();
      await page.locator(`#view-product-button-${products[1].id}`).click();
      await expect(page).toHaveURL(`/products/${products[1].slug}`);
      await page.goBack();
      await page.locator(`#view-product-button-${products[2].id}`).click();
      await expect(page).toHaveURL(`/products/${products[2].slug}`);
      await page.goBack();

      // Checking that Featured content filters work
      await page.locator("div").locator("#filter_by").first().check();
      await page.locator("div").locator("#filter_by").nth(1).check();
      await page.locator("div").locator("#filter_by").nth(2).check();
      await page.locator("div").locator("#filter_by").first().uncheck();
      await page.locator("div").locator("#filter_by").nth(1).uncheck();
      await page.locator("div").locator("#filter_by").nth(2).uncheck();

      // Checking that Industries served filters work
      await page.locator("div").locator("#filter_by").nth(4).check();
      await page.locator("div").locator("#filter_by").nth(5).check();
      await page.locator("div").locator("#filter_by").nth(4).uncheck();
      await page.locator("div").locator("#filter_by").nth(5).uncheck();

      // Checking that sort by select works
      await page.locator("#sort-by-select").selectOption("Most Reviews");
      await page.locator("#sort-by-select").selectOption("Highest Ratings");
      await page.locator("#sort-by-select").selectOption("Name");

      // Testing claim listing modal
      await page.locator(`#claim-listing-button-${products[1].id}`).click();
      await page.locator(`#claim-listing-button`).click();
      await expect(page).toHaveURL(`products/${products[1].slug}?claim=true`);
      await page.locator(`#select-pricing-${stripeProduct.id}`).click();
      await page.goBack();
    })
  );
});
