import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { faker } from "@faker-js/faker";
import { createProductWithSubscription } from "./db-helpers/product-subscription.spec.helper";
import {
  createTestCategories,
  createTestIndustries,
  createTestGoodForTags,
  createTestReview,
} from "./db-helpers/general.helper";
import type { VendorValueTags } from "@prisma/client";
import { VendorValueTagsLabels } from "~/utils/constants.utils";

const withFixture = withE2EFixtureFactory({
  setup: async ({ db }) => {
    const randomPrefixForTestProducts = faker.string.alphanumeric(5);

    const user = await db.user.create({
      data: {
        email: faker.internet.email({ provider: "example.com" }),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
      },
    });

    const categories = await createTestCategories({}, { count: 2 });
    const industries = await createTestIndustries({}, { count: 3 });
    const goodForTags = await createTestGoodForTags({}, { count: 3 });

    const getProductDataForCreation = () => ({
      title: `${randomPrefixForTestProducts} ${faker.commerce.productName()} ${faker.string.alphanumeric(
        5
      )}`,
      description: faker.commerce.productDescription(),
      positioning: faker.commerce.productDescription(),
      secondary_category: { connect: { id: categories[0].id } },
      tertiary_category: { connect: { id: categories[1].id } },
      demo_scheduling_url: "https://example.com",
      brand_video_urls: [
        {
          title: faker.commerce.productName(),
          url: "https://www.youtube.com/watch?v=9xwazD5SyVg",
          type: "youtube",
          embedUrl: "https://www.youtube.com/embed/9xwazD5SyVg",
        },
      ],
      demo_storylane_url: "https://www.storylane.com/demo",
      features: {
        createMany: {
          data: Array.from({ length: 2 }).map((_, i) => ({
            name: faker.commerce.productName(),
            description: faker.commerce.productDescription(),
            order: i,
          })),
        },
      },
      industries: {
        connect: faker.helpers
          .arrayElements(industries)
          .map(industry => ({ id: industry.id })),
      },
      good_for_tags: {
        connect: faker.helpers
          .arrayElements(goodForTags)
          .map(tag => ({ id: tag.id })),
      },
      packages: {
        createMany: {
          data: [
            {
              name: faker.commerce.productName(),
              description: faker.commerce.productDescription(),
              price: Number(faker.commerce.price()),
              order: 0,
            },
            {
              name: faker.commerce.productName(),
              description: faker.commerce.productDescription(),
              price: Number(faker.commerce.price()),
              order: 1,
            },
          ],
        },
      },
      promo_text: `${faker.number.int({
        min: 10,
        max: 50,
      })}% off for ${faker.number.int({ min: 2, max: 10 })} months`,
    });

    const productsWithSubscriptionAndRating = await Promise.all(
      Array.from({ length: 5 }).map(async () => {
        const product = await createProductWithSubscription(
          user.id,
          getProductDataForCreation(),
          {
            good_for_tags: true,
            industries: true,
          }
        );

        await Promise.all(
          Array.from({ length: 5 }).map(() =>
            createTestReview({
              product_id: product.product.id,
              user_id: user.id,
            })
          )
        );

        const aggregates = await db.productReview.aggregate({
          _avg: {
            compatibility_score: true,
            customer_service_score: true,
            onboarding_score: true,
            value_score: true,
          },
          _count: true,
          where: {
            product_id: product.product.id,
            approved_by_id: { not: null },
          },
        });

        const productRating =
          ((aggregates._avg.compatibility_score ?? 0) * 10 +
            (aggregates._avg.customer_service_score ?? 0) * 10 +
            (aggregates._avg.onboarding_score ?? 0) * 10 +
            (aggregates._avg.value_score ?? 0) * 10) /
          4 /
          10;

        return {
          ...product,
          product: {
            ...product.product,
            productRating: +productRating.toFixed(1),
            productReviewsCount: aggregates._count,
          },
        };
      })
    );

    const unclaimedProducts = await Promise.all(
      Array.from({ length: 5 }).map(async (_, i) =>
        db.product.create({
          data: {
            slug: faker.helpers.slugify(faker.commerce.productName()),
            primary_category: {
              connect: { id: productsWithSubscriptionAndRating[i].category.id },
            },
            vendor: {
              connect: { id: productsWithSubscriptionAndRating[i].vendor.id },
            },
            state: "discovery",
            approved_at: new Date(),
            page_title: faker.commerce.productName(),
            meta_description: faker.commerce.productDescription(),
            ...getProductDataForCreation(),
          },
          include: {
            good_for_tags: true,
            industries: true,
          },
        })
      )
    );

    const vendorWithValueTags = await db.vendor.update({
      where: { id: productsWithSubscriptionAndRating[0].vendor.id },
      data: {
        description: faker.company.catchPhrase(),
        value_tags: {
          set: faker.helpers.arrayElements(Object.keys(VendorValueTagsLabels), {
            min: 1,
            max: 2,
          }) as VendorValueTags[],
        },
      },
    });

    return {
      user,
      categories,
      industries,
      goodForTags,
      productsWithSubscriptionAndRating,
      unclaimedProducts,
      vendorWithValueTags,
      randomPrefixForTestProducts,
    };
  },
  cleanup: async ({
    db,
    user,
    categories,
    industries,
    goodForTags,
    productsWithSubscriptionAndRating,
    unclaimedProducts,
  }) => {
    await db.userRole.deleteMany({
      where: { user_id: { in: [user.id] } },
    });
    await db.productSubscription.deleteMany({
      where: {
        id: {
          in: productsWithSubscriptionAndRating.map(
            p => p.productSubscription.id
          ),
        },
      },
    });
    await db.stripePrice.deleteMany({
      where: {
        id: {
          in: productsWithSubscriptionAndRating.map(p => p.stripePrice.id),
        },
      },
    });
    await db.stripeProduct.deleteMany({
      where: {
        id: {
          in: productsWithSubscriptionAndRating.map(p => p.stripeProduct.id),
        },
      },
    });
    await db.productReview.deleteMany({
      where: {
        product_id: {
          in: [
            ...productsWithSubscriptionAndRating.map(p => p.product.id),
            ...unclaimedProducts.map(p => p.id),
          ],
        },
      },
    });
    await db.product.deleteMany({
      where: {
        id: {
          in: [
            ...productsWithSubscriptionAndRating.map(p => p.product.id),
            ...unclaimedProducts.map(p => p.id),
          ],
        },
      },
    });
    await db.vendor.deleteMany({
      where: {
        id: { in: productsWithSubscriptionAndRating.map(p => p.vendor.id) },
      },
    });
    await db.productCategory.deleteMany({
      where: {
        id: {
          in: [
            ...categories.map(category => category.id),
            ...productsWithSubscriptionAndRating.map(p => p.category.id),
          ],
        },
      },
    });
    await db.industry.deleteMany({
      where: { id: { in: industries.map(industry => industry.id) } },
    });
    await db.goodForTag.deleteMany({
      where: { id: { in: goodForTags.map(tag => tag.id) } },
    });
    await db.userCredential.deleteMany({
      where: { user_id: { in: [user.id] } },
    });
    await db.user.deleteMany({
      where: { id: { in: [user.id] } },
    });
  },
});

test.describe.parallel("Discovery > Search", () => {
  test(
    "Search by product name, check product details (with subscription and rating)",
    withFixture(async ({ page, productsWithSubscriptionAndRating }) => {
      const product = productsWithSubscriptionAndRating[1].product;
      const vendor = productsWithSubscriptionAndRating[1].vendor;

      await page.goto("/");
      await page.click("#search-bar");
      await page.fill("#search-bar", product.title);
      await page.click("#search-button");

      // Check product details
      page.waitForSelector(`#product-card-${product.id}`);
      const productCard = page.locator(`#product-card-${product.id}`);
      expect(productCard).not.toBeNull();

      if (!productCard) {
        throw new Error("Product card not found");
      }

      // Check product name
      await expect(productCard.locator(`#product-name`)).toHaveText(
        product.title
      );

      // Check vendor name
      await expect(productCard.locator(`#product-vendor-name-link`)).toHaveText(
        vendor.name
      );

      // Check product rating
      await expect(productCard.locator(`#product-rating`)).toContainText(
        `${product.productRating.toFixed(1)}(${product.productReviewsCount})`
      );

      // Check product description
      await expect(productCard.locator(`#product-description`)).toHaveText(
        product.description
      );

      // Check good for tags
      for (const tag of product.good_for_tags) {
        await expect(
          productCard.locator(`#product-good-for-tag-${tag.id}`).first()
        ).toHaveText(tag.name);
      }

      // Check promo banner
      await expect(productCard.locator(`#product-promo-banner`)).toHaveText(
        product.promo_text!
      );

      // Check link to product details
      await productCard.click();

      await page.waitForURL(`/products/${product.slug}`);
    })
  );

  test(
    "Search by product name, check product details (unclaimed product)",
    withFixture(
      async ({
        page,
        unclaimedProducts,
        productsWithSubscriptionAndRating,
      }) => {
        const product = unclaimedProducts[2];
        const vendor = productsWithSubscriptionAndRating[2].vendor;

        await page.goto("/");
        await page.click("#search-bar");
        await page.fill("#search-bar", product.title);
        await page.click("#search-button");

        // Check product details
        page.waitForSelector(`#product-card-${product.id}`);
        const productCard = page.locator(`#product-card-${product.id}`);
        expect(productCard).not.toBeNull();

        if (!productCard) {
          throw new Error("Product card not found");
        }

        // Check product name
        await expect(productCard.locator(`#product-name`)).toHaveText(
          product.title
        );

        // Check vendor name
        await expect(
          productCard.locator(`#product-vendor-name-link`)
        ).toHaveText(vendor.name);

        // Check product rating
        await expect(productCard.locator(`#product-rating`)).toHaveText(
          `0.0(0)`
        );

        // Check product description
        await expect(productCard.locator(`#product-description`)).toHaveText(
          product.description
        );

        // Check good for tags (should be hidden)
        for (const tag of product.good_for_tags) {
          expect(
            productCard.locator(`#product-good-for-tag-${tag.id}`).first()
          ).toBeHidden();
        }

        // Check promo banner (should be hidden)
        await expect(productCard.locator(`#product-promo-banner`)).toBeHidden();

        // Check link to product details
        await productCard.click();

        await page.waitForURL(`/products/${product.slug}`);
      }
    )
  );

  test(
    "Search by vendor name, check vendor details, check product cards",
    withFixture(
      async ({
        page,
        productsWithSubscriptionAndRating,
        vendorWithValueTags,
        unclaimedProducts,
      }) => {
        const vendor = vendorWithValueTags;
        const vendorRating =
          productsWithSubscriptionAndRating[0].product.productRating;
        const vendorReviewsCount =
          productsWithSubscriptionAndRating[0].product.productReviewsCount;

        await page.goto("/");
        await page.click("#search-bar");
        await page.fill("#search-bar", vendor.name);
        await page.click("#search-button");

        // Check vendor details
        page.waitForSelector(`#vendor-card-${vendor.id}`);
        const vendorCard = page.locator(`#vendor-card-${vendor.id}`);
        expect(vendorCard).not.toBeNull();

        if (!vendorCard) {
          throw new Error("Vendor card not found");
        }

        // Check vendor name
        await expect(vendorCard.locator(`#vendor-name`)).toHaveText(
          vendor.name
        );

        // Check vendor description
        await expect(
          vendorCard.locator(`#vendor-description`).first()
        ).toHaveText(vendor.description!);

        // Check vendor rating
        await expect(vendorCard.locator(`#vendor-rating`)).toContainText(
          `${vendorRating.toFixed(1)}(${vendorReviewsCount})`
        );

        // Check vendor value tags
        for (const tag of vendor.value_tags) {
          await expect(
            vendorCard.locator(`#vendor-value-tag-${tag}`).first()
          ).toHaveText(VendorValueTagsLabels[tag]);
        }

        // Check vendor products
        await expect(
          page.locator(
            `#product-card-${productsWithSubscriptionAndRating[0].product.id}`
          )
        ).toBeVisible();
        await expect(
          page.locator(`#product-card-${unclaimedProducts[0].id}`)
        ).toBeVisible();

        // Check link to vendor details
        await vendorCard.locator(`#view-vendor-button`).click();

        await page.waitForURL(`/vendors/${vendor.slug}`);

        await page.goBack();

        // Check link to view all products
        await page.click("#view-vendor-products-button");

        await page.waitForURL(`/vendors/${vendor.slug}/products`);
      }
    )
  );

  test(
    "Search with no results",
    withFixture(async ({ page }) => {
      await page.goto("/");
      await page.click("#search-bar");
      await page.fill("#search-bar", faker.lorem.sentence());
      await page.click("#search-button");

      await page.waitForSelector("#no-results-message");
      await expect(page.locator("#no-results-message")).toHaveText(
        "No Products Found. Try changing your filters."
      );
    })
  );

  test(
    "Sidebar filters",
    withFixture(
      async ({
        page,
        categories,
        industries,
        productsWithSubscriptionAndRating,
        unclaimedProducts,
        randomPrefixForTestProducts,
      }) => {
        await page.goto("/");
        await page.click("#search-bar");
        await page.fill("#search-bar", randomPrefixForTestProducts);
        await page.click("#search-button");

        const allResultsCount =
          productsWithSubscriptionAndRating.length + unclaimedProducts.length;

        // Check all results count
        await expect(page.locator("#all-results-count")).toHaveText(
          `All Results (${allResultsCount})`
        );

        // Check Featured Content
        const featuredContentFilter = [
          {
            value: "promos",
            name: "Promos and discounts",
            expectedCount: productsWithSubscriptionAndRating.length,
          },
          {
            value: "demos",
            name: "Product Demos",
            expectedCount: productsWithSubscriptionAndRating.length,
          },
          {
            value: "pricing",
            name: "Published pricing",
            expectedCount: productsWithSubscriptionAndRating.length,
          },
          { value: "videos", name: "Videos", expectedCount: 0 },
        ];
        for (const filter of featuredContentFilter) {
          const featuredContentFilter = page.locator(
            `input[name='filter_by'][value='${filter.value}']`
          );
          await featuredContentFilter.click();
          // Check all results count
          if (filter.expectedCount > 0) {
            // Only products with the selected filter should be visible
            for (const product of productsWithSubscriptionAndRating) {
              await expect(
                page.locator(`#product-card-${product.product.id}`)
              ).toBeVisible();
            }

            await expect(page.locator("#all-results-count")).toHaveText(
              `All Results (${productsWithSubscriptionAndRating.length})`
            );
          } else {
            await expect(page.locator("#all-results-count")).toHaveText(
              `All Results (0)`
            );
          }
          await featuredContentFilter.click();
          await expect(page.locator("#all-results-count")).toHaveText(
            `All Results (${allResultsCount})`
          );
        }

        // Check industries
        for (const industry of industries) {
          const industryFilter = page.locator(
            `input[name='filter_by'][value='${industry.id}']`
          );
          await industryFilter.click();
          // Only products with the selected industry should be visible
          for (const product of [
            ...productsWithSubscriptionAndRating.map(p => p.product),
            ...unclaimedProducts,
          ]) {
            if (product.industries.some(i => i.id === industry.id)) {
              await expect(
                page.locator(`#product-card-${product.id}`)
              ).toBeVisible();
            } else {
              await expect(
                page.locator(`#product-card-${product.id}`)
              ).toBeHidden();
            }
          }
          await industryFilter.click();
          await expect(page.locator("#all-results-count")).toHaveText(
            `All Results (${allResultsCount})`
          );
        }

        // Check category links
        for (const category of categories) {
          await expect(page.locator(`#category-${category.id}`)).toBeVisible();
        }

        await page.click(`#category-${categories[0].id}`);

        await page.waitForURL(`/categories/${categories[0].slug}`);
      }
    )
  );
});
