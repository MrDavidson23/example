import { faker } from "@faker-js/faker";
import type { Contract } from "@prisma/client";
import {
  ContractLineItemLocationStatus,
  ContractLineItemPriceCadence,
  ContractPricingType,
  ContractStatus,
  LocationStatus,
} from "@prisma/client";
import { getDb } from "~/services/db.server";

export async function createContract(managerAccountVendorId: string) {
  const db = getDb();
  const isCorporate = !faker.number.int({ min: 0, max: 5 });
  const contract = await db.contract.create({
    data: {
      contract_owner_name: faker.person.fullName(),
      approver: faker.person.fullName(),
      expires_at: faker.date.future(),
      current_term_end_date: faker.date.future(),
      name: faker.commerce.productName(),
      renewal_reminder_lead_time_months: faker.number.int({ max: 12 }),
      status: ContractStatus.Active,
      term_length_months: faker.number.int({ max: 48 }),
      manager_account_vendor: {
        connect: { id: managerAccountVendorId },
      },
      is_corporate_only: isCorporate,
    },
    include: {
      manager_account_vendor: true,
    },
  });

  return contract;
}

export async function createContractLineItem(
  contract: Contract,
  productIds: string[],
  locationIds?: string[]
) {
  const db = getDb();
  const departments = [
    "Accounting",
    "HR",
    "IT",
    "Sales",
    "Marketing",
    "Innovation",
    "Support",
  ];

  let data = {
    name: faker.commerce.productName(),
    contract: { connect: { id: contract.id } },
    price: faker.number.int({ min: 100, max: 1000 }),
    cadence: ContractLineItemPriceCadence.Monthly,
    pricing_type: faker.helpers.enumValue(ContractPricingType),
    seats_number: faker.number.int({ min: 1, max: 100 }),
    estimated_cost: faker.number.int({ min: 100, max: 1000 }),
    contract_line_item_products: {
      createMany: {
        data: productIds.map(product_id => ({
          department: faker.helpers.arrayElement(departments),
          price: faker.number.int({ min: 100, max: 1000 }),
          product_id,
        })),
      },
    },
    contract_line_item_locations: {},
  };
  if (locationIds) {
    data = {
      ...data,
      contract_line_item_locations: {
        createMany: {
          data: locationIds.map(location_id => ({
            location_id,
            status: faker.helpers.enumValue(ContractLineItemLocationStatus),
          })),
        },
      },
    };
  }
  const contractLineItem = await db.contractLineItem.create({
    data: {
      ...data,
    },
    include: {
      contract_line_item_products: {
        select: {
          product: {
            select: {
              title: true,
            },
          },
        },
      },
      contract_line_item_locations: true,
    },
  });

  return contractLineItem;
}

export async function createTestLocation(
  data: {
    manager_account_id: string;
    status?: LocationStatus;
  },
  db = getDb()
) {
  return await db.location.create({
    data: {
      name: `${faker.location.city()} ${faker.location.secondaryAddress()}`,
      owner_name: faker.person.fullName(),
      class: "A",
      manager_account: { connect: { id: data.manager_account_id } },
      street_1: faker.location.streetAddress(),
      city: faker.location.city(),
      state: faker.location.state(),
      zip: faker.location.zipCode(),
      region: faker.location.city(),
      status: data?.status ?? faker.helpers.enumValue(LocationStatus),
    },
  });
}

export async function createTestLocations(
  data: {
    manager_account_id: string;
    status?: LocationStatus;
  },
  options?: { count?: number },
  db = getDb()
) {
  return await Promise.all(
    Array.from({ length: options?.count ?? 5 }).map(() =>
      createTestLocation(data, db)
    )
  );
}
