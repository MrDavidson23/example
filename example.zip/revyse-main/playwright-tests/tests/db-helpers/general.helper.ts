import { faker } from "@faker-js/faker";
import type { Prisma } from "@prisma/client";
import { ProductState, Role, UserRoleType, VendorState } from "@prisma/client";
import { getDb, type ProxyPrismaClient } from "~/services/db.server";
import { slugify } from "~/utils/string.utils";

export async function createTestCategory(
  data?: Partial<Prisma.ProductCategoryCreateInput>,
  db: ProxyPrismaClient = getDb()
) {
  const name = `${faker.commerce.department()} ${faker.string.alphanumeric(5)}`;
  return await db.productCategory.create({
    data: {
      name: `${faker.commerce.department()} ${faker.string.alphanumeric(5)}`,
      description: faker.commerce.productDescription(),
      slug: slugify(name),
      faq_1: "faq 1",
      faq_2: "faq 2",
      faq_3: "faq 3",
      faq_1_answer: "faq 1",
      faq_2_answer: "faq 2",
      faq_3_answer: "faq 3",
      page_title: name,
      meta_description: name,
      ...data,
    },
  });
}

export async function createTestCategories(
  data?: Partial<Prisma.ProductCategoryCreateInput>,
  options?: { count?: number },
  db: ProxyPrismaClient = getDb()
) {
  return await Promise.all(
    Array.from({ length: options?.count ?? 5 }).map(() =>
      createTestCategory(data, db)
    )
  );
}

export async function createTestProduct(
  data: {
    category_id: string;
    vendor_id?: string;
    state?: ProductState;
  },
  db: ProxyPrismaClient = getDb()
) {
  const state = data.state ?? faker.helpers.enumValue(ProductState);
  return await db.product.create({
    data: {
      title: faker.commerce.productName(),
      slug: faker.helpers.slugify(faker.commerce.productName()),
      description: faker.commerce.productDescription(),
      positioning: "",
      approved_at: new Date(),
      primary_category_id: data.category_id,
      vendor_id: data.vendor_id ?? undefined,
      page_title: faker.commerce.productName(),
      meta_description: faker.commerce.productName(),
      state,
    },
  });
}

export async function createTestProducts(
  {
    category_id,
    vendor_id,
    state,
  }: { category_id: string; vendor_id?: string; state?: ProductState },
  options?: { count?: number },
  db: ProxyPrismaClient = getDb()
) {
  return await Promise.all(
    Array.from({ length: options?.count ?? 5 }).map(() =>
      createTestProduct({ category_id, vendor_id, state }, db)
    )
  );
}

export async function createTestVendor(
  data?: {
    name?: string;
    state?: VendorState;
  },
  db: ProxyPrismaClient = getDb()
) {
  const name = data?.name ?? faker.company.name();
  const state = data?.state ?? faker.helpers.enumValue(VendorState);
  return await db.vendor.create({
    data: {
      name,
      slug: slugify(name),
      state,
      description: faker.company.catchPhrase(),
    },
  });
}

export async function createAdminUser(
  userId: string,
  db: ProxyPrismaClient = getDb()
) {
  return await db.userRole.create({
    data: {
      role: Role.GOD_MODE,
      type: UserRoleType.GLOBAL,
      user_id: userId,
    },
  });
}

export async function createTestVendors(
  data?: {
    state?: VendorState;
  },
  options?: { count?: number },
  db: ProxyPrismaClient = getDb()
) {
  return await Promise.all(
    Array.from({ length: options?.count ?? 5 }).map(() =>
      createTestVendor(data, db)
    )
  );
}

export async function createTestIndustry(
  data?: {
    name?: string;
  },
  db: ProxyPrismaClient = getDb()
) {
  const name =
    data?.name ??
    `${faker.commerce.department()} ${faker.string.alphanumeric(5)}`;
  return await db.industry.create({
    data: {
      name,
      description: faker.commerce.productDescription(),
      slug: slugify(name),
    },
  });
}

export async function createTestIndustries(
  data: {},
  options?: { count?: number },
  db: ProxyPrismaClient = getDb()
) {
  return await Promise.all(
    Array.from({ length: options?.count ?? 5 }).map(() =>
      createTestIndustry(data, db)
    )
  );
}

export async function createTestGoodForTag(
  data?: {
    name?: string;
  },
  db: ProxyPrismaClient = getDb()
) {
  const name =
    data?.name ??
    `${faker.commerce.department()} ${faker.string.alphanumeric(5)}`;
  return await db.goodForTag.create({
    data: {
      name,
      description: faker.commerce.productDescription(),
      slug: slugify(name),
    },
  });
}

export async function createTestGoodForTags(
  data: {},
  options?: { count?: number },
  db: ProxyPrismaClient = getDb()
) {
  return await Promise.all(
    Array.from({ length: options?.count ?? 5 }).map(() =>
      createTestGoodForTag(data, db)
    )
  );
}

export async function createTestReview(
  data: {
    product_id: string;
    user_id: string;
  },
  db: ProxyPrismaClient = getDb()
) {
  return await db.productReview.create({
    data: {
      approved_at: faker.date.past(),
      product: { connect: { id: data.product_id } },
      user: { connect: { id: data.user_id } },
      compatibility_score: faker.number.int({ min: 2, max: 5 }),
      customer_service_score: faker.number.int({ min: 2, max: 5 }),
      onboarding_score: faker.number.int({ min: 2, max: 5 }),
      value_score: faker.number.int({ min: 2, max: 5 }),
      compatibility_desc: faker.lorem.sentence(),
      customer_service_desc: faker.lorem.sentence(),
      decision_maker: faker.person.firstName(),
      dislike_most: faker.lorem.sentence(),
      like_most: faker.lorem.sentence(),
      onboarding_desc: faker.lorem.sentence(),
      primary_use_case: faker.lorem.sentence(),
      recommend_to: faker.lorem.sentence(),
      show_company: faker.datatype.boolean(),
      show_job_title: faker.datatype.boolean(),
      show_last_name: faker.datatype.boolean(),
      value_desc: faker.lorem.sentence(),
      approved_by: { connect: { id: data.user_id } },
    },
  });
}
