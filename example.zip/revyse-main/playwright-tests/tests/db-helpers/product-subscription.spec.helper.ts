import type { Prisma } from "@prisma/client";
import {
  ProductState,
  Role,
  UserRoleType,
  VendorState,
  SubscriptionStatus,
  Tier,
} from "@prisma/client";
import { getDb } from "~/services/db.server";
import { faker } from "@faker-js/faker";
import { slugify } from "~/utils/string.utils";

export async function createProductWithSubscription(
  userId: string,
  productData?: Partial<Prisma.ProductCreateInput>,
  productInclude?: Prisma.ProductInclude
) {
  const db = getDb();
  const categoryName =
    faker.commerce.department() + " " + faker.string.alphanumeric(5);
  const category = await db.productCategory.create({
    data: {
      name: categoryName,
      description: faker.commerce.productDescription(),
      slug: slugify(categoryName),
      faq_1: "faq 1",
      faq_2: "faq 2",
      faq_3: "faq 3",
      faq_1_answer: "faq 1",
      faq_2_answer: "faq 2",
      faq_3_answer: "faq 3",
      page_title: categoryName,
      meta_description: categoryName,
    },
  });
  const vendorName = faker.company.name();
  const vendor = await db.vendor.create({
    data: {
      slug: slugify(vendorName),
      name: vendorName,
      website: faker.internet.url(),
      state: VendorState.ApprovedForPublishing,
      hq_location: faker.location.city(),
      founded_year: faker.date.past().getFullYear().toString(),
      number_employees: faker.number.int({ min: 1, max: 1000 }).toString(),
      linkedin_profile_url: faker.internet.url(),
    },
  });

  const productName =
    faker.commerce.productName() + " " + faker.string.alphanumeric(5);
  const product = await db.product.create({
    data: {
      title: productName,
      slug: slugify(productName),
      description: faker.commerce.productDescription(),
      positioning: "",
      approved_at: new Date(),
      primary_category: { connect: { id: category.id } },
      vendor: { connect: { id: vendor.id } },
      page_title: productName,
      meta_description: productName,
      state: ProductState.discovery,
      ...productData,
    },
    include: {
      features: true,
      packages: true,
      ...productInclude,
    },
  });

  const stripeProduct = await db.stripeProduct.create({
    data: {
      id: `prod_${faker.string.uuid()}`,
      name: "product",
      active: true,
      tier: Tier.tier_3,
      description: "product",
    },
  });

  const stripePrice = await db.stripePrice.create({
    data: {
      id: `price_${faker.string.uuid()}`,
      product: { connect: { id: stripeProduct.id } },
      active: true,
      cadence: "monthly",
      price: 1000,
    },
  });

  const productSubscription = await db.productSubscription.create({
    data: {
      stripe_id: `sub_${faker.string.uuid()}`,
      status: SubscriptionStatus.active,
      product: { connect: { id: product.id } },
      stripe_price: { connect: { id: stripePrice.id } },
    },
  });

  const userRole = await db.userRole.create({
    data: {
      user_id: userId,
      resource_id: productSubscription.id,
      type: UserRoleType.PRODUCT_SUBSCRIPTION,
      role: Role.OWNER,
    },
  });
  return {
    category,
    vendor,
    product,
    stripeProduct,
    stripePrice,
    productSubscription,
    userRole,
  };
}
