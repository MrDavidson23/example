import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import {
  createContract,
  createContractLineItem,
  createTestLocations,
} from "./db-helpers/intelligence.helper";
import {
  createTestCategory,
  createTestProducts,
} from "./db-helpers/general.helper";
import { map } from "lodash";
import {
  ContractLineItemLocationStatus,
  ContractLineItemStatus,
  LocationStatus,
} from "@prisma/client";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);
    const category = await createTestCategory();
    const products = await createTestProducts({ category_id: category.id });
    const contract = await createContract(accountVendor.id);
    const locations = await createTestLocations(
      { manager_account_id: account.id, status: LocationStatus.Active },
      { count: 20 }
    );
    const contractLineItem = await createContractLineItem(
      contract,
      map(products, "id"),
      map(locations, "id")
    );

    return {
      user,
      account,
      vendor,
      accountVendor,
      contract,
      locations,
      category,
      contractLineItem,
    };
  },
  cleanup: async ({
    db,
    user,
    account,
    contract,
    vendor,
    contractLineItem,
    category,
  }) => {
    await db.contractLineItemProduct.deleteMany({
      where: { contract_line_item_id: contractLineItem.id },
    });
    await db.contractLineItemLocation.deleteMany({
      where: { contract_line_item_id: contractLineItem.id },
    });
    await db.contractLineItem.deleteMany({
      where: { contract_id: contract.id },
    });
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.contract.delete({ where: { id: contract.id } });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.location.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.product.deleteMany({ where: { vendor_id: vendor.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.productCategory.delete({ where: { id: category.id } });
  },
});

test.describe.parallel("Intelligence Contract Line Item Summary", () => {
  test(
    "Testing card sections links",
    withFixture(async ({ page, account, contract, contractLineItem }) => {
      await page.goto(
        `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/summary`
      );
      // Test Edit CTAs
      await page.locator("#edit-products-and-fees").click();
      await expect(page).toHaveURL(
        `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/`
      );
      await page.getByRole("link", { name: contractLineItem.name! }).click();
      await page.locator("#primary-edit-pricing-button").click();
      await expect(page).toHaveURL(
        `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/set-price`
      );

      // Test vendor name link redirect
      await page.getByRole("link", { name: contractLineItem.name! }).click();
      await page.locator("#vendor-link").click();
      await expect(page).toHaveURL(
        `/intelligence/${account.id}/vendors/${contract.manager_account_vendor_id}`
      );
    })
  );

  test(
    "Testing ellipsis menu actions",
    withFixture(async ({ page, account, contract, contractLineItem }) => {
      await page.goto(
        `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/summary`
      );

      // Test Assign Locations CTA
      await page.locator("#ellipsis-menu").click();
      await page.locator("#assign-locations-button").click();
      await expect(page).toHaveURL(
        `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/assign-locations`
      );
      await page.getByRole("link", { name: contractLineItem.name! }).click();

      // Test Cancel Locations CTA
      await page.locator("#ellipsis-menu").click();
      await page.locator("#cancel-locations").click();
      // Canceling contract line item locations
      await page
        .locator(
          `#editLocation-${contractLineItem.contract_line_item_locations[0].id}`
        )
        .click();
      await page
        .locator("#status")
        .selectOption(ContractLineItemLocationStatus.Canceled);
      await page.locator("#save-contract-lineItem-location").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Status updated successfully"
      );

      // Test Edit Pricing locations CTA
      await page.locator("#ellipsis-menu").click();
      await page.locator("#edit-pricing-button").click();
      await expect(page).toHaveURL(
        `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/set-price`
      );
      await page.getByRole("link", { name: contractLineItem.name! }).click();

      // Test Edit Products and Fees CTA
      await page.locator("#ellipsis-menu").click();
      await page.locator("#edit-products-and-fees-button").click();
      await expect(page).toHaveURL(
        `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/`
      );
      await page.getByRole("link", { name: contractLineItem.name! }).click();

      // Test Cancel Line item CTA
      await page.locator("#ellipsis-menu").click();
      await page.locator("#editLineItemStatus").click();
      // Canceling line item
      await page
        .locator("#status")
        .selectOption(ContractLineItemStatus.Canceled);
      await page.locator("#save-line-item-status").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Status updated successfully"
      );
      await expect(page.locator("#status-chip").first()).toContainText(
        ContractLineItemStatus.Canceled
      );

      // Test Activate Line item CTA
      await page.locator("#ellipsis-menu").click();
      await page.locator("#editLineItemStatus").click();
      await page.locator("#status").selectOption(ContractLineItemStatus.Active);
      await page.locator("#save-line-item-status").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Status updated successfully"
      );
      await expect(page.locator("#status-chip").first()).toContainText(
        ContractLineItemStatus.Active
      );

      // Test Delete Line item CTA
      await page.locator("#ellipsis-menu").click();
      await page.locator("#deleteLineItem").click();
      await page.locator("#confirm-delete-modal-confirm-button").click();
      await expect(page).toHaveURL(
        `/intelligence/${account.id}/contract/${contract.id}/line-item/`
      );
      await expect(page.locator(".Toastify").first()).toContainText(
        "Line item deleted successfully"
      );
    })
  );
});
