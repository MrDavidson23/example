import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { createAccount } from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    return { user, account, vendor };
  },
  cleanup: async ({ db, user, account, vendor }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
  },
});

const withRegularUserFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    return { user };
  },
  cleanup: async ({ db, user }) => {
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe("Intelligence Dashboard", () => {
  test(
    "Hit intelligence dashboard logged in as user with manager account",
    withFixture(async ({ page, baseURL, account }) => {
      await page.goto(`/intelligence/${account.id}`);
      const response = await page.request.get(
        `${baseURL}/intelligence/${account.id}}`
      );
      await expect(response).toBeOK();
    })
  );

  test(
    "Hit intelligence dashboard after logging out",
    withFixture(async ({ page, account }) => {
      await page.goto(`/intelligence/${account.id}`);
      await page.locator("#logout-link").click();
      await page.locator("#intelligence-link").click();
      await expect(page).toHaveURL("login?redirectTo=%2Fintelligence");
    })
  );

  test(
    "Hit intelligence dashboard logged in as user without manager account",
    withRegularUserFixture(async ({ page }) => {
      await page.locator("#intelligence-link").click();
      await expect(page).toHaveURL("vendor-intelligence");
    })
  );
});
