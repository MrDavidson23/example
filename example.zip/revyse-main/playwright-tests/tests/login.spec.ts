import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { login } from "./page-helpers/login.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    await page.goto("/logout");
    return { user };
  },
  cleanup: async ({ db, user }) => {
    await db.userCredential.delete({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe("Login Page", () => {
  test(
    "Login Form",
    withFixture(async ({ page, baseURL, user }) => {
      // Login with invalid data
      await login(page, baseURL, user.email, "incorrect-password");
      await expect(page.locator("#errors-wrong-combination")).toHaveText(
        "Username/Password combination is incorrect"
      );

      // Login with valid data
      await login(page, baseURL, user.email, "changeme");
      await page.goto("/vendor");
      const response = await page.request.get(`${baseURL}/vendor`);
      await expect(response).toBeOK();
    })
  );
});

test.describe("Login Page CTAS", () => {
  test("Login page calls to action", async ({ page, baseURL }) => {
    await page.goto(baseURL!);
    await page.getByRole("link", { name: "Log In", exact: true }).click();
    await page.locator("#or-sign-up-link").click();
    await expect(page).toHaveURL(/sign-up/);
    await page.goBack();
    await page.locator("#forgot-password-link").click();
    await expect(page).toHaveURL(/forgot-password/);
  });
});
