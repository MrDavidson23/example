import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { TestDIContainer } from "~/di-containers/test.di-container.server";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const { db } = TestDIContainer();

    const user = await registerNewUser(page);
    await page.goto("/logout");
    const token = await db.forgotPasswordToken.create({
      data: {
        user: {
          connect: {
            id: user.id,
          },
        },
      },
    });

    return { user, token };
  },
  cleanup: async ({ db, user, token }) => {
    await db.forgotPasswordToken.delete({
      where: { id: token.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe("Reset Password Token page", () => {
  test(
    "Reset user password workflow",
    withFixture(async ({ page, token }) => {
      await page.goto(`/reset-password/${token.id}`);

      // Fill reset password form with no matching passwords
      await page.locator("#password").fill("newpassword1");
      await page.locator("#password-confirmation").fill("newpassword2");
      await page.locator("#reset-password-button").click();
      await expect(page.locator("#errors-password-confirmation")).toHaveText(
        "Passwords do not match"
      );

      // Fill reset password form correctly
      await page.locator("#password").fill("newpassword");
      await page.locator("#password-confirmation").fill("newpassword");
      await page.locator("#reset-password-button").click();
      await expect(page).toHaveURL("/profile");

      // Try to use already used reset password token
      await page.goto("/logout");
      await page.goto(`/reset-password/${token.id}`);
      await expect(page).toHaveURL("/login");
    })
  );
});
