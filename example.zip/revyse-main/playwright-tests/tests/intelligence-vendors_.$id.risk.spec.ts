import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);
    return { user, account, vendor, accountVendor };
  },
  cleanup: async ({ db, user, account, vendor, accountVendor }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });

    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
  },
});

test.describe("Intelligence Vendor Risk Management", () => {
  test(
    "Update risk info",
    withFixture(async ({ page, accountVendor, account }) => {
      await page.goto(
        `/intelligence/${account.id}/vendors/${accountVendor.id}/risk`
      );
      // Submit empty form
      await page.locator("#save-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Vendor risk information updated successfully"
      );

      // Submit full form
      await page.click("#edit-vendor-risk");
      await page.locator("#vendor_risk_score").selectOption("Low");
      await page.locator("#business_criticality_rating").selectOption("High");
      await page.locator("#internal_review_status").selectOption("InProgress");
      await page
        .locator("#data_privacy_prospects_residents")
        .selectOption("Yes");
      await page
        .locator("#data_privacy_customers_employees")
        .selectOption("No");
      await page.locator("#cybersecurity").selectOption("Other");

      await page.locator("#save-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Vendor risk information updated successfully"
      );
    })
  );
});
