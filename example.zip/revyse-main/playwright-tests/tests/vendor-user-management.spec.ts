import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { createProductWithSubscription } from "./db-helpers/product-subscription.spec.helper";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { faker } from "@faker-js/faker";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const productSubscription = await createProductWithSubscription(user.id);
    return {
      user,
      ...productSubscription,
    };
  },
  cleanup: async ({
    db,
    user,
    category,
    vendor,
    product,
    stripeProduct,
    stripePrice,
    productSubscription,
    userRole,
  }) => {
    await db.userRole.delete({ where: { id: userRole.id } });
    await db.productSubscription.delete({
      where: { id: productSubscription.id },
    });
    await db.stripePrice.delete({ where: { id: stripePrice.id } });
    await db.stripeProduct.delete({ where: { id: stripeProduct.id } });
    await db.product.delete({ where: { id: product.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.productCategory.delete({ where: { id: category.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

const email = faker.internet
  .email({
    provider: "test.com",
  })
  .toLowerCase();

test.describe.parallel("Vendor User Management", () => {
  test(
    "New user invitation workflow",
    withFixture(async ({ db, page, productSubscription }) => {
      // Send user invitation
      await page.goto("/vendor");
      await page.locator(`#sub_${productSubscription.id}`).click();
      await page.locator("#invite-user").click();
      await page.locator("[id='email']").fill(email);
      await page.locator("[id='role']").selectOption("Editor");
      await page.locator("#send-invitation").click();
      await expect(page).toHaveURL(
        `/vendor/product/${productSubscription.id}/users/`
      );
      await expect(page.locator(".Toastify").first()).toContainText(
        "User invitation sent"
      );
      const userInvite = await db.userInvitation.findFirst({
        where: {
          email: email,
        },
      });

      // Resend user invitation
      await page.locator(`#resend_${userInvite?.id}`).click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "User invitation has been resent"
      );
      // Cancel user invitation
      await page.locator(`#cancel_${userInvite?.id}`).click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "User invitation has been cancelled"
      );
    })
  );

  test(
    "Send empty user invitation form",
    withFixture(async ({ page, productSubscription }) => {
      await page.goto("/vendor");
      await page.locator(`#sub_${productSubscription.id}`).click();
      await page.locator("#invite-user").click();
      await page.locator("#send-invitation").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        DEFAULT_FORM_ERROR_MESSAGE
      );
    })
  );

  test(
    "Send user invitation to existing user email",
    withFixture(async ({ page, productSubscription, user }) => {
      await page.goto("/vendor");
      await page.locator(`#sub_${productSubscription.id}`).click();
      await page.locator("#invite-user").click();
      await page.locator("[id='email']").fill(user.email);
      await page.locator("[id='role']").selectOption("Editor");
      await page.locator("#send-invitation").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        DEFAULT_FORM_ERROR_MESSAGE
      );
    })
  );

  test(
    "Edit current user role",
    withFixture(async ({ page, productSubscription, user }) => {
      await page.goto("/vendor");
      await page.locator(`#sub_${productSubscription.id}`).click();
      await page.locator("#user-list").click();
      await page.getByRole("cell", { name: user.email }).click();
      await page.locator("[id='role']").selectOption("Editor");
      await page.locator("#send-invitation").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        DEFAULT_FORM_ERROR_MESSAGE
      );
    })
  );
});
