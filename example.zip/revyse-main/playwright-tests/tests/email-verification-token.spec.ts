import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page, db }) => {
    const user = await registerNewUser(page);

    const emailVerification = await db.emailVerificationToken.findFirst({
      where: {
        user_id: user.id,
      },
    });
    return {
      user,
      emailVerification,
    };
  },
  cleanup: async ({ db, user }) => {
    await db.emailVerificationToken.deleteMany({
      where: { email: user.email },
    });
    await db.userCredential.deleteMany({
      where: { user_id: user.id },
    });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe("Email Verification token page", () => {
  test(
    "Navigate thru email verification page",
    withFixture(async ({ page, emailVerification }) => {
      await page.goto(`/email-verification/${emailVerification?.id}`);
      const response = await page.request.get(
        `/email-verification/${emailVerification?.id}`
      );
      await expect(response).toBeOK();
      await page.locator("#browse-categories-button").click();
      await expect(page).toHaveURL("/categories");
    })
  );
});
