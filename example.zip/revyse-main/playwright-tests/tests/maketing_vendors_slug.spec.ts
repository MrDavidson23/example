import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { createProductWithSubscription } from "./db-helpers/product-subscription.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const productSubscription = await createProductWithSubscription(user.id);

    return { user, ...productSubscription };
  },
  cleanup: async ({
    db,
    user,
    category,
    vendor,
    product,
    stripeProduct,
    stripePrice,
    productSubscription,
    userRole,
  }) => {
    await db.userRole.delete({ where: { id: userRole.id } });
    await db.productSubscription.delete({
      where: { id: productSubscription.id },
    });
    await db.stripePrice.delete({ where: { id: stripePrice.id } });
    await db.stripeProduct.delete({ where: { id: stripeProduct.id } });
    await db.product.delete({ where: { id: product.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.productCategory.delete({ where: { id: category.id } });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe("Marketing Vendors Slug", () => {
  test(
    "View all products CTAs",
    withFixture(async ({ page, vendor }) => {
      await page.goto(`/vendors/${vendor.slug}`);
      const response = await page.request.get(`/vendors/${vendor.slug}`);
      await expect(response).toBeOK();

      await page.locator("#view-all-products-link").click();
      await expect(page).toHaveURL(`/vendors/${vendor.slug}/products`);
      await page.goBack();

      await page.locator("#view-all-products-primary").click();
      await expect(page).toHaveURL(`/vendors/${vendor.slug}/products`);
      await page.goBack();

      await page.locator("#view-all-products-secondary").click();
      await expect(page).toHaveURL(`/vendors/${vendor.slug}/products`);
      await page.goBack();

      await page.locator("#view-all-products-pagination").click();
      await expect(page).toHaveURL(`/vendors/${vendor.slug}/products`);
      await page.goBack();
    })
  );

  test(
    "Product cards View Details CTA",
    withFixture(async ({ page, vendor, product }) => {
      await page.goto(`/vendors/${vendor.slug}`);
      const response = await page.request.get(`/vendors/${vendor.slug}`);
      await expect(response).toBeOK();

      await page.locator("#view-product-button").click();
      await expect(page).toHaveURL(`/products/${product.slug}`);
      await page.goBack();
    })
  );

  test(
    "Vendor All Products page",
    withFixture(async ({ page, vendor, product }) => {
      await page.goto(`/vendors/${vendor.slug}/products`);
      const response = await page.request.get(
        `/vendors/${vendor.slug}/products`
      );
      await expect(response).toBeOK();

      await page.locator("#search-bar").fill(product.title);
      await page.locator("#search-bar").press("Enter");

      await page.locator("#view-product-button").click();
      await expect(page).toHaveURL(`/products/${product.slug}`);
      await page.goBack();
    })
  );
});
