import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { TestDIContainer } from "~/di-containers/test.di-container.server";
import { faker } from "@faker-js/faker";
import { slugify } from "~/utils/string.utils";

const withFixture = withE2EFixtureFactory({
  setup: async () => {
    const { circleService, db } = TestDIContainer();

    const testPostsNames = Array.from({ length: 10 }, () =>
      faker.lorem.sentence(5)
    );

    await db.post.createMany({
      data: testPostsNames.map((name, i) => ({
        id: i + 1,
        status: "published",
        name,
        body: faker.lorem.paragraphs(5),
        slug: slugify(name),
        space_name: "revyse",
        space_slug: "revyse",
        space_id: 123,
        user_id: faker.number.int({ min: 1, max: 100 }),
        user_email: faker.internet.email(),
        user_name: faker.internet.userName(),
        comments_count: faker.number.int({ min: 1, max: 100 }),
        community_id: faker.number.int({ min: 1, max: 100 }),
        hide_meta_info: false,
        url: faker.internet.url(),
        published_at: faker.date.recent(),
        user_avatar_url: faker.image.avatar(),
        created_at: faker.date.recent(),
        updated_at: faker.date.recent(),
        is_comments_enabled: faker.datatype.boolean(),
        is_comments_closed: faker.datatype.boolean(),
        is_liking_enabled: faker.datatype.boolean(),
        likes_count: faker.number.int({ min: 1, max: 100 }),
        user_comments_count: faker.number.int({ min: 1, max: 100 }),
        user_likes_count: faker.number.int({ min: 1, max: 100 }),
        user_posts_count: faker.number.int({ min: 1, max: 100 }),
        user_topics_count: faker.number.int({ min: 1, max: 100 }),
      })),
    });

    const posts = await circleService.getPosts();
    return { posts, testPostsNames };
  },
  cleanup: async ({ testPostsNames }) => {
    const { db } = TestDIContainer();
    await db.post.deleteMany({ where: { name: { in: testPostsNames } } });
  },
});

test.describe("Revyse Resources (articles)", () => {
  test(
    "Navigation to articles, rendering and search",
    withFixture(async ({ page, baseURL, posts, testPostsNames }) => {
      await page.goto(`${baseURL}/articles`);

      await page.click(`#latest-article-card`);
      await expect(page.locator(`#article-name`)).toHaveText(posts[0].name);
      await page.goBack();

      await page.click(`#article-card`);
      await expect(page.locator(`#article-name`)).toHaveText(posts[1].name);
      await page.goBack();

      const randomPostName = faker.helpers.arrayElement(testPostsNames);
      await page.fill(`#keyword-search`, randomPostName);
      await page.click(`#search-button`);
      await page.click(`#latest-article-card`);
      await expect(page.locator(`#article-name`)).toHaveText(randomPostName);
      await page.goBack();

      await page.fill(`#keyword-search`, faker.lorem.sentence(10));
      await page.click(`#search-button`);
      await expect(page.locator(`#no-articles-fallback`)).toHaveText(
        "No articles found"
      );
    })
  );
});
