import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { createContract } from "./db-helpers/intelligence.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);
    const contracts = await Promise.all(
      Array.from({ length: 20 }).map(() => createContract(accountVendor.id))
    );
    await page.goto(`/intelligence/${account.id}`);
    return { user, account, vendor, accountVendor, contracts };
  },
  cleanup: async ({ db, user, account, vendor, accountVendor }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.contract.deleteMany({
      where: { manager_account_vendor_id: accountVendor.id },
    });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
  },
});

test.describe.parallel("Navigate through the dashboard", () => {
  test(
    "Resident Lifecycle Phases",
    withFixture(async ({ page, baseURL, account }) => {
      const phases = [
        "Touring",
        "Application",
        "Leasing",
        "MoveIn",
        "Residency",
        "Retention",
        "MoveOut",
        "Shopping",
      ];
      await page.locator("#resident-lifecycle-view-all-detail").click();
      await expect(page).toHaveURL(
        `${baseURL}/intelligence/${account.id}/spend-by-resident-phase`
      );
      for (const phase of phases) {
        await page
          .getByRole("link", {
            name:
              phase === "MoveIn"
                ? "Move In"
                : phase === "MoveOut"
                ? "Move Out"
                : phase,
          })
          .first()
          .click();
        await expect(page).toHaveURL(
          `${baseURL}/intelligence/${account.id}/spend-by-resident-phase?phase=${phase}`
        );
        const response = await page.request.get(
          `${baseURL}/intelligence/${account.id}/spend-by-resident-phase?phase=${phase}`
        );
        await expect(response).toBeOK();
      }
    })
  );

  test(
    "Spend by department link",
    withFixture(async ({ page, baseURL, account }) => {
      await page.goto(`/intelligence/${account.id}`);
      await page.locator("#spend-by-department-view-all-details").click();
      await expect(page).toHaveURL(/spend-by-department/);

      const response = await page.request.get(
        `${baseURL}/intelligence/${account.id}/spend-by-department`
      );
      await expect(response).toBeOK();
      await page
        .getByLabel("Breadcrumb")
        .getByRole("link", { name: "Reports" })
        .click();
    })
  );

  test(
    "All contracts link",
    withFixture(async ({ page, baseURL, account }) => {
      await page.locator("#contracts-view-all-link").click();

      await expect(page).toHaveURL(
        `${baseURL}/intelligence/${account.id}/contracts`
      );
    })
  );
});
