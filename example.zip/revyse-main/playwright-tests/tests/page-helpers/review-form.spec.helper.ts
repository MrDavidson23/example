import { faker } from "@faker-js/faker";
import type { Page } from "@playwright/test";

export async function fillReviewForm(page: Page) {
  await page.locator("#title").click();
  await page.locator("#title").fill(faker.commerce.productDescription());

  await page.locator("#primary_use_case").click();
  await page
    .locator("#primary_use_case")
    .fill(faker.commerce.productDescription());

  await page.locator("#like_most").click();
  await page.locator("#like_most").fill(faker.commerce.productDescription());

  await page.locator("#dislike_most").click();
  await page.locator("#dislike_most").fill(faker.commerce.productDescription());

  await page.locator("#recommend_to").click();
  await page.locator("#recommend_to").fill(faker.commerce.productDescription());

  await page
    .locator("#customer_service_score")
    .selectOption("5 - Totally awesome");
  await page.locator("#customer_service_desc").click();
  await page
    .locator("#customer_service_desc")
    .fill(faker.commerce.productDescription());

  await page.locator("#value_score").selectOption("5 - Totally awesome");
  await page.locator("#value_desc").click();
  await page.locator("#value_desc").fill(faker.commerce.productDescription());

  await page.locator("#onboarding_score").selectOption("5 - Totally awesome");
  await page.locator("#onboarding_desc").click();
  await page
    .locator("#onboarding_desc")
    .fill(faker.commerce.productDescription());

  await page
    .locator("#compatibility_score")
    .selectOption("5 - Totally awesome");
  await page.locator("#compatibility_desc").click();
  await page
    .locator("#compatibility_desc")
    .fill(faker.commerce.productDescription());

  await page
    .locator("#decision_maker")
    .selectOption("My client selected the vendor.");
  await page.locator("#who_uses").nth(1).check();

  await page.locator("#show_last_name").selectOption("Last Name");
  await page.locator("#show_job_title").selectOption("Show");
  await page.locator("#show_company").selectOption("Show");
}
