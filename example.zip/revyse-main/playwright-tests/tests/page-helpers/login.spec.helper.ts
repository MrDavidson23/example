import type { Page } from "@playwright/test";

export async function login(
  page: Page,
  baseURL: string | undefined,
  email: string,
  password?: string
) {
  return loginWithUser(page, baseURL, email, password);
}

export async function loginWithUser(
  page: Page,
  baseURL: string | undefined,
  email: string,
  password: string = "changeme"
) {
  await page.goto(baseURL!);
  await page.getByRole("link", { name: "Log In", exact: true }).click();
  await page.locator("[id='email-address']").click();
  await page.locator("[id='email-address']").fill(email);

  await page.locator("[id='password']").click();
  await page.locator("[id='password']").fill(password);
  await page.getByRole("button", { name: "Sign in" }).click();
}
