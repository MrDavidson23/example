import { faker } from "@faker-js/faker";
import type { Page } from "@playwright/test";
import type { Location, ManagerAccount, PrismaClient } from "@prisma/client";

export async function addLocation(
  page: Page,
  db: PrismaClient,
  account: ManagerAccount
): Promise<Location> {
  await page.goto("/intelligence");
  await page.locator("[id='locations-link']").click();
  await page.locator("[id='add-location-button']").click();
  const locationName = faker.location.streetAddress();
  await fillLocationForm(page, locationName);
  const location = await db.location.findFirstOrThrow({
    where: { name: locationName, manager_account_id: account.id },
  });

  return location;
}

export async function fillLocationForm(page: Page, locationName: string) {
  await page.locator("[id='name']").click();
  await page.locator("[id='name']").fill(locationName);

  await page.locator("[id='pms_id']").click();
  await page.locator("[id='pms_id']").fill("12345");

  await page.locator("[id='street_1']").click();
  await page.locator("[id='street_1']").fill("Street Test");

  await page.locator("[id='street_2']").click();
  await page.locator("[id='street_2']").fill("Street Test 2");

  await page.locator("[id='city']").click();
  await page.locator("[id='city']").fill("New York");

  await page.locator("[id='state']").selectOption("NY");

  await page.locator("[id='zip']").click();
  await page.locator("[id='zip']").fill("41001");

  await page.locator("[id='region']").click();
  await page.locator("[id='region']").fill("New York");

  await page.locator("[id='unit_count']").click();
  await page.locator("[id='unit_count']").fill("234");

  await page.locator("[id='class']").selectOption("A");

  await page.locator("[id='property_type']").selectOption("Other");

  await page.locator("[id='owner_name']").click();
  await page.locator("[id='owner_name']").fill("Owner");

  await page.locator("#save-button").click();
  await page.waitForLoadState("networkidle");
}
