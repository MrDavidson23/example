import { faker } from "@faker-js/faker";
import type { Page } from "@playwright/test";
import { getDb } from "~/services/db.server";

export async function registerNewUser(page: Page) {
  const email = faker.internet
    .email({
      provider: "test.com",
    })
    .toLowerCase();

  await page.goto("/sign-up");
  // Navigate to the Sign Up page
  // await page.getByRole("link", { name: "Sign Up", exact: true }).click();

  // Fill in the registration form
  await fillRegistrationForm(page, email);

  // Submit the registration form
  await page.getByRole("button", { name: "Sign Up" }).click();
  await page.waitForURL("/sign-up-success");
  const db = getDb();

  return await db.user.findFirstOrThrow({ where: { email } });
}

export async function createNewManagerAccount(page: Page, email: string) {
  // Navigate to the Sign Up page
  await page.getByRole("link", { name: "Sign Up", exact: true }).click();

  // Fill in the registration form
  await fillRegistrationForm(page, email);

  // Submit the registration form
  await page.getByRole("button", { name: "Sign Up" }).click();
}

// Helper function to fill in the registration form
export async function fillRegistrationForm(page: Page, email: string) {
  await page.locator("[id='first_name']").click();
  await page.locator("[id='first_name']").fill(faker.person.firstName());

  await page.locator("[id='last_name']").click();
  await page.locator("[id='last_name']").fill(faker.person.lastName());

  await page.locator("[id='title']").click();
  await page.locator("[id='title']").fill(faker.person.jobTitle());

  await page.locator("[id='company_name']").click();
  await page.locator("[id='company_name']").fill(faker.company.name());

  await page.locator("[id='email']").click();
  await page.locator("[id='email']").fill(email);

  await page.locator("[id='phone']").click();
  await page.locator("[id='phone']").fill("84437007");

  await page.locator("[id='password']").click();
  await page.locator("[id='password']").fill("changeme");

  await page.locator("[id='password-confirmation']").click();
  await page.locator("[id='password-confirmation']").fill("changeme");

  const recaptchaToken = process.env.RECAPTCHA_E2E_TOKEN ?? "";
  await page.evaluate(
    `document.getElementById("g-recaptcha-response").setAttribute("value", "${recaptchaToken}")`
  );
}
