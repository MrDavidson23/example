import type { Page } from "@playwright/test";
import type { Vendor } from "@prisma/client";

export async function fillContractForm(
  page: Page,
  contractName: string,
  vendor: Vendor
) {
  await page.locator('input[name="selectedVendor"]').click();
  await page
    .locator('input[name="selectedVendor"]')
    // Dunno why but when you enter the whole vendor name it doesn't find it
    .fill(vendor.name.substring(0, vendor.name.length - 2));
  await page.locator(`#selectedVendor-option-${vendor.id}`).click();
  await page.locator("[id='name']").fill(contractName);
  await page.locator("[id='status']").selectOption("Active");
  await page.locator("#is_msa").nth(1).check();
  await page.locator("#will_auto_renew").nth(1).check();
  await page.locator("[id='term_length_months']").fill("24");
  await page.locator("[id='auto_renew_term_length']").fill("12");
  await page.locator("[id='effective_date']").fill("2024-05-18");
  await page.locator("[id='expires_at']").fill("2024-05-18");
  await page.locator("[id='current_term_end_date']").fill("2024-05-18");
  await page.locator("[id='termination_notice_period']").fill("24");
  await page.locator("[id='email-list']").fill("info@contract.com");
  await page.locator("#save-button").click();
}

export async function createLocation(page: Page, locationName: string) {
  await page.locator("[id='locations-link']").click();
  await page.locator("[id='add-location-button']").click();

  await page.locator("[id='name']").click();
  await page.locator("[id='name']").fill(locationName);

  await page.locator("[id='pms_id']").click();
  await page.locator("[id='pms_id']").fill("12345");

  await page.locator("[id='street_1']").click();
  await page.locator("[id='street_1']").fill("Street Test");

  await page.locator("[id='street_2']").click();
  await page.locator("[id='street_2']").fill("Street Test 2");

  await page.locator("[id='city']").click();
  await page.locator("[id='city']").fill("New York");

  await page.locator("[id='state']").selectOption("NY");

  await page.locator("[id='zip']").click();
  await page.locator("[id='zip']").fill("41001");

  await page.locator("[id='searchRegion']").click();
  await page.locator("[id='searchRegion']").fill("New York");

  await page.locator("[id='unit_count']").click();
  await page.locator("[id='unit_count']").fill("234");

  await page.locator("[id='class']").selectOption("A");

  await page.locator("[id='property_type']").selectOption("Other");

  await page.locator("[id='owner_name']").click();
  await page.locator("[id='owner_name']").fill("Owner");

  await page.locator("#save-button").click();
  await page.getByRole("button", { name: "Close", exact: true }).click();
}
