import type {
  Page,
  PlaywrightTestArgs,
  PlaywrightTestOptions,
  TestInfo,
} from "@playwright/test";

import { getDb } from "../../app/services/db.server";
import type { PrismaClient } from "@prisma/client";

/**
 * Higher Order Helper Functions to make testing simpler
 */
type E2EDefaultArgs = {
  db: PrismaClient;
  page: Page;
  baseURL: string | undefined;
};

type E2ESetupFunction<TFixtures> = (
  args: E2EDefaultArgs
) => TFixtures | Promise<TFixtures>;

type E2ETestFunction<TFixtures> = (args: TFixtures & E2EDefaultArgs) => any;
type E2ECleanupFunction<TFixtures> = (
  args: TFixtures & E2EDefaultArgs
) => Promise<any>;

type WithFixtureFunction<TFixtures> = (
  test: E2ETestFunction<TFixtures & E2EDefaultArgs>
) => (
  args: PlaywrightTestArgs & PlaywrightTestOptions,
  testInfo: TestInfo
) => any;

/**
 * Will provide fixtures and a database transaction to your test
 * function and will rollback the transaction when the test completes
 * @param setup
 * @returns
 */
export function withE2EFixtureFactory<TFixtures>({
  setup,
  cleanup,
}: {
  setup: E2ESetupFunction<TFixtures>;
  cleanup?: E2ECleanupFunction<TFixtures>;
}): WithFixtureFunction<TFixtures> {
  return (test: E2ETestFunction<TFixtures>) => {
    return async (
      { page, baseURL }: PlaywrightTestArgs & PlaywrightTestOptions,
      testInfo: TestInfo
    ) => {
      const db = getDb();
      const fixtures = await setup({ db, page, baseURL });
      try {
        await test({ ...fixtures, page, baseURL, db });
      } catch (e) {
        throw e;
      } finally {
        if (cleanup) {
          await cleanup({ ...fixtures, page, baseURL, db });
        }
      }
    };
  };
}
