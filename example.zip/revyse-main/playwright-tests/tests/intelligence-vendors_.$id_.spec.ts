import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);
    return { user, account, vendor, accountVendor };
  },
  cleanup: async ({ db, user, account, vendor }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
  },
});

test.describe("Intelligence Vendor Details Screen", () => {
  test(
    "Correct vendor name is displayed on the vendor details screen",
    withFixture(async ({ page, accountVendor, vendor, account }) => {
      await page.goto(
        `/intelligence/${account.id}/vendors/${accountVendor.id}`
      );

      // Check vendor name
      await expect(page.locator("#vendor-name").first()).toContainText(
        vendor.name
      );
    })
  );

  test(
    "Link to view contracts",
    withFixture(async ({ page, accountVendor, account }) => {
      const vendorURL = `/intelligence/${account.id}/vendors/${accountVendor.id}`;
      // Link to edit primary info
      await page.goto(vendorURL);
      await page.click("#edit-vendor-info");
      await expect(page).toHaveURL(`${vendorURL}/info`);

      // Link to view all contracts
      await page.goto(vendorURL);
      await page.click("#view-all-contracts");
      await expect(page).toHaveURL(`${vendorURL}/contracts`);

      // Link to add new contract
      await page.goto(vendorURL);
      await page.click("#add-contract");
      await expect(page).toHaveURL(
        `/intelligence/${account.id}/contract/new?vendor_id=${accountVendor.vendor_id}`
      );

      // Link to edit contacts
      await page.goto(vendorURL);
      await page.click("#edit-vendor-contacts");
      await expect(page).toHaveURL(`${vendorURL}/contacts`);

      // Link to edit risk
      await page.goto(vendorURL);
      await page.click("#edit-vendor-risk");
      await expect(page).toHaveURL(`${vendorURL}/risk`);

      // Link to Log Incident
      await page.goto(vendorURL);
      await page.click("#log-incident");
      await expect(page).toHaveURL(`${vendorURL}/incident/new`);
    })
  );
});
