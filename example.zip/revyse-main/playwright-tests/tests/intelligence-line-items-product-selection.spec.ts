import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import {
  createContract,
  createTestLocations,
} from "./db-helpers/intelligence.helper";
import {
  createTestCategory,
  createTestProducts,
} from "./db-helpers/general.helper";
import { LocationStatus } from "@prisma/client";
import { map } from "lodash";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);
    const category = await createTestCategory();
    const products = await createTestProducts({
      category_id: category.id,
      vendor_id: vendor.id,
    });
    const contract = await createContract(accountVendor.id);
    const locations = await createTestLocations(
      { manager_account_id: account.id, status: LocationStatus.Active },
      { count: 20 }
    );
    return {
      user,
      account,
      vendor,
      accountVendor,
      contract,
      locations,
      category,
      products,
    };
  },
  cleanup: async ({
    db,
    user,
    account,
    contract,
    vendor,
    category,
    products,
  }) => {
    await db.contractLineItemProduct.deleteMany({
      where: { contract_line_item: { contract_id: contract.id } },
    });
    await db.contractLineItemLocation.deleteMany({
      where: { contract_line_item: { contract_id: contract.id } },
    });
    await db.contractLineItem.deleteMany({
      where: { contract_id: contract.id },
    });
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.contract.delete({ where: { id: contract.id } });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.location.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.product.deleteMany({ where: { id: { in: map(products, "id") } } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.productCategory.delete({ where: { id: category.id } });
  },
});

test.describe.parallel("Intelligence Line Item Select products & fees", () => {
  test(
    "Selecting and deselecting products for contract line items",
    withFixture(async ({ page, account, contract, products }) => {
      await page.goto("/intelligence");
      await page.locator("#contracts-link").click();

      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(contract.name);
      await page.locator("#search-bar").press("Enter");

      await page.locator(`#row_${contract.id}`).first().click();
      await page.locator("#contract-line-items-tab").click();
      // Create a new contract line item
      await page.locator("#add-line-item-button").click();

      await expect(page).toHaveURL(
        `/intelligence/${account.id}/contract/${contract.id}/line-item/new`
      );
      // Selecting two products for the line item
      await page.locator(`#row_product_${products[0].id}`).first().click();
      await page.locator(`#row_product_${products[1].id}`).first().click();
      await page.locator("#save-contract-line-item-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Line item saved successfully\nContinue to set pricing"
      );
      // Go back and deselect one of the two products and expecting the confirmation modal to pop up
      await page.locator("#line-item-crumb").click();

      await page.locator(`#row_product_${products[0].id}`).first().click();
      await expect(
        page.locator("#remove-product-confirmation").first()
      ).toContainText("Do you want to remove this product?");
      await page.locator("#remove-line-item-product").click();
      await page.locator("#save-contract-line-item-button").click();
    })
  );

  test(
    "Creating new fees for contract line item",
    withFixture(async ({ page, account, contract }) => {
      await page.goto("/intelligence");
      await page.locator("#contracts-link").click();

      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(contract.name);
      await page.locator("#search-bar").press("Enter");

      await page.locator(`#row_${contract.id}`).first().click();
      await page.locator("#contract-line-items-tab").click();
      // Add a new line item
      await page.locator("#add-line-item-button").click();

      await expect(page).toHaveURL(
        `/intelligence/${account.id}/contract/${contract.id}/line-item/new`
      );
      // Create a new fee
      await page.locator("#table-add-button").click();
      await page.locator("#fee_name").fill("New Fee");
      await page.locator("#fee_category_id").selectOption("Advertising");

      await page.locator("#save-new-fee").click();

      await expect(page.locator(".Toastify").first()).toContainText(
        "Fee created successfully"
      );

      await page.locator("#save-contract-line-item-button").click();

      await expect(page.locator(".Toastify").first()).toContainText(
        "Line item saved successfully\nContinue to set pricing"
      );
    })
  );

  test(
    "Sending contract line item form without selecting products",
    withFixture(async ({ page, contract }) => {
      await page.goto("/intelligence");
      await page.locator("#contracts-link").click();

      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(contract.name);
      await page.locator("#search-bar").press("Enter");

      await page.locator(`#row_${contract.id}`).first().click();
      await page.locator("#contract-line-items-tab").click();

      // Add a new line item without selecting products or fees
      await page.locator("#add-line-item-button").click();
      await page.locator("#save-contract-line-item-button").click();

      // Expect an error
      await expect(page.locator(".Toastify").first()).toContainText(
        DEFAULT_FORM_ERROR_MESSAGE
      );
    })
  );
});
