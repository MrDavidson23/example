import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const FORM_ERROR_MESSAGE =
  "There was an error requesting a password reset. Please try again.";
const FORM_SUCCESS_MESSAGE =
  "If there is an account associated with the email address entered, you should receive a password reset email in your inbox shortly.";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page, db }) => {
    const user = await registerNewUser(page);
    await page.goto("/logout");
    return { user };
  },
  cleanup: async ({ db, user }) => {
    await db.user.delete({ where: { id: user.id } });
    await db.forgotPasswordToken.deleteMany({ where: { user_id: user.id } });
  },
});

test.describe("Discovery > Forgot Password", () => {
  test(
    "Check forgot password form",
    withFixture(async ({ page, user }) => {
      await page.goto("/login");

      // Click on forgot password link
      await page.click("#forgot-password-link");

      // Check the form
      await expect(page.locator("h1")).toHaveText("Reset your password");

      // Fill in the form with empty email
      await page.fill("#email-address", "");
      await page.click("#forgot-password-submit-button");

      // Check no success message
      await expect(page.locator("#toast")).not.toBeVisible();

      // Fill in the form with invalid email
      await page.fill("#email-address", "invalid@email");
      await page.click("#forgot-password-submit-button");

      // Check error message
      await expect(page.locator("#toast")).toHaveText(FORM_ERROR_MESSAGE);

      // Fill in the form with valid email
      await page.fill("#email-address", user.email);
      await page.click("#forgot-password-submit-button");

      // Check success message
      await expect(page.locator("#toast")).toHaveText(FORM_SUCCESS_MESSAGE);

      // Check login link
      await page.click("#login-link");

      // Check the url
      await expect(page).toHaveURL(/login/);
    })
  );
});
