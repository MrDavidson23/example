import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { createAccount } from "prisma/seed/intelligence.seed";
import { faker } from "@faker-js/faker";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { ManagerAccountRoleType } from "@prisma/client";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page, db }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);

    const user2 = await db.user.create({
      data: {
        email: faker.internet.email({ provider: "test.com" }),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
      },
    });

    await db.managerAccountRole.create({
      data: {
        manager_account: { connect: { id: account.id } },
        user: { connect: { id: user2.id } },
        role: ManagerAccountRoleType.Editor,
      },
    });

    const invitation = await db.userInvitation.create({
      data: {
        email: faker.internet.email({ provider: "test.com" }),
        role: {
          role: ManagerAccountRoleType.Viewer,
          manager_account_id: account.id,
        },
      },
    });

    return { user, user2, account, invitation };
  },
  cleanup: async ({ db, user, user2, account, invitation }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({
      where: { user_id: { in: [user.id, user2.id] } },
    });
    await db.user.deleteMany({ where: { id: { in: [user.id, user2.id] } } });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.userInvitation.delete({ where: { id: invitation.id } });
  },
});

test.describe.parallel("Intelligence Account User Management", () => {
  test(
    "Check users table, edit user and delete user",
    withFixture(async ({ page, account, user, user2, invitation }) => {
      await page.goto("/intelligence");
      await page.click("#account-link");
      await page.click("#users-tab");

      // Check emails and roles are displayed in table
      await expect(
        page.locator(`#row_${user.id}`).getByRole("cell", { name: user.email })
      ).toBeVisible();
      await expect(
        page
          .locator(`#row_${user.id}`)
          .getByRole("cell", { name: ManagerAccountRoleType.Owner })
      ).toBeVisible();
      await expect(
        page
          .locator(`#row_${user2.id}`)
          .getByRole("cell", { name: user2.email })
      ).toBeVisible();
      await expect(
        page
          .locator(`#row_${user2.id}`)
          .getByRole("cell", { name: ManagerAccountRoleType.Editor })
      ).toBeVisible();
      await expect(
        page
          .locator(`#row_${invitation.id}`)
          .getByRole("cell", { name: invitation.email })
      ).toBeVisible();
      await expect(
        page
          .locator(`#row_${invitation.id}`)
          .getByRole("cell", { name: ManagerAccountRoleType.Viewer })
      ).toBeVisible();

      // Edit link
      await page.click(`#row_${user2.id}`);
      await expect(page).toHaveURL(
        `/intelligence/${account.id}/account/users/${user2.id}`
      );

      // Check email field disabled
      await expect(page.locator("[name='email']")).toBeDisabled();

      // Check and change user role
      await expect(page.locator("[name='role']")).toHaveValue(
        ManagerAccountRoleType.Editor
      );
      await page
        .locator("[name='role']")
        .selectOption(ManagerAccountRoleType.Viewer);

      await page.locator("#save").click();

      await expect(page.locator(".Toastify").first()).toContainText(
        "User updated successfully"
      );

      // Check updated role
      await expect(
        page
          .locator(`#row_${user2.id}`)
          .getByRole("cell", { name: ManagerAccountRoleType.Viewer })
      ).toBeVisible();

      // Delete user
      await page.click(`#row_${user2.id}`);
      await page.click("#delete-button");
      await page.click("#confirm-delete-button");

      // Check success
      await expect(page.locator(".Toastify").first()).toContainText(
        "User removed successfully"
      );
    })
  );

  test(
    "Send user invitation, resend invitation and delete invitation",
    withFixture(async ({ db, page }) => {
      await page.goto("/intelligence");
      await page.click("#account-link");
      await page.click("#users-tab");

      await page.click("#add-user");

      // Fill form
      const email = faker.internet.email({ provider: "test.com" });

      await page.locator("[name='email']").fill(email);
      await page
        .locator("[name='role']")
        .selectOption(ManagerAccountRoleType.Editor);

      await page.locator("#save").click();

      // Check success
      await expect(page.locator(".Toastify").first()).toContainText(
        "New invitation sent successfully"
      );

      // Check invitation in db
      const userInvite = await db.userInvitation.findFirst({
        where: {
          email,
        },
      });

      // Resend invitation
      await page
        .locator(`#row_${userInvite?.id}`)
        .getByRole("button", { name: "Resend Invite" })
        .click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Invitation email sent successfully"
      );

      // Delete invitation
      await page.click(`#row_${userInvite?.id}`);

      await page.click("#delete-button");
      await page.click("#confirm-delete-button");

      // Check success
      await expect(page.locator(".Toastify").first()).toContainText(
        "User removed successfully"
      );
    })
  );
});
