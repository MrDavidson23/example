import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { createAccount } from "prisma/seed/intelligence.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    await page.goto(`/intelligence`);
    return { user, account };
  },
  cleanup: async ({ db, user, account }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.managerAccount.delete({ where: { id: account.id } });
  },
});
test.describe("Intelligence Account", () => {
  test(
    "Test CTAs redirects and edit company info form",
    withFixture(async ({ page, account }) => {
      await page.goto(`/intelligence/${account.id}/account`);
      await page.locator("#edit-personal-info").click();
      await expect(page).toHaveURL(`/profile`);
      await page.goBack();
      await page.locator("#edit-company-info").click();
      await page.locator("#name").fill("Company Name");
      await page.locator("#save-account-info").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Intelligence account updated successfully"
      );
    })
  );
});
