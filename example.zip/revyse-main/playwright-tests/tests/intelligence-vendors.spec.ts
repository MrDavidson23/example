import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createManyAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendorA = await createVendor();
    const vendorB = await createVendor();
    const vendorC = await createVendor();
    const vendorD = await createVendor();
    const vendorIds = [vendorA.id, vendorB.id, vendorC.id, vendorD.id];

    const accountVendor = await createManyAccountVendor(account, [
      vendorA.id,
      vendorB.id,
      vendorC.id,
      vendorD.id,
    ]);
    return { user, account, vendorIds, accountVendor };
  },
  cleanup: async ({ db, user, account, vendorIds }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.deleteMany({ where: { id: { in: vendorIds } } });
  },
});

test.describe("Intelligence Vendor Listing Page", () => {
  test(
    "Search vendors",
    withFixture(async ({ page, accountVendor, account }) => {
      await page.goto(`/intelligence/${account.id}/vendors`);
      const response = await page.request.get(
        `/intelligence/${account.id}/vendors`
      );
      await expect(response).toBeOK();
      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(accountVendor[0].vendor.name);
      await page.locator("#search-bar").press("Enter");
      await expect(page.locator("td:nth-child(1)").first()).toContainText(
        accountVendor[0].vendor.name
      );
      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(accountVendor[3].vendor.name);
      await page.locator("#search-bar").press("Enter");
      await expect(page.locator("td:nth-child(1)").first()).toContainText(
        accountVendor[3].vendor.name
      );
    })
  );
});
