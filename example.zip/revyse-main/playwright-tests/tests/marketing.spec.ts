import { test, expect } from "@playwright/test";

test.describe.parallel("Home Page Happy Paths", () => {
  test("Search Products", async ({ page, baseURL }) => {
    await page.goto(baseURL!);
    await page.locator("#search-bar").click();
    await page.locator("#search-bar").fill("revyse");
    await page.locator("#search-button").click();
    await expect(page).toHaveURL(`${baseURL}/search?query=revyse`);
  });
  test("Browse Categories", async ({ page, baseURL }) => {
    await page.goto(baseURL!);
    await page.locator("#category0").click();
    await page.locator("#category1").click();
    await page.locator("#category2").click();
    await page.locator("#see-all-categories").click();
    await expect(page).toHaveURL(`${baseURL}/categories`);
  });
  test("Calls to action", async ({ page, baseURL }) => {
    await page.goto(baseURL!);
    await page.locator("#review-button").click();
    await expect(page).toHaveURL(`${baseURL}/categories`);
    await page.goto(baseURL!);
    await page.locator("#vendor-button").click();
    await expect(page).toHaveURL(`${baseURL}/for-vendors`);
    await page.goto(baseURL!);
    await page.locator("#posts-button").click();
    await expect(page).toHaveURL(`${baseURL}/articles`);
  });
});
