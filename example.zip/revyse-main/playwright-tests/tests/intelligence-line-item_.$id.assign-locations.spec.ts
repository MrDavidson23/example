import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import {
  createContract,
  createContractLineItem,
  createTestLocations,
} from "./db-helpers/intelligence.helper";
import {
  createTestCategory,
  createTestProducts,
} from "./db-helpers/general.helper";
import { map } from "lodash";
import { LocationStatus } from "@prisma/client";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);
    const category = await createTestCategory();
    const products = await createTestProducts({ category_id: category.id });
    const contract = await createContract(accountVendor.id);
    const locations = await createTestLocations(
      { manager_account_id: account.id, status: LocationStatus.Active },
      { count: 20 }
    );
    const contractLineItem = await createContractLineItem(
      contract,
      map(products, "id")
    );

    return {
      user,
      account,
      vendor,
      accountVendor,
      contract,
      locations,
      category,
      contractLineItem,
      products,
    };
  },
  cleanup: async ({
    db,
    user,
    account,
    contract,
    vendor,
    contractLineItem,
    category,
    products,
  }) => {
    await db.contractLineItemProduct.deleteMany({
      where: { contract_line_item_id: contractLineItem.id },
    });
    await db.contractLineItemLocation.deleteMany({
      where: { contract_line_item_id: contractLineItem.id },
    });
    await db.contractLineItem.delete({
      where: { id: contractLineItem.id },
    });
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.contract.delete({ where: { id: contract.id } });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.location.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.product.deleteMany({ where: { id: { in: map(products, "id") } } });
    await db.productCategory.delete({ where: { id: category.id } });
  },
});

test.describe("Intelligence Assign Locations", () => {
  test(
    "Assign locations to contract line item thru ellipsis button menu",
    withFixture(
      async ({ page, account, contract, contractLineItem, locations }) => {
        await page.goto(
          `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/summary`
        );
        await page.locator("#ellipsis-menu").click();
        await page.locator("#assign-locations-button").click();
        await page.getByRole("cell", { name: locations[0].name }).click();
        await page.getByRole("cell", { name: locations[1].name }).click();
        await page.getByRole("cell", { name: locations[2].name }).click();
        await page.getByRole("cell", { name: locations[3].name }).click();
        await page.getByRole("cell", { name: locations[4].name }).click();

        await page.locator("#search-bar").fill(locations[5].name);
        await page.locator("#search-bar").press("Enter");

        await page.getByRole("cell", { name: locations[5].name }).click();
        await page.locator(`#removeTag-${locations[0].id}`).click();
        await page.locator(`#removeTag-${locations[1].id}`).click();

        await page.locator("#save-locations-button").click();
        await page
          .locator("#confirm-assigned-locations-modal-confirm-button")
          .click();
        await expect(page.locator(".Toastify").first()).toContainText(
          "Locations assigned successfully"
        );
      }
    )
  );

  test(
    "Assign locations to contract line item thru CTA",
    withFixture(
      async ({ page, account, contract, contractLineItem, locations }) => {
        await page.goto(
          `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/summary`
        );
        await page.locator("#assign-locations").click();
        await page.getByRole("cell", { name: locations[0].name }).click();
        await page.getByRole("cell", { name: locations[1].name }).click();
        await page.getByRole("cell", { name: locations[2].name }).click();
        await page.getByRole("cell", { name: locations[3].name }).click();
        await page.getByRole("cell", { name: locations[4].name }).click();

        await page.locator("#search-bar").fill(locations[5].name);
        await page.locator("#search-bar").press("Enter");

        await page.getByRole("cell", { name: locations[5].name }).click();
        await page.locator(`#removeTag-${locations[0].id}`).click();
        await page.locator(`#removeTag-${locations[1].id}`).click();

        await page.locator("#save-locations-button").click();
        await page
          .locator("#confirm-assigned-locations-modal-confirm-button")
          .click();
        await expect(page.locator(".Toastify").first()).toContainText(
          "Locations assigned successfully"
        );
      }
    )
  );
});
