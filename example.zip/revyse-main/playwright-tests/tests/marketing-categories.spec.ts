import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { faker } from "@faker-js/faker";
import { createTestCategories } from "./db-helpers/general.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page, db }) => {
    const categories = [];

    const popularCategories = {
      technology: await db.productCategory.findMany({
        where: {
          name: {
            in: ["Smart Home", "Resident App", "Virtual Leasing Agents"],
          },
        },
      }),
      services: await db.productCategory.findMany({
        where: {
          name: { in: ["Branding & Design", "Business Consultants"] },
        },
      }),
      suppliers: await db.productCategory.findMany({
        where: {
          name: { in: ["Facilities & Maintenance Supplies", "WiFi & Telecom"] },
        },
      }),
    };

    categories.push(
      ...(await createTestCategories(
        { secondary_vendor_type: "Software" },
        { count: 5 }
      ))
    );
    categories.push(
      ...(await createTestCategories(
        { secondary_vendor_type: "Hardware" },
        { count: 5 }
      ))
    );
    categories.push(
      ...(await createTestCategories(
        { secondary_vendor_type: "Agencies" },
        { count: 5 }
      ))
    );
    categories.push(
      ...(await createTestCategories(
        { secondary_vendor_type: "Professional Services" },
        { count: 5 }
      ))
    );
    categories.push(
      ...(await createTestCategories(
        { secondary_vendor_type: "Materials" },
        { count: 5 }
      ))
    );
    categories.push(
      ...(await createTestCategories(
        { secondary_vendor_type: "Onsite Services" },
        { count: 5 }
      ))
    );

    return { categories, popularCategories };
  },
  cleanup: async ({ db, categories }) => {
    await db.productCategory.deleteMany({
      where: {
        id: {
          in: categories.flat().map(c => c.id),
        },
      },
    });
  },
});

test.describe.parallel("Discovery > All Categories", () => {
  test(
    "Check category display and popular categories display",
    withFixture(async ({ page, categories, popularCategories }) => {
      await page.goto("/categories");

      // Check popular categories

      // technology
      for (const category of popularCategories.technology) {
        await expect(
          page.locator(
            `#technology #popular-category-${category.id} #popular-category-name`
          )
        ).toHaveText(category.name);
        await expect(
          page.locator(
            `#technology #popular-category-${category.id} #popular-category-description`
          )
        ).toHaveText(`${category.description.substring(0, 230)}...`);
        await expect(
          page.locator(
            `#technology #popular-category-${category.id} #popular-category-name`
          )
        ).toHaveAttribute("href", `/categories/${category.slug}`);
        await expect(
          page.locator(
            `#technology #popular-category-${category.id} #popular-category-view-link`
          )
        ).toHaveAttribute("href", `/categories/${category.slug}`);
      }

      // services
      for (const category of popularCategories.services) {
        await expect(
          page.locator(
            `#services #popular-category-${category.id} #popular-category-name`
          )
        ).toHaveText(category.name);
        await expect(
          page.locator(
            `#services #popular-category-${category.id} #popular-category-description`
          )
        ).toHaveText(`${category.description.substring(0, 230)}...`);
        await expect(
          page.locator(
            `#services #popular-category-${category.id} #popular-category-name`
          )
        ).toHaveAttribute("href", `/categories/${category.slug}`);
        await expect(
          page.locator(
            `#services #popular-category-${category.id} #popular-category-view-link`
          )
        ).toHaveAttribute("href", `/categories/${category.slug}`);
      }

      // suppliers
      for (const category of popularCategories.suppliers) {
        await expect(
          page.locator(
            `#suppliers #popular-category-${category.id} #popular-category-name`
          )
        ).toHaveText(category.name);
        await expect(
          page.locator(
            `#suppliers #popular-category-${category.id} #popular-category-description`
          )
        ).toHaveText(`${category.description.substring(0, 230)}...`);
        await expect(
          page.locator(
            `#suppliers #popular-category-${category.id} #popular-category-name`
          )
        ).toHaveAttribute("href", `/categories/${category.slug}`);
        await expect(
          page.locator(
            `#suppliers #popular-category-${category.id} #popular-category-view-link`
          )
        ).toHaveAttribute("href", `/categories/${category.slug}`);
      }

      // Check categories for each section
      for (const type of [
        "software",
        "hardware",
        "agencies",
        "professional-services",
        "materials",
        "onsite-services",
      ]) {
        const typeCategories = categories.filter(
          c =>
            c.secondary_vendor_type.toLocaleLowerCase().replace(/\s/g, "-") ===
            type
        );
        for (const category of typeCategories) {
          await expect(
            page.locator(`#${type}-section #category-${category.id}`)
          ).toHaveText(category.name);
          await expect(
            page.locator(`#${type}-section #category-${category.id}`)
          ).toHaveAttribute("href", `/categories/${category.slug}`);
        }
      }

      // Check all categories
      for (const category of categories) {
        await expect(
          page.locator(`#all-categories #category-${category.id}`)
        ).toHaveText(category.name);
        await expect(
          page.locator(`#all-categories #category-${category.id}`)
        ).toHaveAttribute("href", `/categories/${category.slug}`);
      }
    })
  );

  test(
    "Check screen links and home link",
    withFixture(async ({ page, categories, popularCategories }) => {
      await page.goto("/categories");

      await page.locator("#crumb-home").click();
      await expect(page).toHaveURL("");
      await page.goto("/categories");

      // Popular categories
      // technology
      await page
        .locator(
          `#technology #popular-category-${popularCategories.technology[0].id} #popular-category-view-link`
        )
        .click();
      await expect(page).toHaveURL(
        `/categories/${popularCategories.technology[0].slug}`
      );
      await page.goBack();

      // services
      await page
        .locator(
          `#services #popular-category-${popularCategories.services[0].id} #popular-category-view-link`
        )
        .click();
      await expect(page).toHaveURL(
        `/categories/${popularCategories.services[0].slug}`
      );
      await page.goBack();

      // suppliers
      await page
        .locator(
          `#suppliers #popular-category-${popularCategories.suppliers[0].id} #popular-category-view-link`
        )
        .click();
      await expect(page).toHaveURL(
        `/categories/${popularCategories.suppliers[0].slug}`
      );
      await page.goBack();

      // Links for each category type
      for (const type of [
        "software",
        "hardware",
        "agencies",
        "professional-services",
        "materials",
        "onsite-services",
      ]) {
        const category = categories.find(
          c =>
            c.secondary_vendor_type.toLowerCase().replace(/\s/g, "-") === type
        )!;
        await page.locator(`#${type}-section #category-${category.id}`).click();
        await expect(page).toHaveURL(`/categories/${category.slug}`);
        await page.goBack();
      }

      // Links for all categories
      for (const category of faker.helpers.arrayElements(categories, 10)) {
        await page.locator(`#all-categories #category-${category.id}`).click();
        await expect(page).toHaveURL(`/categories/${category.slug}`);
        await page.goBack();
      }
    })
  );
});
