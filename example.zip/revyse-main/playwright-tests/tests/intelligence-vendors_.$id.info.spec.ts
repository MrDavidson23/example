import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);
    return { user, account, vendor, accountVendor };
  },
  cleanup: async ({ db, user, account, vendor }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
  },
});

test.describe("Intelligence Vendor Info Page", () => {
  test(
    "Update vendor info",
    withFixture(async ({ page, accountVendor, account }) => {
      await page.goto(
        `/intelligence/${account.id}/vendors/${accountVendor.id}/info`
      );
      // Submit empty form
      await page.locator("#save-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Vendor info updated successfully"
      );

      // Go to info page again
      await page.locator("#edit-vendor-info").click();

      // Submit full form
      await page.locator("[id='status']").selectOption("Active");
      await page.locator("#vendor_since").fill("2021-01-01");
      await page.locator("#internal_vendor_code").fill("code");
      await page.locator("#street_1").fill("1234 Main St.");
      await page.locator("#street_2").fill("Apt 24");
      await page.locator("#city").fill("Bend");
      await page.locator("#state").selectOption("OR");
      await page.locator("#zip").fill("77777");
      await page.locator("#country").fill("USA");
      await page.locator("#phone").fill("(555) 555-5555");
      await page.locator("#save-button").click();
      await expect(page.locator(".Toastify").first()).toContainText(
        "Vendor info updated successfully"
      );
    })
  );
});
