import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import { createProductWithSubscription } from "./db-helpers/product-subscription.spec.helper";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    return {
      user,
    };
  },
  cleanup: async ({ db, user }) => {
    await db.user.delete({ where: { id: user.id } });
  },
});

const withProductCreationFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const productSubscription = await createProductWithSubscription(user.id);
    return {
      user,
      ...productSubscription,
    };
  },
  cleanup: async ({
    db,
    user,
    category,
    vendor,
    product,
    stripeProduct,
    stripePrice,
    productSubscription,
    userRole,
  }) => {
    await db.userRole.delete({ where: { id: userRole.id } });
    await db.productSubscription.delete({
      where: { id: productSubscription.id },
    });
    await db.stripePrice.delete({ where: { id: stripePrice.id } });
    await db.stripeProduct.delete({ where: { id: stripeProduct.id } });
    await db.product.delete({ where: { id: product.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
    await db.productCategory.delete({ where: { id: category.id } });
    await db.user.delete({ where: { id: user.id } });
  },
});

test.describe.parallel("Vendor Portal Page", () => {
  test(
    "All Reviews link",
    withFixture(async ({ db, page }) => {
      await page.goto("/vendor");
      await page.locator("#all-reviews").click();
      await expect(page).toHaveURL(`/vendor/reviews`);
    })
  );

  test(
    "All Listings link",
    withFixture(async ({ page }) => {
      await page.goto("/vendor");
      await page.locator("#all-listings").click();
      await expect(page).toHaveURL(`/vendor/products`);
    })
  );

  test(
    "Create One add button",
    withFixture(async ({ page }) => {
      await page.goto("/vendor");
      await page.locator("#create-product").click();
      await expect(page).toHaveURL(`/vendor/products/new`);
    })
  );

  test(
    "Products Links",
    withProductCreationFixture(async ({ page, productSubscription }) => {
      await page.goto("/vendor");
      await page.locator(`#sub_${productSubscription.id}`).click();
      await expect(page).toHaveURL(
        `/vendor/products/${productSubscription.product_id}`
      );
    })
  );
});
