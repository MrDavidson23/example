import { test, expect } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { fillContractForm } from "./page-helpers/contract.spec.helper";
import { faker } from "@faker-js/faker";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const vendor2 = await createVendor();
    const vendor3 = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);
    await page.goto(`/intelligence`);
    return { user, account, vendor, vendor2, vendor3, accountVendor };
  },
  cleanup: async ({ db, user, account, vendor, vendor2, vendor3 }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.contract.deleteMany({
      where: { manager_account_vendor: { manager_account_id: account.id } },
    });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.deleteMany({
      where: { id: { in: [vendor.id, vendor2.id, vendor3.id] } },
    });
  },
});

test.describe.parallel("Intelligence Contracts Page", () => {
  test(
    "Add a new contract manually",
    withFixture(async ({ page, vendor }) => {
      await page.locator("[id='contracts-link']").click();
      await page.locator("[id='add-contract-button']").click();

      const contractName = faker.company.name();
      await fillContractForm(page, contractName, vendor);

      await page.locator("[id='contracts-link']").click();
      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(contractName);
      await page.locator("#search-bar").press("Enter");
      const contractCell = await page.getByRole("cell", { name: contractName });
      await expect(contractCell).toContainText(contractName);
      await contractCell.click();
      await expect(page).toHaveURL(/details/);
    })
  );

  test(
    "Edit contract",
    withFixture(async ({ page, vendor2, vendor3 }) => {
      await page.locator("[id='contracts-link']").click();
      await page.locator("[id='add-contract-button']").click();
      const contractName = faker.company.name();
      await fillContractForm(page, contractName, vendor2);
      await expect(page.locator(".Toastify").first()).toContainText(
        "Contract saved successfully"
      );
      await page.locator("[id='contracts-link']").click();
      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(contractName);
      await page.locator("#search-bar").press("Enter");
      await page.getByRole("cell", { name: contractName }).first().click();
      await page.getByRole("button", { name: "Edit Contract" }).click();
      await page.locator("[id='clear-vendor']").click();

      const newContractName = `${contractName} - Test 3`;
      await fillContractForm(page, newContractName, vendor3);
      await expect(page.locator(".Toastify").first()).toContainText(
        "Contract saved successfully"
      );

      await page.locator("[id='contracts-link']").click();
      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill(newContractName);
      await page.locator("#search-bar").press("Enter");
      await expect(
        page.getByRole("cell", { name: newContractName }).first()
      ).toContainText(newContractName);
    })
  );

  test(
    "Delete contract",
    withFixture(async ({ page, account, vendor }) => {
      await page.locator("#contracts-link").click();
      await page.locator("#add-contract-button").click();
      await fillContractForm(page, "Contract To Delete", vendor);
      await page.locator("#contracts-link").click();
      await page.locator("#search-bar").click();
      await page.locator("#search-bar").fill("Contract To Delete");
      await page.locator("#search-bar").press("Enter");
      await page
        .getByRole("cell", { name: "Contract To Delete" })
        .first()
        .click();
      await page.locator("#cancel-contract-button").click();
      await page.locator("#confirm-delete-modal-confirm-button").click();
      await expect(page).toHaveURL(
        `/intelligence/${account.id}/contracts?status=archived`
      );
      await expect(page.locator(".Toastify").first()).toContainText(
        "Contract archived successfully"
      );
      await page
        .getByRole("cell", { name: "Contract To Delete" })
        .first()
        .click();
      await page.locator("#delete-contract-button").click();
      await page.locator("#confirm-delete-modal-confirm-button").click();
      await expect(page).toHaveURL(`/intelligence/${account.id}/contracts`);
      await expect(page.locator(".Toastify").first()).toContainText(
        "Contract deleted successfully"
      );
    })
  );

  // test.skip("Create line item", async ({ page }) => {
  //   await createLocation(page, "Location 1");
  //   await createLocation(page, "Location 2");
  //   await createLocation(page, "Location 3");
  //   await page.locator("[id='contracts-link']").click();
  //   await page.getByRole("cell", { name: "Test 1 Contract" }).first().click();
  //   await page
  //     .getByRole("link", { name: "Products and Line Items", exact: true })
  //     .click();
  //   await page
  //     .getByRole("button", { name: "Add Line Item", exact: true })
  //     .click();
  //   await page.locator("[id='name']").click();
  //   await page.locator("[id='name']").fill("New Line Item");
  //   await page.locator(".product-card").first().click();
  //   await page.locator("[id='saveContractLineItemButton']").click();
  //   await page
  //     .locator("[id='contract_line_item.cadence']")
  //     .selectOption("Monthly");
  //   await page
  //     .locator("[id='contract_line_item.pricing_type']")
  //     .selectOption("PerLocation");
  //   await page.locator("[id='contract_line_item.price']").dblclick();
  //   await page.locator("[id='contract_line_item.price']").fill("$5,7865");
  //   await page.locator("[id='contract_line_item.setup_fee']").click();
  //   await page.locator("[id='contract_line_item.setup_fee']").fill("$896");
  //   await page.locator("[id='contract_line_item.discount']").click();
  //   await page.locator("[id='contract_line_item.discount']").fill("$4567");
  //   await page.locator("[id='contract_line_item.discount']").click();
  //   await page.locator("[id='contract_line_item.discount']").fill("$67");
  //   await page.locator("[id='department']").click();
  //   await page.locator("[id='department']").fill("New Department");
  //   await page.locator("#save-button").click();

  //   // TODO: Add tests for assigning locations
  // });
});
