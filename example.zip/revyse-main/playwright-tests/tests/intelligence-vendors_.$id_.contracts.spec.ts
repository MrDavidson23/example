import { test } from "@playwright/test";
import { withE2EFixtureFactory } from "./utils";
import {
  createAccount,
  createAccountVendor,
} from "prisma/seed/intelligence.seed";
import { createVendor } from "prisma/seed/vendor.seed";
import { registerNewUser } from "./page-helpers/sign-up.spec.helper";
import { createContract } from "./db-helpers/intelligence.helper";

const withFixture = withE2EFixtureFactory({
  setup: async ({ page }) => {
    const user = await registerNewUser(page);
    const account = await createAccount(user);
    const vendor = await createVendor();
    const accountVendor = await createAccountVendor(account, vendor.id);
    const contracts = await Promise.all(
      Array.from({ length: 20 }).map(() => createContract(accountVendor.id))
    );

    return { user, account, vendor, accountVendor, contracts };
  },
  cleanup: async ({ db, user, account, vendor, accountVendor }) => {
    await db.managerAccountRole.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.userCredential.deleteMany({ where: { user_id: user.id } });
    await db.user.delete({ where: { id: user.id } });
    await db.contract.deleteMany({
      where: { manager_account_vendor_id: accountVendor.id },
    });
    await db.managerAccountVendor.deleteMany({
      where: { manager_account_id: account.id },
    });
    await db.managerAccount.delete({ where: { id: account.id } });
    await db.vendor.delete({ where: { id: vendor.id } });
  },
});

test.describe("Intelligence Vendor Contract Management", () => {
  test(
    "Add new contract link",
    withFixture(async ({ page, accountVendor, account }) => {
      await page.goto(
        `/intelligence/${account.id}/vendors/${accountVendor.id}/contracts`
      );

      await page.click("[id='add-new-contract']");

      await page.waitForURL(
        `/intelligence/${account.id}/contract/new?vendor_id=${accountVendor.vendor_id}`
      );
    })
  );

  test(
    "Check that contracts are displayed",
    withFixture(async ({ page, accountVendor, contracts, account }) => {
      await page.goto(
        `/intelligence/${account.id}/vendors/${accountVendor.id}/contracts`
      );

      await page.locator("[id='search-bar']").click();
      await page.locator("[id='search-bar']").fill(contracts[0].name);
      await page.locator("[id='search-bar']").press("Enter");

      await page.waitForSelector(`[id='contract_${contracts[0].id}']`);

      await page.locator("[id='search-bar']").click();
      await page.locator("[id='search-bar']").fill(contracts[1].name);
      await page.locator("[id='search-bar']").press("Enter");

      await page.waitForSelector(`[id='contract_${contracts[1].id}']`);
    })
  );

  test(
    "Check contract row click",
    withFixture(async ({ page, accountVendor, contracts, account }) => {
      await page.goto(
        `/intelligence/${account.id}/vendors/${accountVendor.id}/contracts`
      );

      await page.locator("[id='search-bar']").click();
      await page.locator("[id='search-bar']").fill(contracts[0].name);
      await page.locator("[id='search-bar']").press("Enter");

      await page.click(`[id='contract_${contracts[0].id}']`);

      await page.waitForURL(
        `/intelligence/${account.id}/contract/${contracts[0].id}/details`
      );
    })
  );
});
