import http from 'k6/http';
import { sleep } from 'k6';

export const options = {
  vus: 1,
  duration: '20s',
  ext: {
    loadimpact: {
      // Project: Default project
      projectID: 3644137,
      // Test runs with the same name groups test runs together
      name: 'Simple Test'
    }
  }
};

export default function() {
  http.get('https://load.revyse.com');
  sleep(1);
  http.get('https://load.revyse.com/categories');
  sleep(1);
  http.get('https://load.revyse.com/categories/advertising');
  sleep(1);
  http.get('https://load.revyse.com/products/gro-advertising');
  sleep(1);
  http.get('https://load.revyse.com/products/gro-advertising/reviews');
  sleep(1);
  const login = http.get('https://load.revyse.com/login');
  login.submitForm({
    formSelector: '#login-form',
    fields: { email: 'jonathan@revyse.com', password: 'jonny2424' },
  });
  sleep(1);
  const review = http.get('https://load.revyse.com/products/gro-advertising/reviews/new');
  review.submitForm({
    formSelector: '#review-form',
    fields: { 
      title: "tests",
      decision_maker: "SUPERVISOR",
      first_time_or_switch: "FIRST_TIME",
      first_time_or_switch_desc: "",
      considered_alt_vendors: "YES",
      considered_alt_vendors_desc: "",
      who_uses: ["ME"],
      primary_use_case: "asdfasdf",
      like_most: "asdfasdf",
      dislike_most: "asdfasdf",
      recommend_to: "asdfasfd",
      plan_to_shop: "NO",
      custom_question_1: "",
      custom_question_2: "",
      custom_question_3: "",
      customer_service_score: 5,
      customer_service_desc: "",
      value_score: 4,
      value_desc: "",
      onboarding_score: 3,
      onboarding_desc: "",
      compatibility_score: 3,
      compatibility_desc: "",
      show_last_name: "false",
      show_job_title: "false",
      show_company: "false",
  }});
  sleep(1);
  
}