# Load Testing

We use k6 for load testing

## Prereqs

1. Install k6: `brew install k6`
2. Get invited to k6
3. k6 login cloud --token <TOKEN>
4. Run a script (they are all in this directory): `k6 cloud script.js`
