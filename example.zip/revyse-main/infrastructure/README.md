# Revyse Infrastructure

The intent of the terraform configuration is that we can setup a new environment with very little
manual setup. However, to get things going we do need a couple one-time things.

## DNS

We use the `app` subdomain and then tack the environment on to the front of it. So the `dev`
environment will end up being `dev.<ROOT_DOMAIN>`. In order to be able to automatically create these
subdomains we need to setup a Route 53 zone:

1. Login to AWS console
2. Go to Route 53 (its what they call their DNS management product)
3. Create a new "Hosted Zone"
4. Domain name: `app.<ROOT_DOMAIN>`
5. Go to your DNS hosting provider and setup NS records that point to the ones that Route just 53 created for you. This allows AWS to completely control that subdomain.
6. That should be it.

## Environment Configuration

We'll use AWS Systems Manager > Parameter store to keep all of our environment configurations. At a baseline
you'll need to setup the `<ENV>_DB_USER` and `<ENV>_DB_PASS` (they can be anything) parameters before you run
the terraform configuration at all. This is because tf will pull these when creating the RDS database. Other
parameters will get pulled when deploying to ECS but those won't block TF from completing the apply, they will
just cause the service to not come up.

## AWS Credentials

In order to run any of these things you'll need some AWS credentials. If you haven't already, generate a new access key in IAM then copy it and its associated secret into your `~/.aws/credentials` like so:

```
[<PROFILE>]
aws_access_key_id = <ACCESS_KEY>
aws_secret_access_key = <SECRET>
```

Whichever `<PROFILE>` you used is the one you'll want to use in the TF configuration in `infrastructure/provider.tf` as well.

## Create an S3 Bucket to house the terraform state

A default bucket with a name like `<PROJECT>-terraform` works well

## Create an ECR Repository for our Docker images

Got to ECR > Create repository, name it something simple like `<PROJECT>`. Copy the URI you'll need it next.

## Configure Local Build Script

1. Open `build-container.sh` and copy the ECR repository URI into the `ecr` variable at the top.
2. Open `build-push.sh` and copy the ECR repository URI into the `ecr` variable at the top.

## Make sure you have the AWS CLI installed

For mac, Run: `brew install awscli`
For other, dunno

## Create a TLS cert in AWS Certificate Manager

1. Create a new wildcard cert with domain: `*.<DOMAIN>`.
2. Click into the cert and you have to verify it. Click the "Create records in Route 53" button. This is the easiest way. It might take a few seconds but it should auto validate after that.

## Setup IAM Roles & Policies

### ECSAutoScaling Role

1. Go to IAM > Roles > Create role
2. Trusted entity type: AWS Service
3. Use case: Choose a service to view use case > Elastic Container Service > Elastic Container Service Autoscale
4. Name it `ECSAUtoScaling`

### ReadFromParameterStore Policy

1. Go to IAM > Policies > Create policy
2. Paste this JSON into the JSON tab:

```
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "ssm:GetParametersByPath",
                "ssm:GetParameters",
                "ssm:GetParameter"
            ],
            "Resource": [
                "arn:aws:ssm:*:*:parameter/*"
            ]
        }
    ]
}
```

3. Name it `ReadFromParameterStore`

### ECSTaskExecution

1. Go to IAM > Roles > Create role
2. Trusted entity type: AWS Service
3. Use case: Choose a service to view use case > Elastic Container Service > Elastic Container Service Task
4. Select `ReadFromParameterStore` and `AmazonECSTaskExecutionRolePolicy`. Click next.
5. Name it: `ECSTaskExecution`

## Update the Account ID in ECS Task Definition

In `master.tf` for the `aws_ecs_task_definition` set the `aws_account_id` to the correct account id.

## Build and push the image

Run `./build-container.sh`
Follow the prompts

## Deploy a new environment

`terraform workspace create <ENV>`
`terraform apply`
