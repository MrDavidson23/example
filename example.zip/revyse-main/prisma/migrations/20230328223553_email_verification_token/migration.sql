/*
  Warnings:

  - A unique constraint covering the columns `[id,email]` on the table `user` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateTable
CREATE TABLE "email_verification_token" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "created_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "verified_at" TIMESTAMP(6),
    "user_id" UUID NOT NULL,
    "email" VARCHAR NOT NULL,

    CONSTRAINT "email_verification_token_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "evt_user_idx" ON "email_verification_token"("user_id");

-- CreateIndex
CREATE UNIQUE INDEX "email_verification_token_user_id_email_key" ON "email_verification_token"("user_id", "email");

-- CreateIndex
CREATE UNIQUE INDEX "user_id_email_key" ON "user"("id", "email");

-- AddForeignKey
ALTER TABLE "email_verification_token" ADD CONSTRAINT "user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "user"("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "email_verification_token" ADD CONSTRAINT "email_verification_token_user_id_email_fkey" FOREIGN KEY ("user_id", "email") REFERENCES "user"("id", "email") ON DELETE RESTRICT ON UPDATE CASCADE;
