/*
  Warnings:

  - You are about to drop the column `category_id` on the `product` table. All the data in the column will be lost.

*/
ALTER TABLE "product" 
RENAME COLUMN "category_id" to "primary_category_id";
ALTER TABLE "public"."product" DROP CONSTRAINT "product_category_id_fkey";

-- AlterTable
ALTER TABLE "product"
ADD COLUMN     "banner_url" TEXT,
ADD COLUMN     "brand_video_urls" TEXT[],
ADD COLUMN     "demo_scheduling_url" VARCHAR,
ADD COLUMN     "download_urls" TEXT[],
ADD COLUMN     "image_urls" TEXT[],
ADD COLUMN     "lead_prospect_email" VARCHAR,
ADD COLUMN     "logo_url" TEXT,
ADD COLUMN     "product_demo_urls" TEXT[],
ADD COLUMN     "review_questions" TEXT[],
ADD COLUMN     "secondary_category_id" UUID,
ADD COLUMN     "tertiary_category_id" UUID;

-- AlterTable
ALTER TABLE "product_category" ALTER COLUMN "name" SET DATA TYPE VARCHAR;

-- AlterTable
ALTER TABLE "vendor" ADD COLUMN     "founded_year" VARCHAR,
ADD COLUMN     "hq_location" VARCHAR,
ADD COLUMN     "linkedin_profile_url" VARCHAR,
ADD COLUMN     "number_employees" VARCHAR,
ADD COLUMN     "website" VARCHAR;

-- CreateTable
CREATE TABLE "product_feature" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "created_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "product_id" UUID NOT NULL,
    "order" INTEGER NOT NULL,

    CONSTRAINT "product_feature_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "product_package" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "created_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "product_id" UUID NOT NULL,
    "order" INTEGER NOT NULL,
    "features" TEXT[],
    "price_monthly" DOUBLE PRECISION,
    "price_yearly" DOUBLE PRECISION,
    "button_text" VARCHAR NOT NULL,
    "button_url" VARCHAR NOT NULL,

    CONSTRAINT "product_package_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "industry" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "created_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "slug" TEXT NOT NULL,

    CONSTRAINT "industry_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "good_for_tag" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "created_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "slug" TEXT NOT NULL,

    CONSTRAINT "good_for_tag_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "integration_partner" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "created_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updated_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "name" TEXT NOT NULL,
    "description" TEXT NOT NULL,

    CONSTRAINT "integration_partner_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_IndustryToProduct" (
    "A" UUID NOT NULL,
    "B" UUID NOT NULL
);

-- CreateTable
CREATE TABLE "_GoodForTagToProduct" (
    "A" UUID NOT NULL,
    "B" UUID NOT NULL
);

-- CreateTable
CREATE TABLE "_IntegrationPartnerToProduct" (
    "A" UUID NOT NULL,
    "B" UUID NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "product_feature_name_key" ON "product_feature"("name");

-- CreateIndex
CREATE UNIQUE INDEX "product_package_name_key" ON "product_package"("name");

-- CreateIndex
CREATE UNIQUE INDEX "industry_name_key" ON "industry"("name");

-- CreateIndex
CREATE UNIQUE INDEX "industry_slug_key" ON "industry"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "good_for_tag_name_key" ON "good_for_tag"("name");

-- CreateIndex
CREATE UNIQUE INDEX "good_for_tag_slug_key" ON "good_for_tag"("slug");

-- CreateIndex
CREATE UNIQUE INDEX "integration_partner_name_key" ON "integration_partner"("name");

-- CreateIndex
CREATE UNIQUE INDEX "_IndustryToProduct_AB_unique" ON "_IndustryToProduct"("A", "B");

-- CreateIndex
CREATE INDEX "_IndustryToProduct_B_index" ON "_IndustryToProduct"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_GoodForTagToProduct_AB_unique" ON "_GoodForTagToProduct"("A", "B");

-- CreateIndex
CREATE INDEX "_GoodForTagToProduct_B_index" ON "_GoodForTagToProduct"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_IntegrationPartnerToProduct_AB_unique" ON "_IntegrationPartnerToProduct"("A", "B");

-- CreateIndex
CREATE INDEX "_IntegrationPartnerToProduct_B_index" ON "_IntegrationPartnerToProduct"("B");

-- AddForeignKey
ALTER TABLE "product" ADD CONSTRAINT "product_primary_category_id_fkey" FOREIGN KEY ("primary_category_id") REFERENCES "product_category"("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "product" ADD CONSTRAINT "product_secondary_category_id_fkey" FOREIGN KEY ("secondary_category_id") REFERENCES "product_category"("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "product" ADD CONSTRAINT "product_tertiary_category_id_fkey" FOREIGN KEY ("tertiary_category_id") REFERENCES "product_category"("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "product_feature" ADD CONSTRAINT "product_feature_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "product"("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "product_package" ADD CONSTRAINT "product_package_product_id_fkey" FOREIGN KEY ("product_id") REFERENCES "product"("id") ON DELETE CASCADE ON UPDATE NO ACTION;

-- AddForeignKey
ALTER TABLE "_IndustryToProduct" ADD CONSTRAINT "_IndustryToProduct_A_fkey" FOREIGN KEY ("A") REFERENCES "industry"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_IndustryToProduct" ADD CONSTRAINT "_IndustryToProduct_B_fkey" FOREIGN KEY ("B") REFERENCES "product"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_GoodForTagToProduct" ADD CONSTRAINT "_GoodForTagToProduct_A_fkey" FOREIGN KEY ("A") REFERENCES "good_for_tag"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_GoodForTagToProduct" ADD CONSTRAINT "_GoodForTagToProduct_B_fkey" FOREIGN KEY ("B") REFERENCES "product"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_IntegrationPartnerToProduct" ADD CONSTRAINT "_IntegrationPartnerToProduct_A_fkey" FOREIGN KEY ("A") REFERENCES "integration_partner"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_IntegrationPartnerToProduct" ADD CONSTRAINT "_IntegrationPartnerToProduct_B_fkey" FOREIGN KEY ("B") REFERENCES "product"("id") ON DELETE CASCADE ON UPDATE CASCADE;
