-- AlterTable
ALTER TABLE "product" ALTER COLUMN "slug" SET DATA TYPE VARCHAR;
update product set slug = id;

-- AlterTable
ALTER TABLE "product_category" ALTER COLUMN "slug" SET DATA TYPE VARCHAR;
update product_category set slug = id;

-- AlterTable
ALTER TABLE "vendor" ALTER COLUMN "slug" SET DATA TYPE VARCHAR;
update vendor set slug = id;
