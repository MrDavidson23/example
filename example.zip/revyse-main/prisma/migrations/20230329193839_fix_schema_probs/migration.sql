-- DropForeignKey
ALTER TABLE "email_verification_token" DROP CONSTRAINT "email_verification_token_user_id_email_fkey";

-- DropIndex
DROP INDEX "email_verification_token_user_id_email_key";

-- DropIndex
DROP INDEX "user_id_email_key";
