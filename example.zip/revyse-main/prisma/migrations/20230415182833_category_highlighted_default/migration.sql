-- AlterTable
ALTER TABLE "product_category" ALTER COLUMN "highlighted" SET DEFAULT false;
