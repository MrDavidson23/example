-- AlterTable
ALTER TABLE "product" ALTER COLUMN "brand_video_urls" SET DEFAULT ARRAY[]::TEXT[],
ALTER COLUMN "download_urls" SET DEFAULT ARRAY[]::TEXT[],
ALTER COLUMN "image_urls" SET DEFAULT ARRAY[]::TEXT[],
ALTER COLUMN "product_demo_urls" SET DEFAULT ARRAY[]::TEXT[],
ALTER COLUMN "review_questions" SET DEFAULT ARRAY[]::TEXT[];
