-- AlterTable
ALTER TABLE "product" ADD COLUMN     "slug" TEXT;

-- AlterTable
ALTER TABLE "product_category" ADD COLUMN     "slug" TEXT;

-- AlterTable
ALTER TABLE "vendor" ADD COLUMN     "slug" TEXT;
