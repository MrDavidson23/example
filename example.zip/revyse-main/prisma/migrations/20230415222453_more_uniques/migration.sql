/*
  Warnings:

  - A unique constraint covering the columns `[title]` on the table `product` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[name]` on the table `vendor` will be added. If there are existing duplicate values, this will fail.
  - Made the column `slug` on table `product` required. This step will fail if there are existing NULL values in that column.
  - Made the column `slug` on table `product_category` required. This step will fail if there are existing NULL values in that column.
  - Made the column `slug` on table `vendor` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "product" ALTER COLUMN "slug" SET NOT NULL;

-- AlterTable
ALTER TABLE "product_category" ALTER COLUMN "slug" SET NOT NULL;

-- AlterTable
ALTER TABLE "vendor" ALTER COLUMN "slug" SET NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "product_title_key" ON "product"("title");

-- CreateIndex
CREATE UNIQUE INDEX "vendor_name_key" ON "vendor"("name");
