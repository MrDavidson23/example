-- DropIndex
DROP INDEX "product_feature_name_key";

-- DropIndex
DROP INDEX "product_package_name_key";
