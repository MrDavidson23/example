-- AlterTable
ALTER TABLE "product_category" ADD COLUMN     "primary_vendor_type" TEXT NOT NULL DEFAULT 'Technology',
ADD COLUMN     "secondary_vendor_type" TEXT NOT NULL DEFAULT 'Software';
