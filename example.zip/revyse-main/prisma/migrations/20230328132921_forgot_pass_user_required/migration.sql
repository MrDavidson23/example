/*
  Warnings:

  - Made the column `user_id` on table `forgot_password_token` required. This step will fail if there are existing NULL values in that column.

*/
-- AlterTable
ALTER TABLE "forgot_password_token" ALTER COLUMN "user_id" SET NOT NULL;
