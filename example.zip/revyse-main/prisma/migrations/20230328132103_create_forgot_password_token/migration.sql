-- CreateTable
CREATE TABLE "forgot_password_token" (
    "id" UUID NOT NULL DEFAULT uuid_generate_v4(),
    "created_at" TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "used_at" TIMESTAMP(6),
    "user_id" UUID,

    CONSTRAINT "forgot_password_token_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "fpt_user_idx" ON "forgot_password_token"("user_id");

-- AddForeignKey
ALTER TABLE "forgot_password_token" ADD CONSTRAINT "user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "user"("id") ON DELETE CASCADE ON UPDATE NO ACTION;
