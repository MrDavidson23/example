import { WebDIContainer } from "../di-containers/web.di-container.server";
import { RemixAdapter } from "./RemixAdapter";
import { BullMQAdapter } from "@bull-board/api/bullMQAdapter";
import { createBullBoard } from "@bull-board/api";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { assertGodModeOrRedirect } from "~/utils/auth.utils.server";

async function handleBullBoardRequest(request: Request) {
  await assertGodModeOrRedirect(request);
  const serverAdapter = new RemixAdapter("/admin/bull-board");

  const { jobService } = await WebDIContainer();

  createBullBoard({
    queues: jobService.queues.map(q => new BullMQAdapter(q)),
    serverAdapter,
  });

  const response = await serverAdapter.handleRequest(request);
  return response;
}

export async function action({ request }: ActionFunctionArgs) {
  return handleBullBoardRequest(request);
}

export async function loader({ request }: LoaderFunctionArgs) {
  return handleBullBoardRequest(request);
}
