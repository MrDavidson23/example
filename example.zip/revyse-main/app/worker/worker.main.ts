import { Worker } from "bullmq";
import { JobRegistry } from "./jobs";
import { getEnv } from "../services/env.service.server";
import { JobService } from "../services/job.service";

async function main() {
  const env = getEnv();
  const worker = new Worker(
    "default",
    async job => {
      const job_spec = JobRegistry[job.name as keyof typeof JobRegistry];
      if (!job_spec) {
        throw new Error(`Job ${job.name} not found`);
      }
      await job_spec.job(job, job.data);
    },
    {
      connection: {
        host: env.REDIS_CLUSTER_ENDPOINT,
        port: 6379,
      },
    }
  );

  worker.on("completed", job => {
    console.log(`${job.id} has completed!`);
  });

  worker.on("failed", (job, err) => {
    console.error(`${job?.id} has failed with ${err.message}`);
  });

  const job_service = new JobService();
  await job_service.initCrons();
}

main()
  .then(() => {
    console.log("Worker started");
  })
  .catch(err => {
    console.error(err);
    process.exit(1);
  });
