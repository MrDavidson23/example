import { WebDIContainer } from "../../di-containers/web.di-container.server";
import type { JobSpec } from "./job.type";

export const circleCronJob = {
  name: "circlePostsCronJob",
  job: async () => {
    const { circleService } = await WebDIContainer();
    await circleService.syncPosts();
  },
  options: {
    removeOnComplete: true,
    repeat: { pattern: "0 * * * *" },
    attempts: 1,
  },
} as const satisfies JobSpec<string>;
