import type { JobSpec } from "./job.type";
import { WebDIContainer } from "../../di-containers/web.di-container.server";

export const intelligenceNotificationsCronJob = {
  name: "intelligenceNotificationsCronJob",
  job: async job => {
    job.log("Starting intelligenceNotificationsCronJob");
    const { intelligenceNotificationService } = await WebDIContainer();
    await intelligenceNotificationService.sendConsolidatedNotificationsEmail();
  },
  options: {
    repeat: {
      pattern: "0 18 * * 2,4",
    },
  },
} as const satisfies JobSpec<string>;
