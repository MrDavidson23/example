import { WebDIContainer } from "../../di-containers/web.di-container.server";
import type { JobSpec } from "./job.type";

export const ragIndexFileJob = {
  name: "rag_index_file",
  job: async (job, data) => {
    const { ragService } = await WebDIContainer();
    await ragService.addFileToIndex(data);
  },
  options: {
    removeOnComplete: true,
    attempts: 5,
    backoff: {
      type: "exponential",
      delay: 102_000,
    },
  },
} as const satisfies JobSpec<{
  file_id: string;
  contract_id: string;
  account_id: string;
}>;
