import type { Job, Queue } from "bullmq";

export type JobSpec<DataType> = {
  name: string;
  job: (job: Job, data: DataType) => Promise<unknown> | unknown;
  options: Parameters<Queue["add"]>[2];
};
