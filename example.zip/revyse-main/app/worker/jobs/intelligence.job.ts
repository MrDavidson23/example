import type { JobSpec } from "./job.type";
import { WebDIContainer } from "../../di-containers/web.di-container.server";

export const intelligenceCronJob = {
  name: "intelligenceCronJob",
  job: async job => {
    job.log("Starting intelligenceAutoRenewalCronJob");
    const {
      contractRenewalService,
      syncCurrentTermEndDateService,
      managerAccountTaskService,
    } = await WebDIContainer();
    job.log("syncNewCurrentTermEndDates starting...");
    await syncCurrentTermEndDateService.syncNewCurrentTermEndDates();
    job.log("updateContractRenewalTaskScheduleStatuses starting...");
    await managerAccountTaskService.updateContractRenewalTaskScheduleStatuses();
    job.log("sendRenewalReminderNotifications starting...");
    await contractRenewalService.handleContractRenewal();
  },
  options: {
    repeat: {
      pattern: "0 8 * * *",
    },
  },
} as const satisfies JobSpec<string>;
