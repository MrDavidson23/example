import { circleCronJob } from "./circle.job";
import { intelligenceNotificationsCronJob } from "./intelligence-notifications.job";
import { intelligenceCronJob } from "./intelligence.job";
import type { JobSpec } from "./job.type";
import { ragIndexFileJob } from "./rag_index_file.job";

export const JobRegistry = {
  [ragIndexFileJob.name]: ragIndexFileJob,
  [circleCronJob.name]: circleCronJob,
  [intelligenceCronJob.name]: intelligenceCronJob,
  [intelligenceNotificationsCronJob.name]: intelligenceNotificationsCronJob,
} satisfies { [name: string]: JobSpec<any> };

export const CronList = Object.values(JobRegistry).filter(
  jobSpec => "repeat" in jobSpec.options
);
