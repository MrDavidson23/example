import { randomUUID } from "crypto";
import { type Readable } from "stream";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { isNil } from "lodash";

// This script will populate the vendor logos with the first product logo for each vendor.
export async function run() {
  console.log("Cloning product logos to vendors...");
  const { db, s3Service } = await WebDIContainer();

  const vendors = await db.vendor.findMany({
    where: {
      logo_file_id: null,
      products: {
        some: {
          logo_file_id: {
            not: null,
          },
        },
      },
    },
    include: {
      products: {
        where: {
          logo_file_id: {
            not: null,
          },
        },
        orderBy: {
          created_at: "asc",
        },
        take: 1,
      },
    },
  });

  await Promise.all(
    vendors.map(vendor => {
      return db.$transaction(async tx => {
        if (!isNil(vendor.logo_file_id)) return;
        if (!vendor.products[0].logo_file_id) return;

        const file = await tx.file.findUnique({
          where: {
            id: vendor.products[0].logo_file_id,
          },
        });

        if (!file) {
          console.error(
            `Failed to find file ${vendor.products[0].logo_file_id}`
          );
          return;
        }

        const response = await s3Service.getObject(file.uri);

        // Read the stream and collect it into a buffer
        const chunks: Uint8Array[] = [];
        for await (const chunk of response.Body as Readable) {
          chunks.push(chunk);
        }
        const buffer = Buffer.concat(chunks);

        // Upload the buffer to S3
        const fileExt = file.title?.split(".").pop() ?? "";

        const objectId = `${randomUUID()}.${fileExt}`;

        await s3Service.pushObject(objectId, buffer, file.mime_type!);

        const headData = await s3Service.getObjectMetadata(objectId);
        const bytes = headData.ContentLength ?? 0;

        const newFile = await tx.file.create({
          data: {
            mime_type: file.mime_type,
            size_kb: Math.round(bytes / 1000.0),
            uri: objectId,
            title: file.title,
          },
        });

        await tx.vendor.update({
          where: {
            id: vendor.id,
          },
          data: {
            logo_file_id: newFile.id,
          },
        });
        console.log(`Cloned product logo to vendor ${vendor.id}`);
      });
    })
  );

  console.log("Done!");
}

run()
  .catch(e => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => {
    process.exit(0);
  });
