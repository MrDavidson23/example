import { RAGService } from "./../services/rag.service.server";
import { MockMailChimpService } from "./../services/mail-chimp.service";
import { MockS3Service } from "../services/s3.service.server";
import { AuthService } from "../services/auth.service.server";
import type { ProxyPrismaClient } from "../services/db.server";
import { getDb } from "../services/db.server";
import { MockMailService } from "../services/mail.service.server";
import { TemplateService } from "../services/template.service.server";
import type { DIContainer } from "./di-container.server";
import { NotificationService } from "../services/notification.service.server";
import { CircleSOService } from "../services/circle.service.server";
import { SSOService } from "../services/sso.service.server";
import { ManagerAccountService } from "../services/manager-account.service.server";
import { ContractRenewalService } from "../services/contract-renewal.service.server";
import { SyncCurrentTermEndDateService } from "../services/sync-current-term-end-date.service.server";
import { ManagerAccountRoleService } from "../services/manager-account-role.service.server";
import { ContractLineItemLocationService } from "../services/line-item-location.service.server";
import { ContractLineItemService } from "../services/line-item.service.server";
import { LocationService } from "../services/location.service.server";
import { FeatureFlagService } from "../services/feature-flag.service.server";
import { ManagerAccountVendorService } from "../services/manager-account-vendor.service.server";
import { PropexoService } from "../services/propexo.service.server";
import { ContractExtractionService } from "../services/contract-extraction.service.server";
import { BuyerContactRequestService } from "../services/buyer-contact-request.service.server";
import { ProductService } from "../services/product.service.server";
import { ProductSubscriptionService } from "../services/product-subscription.service.server";
import { CustomerSupportService } from "../services/customer-support.service.server";
import { FileService } from "../services/file.service.server";
import { ManagerAccountTaskService } from "../services/manager-account-task.service.server";
import { IntelligenceNotificationService } from "../services/intelligence-notification.service.server";
import { VendorService } from "../services/vendor.service.server";
import { JobService } from "../services/job.service";
import { StripeService } from "../services/stripe.service.server";
import { ProductCategoryService } from "../services/product-category.service.server";
import { ReviewService } from "../services/review.service.server";
import { MockCircleClientService } from "../services/circle-client.service.server";
import { AutocompleteSearchBarService } from "../services/autocomplete-searchbar.service.server";
import { ContractService } from "../services/contract.service.server";
import { ManagerAccountVendorIncidentService } from "../services/manager-account-vendor-incident.service.server";
import { UserService } from "../services/user.service.server";
import { FeeService } from "../services/fee.service.server";
import { RecaptchaService } from "../services/recaptcha.service.server";
import { LocationNoticeService } from "../services/location-notice.service.server";
import { LocationServiceTerminationService } from "../services/location-service-termination.service.server";

export function TestDIContainer(dbClient?: ProxyPrismaClient): DIContainer {
  const db = dbClient ?? getDb();
  const templateService = new TemplateService();
  const mailService = new MockMailService();
  const notificationService = new NotificationService(
    mailService,
    templateService
  );
  const s3Service = new MockS3Service();
  const mailChimpService = new MockMailChimpService();
  const circleClientService = new MockCircleClientService();
  const circleService = new CircleSOService(db, circleClientService);
  const ssoService = new SSOService(db);
  const authService = new AuthService({
    db,
    templateService,
    mailService,
    notificationService,
    mailChimpService,
  });
  const customerSupportService = new CustomerSupportService(mailService);
  const productService = new ProductService(db, templateService, mailService);
  const productCategoryService = new ProductCategoryService(db, productService);
  const vendorService = new VendorService(db);
  const productSubscriptionService = new ProductSubscriptionService(
    db,
    mailService,
    templateService,
    customerSupportService
  );
  const managerAccountService = new ManagerAccountService(db, productService);
  const managerAccountRoleService = new ManagerAccountRoleService(
    db,
    mailService,
    templateService
  );
  const intelligenceNotificationService = new IntelligenceNotificationService(
    db,
    mailService,
    templateService
  );
  const managerAccountTaskService = new ManagerAccountTaskService(
    db,
    managerAccountRoleService,
    intelligenceNotificationService
  );
  const managerAccountVendorIncidentService =
    new ManagerAccountVendorIncidentService(db);
  const propexoService = new PropexoService(db);
  const reviewService = new ReviewService(
    db,
    customerSupportService,
    notificationService
  );
  const contractRenewalService = new ContractRenewalService(
    db,
    mailService,
    templateService,
    managerAccountTaskService
  );
  const syncCurrentTermEndDateService = new SyncCurrentTermEndDateService(db);
  const contractLineItemLocationService = new ContractLineItemLocationService(
    db
  );
  const locationService = new LocationService(db);
  const featureFlagService = new FeatureFlagService();
  const managerAccountVendorService = new ManagerAccountVendorService(
    db,
    managerAccountService,
    s3Service,
    customerSupportService
  );
  const ragService = new RAGService(db, s3Service);
  const contractExtractionService = new ContractExtractionService(
    db,
    ragService
  );
  const contractService = new ContractService(
    db,
    s3Service,
    customerSupportService,
    featureFlagService,
    ragService
  );
  const contractLineItemService = new ContractLineItemService(
    db,
    productService,
    contractService
  );
  const buyerContactRequestService = new BuyerContactRequestService(
    db,
    mailService,
    templateService
  );
  const fileService = new FileService(db, s3Service);
  const jobService = new JobService();
  const stripeService = new StripeService(db);
  const autocompleteSearchBarService = new AutocompleteSearchBarService(db);
  const userService = new UserService(db, authService, notificationService);
  const feeService = new FeeService(db);
  const recaptchaService = new RecaptchaService();
  const locationNoticeService = new LocationNoticeService(
    db,
    mailService,
    s3Service
  );
  const locationServiceTerminationService =
    new LocationServiceTerminationService(db, mailService, s3Service);

  const container: DIContainer = {
    db,
    templateService,
    mailService,
    authService,
    s3Service,
    circleClientService,
    circleService,
    ssoService,
    notificationService,
    mailChimpService,
    productService,
    productCategoryService,
    vendorService,
    productSubscriptionService,
    managerAccountService,
    contractService,
    contractRenewalService,
    syncCurrentTermEndDateService,
    managerAccountRoleService,
    contractLineItemLocationService,
    contractLineItemService,
    locationService,
    featureFlagService,
    managerAccountVendorService,
    managerAccountVendorIncidentService,
    propexoService,
    customerSupportService,
    reviewService,
    ragService,
    contractExtractionService,
    buyerContactRequestService,
    fileService,
    intelligenceNotificationService,
    managerAccountTaskService,
    jobService,
    stripeService,
    autocompleteSearchBarService,
    userService,
    feeService,
    recaptchaService,
    locationNoticeService,
    locationServiceTerminationService,
  };

  return container;
}
