import { ArrowRightIcon } from "@heroicons/react/20/solid";
import { VendorState, type Prisma, type VendorValueTags } from "@prisma/client";
import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Link, useLoaderData } from "@remix-run/react";
import { isEmpty, orderBy } from "lodash";
import { useEffect, useState } from "react";
import { DiscoveryHeader } from "~/components/discovery/discovery-header.component";
import { CrudCheckboxField } from "~/components/form/crud-form.component";
import { ProductCard } from "~/components/product-card.component";
import { VendorCard } from "~/components/vendor-card.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { FeatureFlag } from "~/services/feature-flag.service.server";
import {
  VendorValueIcons,
  VendorValueTagsLabels,
} from "~/utils/constants.utils";
import { tierHasPermission } from "~/utils/permission.utils";

const DEFAULT_SHOWED_PRODUCTS = 100;

export async function loader({ params, request }: LoaderFunctionArgs) {
  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const searchTerm = search.get("query");
  const {
    featureFlagService,
    productService,
    vendorService,
    managerAccountVendorService,
    productCategoryService,
  } = await WebDIContainer();

  const searchTermFilters: Prisma.VendorWhereInput = searchTerm
    ? {
        name: { equals: searchTerm, mode: "insensitive" },
      }
    : {};

  const productIds = searchTerm
    ? (
        await productService.getProductsForSearch(
          searchTerm,
          DEFAULT_SHOWED_PRODUCTS
        )
      ).map(p => p.id)
    : [];
  const products = await productService.getProductsWithRatings({
    ids: productIds,
  });

  const vendors = await vendorService.getVendors({
    filters: {
      ...searchTermFilters,
      state: VendorState.ApprovedForPublishing,
    },
  });
  const ratingPromises = vendors.map(async vendor => ({
    ...vendor,
    vendor_rating: await managerAccountVendorService.getVendorRating(vendor.id),
  }));
  const vendorsWithRatings = await Promise.all(ratingPromises);

  const categories = searchTerm
    ? await productCategoryService.getCategoriesForProducts({
        search: searchTerm,
        products,
      })
    : [];

  const industries = await productService.getIndustryOptions();

  const showVendorFilters = featureFlagService.isEnabled(
    FeatureFlag.ShowVendorFilters
  );

  return json({
    categories,
    industries,
    products,
    vendors: vendorsWithRatings,
    searchTerm,
    showVendorFilters,
  });
}

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  const searchTerm = data!.searchTerm;
  return [
    { title: `Search: ${searchTerm} | Revyse` },
    {
      name: "description",
      content: `Search results for: ${searchTerm}`,
    },
  ];
};

export default function SearchSlugRoute() {
  const {
    categories,
    industries,
    products,
    vendors,
    searchTerm,
    showVendorFilters,
  } = useLoaderData<typeof loader>();
  const [productList, setProductList] = useState(products);
  const [vendorList, setVendorList] = useState(vendors);

  const [sort, setSort] = useState<"reviews" | "ratings" | "name">("reviews");
  const [filterIndustries, setFilterIndustries] = useState<string[]>([]);
  const featuredContentFilter = [
    { value: "promos", name: "Promos and discounts" },
    { value: "demos", name: "Product Demos" },
    { value: "pricing", name: "Published pricing" },
    { value: "videos", name: "Videos" },
  ];
  const [filterFeaturedContent, setFilterFeaturedContent] = useState<string[]>(
    []
  );
  const [filterValueTags, setFilterValueTags] = useState<VendorValueTags[]>([]);

  useEffect(() => {
    let items = [...products];
    if (filterIndustries.length > 0) {
      items = products.filter(product => {
        return filterIndustries.some(industry =>
          product.industries.find(i => i.id === industry)
        );
      });
    }

    // Sort by tier and claimed listing whenever most reviews or high ratings sort is selected
    if (sort === "name") {
      items = orderBy(items, "title");
    } else {
      items = orderBy(
        items,
        [
          sort === "reviews" ? "totalReviews" : "avgReview",
          "name",
          product => {
            switch (product.tier) {
              case "tier_3":
                return 1;
              case "tier_2":
                return 2;
              case "tier_1":
                return 3;
              case "free":
                return 4;
              default:
                return 5;
            }
          },
        ],
        ["desc", "asc", "asc"]
      );
    }

    // If "Featured Content filters" are selected then filter supporting multiple filtering
    if (filterFeaturedContent.length > 0) {
      items = items.filter(product => {
        // Iterate through each selected filter and evaluate the condition
        return filterFeaturedContent.every(feature => {
          // Return true if the product satisfies the specific feature conditions
          return (
            (feature === "pricing" &&
              tierHasPermission(product.tier, "show_pricing") &&
              product._count.packages > 0) ||
            (feature === "promos" &&
              tierHasPermission(product.tier, "show_promo") &&
              product.promo_text) ||
            (feature === "videos" &&
              tierHasPermission(product.tier, "show_brand_videos") &&
              product._count.brand_video_files > 0) ||
            (feature === "demos" &&
              tierHasPermission(product.tier, "show_demos") &&
              ((product.demo_storylane_url !== null &&
                product.demo_storylane_url.length > 0) ||
                product._count.demo_files > 0))
          );
        });
      });
    }

    if (filterValueTags.length > 0) {
      items = items.filter(product => {
        return filterValueTags.every(tag => {
          return product.vendor?.value_tags.includes(tag);
        });
      });
    }

    setProductList(items);
  }, [
    sort,
    filterIndustries,
    filterFeaturedContent,
    products,
    filterValueTags,
  ]);

  useEffect(() => {
    let items = [...vendors];
    items = orderBy(items, "name");

    if (filterFeaturedContent.length > 0) {
      items = items.filter(vendor => {
        return filterFeaturedContent.every(feature => {
          return vendor.products.some(product => {
            return (
              (feature === "pricing" && product._count.packages > 0) ||
              (feature === "promos" && product.promo_text) ||
              (feature === "videos" && product._count.brand_video_files > 0) ||
              (feature === "demos" &&
                ((product.demo_storylane_url !== null &&
                  product.demo_storylane_url.length > 0) ||
                  product._count.demo_files > 0))
            );
          });
        });
      });
    }

    if (filterValueTags.length > 0) {
      items = items.filter(vendor => {
        return filterValueTags.every(tag => {
          return vendor?.value_tags.includes(tag);
        });
      });
    }

    setVendorList(items);
  }, [sort, vendors, filterFeaturedContent, filterValueTags]);

  return (
    <>
      <DiscoveryHeader
        title={`"${searchTerm}"`}
        crumbs={[
          { label: "HOME", link: "/", active: false },
          { label: "SEARCH", link: "/search", active: false },
          {
            label: `"${searchTerm}"`,
            link: `/search?query=${searchTerm}`,
            active: true,
          },
        ]}
        showImage={false}
      />

      <div className="flex justify-center bg-white">
        <div className="max-w-7xl flex-grow md:px-8">
          <div className="flex my-6 md:my-12 gap-10">
            <div className="space-y-8 w-64 pr-4 flex-col hidden md:flex">
              <h3 className="text-lg font-bold" id="all-results-count">
                All Results ({vendorList.length + productList.length})
              </h3>
              <div>
                <h3 className="text-lg font-bold mb-2">Sort By</h3>
                <select
                  className="rounded-3xl border-sky-600 text-sky-600"
                  onChange={evt => {
                    setSort(evt.target.value as any);
                  }}
                  id="sort-by-dropdown"
                >
                  <option value="reviews">Most Reviews</option>
                  <option value="ratings">Highest Ratings</option>
                  <option value="name">Name</option>
                </select>
              </div>
              <div className="w-max">
                <h3 className="text-lg font-bold">Filter By</h3>
                <div className="text-base font-semibold my-4">
                  Featured Content
                </div>
                <div>
                  {featuredContentFilter.map(option => (
                    <CrudCheckboxField
                      key={option.value}
                      field={{
                        name: "filter_by",
                        value: option.value,
                        label: option.name,
                        errors: [],
                        description: "",
                        defaultChecked: filterFeaturedContent.includes(
                          option.value
                        ),
                        type: "checkbox",
                      }}
                      onChange={evt => {
                        const checked = evt.target.checked;
                        if (checked) {
                          setFilterFeaturedContent([
                            ...filterFeaturedContent,
                            option.value,
                          ]);
                        } else {
                          setFilterFeaturedContent(
                            filterFeaturedContent.filter(
                              i => i !== option.value
                            )
                          );
                        }
                      }}
                    />
                  ))}
                </div>
                {showVendorFilters && (
                  <>
                    <div className="text-base font-semibold my-4">
                      Value Tags
                    </div>
                    {Object.entries(VendorValueTagsLabels).map(
                      ([key, label]) => (
                        <CrudCheckboxField
                          key={key}
                          field={{
                            name: "filter_by",
                            value: key,
                            label: label,
                            errors: [],
                            description: "",
                            defaultChecked: filterValueTags.includes(
                              key as VendorValueTags
                            ),
                            type: "checkbox",
                          }}
                          onChange={evt => {
                            const checked = evt.target.checked;
                            if (checked) {
                              setFilterValueTags([
                                ...filterValueTags,
                                key as VendorValueTags,
                              ]);
                            } else {
                              setFilterValueTags(
                                filterValueTags.filter(i => i !== key)
                              );
                            }
                          }}
                        />
                      )
                    )}
                  </>
                )}
                <div className="text-base font-semibold my-4">
                  Industries Served
                </div>
                <div>
                  {industries.map(industry => (
                    <CrudCheckboxField
                      key={industry.id}
                      field={{
                        name: "filter_by",
                        value: industry.id,
                        label: industry.name,
                        errors: [],
                        description: "",
                        defaultChecked: filterIndustries.includes(industry.id),
                        type: "checkbox",
                      }}
                      onChange={(evt: any) => {
                        if (evt.target.checked) {
                          setFilterIndustries([
                            ...filterIndustries,
                            industry.id,
                          ]);
                        } else {
                          setFilterIndustries(
                            filterIndustries.filter(i => i !== industry.id)
                          );
                        }
                      }}
                    />
                  ))}
                </div>
              </div>
              <strong className="mt-12">
                Categories ({categories.length})
              </strong>
              {categories.map(category => (
                <div
                  key={category.id}
                  className="my-2"
                  id={`category-${category.id}`}
                >
                  <Link
                    to={`/categories/${category.slug}`}
                    className="text-sky-600"
                  >
                    {category.name} <ArrowRightIcon className="h-4 inline" />
                  </Link>
                </div>
              ))}
            </div>
            <div className="flex-grow flex flex-col gap-8">
              {!isEmpty(vendorList) && (
                <>
                  <h2 className="text-2xl font-medium px-4 md:px-0">
                    Vendors ({vendorList.length})
                  </h2>
                  {vendorList.map(vendor => {
                    const tags = vendor.value_tags.map(tag => ({
                      value: tag,
                      label: VendorValueTagsLabels[tag],
                      icon: VendorValueIcons[tag],
                    }));

                    return (
                      <VendorCard key={vendor.id} vendor={vendor} tags={tags} />
                    );
                  })}
                </>
              )}
              <h2 className="text-2xl font-medium px-4 md:px-0">
                Products ({productList.length})
              </h2>
              {productList.map(product => {
                const p = {
                  ...product,
                  vendor_name: product.vendor!.name,
                  vendor_slug: product.vendor!.slug,
                  avg_score: product.avgReview,
                  cnt: product.totalReviews,
                };
                return <ProductCard key={product.id} product={p} />;
              })}
              {productList.length === 0 && (
                <div
                  className="text-center text-gray-500 py-20 border border-gray-200 border-dashed rounded-3xl"
                  id="no-results-message"
                >
                  No Products Found. Try changing your filters.
                </div>
              )}

              {/* TODO: uncomment when we implement pagination
              <div className="flex justify-between text-xs ">
                <div>Showing 1 to 15 of 36 results | View all Results</div>
                <div className="flex items-center gap-8">
                  <div className="flex items-center">
                    <ChevronLeftIcon className="h-5" /> Previous
                  </div>
                  <div className="flex items-center">
                    Next <ChevronRightIcon className="h-5" />
                  </div>
                </div>
              </div> */}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
