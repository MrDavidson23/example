import { json, redirect } from "@remix-run/node";
import { Outlet, useLoaderData, useLocation } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import PageTabs from "~/components/intelligence/page-tabs.component";
import { first, flatMap } from "lodash";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  Permission,
  type PermissionType,
} from "~/utils/intelligence-permission.utils";
import { equalPathnames } from "~/utils/string.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import {
  canDoSomeOnLocation,
  canDoSomeOnLocationOrThrow,
} from "~/utils/location-permission.utils";
dayjs.extend(utc);

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {}
  );

  const locationId = params.location_id!;

  const url = new URL(request.url);

  const options: {
    navigateTo: string;
    label: string;
    expectedResult: string;
    permissions: PermissionType[];
    id: string;
  }[] = [
    {
      expectedResult: "details",
      navigateTo: `/intelligence/${account.id}/locations/${locationId}/details`,
      label: "Location Details",
      permissions: [Permission.ViewLocationDetails],
      id: "details",
    },
    {
      expectedResult: "assigned-vendors",
      navigateTo: `/intelligence/${account.id}/locations/${locationId}/assigned-vendors`,
      label: "Assigned Line Items",
      permissions: [Permission.ViewLocationVendorsAndProducts],
      id: "assigned-vendors",
    },
    {
      expectedResult: "location-documents",
      navigateTo: `/intelligence/${account.id}/locations/${locationId}/location-documents`,
      label: "Documents",
      permissions: [Permission.ViewLocationDetails],
      id: "location-documents",
    },
    {
      expectedResult: "notices",
      navigateTo: `/intelligence/${account.id}/locations/${locationId}/notices`,
      label: "Notices",
      permissions: [Permission.ViewLocationNotices],
      id: "location-notices",
    },
  ];

  const authorizedOptions = options.filter(option =>
    canDoSomeOnLocation(user, account, { id: locationId }, option.permissions)
  );

  // If the current url is any of the links
  if (options.some(option => equalPathnames(option.navigateTo, url.pathname))) {
    // If no permissions to any tab, throw 403
    canDoSomeOnLocationOrThrow(
      user,
      account,
      { id: locationId },
      flatMap(options, "permissions")
    );

    // If no permissions to the requested tab, navigate to the first available
    if (
      !authorizedOptions.some(link =>
        equalPathnames(link.navigateTo, url.pathname)
      )
    ) {
      throw redirect(first(authorizedOptions)?.navigateTo || "/", 303);
    }
  }

  return json({
    options: authorizedOptions,
  });
}

export default function IntelligenceLocations() {
  const location = useLocation();

  const { options } = useLoaderData<typeof loader>();

  const formattedOptions = options.map(option => ({
    ...option,
    currentUrl: location.pathname,
  }));

  return (
    <>
      <div className="space-y-8 pb-12">
        {formattedOptions.length > 1 && (
          <PageTabs
            validationType="urlIncludes"
            options={formattedOptions}
            columns={formattedOptions.length}
          ></PageTabs>
        )}
        <Outlet />
      </div>
    </>
  );
}
