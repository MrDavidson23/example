import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  MetaFunction,
} from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { Form, Link, useActionData, useLoaderData } from "@remix-run/react";
import { LockClosedIcon } from "@heroicons/react/20/solid";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { z } from "zod";
import { isNil } from "lodash";
import { createUserSession } from "~/utils/session.server";
import { castFormFields } from "~/utils/type.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import { Toast } from "~/components/toast.component";
import { EyeIcon, EyeSlashIcon } from "@heroicons/react/24/outline";
import { useState } from "react";
import { tvField } from "~/utils/global-tailwind-variants.utils";

export type JsonData = {
  fields?: Record<string, string | null>;
  success?: boolean;
  errors?: Record<string, string[] | null>;
};
export const meta: MetaFunction = () => [
  { title: "Revyse | Reset Password" },
  {
    name: "description",
    content: "You can reset your password here",
  },
];

const ResetPasswordForm = z
  .object({
    password: z.string().min(6, "Password must be at least 6 characters long"),
    passwordConfirmation: z.string(),
    token: z.string().uuid(),
  })
  .superRefine((data, ctx) => {
    if (data.password !== data.passwordConfirmation) {
      return ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Passwords do not match",
        path: ["passwordConfirmation"],
      });
    }
  });

export const action = async ({ request }: ActionFunctionArgs) => {
  const form = await request.formData();

  const password = form.get("password");
  const passwordConfirmation = form.get("passwordConfirmation");
  const token = form.get("token");

  const fields = { password, token, passwordConfirmation };
  const validation = ResetPasswordForm.safeParse(fields);

  if (validation.success) {
    const { authService } = await WebDIContainer();
    const user = await authService.resetPassword(
      validation.data.token,
      validation.data.password
    );

    if (!isNil(user)) {
      return createUserSession(user.id, "/profile");
    }

    return json<JsonData>(
      {
        fields: castFormFields(fields),
        errors: issuesByKey([
          {
            path: ["general"],
            message: "Token not found.",
          },
        ]),
      },
      { status: 400 }
    );
  }

  return json<JsonData>(
    {
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    { status: 400 }
  );
};

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const token = params.token;
  if (isNil(token)) {
    return redirect("/login");
  }
  const { authService } = await WebDIContainer();
  const user = await authService.findUserByForgotPasswordToken(token);

  if (isNil(user)) {
    return redirect("/login");
  }

  return json({
    token,
  });
};

export default function ForgotPasswordRoute() {
  const actionData = useActionData<typeof action>();
  const { token } = useLoaderData<typeof loader>();

  const [showPassword, setShowPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword(prev => !prev);
  };
  return (
    <>
      <div className="flex min-h-full items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-md space-y-8">
          <div>
            <img
              className="mx-auto h-12 w-auto"
              src="/assets/Revyse-Logo-Black.png"
              alt="Revyse"
              width="300"
              height="105"
            />
            <h1 className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900">
              Reset your password
            </h1>
            <p className="mt-2 text-center text-sm text-gray-600">
              Or{" "}
              <Link
                to="../login"
                className="font-medium text-sky-600 hover:text-sky-500"
              >
                Login
              </Link>
            </p>
          </div>
          <Form className="mt-8 space-y-6" method="post">
            <input type="hidden" name="token" value={token} />
            <div className="rounded-md space-y-3">
              <div>
                <label htmlFor="email-address" className="sr-only">
                  New Password
                </label>
                <div className="relative">
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    required
                    className={tvField({
                      className: "shadow-sm relative",
                      error: (actionData?.errors?.password?.length ?? 0) > 0,
                    })}
                    placeholder="Password"
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 flex items-center pr-3 z-10"
                    onClick={togglePasswordVisibility}
                  >
                    {showPassword ? (
                      <EyeSlashIcon
                        className="h-5 w-5 text-gray-400 hover:text-gray-500"
                        aria-hidden="true"
                      />
                    ) : (
                      <EyeIcon
                        className="h-5 w-5 text-gray-400 hover:text-gray-500"
                        aria-hidden="true"
                      />
                    )}
                  </button>
                </div>
                <div className="text-red-500 mt-2 text-sm">
                  {actionData?.errors?.password?.join(", ")}
                </div>
              </div>
              <div>
                <input
                  id="password-confirmation"
                  name="passwordConfirmation"
                  type="password"
                  autoComplete="current-password"
                  className={tvField({
                    className: "shadow-sm relative",
                    error:
                      (actionData?.errors?.passwordConfirmation?.length ?? 0) >
                      0,
                  })}
                  placeholder="Confirm Password"
                  defaultValue={
                    actionData?.fields?.passwordConfirmation ?? undefined
                  }
                />
                <div
                  className="text-red-500 mt-2 text-sm"
                  id="errors-password-confirmation"
                >
                  {actionData?.errors?.passwordConfirmation?.join(", ")}
                </div>
              </div>
            </div>

            <div>
              <div className="text-red-500 my-2 min-h-1" role="alert">
                {actionData?.success !== undefined && (
                  <Toast
                    variant={actionData?.success ? "success" : "error"}
                    message={
                      actionData?.success
                        ? "Password has been reset."
                        : (actionData.errors?.general as unknown as string) ??
                          "There were problems resetting your password. Please try again."
                    }
                  />
                )}
              </div>
              <button
                id="reset-password-button"
                type="submit"
                className="group relative flex w-full justify-center rounded-md bg-sky-600 py-2 px-3 text-sm font-semibold text-white hover:bg-sky-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-600"
              >
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <LockClosedIcon
                    className="h-5 w-5 text-sky-500 group-hover:text-sky-400"
                    aria-hidden="true"
                  />
                </span>
                Reset Password
              </button>
            </div>
          </Form>
        </div>
      </div>
    </>
  );
}
