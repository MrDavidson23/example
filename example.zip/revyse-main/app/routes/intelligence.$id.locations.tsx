import { useEffect, useState } from "react";
import { json } from "@remix-run/node";
import { isEmpty } from "lodash";
import { z } from "zod";
import type { Location, Vendor } from "@prisma/client";
import {
  LocationClass,
  LocationCountry,
  LocationPropertyStage,
  LocationPropertyType,
  LocationStatus,
} from "@prisma/client";
import { CTA } from "~/components/cta.component";
import { Table } from "~/components/intelligence/table.component";
import { UploadCSVForm } from "~/components/intelligence/upload-csv.component";
import { useActionData, useLoaderData, useNavigate } from "@remix-run/react";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
} from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { Modal } from "~/components/modal.component";
import { LocationForm } from "~/components/intelligence/locations-form.component";
import { CrudCheckboxField } from "~/components/form/crud-form.component";
import { Pagination } from "~/components/intelligence/pagination.component";
import { NonEmptyString } from "~/utils/validation.utils.server";
import { AutocompleteFilter } from "~/components/intelligence/autocomplete-filter.component";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { castFormFields } from "~/utils/type.utils";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { FilterBar } from "~/components/filter-bar.component";
import StatusChip from "~/components/status-chip.component";
import PageTabs from "~/components/intelligence/page-tabs.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import type { LocationsFilterType } from "~/services/location.service.server";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { canDoSomeOnLocation } from "~/utils/location-permission.utils";
import { CanDo } from "~/components/intelligence/can-do.component";

type Region = { region: string | undefined | null };
type Owner = { owner_name: string | undefined | null };

type JsonData = {
  fields?: Record<string, string | null> | null;
  success?: boolean;
  errors?: Record<string, string[] | null>;
  error?: string | null;
  vendor?: Vendor | null;
  data?: Record<string, string | null> | null;
  vendors?: Vendor[] | null;
  regions?:
    | {
        region: string;
      }[]
    | null;
  location?: Location | null;
};

const LocationDataForm = z.object({
  name: z.string().min(1, "Name is required"),
  unit_count: z.number().int().min(1, "Unit count is required"),
  class: z.nativeEnum(LocationClass),
  property_stage: z.nativeEnum(LocationPropertyStage).optional().nullable(),
  property_type: z.nativeEnum(LocationPropertyType),
  owner_name: z.string(),
  pms_id: z.string(),
  street_1: z.string().min(1, "Street 1 is required"),
  street_2: z.string(),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State is required"),
  country: z
    .nativeEnum(LocationCountry)
    .or(z.literal("null"))
    .transform(v => (v === "null" ? null : v)),
  zip: z.string().min(1, "Zip code name is required"),
  region: z
    .string()
    .min(1, "Region is required")
    .or(z.literal(""))
    .transform(r => (!isEmpty(r) ? r : null)),
});

const SearchRegionForm = z.object({
  term: NonEmptyString,
});
export const createAction = async ({
  form,
  managerAccountId,
}: {
  form: FormData;
  managerAccountId: string;
}) => {
  const unitCount = form.get("unit_count") as string;
  const fields = {
    name: form.get("name"),
    unit_count: parseInt(unitCount),
    class: form.get("class"),
    property_stage: form.get("property_stage"),
    property_type: form.get("property_type"),
    owner_name: form.get("owner_name"),
    pms_id: form.get("pms_id"),
    street_1: form.get("street_1"),
    street_2: form.get("street_2"),
    city: form.get("city"),
    state: form.get("state"),
    country: form.get("country"),
    zip: form.get("zip"),
    region: form.get("region"),
  };

  const validation = LocationDataForm.safeParse(fields);

  if (validation.success) {
    const { locationService } = await WebDIContainer();
    const createdLocation = await locationService.createLocation({
      ...validation.data,
      manager_account: { connect: { id: managerAccountId } },
    });

    return jsonWithSuccess(
      {
        success: true,
        fields: castFormFields(fields),
        location: createdLocation,
        errors: issuesByKey([]),
      },
      "Location created successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return jsonWithError(
    { success: false, fields, errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
};

async function uploadLocations({
  data,
  managerAccountId,
}: {
  data: any;
  managerAccountId: string;
}) {
  const { locationService } = await WebDIContainer();

  const stringOrNull = (value: any) => (!isEmpty(value) ? value : null);

  const parsePropertyClass = (value: any) => {
    switch (value) {
      case "A+":
        return LocationClass.APlus;
      case "A":
        return LocationClass.A;
      case "B":
        return LocationClass.B;
      case "C":
        return LocationClass.C;
      case "D":
        return LocationClass.D;
      default:
        return stringOrNull(value);
    }
  };

  const parsePropertyType = (value: any) => {
    switch (value) {
      case "Conventional Multifamily":
        return LocationPropertyType.ConventionalMultifamily;
      case "Affordable":
        return LocationPropertyType.Affordable;
      case "Student":
        return LocationPropertyType.Student;
      case "Senior":
        return LocationPropertyType.Senior;
      case "Self Storage":
        return LocationPropertyType.SelfStorage;
      case "Office/Commercial":
        return LocationPropertyType.OfficeCommercial;
      case "Build-to-Rent":
        return LocationPropertyType.BuildToRent;
      case "Single Family":
        return LocationPropertyType.SingleFamily;
      case "Other":
        return LocationPropertyType.Other;
      default:
        return stringOrNull(value);
    }
  };

  const parsePropertyStage = (value: any) => {
    switch (value) {
      case "Lease-Up":
        return LocationPropertyStage.LeaseUp;
      case "Stabilized":
        return LocationPropertyStage.Stabilized;
      case "Renovation":
        return LocationPropertyStage.Renovation;
      case "Other":
        return LocationPropertyStage.Other;
      default:
        return stringOrNull(value);
    }
  };

  // First row can be headers explaining cell types, so we filter that row out
  const clearedRows = data.filter(
    (item: any) => !(item["Name"] === "Text" && item["Unit Count"] === "Number")
  );

  if (clearedRows.length === 0) {
    return jsonWithError(
      {
        success: false,
      },
      "No data to insert, make sure your CSV has data in it",
      { status: 400 }
    );
  }

  try {
    const locationsToInsert = clearedRows.map((item: any) => {
      // stringOrNull function used to avoid empty strings being inserted into the database
      return {
        name: stringOrNull(item["Name"]),
        unit_count: parseInt(item["Unit Count"]),
        class: parsePropertyClass(item["Property Class"]),
        property_type: parsePropertyType(item["Property Type"]),
        property_stage: parsePropertyStage(item["Property Stage"]),
        owner_name: stringOrNull(item["Owner Name"]),
        pms_id: stringOrNull(item["PMS Id"]),
        street_1: stringOrNull(item["Street 1"]),
        street_2: stringOrNull(item["Street 2"]),
        city: stringOrNull(item["City"]),
        state: stringOrNull(item["State"]),
        country: stringOrNull(item["Country"]),
        zip: stringOrNull(item["ZIP"]),
        region: stringOrNull(item["Region"]),
        manager_account_id: managerAccountId,
      };
    });

    await locationService.createLocations(locationsToInsert);

    return jsonWithSuccess(
      { success: true, data: locationsToInsert },
      "Locations inserted successfully"
    );
  } catch {
    return jsonWithError(
      {
        success: false,
      },
      "Failed to insert locations, please make sure your headers and rows are correct",
      { status: 500 }
    );
  }
}

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocations],
    }
  );
  const managerAccountId = account.id;

  const { locationService } = await WebDIContainer();

  const form = await request.formData();
  const intent = form.get("intent");

  // Handle Upload locations
  if (intent === "uploadCSV") {
    const file = form.get("formData");
    const formData = file?.toString() || "";
    const jsonData = JSON.parse(formData);
    return uploadLocations({ data: jsonData, managerAccountId });
  }
  if (intent === "searchRegion") {
    const fields = {
      term: form.get("term"),
    };
    const validation = SearchRegionForm.safeParse(fields);

    if (validation.success) {
      const regions = await locationService.getLocationsRegions(
        managerAccountId,
        validation.data.term
      );
      return json<JsonData>({
        success: true,
        fields: castFormFields(fields),
        regions,
      });
    }
    return json<JsonData>({
      success: false,
      vendor: null,
      vendors: null,
      errors: issuesByKey(validation.error.issues),
    });
  }
  // Handle New location
  return createAction({ form, managerAccountId });
};

export async function loader({ request, params }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewLocationsTable],
    }
  );
  const managerAccountId = account.id;

  const { locationService } = await WebDIContainer();

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const searchTerm = search.get("query");
  const unitCountParam = search.get("unit_count")?.split(",") ?? [];
  const propertyClassParam = search.get("property_class")?.split(",") ?? [];
  const propertyTypeParam = search.get("property_type")?.split(",") ?? [];
  const propertyStageParam = search.get("property_stage")?.split(",") ?? [];
  const regionParam = search.get("region")?.split(",") ?? [];
  const ownerParam = search.get("owner")?.split(",") ?? [];

  const page = parseInt(search.get("page") || "1");
  const perPage = parseInt(search.get("perPage") || "50");

  const status = search.get("status") ?? "active";

  const offset = (page - 1) * perPage;

  const locationsFilters: LocationsFilterType = {
    query: searchTerm ?? undefined,
    unitCount: unitCountParam,
    propertyClass: propertyClassParam as LocationClass[],
    propertyType: propertyTypeParam as LocationPropertyType[],
    propertyStage: propertyStageParam as LocationPropertyStage[],
    region: regionParam,
    owner: ownerParam,
    status:
      status === "active"
        ? [LocationStatus.Active, LocationStatus.Pending]
        : [LocationStatus.Disposed],
  };

  const locations = await locationService.getLocations(
    user,
    account,
    locationsFilters,
    offset,
    perPage,
  );

  const locationsCount = await locationService.getLocationsCount(
    user,
    account,
    locationsFilters,
  );

  const regions = await locationService.getLocationsRegions(managerAccountId);

  const owners = await locationService.getLocationsOwners(managerAccountId);

  return json({
    user,
    account,
    locations,
    regions,
    owners,
    locationsCount,
    unitCountParam,
    propertyClassParam,
    propertyTypeParam,
    propertyStageParam,
    searchTerm,
    regionParam,
    ownerParam,
    page,
    status,
  });
}

export default function Locations() {
  const navigate = useNavigate();
  const actionData = useActionData<typeof action>();
  const {
    user,
    account,
    locations,
    regions,
    owners,
    locationsCount,
    unitCountParam,
    propertyClassParam,
    propertyTypeParam,
    propertyStageParam,
    searchTerm,
    regionParam,
    ownerParam,
    page,
    status,
  } = useLoaderData<typeof loader>();
  const baseUrl = `/intelligence/${account.id}/locations/`;
  const [uploadCSVLocations, setUploadCSVLocations] = useState(false);
  const [addManualLocations, setAddManualLocations] = useState(false);
  const [openFilteringModal, setOpenFilteringModal] = useState(false);
  const [filterByPropertyClass, setFilterByPropertyClass] = useState<string[]>(
    []
  );
  const [filterByPropertyType, setFilterByPropertyType] = useState<string[]>(
    []
  );
  const [filterByPropertyStage, setFilterByPropertyStage] = useState<string[]>(
    []
  );
  const [filterByRegion, setFilterByRegion] = useState<string[]>([]);
  const [filterByOwnerName, setFilterByOwnerName] = useState<string[]>([]);
  const [selectedRegions, setSelectedRegions] = useState<Region[]>([]);
  const [selectedOwners, setSelectedOwners] = useState<Owner[]>([]);

  const [autocompleteValue, setAutocompleteValue] = useState<string>("");
  const [autocompleteOwnerName, setAutocompleteOwnerName] =
    useState<string>("");
  const [regionErrorMessage, setRegionErrorMessage] = useState<string>("");
  const [ownerErrorMessage, setOwnerErrorMessage] = useState<string>("");

  const [currentPage, setCurrentPage] = useState(page ?? 1);
  const perPage = 50; // [perPage, setPerPage] = useState(50);

  const unitCountFilter = [
    { value: "1-50", name: "1-50" },
    { value: "50-100", name: "50-100" },
    { value: "100-200", name: "100-200" },
    { value: "200-500", name: "200-500" },
    { value: "500", name: "500+" },
  ];
  const [filterByUnitCount, setFilterByUnitCount] = useState<string[]>([]);

  useEffect(() => {
    if (actionData?.success) {
      setUploadCSVLocations(false);
      setAddManualLocations(false);
    }
  }, [actionData]);

  const propertyClassFilter = [
    { name: "A+", value: LocationClass.APlus },
    { name: LocationClass.A, value: LocationClass.A },
    { name: LocationClass.B, value: LocationClass.B },
    { name: LocationClass.C, value: LocationClass.C },
    { name: LocationClass.D, value: LocationClass.D },
  ];

  const propertyStageFilter = [
    { name: "Lease-Up", value: LocationPropertyStage.LeaseUp },
    {
      name: LocationPropertyStage.Renovation,
      value: LocationPropertyStage.Renovation,
    },
    {
      name: LocationPropertyStage.Stabilized,
      value: LocationPropertyStage.Stabilized,
    },
    { name: LocationPropertyStage.Other, value: LocationPropertyStage.Other },
  ];

  const propertyTypeFilter = [
    {
      name: "Conventional Multifamily",
      value: LocationPropertyType.ConventionalMultifamily,
    },
    {
      name: LocationPropertyType.Affordable,
      value: LocationPropertyType.Affordable,
    },
    {
      name: LocationPropertyType.Student,
      value: LocationPropertyType.Student,
    },
    { name: LocationPropertyType.Senior, value: LocationPropertyType.Senior },
    { name: "Self Storage", value: LocationPropertyType.SelfStorage },
    {
      name: "Office/Commercial",
      value: LocationPropertyType.OfficeCommercial,
    },
    { name: "Build-to-Rent", value: LocationPropertyType.BuildToRent },
    { name: "Single Family", value: LocationPropertyType.SingleFamily },
    { name: LocationPropertyType.Other, value: LocationPropertyType.Other },
  ];

  const handleAddButton = () => {
    setAddManualLocations(true);
  };

  function constructNewURL(
    baseUrl: string,
    searchQuery: string,
    filterByUnitCount: string[],
    filterByPropertyClass: string[],
    filterByPropertyType: string[],
    filterByPropertyStage: string[],
    filterByRegion: string[],
    filterByOwnerName: string[],
    newPage: number,
    perPage: number,
    newStatus?: string
  ): string {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchQuery);

    if ((newStatus ?? status) === "active") {
      searchParams.delete("status");
    } else {
      searchParams.append("status", newStatus ?? status ?? "archived");
    }

    if (filterByUnitCount.length > 0) {
      searchParams.append("unit_count", filterByUnitCount.join(","));
    }
    if (filterByPropertyClass.length > 0) {
      searchParams.append("property_class", filterByPropertyClass.join(","));
    }
    if (filterByPropertyType.length > 0) {
      searchParams.append("property_type", filterByPropertyType.join(","));
    }
    if (filterByPropertyStage.length > 0) {
      searchParams.append("property_stage", filterByPropertyStage.join(","));
    }
    if (filterByRegion.length > 0) {
      searchParams.append("region", filterByRegion.join(","));
    }

    if (filterByOwnerName.length > 0) {
      searchParams.append("owner", filterByOwnerName.join(","));
    }
    searchParams.append("page", newPage.toString());
    searchParams.append("perPage", perPage.toString());

    return `${baseUrl}?${searchParams.toString()}`;
  }

  // Handle filtering, name searching and pagination
  const handleFiltering = (newPage?: number, newSearchQuery?: string) => {
    const newURL = constructNewURL(
      baseUrl,
      newSearchQuery ?? searchTerm ?? "",
      filterByUnitCount,
      filterByPropertyClass,
      filterByPropertyType,
      filterByPropertyStage,
      filterByRegion,
      filterByOwnerName,
      newPage ? newPage : currentPage,
      perPage
    );
    setOpenFilteringModal(false);
    navigate(newURL);
  };

  const clearFilters = () => {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchTerm ?? "");

    setFilterByPropertyClass([]);
    setFilterByPropertyType([]);
    setFilterByPropertyStage([]);
    setFilterByUnitCount([]);
    setFilterByRegion([]);
    setFilterByOwnerName([]);
    setSelectedRegions([]);
    setSelectedOwners([]);

    searchParams.delete("unit_count");
    searchParams.delete("property_class");
    searchParams.delete("property_type");
    searchParams.delete("property_stage");
    searchParams.delete("region");
    searchParams.delete("owner");

    const newURL = `${baseUrl}?${searchParams.toString()}`;

    setOpenFilteringModal(false);
    navigate(newURL);
  };

  useEffect(() => {
    if (unitCountParam.length > 0) {
      setFilterByUnitCount(unitCountParam);
    }

    if (propertyClassParam.length > 0) {
      setFilterByPropertyClass(propertyClassParam);
    }

    if (propertyTypeParam.length > 0) {
      setFilterByPropertyType(propertyTypeParam);
    }

    if (propertyStageParam.length > 0) {
      setFilterByPropertyStage(propertyStageParam);
    }

    if (regionParam.length > 0) {
      setFilterByRegion(regionParam);

      const initialSelectedRegions = regions
        .filter(region => regionParam.includes(region?.region || ""))
        .filter(Boolean);

      setSelectedRegions(initialSelectedRegions);
    }

    if (ownerParam.length > 0) {
      setFilterByOwnerName(ownerParam);

      const initialSelectedOwners = owners
        .filter(owner => ownerParam.includes(owner?.owner_name || ""))
        .filter(Boolean);

      setSelectedOwners(initialSelectedOwners);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handlePageChange = (newPage: number) => {
    const newURL = constructNewURL(
      baseUrl,
      searchTerm ?? "",
      filterByUnitCount,
      filterByPropertyClass,
      filterByPropertyType,
      filterByPropertyStage,
      filterByRegion,
      filterByOwnerName,
      newPage,
      perPage
    );
    navigate(newURL);
    setCurrentPage(newPage);
  };

  const handleAddRegion = (region: Region) => {
    if (region.region && !filterByRegion.includes(region.region)) {
      setSelectedRegions([...selectedRegions, region]);

      setFilterByRegion([...filterByRegion, region.region || ""]);
      setAutocompleteValue("");
    } else {
      setRegionErrorMessage("Filter is already selected");
    }
  };

  const handleAddOwnerName = (owner: Owner) => {
    if (owner.owner_name && !filterByOwnerName.includes(owner.owner_name)) {
      setSelectedOwners([...selectedOwners, owner]);
      setFilterByOwnerName([...filterByOwnerName, owner.owner_name || ""]);
      setAutocompleteOwnerName("");
    } else {
      setOwnerErrorMessage("Filter is already selected");
    }
  };

  const handleRemoveRegion = (region: Region) => {
    const updatedVendors = selectedRegions.filter(
      selectedRegion => selectedRegion.region !== region.region
    );
    setSelectedRegions(updatedVendors);
    setFilterByRegion(filterByRegion.filter(r => r !== region.region));
    setRegionErrorMessage("");
  };
  const handleRemoveOwner = (owner: Owner) => {
    const updatedOwners = selectedOwners.filter(
      selectedOwner => selectedOwner.owner_name !== owner.owner_name
    );
    setSelectedOwners(updatedOwners);
    setFilterByOwnerName(filterByOwnerName.filter(o => o !== owner.owner_name));
    setOwnerErrorMessage("");
  };

  const filteredRegions = regions.filter(region =>
    region?.region.toLowerCase().includes(autocompleteValue.toLowerCase())
  );

  const filteredOwners = owners.filter(owner =>
    owner?.owner_name
      ?.toLowerCase()
      .includes(autocompleteOwnerName.toLowerCase())
  );

  const totalPages = Math.ceil(locationsCount / perPage);
  const pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);
  const resultsText = `${locations.length} out of ${locationsCount} results`;

  const renderRegion = (option: Region) => {
    return option.region;
  };

  const renderOwner = (option: Owner) => {
    return option.owner_name;
  };

  // Permissions
  const userCanManageLocations = canDoOnAccount(
    user,
    account,
    Permission.ManageLocations
  );

  return (
    <>
      <Modal
        isOpen={uploadCSVLocations}
        onClose={() => setUploadCSVLocations(false)}
        size="medium"
        manager={true}
      >
        <UploadCSVForm
          actionUrl={`/intelligence/${account.id}/locations`}
          template="/assets/location-csv-example.csv"
          requiredHeaders="Name, Unit Count, Property
					Class, Property Type, Street 1, City, State, ZIP"
          optionalHeaders="Property Stage, Owner Name, PMS Id, Street 2, Country, Region"
        ></UploadCSVForm>
      </Modal>
      <Modal
        isOpen={addManualLocations}
        onClose={() => setAddManualLocations(false)}
        size="medium"
        manager={true}
      >
        <LocationForm
          actionData={actionData}
          account_id={account.id}
          regionOptions={regions}
          ownerOptions={owners.map(owner => owner.owner_name)}
        ></LocationForm>
      </Modal>
      <Modal
        isOpen={openFilteringModal}
        onClose={() => setOpenFilteringModal(false)}
        size="medium"
        manager={true}
      >
        <div className="p-2 lg:p-6">
          <h4 className="font-bold">Filter By</h4>
          <div className="divide divide-y divide-2 ">
            <div>
              <div className="my-4 font-semibold">Unit Count</div>
              <div className="flex justify-around">
                {unitCountFilter.map((option, index) => (
                  <CrudCheckboxField
                    key={index}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: filterByUnitCount.includes(option.value),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterByUnitCount([
                          ...filterByUnitCount,
                          option.value,
                        ]);
                      } else {
                        setFilterByUnitCount(
                          filterByUnitCount.filter(i => i !== option.value)
                        );
                      }
                    }}
                  />
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Property Class</div>
              <div className="flex justify-around">
                {propertyClassFilter.map((option, index) => (
                  <CrudCheckboxField
                    key={index}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: filterByPropertyClass.includes(
                        option.value
                      ),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterByPropertyClass([
                          ...filterByPropertyClass,
                          option.value,
                        ]);
                      } else {
                        setFilterByPropertyClass(
                          filterByPropertyClass.filter(i => i !== option.value)
                        );
                      }
                    }}
                  />
                ))}
              </div>
            </div>

            <div>
              <div className="my-4 font-semibold">Regions</div>
              <AutocompleteFilter
                initialValue={autocompleteValue}
                options={filteredRegions}
                onFilterChange={setAutocompleteValue}
                onAddTag={handleAddRegion}
                onRemoveTag={handleRemoveRegion}
                selectedTags={selectedRegions}
                errorMessage={regionErrorMessage}
                renderOption={renderRegion}
              />
            </div>
            <div>
              <div className="my-4 font-semibold">Property Type</div>
              <div className="grid grid-cols-3">
                {propertyTypeFilter.map((option, index) => (
                  <div key={index}>
                    <CrudCheckboxField
                      key={index}
                      field={{
                        name: "filter_by",
                        value: option.value,
                        label: option.name,
                        errors: [],
                        description: "",
                        defaultChecked: filterByPropertyType.includes(
                          option.value
                        ),
                        type: "checkbox",
                      }}
                      onChange={evt => {
                        const checked = evt.target.checked;
                        if (checked) {
                          setFilterByPropertyType([
                            ...filterByPropertyType,
                            option.value,
                          ]);
                        } else {
                          setFilterByPropertyType(
                            filterByPropertyType.filter(i => i !== option.value)
                          );
                        }
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Property Stage</div>
              <div className="grid grid-cols-3">
                {propertyStageFilter.map((option, index) => (
                  <div key={index}>
                    <CrudCheckboxField
                      key={index}
                      field={{
                        name: "filter_by",
                        value: option.value,
                        label: option.name,
                        errors: [],
                        description: "",
                        defaultChecked: filterByPropertyStage.includes(
                          option.value
                        ),
                        type: "checkbox",
                      }}
                      onChange={evt => {
                        const checked = evt.target.checked;
                        if (checked) {
                          setFilterByPropertyStage([
                            ...filterByPropertyStage,
                            option.value,
                          ]);
                        } else {
                          setFilterByPropertyStage(
                            filterByPropertyStage.filter(
                              i => i !== option?.value
                            )
                          );
                        }
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Owner Name</div>
              <AutocompleteFilter
                initialValue={autocompleteOwnerName}
                options={filteredOwners}
                onFilterChange={setAutocompleteOwnerName}
                onAddTag={handleAddOwnerName}
                onRemoveTag={handleRemoveOwner}
                selectedTags={selectedOwners}
                errorMessage={ownerErrorMessage}
                renderOption={renderOwner}
              />
            </div>
          </div>
          <div className="flex justify-end mt-8 items-center space-x-3">
            <button
              className="text-sky-500"
              onClick={() => {
                setCurrentPage(1);
                clearFilters();
              }}
            >
              Clear filters
            </button>
            <CTA
              variant="coral-shadow"
              onClick={() => {
                handleFiltering(1);
              }}
            >
              Show results
            </CTA>
          </div>
        </div>
      </Modal>
      <div className="mb-8">
        <PageTabs
          validationType="urlParams"
          options={[
            {
              currentParam: status,
              expectedResult: "active",
              navigateTo: constructNewURL(
                baseUrl,
                searchTerm ?? "",
                filterByUnitCount,
                filterByPropertyClass,
                filterByPropertyType,
                filterByPropertyStage,
                filterByRegion,
                filterByOwnerName,
                1,
                perPage,
                "active"
              ),
              label: "Active Locations",
            },
            {
              currentParam: status,
              expectedResult: "archived",
              navigateTo: constructNewURL(
                baseUrl,
                searchTerm ?? "",
                filterByUnitCount,
                filterByPropertyClass,
                filterByPropertyType,
                filterByPropertyStage,
                filterByRegion,
                filterByOwnerName,
                1,
                perPage,
                "archived"
              ),
              label: "Archived Locations",
            },
          ]}
          columns={2}
        />
      </div>
      <div className="space-y-8 pb-12">
        <IntelligenceScreenHeader
          title={`All ${status} locations`}
          description={
            status === "archived" ? (
              "View and manage your archived locations."
            ) : (
              <>
                View and manage your active locations.{" "}
                <CanDo permission={Permission.ManageLocations}>
                  To add a location, click "Add Location." To bulk upload
                  multiple locations, click "Upload Locations" and download an
                  example CSV file.
                </CanDo>
              </>
            )
          }
          buttonsSlot={
            status === "active" && (
              <CanDo permission={Permission.ManageLocations}>
                <div className="space-x-4 flex">
                  <div>
                    <CTA
                      type="button"
                      onClick={() => setUploadCSVLocations(true)}
                      fillStyle="outline"
                      className="text-sm md:text-base w-fit"
                    >
                      Upload Locations
                    </CTA>
                  </div>
                  <div id="add-location-button">
                    <CTA
                      type="button"
                      onClick={() => setAddManualLocations(true)}
                      variant="coral-shadow"
                      className="text-sm md:text-base w-fit"
                    >
                      Add Location
                    </CTA>
                  </div>
                </div>
              </CanDo>
            )
          }
        />
        <FilterBar
          inputPlaceholder="Search locations"
          defaultSearchQuery={searchTerm ?? ""}
          onFilter={searchQuery => {
            handleFiltering(1, searchQuery);
          }}
          filters={{
            onOpenFilteringModal: setOpenFilteringModal,
            filtersCount:
              filterByUnitCount.length +
              filterByPropertyClass.length +
              filterByRegion.length +
              filterByPropertyType.length +
              filterByPropertyStage.length +
              filterByOwnerName.length,
          }}
        />
        <div>
          <Table
            cols={[
              { name: "name", label: "Location Name" },
              {
                renderer: location => (
                  <div className="flex items-center space-x-2">
                    <div className="whitespace-normal line-clamp-3 truncate font-light">
                      {[location.city, location.state]
                        .filter(Boolean)
                        .join(", ")}
                    </div>
                  </div>
                ),
                label: "Address",
              },
              {
                renderer: location => (
                  <div className="font-light">{location.region ?? "--"}</div>
                ),
                label: "Region",
              },
              {
                renderer: location => (
                  <div className="font-light">{location.unit_count}</div>
                ),
                label: "Unit Count",
              },
              {
                renderer: location => (
                  <div className="font-light">{location.class}</div>
                ),
                label: "Property Class",
              },
              {
                renderer: location => (
                  <div className="flex items-center space-x-2">
                    <div className="whitespace-normal line-clamp-3 truncate font-light">
                      {(() => {
                        switch (location.property_type) {
                          case LocationPropertyType.ConventionalMultifamily:
                            return "Conventional Multifamily";
                          case LocationPropertyType.SelfStorage:
                            return "Self Storage";
                          case LocationPropertyType.OfficeCommercial:
                            return "Office/Commercial";
                          case LocationPropertyType.BuildToRent:
                            return "Build-to-Rent";
                          case LocationPropertyType.SingleFamily:
                            return "Single Family";
                          default:
                            return location.property_type;
                        }
                      })()}
                    </div>
                  </div>
                ),
                label: "Property Type",
              },
              {
                renderer: location => (
                  <div className="font-light">{location.owner_name}</div>
                ),
                label: "Owner Name",
              },
              {
                label: "Status",
                name: "status",
                renderer: location => (
                  <StatusChip
                    model="LocationStatus"
                    status={location.status}
                    label={location.status}
                  />
                ),
              },
            ]}
            data={locations}
            addButtonLabel="add location"
            showAddButton={userCanManageLocations}
            handleCallback={handleAddButton}
            showSelectBox={false}
            onClickRow={location =>
              canDoSomeOnLocation(user, account, location, [
                Permission.ViewLocationDetails,
                Permission.ViewLocationVendorsAndProducts,
              ]) &&
              navigate(
                `/intelligence/${account.id}/locations/${location.id}/details`
              )
            }
          ></Table>
          <Pagination
            resultsText={resultsText}
            pageNumbers={pageNumbers}
            currentPage={currentPage}
            totalPages={totalPages}
            handleCallback={handlePageChange}
          ></Pagination>
        </div>
      </div>
    </>
  );
}
