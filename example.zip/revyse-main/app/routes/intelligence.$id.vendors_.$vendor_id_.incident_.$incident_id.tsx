import { useActionData, useLoaderData, useNavigation } from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { Permission } from "~/utils/intelligence-permission.utils";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  type ManagerAccount,
  ManagerAccountVendorIncidentImpact,
  ManagerAccountVendorIncidentStatus,
} from "@prisma/client";
import { useEffect } from "react";
import { jsonWithError, redirectWithSuccess } from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { castFormFields } from "~/utils/type.utils";
import { IncidentForm } from "~/components/intelligence/vendors/incident-form.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const UpdateIncidentForm = z
  .object({
    name: z.string().min(1, "Incident name is required"),
    status: z.nativeEnum(ManagerAccountVendorIncidentStatus),
    created_date: z.preprocess(
      val => (val === "" ? null : dayjs.utc(val as string).toDate()),
      z.date()
    ),
    resolved_date: z.preprocess(
      val => (val === "" ? null : dayjs.utc(val as string).toDate()),
      z.date().nullable()
    ),
    nature_scope_timing: z.string().optional(),
    impact: z.nativeEnum(ManagerAccountVendorIncidentImpact).optional(),
    description: z.string().optional(),
    next_steps: z.string().optional(),
    response_team: z.string().optional(),
  })
  .superRefine((values, ctx) => {
    const resolvedDate = values.resolved_date;
    const createdDate = values.created_date;

    if (resolvedDate && createdDate && resolvedDate < createdDate) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Resolved date cannot be before created date",
        path: ["resolved_date"],
      });
    }
  });

async function deleteIncident({
  id,
  accountVendorId,
  account,
}: {
  id: string | undefined;
  accountVendorId: string;
  account: ManagerAccount;
}) {
  const { managerAccountVendorIncidentService } = await WebDIContainer();
  await managerAccountVendorIncidentService.deleteIncident(id);
  return redirectWithSuccess(
    `/intelligence/${account.id}/vendors/${accountVendorId}`,
    "Incident deleted successfully"
  );
}

async function updateIncident({
  form,
  id,
  accountVendorId,
  request,
  account,
}: {
  form: FormData;
  id: string;
  accountVendorId: string;
  request: Request;
  account: ManagerAccount;
}) {
  const { managerAccountVendorIncidentService } = await WebDIContainer();

  const fields = {
    name: form.get("name"),
    status: form.get("status"),
    created_date: form.get("created_date"),
    resolved_date: form.get("resolved_date"),
    nature_scope_timing: form.get("nature_scope_timing"),
    impact: form.get("impact"),
    description: form.get("description"),
    next_steps: form.get("next_steps"),
    response_team: form.get("response_team"),
  };

  const validation = UpdateIncidentForm.safeParse(fields);

  if (validation.success) {
    await managerAccountVendorIncidentService.handleIncident(
      id,
      accountVendorId,
      validation.data
    );
    return redirectWithSuccess(
      `/intelligence/${account.id}/vendors/${accountVendorId}`,
      `Incident ${id === "new" ? "created" : "updated"} successfully`
    );
  }
  return jsonWithError(
    {
      success: false,
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
}

export async function action({ params, request }: ActionFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );
  const id = params.vendor_id as string;
  const incidentId = params.incident_id as string;

  const { managerAccountVendorService } = await WebDIContainer();

  const accountVendor =
    await managerAccountVendorService.getManagerAccountVendor(id, {
      manager_account: true,
    });

  if (!accountVendor) {
    throw new Response("Not found", { status: 404 });
  }

  const form = await request.formData();
  const intent = form.get("intent");

  if (intent == "deleteIncident") {
    return deleteIncident({
      id: incidentId,
      accountVendorId: accountVendor.id,
      account: accountVendor.manager_account,
    });
  } else {
    return updateIncident({
      form,
      id: incidentId,
      accountVendorId: accountVendor.id,
      request,
      account: accountVendor.manager_account,
    });
  }
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );

  const { managerAccountVendorIncidentService, managerAccountVendorService } =
    await WebDIContainer();
  const id = params.vendor_id!;
  const incidentId = params.incident_id;

  const accountVendor =
    await managerAccountVendorService.getManagerAccountVendor(id, {
      manager_account: true,
      vendor: true,
    });

  if (!accountVendor) {
    throw new Response("Not found", { status: 404 });
  }

  const incident =
    incidentId === "new"
      ? ({
          id: "new",
          name: "",
          status: ManagerAccountVendorIncidentStatus.New,
          created_date: new Date(),
          resolved_date: null,
          nature_scope_timing: null,
          impact: ManagerAccountVendorIncidentImpact.NotSet,
          description: null,
          next_steps: null,
          response_team: null,
          manager_account_vendor_id: accountVendor.id,
          manager_account_vendor: accountVendor,
          created_at: new Date(),
          updated_at: new Date(),
        } as Awaited<
          ReturnType<typeof managerAccountVendorIncidentService.loadIncident>
        >)
      : await managerAccountVendorIncidentService.loadIncident(incidentId);

  if (!incident) {
    throw new Response("Not found", { status: 404 });
  }

  return json({
    accountVendor,
    incident,
  });
}

export default function VendorNewIncident() {
  const actionData = useActionData<typeof action>();
  const { accountVendor, incident } = useLoaderData<typeof loader>();
  const navigation = useNavigation();

  useEffect(() => {
    if (navigation.state == "idle") {
      window.scrollTo(0, 0);
    }
  }, [navigation.state]);

  return (
    <div className="space-y-8 pb-12">
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "Vendors",
            to: `/intelligence/${accountVendor.manager_account_id}/vendors`,
          },
          {
            name: accountVendor.vendor.name,
            to: `/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}`,
          },
          {
            name: incident.id !== "new" ? incident.name : "Log new incident",
            to: `/intelligence/${accountVendor.manager_account_id}/contract/${accountVendor.id}/incident/`,
            active: true,
          },
        ]}
        title={incident.id !== "new" ? "Edit incident" : "Log new incident"}
        description={
          <>
            Record and track incidents involving {accountVendor.vendor.name},
            including the nature and timing of the incident, the systems or
            resources involved, and who was responsible for assessing the
            impact.
          </>
        }
      />
      <IncidentForm
        incident={incident}
        actionData={actionData}
        accountVendor={accountVendor}
      ></IncidentForm>
    </div>
  );
}
