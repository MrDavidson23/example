import { type ActionFunctionArgs } from "@remix-run/node";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { Permission } from "~/utils/intelligence-permission.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

export async function action({ request, params }: ActionFunctionArgs) {
  const { user } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.UseAIAssist],
    }
  );
  const { db, contractExtractionService } = await WebDIContainer();

  const contract = await db.contract.findFirstOrThrow({
    where: { id: params.contract_id },
    include: {
      document_files: { where: { file: { indexed_at: { not: null } } } },
    },
  });

  if (contract.document_files.length === 0) {
    return jsonWithError({}, "No indexed documents found for this contract");
  }

  // TODO: need to extract this to a worker at some point.
  contractExtractionService.extractInfoFromContract({
    contract_id: contract.id,
    user_id: user.id,
  });

  return jsonWithSuccess({}, "Contract extraction started");
}
