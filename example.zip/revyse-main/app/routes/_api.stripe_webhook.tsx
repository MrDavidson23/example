import type { ActionFunctionArgs } from "@remix-run/node";
import Stripe from "stripe";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { getEnv } from "~/services/env.service.server";

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const payload = await request.text();
  const sig = request.headers.get("stripe-signature");
  if (!sig) {
    console.log("Stripe webhook missing stripe-signature header");
    return new Response(`Bad Request`, { status: 400 });
  }

  try {
    const stripe = new Stripe(getEnv().STRIPE_SECRET_KEY, {
      apiVersion: "2022-11-15",
    });
    const event = stripe.webhooks.constructEvent(
      payload,
      sig,
      getEnv().STRIPE_WEBHOOK_SECRET
    );

    const { productSubscriptionService, stripeService } =
      await WebDIContainer();
    console.log("Stripe webhook event", event.type);
    console.log("Event", JSON.stringify(event.data.object, null, 2));

    switch (event.type) {
      case "checkout.session.completed": {
        await productSubscriptionService.createProductAndSubscription(
          event.data.object as Stripe.Checkout.Session,
          stripe
        );
        break;
      }
      // case "checkout.session.expired": {
      //   const checkoutSessionExpired = event.data.object;
      //   // Then define and call a function to handle the event checkout.session.expired
      //   break;
      // }
      case "customer.subscription.deleted": {
        const subscription = event.data.object as Stripe.Subscription & {
          plan: { id: string };
        };
        await productSubscriptionService.updateSubscription(subscription, true);
        break;
      }
      case "customer.subscription.created": {
        const subscription = event.data.object as Stripe.Subscription;
        await productSubscriptionService.updateSubscription(subscription);
        break;
      }
      case "customer.subscription.updated": {
        const subscription = event.data.object as Stripe.Subscription & {
          plan: { id: string };
        };
        await productSubscriptionService.updateSubscription(subscription, true);
        break;
      }
      // case "customer.subscription.paused":
      //   const customerSubscriptionPaused = event.data.object;
      //   // Then define and call a function to handle the event customer.subscription.paused
      //   break;
      // case "customer.subscription.resumed":
      //   const customerSubscriptionResumed = event.data.object;
      //   // Then define and call a function to handle the event customer.subscription.resumed
      //   break;
      // case "plan.created": {
      //   const planCreated = event.data.object as Stripe.Plan;
      //   console.log("plan created", JSON.stringify(planCreated, null, 2));
      //   await db.stripePlan.upsert({
      //     where: { id: planCreated.id },
      //     create: {
      //       id: planCreated.id,
      //       name: planCreated.nickname || "",
      //       description: "",
      //       price: planCreated.amount || 0,
      //     },
      //     update: {
      //       name: planCreated.nickname || "",
      //       description: "",
      //       price: planCreated.amount || 0,
      //     },
      //   });
      //   // Then define and call a function to handle the event plan.created
      //   break;
      // }
      // case "plan.deleted":
      //   const planDeleted = event.data.object;
      //   // Then define and call a function to handle the event plan.deleted
      //   break;
      // case "plan.updated": {
      //   const planUpdated = event.data.object as Stripe.Plan;
      //   console.log("plan updated", JSON.stringify(planUpdated, null, 2));
      //   await db.stripeProduct.upsert({
      //     where: { id: planUpdated.id },
      //     create: {
      //       id: planUpdated.id,
      //       name: planUpdated.nickname || "",
      //       description: "",
      //     },
      //     update: {
      //       name: planUpdated.nickname || "",
      //       description: "",
      //       price: planUpdated.amount || 0,
      //     },
      //   });
      //   break;
      // }
      case "product.updated": {
        const product = event.data.object as Stripe.Product;
        await stripeService.upsertStripeProduct(product);
        break;
      }
      case "product.created": {
        const product = event.data.object as Stripe.Product;
        await stripeService.upsertStripeProduct(product);
        break;
      }
      case "price.created": {
        const price = event.data.object as Stripe.Price;
        await stripeService.upsertStripePrice(price);
        break;
      }
      case "price.updated": {
        const price = event.data.object as Stripe.Price;
        await stripeService.upsertStripePrice(price);
        break;
      }
      default:
        // Unexpected event type
        console.log(`Unhandled event type ${event.type}.`);
    }
    return new Response("Success", { status: 200 });
  } catch (err: any) {
    console.error(err.message);
    return new Response(`Webhook Error: ${err.message}`, { status: 500 });
  }
};
