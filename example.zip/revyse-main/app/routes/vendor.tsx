/* eslint-disable jsx-a11y/anchor-is-valid */
import { useMemo, useState } from "react";
import { Dialog, Popover } from "@headlessui/react";
import { Bars3Icon, XMarkIcon } from "@heroicons/react/24/outline";
import { Link, Outlet, useLoaderData, useLocation } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { assertAuthenticatedOrRedirect } from "~/utils/auth.utils.server";
import { Avatar } from "~/components/avatar.component";
import { Footer } from "~/components/footer.component";

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const user = await assertAuthenticatedOrRedirect(request);
  return json({ user });
};

export default function VendorRoute() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { user } = useLoaderData<typeof loader>();
  const godModeRole = user?.user_roles.find(r => r.role === "GOD_MODE");
  const location = useLocation();
  const loginLink = useMemo(
    () =>
      `/login?redirectTo=${encodeURIComponent(
        location.pathname + location.search
      )}`,
    [location.pathname, location.search]
  );
  return (
    <div className="flex flex-col min-h-full">
      <header className="bg-white">
        <nav
          className="mx-auto flex max-w-7xl items-center justify-between p-6 lg:px-8"
          aria-label="Global"
        >
          <div className="flex lg:flex-1">
            <Link to="/" className="-m-1.5 p-1.5 flex">
              <span className="sr-only">Revyse</span>
              <img
                className="lg:h-8 h-6 w-auto"
                src="/assets/revyse-logo-color-black.png"
                alt=""
                width="320"
                height="112"
              />
              <span className="text-white bg-coral flex items-center px-1 lg:px-2 font-light text-sm lg:text-lg mx-0 lg:mx-2">
                vendor
              </span>
            </Link>
          </div>
          <div className="flex lg:hidden">
            <button
              type="button"
              className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-gray-700"
              onClick={() => setMobileMenuOpen(true)}
            >
              <span className="sr-only">Open main menu</span>
              <Bars3Icon className="h-6 w-6" aria-hidden="true" />
            </button>
          </div>
          <Popover.Group className="hidden lg:flex lg:gap-x-12">
            <Link
              to="/vendor"
              className="text-sm font-semibold leading-6 text-gray-900"
            >
              Dashboard
            </Link>
            <Link
              to="/vendor/products"
              className="text-sm font-semibold leading-6 text-gray-900"
              id="vendor-products-link"
            >
              Product Listings
            </Link>
            <Link
              to="/vendor/reviews"
              className="text-sm font-semibold leading-6 text-gray-900"
              id="vendor-reviews-link"
            >
              Reviews
            </Link>
            {godModeRole && (
              <Link
                to="/admin"
                className="text-sm font-semibold leading-6 text-coral"
              >
                Admin
              </Link>
            )}
          </Popover.Group>
          <div className="hidden lg:flex lg:flex-1 lg:justify-end lg:items-center text-gray-900">
            {!user ? (
              <>
                <Link
                  to={loginLink}
                  className="text-sm font-semibold leading-6 rounded-2xl border border-coral text-coral px-4 py-1 mr-2"
                >
                  Log In
                </Link>
                <Link
                  to="/sign-up"
                  className="text-sm font-semibold leading-6 rounded-2xl bg-coral text-white px-4 py-1"
                >
                  Sign Up
                </Link>
              </>
            ) : (
              <>
                <Link id="logout-link" to="/logout" className="h-6 mr-1">
                  Logout
                </Link>
                <Link to="/profile">
                  <Avatar
                    first_name={user.first_name!}
                    last_name={user.last_name!}
                    className="h-8 w-8 text-sm"
                  />
                </Link>
              </>
            )}
          </div>
        </nav>
        <Dialog
          as="div"
          className="lg:hidden"
          open={mobileMenuOpen}
          onClose={setMobileMenuOpen}
        >
          <div className="fixed inset-0 z-10" />
          <Dialog.Panel className="fixed inset-y-0 right-0 z-10 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10">
            <div className="flex items-center justify-between">
              <a href="#" className="-m-1.5 p-1.5">
                <span className="sr-only">Your Company</span>
                <img
                  className="h-8 w-auto"
                  src="assets/Revyse-Logo-Black.png"
                  alt=""
                  width="300"
                  height="105"
                />
              </a>
              <button
                type="button"
                className="-m-2.5 rounded-md p-2.5 text-gray-700"
                onClick={() => setMobileMenuOpen(false)}
              >
                <span className="sr-only">Close menu</span>
                <XMarkIcon className="h-6 w-6" aria-hidden="true" />
              </button>
            </div>
            <div className="mt-6 flow-root">
              <div className="-my-6 divide-y divide-gray-500/10">
                <div className="space-y-2 py-6">
                  <Link
                    to="/vendor"
                    className="-mx-3 block rounded-lg py-2 px-3 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                  >
                    Dashboard
                  </Link>
                  <a
                    href="/vendor/products"
                    className="-mx-3 block rounded-lg py-2 px-3 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                  >
                    Product Listings
                  </a>
                  <a
                    href="/vendor/reviews"
                    className="-mx-3 block rounded-lg py-2 px-3 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                    id="vendor-reviews-link"
                  >
                    Reviews
                  </a>
                </div>
                <div className="py-6">
                  {!user ? (
                    <Link
                      to={loginLink}
                      className="-mx-3 block rounded-lg py-2.5 px-3 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                    >
                      Log in
                    </Link>
                  ) : (
                    <Link
                      to="/logout"
                      className="-mx-3 block rounded-lg py-2.5 px-3 text-base font-semibold leading-7 text-gray-900 hover:bg-gray-50"
                    >
                      Log out
                    </Link>
                  )}
                </div>
              </div>
            </div>
          </Dialog.Panel>
        </Dialog>
      </header>
      <div className="flex-grow">
        <Outlet />
      </div>
      <Footer />
    </div>
  );
}
