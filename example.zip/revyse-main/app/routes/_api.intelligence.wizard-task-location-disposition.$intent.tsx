import type { ActionFunctionArgs } from "@remix-run/node";
import { isNil } from "lodash";
import { z } from "zod";
import { WizardTaskLocationDispositionRenewalStep } from "~/components/intelligence/tasks/location-disposition-wizard.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assert, assertAuthorized } from "~/utils/assert.utils.server";
import { issuesByKey } from "~/utils/form.utils.server";
import {
  Permission,
  canDoOnAccountOrThrow,
} from "~/utils/intelligence-permission.utils";
import { getUser } from "~/utils/session.server";

export enum WizardTaskLocationDispositionStatus {
  Disposed = "disposed",
  Pending = "pending",
  Keep = "keep",
}

export const zWizardTaskLocationDispositionStepsForm = {
  [WizardTaskLocationDispositionRenewalStep.PendingDueDate]: z.object({
    due_date: z
      .string()
      .min(1, "Due date is required")
      .regex(/^\d{4}-\d{2}-\d{2}$/, "Due date is required")
      .transform(v => new Date(v)),
  }),
};

const zWizardTaskLocationDispositionForm = z
  .object({
    task_id: z.string(),
    manager_account_id: z.string(),
  })
  .and(
    z.discriminatedUnion("status", [
      // Disposed
      z.object({
        status: z.literal(WizardTaskLocationDispositionStatus.Disposed),
      }),
      // Pending
      z
        .object({
          status: z.literal(WizardTaskLocationDispositionStatus.Pending),
        })
        .merge(
          zWizardTaskLocationDispositionStepsForm[
            WizardTaskLocationDispositionRenewalStep.PendingDueDate
          ]
        ),
      // Canceled
      z.object({
        status: z.literal(WizardTaskLocationDispositionStatus.Keep),
      }),
    ])
  );

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));

  const { intent } = params;

  const form = await request.formData();

  if (intent !== "submit" && intent !== "check-errors") {
    throw new Error("Invalid intent");
  }

  const fields = Object.fromEntries(form.entries());

  const { managerAccountService, db, managerAccountTaskService } =
    await WebDIContainer();
  const managerAccountId = fields.manager_account_id as string;

  const account = await managerAccountService.getManagerAccount(
    managerAccountId
  );
  assert(!isNil(account), "Manager account not found");
  canDoOnAccountOrThrow(user, account, Permission.ManageTasks);

  if (intent === "check-errors") {
    return await handleCheckErrors({ fields });
  }

  const validation = zWizardTaskLocationDispositionForm.safeParse(fields);
  if (!validation.success) {
    return {
      success: false,
      errors: issuesByKey(validation.error.errors),
      fields,
    };
  }

  const { task_id, status } = validation.data;
  const task = await db.taskLocationDisposition.findUniqueOrThrow({
    where: { id: task_id },
  });

  if (status === WizardTaskLocationDispositionStatus.Disposed) {
    await managerAccountTaskService.handleWizardLocationDispositionTaskDisposed(
      {
        task,
      }
    );
  } else if (status === WizardTaskLocationDispositionStatus.Pending) {
    await managerAccountTaskService.handleWizardLocationDispositionTaskPending({
      task,
      fields: validation.data,
    });
  } else if (status === WizardTaskLocationDispositionStatus.Keep) {
    await managerAccountTaskService.handleWizardLocationDispositionTaskKeep({
      task,
    });
  }

  return {
    success: true,
    fields,
  };
};

async function handleCheckErrors({
  fields,
}: {
  fields: Record<string, FormDataEntryValue>;
}) {
  const validation =
    zWizardTaskLocationDispositionStepsForm[
      fields.step_id as keyof typeof zWizardTaskLocationDispositionStepsForm
    ].safeParse(fields);

  if (!validation.success) {
    return {
      success: false,
      errors: issuesByKey(validation.error.errors),
      fields,
    };
  }
  return {
    success: true,
    fields,
  };
}
