import { Card } from "~/components/card.component";

import { useLoaderData, useNavigate, useSearchParams } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { Empty } from "~/components/empty.component";
import { IconCircle } from "~/components/circle-icon.component";
import {
  BriefcaseIcon,
  BuildingOffice2Icon,
  MagnifyingGlassIcon,
  ShoppingBagIcon,
  TruckIcon,
} from "@heroicons/react/24/outline";
import { money } from "~/utils/number.utils";
import type { ResidentLifecyclePhase } from "@prisma/client";
import { OverlapIcon } from "~/components/icons/overlap.icon";
import { Tooltip } from "~/components/tooltip.component";
import PageTabs from "~/components/intelligence/page-tabs.component";
import { Table } from "~/components/intelligence/table.component";
import { Permission } from "~/utils/intelligence-permission.utils";
import StarRating from "~/components/star-rating.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { ProfessionalServicesIcon } from "~/components/icons/professional-services.icon";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

const SpendByEnterpriseCategoryLabels = {
  EnterpriseCorporateTech: "Corporate Tech",
  EnterprisePropertyTech: "Property Tech",
  ProfessionalServices: "Professional Services",
  OnsiteSuppliers: "Onsite Suppliers",
} as const;

const SpendByEnterpriseCategoryDescriptions = {
  EnterpriseCorporateTech:
    "Tools that assist the enterprise in executing corporate-level functions.",
  EnterprisePropertyTech:
    "Tools that assist the enterprise in executing property-level functions.",
  ProfessionalServices:
    "Vendors providing expertise or guidance to the enterprise.",
  OnsiteSuppliers: "Vendors providing goods or services to properties.",
} as const;

const SpendByEnterpriseCategoryIcons = {
  EnterpriseCorporateTech: MagnifyingGlassIcon,
  EnterprisePropertyTech: BuildingOffice2Icon,
  ProfessionalServices: ProfessionalServicesIcon,
  OnsiteSuppliers: TruckIcon,
} as const;

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewSpendByEnterpriseCategory],
    }
  );

  const { managerAccountService } = await WebDIContainer();

  const spend = await managerAccountService.getSpend(user, account, {
    byRLP: true,
  });
  return json({
    productsByResidentPhase:
      await managerAccountService.getProductsByResidentLifecyclePhase(
        user,
        account
      ),
    spendByResidentPhase: spend.byRLP,
    account,
  });
}

export default function SpendByEnterpriseCategory() {
  const { spendByResidentPhase, productsByResidentPhase, account } =
    useLoaderData<typeof loader>();
  const [searchParams] = useSearchParams();
  const phase = searchParams.get("phase") ?? "EnterpriseCorporateTech";

  const navigate = useNavigate();

  return (
    <div className="flex flex-col gap-4">
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "Reports",
            to: `/intelligence/${account.id}`,
            active: false,
          },
          {
            name: "Contract Insights by Enterprise Category",
            to: `/intelligence/${account.id}/spend-by-department`,
            active: true,
          },
        ]}
        title="Contract Insights by Enterprise Category"
        description="By visualizing your products and services across the enterprise, you can make strategic decisions to ensure spend is aligned with corporate goals and initiatives."
      />
      <div className="mt-3 px-3">
        <PageTabs
          validationType="urlParams"
          options={Object.keys(SpendByEnterpriseCategoryLabels).map(key => ({
            currentParam: phase,
            expectedResult: key,
            navigateTo: `?phase=${key}`,
            label:
              SpendByEnterpriseCategoryLabels[
                key as keyof typeof SpendByEnterpriseCategoryLabels
              ],
          }))}
          columns={4}
        />
      </div>
      {Object.values(spendByResidentPhase).length == 0 && <Empty />}

      <Card className="p-0">
        <div className="">
          <div className="flex align-middle p-4 md:p-8 flex-wrap items-center justify-evenly gap-4 md:gap-20">
            <div className="flex gap-6 items-center flex-grow">
              <IconCircle
                Icon={
                  SpendByEnterpriseCategoryIcons[
                    phase as keyof typeof SpendByEnterpriseCategoryIcons
                  ]
                }
                color="yellow"
                size="16"
              />

              <div className="text-xl text-montserrat md:w-72">
                <h3>
                  {
                    SpendByEnterpriseCategoryLabels[
                      phase as keyof typeof SpendByEnterpriseCategoryLabels
                    ]
                  }
                </h3>
                <div className="text-sm">
                  {
                    SpendByEnterpriseCategoryDescriptions[
                      phase as keyof typeof SpendByEnterpriseCategoryDescriptions
                    ]
                  }
                </div>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <IconCircle Icon={BriefcaseIcon} color="yellow" size="8" />
              <div>
                <div className="text-gray-500">Spend</div>
                <div className="font-semibold">
                  {money(
                    spendByResidentPhase[phase as ResidentLifecyclePhase] ?? 0
                  )}
                </div>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <IconCircle Icon={ShoppingBagIcon} color="yellow" size="8" />
              <div>
                <div className="text-gray-500">Products</div>
                <div className="font-semibold">
                  {
                    productsByResidentPhase[phase as ResidentLifecyclePhase]
                      .length
                  }
                </div>
              </div>
            </div>
          </div>
          <Table
            showSelectBox={false}
            showAddButton={false}
            variant="white"
            onClickRow={row => {
              navigate(`/products/${row.product_slug}`);
            }}
            cols={[
              { label: "Category", name: "category" },
              { label: "Vendor", name: "vendor" },
              {
                label: "Product",
                name: "product",
              },
              {
                label: "Revyse Rating",
                renderer: value => (
                  <div>
                    <StarRating rating={value.rating} />
                  </div>
                ),
                hideSmallScreen: true,
              },
              {
                label: "Has Overlap",
                renderer: v =>
                  v.hasOverlap && (
                    <Tooltip
                      text="This product has functional overlap with other products."
                      position="left"
                    >
                      <OverlapIcon className="h-5" />
                    </Tooltip>
                  ),
              },
            ]}
            data={productsByResidentPhase[phase as ResidentLifecyclePhase].map(
              p => {
                return {
                  id: p.id,
                  category: p.primary_category.name,
                  vendor: p.vendor.name,
                  product: p.title,
                  rating: p.avgReview,
                  hasOverlap: p.hasOverlap,
                  product_slug: p.slug,
                };
              }
            )}
          ></Table>
        </div>
      </Card>
    </div>
  );
}
