import { useCallback, useEffect, useMemo, useState } from "react";
import { json } from "@remix-run/node";
import type { Prisma } from "@prisma/client";
import { ContractStatus } from "@prisma/client";
import { useLoaderData, useNavigate } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { isEmpty } from "lodash";
import { CTA } from "~/components/cta.component";
import { Pagination } from "~/components/intelligence/pagination.component";
import { Modal } from "~/components/modal.component";
import {
  CrudCheckboxField,
  CrudDateField,
} from "~/components/form/crud-form.component";
import { Toast } from "~/components/toast.component";
import { AutocompleteFilter } from "~/components/intelligence/autocomplete-filter.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  canDoOnAccount,
  Permission,
} from "~/utils/intelligence-permission.utils";
import { CopyLocationAssignmentsConfirmModal } from "~/components/intelligence/locations/copy-location-assignments-confirm-modal.component";
import { LocationContractLineItemsTable } from "~/components/intelligence/locations/contract-line-item-location-table.component";
import { Button } from "~/components/button.component";
import { FilterBar } from "~/components/filter-bar.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

type Vendor = { id: string; name: string };

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocations],
      locationId: params.location_id,
    }
  );

  const { locationService, vendorService, contractLineItemLocationService } =
    await WebDIContainer();
  const locationId = params.location_id!;

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const vendorParam = search.getAll("vendor");
  const locationParam = search.getAll("locationQuantity");
  const statusParam = search.getAll("status") as ContractStatus[];
  const startDate = search.get("startDate");
  const endDate = search.get("endDate");

  const searchTerm = search.get("query");
  const page = parseInt(search.get("page") || "1");
  const perPage = parseInt(search.get("perPage") || "50");

  const offset = (page - 1) * perPage;

  let filters: Prisma.ContractLineItemLocationWhereInput = {
    location_id: params.location_id,
    OR: [
      {
        contract_line_item: {
          contract: {
            name: {
              contains: searchTerm ?? "",
              mode: "insensitive",
            },
          },
        },
      },
      {
        contract_line_item: {
          contract: {
            manager_account_vendor: {
              vendor: {
                name: {
                  contains: searchTerm ?? "",
                  mode: "insensitive",
                },
              },
            },
          },
        },
      },
      {
        contract_line_item: {
          name: {
            contains: searchTerm ?? "",
            mode: "insensitive",
          },
        },
      },
      {
        contract_line_item: {
          contract_line_item_products: {
            some: {
              product: {
                title: {
                  contains: searchTerm ?? "",
                  mode: "insensitive",
                },
              },
            },
          },
        },
      },
      {
        contract_line_item: {
          contract_line_item_fees: {
            some: {
              fee: {
                name: {
                  contains: searchTerm ?? "",
                  mode: "insensitive",
                },
              },
            },
          },
        },
      },
    ],
  };

  filters.contract_line_item =
    statusParam.length > 0 && vendorParam.length > 0
      ? {
          contract: {
            manager_account_vendor: {
              vendor_id: {
                in: vendorParam.flatMap(vendorValue => vendorValue.split(",")),
              },
            },
            status: {
              in: statusParam.flatMap(statusValue =>
                statusValue.split(",")
              ) as ContractStatus[],
            },
          },
        }
      : vendorParam.length > 0
      ? {
          contract: {
            manager_account_vendor: {
              vendor_id: {
                in: vendorParam.flatMap(vendorValue => vendorValue.split(",")),
              },
            },
          },
        }
      : statusParam.length > 0
      ? {
          contract: {
            status: {
              in: statusParam.flatMap(statusValue =>
                statusValue.split(",")
              ) as ContractStatus[],
            },
          },
        }
      : {
          contract: {},
        };

  if (startDate && endDate) {
    filters.expires_at = {
      gte: new Date(startDate),
      lte: new Date(endDate),
    };
  }

  if (!canDoOnAccount(user, account, Permission.ViewSensitiveContracts)) {
    filters.contract_line_item!.contract!.is_sensitive = false;
  }

  const contractLineItemLocations =
    await contractLineItemLocationService.getLocationContractLineItems(
      params.location_id,
      filters,
      offset,
      perPage
    );

  const contractLineItemLocationsCount =
    await contractLineItemLocationService.getLocationContractLineItemsCount(
      params.location_id,
      filters
    );
  const location = await locationService.getLocation(locationId);

  const vendors = await vendorService.getVendorsIdAndName({
    user,
    account,
  });

  const filteredContractLineItemLocations = contractLineItemLocations.filter(
    contractLineItemLocation => {
      if (locationParam.length > 0) {
        return locationParam.some(range => {
          const [min, max] = range.split("-").map(Number);
          const locationCount =
            contractLineItemLocation.contract_line_item
              .contract_line_item_locations?.length ?? 0;

          return (
            !isNaN(min) &&
            !isNaN(max) &&
            locationCount >= min &&
            locationCount <= max
          );
        });
      }
      return true;
    }
  );

  return json({
    location,
    contractLineItemLocations: filteredContractLineItemLocations,
    contractLineItemLocationsCount,
    vendors,
    locationParam,
    statusParam,
    vendorParam,
    searchTerm,
    page,
    endDate,
    startDate,
    account,
  });
}

export default function CopyLocationAssignments() {
  const navigate = useNavigate();
  const {
    contractLineItemLocations,
    contractLineItemLocationsCount,
    vendors,
    location,
    locationParam,
    statusParam,
    vendorParam,
    searchTerm,
    page,
    endDate,
    startDate,
    account,
  } = useLoaderData<typeof loader>();
  const baseUrl = `/intelligence/${account.id}/locations/${location?.id}/assigned-vendors/copy`;
  const [openFilteringModal, setOpenFilteringModal] = useState(false);
  const [filterByVendor, setFilterByVendor] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(page ?? 1);
  const [perPage] = useState(50);
  const [selectedVendors, setSelectedVendors] = useState<
    {
      id: string;
      name: string;
    }[]
  >([]);
  const [autocompleteValue, setAutocompleteValue] = useState<string>("");
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [renewalDateFrom, setRenewalDateFrom] = useState(startDate ?? "");
  const [renewalDateTo, setRenewalDateTo] = useState(endDate ?? "");
  const [dateRangeError, setDateRangeError] = useState<string>("");

  const locationQuantity = [
    { value: "1-50", name: "1-50" },
    { value: "50-100", name: "50-100" },
    { value: "100-200", name: "100-200" },
    { value: "200-500", name: "200-500" },
    { value: "500", name: "500+" },
  ];
  const [filterByLocationsQuantity, setFilterByLocationsQuantity] = useState<
    string[]
  >([]);
  const [filterByContractStatus, setFilterByContractStatus] = useState<
    string[]
  >([]);

  // Copy related
  const [openCopyAssignmentsConfirmModal, setOpenCopyAssignmentsConfirmModal] =
    useState(false);

  const [selectedRows, setSelectedRows] = useState<string[]>([]);

  const formattedSelectedRowsToModal = useMemo(() => {
    if (!openCopyAssignmentsConfirmModal) {
      return [];
    } else {
      return contractLineItemLocations.filter(item =>
        selectedRows.includes(item.id)
      );
    }
  }, [
    openCopyAssignmentsConfirmModal,
    contractLineItemLocations,
    selectedRows,
  ]);

  const onConfirmCopy = useCallback(() => {
    setOpenCopyAssignmentsConfirmModal(false);
    const itemsToCopyParam = selectedRows.join(",");

    const url = `./to?itemsToCopy=${itemsToCopyParam}`;
    navigate(url);
  }, [navigate, selectedRows]);

  // End of Copy related

  function constructNewURL(
    baseUrl: string,
    searchQuery: string,
    filterByLocationsQuantity: string[],
    filterByContractStatus: string[],
    filterByVendor: string[],
    newPage: number,
    perPage: number,
    renewalDateFrom?: string,
    renewalDateTo?: string
  ): string {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchQuery);

    if (filterByLocationsQuantity.length > 0) {
      searchParams.append(
        "locationQuantity",
        filterByLocationsQuantity.join(",")
      );
    }

    if (filterByContractStatus.length > 0) {
      searchParams.append("status", filterByContractStatus.join(","));
    }

    if (filterByVendor.length > 0) {
      searchParams.append("vendor", filterByVendor.join(","));
    }

    if (renewalDateFrom) {
      searchParams.append("startDate", renewalDateFrom);
    }

    if (renewalDateTo) {
      searchParams.append("endDate", renewalDateTo);
    }

    searchParams.append("page", newPage.toString());
    searchParams.append("perPage", perPage.toString());

    return `${baseUrl}?${searchParams.toString()}`;
  }

  // Handle filtering, name searching and pagination
  const handleFiltering = (newPage?: number, newSearchQuery?: string) => {
    const newURL = constructNewURL(
      baseUrl,
      newSearchQuery ?? searchTerm ?? "",
      filterByLocationsQuantity,
      filterByContractStatus,
      filterByVendor,
      newPage ? newPage : currentPage,
      perPage,
      renewalDateFrom,
      renewalDateTo
    );
    if (!isEmpty(renewalDateFrom) && isEmpty(renewalDateTo)) {
      setDateRangeError("Select end date");
      return;
    }
    if (!isEmpty(renewalDateTo) && isEmpty(renewalDateFrom)) {
      setDateRangeError("Select start date");
      return;
    }
    setDateRangeError("");
    setOpenFilteringModal(false);
    navigate(newURL);
  };

  const clearFilters = () => {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchTerm ?? "");

    setFilterByVendor([]);
    setSelectedVendors([]);
    setFilterByLocationsQuantity([]);
    setFilterByContractStatus([]);
    setRenewalDateFrom("");
    setRenewalDateTo("");

    searchParams.delete("locationQuantity");
    searchParams.delete("vendor");

    const newURL = `${baseUrl}?${searchParams.toString()}`;

    setOpenFilteringModal(false);
    navigate(newURL);
  };

  const handlePageChange = (newPage: number) => {
    const newURL = constructNewURL(
      baseUrl,
      searchTerm ?? "",
      filterByLocationsQuantity,
      filterByContractStatus,
      filterByVendor,
      newPage,
      perPage
    );
    navigate(newURL);
    setCurrentPage(newPage);
  };

  const totalPages = Math.ceil(contractLineItemLocationsCount / perPage);
  const pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);
  const resultsText = `${contractLineItemLocations.length} out of ${contractLineItemLocationsCount} results`;

  useEffect(() => {
    if (locationParam.length > 0) {
      const locationRanges = locationParam.flatMap(value => value.split(","));
      setFilterByLocationsQuantity(locationRanges);
    }

    if (statusParam.length > 0) {
      const status = statusParam.flatMap(value => value.split(","));
      setFilterByContractStatus(status);
    }

    if (vendorParam.length > 0) {
      const vendorFilters = vendorParam.flatMap(value => value.split(","));
      setFilterByVendor(vendorFilters);

      const initialSelectedVendors = vendors
        .filter(vendor => vendorFilters.includes(vendor?.id || ""))
        .filter(Boolean);

      setSelectedVendors(initialSelectedVendors);
    }
  }, [locationParam, statusParam, vendorParam, vendors]);

  const handleAddTag = (vendor: Vendor) => {
    if (vendor && !filterByVendor.includes(vendor.id)) {
      setSelectedVendors([...selectedVendors, vendor]);
      setFilterByVendor([...filterByVendor, vendor.id || ""]);
      setAutocompleteValue("");
    } else {
      setErrorMessage("Filter is already selected");
    }
  };

  const handleRemoveTag = (vendor: Vendor) => {
    const updatedVendors = selectedVendors.filter(
      selectedVendor => selectedVendor.id !== vendor.id
    );
    setSelectedVendors(updatedVendors);
    setFilterByVendor(filterByVendor.filter(id => id !== vendor.id));
    setErrorMessage("");
  };

  const filteredVendors = vendors.filter(vendor =>
    vendor?.name.toLowerCase().includes(autocompleteValue.toLowerCase())
  );

  const renderVendor = (option: Vendor) => {
    return option.name;
  };

  return (
    <>
      <CopyLocationAssignmentsConfirmModal
        isOpen={openCopyAssignmentsConfirmModal}
        itemsToCopy={formattedSelectedRowsToModal}
        onClose={() => setOpenCopyAssignmentsConfirmModal(false)}
        onConfirm={onConfirmCopy}
      />
      <Modal
        isOpen={openFilteringModal}
        onClose={() => setOpenFilteringModal(false)}
        size="medium"
        manager={true}
      >
        <div className="p-2 lg:p-6">
          {dateRangeError && <Toast variant="error" message={dateRangeError} />}
          <h4 className="font-bold">Filter By</h4>
          <div className="divide divide-y divide-2 ">
            <div>
              <div className="my-4 font-semibold"># Locations Assigned</div>
              <div className="flex justify-around">
                {locationQuantity.map((option, index) => (
                  <CrudCheckboxField
                    key={index}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: filterByLocationsQuantity.includes(
                        option.value
                      ),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterByLocationsQuantity([
                          ...filterByLocationsQuantity,
                          option.value,
                        ]);
                      } else {
                        setFilterByLocationsQuantity(
                          filterByLocationsQuantity.filter(
                            i => i !== option.value
                          )
                        );
                      }
                    }}
                  />
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Vendors</div>
              <AutocompleteFilter
                initialValue={autocompleteValue}
                options={filteredVendors}
                onFilterChange={setAutocompleteValue}
                onAddTag={handleAddTag}
                onRemoveTag={handleRemoveTag}
                selectedTags={selectedVendors}
                errorMessage={errorMessage}
                renderOption={renderVendor}
              />
            </div>
            <div>
              <div className="my-4 font-semibold">
                Current Term End Date Range
              </div>
              <div className="flex gap-x-6">
                <div className="w-full">
                  <CrudDateField
                    field={{
                      type: "text",
                      name: "startDate",
                      errors: [],
                      label: "Start Date",
                      placeholder: "From Date",
                      defaultValue: renewalDateFrom,
                      onChange: e => setRenewalDateFrom(e.target.value),
                    }}
                  />
                </div>
                <div className="w-full">
                  <CrudDateField
                    field={{
                      type: "text",
                      name: "endDate",
                      errors: [],
                      label: "End Date",
                      placeholder: "To Date",
                      defaultValue: renewalDateTo,
                      onChange: e => setRenewalDateTo(e.target.value),
                    }}
                  />
                </div>
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Contract Status</div>
              <div className="flex justify-around">
                {Object.values(ContractStatus).map((option, index) => (
                  <CrudCheckboxField
                    key={index}
                    field={{
                      name: "filter_by",
                      value: option,
                      label: option,
                      errors: [],
                      description: "",
                      defaultChecked: filterByContractStatus.includes(option),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterByContractStatus([
                          ...filterByContractStatus,
                          option,
                        ]);
                      } else {
                        setFilterByContractStatus(
                          filterByContractStatus.filter(i => i !== option)
                        );
                      }
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
          <div className="flex justify-end mt-8 items-center space-x-3">
            <button
              className="text-sky-500"
              onClick={() => {
                setCurrentPage(1);
                clearFilters();
              }}
            >
              Clear filters
            </button>
            <CTA
              variant="coral-shadow"
              onClick={() => {
                handleFiltering(1);
              }}
            >
              Show results
            </CTA>
          </div>
        </div>
      </Modal>
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location?.name ?? "",
            to: `/intelligence/${account.id}/locations/${location?.id}/details`,
          },
          {
            name: "Assigned line items",
            to: `/intelligence/${account.id}/locations/${location?.id}/assigned-vendors`,
          },
          {
            name: "Copy assignments",
            to: `/intelligence/${account.id}/locations/${location?.id}/assigned-vendors/copy`,
            active: true,
          },
        ]}
        title={
          <>
            Copy assignments: <br /> {location?.name}
          </>
        }
        description="Select the line items to be copied to a new location by checking the box
          in the corresponding row."
        buttonsSlot={
          <>
            <Button
              onClick={() =>
                navigate(
                  `/intelligence/${account.id}/locations/${location?.id}/assigned-vendors`
                )
              }
              color="transparent"
              className="mr-3"
            >
              Go Back
            </Button>
            <CTA
              id="copy-button"
              onClick={() => setOpenCopyAssignmentsConfirmModal(true)}
              disabled={isEmpty(selectedRows)}
            >
              Copy Assignments
            </CTA>
          </>
        }
      />
      <FilterBar
        inputPlaceholder="Search vendors, products or line items"
        onFilter={searchQuery => {
          handleFiltering(1, searchQuery);
        }}
        filters={{
          onOpenFilteringModal: setOpenFilteringModal,
          filtersCount:
            filterByLocationsQuantity.length +
            filterByContractStatus.length +
            filterByVendor.length +
            (startDate && endDate ? 1 : 0),
        }}
      />
      <div>
        <LocationContractLineItemsTable
          columnsToShow={[
            "vendorNameWithContractName",
            "contractLineItemName",
            "price",
            "currentTermEnds",
            "contractLineItemStatus",
          ]}
          items={contractLineItemLocations}
          showSelectBox={true}
          onSelectRows={rows => setSelectedRows(rows)}
        />
        <Pagination
          resultsText={resultsText}
          pageNumbers={pageNumbers}
          currentPage={currentPage}
          totalPages={totalPages}
          handleCallback={handlePageChange}
        ></Pagination>
      </div>
    </>
  );
}
