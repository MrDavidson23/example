import {
  type ActionFunctionArgs,
  type LoaderFunctionArgs,
  redirect,
} from "@remix-run/node";
import {
  type ManagerAccountRole,
  ManagerAccountRoleType,
  type UserInvitation,
} from "@prisma/client";
import {
  Form,
  useActionData,
  useLoaderData,
  useLocation,
  useNavigation,
} from "@remix-run/react";
import React, { useEffect, useRef, useState } from "react";
import { z } from "zod";
import { Button } from "~/components/button.component";
import {
  CrudSelectField,
  CrudTextField,
} from "~/components/form/crud-form.component";
import { issuesByKey } from "~/utils/form.utils.server";
import { get } from "lodash";
import { ArrowLeftIcon, TrashIcon } from "@heroicons/react/24/outline";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { Permission } from "~/utils/intelligence-permission.utils";
import { CTA } from "~/components/cta.component";
import {
  jsonWithError,
  jsonWithSuccess,
  redirectWithSuccess,
} from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { Modal } from "~/components/modal.component";
import { castFormFields } from "~/utils/type.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

export type JsonData = {
  fields?: Record<
    string,
    string | FormDataEntryValue | undefined | null
  > | null;
  success?: boolean;
  errors?: Record<string, string[] | null>;
};

const MANAGER_ACCOUNT_ROLE_OPTIONS = [
  { label: "Owner", value: ManagerAccountRoleType.Owner },
  { label: "Editor", value: ManagerAccountRoleType.Editor },
  { label: "Viewer", value: ManagerAccountRoleType.Viewer },
];

// ZOD fields and custom messages
const ZOD_FIELDS = {
  email: z.string().email().min(1, "Email is required"),
  role: z.enum(["Owner", "Editor", "Viewer"], {
    errorMap: () => {
      return { message: "Please select a permission level" };
    },
  }),
  uuid: z.string().uuid(),
};

export const action = async ({ request, params }: ActionFunctionArgs) => {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageAccountUsers],
    }
  );

  const { id: managerAccountId, user_id: invitationOrUserId } = params as {
    id: string;
    user_id: string;
  };

  const { managerAccountRoleService } = await WebDIContainer();

  const form = await request.formData();

  // CREATE
  if (invitationOrUserId === "new") {
    return await createAction(managerAccountId, form);
  }

  const managerAccountRole =
    await managerAccountRoleService.getManagerAccountRole({
      manager_account_id: managerAccountId,
      user_id: invitationOrUserId,
    });
  const isInvitation = !managerAccountRole;

  const model = isInvitation
    ? await managerAccountRoleService.getManagerAccountRoleUserInvitation({
        id: invitationOrUserId,
      })
    : managerAccountRole;

  const intent = form.get("intent");
  const nextAction = form.get("nextAction") as string;
  // DELETE
  if (intent === "delete") {
    return await deleteAction(model, isInvitation, managerAccountId);
  } else if (intent === "reassignTasks") {
    return await reassignTasks(
      form,
      nextAction,
      managerAccountRole,
      managerAccountId
    );
  }
  // UPDATE
  else {
    return await updateAction(model, isInvitation, form, managerAccountId);
  }
};

// CREATE ACTION //

const NewManageAccountRoleForm = z.object({
  email: ZOD_FIELDS.email,
  role: ZOD_FIELDS.role,
  manager_account_id: ZOD_FIELDS.uuid,
});

async function createAction(
  managerAccountId: string | undefined,
  form: FormData
) {
  const email = form.get("email") as string;
  const fields = {
    email: email.trim(),
    role: form.get("role"),
    manager_account_id: managerAccountId,
  };

  const validation = NewManageAccountRoleForm.safeParse(fields);

  // SUCCESS scenario
  if (validation.success) {
    const { managerAccountRoleService } = await WebDIContainer();

    await managerAccountRoleService.createManagerAccountRoleUserInvitation(
      validation.data,
      true
    );
    return redirectWithSuccess(
      `/intelligence/${managerAccountId}/account/users`,
      "New invitation sent successfully"
    );
  }
  // ERROR 400 if any error with the fields validation
  return jsonWithError<JsonData>(
    {
      success: false,
      fields,
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
}

// UPDATE ACTION //

const UpdateManageAccountRoleForm = z.object({
  role: ZOD_FIELDS.role,
  email: ZOD_FIELDS.email.optional(), // Only for invitations
});

async function updateAction(
  model: UserInvitation | ManagerAccountRole | null,
  isInvitation: boolean,
  form: FormData,
  managerAccountId: string
) {
  const email = (form.get("email") as string) ?? undefined;
  const fields = {
    role: form.get("role"),
    email,
  };

  const validation = UpdateManageAccountRoleForm.safeParse(fields);

  if (validation.success) {
    if (model) {
      const { managerAccountRoleService } = await WebDIContainer();

      if (isInvitation) {
        // If email is different, create new invitation, if there are errors when creating then return those errors
        if (get(model, "email") !== validation.data.email) {
          const responseJson = await createAction(managerAccountId, form);
          if (get(responseJson, "status") !== 200) {
            return responseJson;
          }
          await managerAccountRoleService.deleteUserInvitation(model.id);
          const newInvitation =
            await managerAccountRoleService.getManagerAccountRoleUserInvitation(
              {
                manager_account_id: managerAccountId,
                email: validation.data.email,
              }
            );
          return redirectWithSuccess(
            `/intelligence/${managerAccountId}/account/users/${newInvitation?.id}`,
            "Invitation email sent to the new email successfully"
          );
        }
        // If email is the same, just update the role in the invitation
        else {
          await managerAccountRoleService.updateUserInvitationRole(model.id, {
            manager_account_id: managerAccountId,
            role: validation.data.role,
          });
        }
      }
      // If it's not an invitation, then update the role for the ManagerAccountRole
      else {
        await managerAccountRoleService.updateManagerAccountRoleRole(
          model.id,
          validation.data.role
        );
      }
      return redirectWithSuccess(
        `/intelligence/${managerAccountId}/account/users`,
        "User updated successfully"
      );
    }

    // ERROR 404 if the managerAccountRole wasn't found
    return jsonWithError<JsonData>(
      {
        fields,
        success: false,
        errors: {
          email: ["The Intelligence Account user wasn't found"],
        } as { [key: string]: string[] },
      },
      "The user wasn't found",
      { status: 404 }
    );
  }
  // ERROR 400 if any error with the fields validation
  return jsonWithError<JsonData>(
    {
      success: false,
      fields,
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
}

// DELETE ACTION

async function deleteAction(
  model: UserInvitation | ManagerAccountRole | null,
  isInvitation: boolean,
  managerAccountId: string
) {
  if (model) {
    const { managerAccountRoleService } = await WebDIContainer();
    if (isInvitation) {
      await managerAccountRoleService.deleteUserInvitation(model.id);
    } else {
      await managerAccountRoleService.deleteManagerAccountRole(model.id);
    }
    return redirectWithSuccess(
      `/intelligence/${managerAccountId}/account/users`,
      "User removed successfully"
    );
  }
  // ERROR 404 if the managerAccountRole wasn't found
  return jsonWithError<JsonData>(
    {
      fields: null,
      success: false,
      errors: {
        email: ["The Account User wasn't found"],
      } as { [key: string]: string[] },
    },
    "The user wasn't found",
    { status: 404 }
  );
}

const ReassignTasksForm = z.object({
  task_owner_id: z.string().uuid(),
});

async function reassignTasks(
  form: FormData,
  nextAction: string,
  role: ManagerAccountRole | null,
  managerAccountId: string
) {
  const fields = {
    task_owner_id: form.get("task_owner_id"),
  };

  const validation = ReassignTasksForm.safeParse(fields);

  if (validation.success) {
    const { managerAccountTaskService } = await WebDIContainer();
    if (role) {
      await managerAccountTaskService.reassignUserTasks(
        role.id,
        validation.data.task_owner_id
      );
      if (nextAction === "delete") {
        return await deleteAction(role, false, managerAccountId);
      }
      if (nextAction === "updateRole") {
        return await updateAction(role, false, form, managerAccountId);
      }
      return jsonWithSuccess<JsonData>(
        {
          success: true,
          fields: castFormFields(fields),
          errors: issuesByKey([]),
        },
        "Task owner reassigned successfully"
      );
    }
    return jsonWithError<JsonData>(
      {
        fields,
        success: false,
        errors: {
          email: ["The Intelligence Account user wasn't found"],
        } as { [key: string]: string[] },
      },
      "The user wasn't found",
      { status: 404 }
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return jsonWithError<JsonData>(
    { success: false, fields, errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
}

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const { user, account: managerAccount } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageAccountUsers],
    }
  );

  const { id: managerAccountId, user_id: invitationOrUserId } = params as {
    id: string;
    user_id: string;
  };

  const isCreating = invitationOrUserId === "new";

  const { managerAccountRoleService, managerAccountTaskService } =
    await WebDIContainer();

  if (!isCreating) {
    const uuidChecker = z.string().uuid();
    if (!uuidChecker.safeParse(managerAccountId).success) {
      throw redirect(`/intelligence/`);
    }
    if (!uuidChecker.safeParse(invitationOrUserId).success) {
      throw redirect(`/intelligence/${managerAccountId}/account/users`);
    }

    const managerAccountRole =
      await managerAccountRoleService.getManagerAccountRole({
        manager_account_id: managerAccountId,
        user_id: invitationOrUserId,
      });
    const isInvitation = !managerAccountRole;

    const invitation = isInvitation
      ? await managerAccountRoleService.getManagerAccountRoleUserInvitation({
          id: invitationOrUserId,
        })
      : null;

    if (
      (!managerAccountRole && !invitation) || // If no found any with this id
      (isInvitation && invitation && invitation.accepted_by_id !== null) || // If the invitation exists but already accepted
      managerAccountRole?.user_id == user.id // If they are editing themselves
    ) {
      throw redirect(`/intelligence/${managerAccountId}/account/users`);
    }

    const isTaskOwner = await managerAccountTaskService.isTaskOwner(
      managerAccountRole?.id
    );

    const accountRoles = await managerAccountRoleService.getManagerAccountRoles(
      managerAccountId,
      {
        status: [],
        perPage: 100,
        page: 1,
        permissionLevel: [
          ManagerAccountRoleType.Owner,
          ManagerAccountRoleType.Editor,
        ],
      }
    );
    const accountUsers = accountRoles
      .filter(user => user.id !== managerAccountRole?.id)
      .map(user => ({
        id: user.id,
        first_name: user.user.first_name,
        last_name: user.user.last_name,
        email: user.user.email,
      }));

    return {
      isCreating,
      isInvitation,
      invitation,
      managerAccountRole,
      managerAccountId,
      managerAccount,
      isTaskOwner,
      accountUsers,
    };
  }
  return {
    isCreating,
    isInvitation: true,
    invitation: null,
    managerAccountRole: null,
    managerAccountId,
    managerAccount,
    isTaskOwner: false,
    accountUsers: null,
  };
};

export default function IntelligenceManagerAccountUser() {
  const actionData = useActionData<typeof action>();
  const currentPath = useLocation().pathname;

  const { state } = useNavigation();

  const isSubmitting = state === "submitting";
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [reassignTasksModal, setReassignTasksModal] = useState(false);
  const [intent, setIntent] = useState("");

  const $form = useRef<HTMLFormElement>(null);

  const {
    isCreating,
    isInvitation,
    managerAccountRole,
    invitation,
    managerAccountId,
    isTaskOwner,
    managerAccount,
    accountUsers,
  } = useLoaderData<typeof loader>();

  const [userRoleType, setUserRoleType] = useState(
    isInvitation ? get(invitation?.role, "role") : managerAccountRole?.role
  );

  const userOptions =
    accountUsers &&
    accountUsers.map(user => ({
      label: `${user?.first_name} ${user?.last_name} - ${user?.email}`,
      value: user?.id,
    }));

  useEffect(() => {
    if (isCreating && state === "idle" && actionData?.success) {
      $form.current?.reset();
    }
  }, [state, actionData, isCreating]);

  const title = isCreating
    ? "Send new invitation"
    : isInvitation
    ? `Edit invitation for ${invitation?.email}`
    : `Edit role for ${managerAccountRole?.user.first_name} ${managerAccountRole?.user.last_name}`; // TODO: and locations

  const submitButtonVerbiage = isSubmitting
    ? "Sending and saving..."
    : isCreating
    ? "Send New Invitation"
    : isInvitation
    ? `Save Invitation`
    : `Save Changes`;

  const deleteButtonVerbiage = isInvitation
    ? `Cancel Invitation`
    : `Remove Access`;

  const confirmDeleteButtonVerbiage = isInvitation
    ? `Are you sure you want to cancel the invitation?`
    : `Are you sure you want to remove this user access?`;

  return (
    <>
      {userOptions && (
        <Modal
          isOpen={reassignTasksModal}
          onClose={() => setReassignTasksModal(false)}
          size="medium"
          manager={true}
        >
          <div className="p-3 space-y-5">
            <h1 className="text-2xl">
              Reassign {managerAccountRole?.user.first_name}{" "}
              {managerAccountRole?.user.last_name}'s tasks.
            </h1>
            <div>
              Before we can update this user’s access, their tasks will need to
              be reassigned to another user on the {managerAccount?.name}{" "}
              account.
            </div>
            <Form method="post" encType="multipart/form-data">
              <input type="hidden" name="intent" value="reassignTasks" />
              <input type="hidden" name="nextAction" value={intent} />
              {/* Provide the user role when needed */}
              <input type="hidden" name="role" value={userRoleType} />
              <CrudSelectField
                field={{
                  name: "task_owner_id",
                  type: "select",
                  options: userOptions,
                  errors: actionData?.errors?.task_owner_id ?? [],
                  label: "Task Owner",
                  defaultValue:
                    managerAccountRole?.id ??
                    (actionData?.fields?.task_owner_id as string) ??
                    undefined,
                }}
              />
              <div className="flex justify-between mt-5 w-full">
                <Button
                  onClick={() => setReassignTasksModal(false)}
                  color="transparent"
                >
                  <ArrowLeftIcon className="h-5 mr-2" /> Back
                </Button>
                <CTA className="m-2" type="submit">
                  Reassign Tasks
                </CTA>
              </div>
            </Form>
          </div>
        </Modal>
      )}
      <IntelligenceScreenHeader
        title={title}
        crumbs={[
          {
            name: "User management",
            to: `/intelligence/${managerAccountId}/account/users`,
          },
          { name: title, to: currentPath, active: true },
        ]}
      />
      <Form method="post" ref={$form}>
        <div className="-space-y-px rounded-md shadow-sm border border-gray-100 bg-white p-6 grid md:grid-cols-2 gap-6 mt-6">
          <div>
            <CrudTextField
              field={{
                label: "Email",
                name: "email",
                errors: actionData?.errors?.email ?? [],
                defaultValue: isInvitation
                  ? invitation?.email
                  : managerAccountRole?.user.email,
                type: "text",
                disabled: !isCreating && !isInvitation,
              }}
              className="disabled:opacity-75"
            />
          </div>
          <div>
            <CrudSelectField
              field={{
                label: "Role",
                name: "role",
                errors: actionData?.errors?.role ?? [],
                defaultValue: userRoleType,
                type: "select",
                options: MANAGER_ACCOUNT_ROLE_OPTIONS,
              }}
              onChange={e =>
                setUserRoleType(e.target.value as ManagerAccountRoleType)
              }
            />
          </div>
        </div>
        <div className="flex justify-around md:justify-between mt-6 flex-wrap-reverse md:flex-nowrap">
          <Button
            className="text-sm"
            color="transparent"
            to={`/intelligence/${managerAccountId}/account/users`}
          >
            <ArrowLeftIcon className="h-5 mr-3" />
            Return to user management
          </Button>
          <div className="flex justify-end items-center">
            <div className="mr-4">
              {!isCreating &&
                (confirmDeleteOpen ? (
                  <Form
                    className="flex justify-between items-center"
                    method="post"
                  >
                    {confirmDeleteButtonVerbiage}
                    <input type="hidden" name="intent" value="delete" />
                    <CTA
                      onClick={() => setConfirmDeleteOpen(false)}
                      variant="sky"
                      className="ml-2"
                    >
                      Cancel
                    </CTA>
                    {userRoleType && isTaskOwner && !isInvitation ? (
                      <CTA
                        type="button"
                        className="ml-2 bg-red-600 hover:bg-red-500"
                        onClick={() => {
                          setReassignTasksModal(true);
                          setIntent("delete");
                        }}
                        id="confirm-delete-button"
                      >
                        Yep!
                      </CTA>
                    ) : (
                      <CTA
                        type="submit"
                        className="ml-2 bg-red-600 hover:bg-red-500"
                        id="confirm-delete-button"
                      >
                        Yep!
                      </CTA>
                    )}
                  </Form>
                ) : (
                  <>
                    <Button
                      onClick={() => {
                        setConfirmDeleteOpen(!confirmDeleteOpen);
                      }}
                      color="transparent"
                      id="delete-button"
                    >
                      <div className="flex">
                        <TrashIcon className="h-5 mr-1" />
                        {deleteButtonVerbiage}
                      </div>
                    </Button>
                  </>
                ))}
            </div>
            {!confirmDeleteOpen &&
              (userRoleType && isTaskOwner && !isInvitation ? (
                <CTA
                  type="button"
                  disabled={isSubmitting || confirmDeleteOpen}
                  className={`${isSubmitting && "animate-bounce"}`}
                  onClick={() => {
                    setReassignTasksModal(true);
                    setIntent("updateRole");
                  }}
                  id="save"
                >
                  {submitButtonVerbiage}
                </CTA>
              ) : (
                <CTA
                  type="submit"
                  disabled={isSubmitting || confirmDeleteOpen}
                  className={`${isSubmitting && "animate-bounce"}`}
                  id="save"
                >
                  {submitButtonVerbiage}
                </CTA>
              ))}
          </div>
        </div>
      </Form>
      <div className="flex justify-end pr-6 mt-3 items-center"></div>
    </>
  );
}
