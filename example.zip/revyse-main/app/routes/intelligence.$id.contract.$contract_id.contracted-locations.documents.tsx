import type { ActionFunctionArgs } from "@remix-run/node";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { castFormFields } from "~/utils/type.utils";
import { Permission } from "~/utils/intelligence-permission.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const MB = 1024 * 1024;
const FILE_BYTE_LIMIT = 50 * MB;

const UpdateContractLocationFileForm = z.object({
  id: z.string(),
  name: z.string(),
  file: z.string().nullable(),
  locationId: z.string(),
});

const DeleteContractLocationFileForm = z.object({
  id: z.string().uuid(),
});

export async function action({ params, request }: ActionFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContractLocationsDocuments],
    }
  );
  const contractId = params.contract_id as string;

  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "file", byteLimit: FILE_BYTE_LIMIT },
  ]);

  if (form.get("intent") === "delete") {
    return deleteContractLocationFile({ form });
  }

  return updateContractLocationFile({ form, contractId: contractId });
}

async function deleteContractLocationFile({ form }: { form: FormData }) {
  const { contractService } = await WebDIContainer();
  const fields = {
    id: form.get("id"),
  };

  const validation = DeleteContractLocationFileForm.safeParse(fields);

  if (validation.success) {
    const response = await contractService.deleteContractLocationFile(
      validation.data.id
    );
    if (response.success) {
      return jsonWithSuccess(
        {
          success: true,
          contractFile: null,
          fields: castFormFields(fields),
          errors: issuesByKey([]),
        },
        "Document deleted"
      );
    } else {
      return jsonWithError(
        {
          success: false,
          contractFile: null,
          fields: null,
          errors: { server: [response.error] } as Record<string, string[]>,
        },
        "Error deleting document"
      );
    }
  }
}

async function updateContractLocationFile({
  form,
  contractId,
}: {
  form: FormData;
  contractId: string;
}) {
  const { contractService } = await WebDIContainer();

  const fields = {
    id: form.get("id"),
    name: form.get("name"),
    file: form.get("file"),
    locationId: form.get("locationId"),
  };

  const validation = UpdateContractLocationFileForm.safeParse(fields);
  if (validation.success) {
    const contractedLocationFile =
      await contractService.handleContractLocationFile({
        ...validation.data,
        contractId,
      });

    return jsonWithSuccess(
      {
        success: true,
        contractedLocationFile,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      },
      `Document ${validation.data.id?.includes("new_") ? "created" : "updated"}`
    );
  }
  return jsonWithError(
    {
      success: false,
      contractedLocationFile: null,
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    "Error updating document"
  );
}
