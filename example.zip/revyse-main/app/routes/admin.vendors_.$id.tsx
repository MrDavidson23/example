import { EyeIcon, TrashIcon } from "@heroicons/react/20/solid";
import {
  IntegrationProvider,
  VendorCompanyStatus,
  VendorLastFundingRound,
  VendorState,
  VendorValueTags,
} from "@prisma/client";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  SerializeFrom,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { Form, useActionData, useLoaderData } from "@remix-run/react";
import { isEmpty, isNil, map } from "lodash";
import React, { useState } from "react";
import type { Vendor, VendorIntegration } from "@prisma/client";
import { z } from "zod";
import VendorIntegrationsManager from "~/components/admin/vendor/vendor-integrations-manager.component";
import { Button, DangerButton } from "~/components/button.component";
import { CrudFormPage } from "~/components/form/crud-form-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import { assertAuthorized } from "~/utils/assert.utils.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { getUser } from "~/utils/session.server";
import {
  jsonWithError,
  jsonWithSuccess,
  redirectWithSuccess,
} from "remix-toast";
import {
  DEFAULT_FORM_ERROR_MESSAGE,
  VendorCompanyStatusLabels,
  VendorLastFundingRoundLabels,
  VendorTotalRoundsLabels,
  VendorValueTagsLabels,
} from "~/utils/constants.utils";
import { castFormFields } from "~/utils/type.utils";
import { CurrencyField } from "~/components/form/currency-field.component";
import { CrudCheckboxField } from "~/components/form/crud-form.component";
import { Currency } from "~/utils/validation.utils.server";

const MB = 1024 * 1024;
const LOGO_BYTE_LIMIT = 0.5 * MB;

const NewProductForm = z
  .object({
    name: z.string().min(1, "Name is required"),
    description: z.string().min(1, "Description is required"),
    founded_year: z.string(),
    hq_location: z.string(),
    linkedin_profile_url: z.string(),
    number_employees: z.string().nullable(),
    website: z.string(),
    state: z.nativeEnum(VendorState),
    logo_file_id: z
      .string()
      .min(1)
      .nullable()
      .transform(v => (v === "--" ? undefined : v ?? undefined)),
    vendor_integrations: z.array(
      z.object({
        id: z.string(),
        integrated_vendor_id: z.string().nullable(),
        integrated_product_id: z.string().nullable(),
        integration_provider: z.nativeEnum(IntegrationProvider),
      })
    ),
    slug: z
      .string()
      .regex(
        /^[a-z0-9]+(?:(?:-|_)+[a-z0-9]+)*$/,
        "Slug must be lowercase and can only contain letters, numbers, dashes, and underscores."
      )
      .nullable(),
    company_status: z
      .nativeEnum(VendorCompanyStatus)
      .or(z.literal("null"))
      .transform(v => (v === "null" ? null : v)),
    last_funding_round: z.nativeEnum(VendorLastFundingRound),
    total_rounds: z
      .enum(["null", ...Object.keys(VendorTotalRoundsLabels)])
      .transform(v => (v === "null" ? null : Number(v))),
    total_funding: z.nullable(Currency),
    value_tags: z.array(z.nativeEnum(VendorValueTags)).optional(),
  })
  .superRefine((data, ctx) => {
    if (data.state === VendorState.ApprovedForPublishing && !data.slug) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message:
          "Slug is required for vendors that are approved for publishing.",
        path: ["slug"],
      });
    }
  });

async function updateAction({
  id,
  form,
  user,
}: {
  id: string | undefined;
  form: FormData;
  user: { id: string };
}) {
  const fields = {
    name: form.get("name"),
    description: form.get("description"),
    founded_year: form.get("founded_year"),
    hq_location: form.get("hq_location"),
    linkedin_profile_url: form.get("linkedin_profile_url"),
    number_employees: form.get("number_employees"),
    website: form.get("website"),
    logo_file_id: form.get("logo_file_id"),
    state: form.get("state"),
    vendor_integrations: form
      .getAll("vendor_integrations_id[]")
      .map((id, i) => ({
        id,
        integrated_vendor_id: !isEmpty(
          form.getAll("vendor_integrations_integrated_vendor_id[]")[i]
        )
          ? form.getAll("vendor_integrations_integrated_vendor_id[]")[i]
          : null,
        integrated_product_id: !isEmpty(
          form.getAll("vendor_integrations_integrated_product_id[]")[i]
        )
          ? form.getAll("vendor_integrations_integrated_product_id[]")[i]
          : null,
        integration_provider: form.getAll(
          "vendor_integrations_integration_provider[]"
        )[i] as IntegrationProvider,
      })),
    slug: !isEmpty(form.get("slug")) ? form.get("slug") : null,
    company_status: form.get("company_status"),
    last_funding_round: form.get("last_funding_round"),
    total_rounds: form.get("total_rounds"),
    total_funding: !isEmpty(form.get("total_funding"))
      ? form.get("total_funding")
      : null,
    value_tags: form.getAll("value_tags") as string[],
  };
  const validation = NewProductForm.safeParse(fields);

  if (validation.success) {
    const { vendorService } = await WebDIContainer();

    // show error messaging if a user tries to remove approval (Not Approved or Revyse Intelligence-Only)
    // for a vendor who was previously approved to be published across Revyse and has actively published products on Discovery
    if (validation.data.state !== VendorState.ApprovedForPublishing) {
      const vendor = await vendorService.getVendor(id!);

      if (
        vendor?.state === VendorState.ApprovedForPublishing &&
        vendor?.products.length > 0
      ) {
        return jsonWithError(
          {
            fields: castFormFields(fields),
            success: false,
            errors: issuesByKey([
              {
                path: ["state"],
                message:
                  "Vendor status cannot be changed because there are active products published on Revyse Discovery that are associated with this vendor.",
              },
            ]),
          },
          DEFAULT_FORM_ERROR_MESSAGE,
          { status: 400 }
        );
      }
    }
    const data = {
      ...validation.data,
      approved_by_id:
        validation.data.state === VendorState.ApprovedForPublishing
          ? user.id
          : null,
      approved_at:
        validation.data.state === VendorState.ApprovedForPublishing
          ? new Date()
          : null,
      vendor_integrations: {
        deleteMany: {
          id: {
            notIn: map(validation.data.vendor_integrations, "id").filter(
              v => !v.includes("new_")
            ),
          },
        },
        updateMany: validation.data.vendor_integrations
          .filter(v => !v.id.includes("new_"))
          .map(vendorIntegration => ({
            data: {
              integrated_vendor_id: vendorIntegration.integrated_vendor_id,
              integrated_product_id: vendorIntegration.integrated_product_id,
              integration_provider: vendorIntegration.integration_provider,
              last_verified_at: new Date(),
            },
            where: { id: vendorIntegration.id },
          })),
        createMany: {
          data: validation.data.vendor_integrations
            .filter(v => v.id.includes("new_"))
            .map(vendorIntegration => ({
              integrated_vendor_id: vendorIntegration.integrated_vendor_id,
              integrated_product_id: vendorIntegration.integrated_product_id,
              integration_provider: vendorIntegration.integration_provider,
            })),
        },
      },
      value_tags: {
        set: validation.data.value_tags,
      },
    };

    await vendorService.updateVendor(id!, data);

    return jsonWithSuccess(
      {
        fields: castFormFields(fields),
        success: true,
        errors: issuesByKey([]),
      },
      "Vendor updated successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return jsonWithError(
    { fields: castFormFields(fields), success: false, errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
}

async function deleteAction({ id }: { id: string | undefined }) {
  const { vendorService } = await WebDIContainer();

  const vendor = await vendorService.getVendor(id!);

  if (
    vendor?.products.length > 0 ||
    vendor?.manager_account_vendors.length > 0
  ) {
    return jsonWithError(
      {
        fields: { id } as Partial<Vendor>,
        success: false,
        errors: issuesByKey([
          {
            path: ["general"],
            message:
              "This vendor is associated with a published product or is part of an intelligence account.",
          },
        ]),
      },
      "This vendor is associated with a published product or is part of an intelligence account"
    );
  }
  await vendorService.deleteVendor(id!);
  return redirectWithSuccess("/admin/vendors", "Vendor deleted successfully");
}

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));
  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "logo_file_id", byteLimit: LOGO_BYTE_LIMIT },
  ]);

  const intent = form.get("intent");
  if (intent === "delete") {
    return deleteAction({ id: params.id });
  }

  return updateAction({ id: params.id, form, user });
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { vendorService } = await WebDIContainer();
  const vendor = await vendorService.getVendorWithIntegrations(params.id!);
  if (isNil(vendor)) {
    throw json(undefined, { status: 404 });
  }

  const vendorIntegrationVendorOptions =
    await vendorService.getVendorIntegrationVendorOptions({
      id: {
        not: {
          in: [
            vendor.id,
            ...(map(vendor.vendor_integrations, "integrated_vendor_id").filter(
              Boolean
            ) as string[]),
          ],
        },
      },
    });

  const vendorIntegrationProductOptions =
    await vendorService.getVendorIntegrationProductOptions({
      id: {
        not: {
          in: [
            ...(map(vendor.vendor_integrations, "integrated_product_id").filter(
              Boolean
            ) as string[]),
          ],
        },
      },
    });

  const integrationOptionGroups = [
    {
      group: "Vendors",
      options: vendorIntegrationVendorOptions.map(vendor => ({
        label: vendor.name,
        value: vendor.id,
        logo_file_id: vendor.logo_file_id,
      })),
    },
    {
      group: "Products",
      options: vendorIntegrationProductOptions.map(product => ({
        label: product.title,
        value: product.id,
        logo_file_id: product.logo_file_id,
      })),
    },
  ];

  return json({ vendor, integrationOptionGroups });
}

export default function AdminVendorIdRoute() {
  const actionData = useActionData<typeof action>();
  const { vendor, integrationOptionGroups } = useLoaderData<typeof loader>();
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  const [vendorIntegrations, setVendorIntegrations] = useState<
    Partial<SerializeFrom<VendorIntegration>>[]
  >(vendor.vendor_integrations);

  return (
    <>
      <CrudFormPage
        crumbs={[
          { name: "Vendors", to: "/admin/vendors", active: false },
          {
            name: vendor.name,
            to: `/admin/vendors/${vendor.id}`,
            active: true,
          },
        ]}
        config={{
          submitSuccess: actionData?.success,
          customToastMessage: actionData?.errors.general?.join(", "),
          showToast: !isEmpty(actionData?.errors.general),
          sections: [
            {
              title: "Update Vendor",
              subtitle: "",
              fields: [
                {
                  name: "name",
                  label: "Name",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.name ?? undefined
                    : vendor.name,
                  errors: actionData?.errors?.name ?? [],
                },
                {
                  name: "description",
                  label: "Description",
                  description: "A full description of the vendor",
                  type: "textarea",
                  defaultValue: actionData
                    ? actionData.fields?.description ?? undefined
                    : vendor.description ?? undefined,
                  errors: actionData?.errors?.description ?? [],
                },
                {
                  name: "slug",
                  label: "Slug",
                  type: "text",
                  defaultValue: vendor.slug ?? undefined,
                  errors: actionData?.errors?.slug ?? [],
                },
                {
                  name: "logo_file_id",
                  label: "Logo (192 x 192)",
                  buttonLabel: "",
                  type: "image-upload",
                  defaultValue: vendor?.logo_file
                    ? vendor.logo_file
                    : undefined,
                  errors: actionData?.errors?.logo_file_id ?? [],
                  maxFileSize: LOGO_BYTE_LIMIT,
                  allowRemoval: true,
                  defaultNoValue: (
                    <img
                      src="/assets/default-logo.png"
                      className="w-12 h-12"
                      alt="Vendor default logo"
                      width="600"
                      height="600"
                    />
                  ),
                  square: true,
                },
                {
                  name: "state",
                  label: "Not Approved",
                  type: "radio",
                  value: VendorState.NotApproved,
                  errors:
                    actionData?.fields?.state === VendorState.NotApproved
                      ? actionData?.errors?.state ?? []
                      : [],
                  defaultChecked: vendor.state === VendorState.NotApproved,
                  description: "This vendor has not been published.",
                },
                {
                  name: "state",
                  label: "Approved for Publishing on Revyse",
                  type: "radio",
                  value: VendorState.ApprovedForPublishing,
                  errors:
                    actionData?.fields?.state ===
                    VendorState.ApprovedForPublishing
                      ? actionData?.errors?.state ?? []
                      : [],
                  defaultChecked:
                    vendor.state === VendorState.ApprovedForPublishing,
                  description:
                    "Check this box to publish to Revyse Discovery and Revyse Intelligence.",
                },
                {
                  name: "state",
                  label: "Revyse Intelligence-Only",
                  type: "radio",
                  value: VendorState.RevyseIntelligenceOnly,
                  errors:
                    actionData?.fields?.state ===
                    VendorState.RevyseIntelligenceOnly
                      ? actionData?.errors?.state ?? []
                      : [],
                  defaultChecked:
                    vendor.state === VendorState.RevyseIntelligenceOnly,
                  description:
                    "This vendor will not be visible on Revyse Discovery.",
                },
                {
                  name: "founded_year",
                  label: "Founded Year",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.founded_year ?? undefined
                    : vendor.founded_year ?? undefined,
                  errors: actionData?.errors?.founded_year ?? [],
                },
                {
                  name: "hq_location",
                  label: "HQ Location",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.hq_location ?? undefined
                    : vendor.hq_location ?? undefined,
                  errors: actionData?.errors?.hq_location ?? [],
                },
                {
                  name: "linkedin_profile_url",
                  label: "LinkedIn Profile URL",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.linkedin_profile_url ?? undefined
                    : vendor.linkedin_profile_url ?? undefined,
                  errors: actionData?.errors?.linkedin_profile_url ?? [],
                },
                {
                  name: "number_employees",
                  label: "Number of Employees",
                  type: "select",
                  defaultValue: actionData
                    ? actionData.fields?.number_employees ?? undefined
                    : vendor.number_employees ?? undefined,
                  options: [
                    { label: "1-10", value: "1-10" },
                    { label: "11-50", value: "11-50" },
                    { label: "51-200", value: "51-200" },
                    { label: "201-500", value: "201-500" },
                    { label: "501-1000", value: "501-1000" },
                    { label: "1000+", value: "1000+" },
                  ],
                  errors: actionData?.errors?.number_employees ?? [],
                },
                {
                  name: "website",
                  label: "Website",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.website ?? undefined
                    : vendor.website ?? undefined,
                  errors: actionData?.errors?.website ?? [],
                },
                {
                  name: "company_status",
                  label: "Company Status",
                  type: "select",
                  defaultValue:
                    actionData?.fields?.company_status ??
                    vendor.company_status ??
                    undefined,
                  options: Object.keys(VendorCompanyStatusLabels).map(key => ({
                    label:
                      VendorCompanyStatusLabels[
                        key as keyof typeof VendorCompanyStatusLabels
                      ],
                    value: key,
                  })),
                  errors: actionData?.errors?.company_status ?? [],
                  allowNull: true,
                },
              ],
            },
            {
              title: "Vendor Integrations",
              subtitle: "",
              fields: [
                {
                  name: "vendor_integrations",
                  type: "custom",
                  render: () => (
                    <>
                      <VendorIntegrationsManager
                        vendorIntegrations={vendorIntegrations}
                        onChange={setVendorIntegrations}
                        options={integrationOptionGroups}
                      />
                      {vendorIntegrations.map(vendorIntegration => (
                        <React.Fragment key={vendorIntegration.id}>
                          <input
                            type="hidden"
                            name="vendor_integrations_id[]"
                            value={vendorIntegration.id}
                          />
                          <input
                            type="hidden"
                            name="vendor_integrations_integrated_vendor_id[]"
                            value={
                              vendorIntegration.integrated_vendor_id ??
                              undefined
                            }
                          />
                          <input
                            type="hidden"
                            name="vendor_integrations_integrated_product_id[]"
                            value={
                              vendorIntegration.integrated_product_id ??
                              undefined
                            }
                          />
                          <input
                            type="hidden"
                            name="vendor_integrations_integration_provider[]"
                            value={vendorIntegration.integration_provider}
                          />
                        </React.Fragment>
                      ))}
                    </>
                  ),
                },
              ],
            },
            {
              title: "Financials",
              subtitle: "",
              fields: [
                {
                  name: "last_funding_round",
                  label: "Last Funding Round",
                  type: "select",
                  defaultValue:
                    actionData?.fields?.last_funding_round ??
                    vendor.last_funding_round ??
                    VendorLastFundingRoundLabels.NotSet,
                  options: Object.keys(VendorLastFundingRoundLabels).map(
                    key => ({
                      label:
                        VendorLastFundingRoundLabels[
                          key as keyof typeof VendorLastFundingRoundLabels
                        ],
                      value: key,
                    })
                  ),
                  errors: actionData?.errors?.last_funding_round ?? [],
                },
                {
                  name: "total_rounds",
                  label: "Total Rounds",
                  type: "select",
                  defaultValue:
                    actionData?.fields?.total_rounds ??
                    vendor.total_rounds ??
                    undefined,
                  options: Object.entries(VendorTotalRoundsLabels).map(
                    ([key, value]) => ({
                      label: value,
                      value: key,
                    })
                  ),
                  errors: actionData?.errors?.total_rounds ?? [],
                  allowNull: true,
                  nullLabel: "Not Set",
                },
                {
                  name: "total_funding",
                  type: "custom",
                  render: () => (
                    <div className="col-span-full">
                      <CurrencyField
                        label="Total Funding"
                        name="total_funding"
                        defaultValue={
                          actionData?.fields?.total_funding ??
                          vendor.total_funding ??
                          undefined
                        }
                        errors={actionData?.errors?.total_funding ?? []}
                      />
                    </div>
                  ),
                },
              ],
            },
            {
              title: "Vendor Value Tags",
              subtitle: "",
              fields: [
                {
                  name: "value_tags",
                  type: "custom",
                  render: () => (
                    <div className="grid grid-cols-2 gap-2 col-span-full">
                      {Object.entries(VendorValueTagsLabels).map(
                        ([value, label]) => (
                          <CrudCheckboxField
                            key={value}
                            field={{
                              name: "value_tags",
                              label: label,
                              type: "checkbox",
                              value: value,
                              defaultChecked:
                                actionData?.fields?.value_tags?.includes(
                                  value
                                ) ??
                                Array.from(vendor.value_tags).includes(
                                  value as VendorValueTags
                                ) ??
                                false,
                              errors: actionData?.errors?.value_tags ?? [],
                              description: "",
                            }}
                          />
                        )
                      )}
                    </div>
                  ),
                },
              ],
            },
          ],
        }}
        buttonsSlot={
          <div className="flex gap-2 justify-between">
            {vendor.id !== "new" &&
              vendor.approved_at &&
              vendor.state === VendorState.ApprovedForPublishing && (
                <Button to={`/vendors/${vendor.slug}`} id="view-listing">
                  <EyeIcon className="h-6 mr-2" /> View Vendor Page
                </Button>
              )}
            {confirmDeleteOpen ? (
              <Form
                className="flex justify-between items-center"
                method="post"
                encType="multipart/form-data"
              >
                Are you sure you want to delete this vendor?
                <input type="hidden" name="intent" value="delete" />
                <Button
                  onClick={() => setConfirmDeleteOpen(false)}
                  className="ml-2"
                >
                  Cancel
                </Button>
                <DangerButton
                  type="submit"
                  className="ml-2"
                  id="confirm-delete-button"
                >
                  Yep!
                </DangerButton>
              </Form>
            ) : (
              <DangerButton
                onClick={() => {
                  setConfirmDeleteOpen(!confirmDeleteOpen);
                }}
                id="delete-button"
              >
                <div className="flex">
                  <TrashIcon className="h-5 mr-1" />
                  Delete
                </div>
              </DangerButton>
            )}
          </div>
        }
      />
    </>
  );
}
