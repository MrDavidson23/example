import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { getEnv } from "~/services/env.service.server";
import { FeatureFlag } from "~/services/feature-flag.service.server";

export async function loader() {
  const origin = getEnv().REVYSE_UI_ORIGIN;
  const { featureFlagService } = await WebDIContainer();

  let robotText = "";
  if (featureFlagService.isEnabled(FeatureFlag.AllowRobots)) {
    robotText = `
		User-agent: *
		Allow: /

		Sitemap: ${origin}/sitemap.xml
		`;
  } else {
    // Disallow all robots from indexing the images and assets
    // other routes are allowed to be blocked by the noindex meta tag
    robotText = `
		User-agent: *
		Disallow: /images/

    User-agent: *
		Disallow: /assets/
		`;
  }
  return new Response(robotText, {
    status: 200,
    headers: {
      "Content-Type": "text/plain",
    },
  });
}
