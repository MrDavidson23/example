import { WebDIContainer } from "~/di-containers/web.di-container.server";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { z } from "zod";

export async function loader({ params }: LoaderFunctionArgs) {
  const { fileService } = await WebDIContainer();
  const validation = z.string().uuid().safeParse(params.id);

  if (!validation.success) {
    return new Response("Not found", {
      status: 404,
      headers: {
        "Content-Type": "text/html",
      },
    });
  }

  const { file, buffer } = await fileService.getFileAndBuffer(params.id!);

  if (!file || !params.id) {
    return new Response("Not found", {
      status: 404,
      headers: {
        "Content-Type": "text/html",
      },
    });
  }

  // Return the buffer as the response body and add as content-type the mime_type of the file
  return new Response(buffer, {
    status: 200,
    headers: {
      "Content-Type": file.mime_type,
    },
  });
}
