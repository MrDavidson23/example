import { useCallback, useMemo } from "react";
import {
  Link,
  useLoaderData,
  useNavigate,
  useSearchParams,
} from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { InformationCircleIcon } from "@heroicons/react/24/outline";
import { ContractStatus, LocationStatus } from "@prisma/client";
import { CTA } from "~/components/cta.component";
import { Table } from "~/components/intelligence/table.component";
import { Pagination } from "~/components/intelligence/pagination.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { every, isEmpty } from "lodash";
import PageTabs from "~/components/intelligence/page-tabs.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { Tooltip } from "~/components/tooltip.component";
import StatusChip from "~/components/status-chip.component";
import { WarningIcon } from "~/components/icons/warning.icon";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { CanDo } from "~/components/intelligence/can-do.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { IntelligenceFilter } from "~/components/intelligence/intelligence-filter.component";
import {
  getFiltersFromSearchParams,
  updateSearchParams,
} from "~/utils/filtering.utils";
dayjs.extend(utc);

const DEFAULT_PAGE_SIZE = 10;

const CONTRACT_WARNING_MESSAGE =
  "This contract is missing data. Finish configuring your contract to view important details.";

export async function loader({ request, params }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewContractsTable],
    }
  );

  const managerAccountId = account.id;
  const {
    contractService,
    vendorService,
    managerAccountService,
    locationService,
  } = await WebDIContainer();

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);

  const filtersFromSearchParams = getFiltersFromSearchParams(search, [
    "location_count_ranges",
    "vendors",
    "locations",
    "owners_or_approvers",
    "current_term_end_date",
  ]);

  console.log(filtersFromSearchParams);

  const page = parseInt(search.get("page") || "1");
  const perPage = parseInt(search.get("perPage") || String(DEFAULT_PAGE_SIZE));

  const locationsAssignedFilter = !isEmpty(
    filtersFromSearchParams.location_count_ranges
  )
    ? ((filtersFromSearchParams.location_count_ranges as string[]).map(
        range => {
          const [min, max] = range.split("-").map(Number);

          return [min, max ?? Number.MAX_SAFE_INTEGER];
        }
      ) as [number, number][])
    : undefined;

  const statusFilter =
    filtersFromSearchParams.status === "archived"
      ? [ContractStatus.Canceled]
      : [ContractStatus.Pending, ContractStatus.Active];

  const filters = {
    ...filtersFromSearchParams,
    location_count_ranges: locationsAssignedFilter,
    status: statusFilter,
  };

  const orderByString = search.getAll("orderBy");

  const orderBy = !isEmpty(orderByString)
    ? orderByString.map(value => {
        const [key, direction] = value.split(":");
        return { [key]: direction };
      })
    : [
        {
          current_term_end_date: "asc",
        },
      ];

  const { total_count, rows: contracts } =
    await managerAccountService.getContractsTableData(
      user,
      account,
      filters,
      perPage,
      (page - 1) * perPage,
      orderBy
    );

  const vendors = await vendorService.getVendorsIdAndName({
    user,
    account,
  });

  const ownersAndApprovers =
    await contractService.getContractOwnersAndApprovers({
      manager_account_vendor: {
        manager_account_id: managerAccountId,
      },
    });

  const locations = await locationService.getLocations(user, account, {
    status: [LocationStatus.Active, LocationStatus.Pending],
  });

  return json({
    user,
    account,
    contracts: contracts ?? [],
    contractsCount: total_count,
    vendors,
    locations,
    ownersAndApprovers,
    page,
  });
}

export default function Contracts() {
  const navigate = useNavigate();
  const {
    user,
    account,
    contracts,
    contractsCount,
    vendors,
    locations,
    ownersAndApprovers,
  } = useLoaderData<typeof loader>();
  const [searchParams, setSearchParams] = useSearchParams();

  const paginationParams = useMemo(
    () => ({
      page: searchParams.get("page") || "1",
      perPage: searchParams.get("perPage") || String(DEFAULT_PAGE_SIZE),
    }),
    [searchParams]
  );

  const status = useMemo(
    () => searchParams.get("status") ?? "active",
    [searchParams]
  );

  const totalPages = useMemo(
    () =>
      Math.ceil(
        contractsCount /
          (Number(paginationParams?.perPage) || DEFAULT_PAGE_SIZE)
      ),
    [contractsCount, paginationParams?.perPage]
  );
  const pageNumbers = useMemo(
    () => Array.from({ length: totalPages }, (_, i) => i + 1),
    [totalPages]
  );
  const resultsText = useMemo(
    () => `${contracts.length} out of ${contractsCount} results`,
    [contracts, contractsCount]
  );

  const onOrderBy = useCallback(
    (value: Record<string, string>) => {
      const newOrderBy = Object.entries(value).map(
        ([key, value]) => `${key}:${value}`
      );
      setSearchParams((oldSearchParams: any) => ({
        ...Object.fromEntries(oldSearchParams),
        orderBy: newOrderBy,
      }));
    },
    [setSearchParams]
  );

  const handlePageChange = (page: number) => {
    setSearchParams(oldSearchParams => {
      updateSearchParams(oldSearchParams, { page: String(page) });
      return oldSearchParams;
    });
  };

  const handleAddButton = () => {
    navigate(`/intelligence/${account.id}/contract/new/`);
  };

  const changeStatus = (status: "active" | "archived") => {
    setSearchParams(oldSearchParams => {
      updateSearchParams(oldSearchParams, {
        status: status === "active" ? undefined : status,
        page: "1",
      });
      return oldSearchParams;
    });
  };

  // Permissions
  const userCanManageContracts = canDoOnAccount(
    user,
    account,
    Permission.ManageContracts
  );
  const userCanViewContractDetails = canDoOnAccount(
    user,
    account,
    Permission.ViewContractDetails
  );

  return (
    <>
      <div className="space-y-8 pb-12">
        <PageTabs
          validationType="urlParams"
          options={[
            {
              currentParam: status,
              expectedResult: "active",
              onNavigate: () => changeStatus("active"),
              label: "Active Contracts",
            },
            {
              currentParam: status,
              expectedResult: "archived",
              onNavigate: () => changeStatus("archived"),
              label: "Archived Contracts",
            },
          ]}
          columns={2}
        ></PageTabs>
        <IntelligenceScreenHeader
          title={`All ${
            status == "archived" ? "archived" : "active"
          } contracts`}
          description={
            <>
              View and manage your
              {status == "archived" ? " archived" : " active"} contracts and the
              associated products and locations for each.
              {status !== "archived" &&
                userCanManageContracts &&
                " Click the “Add Contract” button to add a new contract."}
            </>
          }
          buttonsSlot={
            status !== "archived" && (
              <div id="add-contract-button">
                <CTA
                  type="button"
                  to={`/intelligence/${account.id}/contract/new`}
                  variant="coral-shadow"
                  className="lg:w-fit mt-3 lg:mt-0"
                >
                  Add Contract
                </CTA>
              </div>
            )
          }
        />
        <IntelligenceFilter
          modalFilters={[
            {
              label: "# Locations Assigned",
              name: "location_count_ranges",
              type: "MultiSelect",
              options: [
                { value: "1-5", label: "1-50" },
                { value: "5-50", label: "50-100" },
                { value: "100-200", label: "100-200" },
                { value: "200-500", label: "200-500" },
                { value: "500", label: "500+" },
              ],
            },
            {
              label: "Vendors",
              name: "vendors",
              type: "MultiAutocomplete",
              options: vendors.map(vendor => ({
                label: vendor.name,
                value: vendor.id,
              })),
            },
            {
              label: "Locations",
              name: "locations",
              type: "MultiAutocomplete",
              options: locations.map(location => ({
                label: location.name,
                value: location.id,
              })),
            },
            {
              label: "Contract Owner or Contract Approver",
              name: "owners_or_approvers",
              type: "MultiAutocomplete",
              options: ownersAndApprovers.map(name => ({
                label: name,
                value: name,
              })),
            },
            {
              label: "Current Term End Date",
              name: "current_term_end_date",
              type: "DateRange",
            },
          ]}
          handleOnSearchParams={true}
          filterBar={{
            inputPlaceholder: "Search contracts",
          }}
        />
        <div>
          <Table
            cols={[
              { name: "name", label: "Contract" },
              {
                name: "vendor_name",
                label: "Vendor",
                columnClassName: "font-normal",
                sortable: true,
              },
              {
                name: "current_term_end_date",
                label: "Current Term Ends",
                renderer: contract => {
                  const showWarningIcon =
                    contract.status === ContractStatus.Active &&
                    isEmpty(contract.current_term_end_date);
                  return (
                    <div
                      className={
                        dayjs.utc(contract?.current_term_end_date).toDate() <
                        new Date()
                          ? "text-red-500"
                          : ""
                      }
                    >
                      {contract.current_term_end_date
                        ? dayjs
                            .utc(contract.current_term_end_date)
                            .format("MMM D, YYYY")
                        : "No Data"}
                      {showWarningIcon && (
                        <WarningIcon
                          className="w-6 ml-1"
                          tooltip={CONTRACT_WARNING_MESSAGE}
                        />
                      )}
                    </div>
                  );
                },
              },
              {
                label: "Line Items",
                renderer: contract => {
                  const totalCount = contract.line_items_count;
                  const showWarningIcon =
                    contract.status === ContractStatus.Active && totalCount < 1;

                  return (
                    <div className="flex items-center space-x-2">
                      <div className="font-light">{totalCount}</div>
                      <CanDo
                        permission={
                          Permission.ViewContractProductsAndContractLineItemsTable
                        }
                      >
                        {(totalCount > 0 ||
                          contract.status != ContractStatus.Canceled) && (
                          <Link
                            to={`/intelligence/${account.id}/contract/${contract.id}/line-item`}
                            onClick={e => e.stopPropagation()}
                            className="font-medium underline text-sky-600"
                          >
                            {totalCount < 1 ? "Add" : "See Full List"}
                          </Link>
                        )}
                      </CanDo>
                      {showWarningIcon && (
                        <WarningIcon
                          className="w-6 ml-1"
                          tooltip={CONTRACT_WARNING_MESSAGE}
                        />
                      )}
                    </div>
                  );
                },
              },
              {
                renderer: contract => {
                  const allCorporateOnly =
                    contract.contract_line_items.length > 0 &&
                    every(contract.contract_line_items, "is_corporate_only");
                  if (allCorporateOnly) {
                    return <div className="font-normal">Corporate</div>;
                  }

                  const showWarningIcon =
                    contract.status === ContractStatus.Active &&
                    contract.contracted_locations_count === 0;
                  return (
                    <div className="flex items-center space-x-2">
                      <div className="font-light">
                        {contract.contracted_locations_count}
                      </div>
                      <CanDo permission={Permission.ViewContractLocations}>
                        {contract.contracted_locations_count > 0 && (
                          <Link
                            to={`/intelligence/${account.id}/contract/${contract.id}/contracted-locations/`}
                            onClick={e => e.stopPropagation()}
                            className="font-medium underline text-sky-600"
                          >
                            See Full List
                          </Link>
                        )}
                      </CanDo>
                      {showWarningIcon && (
                        <WarningIcon
                          className="w-6 ml-1"
                          tooltip={CONTRACT_WARNING_MESSAGE}
                        />
                      )}
                    </div>
                  );
                },
                label: "Contracted Locations",
              },
              {
                renderer: contract => {
                  const showWarningIcon =
                    contract.status === ContractStatus.Active &&
                    contract.annual_value === 0;
                  return (
                    <div className="flex items-center font-normal">
                      {contract.annual_value.toLocaleString(undefined, {
                        style: "currency",
                        currency: "USD",
                      })}
                      {showWarningIcon && (
                        <WarningIcon
                          className="w-6 ml-1"
                          tooltip={CONTRACT_WARNING_MESSAGE}
                        />
                      )}
                    </div>
                  );
                },
                name: "annual_value",
                label: (
                  <span>
                    Annual Contract Value
                    <Tooltip
                      position="bottom"
                      text="The current estimated annual value of the contract as configured today."
                      size="small"
                    >
                      <InformationCircleIcon className="h-5 ml-1" />
                    </Tooltip>
                  </span>
                ),
                sortable: true,
              },
              {
                label: "Status",
                name: "status",
                renderer: contract => (
                  <div className="flex flex-col justify-center items-center w-min">
                    <StatusChip
                      model="ContractStatus"
                      status={contract.status}
                      label={contract.status}
                    />
                    {contract.status === ContractStatus.Canceled &&
                      contract.canceled_at && (
                        <div className="text-xs mt-2">
                          {dayjs
                            .utc(contract.canceled_at)
                            .format("MMM D, YYYY")}
                        </div>
                      )}
                  </div>
                ),
              },
            ]}
            data={contracts}
            addButtonLabel="Add contract"
            showAddButton={userCanManageContracts && status == "active"}
            handleCallback={handleAddButton}
            showSelectBox={false}
            onClickRow={contract =>
              userCanViewContractDetails &&
              navigate(
                `/intelligence/${account.id}/contract/${contract.id}/details`
              )
            }
            onOrderBy={onOrderBy}
            allowSorting={true}
          ></Table>
          <Pagination
            resultsText={resultsText}
            pageNumbers={pageNumbers}
            currentPage={Number(paginationParams?.page) || 1}
            totalPages={totalPages}
            handleCallback={handlePageChange}
          ></Pagination>
        </div>
      </div>
    </>
  );
}
