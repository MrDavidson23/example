import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  MetaFunction,
} from "@remix-run/node";
import { useActionData, useLoaderData, Form } from "@remix-run/react";
import { getUser } from "~/utils/session.server";
import { json } from "@remix-run/node";
import { isEmpty, isNil } from "lodash";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import {
  assertAuthorized,
  assertAuthorizedOrRedirect,
} from "~/utils/assert.utils.server";
import { CheckCircleIcon } from "@heroicons/react/20/solid";
import { z } from "zod";
import { NonEmptyString } from "~/utils/validation.utils.server";
import { CrudTextField } from "~/components/form/crud-form.component";
import { issuesByKey } from "~/utils/form.utils.server";
import { Button } from "~/components/button.component";
import { Toast } from "~/components/toast.component";
import { castFormFields } from "~/utils/type.utils";
import { EyeIcon, EyeSlashIcon } from "@heroicons/react/24/outline";
import { useState } from "react";
import { tvField } from "~/utils/global-tailwind-variants.utils";

export const meta: MetaFunction = () => [
  { title: "Revyse | Profile" },
  {
    name: "description",
    content: "Update your profile",
  },
];

const ProfileForm = z.object({
  first_name: NonEmptyString,
  last_name: NonEmptyString,
  title: NonEmptyString,
  company_name: NonEmptyString,
  phone: NonEmptyString,
  email: z.string().email(),
});

const ResetPasswordForm = z
  .object({
    password: z
      .string()
      .min(6, "Password must be at least 6 characters long")
      .optional()
      .or(z.literal("")),
    passwordConfirmation: z.string().optional().or(z.literal("")),
  })
  .superRefine((data, ctx) => {
    if (data.password !== data.passwordConfirmation) {
      return ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Passwords do not match",
        path: ["passwordConfirmation"],
      });
    }
  });

export const action = async ({ request }: ActionFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));
  const { userService } = await WebDIContainer();

  const form = await request.formData();
  const intent = form.get("intent");

  if (intent === "resetPassword") {
    const fields = {
      password: form.get("password"),
      passwordConfirmation: form.get("passwordConfirmation"),
    };
    const validation = ResetPasswordForm.safeParse(fields);
    if (validation.success) {
      await userService.updateUserPassword(user.id, validation.data.password);

      return json({
        success: true,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      });
    }
    return json(
      {
        success: false,
        fields: castFormFields(fields),
        errors: issuesByKey(validation.error.issues),
      },
      { status: 400 }
    );
  } else {
    const fields = {
      first_name: form.get("first_name"),
      last_name: form.get("last_name"),
      email: form.get("email"),
      title: form.get("title"),
      company_name: form.get("company_name"),
      phone: form.get("phone"),
    };
    const validation = ProfileForm.safeParse(fields);

    if (validation.success) {
      // Check if the email is already in use
      const existingUsers = await userService.getUsers({
        where: {
          email: validation.data.email,
          id: { not: user.id },
        },
        take: 1,
      });

      if (!isEmpty(existingUsers)) {
        return json(
          {
            success: false,
            fields: castFormFields(fields),
            errors: issuesByKey([
              {
                path: ["email"],
                message: `User with email ${validation.data.email} already exists`,
              },
            ]),
          },
          { status: 400 }
        );
      }

      await userService.updateUserProfile({
        id: user.id,
        data: validation.data,
      });

      return json({
        success: true,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      });
    }

    return json(
      {
        success: false,
        fields: castFormFields(fields),
        errors: issuesByKey(validation.error.issues),
      },
      { status: 400 }
    );
  }
};

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorizedOrRedirect(!isNil(user));
  const { userService } = await WebDIContainer();

  const verifiedEmailToken = await userService.getEmailVerificationToken({
    user_id: user.id,
    verified_at: {
      not: null,
    },
    email: user.email,
  });

  return json({ user, verifiedEmailToken });
};

export default function ProfileRoute() {
  const actionData = useActionData<typeof action>();
  const { user, verifiedEmailToken } = useLoaderData<typeof loader>();

  const [showPassword, setShowPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword(prev => !prev);
  };
  return (
    <>
      <div className="flex min-h-full items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-5xl space-y-8">
          <div>
            <h1 className="text-3xl">Profile</h1>
          </div>
          {actionData !== undefined && (
            <Toast
              variant={actionData.success ? "success" : "error"}
              message={
                actionData.success
                  ? "Success!"
                  : "There were problems submitting your form. Please try again."
              }
            />
          )}
          <Form className="mt-8 space-y-6" method="post">
            <div className="-space-y-px rounded-md shadow-sm border border-gray-100 bg-white p-6 grid md:grid-cols-2 gap-6">
              <div>
                <CrudTextField
                  field={{
                    label: "First Name *",
                    name: "first_name",
                    errors: actionData?.errors?.first_name ?? [],
                    defaultValue:
                      actionData?.fields?.first_name ??
                      user.first_name ??
                      undefined,
                    type: "text",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    label: "Last Name *",
                    name: "last_name",
                    errors: actionData?.errors?.last_name ?? [],
                    defaultValue:
                      actionData?.fields?.last_name ??
                      user.last_name ??
                      undefined,
                    type: "text",
                  }}
                />
              </div>

              <div>
                <CrudTextField
                  field={{
                    label: "Job Title *",
                    name: "title",
                    errors: actionData?.errors?.title ?? [],
                    defaultValue:
                      actionData?.fields?.title ?? user.title ?? undefined,
                    type: "text",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    label: "Company Name *",
                    name: "company_name",
                    errors: actionData?.errors?.company_name ?? [],
                    defaultValue:
                      actionData?.fields?.company_name ??
                      user.company_name ??
                      undefined,
                    type: "text",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    label: (
                      <>
                        Work Email Address *{" "}
                        {verifiedEmailToken && (
                          <CheckCircleIcon className="text-green-500 h-5 inline"></CheckCircleIcon>
                        )}
                      </>
                    ),
                    name: "email",
                    errors: actionData?.errors?.email ?? [],
                    defaultValue:
                      actionData?.fields?.email ?? user.email ?? undefined,
                    type: "text",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    label: "Phone *",
                    name: "phone",
                    errors: actionData?.errors?.phone ?? [],
                    defaultValue:
                      actionData?.fields?.phone ?? user.phone ?? undefined,
                    type: "text",
                  }}
                />
              </div>
            </div>
            <div className="flex justify-end pr-6">
              <Button type="submit" id="save-profile">
                Save
              </Button>
            </div>
          </Form>
          <div>
            <h1 className="text-3xl">Reset Password</h1>
          </div>
          <Form className="mt-8 space-y-6" method="post">
            <div className="-space-y-px rounded-md shadow-sm border border-gray-100 bg-white p-6 grid md:grid-cols-2 gap-6">
              <input type="hidden" name="intent" value="resetPassword" />
              <div>
                <label
                  htmlFor="password"
                  className="text-sm font-medium mb-2 block"
                >
                  New Password
                </label>
                <div className="relative">
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    // required
                    className={tvField({
                      className: "shadow-sm relative",
                      error: (actionData?.errors?.password?.length ?? 0) > 0,
                    })}
                    placeholder="Password"
                    defaultValue={actionData?.fields?.password ?? undefined}
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 flex items-center pr-3 z-10"
                    onClick={togglePasswordVisibility}
                  >
                    {showPassword ? (
                      <EyeSlashIcon
                        className="h-5 w-5 text-gray-400 hover:text-gray-500"
                        aria-hidden="true"
                      />
                    ) : (
                      <EyeIcon
                        className="h-5 w-5 text-gray-400 hover:text-gray-500"
                        aria-hidden="true"
                      />
                    )}
                  </button>
                </div>
                <div className="text-red-500 mt-2 text-sm">
                  {actionData?.errors?.password?.join(", ")}
                </div>
              </div>
              <div>
                <label
                  htmlFor="passwordConfirmation"
                  className="text-sm font-medium mb-2 block"
                >
                  Confirm Password *
                </label>
                <input
                  id="password-confirmation"
                  name="passwordConfirmation"
                  type="password"
                  autoComplete="current-password"
                  className={tvField({
                    className: "shadow-sm relative",
                    error:
                      (actionData?.errors?.passwordConfirmation?.length ?? 0) >
                      0,
                  })}
                  placeholder="Confirm Password"
                  defaultValue={
                    actionData?.fields?.passwordConfirmation ?? undefined
                  }
                />
                <div
                  className="text-red-500 mt-2 text-sm"
                  id="errors-password-confirmation"
                >
                  {actionData?.errors?.passwordConfirmation?.join(", ")}
                </div>
              </div>
            </div>
            <div className="flex justify-end pr-6">
              <Button type="submit" id="save-password">
                Save
              </Button>
            </div>
          </Form>
        </div>
      </div>
    </>
  );
}
