import { useLoaderData, useNavigation } from "@remix-run/react";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  SerializeFrom,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { Permission } from "~/utils/intelligence-permission.utils";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { useEffect } from "react";
import type {
  File as PrismaFile,
  ManagerAccountVendorDocumentType,
} from "@prisma/client";
import {
  ManagerAccountVendorBusinessCriticalityRating,
  ManagerAccountVendorCybersecurityOptions,
  ManagerAccountVendorDataPrivacyOptions,
  ManagerAccountVendorInternalReviewStatus,
  ManagerAccountVendorRiskScore,
} from "@prisma/client";
import { castFormFields } from "~/utils/type.utils";
import { jsonWithError, redirectWithSuccess } from "remix-toast";
import { RiskForm } from "~/components/intelligence/vendors/risk-form.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const UpdateVendorRiskForm = z.object({
  vendor_risk_score: z.nativeEnum(ManagerAccountVendorRiskScore),
  business_criticality_rating: z.nativeEnum(
    ManagerAccountVendorBusinessCriticalityRating
  ),
  internal_review_status: z.nativeEnum(
    ManagerAccountVendorInternalReviewStatus
  ),
  data_privacy_prospects_residents: z.nativeEnum(
    ManagerAccountVendorDataPrivacyOptions
  ),
  data_privacy_customers_employees: z.nativeEnum(
    ManagerAccountVendorDataPrivacyOptions
  ),
  cybersecurity: z.nativeEnum(ManagerAccountVendorCybersecurityOptions),
});

export type VendorDocument = {
  id?: string;
  name?: string | null;
  type?: ManagerAccountVendorDocumentType | null;
  created_at?: string;
  file?: SerializeFrom<PrismaFile> | null;
  new_file?: File;
  status?: "uploading" | "uploaded" | "success";
};

async function updateVendorRisk({ form, id }: { form: FormData; id: string }) {
  const { managerAccountVendorService } = await WebDIContainer();

  const fields = {
    vendor_risk_score: form.get("vendor_risk_score"),
    business_criticality_rating: form.get("business_criticality_rating"),
    internal_review_status: form.get("internal_review_status"),
    data_privacy_prospects_residents: form.get(
      "data_privacy_prospects_residents"
    ),
    data_privacy_customers_employees: form.get(
      "data_privacy_customers_employees"
    ),
    cybersecurity: form.get("cybersecurity"),
  };

  const validation = UpdateVendorRiskForm.safeParse(fields);

  if (validation.success) {
    const accountVendor =
      await managerAccountVendorService.updateManagerAccountVendor(
        id,
        validation.data
      );

    return redirectWithSuccess(
      `/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}`,
      "Vendor risk information updated successfully"
    );
  }

  return jsonWithError(
    {
      success: false,
      accountVendor: null,
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE
  );
}
export async function action({ params, request }: ActionFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );
  const id = params.vendor_id as string;

  const form = await request.formData();

  return updateVendorRisk({ form, id });
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );
  const id = params.vendor_id as string;

  const { managerAccountVendorService } = await WebDIContainer();

  const managerAccountVendor =
    await managerAccountVendorService.getManagerAccountVendor(id, {
      vendor: true,
      manager_account_vendor_documents: {
        include: {
          file: true,
        },
        orderBy: {
          name: "asc",
        },
      },
    });

  return json({
    managerAccountVendor,
  });
}

export default function VendorRiskRoute() {
  const { managerAccountVendor } = useLoaderData<typeof loader>();

  const navigation = useNavigation();

  useEffect(() => {
    if (navigation.state == "idle") {
      window.scrollTo(0, 0);
    }
  }, [navigation.state]);

  return (
    <>
      <div className="space-y-8 pb-12">
        <IntelligenceScreenHeader
          crumbs={[
            {
              name: "All vendors",
              to: `/intelligence/${managerAccountVendor.manager_account_id}/vendors`,
            },
            {
              name: managerAccountVendor.vendor.name,
              to: `/intelligence/${managerAccountVendor.manager_account_id}/vendors/${managerAccountVendor.id}`,
            },
            {
              name: "Risk management",
              to: `/intelligence/${managerAccountVendor.manager_account_id}/contract/${managerAccountVendor.id}/info}`,
              active: true,
            },
          ]}
          title="Risk management"
          description={
            <>
              View and manage information related to vendor risk, data privacy,
              cybersecurity frameworks and audits, and upload any corresponding
              documentation for {managerAccountVendor.vendor.name}.
            </>
          }
        />
        <RiskForm
          navigation={navigation}
          accountVendor={managerAccountVendor}
        ></RiskForm>
      </div>
    </>
  );
}
