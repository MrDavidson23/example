import { Card } from "~/components/card.component";

import {
  Link,
  useLoaderData,
  useNavigate,
  useSearchParams,
} from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { IconCircle } from "~/components/circle-icon.component";
import {
  BriefcaseIcon,
  BuildingStorefrontIcon,
  DocumentTextIcon,
  ShoppingBagIcon,
} from "@heroicons/react/24/outline";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import {
  ArrowLeftIcon,
  ArrowRightIcon,
  InformationCircleIcon,
  XMarkIcon,
} from "@heroicons/react/20/solid";
import { Table } from "~/components/intelligence/table.component";
import { IntelligenceFilter } from "~/components/intelligence/intelligence-filter.component";
import {
  MULTIPLE_FILTER_SEPARATOR,
  type ModalFilters,
} from "~/components/intelligence/filters-modal.component";
import {
  getFiltersFromSearchParams,
  updateSearchParams,
} from "~/utils/filtering.utils";
import { useMemo } from "react";
import { Tooltip } from "~/components/tooltip.component";
import { Button } from "~/components/button.component";
import { isEmpty } from "lodash";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

const filterChipLabel = {
  searchQuery: "Search",
  locations: null,
  regions: "Region",
  owners: "Owner",
} as const;

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewSpendByLocation],
    }
  );

  const { managerAccountService, locationService } = await WebDIContainer();

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);

  const filters = getFiltersFromSearchParams(search, [
    "locations", // array field
    "regions", // array field
    "owners", // array field
  ]);

  const { locations: items, totals } =
    await managerAccountService.getSpendByLocationReportData(
      user,
      account,
      filters
    );

  const regions = await locationService.getLocationsRegions(account.id);
  const owners = await locationService.getLocationsOwners(account.id);
  const locations = await locationService.getLocations(user, account);

  return json({
    account,
    user,
    items,
    totals,
    locations: locations.map(location => ({
      value: location.id,
      label: location.name,
    })),
    regions: regions.map(region => ({
      value: region.region,
      label: region.region,
    })),
    owners: owners.map(owner => ({
      value: owner.owner_name,
      label: owner.owner_name,
    })),
  });
}

export default function SpendByLocation() {
  const { account, user, items, totals, locations, regions, owners } =
    useLoaderData<typeof loader>();
  const userCanViewLocationVendorsAndProducts = canDoOnAccount(
    user,
    account,
    Permission.ViewLocationVendorsAndProducts
  );
  const navigate = useNavigate();

  const [searchParams, setSearchParams] = useSearchParams();

  const currentFilters = useMemo(
    () => Object.fromEntries(searchParams.entries()),
    [searchParams]
  );

  const handleFilter = ({
    searchQuery,
    filters,
  }: {
    searchQuery?: string;
    filters?: ModalFilters;
  }) => {
    setSearchParams(oldSearchParams => {
      if (searchQuery !== undefined) {
        updateSearchParams(oldSearchParams, { searchQuery });
      }

      if (filters !== undefined) {
        updateSearchParams(oldSearchParams, filters);
      }

      return oldSearchParams;
    });
  };

  const filtersToDisplay = useMemo(() => {
    return Object.keys(currentFilters).flatMap(key => {
      const labelPrefix = filterChipLabel[key as keyof typeof filterChipLabel];
      if (labelPrefix === undefined) return []; // skip unknown filters
      const values = currentFilters[key].split(MULTIPLE_FILTER_SEPARATOR);
      return values.map(value => {
        const label = `${labelPrefix ? labelPrefix + ": " : ""}${
          key === "locations"
            ? locations.find(l => l.value === value)?.label ?? value
            : value
        }`;

        return { key, label, value };
      });
    });
  }, [currentFilters, locations]);

  const onRemoveValue = (key: string, value: string) => {
    setSearchParams(oldSearchParams => {
      const currentValues = Object.fromEntries(oldSearchParams.entries());
      const values = currentValues[key].split(MULTIPLE_FILTER_SEPARATOR);
      const newValues = values.filter(v => v !== value);
      const newSearchValue = newValues.join(MULTIPLE_FILTER_SEPARATOR);
      updateSearchParams(oldSearchParams, {
        [key]: newSearchValue,
      });
      return oldSearchParams;
    });
  };

  const clearFilters = () => {
    setSearchParams(oldSearchParams => {
      const currentValues = Object.fromEntries(oldSearchParams.entries());
      const newValues = Object.keys(currentValues).reduce(
        (acc, key) => ({ ...acc, [key]: "" }),
        {}
      );
      updateSearchParams(oldSearchParams, newValues);
      return oldSearchParams;
    });
  };

  return (
    <>
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "Reports",
            to: `/intelligence/${account.id}`,
            active: false,
          },
          {
            name: "Contract Insights by Location",
            to: `/intelligence/${account.id}/spend-by-location`,
            active: false,
          },
        ]}
        title={
          <>
            Contract Insights:
            <br /> Location Roll-Up Reports
          </>
        }
        description={
          <div className="w-10/12">
            Get a roll-up report of the vendors assigned to specific locations,
            regions, or ownership groups, and visualize how contracts and spend
            are distributed across your portfolio.
          </div>
        }
        buttonsSlot={
          <div className="w-max">
            <Link
              to={`/intelligence/${account.id}/`}
              className="w-full text-sky-600 flex items-center"
            >
              <ArrowLeftIcon className="h-5 mr-2" /> Back to dashboard
            </Link>
          </div>
        }
      />
      <div className="mt-10">
        <IntelligenceFilter
          modalFilters={[
            {
              label: "Location Name",
              name: "locations",
              type: "MultiAutocomplete",
              options: locations,
            },
            {
              label: "Region",
              name: "regions",
              type: "MultiAutocomplete",
              options: regions,
            },
            {
              label: "Owner",
              name: "owners",
              type: "MultiAutocomplete",
              options: owners,
            },
          ]}
          filterBar={{
            inputPlaceholder: "Search by location name",
          }}
          onFilter={handleFilter}
          currentFilters={currentFilters}
        />
      </div>
      <div>
        {!isEmpty(filtersToDisplay) && (
          <div className="flex flex-wrap space-x-2 my-6">
            {filtersToDisplay.map(({ key, label, value }) => (
              <div
                className="flex justify-center items-center w-max"
                key={value}
              >
                <div className="gap-x-2 w-full bg-transparent border-2 border-sky-500 rounded-full px-3 py-1.5 flex items-center text-sm">
                  <button
                    className="font-light"
                    onClick={() => onRemoveValue(key, value as string)}
                  >
                    <XMarkIcon className="h-5 text-sky-500" />
                  </button>
                  <div className="text-center w-full">{label}</div>
                </div>
              </div>
            ))}
            <Button
              color="transparent"
              className="font-normal"
              onClick={clearFilters}
            >
              Clear All Filters
            </Button>
          </div>
        )}
      </div>
      <div className="space-y-8 pb-10">
        <Card className="mt-10">
          <div className="flex flex-col md:flex-row p-10 items-start md:items-center justify-between gap-2 gap-y-4">
            <div className="flex gap-2 items-center">
              <IconCircle Icon={DocumentTextIcon} color="yellow" size="8" />
              <div>
                <div>Contracts</div>
                <div className="font-semibold">{totals.contracts_count}</div>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <IconCircle
                Icon={BuildingStorefrontIcon}
                color="yellow"
                size="8"
              />
              <div>
                <div>Vendors</div>
                <div className="font-semibold">{totals.vendors_count}</div>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <IconCircle Icon={ShoppingBagIcon} color="yellow" size="8" />
              <div>
                <div className="flex items-center">
                  Cost Per Unit
                  <Tooltip
                    text="Cost per unit is an annualized estimate of the contracted cost per unit for all line items assigned to the selected location(s)."
                    position="leftTop"
                    className="inline"
                  >
                    <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
                  </Tooltip>
                </div>
                <div className="font-semibold">
                  {totals.unit_annual_value?.toLocaleString(undefined, {
                    style: "currency",
                    currency: "USD",
                  }) ?? "--"}
                </div>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <IconCircle Icon={BriefcaseIcon} color="yellow" size="8" />
              <div>
                <div className="flex items-center">
                  Annual Value
                  <Tooltip
                    text="Annual value is an estimate of the contracted spend for all line items assigned to the selected location(s)."
                    position="leftTop"
                    className="inline"
                  >
                    <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
                  </Tooltip>
                </div>
                <div className="font-semibold">
                  {totals.annual_value?.toLocaleString(undefined, {
                    style: "currency",
                    currency: "USD",
                  }) ?? "--"}
                </div>
              </div>
            </div>
          </div>
        </Card>
        <Table
          variant="white"
          cols={[
            {
              label: "Location Name",
              name: "name",
            },
            {
              label: "Vendors",
              name: "vendors_count",
            },
            {
              label: "Contracts",
              name: "contracts_count",
            },
            {
              label: "Line Items",
              name: "line_items_count",
            },
            {
              label: (
                <>
                  Est. Per Unit
                  <Tooltip
                    text="Cost per unit is an annualized estimate of the contracted cost per unit for all line items assigned to the location."
                    position="bottom"
                    className="inline"
                  >
                    <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
                  </Tooltip>
                </>
              ),
              name: "unit_annual_value",
              renderer: location =>
                location.unit_annual_value?.toLocaleString(undefined, {
                  style: "currency",
                  currency: "USD",
                }) ?? "--",
            },
            {
              label: (
                <>
                  Est. Annual Value
                  <Tooltip
                    text="Annual value is an estimate of the contracted spend for all line items assigned to the selected location."
                    position="bottom"
                    className="inline"
                  >
                    <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
                  </Tooltip>
                </>
              ),
              name: "annual_value",
              renderer: location =>
                location.annual_value.toLocaleString(undefined, {
                  style: "currency",
                  currency: "USD",
                }),
            },
            {
              renderer: () => {
                return (
                  <div className="text-sky-500 text-bold">
                    <ArrowRightIcon className="h-5 w-5 ml-4" />
                  </div>
                );
              },
              label: "",
            },
          ]}
          showAddButton={false}
          data={items}
          showSelectBox={false}
          onClickRow={location =>
            userCanViewLocationVendorsAndProducts &&
            navigate(
              `/intelligence/${account.id}/locations/${location.id}/assigned-vendors`
            )
          }
        ></Table>
      </div>
    </>
  );
}
