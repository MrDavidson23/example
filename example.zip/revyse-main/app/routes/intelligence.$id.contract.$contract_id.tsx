import { Outlet, useLoaderData, useLocation } from "@remix-run/react";
import dayjs from "dayjs";
import PageTabs from "~/components/intelligence/page-tabs.component";
import utc from "dayjs/plugin/utc";
import {
  canDoSomeOnAccount,
  canDoSomeOnAccountOrThrow,
  type PermissionType,
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { first, flatMap } from "lodash";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { redirect, type LoaderFunctionArgs, json } from "@remix-run/node";
import { equalPathnames } from "~/utils/string.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account: managerAccount } = await verifyIntelligenceRequest(
    { request, params },
    {}
  );

  const contractId = params.contract_id;

  const { contractService } = await WebDIContainer();

  const options: {
    navigateTo: string;
    label: string;
    expectedResult: string;
    permissions: PermissionType[];
    id?: string;
  }[] = [
    {
      id: "details-tab",
      expectedResult: "details",
      navigateTo: `/intelligence/${managerAccount.id}/contract/${contractId}/details`,
      label: "Contract Details",
      permissions: [Permission.ViewContractDetails],
    },
    {
      id: "contract-line-items-tab",
      expectedResult: "line-item",
      navigateTo: `/intelligence/${managerAccount.id}/contract/${contractId}/line-item`,
      label: "Products and Line Items",
      permissions: [Permission.ViewContractProductsAndContractLineItemsTable],
    },
  ];

  const contract = await contractService.getContractById(contractId!);

  // The contracted locations won't show if the contract have a location
  if (!contract.location_id) {
    options.push({
      id: "contracted-locations-tab",
      expectedResult: "contracted-locations",
      navigateTo: `/intelligence/${managerAccount.id}/contract/${contractId}/contracted-locations`,
      label: "Contracted Locations",
      permissions: [Permission.ViewContractLocations],
    });
  }

  const url = new URL(request.url);

  const authorizedOptions = options.filter(option =>
    canDoSomeOnAccount(user, managerAccount, option.permissions)
  );

  // If the current url is any of the links
  if (options.some(option => equalPathnames(option.navigateTo, url.pathname))) {
    // If no permissions to any tab, throw 403
    canDoSomeOnAccountOrThrow(
      user,
      managerAccount,
      flatMap(options, "permissions")
    );

    // If no permissions to the requested tab, navigate to the first available
    if (
      !authorizedOptions.some(link =>
        equalPathnames(link.navigateTo, url.pathname)
      )
    ) {
      throw redirect(first(authorizedOptions)?.navigateTo || "/", 303);
    }
  }

  // If the contract is sensitive, only users with permission to view sensitive contracts can access it
  if (
    contract.is_sensitive &&
    !canDoOnAccount(user, managerAccount, Permission.ViewSensitiveContracts)
  ) {
    throw redirect(`/intelligence/${managerAccount.id}/contracts`, 303);
  }

  return json({
    options: authorizedOptions,
  });
}

export default function Contract() {
  const location = useLocation();

  const { options } = useLoaderData<typeof loader>();

  const formattedOptions = options.map(option => ({
    ...option,
    currentUrl: location.pathname,
  }));

  return (
    <>
      <div className="space-y-8 pb-12">
        {formattedOptions.length > 1 && (
          <PageTabs
            validationType="urlIncludes"
            options={formattedOptions}
            columns={formattedOptions.length}
          ></PageTabs>
        )}
        <Outlet />
      </div>
    </>
  );
}
