import type { Prisma } from "@prisma/client";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { useMemo } from "react";
import { Button } from "~/components/button.component";
import {
  CrudTable,
  type TableStateConfig,
} from "~/components/crud-table.component";
import { PortalPage } from "~/components/portal-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { getTableState } from "~/utils/table-state.server";

const PAGE_SIZE = 20;

export async function loader({ request }: LoaderFunctionArgs) {
  const { productService } = await WebDIContainer();

  const { pagination, orderBy, search } = getTableState({
    request,
    defaults: {
      pageSize: PAGE_SIZE,
      orderBy: "title:asc",
    },
  });

  const where: Prisma.ProductWhereInput = {
    OR: search
      ? [
          { title: { contains: search, mode: "insensitive" } },
          { vendor: { name: { contains: search, mode: "insensitive" } } },
        ]
      : undefined,
  };

  const products = (
    await productService.getProducts({
      where,
      orderBy,
      take: pagination.take,
      skip: pagination.skip,
    })
  ).map(product => ({
    ...product,
    mostRecentSubscription: product.subscriptions[0],
  }));

  const total = await productService.getProductsCount({ where });

  return json({
    products,
    total,
  });
}

export default function AdminProductsRoute() {
  const { products, total } = useLoaderData<typeof loader>();

  const tableStateConfig: TableStateConfig = useMemo(
    () => ({
      pagination: {
        useSearchParams: true,
        total,
      },
      orderBy: {
        useSearchParams: true,
      },
      search: {
        useSearchParams: true,
        resetPageOnSearch: true,
        inputPlaceholder: "Search by name or vendor",
      },
    }),
    [total]
  );

  return (
    <>
      <PortalPage
        crumbs={[
          {
            name: "Products",
            to: "/admin/products",
            active: true,
          },
        ]}
      >
        <>
          <div className="sm:flex sm:items-center">
            <div className="sm:flex-auto">
              <h1 className="text-base font-semibold leading-6 text-gray-900">
                Products
              </h1>
            </div>
            <div className="mt-4 sm:ml-16 sm:mt-0 sm:flex-none">
              <Button to="./new">Add</Button>
            </div>
          </div>
          <CrudTable
            cols={[
              { name: "title", label: "Name", sortable: true },
              {
                name: "mostRecentSubscription.stripe_price.product.name",
                label: "Plan",
              },
              {
                name: "mostRecentSubscription.status",
                label: "Status",
              },
              { name: "vendor.name", label: "Vendor", sortable: true },
              // { name: "primary_category.name", label: "Category" },
              {
                name: "created_at",
                label: "Created",
                type: "date",
                sortable: true,
              },
              {
                name: "approved_at",
                label: "Approved",
                type: "date",
                sortable: true,
              },
            ]}
            data={products}
            showAddButton={false}
            tableStateConfig={tableStateConfig}
          ></CrudTable>
        </>
      </PortalPage>
    </>
  );
}
