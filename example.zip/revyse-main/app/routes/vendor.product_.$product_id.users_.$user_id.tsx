import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import {
  Form,
  useActionData,
  useLoaderData,
  useNavigation,
} from "@remix-run/react";
import { json } from "@remix-run/node";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { assertAuthorized } from "../utils/assert.utils.server";
import { z } from "zod";
import { issuesByKey } from "../utils/form.utils.server";
import { getUser } from "../utils/session.server";
import { isNil } from "lodash";
import type { User } from "@prisma/client";
import { Role } from "@prisma/client";
import {
  CrudSelectField,
  CrudTextField,
  FormSection,
} from "../components/form/crud-form.component";
import { Button, DangerButton } from "../components/button.component";
import { userHasPermission } from "../utils/permission.utils";
import { PortalPage } from "~/components/portal-page.component";
import { TrashIcon } from "@heroicons/react/24/outline";
import { useEffect, useRef, useState } from "react";
import Stripe from "stripe";
import { getEnv } from "~/services/env.service.server";
import { jsonWithError, redirectWithSuccess } from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { castFormFields } from "~/utils/type.utils";

type JsonData = {
  fields?: Record<string, string | null> | null;
  success?: boolean;
  errors: Record<string, string[] | null>;
};

const roleOptionsForOwners = [
  { label: "Owner", value: Role.OWNER },
  { label: "Editor", value: Role.EDITOR },
  { label: "Admin", value: Role.ADMIN },
];

const roleOptionsForNonOwners = [
  { label: "Editor", value: Role.EDITOR },
  { label: "Admin", value: Role.ADMIN },
];

const UserForm = z.object({
  role: z.string().min(1, "Role is required"),
  id: z.string(),
});

const NewUserForm = z.object({
  email: z.string().email().min(1, "Email is required"),
  role: z.string().min(1, "Role is required"),
  resource_id: z.string(),
});

async function deleteAction({
  id,
  resourceId,
  user,
}: {
  id: string | undefined;
  resourceId: string | undefined;
  user: User;
}) {
  const { productSubscriptionService } = await WebDIContainer();

  const stripe = new Stripe(getEnv().STRIPE_SECRET_KEY, {
    apiVersion: "2022-11-15",
  });

  const userRole = await productSubscriptionService.getResourceUserRole({
    filters: { id },
  });

  if (userRole?.user_id === user.id) {
    return jsonWithError<JsonData>(
      {
        success: false,
        errors: {} as { [key: string]: string[] },
        fields: null,
      },
      "You cannot delete your own user role",
      { status: 400 }
    );
  }

  const owners = await productSubscriptionService.getSubscriptionUsers(
    resourceId
  );

  if (userRole?.role === Role.OWNER) {
    if (owners.length > 1) {
      await productSubscriptionService.deleteSubscriptionRole(id);
      const nextOldestOwner = owners.find(owner => owner.id !== id);

      if (nextOldestOwner) {
        const subscription = await stripe.subscriptions.retrieve(
          userRole.product_subscription?.stripe_id as string
        );
        await stripe.customers.update(subscription.customer as string, {
          email: nextOldestOwner.user.email,
        });
      }

      return redirectWithSuccess(
        `/vendor/product/${resourceId}/users/`,
        "User role deleted"
      );
    } else {
      return jsonWithError<JsonData>(
        {
          success: false,
          errors: {} as { [key: string]: string[] },
          fields: null,
        },
        "You cannot delete the only owner user role associated with this product",
        { status: 400 }
      );
    }
  }
  await productSubscriptionService.deleteSubscriptionRole(id);
  return redirectWithSuccess(
    `/vendor/product/${resourceId}/users/`,
    "User role deleted"
  );
}

async function createAction({
  resourceId,
  form,
}: {
  resourceId: string | undefined;
  form: FormData;
}) {
  const { productSubscriptionService } = await WebDIContainer();

  const email = form.get("email") as string;
  const fields = {
    email: email.trim(),
    role: form.get("role"),
    resource_id: resourceId,
  };

  const validation = NewUserForm.safeParse(fields);

  if (validation.success) {
    const response = await productSubscriptionService.handleSubscriptionRole(
      null,
      validation.data.resource_id,
      validation.data.email,
      validation.data.role
    );

    if (response.success) {
      return redirectWithSuccess(
        `/vendor/product/${resourceId}/users/`,
        "User invitation sent"
      );
    } else {
      return jsonWithError<JsonData>(
        {
          fields: castFormFields(fields),
          success: false,
          errors: {
            email: [
              "An user role with this email already exists for the selected product listing",
            ],
          } as { [key: string]: string[] },
        },
        DEFAULT_FORM_ERROR_MESSAGE,
        { status: 400 }
      );
    }
  }
  return jsonWithError<JsonData>(
    {
      success: false,
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
}

async function updateAction({
  id,
  resourceId,
  form,
  user,
}: {
  id: string | undefined;
  resourceId: string;
  form: FormData;
  user: User;
}) {
  const { productSubscriptionService } = await WebDIContainer();

  const userRole = await productSubscriptionService.getResourceUserRole({
    filters: { id },
  });
  const fields = {
    role: form.get("role"),
    id: form.get("id"),
  };

  if (userRole && userRole.user_id === user.id) {
    return jsonWithError<JsonData>(
      {
        success: false,
        errors: {
          role: ["You cannot change your own role"],
        } as { [key: string]: string[] },
        fields: castFormFields(fields),
      },
      DEFAULT_FORM_ERROR_MESSAGE,
      { status: 400 }
    );
  }

  const validation = UserForm.safeParse(fields);
  const owners = await productSubscriptionService.getSubscriptionOwnerUsers(
    resourceId
  );

  if (validation.success) {
    if (
      userRole &&
      userRole.role === Role.OWNER &&
      validation.data.role !== Role.OWNER &&
      !(owners.length > 1)
    ) {
      return jsonWithError<JsonData>(
        {
          success: false,
          errors: {
            role: [
              "You cannot change the role of the only owner associated with this product",
            ],
          } as { [key: string]: string[] },
          fields: castFormFields(fields),
        },
        DEFAULT_FORM_ERROR_MESSAGE,
        { status: 400 }
      );
    }
    await productSubscriptionService.handleSubscriptionRole(
      validation.data.id,
      resourceId,
      user.email,
      validation.data.role
    );

    return redirectWithSuccess(
      `/vendor/product/${resourceId}/users/${id}`,
      "User role updated"
    );
  }

  return jsonWithError<JsonData>(
    {
      success: false,
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
}

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const form = await request.formData();
  const id = params.user_id;
  const resourceId = params.product_id!;
  const user = await getUser(request);
  assertAuthorized(!isNil(user));

  const intent = form.get("intent");

  if (intent === "delete") {
    return deleteAction({
      id,
      resourceId,
      user,
    });
  } else if (id === "new") {
    return createAction({
      resourceId,
      form: form,
    });
  } else {
    return updateAction({
      id,
      resourceId,
      form: form,
      user,
    });
  }
};

export const loader = async ({ params, request }: LoaderFunctionArgs) => {
  const id = params.user_id;
  const resourceId = params.product_id;
  const { productSubscriptionService } = await WebDIContainer();
  const userRole =
    id === "new"
      ? {
          id: "new",
          user: {
            email: null,
          },
          role: null,
          resource_id: resourceId,
        }
      : await productSubscriptionService.getResourceUserRole({
          filters: { id },
        });

  if (!userRole) {
    throw new Response("Not found", { status: 404 });
  }
  const user = await getUser(request);

  const loggedInUserRole = user?.user_roles.find(
    r => r.resource_id === userRole?.resource_id
  )?.role;

  return json({ id, userRole, loggedInUserRole });
};

export default function VendorUserRoute() {
  const actionData = useActionData<typeof action>();
  let navigation = useNavigation();
  let $form = useRef<HTMLFormElement>(null);
  const { id, userRole, loggedInUserRole } = useLoaderData<typeof loader>();
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  const roleOptions = userHasPermission(loggedInUserRole, "assign_new_owners")
    ? roleOptionsForOwners
    : roleOptionsForNonOwners;

  useEffect(
    function resetFormOnSuccess() {
      if (navigation.state === "idle" && actionData?.success) {
        $form.current?.reset();
      }
    },
    [navigation.state, actionData]
  );

  return (
    <PortalPage
      crumbs={[
        {
          name: "Users",
          to: `/vendor/product/${userRole?.resource_id}/users/`,
          active: true,
        },
      ]}
      buttonsSlot={
        id !== "new" &&
        (confirmDeleteOpen ? (
          <Form className="flex justify-between items-center" method="post">
            Are you sure you want to delete this user role?
            <input type="hidden" name="intent" value="delete" />
            <Button
              onClick={() => setConfirmDeleteOpen(false)}
              className="ml-2 bg-gray-300 hover:bg-gray-400"
            >
              Cancel
            </Button>
            <DangerButton type="submit" className="ml-2">
              Yep!
            </DangerButton>
          </Form>
        ) : (
          <DangerButton
            onClick={() => {
              setConfirmDeleteOpen(!confirmDeleteOpen);
            }}
          >
            <div className="flex">
              <TrashIcon className="h-5 mr-1" />
              Delete
            </div>
          </DangerButton>
        ))
      }
    >
      <Form method="post" ref={$form}>
        <FormSection
          key={userRole?.resource_id}
          title={`${id === "new" ? "Invite new user" : "Edit user role"}`}
          subtitle={
            <div className="flex flex-col text-xs space-y-2">
              <div>
                <b>Owner:</b> Manage subscription, assign all user types, and
                edit listings
              </div>
              <div>
                <b>Admin:</b> Assign admin or editor users, and edit listings
              </div>
              <div>
                <b>Editor:</b> Edit listings
              </div>
            </div>
          }
        >
          <div className="col-span-6">
            <input type="hidden" name="id" value={userRole.id} />
            <div>
              {id === "new" && (
                <CrudTextField
                  field={{
                    label: "Email",
                    name: "email",
                    errors: actionData?.errors.email ?? [],
                    defaultValue:
                      actionData?.fields?.email ??
                      userRole.user.email ??
                      undefined,
                    type: "text",
                  }}
                />
              )}
              <CrudSelectField
                field={{
                  label: "Role",
                  name: "role",
                  errors: actionData?.errors.role ?? [],
                  defaultValue:
                    (actionData?.fields?.role as Role) ??
                    userRole.role ??
                    undefined,
                  type: "select",
                  options: roleOptions,
                }}
              />
            </div>
          </div>
        </FormSection>
        <div className="flex justify-end pr-6">
          <Button id="send-invitation" type="submit">
            Send Invitation
          </Button>
        </div>
      </Form>
    </PortalPage>
  );
}
