import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { redirect } from "@remix-run/node";
import { jsonWithSuccess } from "remix-toast";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assertAuthenticatedOrRedirect } from "~/utils/auth.utils.server";

async function setHelpful({
  request,
  params: { id },
}: {
  request: Request;
  params: { id: string | undefined };
}) {
  const user = await assertAuthenticatedOrRedirect(request);
  const { reviewService } = await WebDIContainer();
  const { review, helpful } = await reviewService.toggleReviewHelpful({
    userId: user.id,
    reviewId: id!,
  });
  return { review, helpful };
}

export async function action({ request, params: { id } }: ActionFunctionArgs) {
  const { helpful } = await setHelpful({ request, params: { id } });
  return jsonWithSuccess(
    { success: true },
    helpful
      ? "Review marked as helpful. Thank you for your feedback!"
      : "Review unmarked as helpful"
  );
}

export async function loader({ request, params: { id } }: LoaderFunctionArgs) {
  const { review } = await setHelpful({ request, params: { id } });
  return redirect(`/products/${review.product.slug}/reviews`);
}
