import { Card } from "~/components/card.component";
import {
  BriefcaseIcon,
  BuildingStorefrontIcon,
  DocumentTextIcon,
} from "@heroicons/react/24/outline";
import {
  Link,
  useLoaderData,
  useNavigate,
  useSearchParams,
} from "@remix-run/react";
import { ArrowRightIcon, ChevronRightIcon } from "@heroicons/react/20/solid";
import { useCallback } from "react";
import StarRating from "~/components/star-rating.component";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { ResidentLifecyclePhase } from "@prisma/client";
import { IconCircle } from "~/components/circle-icon.component";
import { Table } from "~/components/intelligence/table.component";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { Toggle } from "~/components/toggle.component";
import dayjs from "dayjs";
import { isEmpty } from "lodash";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { ResidentLifecycleCard } from "~/components/intelligence/reports/resident-lifecycle-card.component";
import { SpendInsightsByDepartment } from "~/components/intelligence/reports/spend-insights-by-department.component";

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewDashboard],
    }
  );

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const includeMonthToMonthContracts = Boolean(
    Number(search.get("monthToMonthContracts") || "0")
  );

  const { managerAccountService } = await WebDIContainer();

  const spend = await managerAccountService.getSpend(user, account, {
    byDepartment: true,
    byRLP: true,
  });

  return json({
    user,
    account,
    spend,
    totals: await managerAccountService.getTotalsForAccount(user, account),
    numProductsByResidentLifecycle:
      await managerAccountService.getProductsByResidentLifecyclePhase(
        user,
        account
      ),
    contractsUpForRenewal:
      await managerAccountService.getUpcomingContractRenewals(
        user,
        account,
        includeMonthToMonthContracts,
        10
      ),
  });
}

export default function Dashboard() {
  const {
    user,
    account,
    totals,
    spend,
    numProductsByResidentLifecycle,
    contractsUpForRenewal,
  } = useLoaderData<typeof loader>();
  const navigate = useNavigate();

  const [searchParams, setSearchParams] = useSearchParams();

  const handleViewMonthToMonthContractsChange = useCallback(
    (value: Boolean) => {
      if (value) {
        setSearchParams(oldParams => ({
          ...Object.fromEntries(oldParams),
          monthToMonthContracts: "1",
        }));
      } else {
        setSearchParams(oldParams => {
          const newParams = new URLSearchParams(Object.fromEntries(oldParams));
          newParams.delete("monthToMonthContracts");
          return Object.fromEntries(newParams);
        });
      }
    },
    [setSearchParams]
  );

  // Permissions
  const userCanViewSpendByResidentPhase = canDoOnAccount(
    user,
    account,
    Permission.ViewSpendByResidentPhase
  );
  const userCanViewSpendByDepartment = canDoOnAccount(
    user,
    account,
    Permission.ViewSpendByDepartment
  );
  const userCanViewContractsTable = canDoOnAccount(
    user,
    account,
    Permission.ViewContractsTable
  );
  const userCanViewContractDetails = canDoOnAccount(
    user,
    account,
    Permission.ViewContractDetails
  );

  const residentLifecyclePhasesToShow = [
    ResidentLifecyclePhase.Shopping,
    ResidentLifecyclePhase.Touring,
    ResidentLifecyclePhase.Application,
    ResidentLifecyclePhase.Leasing,
    ResidentLifecyclePhase.MoveIn,
    ResidentLifecyclePhase.Residency,
    ResidentLifecyclePhase.Retention,
    ResidentLifecyclePhase.MoveOut,
  ];

  return (
    <div className="flex flex-col gap-8">
      <div className="flex justify-between gap-2 align-top">
        <h2 className="font-semibold text-xl md:text-3xl">
          Welcome to Revyse Vendor Intelligence, {user.first_name}!
        </h2>
      </div>
      <Card>
        <div className="flex align-middle lg:p-4 flex-wrap items-center justify-center lg:justify-evenly gap-4 gap-y-6">
          <div className="flex gap-6 items-center">
            <IconCircle Icon={BriefcaseIcon} color="yellow" size="16" />

            <div className="text-lg lg:text-xl text-montserrat">
              <div>You're currently managing</div>
              <div className="font-semibold text-xl lg:text-2xl">
                {spend.total.toLocaleString(undefined, {
                  style: "currency",
                  currency: "USD",
                })}
              </div>
              <div>in contracted spend.</div>
            </div>
          </div>
          <div className="flex gap-2 items-center">
            <IconCircle Icon={DocumentTextIcon} color="yellow" size="8" />
            <div>
              <div>Contracts</div>
              <div className="font-semibold">{totals?.contracts}</div>
            </div>
          </div>
          <div className="flex gap-2 items-center">
            <IconCircle Icon={BuildingStorefrontIcon} color="yellow" size="8" />
            <div>
              <div>Vendors</div>
              <div className="font-semibold">{totals?.vendors}</div>
            </div>
          </div>
        </div>
      </Card>

      <div>
        <div className="flex justify-between items-center">
          <h3 className="text-lg md:text-2xl flex-grow">
            Contract Insights by Resident Lifecycle Phase
          </h3>
          <Link
            to={`/intelligence/${account.id}/spend-by-resident-phase`}
            className="text-sm lg:text-base text-sky-600 align-middle flex-grow-0 w-28 md:w-auto"
            id="resident-lifecycle-view-all-detail"
          >
            View all details{" "}
            <ArrowRightIcon className="inline h-4"></ArrowRightIcon>
          </Link>
        </div>
        <div className="grid md:grid-cols-4 gap-6 mt-4 ">
          {residentLifecyclePhasesToShow.map((phase, i) => (
            <ResidentLifecycleCard
              key={phase}
              phase={phase}
              annualSpend={spend.byRLP[phase] ?? 0}
              totalProducts={
                numProductsByResidentLifecycle
                  ? numProductsByResidentLifecycle[phase].length
                  : 0
              }
              renderViewLink={userCanViewSpendByResidentPhase}
              account_id={account.id}
            >
              <div
                className={`absolute top-1/2 -right-6
                md:${i > 0 && (i + 1) % 4 == 0 ? "hidden" : "block"}
                ${i > 0 && (i + 1) % 2 == 0 ? "hidden" : "block"}`}
              >
                <ChevronRightIcon className="h-5"></ChevronRightIcon>
              </div>
            </ResidentLifecycleCard>
          ))}
        </div>
      </div>

      <div>
        <div className="flex justify-between items-center">
          <h3 className="text-lg md:text-2xl flex-grow [text-wrap:pretty]">
            Contract Insights by Department
          </h3>
          {userCanViewSpendByDepartment && (
            <Link
              to={`/intelligence/${account.id}/spend-by-department`}
              className="text-sm lg:text-base text-sky-600 w-28 md:w-auto"
              id="spend-by-department-view-all-details"
            >
              View all details{" "}
              <ArrowRightIcon className="inline h-4 ml-1"></ArrowRightIcon>
            </Link>
          )}
        </div>
        <Card className="p-6 mt-4">
          <SpendInsightsByDepartment
            data={
              spend.byDepartment
                ? Object.entries(spend.byDepartment).map(([dept, spend]) => ({
                    id: !isEmpty(dept) ? dept : "Uncategorized",
                    label: !isEmpty(dept) ? dept : "Uncategorized",
                    value: spend,
                  }))
                : []
            }
          />
        </Card>
      </div>

      <div>
        <div className="flex justify-between items-center">
          <h3 className="text-lg md:text-2xl flex-grow [text-wrap:pretty]">
            Your Contracts: Upcoming Renewals & Ratings
          </h3>
          <div className="mr-5 md:flex items-center space-x-3 hidden">
            <Toggle
              checked={searchParams.get("monthToMonthContracts") === "1"}
              onChange={handleViewMonthToMonthContractsChange}
            />
            <span className="text-sm">Show month-to-month contracts</span>
          </div>
          {userCanViewContractsTable && (
            <Link
              to={`/intelligence/${account.id}/contracts`}
              className="text-sm lg:text-base text-sky-600 w-28 md:w-auto"
              id="contracts-view-all-link"
            >
              All your contracts{" "}
              <ArrowRightIcon className="inline h-4 ml-1"></ArrowRightIcon>
            </Link>
          )}
        </div>
        <div className="flex md:hidden w-full justify-end mt-4">
          <div className="mr-5 flex items-center space-x-3">
            <Toggle
              checked={searchParams.get("monthToMonthContracts") === "1"}
              onChange={handleViewMonthToMonthContractsChange}
            />
            <span className="text-sm">Show month-to-month contracts</span>
          </div>
        </div>

        <div className="mt-4">
          <Table
            onClickRow={row => {
              userCanViewContractDetails &&
                navigate(
                  `/intelligence/${account.id}/contract/${row.id}/details`
                );
            }}
            showSelectBox={false}
            showAddButton={false}
            variant="white"
            cols={[
              { label: "Vendor", name: "vendor" },
              {
                label: "Contract",
                name: "contract_name",
                hideSmallScreen: true,
              },
              {
                label: "Products",
                renderer: value => {
                  return (
                    <div>
                      {Object.values(value.products).map(p => (
                        <div
                          className="block w-40 md:w-auto truncate"
                          key={`title-${p.id}`}
                        >
                          {p.title}
                        </div>
                      ))}
                    </div>
                  );
                },
              },
              {
                label: "Revyse Ratings",
                renderer: value => (
                  <div>
                    {Object.values(value.products).map(p => (
                      <StarRating key={`rating-${p.id}`} rating={p.avgReview} />
                    ))}
                  </div>
                ),
                hideSmallScreen: true,
              },
              {
                label: "Current Term Ends",
                renderer: value => {
                  const date = value.renewalDate
                    ? dayjs.utc(value.renewalDate).format("MMM D, YYYY")
                    : "--";
                  const beforeToday = value.renewalDate
                    ? dayjs.utc(value.renewalDate).isBefore(new Date(), "date")
                    : false;

                  return (
                    <span className={beforeToday ? "text-red-500" : ""}>
                      {date}
                    </span>
                  );
                },
              },
              {
                label: "",
                renderer: () => <ArrowRightIcon className="h-4 text-sky-600" />,
                hideSmallScreen: true,
              },
            ]}
            data={
              contractsUpForRenewal
                ? contractsUpForRenewal.map(contract => {
                    const products: Record<
                      string,
                      (typeof contract)["contract_line_items"][number]["contract_line_item_products"][number]["product"]
                    > = {};
                    contract.contract_line_items.forEach(contractLineItem => {
                      contractLineItem.contract_line_item_products.forEach(
                        cp => {
                          products[cp.product.id] = cp.product;
                        }
                      );
                    });
                    return {
                      id: contract.id,
                      vendor: contract.manager_account_vendor.vendor.name,
                      contract_name: contract.name,
                      renewalDate: contract.current_term_end_date,
                      contract,
                      products,
                    };
                  })
                : []
            }
          ></Table>
        </div>
      </div>
    </div>
  );
}
