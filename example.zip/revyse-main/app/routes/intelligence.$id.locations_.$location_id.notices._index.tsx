import { useState } from "react";
import { json } from "@remix-run/node";
import { Link, useLoaderData, useNavigate } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { CTA } from "~/components/cta.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Permission } from "~/utils/intelligence-permission.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { IntelligenceFilter } from "~/components/intelligence/intelligence-filter.component";
import { Table } from "~/components/intelligence/table.component";
import { getFiltersFromSearchParams } from "~/utils/filtering.utils";
import { BuildingOfficeIcon, XCircleIcon } from "@heroicons/react/24/outline";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { WizardModal } from "~/components/modals/wizard-modal.component";
import { GridSelect } from "~/components/form/grid-select.component";
import { CheckCircleIcon, ArrowRightIcon } from "@heroicons/react/24/solid";
import { LocationNoticeStatus } from "@prisma/client";
import {
  LocationNoticeLinkPrefixes,
  LocationNoticeType,
} from "~/utils/location-notice.utils";
import { CanDo } from "~/components/intelligence/can-do.component";
import { LocationNoticeTypeLabels } from "~/utils/constants.utils";
dayjs.extend(utc);

export async function loader({ params, request }: LoaderFunctionArgs) {
  const locationId = params.location_id!;
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewLocationNotices],
      locationId: locationId,
    }
  );

  const {
    managerAccountVendorService,
    locationNoticeService,
    locationService,
  } = await WebDIContainer();
  const managerAccountId = account.id;

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);

  const filters = getFiltersFromSearchParams(search, [
    "status", // array field
    "vendors", // array field
    "type", // array field
    "sent_date", // date range field
  ]);

  const items = await locationNoticeService.getLocationNotices(
    user,
    account,
    locationId,
    filters
  );

  const location = await locationService.getLocation(locationId);

  if (!location) {
    throw new Response("Location not found", { status: 404 });
  }

  const vendors = await managerAccountVendorService.getVendorOptions(
    managerAccountId,
    user,
    {
      locationId: location.id,
    }
  );

  return json({
    user,
    account,
    location,
    vendors: vendors.map(vendor => ({
      value: vendor.id,
      label: vendor.name,
    })),
    items,
  });
}

export default function LocationNotices() {
  const { account, vendors, location, items } = useLoaderData<typeof loader>();

  const navigate = useNavigate();

  const [openCreateNoticeWizard, setOpenCreateNoticeWizard] = useState(false);

  return (
    <>
      <CanDo permission={Permission.ManageLocationNotices} locationId={location.id}>
        <WizardModal
          isOpen={openCreateNoticeWizard}
          onClose={() => setOpenCreateNoticeWizard(false)}
          size="medium"
          steps={[
            {
              id: "step-1",
              title: "Alright, let's create a new notice.",
              subtitle: `Choose the notice type that you’ll be sending for ${location.name}.`,
              body: (
                <>
                  <div className="[text-wrap:pretty]">
                    If you are canceling services with a single vendor, select
                    “Service Termination Notice.” If you are disposing of{" "}
                    {location.name} and need to cancel services with multiple
                    vendors, select “Location Disposition Notice.”
                  </div>
                  <div className="h-36 mt-8">
                    <GridSelect
                      name="notice_type"
                      columns={2}
                      options={[
                        {
                          label: "Service Termination Notice",
                          value:
                            LocationNoticeLinkPrefixes[
                              LocationNoticeType.LocationServiceTermination
                            ],
                          icon: (
                            <XCircleIcon className="h-[60px] w-[60px] text-red-500" />
                          ),
                        },
                        {
                          label: "Location Disposition Notice",
                          value:
                            LocationNoticeLinkPrefixes[
                              LocationNoticeType.LocationNoticeDisposition
                            ],
                          icon: (
                            <BuildingOfficeIcon className="h-[60px] w-[60px] text-sky-500" />
                          ),
                        },
                      ]}
                    />
                  </div>
                </>
              ),
              ctas: {
                primary: {
                  label: "Continue",
                  onClick: formValues => {
                    return {
                      toLink: `/intelligence/${account.id}/locations/${location.id}/notices/new/${formValues.notice_type}/details`,
                    };
                  },
                },
                secondary: {
                  label: "Return to all notices",
                },
              },
            },
          ]}
        ></WizardModal>
      </CanDo>
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
          },
          {
            name: "Notices",
            to: `/intelligence/${account.id}/locations/${location.id}/notices`,
            active: true,
          },
        ]}
        title={
          <>
            Notices: <br /> {location.name}
          </>
        }
        description={`View notices sent on behalf of ${location.name}. To view the details of a notice, click on the corresponding row. 
          To create and send a new notice, click “Create New Notice.”`}
        buttonsSlot={
          <CanDo permission={Permission.ManageLocationNotices} locationId={location.id}>
            <CTA onClick={() => setOpenCreateNoticeWizard(true)}>
              Create New Notice
            </CTA>
          </CanDo>
        }
      />
      <IntelligenceFilter
        filterBar={{
          inputPlaceholder: "Search contract name or vendor name",
        }}
        handleOnSearchParams={true}
        modalFilters={[
          {
            type: "MultiSelect",
            name: "status",
            label: "Notice Status",
            options: [
              { value: "sent", label: "Sent" },
              { value: "incomplete", label: "Incomplete" },
            ],
          },
          {
            type: "MultiAutocomplete",
            name: "vendors",
            label: "Vendors",
            options: vendors,
          },
          {
            type: "MultiSelect",
            name: "type",
            label: "Notice Type",
            options: Object.values(LocationNoticeType).map(status => ({
              value: status,
              label: LocationNoticeTypeLabels[status],
            })),
          },
          {
            type: "DateRange",
            name: "sent_date",
            label: "Notice Sent Date Range",
          },
        ]}
      />
      <div>
        <h3 className="text-lg font-semibold my-3">Notice Activity</h3>
        <Table
          cols={[
            {
              label: "Activity",
              name: "name",
              columnClassName: "whitespace-normal",
            },
            {
              label: "Date of Activity",
              name: "status_updated_at",
              type: "date",
            },
            {
              label: "Vendors",
              renderer: (item: (typeof items)[number]) => {
                if ("location_notice_recipients" in item) {
                  if (item.location_notice_recipients?.length === 0) {
                    return "-";
                  }
                  if (item.location_notice_recipients.length === 1) {
                    return item.location_notice_recipients[0]
                      .manager_account_vendor.vendor.name;
                  }
                  return `${item.location_notice_recipients.length} out of ${vendors.length}`;
                } else {
                  return item.manager_account_vendor.vendor.name;
                }
              },
            },
            {
              label: "Termination Date",
              name: "termination_date",
              renderer: (item: (typeof items)[number]) =>
                dayjs.utc(item.termination_date).format("M/D/YYYY"),
            },
            {
              label: "",
              renderer: (item: (typeof items)[number]) => {
                const step = item.step?.toLowerCase();
                const type = LocationNoticeLinkPrefixes[item.type];
                if (item.status === LocationNoticeStatus.Saved && item.can_view_details) {
                  return (
                    <CanDo permission={Permission.ManageLocationNotices} locationId={location.id}>
                      <Link
                        to={`/intelligence/${account.id}/locations/${location.id}/notices/${item.id}/${type}/${step}`}
                        className="text-sky-500 flex items-center text-sm gap-x-2"
                        onClick={e => e.stopPropagation()}
                      >
                        Complete now
                        <ArrowRightIcon className="h-4" />
                      </Link>
                    </CanDo>
                  );
                } else if (item.status === LocationNoticeStatus.Sent) {
                  return <CheckCircleIcon className="h-7 w-7 text-green-500" />;
                }
              },
            },
          ]}
          data={items}
          showAddButton={false}
          showSelectBox={false}
          alignment="middle"
          rowIdPrefix="location_notice"
          onClickRow={locationNotice =>
            locationNotice.can_view_details && navigate(
              `/intelligence/${account.id}/locations/${location.id}/notices/${
                locationNotice.id
              }/${LocationNoticeLinkPrefixes[locationNotice.type]}`
            )
          }
          disabledRows={items.filter(item => !item.can_view_details)}
          disabledRowClassName="bg-zinc-50"
        />
      </div>
    </>
  );
}
