import { CTA } from "~/components/cta.component";
import {
  Form,
  useActionData,
  useLoaderData,
  useLocation,
  useNavigate,
  useNavigation,
} from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { pull } from "lodash";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import { useEffect, useState } from "react";
import { Modal } from "~/components/modal.component";
import { CrudCheckboxField } from "~/components/form/crud-form.component";
import { CheckIcon, PaperAirplaneIcon } from "@heroicons/react/24/outline";
import type { ManagerAccountUsersFilters } from "~/services/manager-account-role.service.server";
import { Table } from "~/components/intelligence/table.component";
import { Pagination } from "~/components/intelligence/pagination.component";
import { Button } from "~/components/button.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import dayjs from "dayjs";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { RevysePencilIcon } from "~/components/revyse-pencil-icon.component";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { FilterBar } from "~/components/filter-bar.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

const STATUS_FILTER_OPTIONS = [
  { value: "active", label: "Active" },
  { value: "pending", label: "Pending" },
];

const PERMISSION_LEVEL_OPTIONS = [
  { value: "Owner", label: "Owner" },
  { value: "Editor", label: "Editor" },
  { value: "Viewer", label: "Viewer" },
];

const defaultSearchParams: ManagerAccountUsersFilters = {
  page: 1,
  perPage: 10,
  query: "",
  status: [],
  permissionLevel: [],
};
export const action = async ({ request, params }: ActionFunctionArgs) => {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageAccountUsers],
    }
  );

  const form = await request.formData();
  return updateAction(form);
};

const ManagerAccountRoleUserInvitation = z.object({
  id: z.string().uuid(),
});

const updateAction = async (form: FormData) => {
  const fields = {
    id: form.get("invitationId"),
  };

  const validation = ManagerAccountRoleUserInvitation.safeParse(fields);

  if (validation.success) {
    const { managerAccountRoleService } = await WebDIContainer();

    const invitation =
      await managerAccountRoleService.getManagerAccountRoleUserInvitation(
        validation.data
      );

    if (invitation) {
      await managerAccountRoleService.sendManagerAccountUserInvitationEmail(
        invitation
      );

      return jsonWithSuccess(
        {
          success: true,
          fields,
          errors: issuesByKey([]),
        },
        "Invitation email sent successfully"
      );
    }
  }

  const errors =
    "error" in validation ? issuesByKey(validation.error.issues) : [];

  return jsonWithError(
    {
      success: false,
      fields,
      errors,
    },
    "The invitation is invalid, please check again",
    { status: 400 }
  );
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account: managerAccount } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewAccountUsers],
    }
  );

  const url = new URL(request.url);

  const { managerAccountRoleService } = await WebDIContainer();

  const { id: managerAccountId } = params as { id: string };

  const search = new URLSearchParams(url.search);

  const filtersFromURL = Object.fromEntries(search.entries());

  const filters: ManagerAccountUsersFilters = {
    page: Number(filtersFromURL.page) || defaultSearchParams.page,
    perPage: Number(filtersFromURL.perPage) || defaultSearchParams.perPage,
    query: filtersFromURL.query || defaultSearchParams.query,
    status: filtersFromURL.status
      ? filtersFromURL.status?.split(",")
      : defaultSearchParams.status,
    permissionLevel: filtersFromURL.permissionLevel
      ? filtersFromURL.permissionLevel?.split(",")
      : defaultSearchParams.permissionLevel,
  };

  const data = await managerAccountRoleService.getManagerAccountRolesTableData(
    managerAccountId,
    filters
  );

  const count =
    await managerAccountRoleService.getManagerAccountRolesTableDataCount(
      managerAccountId,
      filters
    );

  if (!managerAccount) {
    throw new Response("Not found", { status: 404 });
  }
  return json({
    user,
    managerAccount,
    filters,
    data,
    count,
  });
}

export default function AccountUsers() {
  const { managerAccount, filters, data, count, user } =
    useLoaderData<typeof loader>();

  const actionData = useActionData<typeof action>();

  const navigate = useNavigate();
  const location = useLocation();
  const navigation = useNavigation();

  const [searchParams, setSearchParams] = useState(filters);
  const [openFilteringModal, setOpenFilteringModal] = useState(false);
  const [resentInvitations, setResentInvitations] = useState<string[]>([]);

  useEffect(() => {
    if (!openFilteringModal) {
      // Handle filtering, name/email searching and pagination
      const handleFiltering = () => {
        const paramsObject = {
          page: searchParams.page.toString(),
          perPage: searchParams.perPage.toString(),
          query: searchParams.query || "",
          status: searchParams.status.join(","),
          permissionLevel: searchParams.permissionLevel.join(","),
        };

        const newQueryParams = new URLSearchParams(paramsObject);

        setOpenFilteringModal(false);
        navigate(`${location.pathname}?${newQueryParams.toString()}`);
      };

      handleFiltering();
    }
  }, [searchParams, openFilteringModal, location.pathname, navigate]);

  const clearFilters = () => {
    setSearchParams({
      ...searchParams,
      status: [],
      permissionLevel: [],
      page: 1,
    });
    setOpenFilteringModal(false);
  };

  const setPermissionLevelFilter = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value: permission, checked } = e.target;
    setSearchParams(value => {
      if (checked && !value.permissionLevel.includes(permission)) {
        value.permissionLevel.push(permission);
      }

      if (!checked && value.permissionLevel.includes(permission)) {
        pull(value.permissionLevel, permission);
      }
      return {
        ...value,
      };
    });
  };

  const setStatusFilter = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { value: status, checked } = e.target;
    setSearchParams(value => {
      if (checked && !value.status.includes(status)) {
        value.status.push(status);
      }

      if (!checked && value.status.includes(status)) {
        pull(value.status, status);
      }
      return {
        ...value,
      };
    });
  };

  // Pagination variables
  const totalPages = Math.ceil(count / searchParams.perPage);
  const pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);
  const resultsText = `${data.length} out of ${count} results`;

  // Resend invitation form variables
  const submittingInvitationId =
    navigation.state === "submitting" && navigation.formData
      ? navigation.formData.get("invitationId")
      : null;

  useEffect(() => {
    if (actionData?.success) {
      setResentInvitations(resentInvitations => [
        ...resentInvitations,
        actionData.fields.id as string,
      ]);
    }
  }, [actionData]);

  // Permissions
  const userCanManageUsers = canDoOnAccount(
    user,
    managerAccount,
    Permission.ManageAccountUsers
  );

  return (
    <>
      <Modal
        isOpen={openFilteringModal}
        onClose={() => setOpenFilteringModal(false)}
        size="medium"
        manager={true}
      >
        <div className="p-2 lg:p-6">
          <h4 className="font-bold">Filter By</h4>
          <div className="grid md:grid-cols-2 gap-2 col-span-full">
            <div>
              <div className="my-4 font-semibold">Permission Levels</div>
              <div>
                {PERMISSION_LEVEL_OPTIONS.map(option => (
                  <div className="md:w-64 w-full" key={option.value}>
                    <CrudCheckboxField
                      field={{
                        name: `permissionLevelFilter`,
                        description: "",
                        type: "checkbox",
                        label: option.label,
                        value: option.value,
                        errors: [],
                        defaultChecked: searchParams.permissionLevel.includes(
                          option.value
                        ),
                      }}
                      onChange={setPermissionLevelFilter}
                    />
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Status</div>
              <div>
                {STATUS_FILTER_OPTIONS.map(option => (
                  <div className="md:w-64 w-full" key={option.value}>
                    <CrudCheckboxField
                      field={{
                        name: `statusFilter`,
                        description: "",
                        type: "checkbox",
                        label: option.label,
                        value: option.value,
                        errors: [],
                        defaultChecked: searchParams.status.includes(
                          option.value
                        ),
                      }}
                      onChange={setStatusFilter}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
          <div className="flex justify-end mt-8 items-center space-x-3">
            <button
              className="text-sky-500"
              onClick={() => {
                clearFilters();
              }}
            >
              Clear filters
            </button>
            <CTA
              variant="coral-shadow"
              onClick={() => {
                setOpenFilteringModal(false);
              }}
            >
              Show results
            </CTA>
          </div>
        </div>
      </Modal>
      <IntelligenceScreenHeader
        title="User management"
        description={`View ${
          userCanManageUsers ? "and edit" : ""
        } the users on this account and adjust their permissions.`}
        buttonsSlot={
          userCanManageUsers && (
            <CTA
              id="add-user"
              type="button"
              to={`/intelligence/${managerAccount.id}/account/users/new`}
              variant="coral-shadow"
              className="lg:w-fit mt-3 lg:mt-0"
            >
              Add New User
            </CTA>
          )
        }
      />
      <FilterBar
        inputPlaceholder="Search users"
        defaultSearchQuery={searchParams.query}
        onFilter={searchQuery => {
          setSearchParams({
            ...searchParams,
            query: searchQuery,
            page: 1,
          });
        }}
        filters={{
          onOpenFilteringModal: (open: boolean) => {
            setOpenFilteringModal(open);
          },
          filtersCount:
            searchParams.permissionLevel?.length + searchParams.status?.length,
        }}
      />
      <div>
        <Table
          cols={[
            { name: "name", label: "Name", columnClassName: "align-middle" },
            { name: "email", label: "Email", columnClassName: "align-middle" },
            {
              name: "permissionLevel",
              label: "Permission Level",
              columnClassName: "align-middle",
            },
            {
              label: "Status",
              renderer: managerAccountRole =>
                managerAccountRole.isInvitation ? "Pending" : "Active",
              columnClassName: "align-middle",
            },
            {
              label: "Last Accessed",
              renderer: managerAccountRole =>
                managerAccountRole.lastAccessed
                  ? dayjs(managerAccountRole.lastAccessed).format("MM/DD/YYYY")
                  : "",
              columnClassName: "align-middle",
            },
            {
              label: "",
              renderer: managerAccountRole =>
                userCanManageUsers && (
                  <div className="flex flex-col items-center">
                    {managerAccountRole.id !== user.id && (
                      <Button
                        color="transparent"
                        className="[font-size:inherit]"
                      >
                        <RevysePencilIcon className="mr-3 h-5" />
                        Edit
                      </Button>
                    )}
                    {managerAccountRole.isInvitation && (
                      <Form method="post">
                        <input
                          name="invitationId"
                          type="hidden"
                          value={managerAccountRole.id}
                        />
                        <Button
                          color="transparent"
                          className={`mt-2 [font-size:inherit] ${
                            submittingInvitationId == managerAccountRole.id
                              ? "animate-bounce"
                              : ""
                          } ${
                            resentInvitations.includes(managerAccountRole.id)
                              ? "text-green-500"
                              : ""
                          }`}
                          type="submit"
                          disabled={
                            !!submittingInvitationId ||
                            resentInvitations.includes(managerAccountRole.id)
                          }
                        >
                          {resentInvitations.includes(managerAccountRole.id) ? (
                            <CheckIcon className="mr-3 h-5" />
                          ) : (
                            <PaperAirplaneIcon className="mr-3 h-5" />
                          )}
                          {submittingInvitationId == managerAccountRole.id
                            ? "Sending Invite"
                            : resentInvitations.includes(managerAccountRole.id)
                            ? "Invite Resent"
                            : "Resend Invite"}
                        </Button>
                      </Form>
                    )}
                  </div>
                ),
              columnClassName: "align-middle",
            },
          ]}
          data={data}
          addButtonLabel="add new user"
          showAddButton={true}
          handleCallback={() =>
            userCanManageUsers &&
            navigate(`/intelligence/${managerAccount.id}/account//users/new`)
          }
          showSelectBox={false}
          disabledRows={[{ id: user.id }]}
          onClickRow={managerAccountRole =>
            userCanManageUsers &&
            managerAccountRole.id !== user.id &&
            navigate(
              `/intelligence/${managerAccount.id}/account/users/${managerAccountRole.id}`
            )
          }
        ></Table>
        <Pagination
          resultsText={resultsText}
          pageNumbers={pageNumbers}
          currentPage={searchParams.page}
          totalPages={totalPages}
          handleCallback={page => setSearchParams({ ...searchParams, page })}
        ></Pagination>
      </div>
    </>
  );
}
