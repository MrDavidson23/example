import type { LoaderFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { WebDIContainer } from "../di-containers/web.di-container.server";

export let loader: LoaderFunction = async ({ request }) => {
  try {
    const access_token =
      request.headers.get("Authorization")?.replace("Bearer ", "") || "";

    const { ssoService } = await WebDIContainer();
    const response = await ssoService.getUserInfo(access_token);
    return response;
  } catch (error) {
    console.error(error);
    return json({ error: "Server error" }, { status: 500 });
  }
};
