import {
  ArrowRightIcon,
  CheckIcon,
  ChevronRightIcon,
  ListBulletIcon,
} from "@heroicons/react/20/solid";
import {
  HandThumbUpIcon,
  QuestionMarkCircleIcon,
  BuildingOffice2Icon,
  BuildingOfficeIcon,
  MapPinIcon,
  CalendarIcon,
  UsersIcon,
  ComputerDesktopIcon,
  ChevronUpIcon,
  ChevronDownIcon,
} from "@heroicons/react/24/outline";
import type {
  ActionFunctionArgs,
  LinksFunction,
  LoaderFunctionArgs,
  MetaFunction,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import HTMLReactParser from "html-react-parser";
import {
  Link,
  useFetcher,
  useLoaderData,
  useNavigate,
  useSearchParams,
} from "@remix-run/react";
import { isNil } from "lodash";
import { CTA, CTARedirect } from "~/components/cta.component";
import ProductTile from "~/components/product-tile.component";
import StarRating from "~/components/star-rating.component";
import { DownloadableFilePreview } from "~/components/downloadable-file-preview.component";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { ReviewListComponent } from "~/components/review-list.component";
import { getUser } from "~/utils/session.server";
import { useCallback, useEffect, useRef, useState } from "react";
import { PlanChooserModal } from "~/components/plan-chooser-modal.component";
import { IntegrationProvider, Role } from "@prisma/client";
import { Modal } from "~/components/modal.component";
import { BuyerContactModal } from "~/components/contact-modal.component";
import { UnclaimedListingModal } from "~/components/unclaimed-listing-modal.component";
import { tierHasPermission } from "~/utils/permission.utils";
import { StorylaneDemo } from "~/components/storylane-demo.component";
import { VideoPlayer } from "~/components/video-player.component";
import { formatNumber } from "~/utils/string.utils";
import { RedirectLink } from "~/components/redirect-link.component";
import { JsonLd } from "react-schemaorg";
import richtext from "../styles/richtext.css";
import { Tooltip } from "~/components/tooltip.component";
import { VerifiedIcon } from "~/components/verified-icon.component";
import type { Product } from "schema-dts";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Button } from "~/components/button.component";
import { getEnv } from "~/services/env.service.server";
import { Toast } from "~/components/toast.component";
import { assert } from "~/utils/assert.utils.server";
import { FeatureLocked } from "~/components/discovery/feature-locked.component";
import { ListingCard } from "~/components/discovery/listing-card.component";

dayjs.extend(utc);

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  const product = data!.product;
  return [
    { title: product.page_title },
    {
      name: "description",
      content: product.meta_description,
    },
  ];
};

export const links: LinksFunction = () => {
  return [
    {
      rel: "stylesheet",
      href: richtext,
    },
  ];
};

export const action = async ({ request }: ActionFunctionArgs) => {
  const user = await getUser(request);
  assert(!isNil(user), `User not found`);
  const { customerSupportService } = await WebDIContainer();

  const form = await request.formData();
  const intent = form.get("intent");
  if (intent === "verify-account") {
    const env = getEnv();
    await customerSupportService.sendCSEmail(
      `Verified Buyer Request Alert | A User Has Requested Verification`,
      `<p>Hey Team Revyse,</p> 
			<p>${user.first_name} ${user.last_name} has requested verification using email ${user.email}</p>
			<p>Click here to <a href="${env.REVYSE_UI_ORIGIN}/admin/users/${user.id}">review and approve</a>.</p>`
    );
    return json({ success: true });
  }
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const user = await getUser(request);
  const {
    productSubscriptionService,
    stripeService,
    reviewService,
    productService,
  } = await WebDIContainer();

  const product = await productService.getProductBySlug({ slug: params.slug });

  if (isNil(product)) {
    throw json("Not Found", { status: 404 });
  }
  // Sort the integrations using integrated vendor name or integrated product title
  product?.vendor?.vendor_integrations.sort((a, b) =>
    (
      a.integrated_vendor?.name ||
      a.integrated_product?.title ||
      ""
    ).localeCompare(
      b.integrated_vendor?.name || b.integrated_product?.title || ""
    )
  );

  const lastVerified = new Date(
    Math.max(
      ...(product?.vendor?.vendor_integrations?.map(integration =>
        (integration.last_verified_at || new Date(0)).getTime()
      ) || []),
      new Date(0).getTime()
    )
  );

  const activeSubscription =
    await productSubscriptionService.getProductActiveSubscription(product.id);

  const similarProducts = (
    await productService.getProductsForPrimaryCategory({
      categoryId: product.primary_category.id,
      take: 9,
    })
  ).filter(p => p.id !== product.id);

  const reviews = await reviewService.getReviewsWithRatings({
    productId: product.id,
    take: 2,
  });

  const stripeProducts = await stripeService.getPlanChooserStripeProducts();

  const userRole = user?.id
    ? await productSubscriptionService.getResourceUserRole({
        filters: {
          user_id: user.id,
          resource_id: activeSubscription?.id,
        },
      })
    : null;

  const verifiedBuyer =
    user?.user_roles.some(ur => ur.role === Role.BUYER) || userRole;

  return json({
    lastVerified,
    product,
    reviews,
    user,
    similarProducts,
    activePlan: activeSubscription?.stripe_price.product,
    stripeProducts,
    verifiedBuyer,
  });
}

export default function ProductSlugRoute() {
  const {
    lastVerified,
    product,
    reviews,
    user,
    similarProducts,
    activePlan,
    stripeProducts,
    verifiedBuyer,
  } = useLoaderData<typeof loader>();

  const navigate = useNavigate();
  const fetcher = useFetcher<typeof action>();

  const overviewSection = useRef<HTMLHeadingElement>(null);
  const companyInfoSection = useRef<HTMLHeadingElement>(null);
  const pricingSection = useRef<HTMLHeadingElement>(null);
  const demosSection = useRef<HTMLHeadingElement>(null);
  const imagesSection = useRef<HTMLHeadingElement>(null);
  const videosSection = useRef<HTMLHeadingElement>(null);
  const downloadsSection = useRef<HTMLHeadingElement>(null);
  const reviewsSection = useRef<HTMLDivElement>(null);
  const integrationPartnersSection = useRef<HTMLHeadingElement>(null);

  const numReviews = reviews.total_count;
  const avgCompatibilityScore = reviews.averages.compatibility_score ?? 0;
  const avgCustomerSupportScore = reviews.averages.customer_service_score ?? 0;
  const avgValueScore = reviews.averages.value_score ?? 0;
  const avgOnboardingScore = reviews.averages.onboarding_score ?? 0;

  const [searchParams, setSearchParams] = useSearchParams();
  useEffect(() => {
    if (searchParams.get("claim") === "true") {
      setClaimModalOpen(true);
    }
  }, [searchParams]);
  const [claimModalOpen, setClaimModalOpen] = useState(
    searchParams.get("claim") === "true"
  );
  const [contactModalOpen, setContactModalOpen] = useState(false);
  const [contactModalText, setContactModalText] = useState<
    string | undefined
  >();
  const [showAllIntegrationPartners, setShowAllIntegrationPartners] =
    useState(false);

  const [unclaimedListingModalOpen, setUnclaimedListingModalOpen] =
    useState(false);
  const [verifiedBuyerModalOpen, setVerifiedBuyerModalOpen] = useState(false);
  const overallRating =
    (avgCompatibilityScore +
      avgCustomerSupportScore +
      avgValueScore +
      avgOnboardingScore) /
    4.0;

  const visibleIntegrationPartners = showAllIntegrationPartners
    ? product.vendor?.vendor_integrations
    : product.vendor?.vendor_integrations.slice(0, 8);

  const onContactClick = (altText?: string) => {
    if (verifiedBuyer) {
      setContactModalText(altText);
      setContactModalOpen(true);
    } else if (user) {
      setVerifiedBuyerModalOpen(true);
    } else {
      navigate(
        `/sign-up?intent=BUYER&redirectTo=${encodeURIComponent(
          `/products/${product.slug}`
        )}`
      );
    }
  };

  const onScheduleDemoClick = () => {
    if (verifiedBuyer && product.demo_scheduling_url) {
      window.open(product.demo_scheduling_url, "_blank");
    } else if (user) {
      setVerifiedBuyerModalOpen(true);
    } else {
      navigate(
        `/sign-up?intent=BUYER&redirectTo=${encodeURIComponent(
          `/products/${product.slug}`
        )}`
      );
    }
  };

  /* cspell: disable */
  const videoExtensions = [
    "webm",
    "mpg",
    "mp2",
    "mpeg",
    "mpe",
    "mpv",
    "ogg",
    "mp4",
    "m4p",
    "m4v",
    "avi",
    "wmv",
    "mov",
    "qt",
    "flv",
    "swf",
    "avchd",
  ];
  /* cspell: enable */

  const handleLinkClick = useCallback(
    (ref: React.RefObject<HTMLElement>, position?: ScrollLogicalPosition) => {
      if (ref.current) {
        ref.current.scrollIntoView({
          behavior: "smooth",
          block: position ?? "center",
        });
      }
    },
    []
  );

  const productLogoSrc = product.logo_file_id
    ? `/images/${product.logo_file_id}`
    : `/assets/default-logo.png`;

  return (
    <>
      <PlanChooserModal
        isOpen={claimModalOpen}
        onClose={() => {
          setClaimModalOpen(false);
          setSearchParams({});
        }}
        onChoose={(stripeProduct, price) =>
          navigate(`/checkout/${price.id}/${product.id}`)
        }
        product={product}
        stripeProducts={stripeProducts}
      />
      <Modal
        isOpen={verifiedBuyerModalOpen}
        onClose={() => setVerifiedBuyerModalOpen(false)}
        size="medium-small"
      >
        {fetcher.data?.success !== undefined && (
          <Toast
            variant={fetcher.data?.success ? "success" : "error"}
            message={
              fetcher.data?.success
                ? "Success! Buyer Verification Request has been sent"
                : "There were requesting your Buyer Verification. Please try again."
            }
          />
        )}
        <fetcher.Form method="post" action={`/products/${product.slug}`}>
          <input type="hidden" name="intent" value="verify-account" />

          <h2 className="text-2xl font-bold mb-4">Verify My Account </h2>
          <div>
            Are you a real estate professional shopping for software and
            services?
          </div>
          <br />
          <div>
            Become a verified buyer on Revyse (it’s free!) and get unrestricted
            access to product listings across the platform. Easily see pricing,
            view self-guided product tours, and schedule demos with the click of
            a button.
          </div>
          <br />
          <div>
            Click “Request Buyer Verification” below to submit your info and
            we’ll get you access in no time.
          </div>
          <div className="flex justify-center py-8">
            <CTA
              type="submit"
              variant="coral-shadow"
              className={`${
                fetcher.state === "submitting" ? "animate-bounce" : ""
              }`}
            >
              {fetcher.state === "submitting"
                ? "Sending your request..."
                : "Request Buyer Verification"}
            </CTA>
          </div>
        </fetcher.Form>
      </Modal>
      <UnclaimedListingModal
        isOpen={unclaimedListingModalOpen}
        onClose={() => setUnclaimedListingModalOpen(false)}
        product={product}
      />
      {/* This if logic here is redundant but it unmounts the component after dismissal to
      allow the form to reset */}
      {contactModalOpen && (
        <BuyerContactModal
          isOpen={contactModalOpen}
          onClose={() => setContactModalOpen(false)}
          activePlan={activePlan}
          product={product}
          descriptionText={contactModalText}
        />
      )}
      <div className="flex justify-center">
        <JsonLd<Product>
          item={{
            "@context": "https://schema.org",
            "@type": "Product",

            name: product.title,
            brand: {
              "@type": "Brand",
              name: product.vendor!.name,
            },
            image: `/images/${product.logo_file_id}`,
            description: product.description,
            category: product.primary_category.name,
            aggregateRating:
              overallRating > 0 && numReviews > 0
                ? {
                    "@type": "AggregateRating",
                    ratingValue: overallRating.toFixed(1),
                    reviewCount: `${numReviews}`,
                  }
                : undefined,
          }}
        ></JsonLd>
        <div className="w-full lg:max-w-7xl md:px-6 overflow-clip">
          <div className="flex flex-wrap items-center uppercase text-sm py-6 px-2 md:px-0">
            <Link to="/">HOME</Link>
            <ChevronRightIcon className="h-4" />
            <Link to={`/categories/${product.primary_category.slug}`}>
              {product.primary_category.name}
            </Link>
            <ChevronRightIcon className="h-4" />
            <Link to={`/products/${product.slug}`} className="font-bold">
              {product.title}
            </Link>
          </div>

          <div className="md:rounded-2xl shadow-sm bg-white pb-6 mb-5">
            <div className=" rounded-t-2xl overflow-clip ">
              {tierHasPermission(
                activePlan?.tier,
                "show_custom_banner_image"
              ) && product.banner_file_id ? (
                <div
                  className="md:h-48 bg-cover"
                  style={{
                    backgroundImage: `url(/images/${product.banner_file_id})`,
                  }}
                ></div>
              ) : (
                <div className="bg-sky-600 md:h-20"></div>
              )}
            </div>

            <div className="md:flex px-2 md:px-12">
              {/* image on mobile */}
              <div className="flex md:hidden justify-start pt-8 px-6">
                <div
                  className="w-20 h-20 bg-center bg-cover bg-no-repeat bg-white rounded-md"
                  style={{
                    backgroundImage: `url(${productLogoSrc})`,
                  }}
                ></div>
              </div>
              <div className="md:flex flex-col text-sm hidden bg-white gap-2">
                <div className="-mt-8 mb-10 bg-white rounded-md border border-gray-200 overflow-hidden">
                  {/* image on desktop */}
                  <div
                    className="w-48 h-48 bg-center bg-cover bg-no-repeat bg-white"
                    style={{
                      backgroundImage: `url(${productLogoSrc})`,
                    }}
                  ></div>
                </div>
                <Button
                  color="transparent"
                  onClick={() => handleLinkClick(overviewSection)}
                  className="text-sky-500 font-normal flex justify-start p-0"
                  id="product-overview-link"
                >
                  Product Overview
                </Button>
                <Button
                  color="transparent"
                  onClick={() => handleLinkClick(companyInfoSection)}
                  className="text-sky-500 font-normal flex justify-start p-0"
                  id="company-info-link"
                >
                  Company Info
                </Button>
                {visibleIntegrationPartners &&
                  visibleIntegrationPartners.length > 0 && (
                    <Button
                      color="transparent"
                      onClick={() =>
                        handleLinkClick(integrationPartnersSection)
                      }
                      className="text-sky-500 font-normal flex justify-start p-0"
                      id="integrations-link"
                    >
                      Integrations
                    </Button>
                  )}
                {tierHasPermission(activePlan?.tier, "show_pricing") &&
                  product.packages.length > 0 && (
                    <Button
                      color="transparent"
                      onClick={() => handleLinkClick(pricingSection)}
                      className="text-sky-500 font-normal flex justify-start p-0"
                      id="pricing-link"
                    >
                      {" "}
                      Pricing
                    </Button>
                  )}
                {tierHasPermission(activePlan?.tier, "show_demos") &&
                  (product.demo_files.length > 0 ||
                    product.demo_storylane_url) && (
                    <Button
                      color="transparent"
                      onClick={() => handleLinkClick(demosSection)}
                      className="text-sky-500 font-normal flex justify-start p-0"
                      id="product-demos-link"
                    >
                      Product Demos
                    </Button>
                  )}
                {tierHasPermission(activePlan?.tier, "show_product_images") &&
                  product.image_files.length > 0 && (
                    <Button
                      color="transparent"
                      onClick={() => handleLinkClick(imagesSection)}
                      className="text-sky-500 font-normal flex justify-start p-0"
                      id="product-images-link"
                    >
                      Product Images
                    </Button>
                  )}

                {tierHasPermission(activePlan?.tier, "show_brand_videos") &&
                  product.brand_video_files.length > 0 && (
                    <Button
                      color="transparent"
                      onClick={() => handleLinkClick(videosSection)}
                      className="text-sky-500 font-normal flex justify-start p-0"
                      id="brand-videos-link"
                    >
                      {" "}
                      Brand Videos
                    </Button>
                  )}
                {tierHasPermission(activePlan?.tier, "show_downloads") &&
                  product.download_files.length > 0 && (
                    <Button
                      color="transparent"
                      onClick={() => handleLinkClick(downloadsSection)}
                      className="text-sky-500 font-normal flex justify-start p-0"
                      id="downloads-link"
                    >
                      {" "}
                      Downloads
                    </Button>
                  )}
                {/* TODO: uncomment when implemented 
              <a href="#consultants" className="text-sky-500">
                Consultants
              </a> */}
                <Button
                  color="transparent"
                  onClick={() => handleLinkClick(reviewsSection, "start")}
                  className="text-sky-500 font-normal flex justify-start p-0"
                  id="reviews-link"
                >
                  {" "}
                  Reviews
                </Button>
                <div className="my-2"></div>
                {tierHasPermission(activePlan?.tier, "schedule_demo") &&
                  product.demo_scheduling_url && (
                    <button
                      onClick={onScheduleDemoClick}
                      className="flex items-center text-coral"
                      id="schedule-a-demo-link"
                    >
                      Schedule a Demo <ArrowRightIcon className="h-4 ml-2" />
                    </button>
                  )}
                {tierHasPermission(activePlan?.tier, "contact_vendor") && (
                  <button
                    onClick={() => onContactClick()}
                    className="text-left text-coral"
                    id="contact-vendor-link"
                  >
                    Contact {product.vendor?.name}{" "}
                    <ArrowRightIcon className="h-4 ml-2 inline" />
                  </button>
                )}
                <RedirectLink
                  userLoggedIn={!!user}
                  loginOrSignUp="sign-up"
                  to={`/products/${product.slug}/reviews/new`}
                  className="flex items-center text-coral"
                  id="write-a-review-link"
                >
                  Write a Review <ArrowRightIcon className="h-4 ml-2" />
                </RedirectLink>
                {!activePlan && (
                  <button
                    onClick={() => setClaimModalOpen(true)}
                    className="text-left text-coral"
                  >
                    Claim Listing <ArrowRightIcon className="h-4 ml-2 inline" />
                  </button>
                )}
              </div>
              <div className="pt-2 md:pt-6 p-6">
                <div className="flex flex-grow flex-col lg:flex-row justify-between">
                  <div>
                    <h1 className="font-bold text-2xl" id="product-title">
                      {product.title}
                    </h1>
                    <span className="text-gray-400">
                      by{" "}
                      <Link
                        to={`/vendors/${product.vendor!.slug}`}
                        className="border-b border-b-gray-200"
                        id="product-vendor"
                      >
                        {product.vendor!.name}
                      </Link>
                    </span>
                    <div className="flex text-gray-400 mt-3">
                      <StarRating
                        rating={overallRating}
                        className="mr-2"
                      ></StarRating>{" "}
                      <span className="text-gray-500 mx-2" id="product-rating">
                        {overallRating.toFixed(1)}
                      </span>
                      <span className="md:mx-2">
                        (
                        <button
                          className="hover:text-sky-500"
                          onClick={() =>
                            handleLinkClick(reviewsSection, "start")
                          }
                        >
                          {numReviews}
                        </button>
                        )
                      </span>
                    </div>
                  </div>
                  <div className="flex flex-row lg:flex-col w-full lg:w-auto my-3 lg:my-0 gap-2 lg:gap-0 flex-wrap justify-start">
                    {tierHasPermission(activePlan?.tier, "schedule_demo") &&
                      product.demo_scheduling_url && (
                        <CTA
                          className="lg:mb-2"
                          onClick={onScheduleDemoClick}
                          id="cta-schedule-a-demo"
                        >
                          Schedule a Demo
                        </CTA>
                      )}
                    {tierHasPermission(activePlan?.tier, "contact_vendor") ? (
                      <CTA
                        onClick={() => onContactClick()}
                        className="text-center"
                        id="cta-contact-vendor"
                      >
                        <>Contact {product.vendor?.name}</>
                      </CTA>
                    ) : (
                      <CTARedirect
                        className="text-center"
                        to={`/products/${product.slug}/reviews/new`}
                        userLoggedIn={!!user}
                        loginOrSignUp="sign-up"
                        id="cta-write-a-review"
                      >
                        Write a Review
                      </CTARedirect>
                    )}
                  </div>
                </div>
                <div className="mt-3 font-medium" id="claimed-listing">
                  {activePlan ? (
                    <div className="flex align-middle text-green-500">
                      <CheckIcon className="h-6 mr-1" />
                      Claimed Listing
                    </div>
                  ) : (
                    <div className="flex align-middle text-sky-500">
                      <button
                        onClick={() => setUnclaimedListingModalOpen(true)}
                      >
                        <QuestionMarkCircleIcon className="h-6 inline" />{" "}
                        Unclaimed Listing
                      </button>
                      <div className="ml-2">
                        <Tooltip
                          text="Is this your product listing? Click “Claim Now” to take ownership of this listing as an official company representative, and make updates to the listing in your Revyse Vendor Portal."
                          position="right"
                          className="ml-2 hidden sm:block"
                        >
                          <button
                            onClick={() => setClaimModalOpen(true)}
                            className="text-coral italic"
                          >
                            (Claim Now)
                          </button>
                        </Tooltip>
                      </div>
                    </div>
                  )}
                </div>

                {tierHasPermission(activePlan?.tier, "show_promo") &&
                  product.promo_text && (
                    <div className="bg-themeLightYellow border-l-4 border-themeYellow p-4 my-4 flex flex-wrap md:flex-nowrap justify-between items-center">
                      <div>
                        <p>
                          Exclusive offer for {product.title} through Revyse
                        </p>
                        <p
                          className="text-2xl font-medium italic text-montserrat"
                          id="promo-text"
                        >
                          {product.promo_text}
                        </p>
                      </div>
                      <CTA
                        className="mt-4 md:mt-0"
                        fillStyle="outline"
                        onClick={() =>
                          onContactClick(
                            `Reach out to ${product.vendor?.name} and let them know that you’re interested in learning more about ${product.title}’s featured offer on Revyse.`
                          )
                        }
                        id="cta-claim-offer"
                      >
                        Claim Offer
                      </CTA>
                    </div>
                  )}

                <ListingCard>
                  <>
                    <h3
                      ref={overviewSection}
                      className="border-b border-b-gray-100 pb-4 mb-6 font-medium"
                      id="product-overview-heading"
                    >
                      Product Overview
                    </h3>
                    <h4 className="mb-4 mt-8 font-medium">
                      Product Description
                    </h4>
                    <p id="product-description">{product.description}</p>

                    {tierHasPermission(activePlan?.tier, "show_positioning") &&
                      product.positioning && (
                        <>
                          <h4 className="mb-4 mt-8 font-medium">
                            Product Positioning
                          </h4>
                          <p id="product-positioning">{product.positioning}</p>
                        </>
                      )}

                    {tierHasPermission(activePlan?.tier, "show_features") &&
                      product.features.length > 0 && (
                        <>
                          <h4 className="mb-4 mt-8 font-medium">
                            Main Features
                          </h4>
                          <div
                            className="grid lg:grid-cols-3 gap-5"
                            id="product-features"
                          >
                            {product.features.map(f => (
                              <div
                                key={f.id}
                                className="border border-grey-100 rounded-md w-auto p-5 text-center"
                                id={`product-feature-${f.id}`}
                              >
                                <div
                                  className="text-lg mb-4 leading-tight"
                                  id="product-feature-name"
                                >
                                  {f.name}
                                </div>
                                <div
                                  className="text-sm w-full break-words"
                                  id="product-feature-description"
                                >
                                  {f.description}
                                </div>
                              </div>
                            ))}
                          </div>
                        </>
                      )}

                    <div className="grid grid-cols-1 md:grid-cols-2 mt-8 gap-10">
                      <div className="relative px-8">
                        <ListBulletIcon className="h-6 absolute left-0" />
                        <div className="mb-1 font-medium">
                          Product Categories
                        </div>
                        <Link
                          to={`/categories/${product.primary_category.slug}`}
                          className="text-sky-500 text-sm"
                          id="product-primary-category"
                        >
                          <span>{product.primary_category.name}</span>
                        </Link>
                        {(tierHasPermission(
                          activePlan?.tier,
                          "show_product_categories"
                        ) ||
                          /* cspell: disable-next-line */
                          product.vendor?.slug === "zipcode-creative") && (
                          <>
                            {product.secondary_category && ", "}
                            {product.secondary_category && ", " && (
                              <Link
                                to={`/categories/${product.secondary_category.slug}`}
                                className="text-sky-500 text-sm"
                                id="product-secondary-category"
                              >
                                <span>{product.secondary_category.name}</span>
                              </Link>
                            )}
                            {product.tertiary_category && ", "}
                            {product.tertiary_category && (
                              <Link
                                to={`/categories/${product.tertiary_category.slug}`}
                                className="text-sky-500 text-sm"
                                id="product-tertiary-category"
                              >
                                <span>{product.tertiary_category.name}</span>
                              </Link>
                            )}
                          </>
                        )}
                      </div>
                      <div className="relative px-8">
                        <BuildingOffice2Icon className="h-6 absolute left-0" />
                        <div className="mb-1 font-medium">
                          Industries Served
                        </div>
                        <div className="text-sm" id="product-industries">
                          {product.industries.map(i => i.name).join(", ")}
                        </div>
                      </div>
                      {tierHasPermission(
                        activePlan?.tier,
                        "show_good_for_tags"
                      ) &&
                        product.good_for_tags.length > 0 && (
                          <div className="relative px-8 col-span-full">
                            <HandThumbUpIcon className="h-6 absolute left-0" />
                            <div className="mb-1 font-medium">Good For</div>
                            <div className="flex gap-2 flex-wrap">
                              {product.good_for_tags.map((t, i) => (
                                <Link
                                  to={`/search?query=${t.name}`}
                                  className="text-sky-600 rounded-3xl border border-sky-600 hover:bg-sky-600 hover:text-white transition duration-200 py-2 px-3 text-xs"
                                  key={t.id}
                                  id={`product-good-for-tag-${t.id}`}
                                >
                                  {t.name}
                                </Link>
                              ))}
                            </div>
                          </div>
                        )}
                    </div>
                  </>
                </ListingCard>
                <ListingCard>
                  <>
                    <h3
                      ref={companyInfoSection}
                      className="border-b border-b-gray-100 pb-4 mb-6 font-medium"
                      id="company-info-heading"
                    >
                      Company Information
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-3">
                      <div className="pl-8 relative mb-2 md:mb-6">
                        <BuildingOfficeIcon className="h-6 absolute left-0" />
                        <div className="font-medium mb-1">Company</div>
                        <div className="text-sm" id="company-name">
                          {product.vendor?.name ?? "--"}
                        </div>
                      </div>

                      <div className="pl-8 relative mb-2 md:mb-6">
                        <MapPinIcon className="h-6 absolute left-0" />
                        <div className="font-medium mb-1">HQ Location</div>
                        <div className="text-sm" id="company-hq-location">
                          {product.vendor?.hq_location ?? "--"}
                        </div>
                      </div>

                      <div className="pl-8 relative mb-2 md:mb-6">
                        <CalendarIcon className="h-6 absolute left-0" />
                        <div className="font-medium mb-1">Year Founded</div>
                        <div className="text-sm" id="company-founded-year">
                          {product.vendor?.founded_year ?? "--"}
                        </div>
                      </div>

                      <div className="pl-8 relative mb-2 md:mb-6">
                        <UsersIcon className="h-6 absolute left-0" />
                        <div className="font-medium mb-1">
                          Number of Employees
                        </div>
                        <div className="text-sm" id="company-number-employees">
                          {product.vendor?.number_employees ?? "--"}
                        </div>
                      </div>

                      <div className="pl-8 relative mb-2 md:mb-6">
                        <ComputerDesktopIcon className="h-6 absolute left-0" />
                        <div className="font-medium mb-1">Company Website</div>
                        {product.vendor?.website ? (
                          <Link
                            to={product.vendor.website}
                            className="text-sm text-sky-500"
                            target="_blank"
                            id="company-website"
                          >
                            <p className="w-full truncate">
                              {product.vendor.website.replace(
                                /https?:\/\//,
                                ""
                              )}
                            </p>
                          </Link>
                        ) : (
                          <span>--</span>
                        )}
                      </div>

                      <div className="pl-8 relative mb-2 md:mb-6">
                        <img
                          src="/assets/linkedin-icon.png"
                          alt="linkedin icon"
                          className="h-6 w-auto absolute left-0"
                          width="32"
                          height="32"
                        />
                        <div className="font-medium mb-1">LinkedIn Profile</div>
                        {product.vendor?.linkedin_profile_url ? (
                          <Link
                            to={product.vendor.linkedin_profile_url}
                            className="text-sm text-sky-500"
                            id="company-linkedin-profile"
                          >
                            <p className="w-full truncate">
                              {product.vendor.linkedin_profile_url.replace(
                                /https?:\/\//,
                                ""
                              )}
                            </p>
                          </Link>
                        ) : (
                          <span>--</span>
                        )}
                      </div>
                    </div>
                  </>
                </ListingCard>
                {visibleIntegrationPartners &&
                  visibleIntegrationPartners.length > 0 && (
                    <ListingCard>
                      <div className="space-y-4">
                        <h3
                          className="border-b border-b-gray-100 pb-4 mb-6 font-medium"
                          ref={integrationPartnersSection}
                          id="integrations-heading"
                        >
                          Integration Partners
                        </h3>
                        <p className="mb-1">
                          See if {product.vendor?.name} connects with your
                          favorite tools. For product-to-product integrations or
                          technical questions, reach out to{" "}
                          {product.vendor?.name} for more information.
                        </p>
                        <div className="grid lg:grid-cols-2 gap-3 mt-4">
                          {visibleIntegrationPartners.map((t, i) => (
                            <div
                              key={i}
                              className="rounded-lg border border-gray-100 p-6 flex mb-2 space-x-3"
                              id={`integration-${t.id}`}
                            >
                              <div className="relative row-span-2 w-max">
                                {t.integrated_vendor?.logo_file_id ||
                                t.integrated_product?.logo_file_id ? (
                                  <img
                                    className="w-12 h-12 lg:w-16 lg:h-16 rounded-lg"
                                    src={`/images/${
                                      t.integrated_vendor?.logo_file_id ||
                                      t.integrated_product?.logo_file_id
                                    }`}
                                    width="64"
                                    height="64"
                                    alt="Vendor Logo"
                                  />
                                ) : (
                                  <img
                                    className="w-12 h-12 lg:w-16 lg:h-16 rounded-lg"
                                    src="/assets/default-logo.png"
                                    alt="Vendor Logo"
                                    width="64"
                                    height="64"
                                  />
                                )}
                                <VerifiedIcon className="h-5 lg:h-6 absolute top-[-0.5rem] right-[-0.5rem]" />
                              </div>
                              <div className="flex flex-col justify-center">
                                <div
                                  className="font-medium"
                                  id="integration-name"
                                >
                                  {t.integrated_vendor?.name ||
                                    t.integrated_product?.title}
                                </div>
                                <div className="font-light text-sm text-gray-400">
                                  <span className="inline-block align-middle mr-1">
                                    Data provided by{" "}
                                  </span>
                                  <Tooltip
                                    position="top"
                                    text={
                                      <div>
                                        {t.integration_provider ===
                                        IntegrationProvider.Propexo ? (
                                          <div>
                                            This integration data is provided by
                                            Propexo, a third-party vendor who
                                            verifies and updates industry data
                                            quarterly. <br /> <br /> Learn more
                                            at{" "}
                                            <a
                                              className="underline"
                                              href="https://www.propexo.com/"
                                              target="_blank"
                                              rel="noreferrer"
                                            >
                                              propexo.com
                                            </a>
                                          </div>
                                        ) : (
                                          <div>
                                            This integration data is validated
                                            by the vendor and updated by Revyse.
                                          </div>
                                        )}
                                      </div>
                                    }
                                  >
                                    <div className="cursor-pointer w-max">
                                      <b
                                        className="text-sky-500"
                                        id="integration-provider"
                                      >
                                        {t.integration_provider}
                                      </b>
                                    </div>
                                  </Tooltip>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="flex justify-between items-center">
                          <div className="font-light text-sm text-gray-400">
                            Last verified{" "}
                            {dayjs.utc(lastVerified).format("MM/DD/YYYY")}
                          </div>
                          {product.vendor?.vendor_integrations &&
                            product.vendor?.vendor_integrations?.length > 8 && (
                              <div>
                                {showAllIntegrationPartners ? (
                                  <button
                                    className="font-medium text-sky-500 flex items-center"
                                    onClick={() => {
                                      handleLinkClick(
                                        integrationPartnersSection
                                      );
                                      setShowAllIntegrationPartners(false);
                                    }}
                                  >
                                    Show Less
                                    <ChevronUpIcon className="h-5" />
                                  </button>
                                ) : (
                                  <button
                                    className="font-medium text-sky-500 flex items-center"
                                    onClick={() =>
                                      setShowAllIntegrationPartners(true)
                                    }
                                  >
                                    Show More
                                    <ChevronDownIcon className="h-5" />
                                  </button>
                                )}
                              </div>
                            )}
                        </div>
                      </div>
                    </ListingCard>
                  )}
                {tierHasPermission(activePlan?.tier, "show_pricing") &&
                  product.packages.length > 0 && (
                    <ListingCard>
                      <>
                        <h3
                          ref={pricingSection}
                          className="border-b border-b-gray-100 pb-4 md:mb-6 mb-2 font-medium"
                          id="pricing-heading"
                        >
                          Pricing
                        </h3>
                        {!user ? (
                          <FeatureLocked
                            bgImage="/assets/price-lock-blur.png"
                            text={
                              "Sign in to your verified buyer account to view"
                            }
                            linkText="Sign In"
                            to={`/sign-up?intent=BUYER&redirectTo=${encodeURIComponent(
                              `/products/${product.slug}`
                            )}`}
                          />
                        ) : !verifiedBuyer ? (
                          <FeatureLocked
                            bgImage="/assets/price-lock-blur.png"
                            text={
                              "Sign in to your verified buyer account to view"
                            }
                            linkText="Get Verified (its free!)"
                            onClick={onContactClick}
                          />
                        ) : (
                          product.packages.map((p, j) => {
                            const price = formatNumber(p.price ?? 0);
                            const unit =
                              p.price_type === "monthly"
                                ? "month"
                                : p.price_type;
                            return (
                              <div
                                key={j}
                                className="rounded-lg border border-gray-100 p-4 lg:p-10 flex flex-grow flex-col xl:flex-row mb-2"
                              >
                                <div className="xl:w-1/2">
                                  <div>{p.name}</div>
                                  <h3 className="font-medium pb-4">
                                    {!p.price || p.price <= 0
                                      ? "Free"
                                      : `Starting at $${price}/${unit}`}
                                  </h3>
                                  <div className="richtext">
                                    {HTMLReactParser(p.description)}
                                  </div>
                                </div>
                                <div className="xl:w-1/2 pt-10 xl:pt-0 text-sm">
                                  {p.features
                                    .filter(f => f)
                                    .map((feature, i) => (
                                      <div
                                        key={`${j}-${i}`}
                                        className="grid grid-cols-12"
                                      >
                                        <div className="h-6 w-6 col-span-1">
                                          <CheckIcon className="text-green-500 w-full" />{" "}
                                        </div>
                                        <div className="col-span-11 text-left">
                                          {feature}
                                        </div>
                                      </div>
                                    ))}
                                </div>
                              </div>
                            );
                          })
                        )}
                      </>
                    </ListingCard>
                  )}

                {tierHasPermission(activePlan?.tier, "show_demos") &&
                  (product.demo_files.length > 0 ||
                    product.demo_storylane_url) && (
                    <ListingCard>
                      <>
                        <h3
                          ref={demosSection}
                          className="border-b border-b-gray-100 pb-4 mb-6 font-medium flex justify-between"
                          id="product-demos-heading"
                        >
                          Product Demos
                          {/* <CTA to="#" className="text-sm">
                        Request Product Demo
                      </CTA> */}
                        </h3>
                        {!user ? (
                          <FeatureLocked
                            bgImage="/assets/demo-lock-blur.png"
                            text={
                              <>
                                Sign in to your verified buyer account to view
                              </>
                            }
                            linkText="Sign In"
                            to={`/sign-up?intent=BUYER&redirectTo=${encodeURIComponent(
                              `/products/${product.slug}`
                            )}`}
                          />
                        ) : !verifiedBuyer ? (
                          <FeatureLocked
                            bgImage="/assets/demo-lock-blur.png"
                            text={
                              "Sign in to your verified buyer account to view"
                            }
                            linkText="Get Verified (its free!)"
                            onClick={onContactClick}
                          />
                        ) : (
                          <div className="grid gap-4 w-11/12 lg:w-full mx-auto">
                            {product.demo_files.map(file => (
                              <div
                                key={file.id}
                                className="rounded-xl bg-black overflow-hidden"
                              >
                                <VideoPlayer key={file.id} fileId={file.id} />
                              </div>
                            ))}
                            {product.demo_storylane_url && (
                              <StorylaneDemo
                                demoUrl={product.demo_storylane_url}
                              />
                            )}
                          </div>
                        )}
                      </>
                    </ListingCard>
                  )}

                {tierHasPermission(activePlan?.tier, "show_product_images") &&
                  product.image_files.length > 0 && (
                    <ListingCard>
                      <>
                        <h3
                          ref={imagesSection}
                          className="border-b border-b-gray-100 pb-4 mb-6 font-medium"
                          id="product-images-heading"
                        >
                          Product Images and Screenshots
                        </h3>
                        {!user ? (
                          <FeatureLocked
                            bgImage="/assets/product-images-lock-blur.png"
                            text={
                              <>
                                Sign in to your verified buyer account to view
                              </>
                            }
                            linkText="Sign In"
                            to={`/sign-up?intent=BUYER&redirectTo=${encodeURIComponent(
                              `/products/${product.slug}`
                            )}`}
                          />
                        ) : !verifiedBuyer ? (
                          <FeatureLocked
                            bgImage="/assets/product-images-lock-blur.png"
                            text={
                              "Sign in to your verified buyer account to view"
                            }
                            linkText="Get Verified (its free!)"
                            onClick={onContactClick}
                          />
                        ) : (
                          <div className="grid md:grid-cols-3 grid-cols-1 gap-4">
                            {product.image_files.map(file => (
                              <div
                                className="md:w-auto h-36 w-11/12 lg:w-full mx-auto overflow-hidden border border-gray-100 rounded"
                                key={file.id}
                              >
                                <a
                                  href={`/images/${file.id}`}
                                  target="_blank"
                                  rel="noreferrer"
                                >
                                  <img
                                    src={`/images/${file.id}`}
                                    className="h-auto w-full"
                                    alt="product screenshot"
                                  />
                                </a>
                              </div>
                            ))}
                          </div>
                        )}
                      </>
                    </ListingCard>
                  )}

                {tierHasPermission(activePlan?.tier, "show_brand_videos") &&
                  product.brand_video_files.length > 0 && (
                    <ListingCard>
                      <>
                        <h3
                          ref={videosSection}
                          className="border-b border-b-gray-100 pb-4 mb-6 font-medium"
                          id="brand-videos-heading"
                        >
                          Brand Videos
                        </h3>
                        {!user ? (
                          <FeatureLocked
                            bgImage="/assets/brand-videos-lock-blur.png"
                            text={
                              <>
                                Sign in to your verified buyer account to view
                              </>
                            }
                            linkText="Sign In"
                            to={`/sign-up?intent=BUYER&redirectTo=${encodeURIComponent(
                              `/products/${product.slug}`
                            )}`}
                            variant="small"
                          />
                        ) : !verifiedBuyer ? (
                          <FeatureLocked
                            bgImage="/assets/price-lock-blur.png"
                            text={
                              "Sign in to your verified buyer account to view"
                            }
                            linkText="Get Verified (its free!)"
                            onClick={onContactClick}
                          />
                        ) : (
                          <div className="grid md:grid-cols-3 grid-cols-1 gap-4">
                            {product.brand_video_files.map(file => (
                              <div
                                className="h-min flex flex-col bg-white shadow-md rounded-lg w-11/12 lg:w-full mx-auto"
                                key={file.id}
                              >
                                <div className="md:w-auto h-36 w-full overflow-hidden border border-gray-100 rounded items-end justify-end">
                                  <VideoPlayer key={file.id} fileId={file.id} />
                                </div>
                                {/* Show the brand video titles without taking into account the old file names  */}
                                {file.title &&
                                  !videoExtensions.some(extension =>
                                    file.title.includes(extension)
                                  ) && (
                                    <h6 className="font-light text-center my-2">
                                      {file.title}
                                    </h6>
                                  )}
                              </div>
                            ))}
                            {((product.brand_video_urls as any[]) ?? []).map(
                              video => (
                                <div
                                  className="h-min flex flex-col bg-white shadow-md rounded-lg w-11/12 lg:w-full mx-auto"
                                  key={video.url}
                                >
                                  <div className="md:w-auto h-36 w-full overflow-hidden border border-gray-100 rounded items-end justify-end">
                                    <iframe
                                      className="w-full aspect-video"
                                      src={video.embedUrl}
                                      title="YouTube video player"
                                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                      allowFullScreen
                                    />
                                  </div>
                                  {video.title && (
                                    <h6 className="font-light text-center my-2">
                                      {video.title}
                                    </h6>
                                  )}
                                </div>
                              )
                            )}
                          </div>
                        )}
                      </>
                    </ListingCard>
                  )}

                {tierHasPermission(activePlan?.tier, "show_downloads") &&
                  product.download_files.length > 0 && (
                    <ListingCard>
                      <>
                        <h3
                          ref={downloadsSection}
                          className="border-b border-b-gray-100 pb-4 mb-6 font-medium"
                          id="downloads-heading"
                        >
                          Downloadable Content
                        </h3>
                        {!user ? (
                          <FeatureLocked
                            bgImage="/assets/downloads-lock-blur.png"
                            text={
                              <>
                                Sign in to your verified buyer account to view
                              </>
                            }
                            linkText="Sign In"
                            to={`/sign-up?intent=BUYER&redirectTo=${encodeURIComponent(
                              `/products/${product.slug}`
                            )}`}
                            variant="small"
                          />
                        ) : !verifiedBuyer ? (
                          <FeatureLocked
                            bgImage="/assets/downloads-lock-blur.png"
                            text={
                              "Sign in to your verified buyer account to view"
                            }
                            linkText="Get Verified (its free!)"
                            onClick={onContactClick}
                          />
                        ) : (
                          <div className="grid md:grid-cols-3 grid-cols-1 gap-4">
                            {product.download_files.map(file => (
                              <div className="" key={file.id}>
                                <DownloadableFilePreview
                                  id={file.id}
                                  type={file.mime_type}
                                  title={file.title}
                                  uri={file.uri}
                                />
                              </div>
                            ))}
                          </div>
                        )}
                      </>
                    </ListingCard>
                  )}

                <ListingCard>
                  <div ref={reviewsSection}>
                    <ReviewListComponent
                      product={product}
                      reviews={reviews}
                      user={user}
                    />
                  </div>
                </ListingCard>
              </div>
            </div>
          </div>
          <div className="md:rounded-2xl shadow-sm bg-white overflow-hidden py-8 mb-5">
            <h3 className="font-medium text-md px-8">Similar Products</h3>
            <div className="flex mt-4 overflow-x-scroll pl-8 gap-2">
              {similarProducts.map(p => (
                <ProductTile
                  key={p.id}
                  product={{
                    name: p.title,
                    avgRating: p.avg_score,
                    totalRatings: p.cnt,
                    logo_file: { id: p.logo_file_id },
                  }}
                  onClick={() => {
                    navigate(`/products/${p.slug}`);
                  }}
                  className="w-40 md:w-56 flex-grow-0 flex-shrink-0"
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
