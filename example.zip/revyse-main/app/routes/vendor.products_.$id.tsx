import {
  CheckIcon,
  PlusCircleIcon,
  TrashIcon,
} from "@heroicons/react/20/solid";
import type {
  ActionFunctionArgs,
  LinksFunction,
  LoaderFunctionArgs,
  SerializeFrom,
} from "@remix-run/node";
import { redirect, json } from "@remix-run/node";
import {
  Form,
  Link,
  useActionData,
  useLoaderData,
  useNavigation,
  useSearchParams,
} from "@remix-run/react";
import { isNil } from "lodash";
import { type ChangeEvent, useCallback, useEffect, useState } from "react";
import { z } from "zod";
import { Button, DangerButton } from "../components/button.component";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { assert, assertAuthorized } from "../utils/assert.utils.server";
import { issuesByKey } from "../utils/form.utils.server";
import { parseMultiPartFormDataS3Upload } from "../services/s3.service.server";
import { PortalPage } from "../components/portal-page.component";
import {
  CrudCheckboxField,
  CrudFileUpload,
  CrudSelectField,
  CrudTextField,
  CrudVideoUrlsField,
  FormSection,
} from "../components/form/crud-form.component";
import { EyeIcon, QuestionMarkCircleIcon } from "@heroicons/react/24/outline";
import type { StripeProduct, StripePrice } from "@prisma/client";
import { Role, ProductState, Tier } from "@prisma/client";
import { CrudTextAreaField } from "../components/form/textarea.component";
import { CurrencyField } from "../components/form/currency-field.component";
import { Currency, Slug } from "../utils/validation.utils.server";
import { slugify } from "../utils/string.utils";
import { assertAuthenticatedOrRedirect } from "../utils/auth.utils.server";
import { PlanChooserModal } from "../components/plan-chooser-modal.component";
import { Modal } from "../components/modal.component";
import {
  tierHasPermission,
  userHasPermission,
} from "../utils/permission.utils";
import { Editor } from "~/components/reactquill/richtext-editor.component";
import stylesheetQuill from "react-quill/dist/quill.snow.css";
import {
  jsonWithError,
  jsonWithSuccess,
  redirectWithSuccess,
} from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { castFormFields } from "~/utils/type.utils";
import { tvField } from "~/utils/global-tailwind-variants.utils";
import { LogoBanner } from "~/components/logo-banner.component";
import { FormWithUploads } from "~/components/form/form-with-uploads.component";

const VIDEOS_LIMIT = 6;

const StringArrayWithoutEmptyStrings = z
  .array(
    z
      .string()
      .min(1)
      .transform(v => (v === "--" ? "" : v))
  )
  .transform(v => v.filter(v => v !== ""))
  .transform(v => (v.length === 0 ? undefined : v));

const BrandVideoUrlJson = z.array(
  z.object({
    title: z.optional(z.string()),
    url: z.string().url(),
    type: z.enum(["youtube"]),
    embedUrl: z.string().url(),
  })
);

export const updateAction = async ({
  id,
  form,
  vendorId,
}: {
  id: string | undefined;
  form: FormData;
  vendorId: string | undefined;
}) => {
  // Special parsing for features because of the way http forms work
  const featureIds = form.getAll("features.id") as string[];
  const featureNames = form.getAll("features.name") as string[];
  const featureDescriptions = form.getAll("features.description") as string[];
  const featureOrders = form.getAll("features.order") as string[];
  const features = featureIds.map((id, i) => ({
    id: id.indexOf("new") === 0 ? undefined : id,
    name: featureNames[i],
    description: featureDescriptions[i],
    order: parseInt(featureOrders[i]),
  }));

  // Special parsing for packages because of the way http forms work
  const packageIds = form.getAll("packages.id") as string[];
  const packageNames = form.getAll("packages.name") as string[];
  const packageDescriptions = form.getAll("packages.description") as string[];
  const packageOrders = form.getAll("packages.order") as string[];
  const packageFeatures = form.getAll("packages.features") as string[];
  const packageButtonTexts = form.getAll("packages.button_text") as string[];
  const packageButtonUrls = form.getAll("packages.button_url") as string[];
  const packages = packageIds.map((id, i) => {
    const packagePrefix = `packages.${id}.`;
    return {
      id: id.indexOf("new") === 0 ? undefined : id,
      name: packageNames[i],
      description: packageDescriptions[i],
      order: parseInt(packageOrders[i]),
      features: packageFeatures.slice(i * 8, (i + 1) * 8),
      price_type: form.get(`${packagePrefix}price_type`),
      price: form.get(`${packagePrefix}price`),
      button_text: packageButtonTexts[i],
      button_url: packageButtonUrls[i],
    };
  });
  const brandVideoTitles = form.getAll("brand_video_titles.title") as string[];
  const brandVideoTitlesIds = form.getAll("brand_video_titles.id") as string[];
  const brand_video_titles = brandVideoTitlesIds.map((id, i) => {
    return {
      id: id.indexOf("new") === 0 ? `new_${i + 1}` : id,
      title: brandVideoTitles[i],
    };
  });

  const brand_video_urls: {
    title: string;
    url: string;
    type: "youtube";
    embedUrl: string;
  }[] = JSON.parse((form.get("brand_video_urls") as string) || "[]");

  const fields = {
    title: form.get("title"),
    description: form.get("description"),
    positioning: form.get("positioning"),
    primary_category_id: form.get("primary_category_id"),
    secondary_category_id: form.get("secondary_category_id"),
    tertiary_category_id: form.get("tertiary_category_id"),
    lead_prospect_email: form.get("lead_prospect_email"),
    demo_scheduling_url: form.get("demo_scheduling_url"),
    banner_file_id: form.get("banner_file_id"),
    logo_file_id: form.get("logo_file_id"),
    image_files: form.getAll("image_files") as string[],
    brand_video_files: form.getAll("brand_video_files"),
    brand_video_titles,
    brand_video_urls,
    download_files: form.getAll("download_files") as string[],
    demo_files: form.getAll("demo_files") as string[],
    demo_storylane_url: form.get("demo_storylane_url"),
    features,
    industries: form.getAll("industries") as string[],
    good_for_tags: form.getAll("good_for_tags") as string[],
    packages,
    review_questions: form.getAll("review_questions") as string[],
    slug: form.get("slug") ?? undefined,
    stripeProductId: form.get("stripeProductId"),
    stripePriceId: form.get("stripePriceId"),
    vendor_id: vendorId,
    promo_text: form.get("promo_text"),
  };
  const { stripeService, productService } = await WebDIContainer();

  const ProductForm = z
    .object({
      title: z
        .string()
        .max(55, "Title must be maximum 55 characters")
        .min(1, "Title is required"),
      description: z
        .string()
        .max(500, "Description must be maximum 500 characters")
        .min(1, "Description is required"),
      positioning: z
        .string()
        .optional()
        .nullable()
        .transform(v => v ?? ""),
      primary_category_id: z.string(),
      secondary_category_id: z
        .string()
        .transform(v => (v === "null" ? null : v))
        .optional()
        .nullable(),
      tertiary_category_id: z
        .string()
        .transform(v => (v === "null" ? null : v))
        .optional()
        .nullable(),
      lead_prospect_email: z.string().email().or(z.string().max(0)).nullable(),
      demo_scheduling_url: z.string().url().or(z.string().max(0)).nullable(),
      demo_storylane_url: z.string().url().or(z.string().max(0)).nullable(),
      banner_file_id: z
        .string()
        .min(1)
        .nullable()
        .transform(v => (v === "--" ? undefined : v ?? undefined)),
      logo_file_id: z
        .string()
        .min(1)
        .nullable()
        .transform(v => (v === "--" ? undefined : v ?? undefined)),
      image_files: StringArrayWithoutEmptyStrings,
      brand_video_files: StringArrayWithoutEmptyStrings,
      brand_video_urls: BrandVideoUrlJson,
      download_files: StringArrayWithoutEmptyStrings,
      demo_files: StringArrayWithoutEmptyStrings,
      features: z.array(
        z.object({
          id: z.string().uuid().optional(),
          name: z.string().min(1, "Feature name is required."),
          description: z.string().min(1, "Feature description is required."),
          order: z
            .number({
              invalid_type_error: "Order should be a number",
              required_error: "Order is required",
            })
            .int(),
        })
      ),
      industries: z.array(z.string().uuid()).max(5, "Max 5 industries"),
      good_for_tags: z.array(z.string().uuid()).max(5, "Max 5 tags"),
      packages: z.array(
        z.object({
          id: z.string().uuid().optional(),
          name: z.string().min(1, "Title is required"),
          description: z.string().min(1, "Description is required"),
          order: z.number({ invalid_type_error: "Required" }).int(),
          features: z.array(z.string()),
          price_type: z.string().optional(),
          price: Currency,
          // button_text: z.string({
          //   invalid_type_error: "Button text is required",
          // }),
          // button_url: z.string({ invalid_type_error: "Button URL is required" }),
        })
      ),
      review_questions: z.array(z.string()),
      slug: id === "new" ? Slug : z.undefined(),
      stripeProductId:
        id === "new"
          ? z
              .string()
              .refine(async val =>
                stripeService.getStripeProduct(val, { active: true })
              )
          : z.undefined().nullable(),
      stripePriceId:
        id === "new"
          ? z
              .string()
              .refine(async val =>
                stripeService.getStripePrice(val, { active: true })
              )
          : z.undefined().nullable(),
      promo_text: z.string().max(25, "Max 25 characters").nullable(),
      vendor_id: z.string().optional(),
    })
    .superRefine((values, ctx) => {
      // Limiting videos max
      const count =
        values.brand_video_urls.length +
        (fields.brand_video_titles.length || 0);
      if (VIDEOS_LIMIT && count > VIDEOS_LIMIT) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          path: ["brand_video_max"],
          message: `Max ${VIDEOS_LIMIT} videos`,
        });
      }
    });

  const validation = await ProductForm.safeParseAsync(fields);
  if (validation.success) {
    try {
      const { stripePriceId } = validation.data;

      if (id === "new") {
        const params = new URLSearchParams();

        params.set("title", validation.data.title);
        params.set("description", validation.data.description);
        params.set("slug", validation.data.slug || "");
        params.set("primary_category_id", validation.data.primary_category_id);
        params.set("vendor_id", validation.data.vendor_id || "");

        return redirect(
          `/checkout/${stripePriceId}/${id}?${params.toString()}`
        );
      }

      validation.data.stripeProductId = undefined;
      validation.data.stripePriceId = undefined;

      const product = await productService.getProductIncludingAllFields(id!);

      if (!product) {
        throw new Response("Not found", { status: 404 });
      }

      await productService.updateProduct(product.id, {
        ...validation.data,
        image_files: [
          ...product.image_files.map(f => f.id),
          ...(validation.data.image_files ?? []),
        ],
        brand_video_files: [
          ...product.brand_video_files.map(f => f.id),
          ...(validation.data.brand_video_files ?? []),
        ],
        download_files: [
          ...product.download_files.map(f => f.id),
          ...(validation.data.download_files ?? []),
        ],
        demo_files: [
          ...product.demo_files.map(f => f.id),
          ...(validation.data.demo_files ?? []),
        ],
        brand_video_titles,
      });
    } catch (e: any) {
      console.error(e);

      let issue = { path: ["general"], message: e.message };
      if (e.message.includes("Unique constraint failed")) {
        if (e.message.includes("slug")) {
          issue = { path: ["slug"], message: "Slug is already taken" };
        } else if (e.message.includes("title")) {
          issue = { path: ["title"], message: "Name is already taken" };
        }
      }
      return jsonWithError(
        {
          success: false,
          fields: castFormFields(fields),
          errors: issuesByKey([issue]),
        },
        DEFAULT_FORM_ERROR_MESSAGE,
        { status: 400 }
      );
    }
    return jsonWithSuccess(
      {
        success: true,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      },
      "Product updated successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return jsonWithError(
    { success: false, fields: castFormFields(fields), errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
};

async function deleteAction({ id }: { id: string | undefined }) {
  const { productService } = await WebDIContainer();

  try {
    await productService.deleteProduct(id!);
  } catch (error) {
    if (
      error instanceof Error &&
      error.message === "Cannot delete listing with subscriptions"
    ) {
      assert(false, "Cannot delete listing with subscriptions");
    }
    assert(false, "Error deleting product");
  }
  return redirectWithSuccess(
    "/vendor/products",
    "Product deleted successfully"
  );
}

const MB = 1024 * 1024;
const LOGO_BYTE_LIMIT = 0.5 * MB;
const IMG_BYTE_LIMIT = 5 * MB;
const VID_BYTE_LIMIT = 60 * MB;

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const user = await assertAuthenticatedOrRedirect(request);

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const vendorIdParam = search.get("vendor_id");

  const { productSubscriptionService } = await WebDIContainer();
  const userSubscriptions =
    await productSubscriptionService.getSubscriptionsForUser(user);
  const productSubscription = userSubscriptions.find(
    s => s.product_id === params.id
  );
  const godModeRole = user.user_roles.find(r => r.role === Role.GOD_MODE);

  assertAuthorized(godModeRole || productSubscription, "Unauthorized");

  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "banner_file_id", byteLimit: LOGO_BYTE_LIMIT },
    { field: "logo_file_id", byteLimit: LOGO_BYTE_LIMIT },
    { field: "image_files", byteLimit: IMG_BYTE_LIMIT },
    { field: "brand_video_files", byteLimit: VID_BYTE_LIMIT },
    { field: "download_files", byteLimit: IMG_BYTE_LIMIT },
    { field: "demo_files", byteLimit: VID_BYTE_LIMIT },
  ]);
  const intent = form.get("intent");
  if (intent === "delete") {
    return deleteAction({ id: params.id });
  }

  return updateAction({
    id: params.id,
    form,
    vendorId: vendorIdParam ?? undefined,
  });
};

export const links: LinksFunction = () => [
  { rel: "stylesheet", href: stylesheetQuill },
];

export async function loader({ params, request }: LoaderFunctionArgs) {
  const id = params.id;
  const { productSubscriptionService, productService, stripeService } =
    await WebDIContainer();
  const user = await assertAuthenticatedOrRedirect(request);

  const searchParams = new URLSearchParams(new URL(request.url).search);

  const product =
    id === "new"
      ? ({
          id: "new",
          title: searchParams.get("title") || "",
          slug: searchParams.get("slug") || "",
          description: searchParams.get("description") || "",
          primary_category_id: searchParams.get("primary_category_id") || "",
          state: null,
          industries: [],
          banner_url: null,
          brand_video_urls: [],
          positioning: "",
          created_at: new Date(),
          demo_scheduling_url: null,
          download_urls: [],
          features: [],
          good_for_tags: [],
          image_urls: [],
          lead_prospect_email: null,
          logo_url: null,
          packages: [],
          product_demo_urls: [],
          review_questions: [],
          secondary_category_id: null,
          tertiary_category_id: null,
          updated_at: new Date(),
          vendor: null,
          vendor_id: searchParams.get("vendor_id") || "",
          banner_file_id: null,
          banner_file: null,
          logo_file_id: null,
          logo_file: null,
          image_files: [],
          brand_video_files: [],
          download_files: [],
          demo_files: [],
          approved_at: null,
          approved_by_id: null,
          page_title: "",
          meta_description: "",
          subscriptions: [],
          promo_text: null,
          demo_storylane_url: null,
          manager_account_id: null,
        } as Awaited<
          ReturnType<typeof productService.getProductIncludingAllFields>
        >)
      : await productService.getProductIncludingAllFields(id!);

  if (!product) {
    throw new Response("Not found", { status: 404 });
  }

  const godModeRole = user.user_roles.find(r => r.role === Role.GOD_MODE);
  const userSubscriptions =
    await productSubscriptionService.getSubscriptionsForUser(user);
  const productSubscription = userSubscriptions.find(
    s => s.product_id === params.id
  );
  assertAuthorized(godModeRole || productSubscription, "Unauthorized");

  const stripeProducts = await stripeService.getPlanChooserStripeProducts();

  const assignedUsersCount =
    id !== "new" && product.subscriptions[0]
      ? await productSubscriptionService.getSubscriptionUserCount(
          product.subscriptions[0]
        )
      : 0;

  return json({
    product,
    categories: await productService.getCategoryOptions(),
    industries: await productService.getIndustryOptions(),
    good_for_tags: await productService.getGoodForTagOptions(),
    stripeProducts,
    userRole: productSubscription?.user_roles.find(r => r.user_id === user.id)
      ?.role,
    assignedUsersCount,
  });
}

export default function VendorProductEditRoute() {
  const actionData = useActionData<typeof action>();
  const navigation = useNavigation();
  const {
    product,
    categories,
    industries,
    good_for_tags,
    stripeProducts,
    userRole,
    assignedUsersCount,
  } = useLoaderData<typeof loader>();

  const activeSubscription: (typeof product.subscriptions)[number] | null =
    product.subscriptions[0] ?? null;

  const tier = activeSubscription?.stripe_price.product.tier;
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  const [pricingDescriptions, setPricingDescriptions] = useState<
    { id: number | null; value: string }[]
  >(
    product.packages.length > 0
      ? product.packages.map((item, index) => ({
          id: index,
          value: item.description,
        }))
      : [{ id: 0, value: "" }]
  );

  const [features, setFeatures] = useState<
    Pick<
      (typeof product.features)[number],
      "id" | "order" | "name" | "description"
    >[]
  >(product.features ?? []);
  const [slug, setSlug] = useState(
    actionData?.fields.slug ?? product.slug ?? ""
  );
  const [packages, setPackages] = useState<
    Pick<
      (typeof product.packages)[number],
      | "id"
      | "order"
      | "name"
      | "description"
      | "features"
      | "price_type"
      | "price"
      | "button_text"
      | "button_url"
    >[]
  >(product.packages ?? []);

  const [searchParams] = useSearchParams();

  const stripePriceId =
    actionData?.fields.stripePriceId ?? searchParams.get("stripePriceId") ?? "";

  const [stripePrice, setStripePrice] = useState<
    SerializeFrom<StripePrice> | undefined
  >();
  const [stripeProduct, setStripeProduct] = useState<
    | SerializeFrom<StripeProduct & { prices: SerializeFrom<StripePrice>[] }>
    | undefined
  >();

  useEffect(() => {
    for (const _stripeProduct of stripeProducts) {
      for (const _stripePrice of _stripeProduct.prices) {
        if (_stripePrice.id === stripePriceId) {
          setStripePrice(_stripePrice);
          setStripeProduct(_stripeProduct);
          break;
        }
      }
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const [choosePlanModalOpen, setChoosePlanModalOpen] = useState(false);
  const [unpublishedModalOpen, setUnpublishedModalOpen] = useState(false);

  useEffect(() => {
    if (navigation.state == "idle") {
      window.scrollTo(0, 0);
    }
  }, [navigation.state]);

  const [videoTitles, setVideoTitles] = useState(
    product.brand_video_files.map(video => ({
      id: video.id,
      title: video.title,
    }))
  );
  const [youtubeVideos, setYoutubeVideos] = useState<
    {
      title: string;
      url: string;
      type: "youtube";
      embedUrl: string;
    }[]
  >((product.brand_video_urls as any) ?? []);

  useEffect(() => {
    setVideoTitles(
      product.brand_video_files.map(video => ({
        id: video.id,
        title: video.title,
      }))
    );
  }, [product]);

  const handleNewBrandVideos = () => (event: ChangeEvent<HTMLInputElement>) => {
    const newTitlesArray = event.target.files
      ? Array.from(event.target.files).map((file, index) => ({
          id: `new_${index}`,
          title: "",
        }))
      : [];
    const updatedTitles = videoTitles.filter(
      video => !video.id.includes("new")
    );
    setVideoTitles([...updatedTitles, ...newTitlesArray]);
  };

  const handleVideoTitleChange =
    (index: number) => (event: ChangeEvent<HTMLInputElement>) => {
      const newTitles = [...videoTitles];
      newTitles[index].title = event.target.value;
      setVideoTitles(newTitles);
    };

  const updateVideoTitle = (index: number, childData: string) => {
    const newTitles = [...videoTitles];
    newTitles[index].title = childData;
    setVideoTitles(newTitles);
  };

  const handleVideoUrlsChange = useCallback(
    (
      videos: {
        title: string;
        url: string;
        type: "youtube";
        embedUrl: string;
      }[]
    ) => {
      setYoutubeVideos(videos);
    },
    []
  );

  // eslint-disable-next-line @typescript-eslint/no-empty-function
  useEffect(() => {}, [videoTitles]);

  return (
    <PortalPage
      crumbs={[
        { name: "Dashboard", to: "/vendor" },
        { name: "Products", to: "/vendor/products" },
        {
          name: product.id === "new" ? "New Product Listing" : product.title,
          to: `/vendor/products/${product.id}`,
          active: true,
        },
      ]}
      buttonsSlot={
        <div className="flex justify-between gap-2">
          {product.id !== "new" &&
            product.approved_at &&
            product.state === ProductState.discovery && (
              <Button to={`/products/${product.slug}`} id="view-listing">
                <EyeIcon className="h-6 mr-2" /> View Listing
              </Button>
            )}
          {product.id !== "new" &&
            !activeSubscription &&
            (confirmDeleteOpen ? (
              <Form
                className="flex justify-between  items-center"
                method="post"
                encType="multipart/form-data"
              >
                Are you sure you want to delete this product?
                <input type="hidden" name="intent" value="delete" />
                <Button
                  onClick={() => setConfirmDeleteOpen(false)}
                  className="ml-2"
                >
                  Cancel
                </Button>
                <DangerButton type="submit" className="ml-2">
                  Yep!
                </DangerButton>
              </Form>
            ) : (
              <DangerButton
                onClick={() => {
                  setConfirmDeleteOpen(!confirmDeleteOpen);
                }}
              >
                <div className="flex">
                  <TrashIcon className="h-5 mr-1" />
                  Delete
                </div>
              </DangerButton>
            ))}
        </div>
      }
    >
      <>
        <PlanChooserModal
          isOpen={choosePlanModalOpen}
          onClose={() => setChoosePlanModalOpen(false)}
          onChoose={(stripeProduct, stripePrice) => {
            setStripeProduct(stripeProduct);
            setStripePrice(stripePrice);
            setChoosePlanModalOpen(false);
          }}
          product={product}
          stripeProducts={stripeProducts}
        />
        <Modal
          isOpen={unpublishedModalOpen}
          onClose={() => setUnpublishedModalOpen(false)}
        >
          <h1>Unpublished Listing</h1>
          <p>
            Revyse content specialists review every new product listing for
            quality. Once that's done you'll be notified via email and your
            sparkly new listing will be ready for the world.
          </p>
          <p>
            If you have any questions or concerns please contact{" "}
            <Link to="mailto:support@revyse.com">support@revyse.com</Link>
          </p>
        </Modal>
        <FormWithUploads className="relative">
          {product.id === "new" && (
            <div className="grid md:grid-cols-3">
              <div></div>
              <div className="col-span-2 px-4">
                <h2 className="mb-2 text-2xl font-medium">
                  Tell us about your new product listing
                </h2>
                <p className="mb-6">
                  Fill out the form to create your listing and hit 'Go to
                  Checkout' when you're ready to confirm your new subscription.
                  After you've checked out, you can return to the vendor portal
                  at any time to continue updating your new listing.
                </p>
              </div>
            </div>
          )}

          {product.id === "new" && (
            <FormSection title="Plan">
              <div className="col-span-2">Select your listing package: </div>
              <div className="col-span-2">
                <button
                  onClick={() => setChoosePlanModalOpen(true)}
                  className="text-sky-600 capitalize"
                  type="button"
                >
                  {stripeProduct
                    ? `${stripeProduct?.name} - ${stripePrice?.cadence}`
                    : "Choose"}
                </button>
              </div>
              {actionData?.errors?.stripeProductId ? (
                <div className="col-span-2 text-red-500">Plan is required</div>
              ) : (
                ""
              )}

              <input
                type="hidden"
                name="stripeProductId"
                value={stripeProduct?.id ?? ""}
              />
              <input
                type="hidden"
                name="stripePriceId"
                value={stripePrice?.id ?? ""}
              />
            </FormSection>
          )}

          <FormSection
            title="Product Overview"
            subtitle={
              <>
                {product.approved_at &&
                product.state === ProductState.discovery ? (
                  <div className="text-green-600 text-xs flex my-2 gap-2">
                    <CheckIcon className="h-4" /> Published
                  </div>
                ) : product.id !== "new" ? (
                  <button
                    onClick={() => setUnpublishedModalOpen(true)}
                    className="text-sky-600 text-xs flex my-2 gap-2"
                    type="button"
                  >
                    <QuestionMarkCircleIcon className="h-4" /> Not Published
                  </button>
                ) : (
                  ""
                )}

                {activeSubscription ? (
                  <div className="text-xs my-4">
                    Subscription:{" "}
                    {userRole &&
                    userHasPermission(
                      userRole,
                      "manage_product_subscription"
                    ) ? (
                      <Link
                        onClick={e => e.stopPropagation()}
                        to={`/stripe_portal/${activeSubscription.id}`}
                        className="text-sky-600"
                      >
                        {activeSubscription.stripe_price.product.name}
                      </Link>
                    ) : (
                      <span>
                        {activeSubscription.stripe_price.product.name}
                      </span>
                    )}
                  </div>
                ) : (
                  ""
                )}
                {userRole &&
                  userHasPermission(userRole, "see_user_list") &&
                  product.id !== "new" && (
                    <div>
                      <h2 className="text-base font-semibold leading-7 text-gray-900">
                        User management
                      </h2>
                      <div className="flex flex-col text-xs">
                        <div className="mt-1 text-gray-600">
                          Number of assigned users: <b>{assignedUsersCount}</b>
                        </div>
                        <Link
                          id="user-list"
                          onClick={e => e.stopPropagation()}
                          to={`/vendor/product/${activeSubscription.id}/users/`}
                          className="text-sky-600 mt-4"
                        >
                          Go to user list
                        </Link>
                        <Link
                          id="invite-user"
                          onClick={e => e.stopPropagation()}
                          to={`/vendor/product/${activeSubscription.id}/users/new/`}
                          className="text-sky-600 mt-2"
                        >
                          Invite new user
                        </Link>
                      </div>
                    </div>
                  )}
                <div className="lg:my-12 my-4 text-xs">
                  <p>Need a hand? </p>
                  <p>
                    Contact{" "}
                    <Link
                      className="text-sky-600"
                      to="mailto:support@revyse.com"
                    >
                      support@revyse.com
                    </Link>
                  </p>
                  <p>We're here to help.</p>
                </div>
              </>
            }
          >
            <div className="col-span-full">
              <LogoBanner
                logoError={actionData?.errors.logo_file_id ?? []}
                logo={product?.logo_file}
                bannerError={actionData?.errors.banner_file_id ?? []}
                banner={product?.banner_file}
                showBanner={tierHasPermission(tier, "show_custom_banner_image")}
              />
            </div>
            <CrudTextField
              field={{
                name: "title",
                label: "Product Name",
                type: "text",
                defaultValue: actionData?.fields.title ?? product?.title,
                errors: actionData?.errors.title ?? [],
                onChange: e => {
                  if (product.id !== "new") return;
                  const slugField = document.getElementById(
                    "slug"
                  ) as HTMLInputElement;
                  const slugged = slugify(e.target.value);
                  setSlug(slugged);
                  slugField.value = slugged;
                },
                maxCharacters: 55,
              }}
            />
            <CrudTextField
              field={{
                name: "slug",
                label: "URL Slug",
                type: "text",
                defaultValue: slug,
                errors: actionData?.errors.slug ?? [],
                disabled: product.id !== "new",
                onChange: e => {
                  const slugged = slugify(e.target.value);
                  setSlug(slugged);
                  e.target.value = slugged;
                },
              }}
            />
            <p className="col-span-full -mt-8 text-xs text-gray-500">
              The product listing will appear at{" "}
              <code>revyse.com/products/{slug}</code>. This cannot be changed
              after the listing has been created.
            </p>
            <CrudTextAreaField
              field={{
                name: "description",
                label: "Product Description",
                placeholder: "A full description of the product",
                type: "textarea",
                defaultValue:
                  actionData?.fields.description ?? product?.description,
                errors: actionData?.errors.description ?? [],
                maxCharacters: 500, // 500 characters max for the product description
              }}
            />
            {tierHasPermission(tier, "show_positioning") && (
              <CrudTextAreaField
                field={{
                  name: "positioning",
                  label: "Product Positioning",
                  placeholder: "How is the product positioned in the market?",
                  type: "textarea",
                  defaultValue:
                    actionData?.fields.positioning ?? product?.positioning,
                  errors: actionData?.errors.positioning ?? [],
                }}
              />
            )}
          </FormSection>

          {tierHasPermission(tier, "show_features") && (
            <FormSection title="Main Features" subtitle="(up to 6)">
              <>
                {features.map((f, i) => (
                  <div
                    key={f.id}
                    className="flex col-span-full items-start gap-2"
                  >
                    <input type="hidden" name="features.id" value={f.id} />
                    <CrudTextField
                      field={{
                        name: "features.order",
                        label: "Order",
                        type: "text",
                        defaultValue: f.order,
                        errors: actionData?.errors[`features.${i}.order`] || [],
                      }}
                      className="w-10"
                    />
                    <CrudTextField
                      field={{
                        name: "features.name",
                        label: "Title",
                        type: "text",
                        defaultValue: f.name,
                        errors: actionData?.errors[`features.${i}.name`] || [],
                      }}
                      className="flex-grow"
                    />
                    <CrudTextAreaField
                      field={{
                        name: "features.description",
                        label: "Description",
                        description: "",
                        type: "textarea",
                        defaultValue: f.description,
                        errors:
                          actionData?.errors[`features.${i}.description`] || [],
                      }}
                      className="flex-grow"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const newFeatures = [...features];
                        newFeatures.splice(i, 1);
                        setFeatures(newFeatures);
                      }}
                      className="p-2 mt-7 bg-red-600 rounded-full text-white"
                    >
                      <TrashIcon className="h-5" />
                    </button>
                  </div>
                ))}
                <button
                  className={`flex items-center col-span-2 ${
                    features.length >= 6 ? "text-gray-300" : ""
                  }`}
                  type="button"
                  onClick={() => {
                    const newFeature = {
                      id: `new-${features.length + 1}`,
                      order: features.length + 1,
                      name: "",
                      description: "",
                    };
                    setFeatures([...features, newFeature]);
                  }}
                  disabled={features.length >= 6}
                >
                  <PlusCircleIcon className="h-8 mr-2" />
                  Add Feature
                </button>
              </>
            </FormSection>
          )}
          <FormSection title="Product Categories">
            <CrudSelectField
              field={{
                name: "primary_category_id",
                label: "Primary Category",
                type: "select",
                options: categories.map(c => ({ label: c.name, value: c.id })),
                defaultValue:
                  actionData?.fields.primary_category_id ??
                  product?.primary_category_id,
                errors: actionData?.errors.primary_category_id ?? [],
                description:
                  "Don't see your category listed? Reach out to support@revyse.com and we'll get you squared away.",
              }}
            />

            {((product.id !== "new" &&
              tierHasPermission(tier, "show_product_categories")) ||
              product.vendor?.slug === "zipcode-creative") && (
              <>
                <CrudSelectField
                  field={{
                    name: "secondary_category_id",
                    label: "Secondary Category",
                    type: "select",
                    options: categories.map(c => ({
                      label: c.name,
                      value: c.id,
                    })),
                    defaultValue:
                      actionData?.fields.secondary_category_id ??
                      product?.secondary_category_id ??
                      undefined,
                    errors: actionData?.errors.secondary_category_id ?? [],
                    allowNull: true,
                  }}
                />
                <CrudSelectField
                  field={{
                    name: "tertiary_category_id",
                    label: "Tertiary Category",
                    type: "select",
                    options: categories.map(c => ({
                      label: c.name,
                      value: c.id,
                    })),
                    defaultValue:
                      actionData?.fields.tertiary_category_id ??
                      product?.tertiary_category_id ??
                      undefined,
                    errors: actionData?.errors.tertiary_category_id ?? [],
                    allowNull: true,
                  }}
                />
              </>
            )}
          </FormSection>
          {product.id !== "new" && (
            <>
              <FormSection
                title="Industries Served"
                subtitle="(choose up to 5)"
              >
                <div className="grid md:grid-cols-2 gap-2 col-span-full">
                  {industries.map(i => (
                    <div className="md:w-64 w-full" key={i.id}>
                      <CrudCheckboxField
                        field={{
                          name: `industries`,
                          description: "",
                          type: "checkbox",
                          label: i.name,
                          value: i.id,
                          errors: [],
                          defaultChecked: !!product.industries.find(
                            i2 => i2.id === i.id
                          ),
                        }}
                      />
                    </div>
                  ))}
                  <div className="text-red-600 col-span-full">
                    {(actionData?.errors.industries ?? []).join(",")}
                  </div>
                </div>
              </FormSection>
              {tierHasPermission(tier, "show_good_for_tags") && (
                <FormSection
                  title={`"Good for" Tags`}
                  subtitle="(choose up to 5)"
                >
                  <div className="grid md:grid-cols-2 gap-2 col-span-full">
                    {good_for_tags.map(i => (
                      <div className="md:w-64 w-full" key={i.id}>
                        <CrudCheckboxField
                          field={{
                            name: `good_for_tags`,
                            description: "",
                            type: "checkbox",
                            label: i.name,
                            value: i.id,
                            errors: [],
                            defaultChecked: !!product.good_for_tags.find(
                              i2 => i2.id === i.id
                            ),
                          }}
                        />
                      </div>
                    ))}
                    <div className="text-red-600 col-span">
                      {(actionData?.errors.good_for_tags ?? []).join(",")}
                    </div>
                  </div>
                </FormSection>
              )}

              {(tierHasPermission(tier, "contact_vendor") ||
                tierHasPermission(tier, "schedule_demo") ||
                tierHasPermission(tier, "show_promo")) && (
                <FormSection title="Lead Generation">
                  {tierHasPermission(tier, "show_promo") && (
                    <CrudTextField
                      field={{
                        name: "promo_text",
                        label: "Featured Promotion",
                        placeholder: "e.g. 20% off for 3 months",
                        type: "text",
                        defaultValue:
                          actionData?.fields.promo_text ??
                          product?.promo_text ??
                          undefined,
                        errors: actionData?.errors.promo_text ?? [],
                        maxCharacters: 25,
                      }}
                    />
                  )}
                  {tierHasPermission(tier, "contact_vendor") && (
                    <CrudTextField
                      field={{
                        name: "lead_prospect_email",
                        label: "Lead Prospect Email",
                        placeholder: "e.g. piper.smith@someco.com",
                        type: "text",
                        defaultValue:
                          actionData?.fields.lead_prospect_email ??
                          product?.lead_prospect_email ??
                          undefined,
                        errors: actionData?.errors.lead_prospect_email ?? [],
                      }}
                    />
                  )}
                  {tierHasPermission(tier, "schedule_demo") && (
                    <CrudTextField
                      field={{
                        name: "demo_scheduling_url",
                        label: "Demo Scheduling URL",
                        type: "text",
                        placeholder: "e.g. https://calendly.com/your-profile",
                        defaultValue:
                          actionData?.fields.demo_scheduling_url ??
                          product?.demo_scheduling_url ??
                          undefined,
                        errors: actionData?.errors.demo_scheduling_url ?? [],
                      }}
                    />
                  )}
                </FormSection>
              )}

              {tierHasPermission(tier, "show_pricing") && (
                <FormSection title="Pricing">
                  <>
                    {packages.map((f, i) => (
                      <div
                        key={f.id}
                        className="grid md:grid-cols-2 col-span-full items-start gap-2 pb-4 border-b border-b-grey-200"
                      >
                        <div className="flex items-start col-span-full gap-6">
                          <input
                            type="hidden"
                            name="packages.id"
                            value={f.id}
                          />
                          <CrudTextField
                            field={{
                              name: "packages.order",
                              label: "Order",
                              type: "text",
                              defaultValue: f.order,
                              errors:
                                actionData?.errors[`packages.${i}.order`] ?? [],
                            }}
                            className="w-10"
                          />
                          <CrudTextField
                            field={{
                              name: "packages.name",
                              label: "Title",
                              type: "text",
                              defaultValue: f.name,
                              errors:
                                actionData?.errors[`packages.${i}.name`] ?? [],
                            }}
                            className="flex-grow"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              const newPackages = [...packages];
                              newPackages.splice(i, 1);
                              setPackages(newPackages);
                            }}
                            className="p-2 -mt-1 bg-red-600 rounded-full text-white w-9"
                          >
                            <TrashIcon className="h-5" />
                          </button>
                        </div>
                        <div className="col-span-full h-full mb-8">
                          <div className="text-sm font-medium text-gray-900 mb-2">
                            Description
                          </div>
                          <Editor
                            onChange={e => {
                              const updatedDescriptions =
                                pricingDescriptions.map(desc =>
                                  desc.id === i
                                    ? { ...desc, value: e.html }
                                    : desc
                                );
                              setPricingDescriptions(updatedDescriptions);
                            }}
                            value={f.description}
                            className="h-24"
                            errors={
                              actionData?.errors[`packages.${i}.description`] ??
                              []
                            }
                            toolBarOptions={{
                              toolbar: [
                                ["bold", "italic", "underline"],
                                ["clean"],
                              ],
                            }}
                          />
                          <input
                            type="hidden"
                            name="packages.description"
                            value={
                              !isNil(pricingDescriptions[i])
                                ? pricingDescriptions[i].value
                                : f.description
                            }
                          />
                        </div>
                        <label className="col-span-full block text-sm font-medium leading-6 text-gray-900">
                          Features
                        </label>
                        {[0, 1, 2, 3, 4, 5, 6, 7].map(j => (
                          <input
                            key={`${f.id}-feature-${j}`}
                            type="text"
                            name="packages.features"
                            className={tvField()}
                            defaultValue={f.features[j]}
                          />
                        ))}
                        <CrudSelectField
                          field={{
                            label: `Please select the price type *`,
                            name: `packages.${f.id}.price_type`,
                            type: "select",
                            errors:
                              actionData?.errors[`packages.${i}.price_type`] ??
                              [],
                            options: [
                              { label: "Monthly", value: "monthly" },
                              { label: "Unit", value: "unit" },
                              { label: "Package", value: "package" },
                            ],
                            defaultValue: f.price_type ?? undefined,
                          }}
                        />
                        <CurrencyField
                          name={`packages.${f.id}.price`}
                          label="Price"
                          defaultValue={f.price ?? 0}
                          errors={
                            actionData?.errors[`packages.${f.id}.price`] ?? []
                          }
                          className="col-span-1"
                        />
                        {/* <CrudTextField
                          field={{
                            name: "packages.button_text",
                            label: "CTA Button Text",
                            type: "text",
                            defaultValue: f.button_text ?? undefined,
                            errors:
                              actionData?.errors[`packages.${i}.button_text`] ??
                              [],
                          }}
                          className="col-span-1"
                        />
                        <CrudTextField
                          field={{
                            name: "packages.button_url",
                            label: "CTA Button URL",
                            type: "text",
                            defaultValue: f.button_url ?? undefined,
                            errors:
                              actionData?.errors[`packages.${i}.button_url`] ??
                              [],
                          }}
                          className="col-span-1"
                        /> */}
                      </div>
                    ))}
                    <button
                      className={`flex items-center col-span-3 ${
                        packages.length >= 6 ? "text-gray-300" : ""
                      }`}
                      type="button"
                      onClick={() => {
                        setPackages([
                          ...packages,
                          {
                            id: `new-${packages.length + 1}`,
                            order: packages.length + 1,
                            name: "",
                            description: "",
                            features: [],
                            price_type: null,
                            price: null,
                            button_text: "",
                            button_url: "",
                          },
                        ]);
                        const newPackage = {
                          id: pricingDescriptions.length,
                          value: "",
                        };
                        setPricingDescriptions(prevDescriptions => [
                          ...prevDescriptions,
                          newPackage,
                        ]);
                      }}
                      disabled={packages.length >= 6}
                    >
                      <PlusCircleIcon className="h-8 mr-2" />
                      Add Pricing Package
                    </button>
                  </>
                </FormSection>
              )}
              {tier !== Tier.free && tier !== Tier.tier_1 && (
                <FormSection title="Media">
                  {tierHasPermission(tier, "show_product_images") && (
                    <CrudFileUpload
                      field={{
                        name: "image_files",
                        label: "Product Images & Screenshots",
                        buttonLabel: "",
                        type: "image-upload",
                        defaultValue: product?.image_files
                          ? product.image_files
                          : [],
                        errors: actionData?.errors.image_files ?? [],
                        multiple: true,
                        maxFileSize: IMG_BYTE_LIMIT,
                      }}
                    />
                  )}
                  {tierHasPermission(tier, "show_brand_videos") && (
                    <>
                      <div className="col-span-full">
                        <CrudFileUpload
                          field={{
                            name: "brand_video_files",
                            label: "Brand Videos - File Uploads",
                            buttonLabel: "",
                            type: "file-upload",
                            defaultValue: product.brand_video_files,
                            errors: actionData?.errors.brand_video_files ?? [],
                            multiple: true,
                            maxFileSize: VID_BYTE_LIMIT,
                            accept: "video",
                            onChange: handleNewBrandVideos(),
                            handleCallback: updateVideoTitle,
                            limit: VIDEOS_LIMIT,
                            currentCount:
                              videoTitles.length + youtubeVideos.length,
                            showMaxError: !!actionData?.errors.brand_video_max,
                          }}
                          videoTitles={videoTitles}
                        />
                      </div>
                      {videoTitles.some(video => video.id.includes("new")) && (
                        <div className="col-span-full gap-4 grid grid-cols-1 lg:grid-cols-4">
                          {videoTitles.map(
                            (video, index) =>
                              video.id.includes("new") && (
                                <div key={video.id}>
                                  <input
                                    type="hidden"
                                    name="brand_video_titles.id"
                                    value={video.id}
                                  />
                                  <CrudTextField
                                    field={{
                                      name: "brand_video_titles.title",
                                      label: `Title for new video ${index + 1}`,
                                      type: "text",
                                      placeholder: `Title for the video`,
                                      defaultValue:
                                        videoTitles[index]?.title ?? "",
                                      onChange: handleVideoTitleChange(index),
                                      errors:
                                        actionData?.errors.brand_video_titles ??
                                        [],
                                      maxCharacters: 30,
                                    }}
                                  />
                                </div>
                              )
                          )}
                        </div>
                      )}
                    </>
                  )}
                  {tierHasPermission(tier, "show_brand_videos") && (
                    <>
                      <div className="col-span-full">
                        <CrudVideoUrlsField
                          field={{
                            name: "brand_video_urls",
                            label: "Brand Videos - YouTube URLs",
                            buttonLabel: "Add YouTube URL",
                            defaultValue: youtubeVideos,
                            errors: actionData?.errors.brand_video_urls ?? [],
                            onChange: handleVideoUrlsChange as any,
                            limit: VIDEOS_LIMIT,
                            currentCount:
                              videoTitles.length + youtubeVideos.length,
                            showMaxError: !!actionData?.errors.brand_video_max,
                          }}
                        />
                      </div>
                    </>
                  )}

                  {tierHasPermission(tier, "show_downloads") && (
                    <CrudFileUpload
                      field={{
                        name: "download_files",
                        label: "Content Downloads",
                        buttonLabel: "",
                        type: "file-upload",
                        defaultValue: product.download_files,
                        errors: actionData?.errors.download_files ?? [],
                        multiple: true,
                        maxFileSize: IMG_BYTE_LIMIT,
                      }}
                    />
                  )}

                  {tierHasPermission(tier, "show_demos") && (
                    <>
                      <CrudFileUpload
                        field={{
                          name: "demo_files",
                          label: "Product Demo Videos",
                          buttonLabel: "",
                          type: "file-upload",
                          defaultValue: product.demo_files,
                          errors: actionData?.errors.demo_files ?? [],
                          multiple: true,
                          maxFileSize: VID_BYTE_LIMIT,
                          accept: "video",
                        }}
                      />
                      <CrudTextField
                        field={{
                          name: "demo_storylane_url",
                          label: "Storylane Demo URL",
                          type: "text",
                          placeholder: "https://app.storylane.com/share/...",
                          defaultValue:
                            actionData?.fields.demo_storylane_url ??
                            product?.demo_storylane_url ??
                            undefined,
                          errors: actionData?.errors.demo_storylane_url ?? [],
                        }}
                      />
                    </>
                  )}
                </FormSection>
              )}

              {tierHasPermission(tier, "show_custom_review_questions") && (
                <FormSection title="Custom Questions for Reviews">
                  {[0, 1, 2].map(i => (
                    <CrudTextField
                      key={i}
                      field={{
                        name: "review_questions",
                        label: `Custom Question ${i + 1}`,
                        type: "text",
                        defaultValue: actionData
                          ? actionData.fields.review_questions[i]
                          : product.review_questions[i] ?? undefined,
                        errors: [],
                      }}
                      className="w-full"
                    />
                  ))}
                </FormSection>
              )}
            </>
          )}
          <div className="flex items-center justify-end gap-x-6 px-4 py-4 sm:px-8 sticky bottom-0 bg-gray-50/25 backdrop-blur">
            <Button
              className="flex"
              type="submit"
              disabled={navigation.state === "submitting"}
              id="save-button"
            >
              <>
                {navigation.state === "submitting"
                  ? "Submitting..."
                  : product.id === "new"
                  ? "Go to Checkout"
                  : "Save"}
              </>
            </Button>
          </div>
        </FormWithUploads>
      </>
    </PortalPage>
  );
}
