import { Card } from "~/components/card.component";

import { Link, useLoaderData, useNavigate } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { IconCircle } from "~/components/circle-icon.component";
import {
  BriefcaseIcon,
  BuildingStorefrontIcon,
  DocumentTextIcon,
  ShoppingBagIcon,
} from "@heroicons/react/24/outline";
import { money } from "~/utils/number.utils";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import {
  ArrowLeftIcon,
  ChevronDownIcon,
  ChevronUpIcon,
} from "@heroicons/react/20/solid";
import { Table } from "~/components/intelligence/table.component";
import { Tooltip } from "~/components/tooltip.component";
import { useState } from "react";
import { isEmpty } from "lodash";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewSpendByDepartment],
    }
  );

  const { managerAccountService } = await WebDIContainer();

  const name = params.department === "Uncategorized" ? "" : params.department!;

  const departmentLineItems =
    await managerAccountService.getDepartmentContractLineItems(
      name,
      user,
      account
    );

  const annualValuePromises = departmentLineItems.map(
    async contractLineItem => ({
      ...contractLineItem,
      annual_assigned_value:
        await managerAccountService.getContractLineItemAnnualAssignedValue(
          contractLineItem.id
        ),
    })
  );

  const departmentLineItemsWithAnnualValue = await Promise.all(
    annualValuePromises
  );

  const counts = await managerAccountService.getCountsByDepartment(
    user,
    account
  );
  const spend = (
    await managerAccountService.getSpend(user, account, {
      byDepartment: true,
    })
  ).byDepartment[name];

  return json({
    account,
    user,
    name,
    departmentLineItems: departmentLineItemsWithAnnualValue,
    spendByDepartment: spend ?? 0,
    contractLineItemsByDepartment: counts.contractLineItems[name] ?? 0,
    contractsByDepartment: counts.contracts[name] ?? 0,
    vendorsByDepartment: counts.vendors[name] ?? 0,
  });
}

export default function DepartmentSummary() {
  const {
    account,
    user,
    name,
    departmentLineItems,
    contractsByDepartment,
    spendByDepartment,
    contractLineItemsByDepartment,
    vendorsByDepartment,
  } = useLoaderData<typeof loader>();
  const userCanViewContractLineItem = canDoOnAccount(
    user,
    account,
    Permission.ViewContractLineItem
  );
  const navigate = useNavigate();

  const [showAllLineItems, setShowAllLineItems] = useState(false);

  const visibleLineItems = showAllLineItems
    ? departmentLineItems
    : departmentLineItems.slice(0, 5);

  return (
    <>
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "Reports",
            to: `/intelligence/${account.id}`,
            active: false,
          },
          {
            name: "Contract Insights by Department",
            to: `/intelligence/${account.id}/spend-by-department`,
            active: false,
          },
          {
            name: `${name}`,
            to: `/intelligence/${account.id}/spend-by-department/${name}`,
            active: true,
          },
        ]}
        title={
          <>
            Contract Insights:
            <br /> {!isEmpty(name) ? name : "Uncategorized"}
          </>
        }
        description={
          <div className="w-10/12">
            Get a clear breakdown of the line items managed by {name}, and
            visualize how contracts and spend are distributed across your
            organization.
          </div>
        }
        buttonsSlot={
          <div className="w-max">
            <Link
              to={`/intelligence/${account.id}/spend-by-department`}
              className="w-full text-sky-600 flex items-center"
            >
              <ArrowLeftIcon className="h-5 mr-2" /> Back to all departments
            </Link>
          </div>
        }
      />
      <div className="space-y-8 pb-10">
        <Card className="mt-10">
          <div className="flex align-middle p-10 flex-wrap items-center justify-between gap-2">
            <div className="flex gap-2 items-center">
              <IconCircle Icon={DocumentTextIcon} color="yellow" size="8" />
              <div>
                <div>Contracts</div>
                <div className="font-semibold">{contractsByDepartment}</div>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <IconCircle
                Icon={BuildingStorefrontIcon}
                color="yellow"
                size="8"
              />
              <div>
                <div>Vendors</div>
                <div className="font-semibold">{vendorsByDepartment}</div>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <IconCircle Icon={ShoppingBagIcon} color="yellow" size="8" />
              <div>
                <div>Line Items</div>
                <div className="font-semibold">
                  {contractLineItemsByDepartment}
                </div>
              </div>
            </div>
            <div className="flex gap-2 items-center">
              <IconCircle Icon={BriefcaseIcon} color="yellow" size="8" />
              <div>
                <div className="text-gray-500">Spend</div>
                <div className="font-semibold">{money(spendByDepartment)}</div>
              </div>
            </div>
          </div>
        </Card>
        <Table
          variant="white"
          cols={[
            { name: "contract.name", label: "Contract Name" },
            {
              renderer: lineItem => {
                return (
                  <Link
                    onClick={e => e.stopPropagation()}
                    to={`/intelligence/${account.id}/vendors/${lineItem.contract.manager_account_vendor.id}`}
                    className="text-sky-600"
                  >
                    {lineItem.contract.manager_account_vendor.vendor.name}
                  </Link>
                );
              },
              name: "vendor_name",
              label: "Vendor",
            },
            { name: "name", label: "Line Item Name" },
            {
              renderer: lineItem => {
                return (
                  <div className="flex items-center space-x-2 font-normal">
                    {lineItem.annual_assigned_value.toLocaleString(undefined, {
                      style: "currency",
                      currency: "USD",
                    })}
                  </div>
                );
              },
              name: "annual_assigned_value",
              label: (
                <Tooltip
                  position="left"
                  text="The estimated annual value of this line item as configured today."
                >
                  Est. Annual Value
                </Tooltip>
              ),
            },
          ]}
          showAddButton={false}
          data={visibleLineItems}
          showSelectBox={false}
          onClickRow={lineItem =>
            userCanViewContractLineItem &&
            navigate(
              `/intelligence/${account.id}/contract/${lineItem.contract_id}/line-item/${lineItem.id}/summary`
            )
          }
        ></Table>
        {departmentLineItems && departmentLineItems?.length > 5 && (
          <div className="flex justify-center items-center">
            {showAllLineItems ? (
              <button
                className="font-medium text-sky-500 flex items-center"
                onClick={() => {
                  setShowAllLineItems(false);
                }}
              >
                Show Less
                <ChevronUpIcon className="h-5" />
              </button>
            ) : (
              <button
                className="text-sky-500 flex items-center"
                onClick={() => setShowAllLineItems(true)}
              >
                Show all {departmentLineItems?.length} line items
                <ChevronDownIcon className="h-5" />
              </button>
            )}
          </div>
        )}
      </div>
    </>
  );
}
