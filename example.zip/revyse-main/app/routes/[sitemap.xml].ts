import dayjs from "dayjs";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { getEnv } from "~/services/env.service.server";

type ChangeFrequency =
  | "always"
  | "hourly"
  | "daily"
  | "weekly"
  | "monthly"
  | "yearly"
  | "never";

export const toXmlSitemap = (
  pages: {
    url: string;
    lastmod: Date;
    changefreq: ChangeFrequency;
    priority: number;
  }[]
) => {
  const urlsAsXml = pages
    .map(
      page => `
    <url>
      <loc>${page.url}</loc>
      <lastmod>${dayjs(page.lastmod).format("YYYY-MM-DD")}</lastmod>
      <changefreq>${page.changefreq}</changefreq>
      <priority>${page.priority}</priority>
    </url>
  `
    )
    .join("\n");

  return `<?xml version="1.0" encoding="UTF-8"?>
    <urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" 
            xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
            xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">
      ${urlsAsXml}
    </urlset>`;
};

export async function loader() {
  try {
    const origin = getEnv().REVYSE_UI_ORIGIN;
    const { db, circleService } = await WebDIContainer();
    const categories = await db.productCategory.findMany({
      orderBy: { updated_at: "desc" },
      include: {
        primary_products: {
          where: { approved_at: { not: null } },
          orderBy: { updated_at: "desc" },
          take: 1,
        },
      },
    });
    const articles = await circleService.getPosts();
    const products = await db.product.findMany({
      where: { approved_at: { not: null } },
      include: {
        reviews: {
          where: { approved_at: { not: null } },
          orderBy: { updated_at: "desc" },
          take: 1,
        },
      },
    });
    const mostReceptCategory = categories[0];
    const sitemap = toXmlSitemap([
      {
        url: `${origin}/`,
        lastmod: new Date(),
        changefreq: "daily",
        priority: 1,
      },
      {
        url: `${origin}/categories`,
        lastmod: mostReceptCategory.created_at,
        changefreq: "monthly",
        priority: 0.7,
      },
      {
        url: `${origin}/disclaimer`,
        lastmod: new Date(2023, 5, 28),
        changefreq: "yearly",
        priority: 0.1,
      },
      {
        url: `${origin}/forgot-password`,
        lastmod: new Date(2023, 5, 28),
        changefreq: "yearly",
        priority: 0.1,
      },
      {
        url: `${origin}/login`,
        lastmod: new Date(2023, 5, 28),
        changefreq: "yearly",
        priority: 0.1,
      },
      {
        url: `${origin}/privacy-policy`,
        lastmod: new Date(2023, 5, 28),
        changefreq: "yearly",
        priority: 0.1,
      },
      {
        url: `${origin}/search`,
        lastmod: new Date(2023, 5, 28),
        changefreq: "monthly",
        priority: 0.7,
      },
      {
        url: `${origin}/sign-up`,
        lastmod: new Date(2023, 5, 28),
        changefreq: "yearly",
        priority: 0.1,
      },
      {
        url: `${origin}/terms-of-use`,
        lastmod: new Date(2023, 5, 28),
        changefreq: "yearly",
        priority: 0.1,
      },
      {
        url: `${origin}/who-we-are`,
        lastmod: new Date(2023, 5, 28),
        changefreq: "yearly",
        priority: 0.1,
      },
      {
        url: `${origin}/for-vendors`,
        lastmod: new Date(2023, 5, 28),
        changefreq: "yearly",
        priority: 0.7,
      },
      {
        url: `${origin}/articles`,
        lastmod: articles[0].updated_at,
        changefreq: "yearly",
        priority: 0.7,
      },
      ...articles.map(article => ({
        url: `${origin}/articles/${article.slug}`,
        lastmod: article.updated_at
          ? article.updated_at
          : new Date(2023, 7, 27),
        changefreq: "daily" as ChangeFrequency,
        priority: 1,
      })),
      ...categories.map(category => ({
        url: `${origin}/categories/${category.slug}`,
        lastmod:
          category.primary_products.length > 0
            ? category.updated_at.getDate() >
              category.primary_products[0].updated_at.getDate()
              ? category.updated_at
              : category.primary_products[0].updated_at
            : category.updated_at,
        changefreq: "daily" as ChangeFrequency,
        priority: 1,
      })),
      ...products.map(product => ({
        url: `${origin}/products/${product.slug}`,
        lastmod:
          product.reviews.length > 0
            ? product.updated_at.getDate() >
              product.reviews[0].updated_at.getDate()
              ? product.updated_at
              : product.reviews[0].updated_at
            : product.updated_at,
        changefreq: "daily" as ChangeFrequency,
        priority: 1,
      })),
      ...products.map(product => ({
        url: `${origin}/products/${product.slug}/reviews`,
        lastmod:
          product.reviews.length > 0
            ? product.reviews[0].updated_at
            : new Date(2023, 5, 28),
        changefreq: "daily" as ChangeFrequency,
        priority: 1,
      })),
    ]);
    return new Response(sitemap, {
      status: 200,
      headers: {
        "Content-Type": "application/xml",
        "X-Content-Type-Options": "nosniff",
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch (e) {
    console.error(e);
  }
  return null;
}
