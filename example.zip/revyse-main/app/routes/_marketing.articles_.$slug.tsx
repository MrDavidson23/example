import { useEffect, useState } from "react";
import type {
  LinksFunction,
  LoaderFunctionArgs,
  MetaFunction,
} from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import HTMLReactParser from "html-react-parser";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { json } from "@remix-run/node";
import article from "../styles/article.css";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import { CalendarIcon } from "@heroicons/react/24/outline";
dayjs.extend(relativeTime);

export const links: LinksFunction = () => {
  return [
    {
      rel: "stylesheet",
      href: article,
    },
  ];
};

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  const post = data!.post;
  return [
    { title: post.meta_title },
    {
      name: "description",
      content: post.meta_description,
    },
    {
      name: "og:image",
      content: post.cover_image_url,
    },
  ];
};

export async function loader({ params }: LoaderFunctionArgs) {
  const { circleService } = await WebDIContainer();
  const slug = params.slug || "";

  const post = await circleService.getPost(slug);
  return json({
    post,
    slug: params.slug as string,
  });
}

export default function ArticleSlugRoute() {
  const { post } = useLoaderData<typeof loader>();
  const [modifiedHTMLString, setModifiedHTMLString] = useState(post.body || "");

  useEffect(() => {
    // Process to display links with class "file" as videos
    const parser = new DOMParser();
    const doc = parser.parseFromString(modifiedHTMLString, "text/html");
    const fileLinks = doc.querySelectorAll("a.file");

    fileLinks.forEach(link => {
      if (link instanceof HTMLAnchorElement) {
        const videoElement = document.createElement("video");
        videoElement.src = link.href;
        videoElement.controls = true;

        link.parentNode?.replaceChild(videoElement, link);
      }
    });

    setModifiedHTMLString(doc.body.innerHTML);
  }, [modifiedHTMLString]);

  return (
    <>
      <section
        className="flex flex-col items-center my-10 mx-4 lg:mx-0"
        id="blog-section"
      >
        <div className="md:max-w-4xl flex-grow md:px-6 overflow-clip space-y-6">
          <img
            role="presentation"
            className="h-auto lg:h-72 object-cover rounded-xl float-left mb-6 w-auto"
            src={
              post.cover_image_url ||
              "/assets/article-software-survival-kit.png"
            }
            alt="article cover"
            width="840"
            height="300"
          />
          <h1 className="text-3xl lg:text-5xl font-bold" id="article-name">
            {post.name}
          </h1>
          <div className="flex flex-row space-x-3 items-center">
            <img
              className="object-cover w-9 h-9 rounded-full"
              src={post.user_avatar_url || "/assets/defaultAvatar.png"}
              alt="Avatar"
              height="36"
              width="36"
            />
            <div>
              <p className="font-regular text-gray-800">By {post.user_name}</p>
              <div className="flex flex-row space-x-3 text-sm lg:text-md font-light text-gray-500">
                <p className="flex flex-row items-center">
                  <CalendarIcon className="h-5 mr-1" />
                  Published {dayjs(post.published_at).fromNow()}
                </p>
                <p className="flex flex-row items-center">
                  <CalendarIcon className="h-5 mr-1" />
                  Updated {dayjs(post.updated_at).fromNow()}
                </p>
              </div>
            </div>
          </div>
          <div
            className="whitespace-normal font-light font-lg leading-relaxed text-md"
            id="article-body"
          >
            {HTMLReactParser(modifiedHTMLString || "...")}
          </div>
        </div>
      </section>
      {/* {post.is_comments_enabled ? (
        <div className='mt-12 lg:mt-20 max-w-4xl mx-auto px-6 items-start justify-start flex flex-col'>
          <div className='flex flex-row items-center space-x-3'>
            <div className='bg-coral h-6 lg:h-8 w-1 lg:w-2'></div>
            <div className='font-bold lg:text-3xl text-xl text-left'>Comments</div>
          </div>
          <div className='w-full flex justify-center items-center flex-col'>
            <iframe
              id='iframe'
              className='w-full h-72 my-8'
              style={{
                border: "0",
                boxShadow: "none",
                outline: "0",
              }}
              src={`https://revyse.circle.so/c/${post.space_slug}/${post.slug}?iframe=true&?post=true`}
            ></iframe>
          </div>
        </div>
      ) : null} */}
    </>
  );
}
