import type { ActionFunctionArgs } from "@remix-run/node";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { ContractLineItemLocationStatus } from "@prisma/client";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { Permission } from "~/utils/intelligence-permission.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const UpdateContractLineItemLocationForm = z.object({
  status: z.nativeEnum(ContractLineItemLocationStatus),
  date: z.optional(
    z
      .string()
      .transform(value => {
        if (value) {
          return dayjs.utc(value).toISOString();
        }
        return undefined;
      })
      .refine(value => {
        if (value) {
          return dayjs.utc(value).isValid();
        }
        return true;
      })
  ),
});

export async function action({ params, request }: ActionFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContractLineItemLocations],
    }
  );
  const contractLineItemId = params.contract_line_item_id as string;
  const locationId = params.location_id as string;
  const { contractLineItemLocationService } = await WebDIContainer();

  const form = await request.formData();

  const fields = {
    id: contractLineItemId,
    status: form.get("status") as string,
    date: form.get("date") as string,
  };

  const validation = UpdateContractLineItemLocationForm.safeParse(fields);

  if (!validation.success) {
    return jsonWithError(
      { success: false, fields, errors: issuesByKey(validation.error.issues) },
      DEFAULT_FORM_ERROR_MESSAGE
    );
  }

  const newExpirationDate =
    validation.data.status === ContractLineItemLocationStatus.Active
      ? validation.data.date
      : undefined;
  const newCanceledDate =
    validation.data.status === ContractLineItemLocationStatus.Canceled
      ? validation.data.date
      : null;

  await contractLineItemLocationService.updateContractLineItemLocationStatus({
    contractLineItemId,
    locationId,
    status: validation.data.status,
    newExpirationDate,
    newCanceledDate,
  });

  return jsonWithSuccess(
    { success: true, fields, errors: issuesByKey([]) },
    "Status updated successfully"
  );
}
