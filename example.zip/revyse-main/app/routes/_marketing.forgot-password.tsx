import type { ActionFunctionArgs, MetaFunction } from "@remix-run/node";
import { Form, Link, json, useActionData } from "@remix-run/react";
import { LockClosedIcon } from "@heroicons/react/20/solid";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import { Toast } from "~/components/toast.component";
import { tvField } from "~/utils/global-tailwind-variants.utils";

type JsonData = {
  success?: boolean;
  errors: Record<string, string[] | null>;
};

export const meta: MetaFunction = () => [
  { title: "Revyse | Forgot Password" },
  {
    name: "description",
    content: "Forgot your password? No worries!",
  },
];

const ForgotPasswordForm = z.object({
  email: z.string().email(),
});

export const action = async ({ request }: ActionFunctionArgs) => {
  const form = await request.formData();

  const email = form.get("email");

  const fields = { email };
  const validation = ForgotPasswordForm.safeParse(fields);

  if (validation.success) {
    const { authService } = await WebDIContainer();
    await authService.generateForgotPasswordEmail(validation.data.email);
    return json<JsonData>({
      success: true,
      errors: issuesByKey([]),
    });
  }
  return json<JsonData>({
    success: false,
    errors: issuesByKey([]),
  });
};

export default function ForgotPasswordRoute() {
  const actionData = useActionData<typeof action>();
  return (
    <>
      <div className="flex min-h-full items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-md space-y-8">
          <div>
            <img
              className="mx-auto h-12 w-auto"
              src="/assets/revyse-logo-color-black.png"
              alt=""
              width="320"
              height="112"
            />
            <h1 className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900">
              Reset your password
            </h1>
            <p className="mt-2 text-center text-sm text-gray-600">
              Or{" "}
              <Link
                to="../login"
                className="font-medium text-sky-600 hover:text-sky-500"
                id="login-link"
              >
                Login
              </Link>
            </p>
          </div>
          <Form className="mt-8 space-y-6" method="post">
            <div className="-space-y-px rounded-md shadow-sm">
              <div>
                <label htmlFor="email-address" className="sr-only">
                  Email address
                </label>
                <input
                  id="email-address"
                  name="email"
                  type="email"
                  autoComplete="email"
                  required
                  className={tvField({ className: "relative" })}
                  placeholder="Email address"
                />
              </div>
            </div>
            <div>
              {actionData?.success !== undefined && (
                <Toast
                  variant={actionData?.success ? "success" : "error"}
                  message={
                    actionData?.success
                      ? "If there is an account associated with the email address entered, you should receive a password reset email in your inbox shortly."
                      : "There was an error requesting a password reset. Please try again."
                  }
                />
              )}
              <button
                type="submit"
                className="group relative flex w-full justify-center rounded-md bg-sky-600 py-2 px-3 text-sm font-semibold text-white hover:bg-sky-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sky-600"
                id="forgot-password-submit-button"
              >
                <span className="absolute inset-y-0 left-0 flex items-center pl-3">
                  <LockClosedIcon
                    className="h-5 w-5 text-sky-500 group-hover:text-sky-400"
                    aria-hidden="true"
                  />
                </span>
                Send Password Reset Email
              </button>
            </div>
          </Form>
        </div>
      </div>
    </>
  );
}
