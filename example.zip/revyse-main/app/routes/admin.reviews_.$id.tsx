import {
  CheckBadgeIcon,
  CheckIcon,
  NoSymbolIcon,
  TrashIcon,
  XMarkIcon,
} from "@heroicons/react/20/solid";
import { Role } from "@prisma/client";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Form, useLoaderData } from "@remix-run/react";
import { isNil } from "lodash";
import { useState } from "react";
import {
  jsonWithError,
  jsonWithSuccess,
  redirectWithSuccess,
} from "remix-toast";
import { z } from "zod";
import { Button, DangerButton } from "~/components/button.component";
import { PortalPage } from "~/components/portal-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assert, assertAuthorized } from "~/utils/assert.utils.server";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import { getUser } from "~/utils/session.server";
import { Boolean } from "~/utils/validation.utils.server";

const ReviewForm = z.object({
  approved: Boolean,
});

const ReviewBadgesForm = z.object({
  incentivized: Boolean,
  vendor_invited: Boolean,
});

async function setBadges({ id, form }: { id: string; form: FormData }) {
  const fields = {
    incentivized: form.get("incentivized"),
    vendor_invited: form.get("vendor_invited"),
  };
  const validation = ReviewBadgesForm.safeParse(fields);

  if (validation.success) {
    const { reviewService } = await WebDIContainer();

    await reviewService.updateReview({
      id,
      data: {
        incentivized: validation.data.incentivized,
        vendor_invited: validation.data.vendor_invited,
      },
    });

    return jsonWithSuccess(
      { fields, errors: issuesByKey([]) },
      "Badge updated successfully"
    );
  }
  return jsonWithError(
    { fields, success: false, errors: issuesByKey(validation.error.issues) },
    "Badge update failed",
    { status: 400 }
  );
}

export const action = async ({
  params: { id },
  request,
}: ActionFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));
  const form = await request.formData();
  assert(!!id, "Review ID is required");

  const intent = form.get("intent");
  if (intent === "mark_incentivized" || intent === "mark_invited") {
    return setBadges({ id, form });
  }
  if (intent === "delete") {
    const { reviewService } = await WebDIContainer();
    await reviewService.deleteReview({ id });
    return redirectWithSuccess("/admin/reviews", "Review deleted successfully");
  }
  const fields = {
    approved: form.get("approved"),
  };
  const validation = ReviewForm.safeParse(fields);

  if (validation.success) {
    const { reviewService } = await WebDIContainer();

    await reviewService.updateReviewApproval({
      id,
      approved: validation.data.approved,
      userId: user.id,
    });

    return jsonWithSuccess(
      { fields, errors: issuesByKey([]) },
      "Review updated successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return jsonWithError({ fields, errors }, DEFAULT_FORM_ERROR_MESSAGE, {
    status: 400,
  });
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { reviewService } = await WebDIContainer();

  const review = await reviewService.getReviewById({ id: params.id! });

  if (isNil(review)) {
    throw json("undefined", { status: 404 });
  }
  return json({ review });
}

export default function AdminUserIdRoute() {
  const { review } = useLoaderData<typeof loader>();
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  return (
    <>
      <PortalPage
        crumbs={[
          { name: "Reviews", to: "/admin/reviews", active: false },
          {
            name: `${review.product.title} : ${review.user.first_name} ${review.user.last_name}`,
            to: `/admin/reviews/${review.id}`,
            active: true,
          },
        ]}
        buttonsSlot={
          <div className="flex justify-between gap-2">
            {confirmDeleteOpen ? (
              <Form
                className="flex justify-between  items-center"
                method="post"
              >
                Are you sure you want to delete this review?
                <input type="hidden" name="intent" value="delete" />
                <Button
                  onClick={() => setConfirmDeleteOpen(false)}
                  className="ml-2"
                >
                  Cancel
                </Button>
                <DangerButton type="submit" className="ml-2">
                  Yep!
                </DangerButton>
              </Form>
            ) : (
              <DangerButton
                onClick={() => {
                  setConfirmDeleteOpen(!confirmDeleteOpen);
                }}
              >
                <div className="flex">
                  <TrashIcon className="h-5 mr-1" />
                  Delete
                </div>
              </DangerButton>
            )}
          </div>
        }
      >
        <div className="grid grid-cols-4 gap-4">
          <strong>Title</strong>
          <div className="col-span-3">{review.title}</div>
          <strong>Status</strong>
          <div className="col-span-3">
            {review.approved_by ? "Approved" : "Awaiting Approval"}
          </div>

          <strong className="col-span-4 pt-6">Reviewer</strong>

          <strong>Name</strong>
          <div className="col-span-3">
            {review.user.first_name} {review.user.last_name}
          </div>
          <strong>Email</strong>
          <div className="col-span-3">{review.user.email}</div>
          <strong>Company</strong>
          <div className="col-span-3">{review.user.company_name}</div>
          <strong>Verified Buyer</strong>
          <div className="col-span-3">
            {review.user.user_roles.find(ur => ur.role === Role.BUYER) ? (
              <CheckBadgeIcon className="h-6 text-green-600" />
            ) : (
              <NoSymbolIcon className="h-6 text-red-600" />
            )}
          </div>

          <div className="col-span-4 p-2"></div>
          <strong>Approved By</strong>
          <div className="col-span-3">
            {review.approved_by
              ? `${review.approved_by.first_name} ${review.approved_by.last_name}`
              : "---"}
          </div>
          <strong>Responded By</strong>
          <div className="col-span-3">
            {review.responded_by
              ? `${review.responded_by.first_name} ${review.responded_by.last_name}`
              : "---"}
          </div>
          <strong>Response</strong>
          <div className="col-span-3">{review.response ?? "---"}</div>

          <strong>decision_maker</strong>
          <div className="col-span-3">{review.decision_maker}</div>
          <strong>who_uses</strong>
          <div className="col-span-3">{review.who_uses}</div>
          <strong>primary_use_case</strong>
          <div className="col-span-3">{review.primary_use_case}</div>
          <strong>like_most</strong>
          <div className="col-span-3">{review.like_most}</div>
          <strong>dislike_most</strong>
          <div className="col-span-3">{review.dislike_most}</div>
          <strong>recommend_to</strong>
          <div className="col-span-3">{review.recommend_to}</div>
          <strong>custom_question_1</strong>
          <div className="col-span-3">{review.custom_question_1}</div>
          <strong>custom_question_2</strong>
          <div className="col-span-3">{review.custom_question_2}</div>
          <strong>custom_question_3</strong>
          <div className="col-span-3">{review.custom_question_3}</div>
          <strong>customer_service_score</strong>
          <div className="col-span-3">{review.customer_service_score}</div>
          <strong>customer_service_desc</strong>
          <div className="col-span-3">{review.customer_service_desc}</div>
          <strong>value_score</strong>
          <div className="col-span-3">{review.value_score}</div>
          <strong>value_desc</strong>
          <div className="col-span-3">{review.value_desc}</div>
          <strong>onboarding_score</strong>
          <div className="col-span-3">{review.onboarding_score}</div>
          <strong>onboarding_desc</strong>
          <div className="col-span-3">{review.onboarding_desc}</div>
          <strong>compatibility_score</strong>
          <div className="col-span-3">{review.compatibility_score}</div>
          <strong>compatibility_desc</strong>
          <div className="col-span-3">{review.compatibility_desc}</div>
          <strong>show_last_name</strong>
          <div className="col-span-3">
            {review.show_last_name ? "true" : "false"}
          </div>
          <strong>show_job_title</strong>
          <div className="col-span-3">
            {review.show_job_title ? "true" : "false"}
          </div>
          <strong>show_company</strong>
          <div className="col-span-3">
            {review.show_company ? "true" : "false"}
          </div>
        </div>
      </PortalPage>
      <div className="flex items-center justify-end gap-x-6 px-4 py-4 sm:px-8 sticky bottom-0 bg-gray-50/25 backdrop-blur">
        {review.id !== "new" && (
          <>
            <Form className="flex justify-between  items-center" method="post">
              <input type="hidden" name="intent" value="approve" />
              <input
                type="hidden"
                name="approved"
                value={review.approved_by ? "false" : "true"}
              />
              <Button type="submit" className="ml-2">
                {review.approved_by ? (
                  <>
                    <XMarkIcon className="h-6 mr-2" /> Revoke Approval
                  </>
                ) : (
                  <>
                    <CheckIcon className="h-6 mr-2" /> Approve Review
                  </>
                )}
              </Button>
            </Form>
            <Form className="flex justify-between  items-center" method="post">
              <input type="hidden" name="intent" value="mark_invited" />
              <input
                type="hidden"
                name="vendor_invited"
                value={review.vendor_invited ? "false" : "true"}
              />
              <input
                type="hidden"
                name="incentivized"
                value={review.incentivized ? "true" : "false"}
              />
              <Button type="submit" className="ml-2">
                {review.vendor_invited ? (
                  <>
                    <XMarkIcon className="h-6 mr-2" /> Remove vendor invite
                    badge
                  </>
                ) : (
                  <>
                    <CheckIcon className="h-6 mr-2" /> Set vendor invite badge
                  </>
                )}
              </Button>
            </Form>
            <Form className="flex justify-between  items-center" method="post">
              <input type="hidden" name="intent" value="mark_incentivized" />
              <input
                type="hidden"
                name="incentivized"
                value={review.incentivized ? "false" : "true"}
              />
              <input
                type="hidden"
                name="vendor_invited"
                value={review.vendor_invited ? "true" : "false"}
              />
              <Button type="submit" className="ml-2">
                {review.incentivized ? (
                  <>
                    <XMarkIcon className="h-6 mr-2" /> Remove incentivized badge
                  </>
                ) : (
                  <>
                    <CheckIcon className="h-6 mr-2" /> Set incentivized badge
                  </>
                )}
              </Button>
            </Form>
          </>
        )}
      </div>
    </>
  );
}
