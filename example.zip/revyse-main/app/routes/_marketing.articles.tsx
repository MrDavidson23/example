import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { ArticleCard } from "../components/article-card.component";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { BlogSearch } from "../components/blog-search.component";
import { LatestArticleCard } from "../components/latest-article-card.component";
import { json } from "@remix-run/node";
import { QuestionMarkCircleIcon } from "@heroicons/react/24/outline";

export const meta: MetaFunction<typeof loader> = () => {
  return [
    { title: "Multifamily Technology Buyer’s Guides | Revyse" },
    {
      name: "description",
      content:
        "Explore the ultimate guidebooks for buying multifamily technology. Get expert tips and advice with the latest news and resources from Revyse.",
    },
  ];
};

export async function loader({ request }: LoaderFunctionArgs) {
  const { circleService } = await WebDIContainer();
  const url = new URL(request.url);
  const query = url.searchParams.get("query") || undefined;

  const posts = query
    ? await circleService.getPostsByName(query)
    : await circleService.getPosts();
  return json({
    posts,
  });
}

export default function ArticleRoute() {
  const { posts } = useLoaderData<typeof loader>();

  return (
    <>
      <div className="bg-sky-500 flex justify-center py-12 lg:py-20">
        <div className="max-w-3xl text-white text-center">
          <h1 className="text-4xl lg:text-6xl font-bold mb-4">
            Revyse Resources
          </h1>
          <p className="my-6 text-lg text-white md:px-24">
            Get expert tips, leasing inspiration, and multifamily tech buying
            guidance with the latest news and resources from the Revyse
            Community.
          </p>
          <BlogSearch></BlogSearch>
        </div>
      </div>
      {posts.length > 0 ? (
        <section className="py-6 lg:py-12">
          <div className="container max-w-6xl p-6 mx-auto">
            <div className="grid justify-center grid-cols-1 gap-12 lg:gap-6 sm:grid-cols-2 lg:grid-cols-3">
              {posts.map((p: any) =>
                posts.indexOf(p) === 0 ? (
                  <LatestArticleCard key={p.id} post={p} />
                ) : (
                  <ArticleCard key={p.id} post={p} />
                )
              )}
            </div>
          </div>
        </section>
      ) : (
        <div
          className="p-16 m-12 flex flex-col items-center bg-gray-100 border border-dashed border-gray-400 rounded-xl"
          id="no-articles-fallback"
        >
          <QuestionMarkCircleIcon className="h-12 mb-6" />
          No articles found
        </div>
      )}
    </>
  );
}
