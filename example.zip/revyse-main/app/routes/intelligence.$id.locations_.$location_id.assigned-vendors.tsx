import { useCallback, useEffect, useState } from "react";
import { json } from "@remix-run/node";
import type { Prisma } from "@prisma/client";
import { ContractStatus } from "@prisma/client";
import { useLoaderData, useNavigate, useSearchParams } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { isEmpty } from "lodash";
import { ClipboardDocumentIcon } from "@heroicons/react/24/outline";
import { CTA } from "~/components/cta.component";
import { Pagination } from "~/components/intelligence/pagination.component";
import { Modal } from "~/components/modal.component";
import {
  CrudCheckboxField,
  CrudDateField,
} from "~/components/form/crud-form.component";
import { Toast } from "~/components/toast.component";
import { AutocompleteFilter } from "~/components/intelligence/autocomplete-filter.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { LocationContractLineItemsTable } from "~/components/intelligence/locations/contract-line-item-location-table.component";
import { LocationContractLineItemEditStatusModal } from "~/components/intelligence/locations/contract-line-item-location-edit-status-modal.component";
import { FilterBar } from "~/components/filter-bar.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { redirectWithError } from "remix-toast";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { canDoOnLocation } from "~/utils/location-permission.utils";
dayjs.extend(utc);

type Vendor = { id: string; name: string };
export type Order = { [key: string]: any };

export async function loader({ params, request }: LoaderFunctionArgs) {
  const {
    contractLineItemLocationService,
    locationService,
    managerAccountVendorService,
  } = await WebDIContainer();
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewLocationVendorsAndProducts],
      locationId: params.location_id,
    }
  );
  const managerAccountId = account.id;

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const vendorParam = search.getAll("vendor");
  const locationParam = search.getAll("locationQuantity");
  const statusParam = search.getAll("status") as ContractStatus[];
  const startDate = search.get("startDate");
  const endDate = search.get("endDate");

  const searchTerm = search.get("query");
  const page = parseInt(search.get("page") || "1");
  const perPage = parseInt(search.get("perPage") || "50");
  const orderByParam = search.getAll("orderBy");

  const orderBy: Order = {};

  orderByParam.forEach(value => {
    const [key, direction] = value.split(":");
    orderBy[key] = direction;
  });

  const offset = (page - 1) * perPage;

  let filters: Prisma.ContractLineItemLocationWhereInput = {
    location_id: params.location_id,
    OR: [
      {
        contract_line_item: {
          contract: {
            name: {
              contains: searchTerm ?? "",
              mode: "insensitive",
            },
          },
        },
      },
      {
        contract_line_item: {
          contract: {
            manager_account_vendor: {
              vendor: {
                name: {
                  contains: searchTerm ?? "",
                  mode: "insensitive",
                },
              },
            },
          },
        },
      },
      {
        contract_line_item: {
          name: {
            contains: searchTerm ?? "",
            mode: "insensitive",
          },
        },
      },
      {
        contract_line_item: {
          contract_line_item_products: {
            some: {
              product: {
                title: {
                  contains: searchTerm ?? "",
                  mode: "insensitive",
                },
              },
            },
          },
        },
      },
      {
        contract_line_item: {
          contract_line_item_fees: {
            some: {
              fee: {
                name: {
                  contains: searchTerm ?? "",
                  mode: "insensitive",
                },
              },
            },
          },
        },
      },
    ],
  };

  filters.contract_line_item =
    statusParam.length > 0 && vendorParam.length > 0
      ? {
          contract: {
            manager_account_vendor: {
              vendor_id: {
                in: vendorParam.flatMap(vendorValue => vendorValue.split(",")),
              },
            },
            status: {
              in: statusParam.flatMap(statusValue =>
                statusValue.split(",")
              ) as ContractStatus[],
            },
          },
        }
      : vendorParam.length > 0
      ? {
          contract: {
            manager_account_vendor: {
              vendor_id: {
                in: vendorParam.flatMap(vendorValue => vendorValue.split(",")),
              },
            },
          },
        }
      : statusParam.length > 0
      ? {
          contract: {
            status: {
              in: statusParam.flatMap(statusValue =>
                statusValue.split(",")
              ) as ContractStatus[],
            },
          },
        }
      : {
          contract: {},
        };

  if (startDate && endDate) {
    filters.expires_at = {
      gte: new Date(startDate),
      lte: new Date(endDate),
    };
  }

  if (!canDoOnAccount(user, account, Permission.ViewSensitiveContracts)) {
    filters.contract_line_item!.contract!.is_sensitive = false;
  }

  const locationContractLineItems =
    await contractLineItemLocationService.getLocationContractLineItems(
      params.location_id!,
      filters,
      offset,
      perPage,
      orderBy,
      user,
      account
    );

  const locationContractLineItemsCount =
    await contractLineItemLocationService.getLocationContractLineItemsCount(
      params.location_id,
      filters
    );
  const location = await locationService.getLocation(params.location_id!);

  if (!location) {
    return redirectWithError(
      `/intelligence/${managerAccountId}/locations`,
      "Location not found"
    );
  }

  const vendors = await managerAccountVendorService.getVendorOptions(
    managerAccountId
  );

  const filteredLocationContractLineItems = locationContractLineItems.filter(
    contractLineItemLocation => {
      if (locationParam.length > 0) {
        return locationParam.some(range => {
          const [min, max] = range.split("-").map(Number);
          const locationCount =
            contractLineItemLocation.contract_line_item
              .contract_line_item_locations?.length ?? 0;

          return (
            !isNaN(min) &&
            !isNaN(max) &&
            locationCount >= min &&
            locationCount <= max
          );
        });
      }
      return true;
    }
  );

  return json({
    user,
    account,
    location,
    locationContractLineItems: filteredLocationContractLineItems,
    locationContractLineItemsCount,
    vendors,
    locationParam,
    statusParam,
    vendorParam,
    searchTerm,
    page,
    endDate,
    startDate,
  });
}

export default function AssociatedContracts() {
  const navigate = useNavigate();
  const {
    user,
    account,
    locationContractLineItems,
    locationContractLineItemsCount,
    vendors,
    location,
    locationParam,
    statusParam,
    vendorParam,
    searchTerm,
    page,
    endDate,
    startDate,
  } = useLoaderData<typeof loader>();
  const baseUrl = `/intelligence/${account.id}/locations/${location.id}/assigned-vendors`;
  const [openFilteringModal, setOpenFilteringModal] = useState(false);
  const [filterByVendor, setFilterByVendor] = useState<string[]>([]);
  const [currentPage, setCurrentPage] = useState(page ?? 1);
  const [perPage] = useState(50);
  const [selectedVendors, setSelectedVendors] = useState<Vendor[]>([]);
  const [autocompleteValue, setAutocompleteValue] = useState<string>("");
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [renewalDateFrom, setRenewalDateFrom] = useState(startDate ?? "");
  const [renewalDateTo, setRenewalDateTo] = useState(endDate ?? "");
  const [dateRangeError, setDateRangeError] = useState<string>("");
  const [, setSearchParams] = useSearchParams();

  const locationQuantity = [
    { value: "1-50", name: "1-50" },
    { value: "50-100", name: "50-100" },
    { value: "100-200", name: "100-200" },
    { value: "200-500", name: "200-500" },
    { value: "500", name: "500+" },
  ];
  const [filterByLocationsQuantity, setFilterByLocationsQuantity] = useState<
    string[]
  >([]);
  const [filterByContractStatus, setFilterByContractStatus] = useState<
    string[]
  >([]);

  function constructNewURL(
    baseUrl: string,
    searchQuery: string,
    filterByLocationsQuantity: string[],
    filterByContractStatus: string[],
    filterByVendor: string[],
    newPage: number,
    perPage: number,
    renewalDateFrom?: string,
    renewalDateTo?: string
  ): string {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchQuery);

    if (filterByLocationsQuantity.length > 0) {
      searchParams.append(
        "locationQuantity",
        filterByLocationsQuantity.join(",")
      );
    }

    if (filterByContractStatus.length > 0) {
      searchParams.append("status", filterByContractStatus.join(","));
    }

    if (filterByVendor.length > 0) {
      searchParams.append("vendor", filterByVendor.join(","));
    }

    if (renewalDateFrom) {
      searchParams.append("startDate", renewalDateFrom);
    }

    if (renewalDateTo) {
      searchParams.append("endDate", renewalDateTo);
    }

    searchParams.append("page", newPage.toString());
    searchParams.append("perPage", perPage.toString());

    return `${baseUrl}?${searchParams.toString()}`;
  }

  // Handle filtering, name searching and pagination
  const handleFiltering = (newPage?: number, newSearchQuery?: string) => {
    const newURL = constructNewURL(
      baseUrl,
      newSearchQuery ?? searchTerm ?? "",
      filterByLocationsQuantity,
      filterByContractStatus,
      filterByVendor,
      newPage ? newPage : currentPage,
      perPage,
      renewalDateFrom,
      renewalDateTo
    );
    if (!isEmpty(renewalDateFrom) && isEmpty(renewalDateTo)) {
      setDateRangeError("Select end date");
      return;
    }
    if (!isEmpty(renewalDateTo) && isEmpty(renewalDateFrom)) {
      setDateRangeError("Select start date");
      return;
    }
    setDateRangeError("");
    setOpenFilteringModal(false);
    navigate(newURL);
  };

  const clearFilters = () => {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchTerm ?? "");

    setFilterByVendor([]);
    setSelectedVendors([]);
    setFilterByLocationsQuantity([]);
    setFilterByContractStatus([]);
    setRenewalDateFrom("");
    setRenewalDateTo("");

    searchParams.delete("locationQuantity");
    searchParams.delete("vendor");

    const newURL = `${baseUrl}?${searchParams.toString()}`;

    setOpenFilteringModal(false);
    navigate(newURL);
  };

  const handlePageChange = (newPage: number) => {
    const newURL = constructNewURL(
      baseUrl,
      searchTerm ?? "",
      filterByLocationsQuantity,
      filterByContractStatus,
      filterByVendor,
      newPage,
      perPage
    );
    navigate(newURL);
    setCurrentPage(newPage);
  };

  const totalPages = Math.ceil(locationContractLineItemsCount / perPage);
  const pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);
  const resultsText = `${locationContractLineItems.length} out of ${locationContractLineItemsCount} results`;

  useEffect(() => {
    if (locationParam.length > 0) {
      const locationRanges = locationParam.flatMap(value => value.split(","));
      setFilterByLocationsQuantity(locationRanges);
    }

    if (statusParam.length > 0) {
      const status = statusParam.flatMap(value => value.split(","));
      setFilterByContractStatus(status);
    }

    if (vendorParam.length > 0) {
      const vendorFilters = vendorParam.flatMap(value => value.split(","));
      setFilterByVendor(vendorFilters);

      const initialSelectedVendors = vendors
        .filter(vendor => vendorFilters.includes(vendor?.id || ""))
        .filter(Boolean);

      setSelectedVendors(initialSelectedVendors);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleAddTag = (vendor: Vendor) => {
    if (vendor && !filterByVendor.includes(vendor.id)) {
      setSelectedVendors([...selectedVendors, vendor]);
      setFilterByVendor([...filterByVendor, vendor.id || ""]);
      setAutocompleteValue("");
    } else {
      setErrorMessage("Filter is already selected");
    }
  };

  const handleRemoveTag = (vendor: Vendor) => {
    const updatedVendors = selectedVendors.filter(
      selectedVendor => selectedVendor.id !== vendor.id
    );
    setSelectedVendors(updatedVendors);
    setFilterByVendor(filterByVendor.filter(id => id !== vendor.id));
    setErrorMessage("");
  };

  const onOrderBy = useCallback(
    (value: Record<string, string>) => {
      const newOrderBy = Object.entries(value).map(
        ([key, value]) => `${key}:${value}`
      );
      setSearchParams((oldSearchParams: any) => ({
        ...Object.fromEntries(oldSearchParams),
        orderBy: newOrderBy,
      }));
    },
    [setSearchParams]
  );

  const filteredVendors = vendors.filter(vendor =>
    vendor?.name.toLowerCase().includes(autocompleteValue.toLowerCase())
  );

  const renderVendor = (option: Vendor) => {
    return option.name;
  };

  // Permissions
  const userCanViewContractLineItem = canDoOnLocation(
    user,
    account,
    location,
    Permission.ViewContractLineItem
  );

  const userCanViewCompanyLevelContractLineItem = canDoOnLocation(
    user,
    account,
    location,
    Permission.ViewCompanyLevelContractLineItem
  );

  const userCanManageContractLineItemLocations = canDoOnLocation(
    user,
    account,
    location,
    Permission.ManageContractLineItemLocations
  );

  const userCanCopyLineItemsToLocations = canDoOnLocation(
    user,
    account,
    location,
    Permission.CopyContractLineItemsToLocations
  );

  // If the contract line item contract is managed by the Company Account,
  // then don't allow the community manager user to click the row
  const shouldClickContractLineItemRow = (locationId: string | null) => {
    if (!locationId) {
      return userCanViewCompanyLevelContractLineItem;
    }
    return userCanViewContractLineItem;
  };

  // Copy Assignments related
  const dropdownItems = userCanCopyLineItemsToLocations
    ? [
        {
          to: `${baseUrl}/copy`,
          label: "Copy assignments to new location(s)",
          icon: ClipboardDocumentIcon,
          id: "copy-assignments",
        },
      ]
    : undefined;

  // Line item to edit in modal
  const [contractLineItemToEditModal, setContractLineItemToEditModal] =
    useState<(typeof locationContractLineItems)[number] | null>(null);

  return (
    <>
      <Modal
        isOpen={openFilteringModal}
        onClose={() => setOpenFilteringModal(false)}
        size="medium"
        manager={true}
      >
        <div className="p-2 lg:p-6">
          {dateRangeError && <Toast variant="error" message={dateRangeError} />}
          <h4 className="font-bold">Filter By</h4>
          <div className="divide divide-y divide-2 ">
            <div>
              <div className="my-4 font-semibold"># Locations Assigned</div>
              <div className="flex justify-around">
                {locationQuantity.map((option, index) => (
                  <CrudCheckboxField
                    key={index}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: filterByLocationsQuantity.includes(
                        option.value
                      ),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterByLocationsQuantity([
                          ...filterByLocationsQuantity,
                          option.value,
                        ]);
                      } else {
                        setFilterByLocationsQuantity(
                          filterByLocationsQuantity.filter(
                            i => i !== option.value
                          )
                        );
                      }
                    }}
                  />
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Vendors</div>
              <AutocompleteFilter
                initialValue={autocompleteValue}
                options={filteredVendors}
                onFilterChange={setAutocompleteValue}
                onAddTag={handleAddTag}
                onRemoveTag={handleRemoveTag}
                selectedTags={selectedVendors}
                errorMessage={errorMessage}
                renderOption={renderVendor}
              />
            </div>
            <div>
              <div className="my-4 font-semibold">
                Current Term End Date Range
              </div>
              <div className="flex gap-x-6">
                <div className="w-full">
                  <CrudDateField
                    field={{
                      type: "text",
                      name: "startDate",
                      errors: [],
                      label: "Start Date",
                      placeholder: "From Date",
                      defaultValue: renewalDateFrom,
                      onChange: e => setRenewalDateFrom(e.target.value),
                    }}
                  />
                </div>
                <div className="w-full">
                  <CrudDateField
                    field={{
                      type: "text",
                      name: "endDate",
                      errors: [],
                      label: "End Date",
                      placeholder: "To Date",
                      defaultValue: renewalDateTo,
                      onChange: e => setRenewalDateTo(e.target.value),
                    }}
                  />
                </div>
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Contract Status</div>
              <div className="flex justify-around">
                {Object.values(ContractStatus).map((option, index) => (
                  <CrudCheckboxField
                    key={index}
                    field={{
                      name: "filter_by",
                      value: option,
                      label: option,
                      errors: [],
                      description: "",
                      defaultChecked: filterByContractStatus.includes(option),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterByContractStatus([
                          ...filterByContractStatus,
                          option,
                        ]);
                      } else {
                        setFilterByContractStatus(
                          filterByContractStatus.filter(i => i !== option)
                        );
                      }
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
          <div className="flex justify-end mt-8 items-center space-x-3">
            <button
              className="text-sky-500"
              onClick={() => {
                setCurrentPage(1);
                clearFilters();
              }}
            >
              Clear filters
            </button>
            <CTA
              variant="coral-shadow"
              onClick={() => {
                handleFiltering(1);
              }}
            >
              Show results
            </CTA>
          </div>
        </div>
      </Modal>
      {contractLineItemToEditModal && (
        <LocationContractLineItemEditStatusModal
          isOpen={!!contractLineItemToEditModal}
          contractLineItemLocation={contractLineItemToEditModal}
          location={location}
          onClose={() => setContractLineItemToEditModal(null)}
        />
      )}
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
          },
          {
            name: "Assigned line items",
            to: `/intelligence/${account.id}/locations/${location.id}/assigned-vendors`,
            active: true,
          },
        ]}
        title={
          <>
            Assigned line items: <br /> {location.name}
          </>
        }
        description="View the vendors, contracts, and line items assigned to this location. 
          To change the status of a line item that you manage, click on the edit icon in the corresponding row."
        ellipsisItems={dropdownItems}
      />
      <FilterBar
        inputPlaceholder="Search for contracts, vendors, products, and fees"
        onFilter={searchQuery => {
          handleFiltering(1, searchQuery);
        }}
        filters={{
          onOpenFilteringModal: setOpenFilteringModal,
          filtersCount:
            filterByLocationsQuantity.length +
            filterByContractStatus.length +
            filterByVendor.length +
            (startDate && endDate ? 1 : 0),
        }}
      />
      <div>
        <LocationContractLineItemsTable
          columnsToShow={[
            "vendorNameWithContractName",
            "contractLineItemName",
            "price",
            "currentTermEnds",
            "contractLineItemStatus",
          ]}
          items={locationContractLineItems}
          showSelectBox={false}
          onClickEdit={
            userCanManageContractLineItemLocations
              ? id =>
                  setContractLineItemToEditModal(
                    locationContractLineItems.find(
                      contractLineItem => contractLineItem.id === id
                    ) ?? null
                  )
              : undefined
          }
          onClickRow={location =>
            shouldClickContractLineItemRow(
              location.contract_line_item.contract.location_id
            ) &&
            navigate(
              `/intelligence/${account.id}/contract/${location?.contract_line_item.contract.id}/line-item/${location?.contract_line_item.id}/summary`
            )
          }
          onOrderBy={onOrderBy}
          user={user}
          account={account}
        />
        <Pagination
          resultsText={resultsText}
          pageNumbers={pageNumbers}
          currentPage={currentPage}
          totalPages={totalPages}
          handleCallback={handlePageChange}
        ></Pagination>
      </div>
    </>
  );
}
