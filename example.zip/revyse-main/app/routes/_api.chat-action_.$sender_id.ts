import { EmojiType } from "@prisma/client";
import type { ActionFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { jsonWithError } from "remix-toast";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import { MB } from "~/utils/constants.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import { castFormFields } from "~/utils/type.utils";

const ReactMessageForm = z.object({
  message_id: z.string().uuid(),
  type: z.enum([
    EmojiType.Tada,
    EmojiType.WhiteCheckMark,
    EmojiType.Heart,
    EmojiType.Joy,
    EmojiType.Thumbsup,
  ]),
  sender_id: z.string().uuid(),
});

const MessageFileSchema = z.object({
  id: z.string(),
  name: z.string(),
  file: z.string(),
});

const MessageSubmission = z.object({
  sender_id: z.string().uuid(),
  content: z.string(),
  group_chat_id: z.string().uuid(),
  message_files: z.array(MessageFileSchema),
  mentioned_users: z.array(z.string().uuid()).optional(),
});

export async function action({ request, params }: ActionFunctionArgs) {
  const { managerAccountTaskService } = await WebDIContainer();

  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "message_files.file", byteLimit: 60 * MB },
  ]);
  const intent = form.get("intent") as string;
  const senderId = params.sender_id;

  if (intent === "reactMessage") {
    const fields = {
      type: form.get("type") as string,
      message_id: form.get("message_id"),
      sender_id: senderId,
    };

    const validation = ReactMessageForm.safeParse(fields);

    if (validation.success) {
      await managerAccountTaskService.reactTaskMessage(
        validation.data.message_id,
        validation.data.type,
        validation.data.sender_id
      );
      return json({
        success: true,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      });
    }
  } else {
    const fileIds = form.getAll("message_files.id") as string[];
    const files = form.getAll("message_files.file") as string[];
    const fileNames = form.getAll("message_files.name") as string[];

    const message_files = fileIds.map((file, j) => {
      return {
        id: file,
        name: fileNames[j],
        file: files[j],
      };
    });
    const fields = {
      sender_id: senderId,
      content: form.get("content") as string,
      group_chat_id: form.get("group_chat_id"),
      message_files,
      mentioned_users: [] as string[],
    };

    // Extract mentioned user ids
    const mentionedUserIds: string[] = [];
    const content = fields.content;

    const idRegex = /data-id="([^"]*?)"/g;
    let match;
    while ((match = idRegex.exec(content)) !== null) {
      mentionedUserIds.push(match[1]);
    }

    fields.mentioned_users = mentionedUserIds;

    const validation = MessageSubmission.safeParse(fields);

    if (validation.success) {
      // Wrap images in anchor tags
      let content = validation.data.content;
      const imgRegex = /<img\s+[^>]*?src="([^"]*?)"[^>]*?>/g;
      content = content.replace(imgRegex, (match, src) => {
        return `<a href="${src}">${match}</a>`;
      });

      await managerAccountTaskService.sendTaskMessage(
        validation.data.sender_id,
        content,
        validation.data.group_chat_id,
        validation.data.mentioned_users,
        validation.data.message_files
      );
      return json({
        success: true,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      });
    }

    const errors = issuesByKey(validation.error.issues);

    return jsonWithError(
      { success: false, fields: castFormFields(fields), errors },
      "Error sending the message, please try again.",
      { status: 400 }
    );
  }
}
