import type { MetaFunction } from "@remix-run/node";
import { EnvelopeIcon } from "@heroicons/react/24/outline";
import { ArrowLeftIcon } from "@heroicons/react/20/solid";
import { CTA } from "~/components/cta.component";

export const meta: MetaFunction = () => [
  { title: "Revyse | Connect Request Sent" },
  {
    name: "description",
    content:
      "Your connect request has been received. You'll hear from us soon!",
  },
];

export default function ForgotPasswordRoute() {
  return (
    <div className="flex justify-center">
      <div className="max-w-3xl bg-white text-center rounded-3xl border border-gray-100 p-12 mt-6">
        <EnvelopeIcon className="h-12 inline mb-6" />
        <h1 className="text-3xl">We've received your connect request!</h1>
        <p className="my-4">You'll be hearing from us shortly.</p>
        <p className="my-8 flex items-center justify-center">
          <CTA to="/" className="flex items-center">
            <ArrowLeftIcon className="h-5 mr-2" /> Back to Revyse
          </CTA>
        </p>
      </div>
    </div>
  );
}
