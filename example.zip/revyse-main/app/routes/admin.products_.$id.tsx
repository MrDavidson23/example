import { TrashIcon } from "@heroicons/react/20/solid";
import { PencilIcon } from "@heroicons/react/24/outline";
import { ProductState, VendorState } from "@prisma/client";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Form, Link, useActionData, useLoaderData } from "@remix-run/react";
import { isEmpty, isNil } from "lodash";
import { useState } from "react";
import { jsonWithError, redirectWithSuccess } from "remix-toast";
import { z } from "zod";
import { Button, DangerButton } from "~/components/button.component";
import { CrudFormPage } from "~/components/form/crud-form-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assertAuthorized } from "~/utils/assert.utils.server";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import { getUser } from "~/utils/session.server";
import { slugify } from "~/utils/string.utils";
import { Slug } from "~/utils/validation.utils.server";

const ProductForm = z.object({
  title: z
    .string()
    .max(55, "Title must be maximum 55 characters")
    .min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  vendor_id: z.string().uuid("Vendor required"),
  primary_category_id: z.string().uuid("Category required"),
  slug: Slug,
  state: z.nativeEnum(ProductState).nullable(),
});

export const updateAction = async ({
  id,
  form,
  user,
}: {
  id: string | undefined;
  form: FormData;
  user: { id: string };
}) => {
  const state = !isEmpty(form.get("state")) ? form.get("state") : null;
  const fields = {
    title: form.get("title"),
    description: form.get("description"),
    vendor_id: form.get("vendor_id"),
    primary_category_id: form.get("primary_category_id"),
    slug: form.get("slug"),
    state,
  };

  const validation = ProductForm.safeParse(fields);

  if (validation.success) {
    const { vendorService, productService } = await WebDIContainer();

    // Show error if the user tries to set a product to a published state but the Vendor that they have selected in the dropdown is NOT approved for that
    if (validation.data.state !== null) {
      const vendor = await vendorService.getVendor(validation.data.vendor_id);
      if (
        validation.data.state === ProductState.intelligence &&
        vendor?.state === VendorState.NotApproved
      ) {
        return jsonWithError(
          {
            fields,
            success: false,
            errors: issuesByKey([
              {
                path: ["state"],
                message:
                  "Product cannot be published on Revyse Intelligence because this vendor is not approved for publishing across Revyse Intelligence.",
              },
            ]),
          },
          DEFAULT_FORM_ERROR_MESSAGE
        );
      } else if (
        validation.data.state === ProductState.discovery &&
        vendor?.state !== VendorState.ApprovedForPublishing
      ) {
        return jsonWithError(
          {
            fields,
            success: false,
            errors: issuesByKey([
              {
                path: ["state"],
                message:
                  "Product cannot be published on Revyse Discovery because this vendor is not approved for publishing across Revyse",
              },
            ]),
          },
          DEFAULT_FORM_ERROR_MESSAGE
        );
      }
    }

    const product = await productService.upsertProductFromAdmin(
      id,
      user,
      validation.data
    );

    if (id === "new") {
      return redirectWithSuccess(
        `/admin/products/${product.id}`,
        "Product created successfully"
      );
    }
    return redirectWithSuccess(
      `/admin/products`,
      "Product updated successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return jsonWithError(
    { success: false, fields, errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
};

async function deleteAction({ id }: { id: string | undefined }) {
  const { productService } = await WebDIContainer();
  const response = await productService.deleteProductFromAdmin(id);
  if (!response.success) {
    return jsonWithError(
      {
        success: false,
        fields: {} as any,
        errors: issuesByKey([
          {
            path: ["delete"],
            message: response.error ?? DEFAULT_FORM_ERROR_MESSAGE,
          },
        ]),
      },
      response.error ?? DEFAULT_FORM_ERROR_MESSAGE
    );
  }
  return redirectWithSuccess("/admin/products", "Product deleted successfully");
}

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));
  const form = await request.formData();
  const intent = form.get("intent");
  if (intent === "delete") {
    return deleteAction({ id: params.id });
  }

  return updateAction({ id: params.id, form, user });
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const id = params.id!;
  const { productService, vendorService, productCategoryService } =
    await WebDIContainer();
  const product =
    id === "new"
      ? ({
          id: "new",
          state: null,
          industries: [],
          banner_url: null,
          brand_video_urls: [],
          description: "",
          positioning: "",
          created_at: new Date(),
          demo_scheduling_url: null,
          download_urls: [],
          features: [],
          good_for_tags: [],
          image_urls: [],
          lead_prospect_email: null,
          logo_url: null,
          packages: [],
          primary_category_id: "",
          product_demo_urls: [],
          review_questions: [],
          secondary_category_id: null,
          slug: "",
          tertiary_category_id: null,
          title: "",
          updated_at: new Date(),
          vendor_id: "",
          banner_file_id: null,
          banner_file: null,
          logo_file_id: null,
          logo_file: null,
          image_files: [],
          brand_video_files: [],
          download_files: [],
          demo_files: [],
          approved_at: null,
          approved_by_id: null,
          page_title: "",
          meta_description: "",
          subscriptions: [],
          promo_text: null,
          demo_storylane_url: null,
          manager_account_id: null,
          vendor: null,
        } as Awaited<
          ReturnType<typeof productService.getProductIncludingAllFields>
        >)
      : await productService.getProductIncludingAllFields(id);
  if (!product) {
    throw new Response("Not found", { status: 404 });
  }
  return json({
    product,
    categories: await productCategoryService.getAllCategories(),
    vendors: await vendorService.getVendorsIdAndName({}),
  });
}

export default function AdminProductsNewRoute() {
  const actionData = useActionData<typeof action>();
  const { product, categories, vendors } = useLoaderData<typeof loader>();
  const activeSubscription = product.subscriptions[0];
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [slug, setSlug] = useState(
    actionData?.fields.slug ?? product.slug ?? ""
  );
  const [productState, setProductState] = useState(
    actionData?.fields?.state ?? product?.state ?? ""
  );

  return (
    <>
      <CrudFormPage
        crumbs={[
          { name: "Products", to: "/admin/products", active: false },
          {
            name: product.title,
            to: `/admin/products/${product.id}`,
            active: true,
          },
        ]}
        config={{
          submitSuccess: actionData?.success,
          customToastMessage: actionData?.errors.delete?.join(", "),
          showToast: !isEmpty(actionData?.errors.delete),
          sections: [
            {
              title: "Update Product",
              subtitle: (
                <div>
                  {activeSubscription && (
                    <div className="mt-2">
                      <h4 className="mt-3 text-base mb-1">Subscription</h4>
                      <span className="text-sm">
                        {activeSubscription.stripe_price.product.name} -{" "}
                        {activeSubscription.status}
                      </span>
                      <h4 className="mt-3 text-base mb-1">Users</h4>
                      <div className="flex flex-col gap-y-2">
                        {activeSubscription.user_roles.map(user_role => (
                          <Link
                            key={user_role.id}
                            to={`/admin/users/${user_role.user.id}`}
                            className="grid grid-cols-4 gap-x-2 items-center text-sm hover:text-sky-600"
                            target="_blank"
                          >
                            <span className="col-span-3 truncate">
                              {user_role.user.first_name}{" "}
                              {user_role.user.last_name}
                              <br />
                              {user_role.user.email}
                            </span>
                            <span className="col-span-1 capitalize">
                              {" "}
                              {user_role.role.toLocaleLowerCase()}
                            </span>
                          </Link>
                        ))}
                        {isEmpty(activeSubscription.user_roles) && "--"}
                      </div>
                    </div>
                  )}
                </div>
              ),
              fields: [
                {
                  name: "title",
                  label: "Title",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields.title ?? undefined
                    : product.title,
                  errors: actionData?.errors.title ?? [],
                  onChange: e => {
                    if (product.id !== "new") return;
                    const slugField = document.getElementById(
                      "slug"
                    ) as HTMLInputElement;
                    const slugged = slugify(e.target.value);
                    setSlug(slugged);
                    slugField.value = slugged;
                  },
                  maxCharacters: 55,
                },
                {
                  name: "slug",
                  label: "Slug",
                  type: "text",
                  defaultValue: slug,
                  errors: actionData?.errors.slug ?? [],
                  onChange: e => {
                    const slugged = slugify(e.target.value);
                    setSlug(slugged);
                    e.target.value = slugged;
                  },
                  description:
                    "Please be very careful about changing this. It will severely impact SEO.",
                },
                {
                  name: "state",
                  label: "Not Approved",
                  type: "radio",
                  value: undefined,
                  checked: !productState,
                  errors:
                    actionData?.fields.state === null
                      ? actionData?.errors.state ?? []
                      : [],
                  onChange: e => setProductState(e.target.value),
                  description: "This product has not been published.",
                },
                {
                  name: "state",
                  label: "Approved for Publishing on Revyse",
                  type: "radio",
                  value: "discovery",
                  checked: productState === ProductState.discovery,
                  errors:
                    actionData?.fields.state === ProductState.discovery
                      ? actionData?.errors.state ?? []
                      : [],
                  onChange: e => setProductState(e.target.value),
                  description:
                    "Check this box to publish to Revyse Discovery and Revyse Intelligence.",
                },
                {
                  name: "state",
                  label: "Revyse Intelligence-Only",
                  type: "radio",
                  value: "intelligence",
                  checked: productState === ProductState.intelligence,
                  errors:
                    actionData?.fields.state === ProductState.intelligence
                      ? actionData?.errors.state ?? []
                      : [],
                  onChange: e => setProductState(e.target.value),
                  description:
                    "This product will not be visible on Revyse Discovery.",
                },
                {
                  name: "description",
                  label: "Description",
                  description: "A full description of the product",
                  type: "textarea",
                  defaultValue: actionData
                    ? actionData.fields.description ?? undefined
                    : product.description,
                  errors: actionData?.errors.description ?? [],
                },
                {
                  name: "primary_category_id",
                  label: "Category",
                  type: "select",
                  options: categories.map(c => ({
                    label: c.name,
                    value: c.id,
                  })),
                  defaultValue: actionData
                    ? actionData.fields.primary_category_id ?? undefined
                    : product.primary_category_id,
                  errors: actionData?.errors.primary_category_id ?? [],
                },
                {
                  name: "vendor_id",
                  label: "Vendor",
                  type: "select",
                  options: vendors.map(v => ({ label: v.name, value: v.id })),
                  defaultValue: actionData
                    ? actionData.fields.vendor_id ?? undefined
                    : product.vendor_id ?? undefined,
                  errors: actionData?.errors.vendor_id ?? [],
                },
              ],
            },
          ],
        }}
        buttonsSlot={
          <>
            {product.id !== "new" && (
              <>
                {confirmDeleteOpen ? (
                  <Form
                    className="flex justify-between  items-center"
                    method="post"
                  >
                    Are you sure you want to delete this product? It will be
                    gone forever...
                    <input type="hidden" name="intent" value="delete" />
                    <Button
                      onClick={() => setConfirmDeleteOpen(false)}
                      className="ml-2"
                    >
                      Cancel
                    </Button>
                    <DangerButton type="submit" className="ml-2">
                      Yep!
                    </DangerButton>
                  </Form>
                ) : (
                  <>
                    <Button to={`/vendor/products/${product.id}`} className="">
                      <PencilIcon className="h-4 mr-1" /> Edit Full Listing
                    </Button>
                    <DangerButton
                      onClick={() => {
                        setConfirmDeleteOpen(!confirmDeleteOpen);
                      }}
                    >
                      <div className="flex">
                        <TrashIcon className="h-5 mr-1" />
                        Delete
                      </div>
                    </DangerButton>
                  </>
                )}
              </>
            )}
          </>
        }
      />
    </>
  );
}
