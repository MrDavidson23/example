import { json } from "@remix-run/node";
import { useLoaderData, useLocation, useNavigate } from "@remix-run/react";
import type { LoaderFunctionArgs, SerializeFrom } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Permission } from "~/utils/intelligence-permission.utils";
import { Breadcrumbs } from "~/components/breadcrumbs.component";
import { isEmpty } from "lodash";
import { useMemo, useRef } from "react";
import { VendorPreferredIcon } from "~/components/intelligence/vendors/preferred-icon.component";
import StarRating from "~/components/star-rating.component";
import { Button } from "~/components/button.component";
import { RevysePencilIcon } from "~/components/revyse-pencil-icon.component";
import {
  CalendarDaysIcon,
  ComputerDesktopIcon,
  UsersIcon,
} from "@heroicons/react/24/outline";
import { CTA } from "~/components/cta.component";
import { ContractsTable } from "~/components/intelligence/contracts/contracts-table.component";
import IntelligenceVendorDetailsNavBar from "~/components/intelligence/vendors/intelligence-vendor-details-nav-bar.component";
import ManagerAccountVendorContactCard from "~/components/intelligence/vendors/manager-account-vendor-contact-card.component";
import type { ManagerAccountVendorContact } from "@prisma/client";
import {
  ManagerAccountVendorBusinessCriticalityRating,
  ManagerAccountVendorCybersecurityOptions,
  ManagerAccountVendorContactType,
  ManagerAccountVendorDataPrivacyOptions,
  ManagerAccountVendorInternalReviewStatus,
  ManagerAccountVendorRiskScore,
  IntelligenceVendorIntegrationStatus,
} from "@prisma/client";
import VendorRiskGraph from "~/components/intelligence/vendors/vendor-risk-graph.component";
import BusinessRiskGraph from "~/components/intelligence/vendors/business-risk-graph.component";
import ReviewStatusGraph from "~/components/intelligence/vendors/review-status-graph.component";
import { IncidentsTable } from "~/components/intelligence/vendors/incidents-table.component";
import { ManagerAccountVendorCybersecurityLabels } from "~/utils/constants.utils";
import StatusChip from "~/components/status-chip.component";
import { VerifiedIcon } from "~/components/verified-icon.component";
import { Empty } from "~/components/empty.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { CanDo } from "~/components/intelligence/can-do.component";
dayjs.extend(utc);

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { managerAccountVendorService } = await WebDIContainer();

  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewVendorDetails],
    }
  );

  // Get managerAccountVendor details
  const managerAccountVendor =
    await managerAccountVendorService.getManagerAccountVendorWithIntegrations(
      params.vendor_id!
    );

  if (!managerAccountVendor) {
    throw new Response("Not found", { status: 404 });
  }

  // Gets vendor rating
  const vendorRating = await managerAccountVendorService.getVendorRating(
    managerAccountVendor?.vendor.id || ""
  );

  // Gets 5 contracts to render in the recent contracts table
  const managerAccountVendorContracts =
    await managerAccountVendorService.getManagerAccountVendorContracts(
      user,
      account,
      params.vendor_id || "",
      {},
      5,
      0,
      [{ status: "asc" }, { current_term_end_date: "asc" }]
    );

  return json({
    managerAccountVendor,
    vendorRating,
    managerAccountVendorContracts,
    user,
    account,
  });
}

export default function IntelligenceVendorsCreate() {
  const location = useLocation();
  const navigate = useNavigate();

  const {
    managerAccountVendor,
    vendorRating,
    managerAccountVendorContracts,
    account,
  } = useLoaderData<typeof loader>();

  const sortedVendorIntegrations =
    managerAccountVendor.intelligence_vendor_integrations.sort((a, b) => {
      const nameA =
        a.integrated_vendor?.vendor?.name || a.integrated_product?.title || "";
      const nameB =
        b.integrated_vendor?.vendor?.name || b.integrated_product?.title || "";
      return nameA.localeCompare(nameB);
    });

  // Defining sections to use them in the nav bar
  const overviewSection = useRef<HTMLElement>(null);
  const companyInfoSection = useRef<HTMLElement>(null);
  const recentContractsSection = useRef<HTMLElement>(null);
  const contactsSection = useRef<HTMLElement>(null);
  const riskManagementSection = useRef<HTMLElement>(null);
  const incidentManagementSection = useRef<HTMLElement>(null);

  const navChips = useMemo(() => {
    return [
      {
        label: "Overview",
        ref: overviewSection,
      },
      {
        label: "Company Info",
        ref: companyInfoSection,
      },
      {
        label: "Recent Contracts",
        ref: recentContractsSection,
      },
      {
        label: "Contacts",
        ref: contactsSection,
      },
      {
        label: "Risk Management",
        ref: riskManagementSection,
      },
      {
        label: "Incident Management",
        ref: incidentManagementSection,
      },
    ];
  }, []);

  const logoSrc = useMemo(() => {
    return managerAccountVendor?.vendor.logo_file_id
      ? `/images/${managerAccountVendor?.vendor.logo_file_id}`
      : "/assets/default-logo.png";
  }, [managerAccountVendor?.vendor.logo_file_id]);

  const contactsToShow = useMemo(() => {
    const contacts: {
      type: ManagerAccountVendorContactType;
      contact: SerializeFrom<ManagerAccountVendorContact> | undefined;
    }[] = managerAccountVendor?.manager_account_vendor_contacts.map(
      contact => ({
        type: contact.type,
        contact: contact,
      })
    );

    Object.values(ManagerAccountVendorContactType)
      .filter(type => !contacts.find(c => c.type === type))
      .forEach(type =>
        contacts.push({
          type: type,
          contact: undefined,
        })
      );

    return contacts.slice(0, 4);
  }, [managerAccountVendor?.manager_account_vendor_contacts]);

  return (
    <>
      <Breadcrumbs
        className="grow"
        crumbs={[
          {
            name: "All vendors",
            to: `/intelligence/${managerAccountVendor.manager_account_id}/vendors`,
            active: false,
          },
          {
            name: managerAccountVendor?.vendor.name || "",
            to: location.pathname,
            active: true,
          },
        ]}
      />
      <section
        ref={overviewSection}
        className="mt-5 overflow-hidden bg-white rounded-md shadow"
      >
        {/* Vendor Banner */}
        {/* <img
          src="/assets/default-vendor-banner.png"
          alt="Vendor Banner"
          className="object-cover h-52"
        /> */}
        {/* Vendor Details */}
        <div className="relative grid grid-cols-1 p-7 lg:grid-cols-2">
          <div className="grid justify-start lg:grid-flow-col lg:grid-rows-2 gap-x-7 gap-y-4 items-center relative">
            {/* Vendor Logo */}
            <div className="flex justify-center row-span-2 max-w-24 lg:max-w-[unset]">
              <img
                src={logoSrc}
                alt="Vendor Logo"
                className="w-24 lg:w-48 h-auto rounded-md aspect-square"
                width="192"
                height="192"
              />
              {managerAccountVendor?.is_preferred && (
                <div className="h-7 lg:h-12 absolute top-[-1rem] right-[-1rem]">
                  <VendorPreferredIcon
                    vendorName={managerAccountVendor?.vendor.name || ""}
                    position="right"
                    className="h-full w-7 lg:w-12"
                  />
                </div>
              )}
            </div>
            <div className="flex items-center max-w-md row-span-1">
              {/* Vendor Name */}
              <h1 className="text-xl lg:text-4xl font-bold" id="vendor-name">
                {managerAccountVendor?.vendor.name}
              </h1>
            </div>
            <div className="row-span-1">
              {/* Vendor Rating */}
              <div className="flex gap-3">
                <StarRating rating={vendorRating.rating} size={6} />
                <span>{vendorRating.rating.toFixed(1)}</span>
                <span className="text-gray-400">
                  ({vendorRating.totalReviews})
                </span>
              </div>
              {/* Vendor Status */}
              <StatusChip
                model="ManagerAccountVendorStatus"
                label={managerAccountVendor.status}
                status={managerAccountVendor.status}
                className="mt-4"
              />
            </div>
          </div>
          <div className="grid grid-cols-2 mt-5 border-gray-200 lg:border-l lg:mx-7 lg:pl-7 gap-x-4 gap-y-4 lg:mt-0">
            <div className="font-semibold">Vendor Since</div>
            <div>
              {managerAccountVendor?.vendor_since
                ? dayjs.utc(managerAccountVendor?.vendor_since).format("YYYY")
                : "--"}
            </div>
            <div className="font-semibold">Internal Vendor Code</div>
            <div>
              {managerAccountVendor?.internal_vendor_code
                ? managerAccountVendor?.internal_vendor_code
                : "--"}
            </div>
            <div className="font-semibold">Phone Number</div>
            <div>
              {managerAccountVendor?.phone ? managerAccountVendor?.phone : "--"}
            </div>
            <div className="font-semibold">Address</div>
            <div>
              {[
                managerAccountVendor?.street_1,
                managerAccountVendor?.street_2,
                managerAccountVendor?.city,
                managerAccountVendor?.state,
                managerAccountVendor?.zip,
                managerAccountVendor?.country,
              ]
                .filter(Boolean)
                .join(", ") || "--"}
            </div>
          </div>
          <CanDo permission={Permission.ManageVendors}>
            <Button
              className="absolute top-7 right-2 text-md font-medium py-0"
              color="transparent"
              to={`/intelligence/${account.id}/vendors/${managerAccountVendor?.id}/info`}
              id="edit-vendor-info"
            >
              <RevysePencilIcon className="mr-2" /> Edit
            </Button>
          </CanDo>
        </div>
      </section>
      {/* Nav bar */}
      <IntelligenceVendorDetailsNavBar className="mt-5" items={navChips} />

      <section
        ref={companyInfoSection}
        className="mt-5 overflow-hidden bg-white rounded-md shadow p-7"
      >
        <h2 className="text-lg lg:text-2xl font-semibold leading-tight">
          Company Info
        </h2>
        <hr className="my-5" />
        <div className="text-sm lg:text-base font-normal text-balance">
          {managerAccountVendor?.vendor.description}
        </div>
        <div className="grid grid-flow-row grid-cols-1 space-y-3 mt-7 lg:grid-cols-4 lg:space-y-0 lg:space-x-2">
          <div className="flex">
            <CalendarDaysIcon className="my-auto mr-3 h-7" />
            <div>
              <span className="font-semibold">Year Founded</span>
              <br />
              <span>{managerAccountVendor?.vendor.founded_year ?? "--"}</span>
            </div>
          </div>
          <div className="flex">
            <UsersIcon className="my-auto mr-3 h-7" />
            <div>
              <span className="font-semibold">Number of Employees</span>
              <br />
              <span>
                {managerAccountVendor?.vendor.number_employees ?? "--"}
              </span>
            </div>
          </div>
          <div className="flex">
            <ComputerDesktopIcon className="my-auto mr-3 h-7" />
            <div>
              <span className="font-semibold">Company Website</span>
              <br />
              {managerAccountVendor?.vendor.website ? (
                <a
                  href={managerAccountVendor?.vendor.website}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sky-500 hover:text-sky-600"
                >
                  <div className="max-w-full truncate">
                    {managerAccountVendor?.vendor.website.replace(
                      "https://",
                      ""
                    )}
                  </div>
                </a>
              ) : (
                <span>--</span>
              )}
            </div>
          </div>
          <div className="flex">
            <img
              src="/assets/linkedin-icon.png"
              alt="linkedin icon"
              className="my-auto mr-3 h-7 w-auto"
              width="32"
              height="32"
            />
            <div className="max-w-full">
              <span className="font-semibold">LinkedIn Profile</span>
              <br />
              {managerAccountVendor?.vendor.linkedin_profile_url ? (
                <a
                  href={managerAccountVendor?.vendor.linkedin_profile_url}
                  target="_blank"
                  rel="noreferrer"
                  className="text-sky-500 hover:text-sky-600"
                >
                  <div className="max-w-[20ch] truncate">
                    {managerAccountVendor?.vendor.linkedin_profile_url
                      .replace("https://", "")
                      .replace("www.", "")}
                  </div>
                </a>
              ) : (
                <span>--</span>
              )}
            </div>
          </div>
        </div>
      </section>

      <section
        ref={recentContractsSection}
        className="mt-5 overflow-hidden bg-white rounded-md shadow p-7"
      >
        <div className="flex flex-col lg:flex-row justify-between items-center gap-y-3">
          <h2 className="text-lg lg:text-2xl font-semibold leading-tight">
            Recent Contracts
          </h2>
          <div className="flex flex-wrap lg:flex-nowrap justify-center gap-y-2 gap-x-3">
            <CanDo permission={Permission.ViewContractsTable}>
              <CTA
                variant="sky"
                fillStyle="outline"
                to={`/intelligence/${account.id}/vendors/${managerAccountVendor?.id}/contracts`}
                id="view-all-contracts"
              >
                View All Contracts
              </CTA>
            </CanDo>
            <CanDo permission={Permission.ManageContracts}>
              <CTA
                to={`/intelligence/${account.id}/contract/new?vendor_id=${managerAccountVendor?.vendor_id}`}
                id="add-contract"
              >
                Add Contract
              </CTA>
            </CanDo>
          </div>
        </div>
        <div className="mt-7">
          <ContractsTable
            items={managerAccountVendorContracts ?? []}
            columnsToShow={[
              "name",
              "currentTermEnds",
              "contractLineItemsCount",
              "locationsAssigned",
              "annualValue",
              "status",
              "arrowRight",
            ]}
            onClickRow={contract =>
              navigate(
                `/intelligence/${account.id}/contract/${contract.id}/details`
              )
            }
            allowSorting={false}
          />
        </div>
      </section>

      <section
        ref={contactsSection}
        className="mt-5 overflow-hidden bg-white rounded-md shadow p-7"
      >
        <div className="flex flex-col lg:flex-row justify-between items-center">
          <h2 className="text-lg lg:text-2xl font-semibold leading-tight">
            Contacts
          </h2>
          <CanDo permission={Permission.ManageVendors}>
            <div className="flex">
              <Button
                color="transparent"
                className="text-md font-medium"
                to={`/intelligence/${account.id}/vendors/${managerAccountVendor?.id}/contacts`}
                id="edit-vendor-contacts"
              >
                <RevysePencilIcon className="mr-2" /> Edit
              </Button>
            </div>
          </CanDo>
        </div>
        <hr className="my-5" />
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-x-5">
          {contactsToShow.map(item => (
            <ManagerAccountVendorContactCard
              key={item?.type}
              managerAccountVendorContact={item.contact}
              type={item.type}
              className="mt-5 lg:mt-0"
            />
          ))}
        </div>
      </section>

      <section
        ref={riskManagementSection}
        className="mt-5 overflow-hidden bg-white rounded-md shadow p-7"
      >
        <div className="flex flex-col lg:flex-row justify-between items-center">
          <h2 className="text-lg lg:text-2xl font-semibold leading-tight">
            Risk Management
          </h2>
          <CanDo permission={Permission.ManageVendors}>
            <div className="flex">
              <Button
                color="transparent"
                className="text-md font-medium"
                to={`/intelligence/${account.id}/vendors/${managerAccountVendor?.id}/risk`}
                id="edit-vendor-risk"
              >
                <RevysePencilIcon className="mr-2" /> Edit
              </Button>
            </div>
          </CanDo>
        </div>
        <hr className="my-5" />
        <div className="grid grid-cols-1 lg:grid-cols-3 px-10 py-5 place-items-center">
          <VendorRiskGraph
            value={
              managerAccountVendor?.vendor_risk_score ??
              ManagerAccountVendorRiskScore.NotSet
            }
            className="w-56"
            title="Vendor Risk Score"
            tooltip="Set the vendor risk score based on your internal assessment of vendor risk. Consider reputational risks, legal or regulatory risks, and IT or cybersecurity risks when determining a vendor’s risk score."
          />
          <BusinessRiskGraph
            value={
              managerAccountVendor?.business_criticality_rating ??
              ManagerAccountVendorBusinessCriticalityRating.NotSet
            }
            className="w-64 lg:mt-0 mt-10"
            title="Business Criticality Rating"
            tooltip="Set the business criticality rating based on your internal assessment of criticality. Consider a vendor’s impact on your day-to-day operations and if a sudden loss of service would significantly impact your business."
          />
          <ReviewStatusGraph
            value={
              managerAccountVendor?.internal_review_status ??
              ManagerAccountVendorInternalReviewStatus.NotSet
            }
            className="w-64 lg:mt-0 mt-10"
            title="Internal Review Status"
            tooltip="Set the internal review status based on your company’s designated IT security, procurement, or onboarding processes, and whether the vendor has passed or failed those requirements."
          />
        </div>
        <hr className="my-5" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 px-10 py-5 place-items-center">
          <div className="flex flex-col items-center">
            <h3 className="text-base font-semibold mb-2 lg:mb-5 text-center">
              Data Privacy Considerations
            </h3>
            <StatusChip
              color="black"
              label={
                [
                  managerAccountVendor?.data_privacy_prospects_residents,
                  managerAccountVendor?.data_privacy_customers_employees,
                ].find(
                  v => v != ManagerAccountVendorDataPrivacyOptions.NotSet
                ) ?? "Not Set"
              }
              className="w-max font-normal"
            />
          </div>
          <div className="flex flex-col items-center">
            <h3 className="text-base font-semibold mb-2 lg:mb-5 text-center">
              Cybersecurity Standard
            </h3>
            <StatusChip
              color="black"
              label={
                ManagerAccountVendorCybersecurityLabels[
                  managerAccountVendor?.cybersecurity ??
                    ManagerAccountVendorCybersecurityOptions.NotSet
                ]
              }
              className="w-max font-normal"
            />
          </div>
          <div className="flex flex-col items-center">
            <h3 className="text-base font-semibold mb-2 lg:mb-5 text-center">
              Uploaded Documents
            </h3>
            <StatusChip
              color="black"
              label={
                managerAccountVendor?._count.manager_account_vendor_documents.toString() ??
                "0"
              }
              className="w-max font-normal"
            />
          </div>
        </div>
      </section>

      <section className="mt-5 overflow-hidden bg-white rounded-md shadow p-7">
        <div className="flex flex-col lg:flex-row justify-between items-center">
          <h2 className="text-lg lg:text-2xl font-semibold leading-tight">
            Integration Map
          </h2>
          <CanDo permission={Permission.ManageVendors}>
            <div className="flex">
              <Button
                color="transparent"
                className="text-md font-medium"
                to={`/intelligence/${account.id}/vendors/${managerAccountVendor?.id}/integration-map`}
                id="edit-integration-map"
              >
                <RevysePencilIcon className="mr-2" /> Edit
              </Button>
            </div>
          </CanDo>
        </div>
        <hr className="my-5" />
        <div className="grid grid-cols-3 gap-4">
          {sortedVendorIntegrations.map((t, i) => (
            <div
              key={i}
              className="rounded-lg border border-gray-100 p-6 flex mb-2 space-x-4"
              id={`integration-${t.id}`}
            >
              <div className="relative row-span-2 w-max">
                {t.integrated_vendor?.vendor.logo_file_id ||
                t.integrated_product?.logo_file_id ? (
                  <img
                    className="w-12 h-12 lg:w-16 lg:h-16 rounded-lg"
                    src={`/images/${
                      t.integrated_vendor?.vendor.logo_file_id ||
                      t.integrated_product?.logo_file_id
                    }`}
                    width="64"
                    height="64"
                    alt="Vendor Logo"
                  />
                ) : (
                  <img
                    className="w-12 h-12 lg:w-16 lg:h-16 rounded-lg"
                    src="/assets/default-logo.png"
                    alt="Vendor Logo"
                    width="64"
                    height="64"
                  />
                )}
                <VerifiedIcon className="h-5 lg:h-6 absolute top-[-0.5rem] right-[-0.5rem]" />
              </div>
              <div className="flex flex-col justify-start space-y-1">
                <div className="font-medium" id="integration-name">
                  {t.integrated_vendor?.vendor.name ||
                    t.integrated_product?.title}
                </div>
                <StatusChip
                  model="IntelligenceVendorIntegrationStatus"
                  status={t.status}
                  label={t.status ?? IntelligenceVendorIntegrationStatus.Active}
                ></StatusChip>
              </div>
            </div>
          ))}
          {isEmpty(managerAccountVendor.intelligence_vendor_integrations) && (
            <Empty
              onClick={() =>
                navigate(
                  `/intelligence/${account.id}/vendors/${managerAccountVendor?.id}/integration-map`
                )
              }
              showIcon={true}
              label="Nothing here yet"
            />
          )}
        </div>
      </section>
      <section
        ref={incidentManagementSection}
        className="mt-5 overflow-hidden bg-white rounded-md shadow p-7"
      >
        <div className="flex flex-col lg:flex-row justify-between items-center gap-y-3">
          <h2 className="text-lg lg:text-2xl font-semibold leading-tight">
            Incident Management
          </h2>
          <CanDo permission={Permission.ManageVendors}>
            <div className="flex">
              <CTA
                variant="sky"
                fillStyle="outline"
                to={`/intelligence/${account.id}/vendors/${managerAccountVendor?.id}/incident/new`}
                id="log-incident"
              >
                Log Incident
              </CTA>
            </div>
          </CanDo>
        </div>
        <hr className="my-5" />
        <IncidentsTable
          items={managerAccountVendor?.manager_account_vendor_incidents ?? []}
          columnsToShow={[
            "name",
            "status",
            "createdDate",
            "impact",
            "editAction",
          ]}
          onClickRow={incident =>
            navigate(
              `/intelligence/${account.id}/vendors/${managerAccountVendor?.id}/incident/${incident.id}`
            )
          }
        />
      </section>
    </>
  );
}
