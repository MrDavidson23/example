import { CTA } from "~/components/cta.component";
import { useActionData, useFetcher, useLoaderData } from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { useEffect, useState } from "react";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import { Modal } from "~/components/modal.component";
import { CrudTextField } from "~/components/form/crud-form.component";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { castFormFields } from "~/utils/type.utils";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { Toggle } from "~/components/toggle.component";
import { FormWithUploads } from "~/components/form/form-with-uploads.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(relativeTime);

const MB = 1024 * 1024;
const IMG_BYTE_LIMIT = 5 * MB;

const ManagerAccountDataForm = z.object({
  name: z.string().min(1, "Name is required"),
  avatar_id: z
    .string()
    .min(1)
    .nullable()
    .transform(v => (v === "--" ? undefined : v ?? undefined)),
});

export const updateAction = async ({
  id,
  form,
}: {
  id: string;
  form: FormData;
}) => {
  const fields = {
    name: form.get("name"),
    avatar_id: form.get("avatar_id"),
  };

  const validation = ManagerAccountDataForm.safeParse(fields);

  if (validation.success) {
    const { managerAccountService } = await WebDIContainer();
    await managerAccountService.updateManagerAccount(id, validation.data);

    return jsonWithSuccess(
      {
        success: true,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      },
      "Intelligence account updated successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return jsonWithError(
    { success: false, fields: castFormFields(fields), errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
};

const updateAlertsAndNotificationsAction = async ({
  id,
  userId,
  form,
}: {
  id: string;
  userId: string;
  form: FormData;
}) => {
  const fields = {
    daily_notification_email: form.get("daily_notification_email"),
  };

  const validation = z
    .object({
      daily_notification_email: z
        .literal("true")
        .or(z.literal("false"))
        .transform(v => v === "true"),
    })
    .safeParse(fields);

  if (validation.success) {
    const { managerAccountRoleService } = await WebDIContainer();

    const managerAccountRoleId =
      await managerAccountRoleService.getManagerAccountRole({
        manager_account_id: id,
        user_id: userId,
      });

    if (!managerAccountRoleId) {
      throw new Error("Manager account role not found");
    }

    await managerAccountRoleService.updateAlertsAndNotifications(
      managerAccountRoleId?.id,
      validation.data
    );

    return jsonWithSuccess(
      {
        success: true,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      },
      "Intelligence account updated successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return jsonWithError(
    { success: false, fields: castFormFields(fields), errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
};

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewAccountInformation],
    }
  );

  const managerAccountId = account.id;

  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "avatar_id", byteLimit: IMG_BYTE_LIMIT },
  ]);

  const intent = form.get("intent");

  if (intent === "alerts_and_notifications") {
    return updateAlertsAndNotificationsAction({
      id: managerAccountId,
      userId: user.id,
      form,
    });
  }
  return updateAction({ id: managerAccountId, form });
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewAccountInformation],
    }
  );

  const managerAccountId = account.id;

  const { managerAccountService } = await WebDIContainer();
  const managerAccount = await managerAccountService.getManagerAccountDetails(
    managerAccountId
  );

  const managerAccountRole = user.manager_account_roles[0];

  if (!managerAccount) {
    throw new Response("Not found", { status: 404 });
  }
  return json({
    managerAccount,
    managerAccountRole,
    user,
  });
}

export default function AccountDetails() {
  const { managerAccount, user, managerAccountRole } =
    useLoaderData<typeof loader>();
  const [editAccount, setEditAccount] = useState(false);
  const actionData = useActionData<typeof action>();

  const fetcher = useFetcher();

  const [dailyNotificationEmail, setDailyNotificationEmail] = useState(
    managerAccountRole.daily_notification_email
  );

  // Permissions
  const userCanManageAccountInformation = canDoOnAccount(
    user,
    managerAccount,
    Permission.ManageAccountInformation
  );

  useEffect(() => {
    if (actionData?.success) {
      setEditAccount(false);
    }
  }, [actionData]);

  useEffect(() => {
    setDailyNotificationEmail(managerAccountRole.daily_notification_email);
  }, [managerAccountRole.daily_notification_email]);

  const handleDailyNotificationEmailChange = (checked: boolean) => {
    setDailyNotificationEmail(checked);
    fetcher.submit(
      {
        intent: "alerts_and_notifications",
        daily_notification_email: checked,
      },
      {
        action: `/intelligence/${managerAccount.id}/account?index`,
        method: "post",
        encType: "multipart/form-data",
      }
    );
  };

  return (
    <>
      <Modal
        isOpen={editAccount}
        onClose={() => setEditAccount(false)}
        size="medium"
        manager={true}
      >
        <div className="space-y-6">
          <h2 className="text-lg lg:text-3xl font-semibold leading-7 text-gray-900">
            Edit the master company account
          </h2>
          <FormWithUploads>
            <label className="block text-sm font-medium leading-6 text-gray-900">
              Company Logo (optional)
            </label>
            <div className="flex justify-center my-4">
              <label
                htmlFor="avatar_id"
                className="block text-sm font-medium text-gray-700 cursor-pointer"
              >
                <div className="mt-1 relative flex items-center h-min w-min">
                  <div className="relative h-20 w-20 rounded-full overflow-hidden">
                    <img
                      src={`${
                        managerAccount.avatar?.id
                          ? `/images/${managerAccount.avatar.id}`
                          : actionData?.fields?.avatar?.id
                          ? `/images/${actionData.fields.avatar.id}`
                          : "/assets/defaultAvatar.png"
                      }`}
                      alt="Current Profile"
                      className="h-20 w-20 object-cover"
                      width="80"
                      height="80"
                    />
                  </div>
                  <label
                    htmlFor="avatar_id"
                    className="cursor-pointer absolute bottom-0 right-0 bg-sky-500 text-white rounded-full p-1"
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      className="h-6 w-6"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                    >
                      <path
                        stroke-linecap="round"
                        stroke-linejoin="round"
                        stroke-width="2"
                        d="M12 6v6m0 0v6m0-6h6m-6 0H6"
                      />
                    </svg>
                  </label>
                </div>
              </label>
              <input
                type="file"
                id="avatar_id"
                name="avatar_id"
                accept="image/*"
                className="hidden"
              />
            </div>
            <CrudTextField
              field={{
                label: "Company Name *",
                name: "name",
                errors: actionData?.errors.name ?? [],
                defaultValue:
                  actionData?.fields.name ?? managerAccount.name ?? undefined,
                type: "text",
              }}
            />
            <div className="flex items-center justify-end py-4">
              <CTA
                id="save-account-info"
                variant="sky-shadow"
                className="flex"
                type="submit"
              >
                <>Save</>
              </CTA>
            </div>
          </FormWithUploads>
        </div>
      </Modal>
      <IntelligenceScreenHeader
        title="Account Information"
        description="View and edit your account information."
      />
      <div className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min">
        <div className=" divide divide-y divide-2 divide-gray-200 mt-5">
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold text-lg md:text-2xl pb-3">
              Personal Profile Info
            </div>
            <div className="flex justify-start h-min">
              <CTA
                id="edit-personal-info"
                type="submit"
                variant="coral-shadow"
                to="/profile"
              >
                Edit Personal info
              </CTA>
            </div>
          </div>
          <div>
            <div className="grid grid-cols-2 py-4">
              <div className="font-semibold">Name</div>
              <div>
                {user.first_name} {user.last_name}
              </div>
            </div>
            <div className="grid grid-cols-2 py-4">
              <div className="font-semibold">Title</div>
              <div>{user.title}</div>
            </div>
            <div className="grid grid-cols-2 py-4">
              <div className="font-semibold">Email</div>
              <div>{user.email}</div>
            </div>
            <div className="grid grid-cols-2 py-4">
              <div className="font-semibold">Phone</div>
              <div>{user.phone}</div>
            </div>
            <div className=" divide divide-y divide-2 divide-gray-200 mt-6">
              <div className="grid grid-cols-2 py-4">
                <div className="font-bold text-lg md:text-2xl pb-3">
                  Company Account Info
                </div>
                {userCanManageAccountInformation && (
                  <div className="flex justify-start h-min">
                    <CTA
                      id="edit-company-info"
                      type="submit"
                      variant="coral-shadow"
                      onClick={() => setEditAccount(true)}
                    >
                      Edit Company Info
                    </CTA>
                  </div>
                )}
              </div>
              <div className="grid grid-cols-2 py-4">
                <div className="font-semibold">Company Account Name</div>
                <div>{managerAccount.name}</div>
              </div>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-2 py-4"></div>
        <div className=" divide divide-y divide-2 divide-gray-200 mt-6">
          <div className="font-bold text-lg md:text-2xl pb-3">
            Units & Locations
          </div>
          <div>
            <div className="grid grid-cols-2 py-4">
              <div className="font-semibold">
                Total Number of Locations on Revyse
              </div>
              <div>
                {managerAccount?._count.locations
                  ? managerAccount?._count.locations.toLocaleString("en-US")
                  : ""}
              </div>
            </div>
            <div className="grid grid-cols-2 py-4">
              <div className="font-semibold">
                Total Number of Units on Revyse
              </div>
              <div>{managerAccount?.unit_count ?? "--"}</div>
            </div>
          </div>
        </div>
        <div className=" divide divide-y divide-2 divide-gray-200 mt-14">
          <div className="font-bold text-lg md:text-2xl pb-3">
            Alerts & Notifications
          </div>
          <div>
            <div className="grid grid-cols-2 py-4">
              <div className="font-semibold">Notification Emails</div>
              <div>
                <Toggle
                  checked={dailyNotificationEmail}
                  onChange={handleDailyNotificationEmailChange}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
