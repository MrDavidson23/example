import { CTA } from "~/components/cta.component";
import {
  Link,
  useLoaderData,
  useLocation,
  useNavigate,
} from "@remix-run/react";
import type {
  ActionFunctionArgs,
  LinksFunction,
  LoaderFunctionArgs,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import dayjs from "dayjs";
import { TrashIcon } from "@heroicons/react/24/outline";
import { useEffect, useRef, useState } from "react";
import {
  ContractPricingType,
  ContractLineItemLocationStatus,
  ContractLineItemPriceIncreaseCadence,
  LocationStatus,
  ContractLineItemStatus,
  ContractStatus,
} from "@prisma/client";
import utc from "dayjs/plugin/utc";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import {
  ContractLineItemPriceCadenceLabels,
  ContractPricingTypeLabels,
} from "~/utils/constants.utils";
import { redirectWithError, redirectWithSuccess } from "remix-toast";
import { type DropdownItem } from "~/components/dropdown.component";
import { Button } from "~/components/button.component";
import { LocationContractLineItemsTable } from "~/components/intelligence/locations/contract-line-item-location-table.component";
import { LocationContractLineItemEditStatusModal } from "~/components/intelligence/locations/contract-line-item-location-edit-status-modal.component";
import { RevysePencilIcon } from "~/components/revyse-pencil-icon.component";
import { ConfirmDeleteModal } from "~/components/modals/confirm-delete-modal.component";
import StatusChip from "~/components/status-chip.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { ContractLineItemEditStatusModal } from "~/components/intelligence/contracts/contract-line-item-edit-status-modal.component";
import HTMLReactParser from "html-react-parser";
import richtext from "../styles/richtext.css";
import type { ContractLineItemItem } from "~/components/intelligence/contract-line-item/contract-line-item-items-manager.component";
import { ContractLineItemItems } from "~/components/intelligence/contract-line-item/contract-line-item-items.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

dayjs.extend(utc);

interface Product {
  product: {
    id: string;
    title: string;
  };
}
interface Fee {
  fee?:
    | {
        id: string;
        name: string;
      }
    | undefined
    | null;
}
type CombinedItem = Product | Fee;

export const links: LinksFunction = () => {
  return [
    {
      rel: "stylesheet",
      href: richtext,
    },
  ];
};

function isProduct(item: CombinedItem): item is Product {
  return (item as Product).product !== undefined;
}

async function deleteAction({
  id,
  contractId,
  account_id,
}: {
  id: string;
  contractId: string;
  account_id: string;
}) {
  const { contractLineItemService } = await WebDIContainer();
  const response = await contractLineItemService.deleteContractLineItem(id);
  if (response.success) {
    return redirectWithSuccess(
      `/intelligence/${account_id}/contract/${contractId}/line-item/`,
      "Line item deleted successfully"
    );
  } else {
    return redirectWithError(
      `/intelligence/${account_id}/contract/${contractId}/line-item/`,
      "Cannot discard the line item"
    );
  }
}

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContractLineItem],
    }
  );

  const id = params.contract_line_item_id!;
  const contractId = params.contract_id!;

  const form = await request.formData();
  const intent = form.get("intent");
  if (intent === "delete") {
    return deleteAction({ id, contractId, account_id: account.id });
  }
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewContractLineItem],
    }
  );
  const { contractLineItemService, contractService, locationService } =
    await WebDIContainer();
  const contractId = params.contract_id!;
  const contract = await contractService.getContractById(contractId);

  const url = new URL(request.url);
  const id = params.contract_line_item_id;

  const search = new URLSearchParams(url.search);
  const searchTerm = search.get("query");
  const contractLineItem = await contractLineItemService.loadContractLineItem(
    id
  );

  const contractLocation = contract.location_id
    ? await locationService.getLocation(contract.location_id)
    : null;

  if (!contractLineItem) {
    throw new Response("Not found", { status: 404 });
  }

  return json({
    user,
    account,
    contract,
    contractLineItem,
    url,
    searchTerm,
    contractLocation,
  });
}
export default function ContractLineItemSummary() {
  const navigate = useNavigate();
  const { contractLineItem, contract, user, account, contractLocation } =
    useLoaderData<typeof loader>();
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [changeContractLineItemStatus, setChangeContractLineItemStatus] =
    useState(false);

  const [
    contractLineItemLocationToEditModal,
    setContractLineItemLocationToEditModal,
  ] = useState<
    (typeof contractLineItem)["contract_line_item_locations"][number] | null
  >(null);

  // Permissions
  const userCanManageContractLineItem = canDoOnAccount(
    user,
    account,
    Permission.ManageContractLineItem
  );
  const userCanManageContractLineItemLocations = canDoOnAccount(
    user,
    account,
    Permission.ManageContractLineItemLocations
  );
  const userCanViewLocationDetails = canDoOnAccount(
    user,
    account,
    Permission.ViewLocationDetails
  );

  const dropdownItems: DropdownItem[] = [
    {
      to: `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/set-price`,
      label: "Edit Pricing",
      icon: "",
      id: "edit-pricing-button",
    },
    {
      to: `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/`,
      label: "Edit Products & Fees",
      icon: "",
      id: "edit-products-and-fees-button",
    },
    {
      onClick: () => {
        setChangeContractLineItemStatus(!changeContractLineItemStatus);
      },
      label:
        contractLineItem.status !== ContractLineItemStatus.Canceled
          ? "Cancel Line Item"
          : "Activate Line Item",
      id: "editLineItemStatus",
    },
    {
      onClick: () => {
        setConfirmDeleteOpen(!confirmDeleteOpen);
      },
      label: "Delete Line Item",
      icon: TrashIcon,
      id: "deleteLineItem",
    },
  ];

  const location = useLocation();

  useEffect(() => {
    if (location.hash === "#locations") {
      scrollToAssignedLocationsSection();
    }
  }, [location.hash]);

  const scrollToAssignedLocationsSection = () => {
    locationsSection.current?.scrollIntoView({
      behavior: "smooth",
      block: "center",
    });
  };

  const locationsSection = useRef<HTMLDivElement>(null);

  if (
    userCanManageContractLineItemLocations &&
    contractLineItem.status !== ContractLineItemStatus.Canceled
  ) {
    dropdownItems.unshift(
      {
        to: `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/assign-locations`,
        label: "Assign Locations",
        icon: "",
        id: "assign-locations-button",
      },
      {
        onClick: scrollToAssignedLocationsSection,
        label: "Cancel Locations",
        id: "cancel-locations",
      }
    );
  }

  const displayedStatus =
    contract.status === ContractStatus.Canceled
      ? ContractLineItemStatus.Canceled
      : contractLineItem.status;

  return (
    <>
      {changeContractLineItemStatus && (
        <ContractLineItemEditStatusModal
          contractLineItem={contractLineItem}
          isOpen={!!changeContractLineItemStatus}
          onClose={() => {
            setChangeContractLineItemStatus(false);
          }}
          accountId={account.id}
        />
      )}
      {confirmDeleteOpen && (
        <ConfirmDeleteModal
          isOpen={confirmDeleteOpen}
          onClose={() => setConfirmDeleteOpen(false)}
          onConfirm={() => setConfirmDeleteOpen(false)}
          title="Delete this line item and its corresponding data"
          message="Are you sure you want to delete this line item and all associated pricing and location assignments?"
          submitOnConfirm={true}
        />
      )}
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All contracts",
            to: `/intelligence/${account.id}/contracts`,
          },
          {
            name: contract.name,
            to: `/intelligence/${account.id}/contract/${contract.id}/details`,
          },
          {
            name: "Products and line items",
            to: `/intelligence/${account.id}/contract/${contract.id}/line-item`,
          },
          {
            name: contractLineItem.name
              ? contractLineItem.name
              : "New line item",
            to: `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/summary`,
            active: true,
          },
        ]}
        chip={
          <StatusChip
            model="ContractLineItemStatus"
            status={displayedStatus}
            label={displayedStatus}
          />
        }
        title={
          <>
            Line item summary:
            <br /> {contractLineItem.name}
          </>
        }
        description="View and edit the details of this line item, including the
          products or fees selected, pricing configurations, and location
          assignments."
        ellipsisItems={
          userCanManageContractLineItem ? dropdownItems : undefined
        }
      />
      <div className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min space-y-5">
        <div className="flex justify-between items-center gap-x-2">
          <div className="font-bold text-lg lg:text-xl leading-tight">
            Product & Fee Configuration
          </div>
          {userCanManageContractLineItem && (
            <Button
              color="transparent"
              className="gap-x-2 py-0 px-0"
              id="edit-products-and-fees"
              to={`/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/`}
            >
              <RevysePencilIcon className="h-6 w-6" />
              Edit
            </Button>
          )}
        </div>

        <div className="divide divide-y divide-2 divide-gray-200">
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">Contract Name</div>
            <div>{contractLineItem.contract.name}</div>
          </div>
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">Contract Status</div>
            <div>{contractLineItem.contract.status}</div>
          </div>
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">Vendor Name</div>
            <div>
              <Link
                id="vendor-link"
                to={`/intelligence/${account.id}/vendors/${contract.manager_account_vendor.id}`}
                className="text-sky-600"
              >
                {contractLineItem.contract.manager_account_vendor.vendor.name}
              </Link>
            </div>
          </div>
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">Selected Products & Fees</div>
            <div>
              {[
                ...contractLineItem.contract_line_item_products,
                ...contractLineItem.contract_line_item_fees,
              ].map((item, index, array) => (
                <span key={item.id}>
                  {isProduct(item) ? item.product.title : item.fee?.name}
                  {index < array.length - 1 && ", "}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min space-y-5">
        <div className="flex justify-between items-center gap-x-2">
          <div className="font-bold text-lg lg:text-xl leading-tight">
            Pricing Configuration
          </div>
          {userCanManageContractLineItem && (
            <Button
              color="transparent"
              className="gap-x-2 px-0 py-0"
              to={`/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/set-price`}
              id="primary-edit-pricing-button"
            >
              <RevysePencilIcon className="h-6 w-6" />
              Edit
            </Button>
          )}
        </div>
        <div className=" divide divide-y divide-2 divide-gray-200">
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">Pricing Cadence</div>
            <div>
              {contractLineItem.cadence
                ? ContractLineItemPriceCadenceLabels[contractLineItem.cadence]
                : "--"}
            </div>
          </div>
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">Pricing Type</div>
            <div>
              {contractLineItem.pricing_type
                ? ContractPricingTypeLabels[contractLineItem.pricing_type]
                : ""}
              <b>
                {contractLineItem.pricing_type == ContractPricingType.PerSeat &&
                  ` (${contractLineItem.seats_number})`}
              </b>
            </div>
          </div>
          <div className="grid lg:grid-cols-2 py-4 overflow-x-scroll">
            <div className="font-bold">Price</div>
            {contractLineItem.contract_line_item_products.length +
              contractLineItem.contract_line_item_fees.length >
            1 ? (
              <div>
                <div className="grid grid-cols-4 items-center my-3 gap-2 md:gap-4 text-sm md:text-md">
                  <div className="font-semibold mr-12 col-span-2">
                    Product or Fee
                  </div>
                  <div className="font-semibold">Price</div>
                  <div className="flex items-center space-x-2">
                    <div className="font-semibold">Department</div>
                  </div>
                  {contractLineItem.contract_line_item_products.map(
                    (product, j) => (
                      <>
                        <div className="col-span-2 [text-wrap:pretty]">
                          {product?.product.title}
                        </div>
                        <div>
                          {product?.price.toLocaleString(undefined, {
                            style: "currency",
                            currency: "USD",
                          })}
                        </div>

                        <div>{product?.department}</div>
                      </>
                    )
                  )}
                  {contractLineItem.contract_line_item_fees.map((fee, j) => (
                    <>
                      <div className="col-span-2 [text-wrap:pretty]">
                        {fee?.fee?.name}
                      </div>
                      <div>
                        {fee?.price.toLocaleString(undefined, {
                          style: "currency",
                          currency: "USD",
                        })}
                      </div>
                      <div>{fee?.department}</div>
                    </>
                  ))}
                </div>
                <div className="my-3">
                  Total:{" "}
                  <b>
                    {contractLineItem.price.toLocaleString(undefined, {
                      style: "currency",
                      currency: "USD",
                    })}
                  </b>
                </div>
              </div>
            ) : contractLineItem.pricing_type ===
              ContractPricingType.Itemized ? (
              <ContractLineItemItems
                items={
                  contractLineItem.contract_line_item_items as ContractLineItemItem[]
                }
              />
            ) : (
              <div>
                {contractLineItem.price.toLocaleString(undefined, {
                  style: "currency",
                  currency: "USD",
                })}
              </div>
            )}
          </div>
          {contractLineItem.pricing_type === ContractPricingType.UsageBased && (
            <div className="grid grid-cols-2 py-4">
              <div className="font-bold">
                Estimated Total {contractLineItem.cadence} Cost
              </div>
              <div>
                {contractLineItem.estimated_cost &&
                  contractLineItem.estimated_cost.toLocaleString(undefined, {
                    style: "currency",
                    currency: "USD",
                  })}
              </div>
            </div>
          )}
          {contractLineItem.pricing_type === ContractPricingType.PerLease && (
            <div className="grid grid-cols-2 py-4">
              <div className="font-bold">
                Estimated Total {contractLineItem.cadence} Cost Per Location
              </div>
              <div>
                {contractLineItem.estimated_cost &&
                  contractLineItem.estimated_cost.toLocaleString(undefined, {
                    style: "currency",
                    currency: "USD",
                  })}
              </div>
            </div>
          )}
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">One-Time Set Up Fees</div>
            <div>
              {contractLineItem.setup_fee
                ? `${contractLineItem.setup_fee.toLocaleString(undefined, {
                    style: "currency",
                    currency: "USD",
                  })}`
                : "--"}
            </div>
          </div>
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">Discount Value</div>
            <div>
              {contractLineItem.discount
                ? `${contractLineItem.discount.toLocaleString(undefined, {
                    style: "currency",
                    currency: "USD",
                  })}`
                : "--"}
            </div>
          </div>
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">
              Contracted Price Increase Percentage
            </div>
            <div>
              {contractLineItem.price_increase_percent
                ? `${contractLineItem.price_increase_percent}%`
                : "--"}
            </div>
          </div>
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">Contracted Price Increase Cadence</div>
            <div>
              {" "}
              {(() => {
                switch (contractLineItem.price_increase_cadence) {
                  case ContractLineItemPriceIncreaseCadence.IncreaseAtRenewal:
                    return "Increase At Renewal";
                  case ContractLineItemPriceIncreaseCadence.AnnualIncrease:
                    return "Annual Increase";
                  default:
                    return "--";
                }
              })()}
            </div>
          </div>
          {contractLineItem.contract_line_item_products.length +
            contractLineItem.contract_line_item_fees.length ===
            1 && (
            <div className="grid grid-cols-2 py-4">
              <div className="font-bold">Department</div>
              <div>
                {contractLineItem.contract_line_item_products[0]?.department ||
                  contractLineItem.contract_line_item_fees[0]?.department ||
                  ""}
              </div>
            </div>
          )}
          {!contractLocation && (
            <div className="grid grid-cols-2 py-4">
              <div className="font-bold">Corporate-Only</div>
              <div>{contractLineItem.is_corporate_only ? "Yes" : "No"}</div>
            </div>
          )}
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">Notes</div>
            <div className="richtext">
              {HTMLReactParser(contractLineItem.notes ?? "--")}
            </div>
          </div>
        </div>
      </div>
      <div className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min space-y-5">
        <div className="flex justify-between items-center gap-x-2">
          <h2
            className="font-bold text-lg lg:text-xl leading-tight"
            ref={locationsSection}
          >
            Assigned Locations
          </h2>
          {userCanManageContractLineItemLocations &&
            !contractLocation &&
            contractLineItem.status !== ContractLineItemStatus.Canceled && (
              <CTA
                id="assign-locations"
                to={`/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/assign-locations`}
              >
                Assign Locations
              </CTA>
            )}
        </div>
        <div>
          {contractLocation ? (
            <>
              This contract is specific to{" "}
              <b className="font-semibold">{contractLocation.name}</b>, and no
              additional locations can be assigned.
            </>
          ) : (
            <>
              To assign locations to this line item, click “Assign Locations.”
              To mark a line item as canceled at the location level, click on
              the edit icon in the corresponding row and set the assignment
              status to canceled.
            </>
          )}
        </div>
        <div className=" divide divide-y divide-2 divide-gray-200">
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">Active Locations Assigned</div>
            <div>
              {contractLineItem.is_corporate_only &&
              contractLineItem._count.contract_line_item_locations === 0
                ? "Corporate"
                : contractLineItem.contract_line_item_locations.filter(
                    contractLineItemLocation =>
                      contractLineItemLocation.status !==
                        ContractLineItemLocationStatus.Canceled &&
                      contractLineItemLocation.location.status !==
                        LocationStatus.Disposed
                  ).length}
            </div>
          </div>
          <div className="grid grid-cols-2 py-4">
            <div className="font-bold">Active Units Assigned</div>
            <div>
              {contractLineItem.is_corporate_only &&
              contractLineItem._count.contract_line_item_locations === 0
                ? "Corporate"
                : contractLineItem.contract_line_item_locations
                    .filter(
                      contractLineItemLocation =>
                        contractLineItemLocation.status !==
                        ContractLineItemLocationStatus.Canceled
                    )
                    .reduce((sum, location) => {
                      const result = sum + (location.location.unit_count || 0);
                      return result;
                    }, 0)
                    .toLocaleString()}
            </div>
          </div>
        </div>
        <div>
          {contractLineItemLocationToEditModal && (
            <LocationContractLineItemEditStatusModal
              contractLineItemLocation={{
                ...contractLineItemLocationToEditModal,
                contract_line_item: contractLineItem,
              }}
              isOpen={!!contractLineItemLocationToEditModal}
              onClose={() => {
                setContractLineItemLocationToEditModal(null);
              }}
              location={contractLineItemLocationToEditModal.location}
            />
          )}
          <LocationContractLineItemsTable
            items={contractLineItem.contract_line_item_locations.map(
              contractLineItemLocation => ({
                ...contractLineItemLocation,
                contract_line_item: contractLineItem,
              })
            )}
            columnsToShow={[
              "locationName",
              "locationAddress",
              "locationUnitCount",
              "locationPropertyType",
              "currentTermEnds",
              "contractLineItemStatus",
            ]}
            onClickRow={contractLineItemLocation =>
              userCanViewLocationDetails &&
              navigate(
                `/intelligence/${account.id}/locations/${contractLineItemLocation.location.id}/details`
              )
            }
            onClickEdit={
              userCanManageContractLineItemLocations && !contractLocation
                ? id =>
                    setContractLineItemLocationToEditModal(
                      contractLineItem.contract_line_item_locations.find(
                        contractLineItemLocation =>
                          contractLineItemLocation.id === id
                      ) ?? null
                    )
                : undefined
            }
          />
        </div>
      </div>
    </>
  );
}
