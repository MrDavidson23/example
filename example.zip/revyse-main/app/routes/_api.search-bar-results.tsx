import { json, type LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const searchTerm = search.get("query");
  const { autocompleteSearchBarService } = await WebDIContainer();

  const products = searchTerm
    ? await autocompleteSearchBarService.getProductsBySearchTerm(searchTerm)
    : [];

  const vendors = searchTerm
    ? await autocompleteSearchBarService.getVendorsBySearchTerm(searchTerm)
    : [];

  const categories = searchTerm
    ? await autocompleteSearchBarService.getCategoriesBySearchTerm(searchTerm)
    : [];

  return json({
    categories,
    products,
    vendors,
  });
}
