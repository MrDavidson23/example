import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import type { LoaderFunctionArgs } from "@remix-run/node";

export async function loader({ params }: LoaderFunctionArgs) {
  const { db } = await WebDIContainer();
  const validation = z.string().uuid().safeParse(params.id);

  if (!validation.success) {
    return new Response("Not found", {
      status: 404,
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  const file = await db.file.findFirst({
    where: { id: params.id },
  });

  if (!file || !params.id) {
    return new Response("Not found", {
      status: 404,
      headers: {
        "Content-Type": "application/json",
      },
    });
  }

  const { s3Service } = await WebDIContainer();
  const fileKey = file.uri;
  const expirationInSeconds = 60 * 60;

  try {
    const signedUrl = await s3Service.getFileSignedUrl(
      fileKey,
      expirationInSeconds
    );
    return new Response(signedUrl, {
      status: 200,
      headers: {
        "Content-Type": "application/json",
      },
    });
  } catch (err) {
    console.error(err);
    return new Response("Error getting the requested file", {
      status: 500,
      headers: {
        "Content-Type": "application/json",
      },
    });
  }
}
