import { json } from "@remix-run/node";
import {
  Form,
  Link,
  useActionData,
  useFetcher,
  useLoaderData,
  useNavigate,
  useNavigation,
  useOutletContext,
} from "@remix-run/react";
import type {
  ActionFunctionArgs,
  LinksFunction,
  LoaderFunctionArgs,
} from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { every, isEmpty } from "lodash";
import { CTA } from "~/components/cta.component";
import StatusChip from "~/components/status-chip.component";
import { useEffect, useMemo, useState } from "react";
import { VendorPreferredIcon } from "~/components/intelligence/vendors/preferred-icon.component";
import StarRating from "~/components/star-rating.component";
import { Button, DangerButton } from "~/components/button.component";
import { RevysePencilIcon } from "~/components/revyse-pencil-icon.component";
import {
  ArrowLeftIcon,
  ArrowPathRoundedSquareIcon,
  ArrowTrendingUpIcon,
  BriefcaseIcon,
  BuildingOfficeIcon,
  ChatBubbleOvalLeftEllipsisIcon,
  ClockIcon,
  ExclamationCircleIcon,
  ShoppingBagIcon,
} from "@heroicons/react/24/outline";
import { Tooltip } from "~/components/tooltip.component";
import {
  ContractStatus,
  ManagerAccountRoleType,
  ManagerAccountVendorContactType,
  TaskCompletionStatus,
} from "@prisma/client";
import ManagerAccountVendorContactCard from "~/components/intelligence/vendors/manager-account-vendor-contact-card.component";
import ProductTile from "~/components/product-tile.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { Modal } from "~/components/modal.component";
import {
  CrudDateField,
  CrudSelectField,
} from "~/components/form/crud-form.component";
import { z } from "zod";
import { jsonWithSuccess, redirectWithSuccess } from "remix-toast";
import { issuesByKey } from "~/utils/form.utils.server";
import { TaskScheduleStatusLabels } from "~/utils/constants.utils";
import { castFormFields } from "~/utils/type.utils";
import { ChatBubble } from "~/components/intelligence/tasks/chat-bubble.component";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import { ContractRenewalWizard } from "~/components/intelligence/tasks/contract-renewal-wizard.component";
import stylesheetQuill from "react-quill/dist/quill.snow.css";
import stylesheetEmoji from "quill-emoji/dist/quill-emoji.css";
import stylesheetQuillMention from "quill-mention/dist/quill.mention.css";
import chatStyle from "../styles/chat.css";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

dayjs.extend(utc);

const MB = 1024 * 1024;
const MAX_BYTE_LIMIT = 60 * MB;

type JsonData = {
  fields?: Record<string, string | null> | null;
  success?: boolean;
  errors?: Record<string, string[] | null>;
};

export const links: LinksFunction = () => [
  { rel: "stylesheet", href: chatStyle },
  { rel: "stylesheet", href: stylesheetQuill },
  { rel: "stylesheet", href: stylesheetEmoji },
  { rel: "stylesheet", href: stylesheetQuillMention },
];

const LocationDataForm = z.object({
  due_date: z.date().nullable(),
  task_owner_id: z
    .string()
    .uuid()
    .or(z.literal("null").transform(v => (v === "null" ? null : v))),
});

async function archiveTask({
  id,
  accountId,
}: {
  id: string;
  accountId: string;
}) {
  const { managerAccountTaskService } = await WebDIContainer();

  await managerAccountTaskService.archiveContractRenewalTask(id);

  return redirectWithSuccess(
    `/intelligence/${accountId}/tasks/contract-renewal/${id}`,
    "Task archived successfully"
  );
}

async function activateTask({
  id,
  accountId,
}: {
  id: string;
  accountId: string;
}) {
  const { managerAccountTaskService } = await WebDIContainer();

  await managerAccountTaskService.activateContractRenewalTask(id);

  return redirectWithSuccess(
    `/intelligence/${accountId}/tasks/contract-renewal/${id}`,
    "Task reactivated successfully"
  );
}

async function updateAction({ id, form }: { id: string; form: FormData }) {
  const dueDate = form.get("due_date") as string;

  const fields = {
    due_date: dueDate ? new Date(dueDate) : null,
    task_owner_id: form.get("task_owner_id"),
  };

  const validation = LocationDataForm.safeParse(fields);

  if (validation.success) {
    const { managerAccountTaskService } = await WebDIContainer();

    await managerAccountTaskService.updateContractRenewalTask(
      id,
      validation.data.due_date,
      validation.data.task_owner_id
    );
    return jsonWithSuccess<JsonData>(
      {
        success: true,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      },
      "Task updated successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return json<JsonData>(
    { success: false, fields: castFormFields(fields), errors },
    { status: 400 }
  );
}

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageTasks],
    }
  );
  const managerAccountId = account.id;

  const task_id = params.task_id!;

  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "message_files.file", byteLimit: MAX_BYTE_LIMIT },
  ]);
  const intent = form.get("intent");

  if (task_id && intent === "cancelTask") {
    return archiveTask({ id: task_id, accountId: managerAccountId });
  }
  if (task_id && intent === "activateTask") {
    return activateTask({ id: task_id, accountId: managerAccountId });
  }
  return updateAction({ id: task_id, form });
};

async function getManagerAccountRolesWithPermissions(
  managerAccountId: string,
  permissionLevels: ManagerAccountRoleType[]
) {
  const { managerAccountRoleService } = await WebDIContainer();
  const taskOwners = await managerAccountRoleService.getManagerAccountRoles(
    managerAccountId,
    {
      permissionLevel: permissionLevels,
      page: 1,
      perPage: 500,
      status: [],
    }
  );
  return taskOwners;
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewTaskDetails],
    }
  );
  const managerAccountId = account.id;

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const chatParam = Boolean(search.get("chat"));

  const {
    managerAccountService,
    managerAccountRoleService,
    managerAccountVendorService,
    managerAccountTaskService,
    productService,
  } = await WebDIContainer();

  const task = await managerAccountTaskService.loadContractRenewalTask(
    params.task_id
  );

  if (!task) {
    throw new Response("Not found", { status: 404 });
  }

  // Check if the user has permission to view sensitive contract
  if (
    task.contract.is_sensitive &&
    !canDoOnAccount(user, account, Permission.ViewSensitiveContracts)
  ) {
    throw new Response("Not found", { status: 404 });
  }

  const contractAnnualValue =
    await managerAccountService.getContractAnnualAssignedValue(
      task.contract.id
    );

  const allCategoryIds = task.contract.contract_line_items.flatMap(
    lineItem =>
      [
        ...lineItem.contract_line_item_products
          .map(product => product.product.primary_category?.id)
          .filter(Boolean),
        ...lineItem.contract_line_item_fees
          .map(fee => fee.fee?.category?.id)
          .filter(Boolean),
      ] as string[]
  );

  const sender = await managerAccountRoleService.getManagerAccountRole({
    manager_account_id: managerAccountId,
    user_id: user.id,
  });
  if (!sender) {
    throw new Response("Not manager account role found", { status: 404 });
  }

  const messages = await managerAccountTaskService.getGroupChatMessages(
    task.group_chat_id
  );

  const alternativeProducts = await productService.getProductsMostLoved({
    take: 4,
    categories: allCategoryIds,
  });

  const vendorRating = await managerAccountVendorService.getVendorRating(
    task.contract.manager_account_vendor?.vendor.id || ""
  );

  const taskOwnerOptions = (
    await getManagerAccountRolesWithPermissions(managerAccountId, [
      ManagerAccountRoleType.Owner,
      ManagerAccountRoleType.Editor,
    ])
  ).map(role => ({
    label: `${role.user.first_name} ${role.user.last_name} - ${role.user.email}`,
    value: role.id,
  }));

  const userMentionOptions = (
    await getManagerAccountRolesWithPermissions(
      managerAccountId,
      task.contract.is_sensitive
        ? [ManagerAccountRoleType.Owner]
        : [
            ManagerAccountRoleType.Owner,
            ManagerAccountRoleType.Editor,
            ManagerAccountRoleType.Viewer,
          ]
    )
  ).map(role => ({
    value: `${role.user.first_name} ${role.user.last_name}`,
    id: role.id,
  }));

  return json({
    user,
    account,
    task,
    vendorRating,
    contractAnnualValue,
    alternativeProducts,
    messages,
    taskOwnerOptions,
    userMentionOptions,
    senderId: sender.id,
    chatParam,
  });
}

export default function IntelligenceTaskInfo() {
  const {
    task,
    account,
    user,
    vendorRating,
    contractAnnualValue,
    alternativeProducts,
    messages,
    taskOwnerOptions,
    userMentionOptions,
    senderId,
    chatParam,
  } = useLoaderData<typeof loader>();

  const actionData = useActionData<typeof action>();
  const fetcher = useFetcher<typeof action>();

  const navigate = useNavigate();
  const navigation = useNavigation();

  const baseUrl = `/intelligence/${account.id}/tasks/contract-renewal/${task.id}`;
  const actionUrl = `/chat-action/${senderId}`;

  const [editTask, setEditTask] = useState(false);
  const [openChat, setOpenChat] = useState(false);

  const [confirmCancelContractRenewal, setConfirmCancelContractRenewal] =
    useState(false);

  const [wizardOpen, setWizardOpen] = useState(false);

  const { toggleCollapse, isCollapsed } = useOutletContext() as {
    toggleCollapse: () => void;
    isCollapsed: boolean;
  };

  // Permissions
  const userCanManageContract = canDoOnAccount(
    user,
    account,
    Permission.ManageContracts
  );

  const userCanManageTasks = canDoOnAccount(
    user,
    account,
    Permission.ManageTasks
  );

  const userCanManageVendors = canDoOnAccount(
    user,
    account,
    Permission.ManageVendors
  );

  const userCanViewContractDetails = canDoOnAccount(
    user,
    account,
    Permission.ViewContractDetails
  );

  const userCanSendTaskChatMessage = canDoOnAccount(
    user,
    account,
    Permission.SendTaskChatMessage
  );

  const logoSrc = useMemo(() => {
    return task.contract.manager_account_vendor?.vendor.logo_file_id
      ? `/images/${task.contract.manager_account_vendor?.vendor.logo_file_id}`
      : "/assets/default-logo.png";
  }, [task.contract.manager_account_vendor?.vendor.logo_file_id]);

  const filteredContractsLineItems = task.contract.contract_line_items.filter(
    contractLineItem =>
      contractLineItem.price_increase_percent &&
      contractLineItem.price_increase_percent > 0
  );

  const contractedLocations = () => {
    const allCorporateOnly =
      task.contract.contract_line_items.length > 0 &&
      every(task.contract.contract_line_items, "is_corporate_only");
    if (allCorporateOnly) {
      return <div className="font-normal">Corporate</div>;
    }

    if (
      task.contract.status === ContractStatus.Pending ||
      task.contract.status === ContractStatus.Canceled
    ) {
      return "--";
    }

    let totalCount = new Set(
      task.contract.contract_line_items
        .flatMap(
          contractLineItem => contractLineItem?.contract_line_item_locations
        )
        .filter(location => location !== null && location !== undefined)
        .map(location => location.location_id)
    ).size;
    return <div>{totalCount}</div>;
  };

  const handleSendMessage = async (formData: FormData) => {
    formData.append("intent", "sendMessage");
    formData.append("group_chat_id", `${task.group_chat_id}`);

    await fetcher.submit(formData, {
      action: actionUrl,
      method: "post",
      encType: "multipart/form-data",
    });
  };

  useEffect(() => {
    if (navigation.state == "idle") {
      setEditTask(false);
    }
  }, [navigation.state]);

  useEffect(() => {
    if (chatParam) {
      if (!isCollapsed) toggleCollapse();
      setOpenChat(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const renderPrimaryCTA = () => {
    if (
      userCanViewContractDetails &&
      (task.completion_status === TaskCompletionStatus.Completed ||
        task.completion_status === TaskCompletionStatus.Canceled)
    ) {
      return (
        <CTA
          id="view-contract-details"
          variant="sky-shadow"
          to={`/intelligence/${account.id}/contract/${task.contract_id}/details`}
        >
          View Contract Details
        </CTA>
      );
    } else if (userCanManageTasks && userCanManageContract) {
      return (
        <CTA
          id="complete-task"
          type="submit"
          variant="coral-shadow"
          onClick={() => setWizardOpen(true)}
        >
          Complete Task
        </CTA>
      );
    }

    return <></>;
  };

  const renderCancelReactivateButton = () => {
    const isCanceled = task.completion_status === "Canceled";

    const buttonText = isCanceled ? "Activate Task" : "Cancel Task";
    const confirmVerbiage = isCanceled
      ? "Are you sure you want to reactivate this task?"
      : "Are you sure you want to archive this task and mark it as “Canceled”?";
    const intent = isCanceled ? "activateTask" : "cancelTask";

    if (confirmCancelContractRenewal) {
      return (
        <div className="flex justify-between items-center">
          {confirmVerbiage}
          <Button
            color="transparent"
            onClick={() => setConfirmCancelContractRenewal(false)}
            className="ml-2 rounded-full"
          >
            <ArrowLeftIcon className="h-5 mr-2" /> No, go back
          </Button>
          <DangerButton
            type="submit"
            className="ml-2 rounded-full bg-coral"
            onClick={() => {
              fetcher.submit(
                {
                  intent,
                },
                {
                  action: baseUrl,
                  method: "post",
                  encType: "multipart/form-data",
                }
              );
              setEditTask(false);
              setConfirmCancelContractRenewal(false);
            }}
          >
            Yep!
          </DangerButton>
        </div>
      );
    }
    return (
      <div>
        <CTA
          type="button"
          fillStyle="outline"
          onClick={() => {
            setConfirmCancelContractRenewal(!confirmCancelContractRenewal);
          }}
        >
          {buttonText}
        </CTA>
      </div>
    );
  };

  return (
    <>
      {wizardOpen && (
        <ContractRenewalWizard
          isOpen={wizardOpen}
          onClose={() => setWizardOpen(false)}
          task={task}
          taskOwnerOptions={taskOwnerOptions}
        />
      )}
      <div
        className={`${
          openChat ? "grid grid-cols-3 gap-x-8" : "space-y-8 pb-12"
        }`}
      >
        {userCanManageTasks && (
          <Modal
            isOpen={editTask}
            onClose={() => setEditTask(false)}
            size="medium"
            manager={true}
          >
            <div className="p-3 space-y-5">
              <h1 className="text-2xl">Edit task details</h1>
              <div>
                Update the details of this{" "}
                {task.contract.manager_account_vendor.vendor.name} contract
                renewal task.
              </div>
              <Form method="post" encType="multipart/form-data">
                <CrudDateField
                  field={{
                    name: "due_date",
                    label: "Task Due Date",
                    type: "text",
                    errors: [],
                    defaultValue:
                      dayjs.utc(task.due_date as string).format("YYYY-MM-DD") ??
                      dayjs
                        .utc(actionData?.fields?.due_date as string)
                        .format("YYYY-MM-DD") ??
                      dayjs.utc().format("YYYY-MM-DD"),
                  }}
                  minDate={new Date().toISOString().split("T")[0]}
                />
                <CrudSelectField
                  field={{
                    name: "task_owner_id",
                    type: "select",
                    options: taskOwnerOptions,
                    errors: actionData?.errors?.task_owner_id ?? [],
                    label: "Task Owner",
                    defaultValue: task.task_owner_id
                      ? task.task_owner_id
                      : task.contract.task_owner_id
                      ? task.contract.task_owner_id
                      : actionData?.fields?.task_owner_id ?? undefined,
                  }}
                />
                <div className="space-x-4 flex justify-end py-3">
                  {renderCancelReactivateButton()}
                  {!confirmCancelContractRenewal && (
                    <div>
                      <CTA type="submit">
                        <>
                          {navigation.state === "submitting"
                            ? "Submitting..."
                            : "Save Task"}
                        </>
                      </CTA>
                    </div>
                  )}
                </div>
              </Form>
            </div>
          </Modal>
        )}
        <div className={`${openChat ? "col-span-2" : "flex flex-col"}`}>
          <IntelligenceScreenHeader
            crumbs={[
              {
                name: "Tasks",
                to: `/intelligence/${account.id}/tasks`,
                active: false,
              },
              {
                name: `Contract renewal: ${task.contract.name}` || "",
                to: `/intelligence/${account.id}/tasks/contract-renewal/${task.id}`,
                active: true,
              },
            ]}
            chip={
              <StatusChip
                model="TaskCompletionStatus"
                status={task.completion_status}
                label={task.completion_status}
                suffix="Task"
              />
            }
            title={
              <>
                Contract renewal:
                <br />
                {task.contract.name}
              </>
            }
            description="View the details of your upcoming contract renewal, including due
						date, task owner, and status. Once your contract has renewed,
						click “Complete Task” to update your contract info and mark this
						task as done."
            buttonsSlot={
              <div className="flex lg:justify-end lg:my-0 my-4 justify-center items-center space-x-3">
                {renderPrimaryCTA()}
                <Button
                  className="col-span-1 flex justify-end"
                  color="transparent"
                  onClick={e => {
                    e.preventDefault();
                    e.stopPropagation();
                    setOpenChat(!openChat);
                    toggleCollapse();
                  }}
                >
                  <div className="relative">
                    <ChatBubbleOvalLeftEllipsisIcon className="w-8 h-8" />
                    {!isEmpty(messages) && (
                      <div className="absolute top-0.5 right-0.5 w-2.5 h-2.5 rounded-full bg-yellow-400 border border-white"></div>
                    )}
                  </div>
                </Button>
              </div>
            }
          />
          <section className="mt-5 overflow-hidden bg-white rounded-md shadow">
            <div className="grid grid-cols-1 p-7 lg:grid-cols-2 space-y-5 lg:space-y-0">
              <div className="grid justify-start lg:grid-cols-3 gap-x-7 items-center">
                <div className="relative flex justify-center col-span-1 max-w-24 lg:max-w-[unset]">
                  <img
                    src={logoSrc}
                    alt="Vendor Logo"
                    className="w-24 lg:w-48 h-auto rounded-md aspect-square"
                    width="192"
                    height="192"
                  />
                  {task.contract.manager_account_vendor?.is_preferred && (
                    <div className="h-7 lg:h-12 absolute top-[-1rem] right-[-1rem]">
                      <VendorPreferredIcon
                        vendorName={
                          task.contract.manager_account_vendor?.vendor.name ||
                          ""
                        }
                        position="right"
                        className="h-full w-7 lg:w-12"
                      />
                    </div>
                  )}
                </div>
                <div className="max-w-md col-span-2 space-y-4">
                  <h1
                    className="mt-2 lg:mt-0 text-xl xl:text-3xl font-bold"
                    id="vendor-name"
                  >
                    {task.contract.name}
                  </h1>
                  <div>
                    <div className="text-lg font-light" id="vendor-name">
                      {task.contract.manager_account_vendor?.vendor.name}
                    </div>
                    <div className="flex gap-3">
                      <StarRating rating={vendorRating.rating} size={6} />
                      <span>{vendorRating.rating.toFixed(1)}</span>
                      <span className="text-gray-400">
                        ({vendorRating.totalReviews})
                      </span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="relative space-y-5 border-gray-200 lg:border-l lg:mx-7 lg:pl-7 ">
                <div className="text-xl font-semibold">Task Info</div>
                <div className="grid lg:grid-cols-2 gap-x-4 gap-y-4 lg:mt-0">
                  <div className="font-semibold">Status</div>
                  <div>
                    <StatusChip
                      model="TaskScheduleStatus"
                      status={task.schedule_status}
                      label={TaskScheduleStatusLabels[task.schedule_status]}
                      className="w-fit"
                    />
                  </div>

                  <div className="font-semibold">
                    Start Date
                    <Tooltip
                      position="left"
                      text="The task start date is the date that you’ll begin working on this task. For contract renewal tasks, the best task start date is typically a few months before the contract's current term ends."
                    >
                      <div className="flex flex-row items-center space-x-1 cursor-pointer">
                        <ExclamationCircleIcon className="ml-2 text-gray-500 h-5" />
                      </div>
                    </Tooltip>
                  </div>
                  <div>
                    {task.start_date
                      ? dayjs.utc(task.start_date).format("MMM D, YYYY")
                      : "--"}
                  </div>

                  <div className="font-semibold">
                    Due Date
                    <Tooltip
                      position="left"
                      text="The task due date is the date when all work on the task should be completed. For contract renewal tasks, the best task due date is typically on the date that the current term ends."
                    >
                      <div className="flex flex-row items-center space-x-1 cursor-pointer">
                        <ExclamationCircleIcon className="ml-2 text-gray-500 h-5" />
                      </div>
                    </Tooltip>
                  </div>
                  <div>
                    {task.due_date
                      ? dayjs.utc(task.due_date).format("MMM D, YYYY")
                      : "--"}
                  </div>
                  <div className="font-semibold">
                    Task Owner
                    <Tooltip
                      position="left"
                      text="The Task Owner is the user that is responsible for completing action-items in Revyse when the contract renews."
                    >
                      <div className="flex flex-row items-center space-x-1 cursor-pointer">
                        <ExclamationCircleIcon className="ml-2 text-gray-500 h-5" />
                      </div>
                    </Tooltip>
                  </div>
                  <div>
                    {task.task_owner ? (
                      <div>
                        {task.task_owner?.user.first_name}{" "}
                        {task.task_owner?.user.last_name}
                      </div>
                    ) : (
                      <div>
                        {task.contract.task_owner?.user.first_name}{" "}
                        {task.contract.task_owner?.user.last_name}
                      </div>
                    )}
                  </div>

                  {userCanManageTasks && (
                    <Button
                      className="absolute top-[-1rem] right-[-2rem] text-md font-medium"
                      color="transparent"
                      onClick={() => setEditTask(true)}
                    >
                      <RevysePencilIcon className="mr-2" /> Edit
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </section>
          <section className="mt-5 overflow-hidden bg-white rounded-md shadow p-7">
            <div className="flex flex-col lg:flex-row justify-between items-center space-y-3 lg:space-y-0">
              <div className="flex items-center space-x-3">
                <h2 className="text-lg lg:text-2xl font-semibold leading-tight">
                  Contract Info
                </h2>
                <div>
                  <StatusChip
                    model="ContractStatus"
                    status={task.contract.status}
                    label={task.contract.status}
                    suffix="Contract"
                  />
                </div>
              </div>
              <div>
                <CTA
                  fillStyle="outline"
                  variant="sky"
                  to={`/intelligence/${account.id}/contract/${task.contract_id}/details`}
                >
                  View all contract details
                </CTA>
              </div>
            </div>
            <hr className="my-5" />
            <div className="text-sm lg:text-base mt-4">
              View the most important details of your upcoming{" "}
              {task.contract.manager_account_vendor.vendor.name} contract
              renewal, including current term end date, auto-renewal terms, and
              scheduled price increases. To see all configured contract terms,
              click “View all contract details”.
            </div>
            <div className="grid grid-flow-row grid-cols-1 lg:grid-cols-3 gap-5 mt-8">
              <div className="flex">
                <ClockIcon className="my-auto mr-3 h-7" />
                <div>
                  <span className="font-semibold">Current Term Ends</span>
                  <br />
                  <span>
                    {task.contract.current_term_end_date
                      ? dayjs
                          .utc(task.contract.current_term_end_date)
                          .format("MMM D, YYYY")
                      : "--"}
                  </span>
                </div>
              </div>
              <div className="flex">
                <ArrowPathRoundedSquareIcon className="my-auto mr-3 h-7" />
                <div>
                  <span className="font-semibold">Auto Renewal</span>
                  <br />
                  <span>
                    {task.contract.auto_renew_term_length
                      ? `${task.contract.auto_renew_term_length} months`
                      : "--"}
                  </span>
                </div>
              </div>
              <div className="flex">
                <ArrowTrendingUpIcon className="my-auto mr-3 h-7" />
                <div>
                  <span className="font-semibold">
                    Contracted Price Increase
                  </span>
                  <br />
                  {filteredContractsLineItems.length > 0
                    ? "Yes"
                    : "None Entered"}
                </div>
              </div>
              <div className="flex">
                <ShoppingBagIcon className="my-auto mr-3 h-7" />
                <div>
                  <span className="font-semibold">Line Items</span>
                  <br />
                  <Link
                    className="text-sky-500"
                    to={`/intelligence/${account.id}/contract/${task.contract_id}/line-item`}
                  >
                    {task.contract.contract_line_items.length}
                  </Link>
                </div>
              </div>
              <div className="flex">
                <BuildingOfficeIcon className="my-auto mr-3 h-7" />
                <div>
                  <span className="font-semibold">Locations Assigned</span>
                  <br />
                  <Link
                    className="text-sky-500"
                    to={`/intelligence/${account.id}/contract/${task.contract_id}/contracted-locations/`}
                  >
                    {contractedLocations()}
                  </Link>
                </div>
              </div>
              <div className="flex">
                <BriefcaseIcon className="my-auto mr-3 h-7" />
                <div>
                  <span className="font-semibold">Annual Contract Value</span>
                  <br />
                  {contractAnnualValue.toLocaleString(undefined, {
                    style: "currency",
                    currency: "USD",
                  })}
                </div>
              </div>
            </div>
          </section>
          <section className="mt-5 overflow-hidden bg-white rounded-md shadow p-7">
            <div className="flex flex-col lg:flex-row justify-between items-center">
              <h2 className="text-lg lg:text-2xl font-semibold leading-tight">
                {task.contract.manager_account_vendor.vendor.name} Contacts
              </h2>
              {userCanManageVendors && (
                <div className="flex">
                  <Button
                    color="transparent"
                    className="text-md font-medium"
                    to={`/intelligence/${account.id}/vendors/${task.contract.manager_account_vendor?.id}/contacts`}
                    id="edit-vendor-contacts"
                  >
                    <RevysePencilIcon className="mr-2" /> Edit
                  </Button>
                </div>
              )}
            </div>
            <hr className="my-5" />
            <div className="text-sm lg:text-base mt-4">
              View the contact information for{" "}
              {task.contract.manager_account_vendor.vendor.name}, including your
              primary account contact and the billing inquiry contact, as you
              consider your upcoming contract renewal.
            </div>
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-x-5 mt-8">
              {Object.values(ManagerAccountVendorContactType).map(type => {
                if (type !== ManagerAccountVendorContactType.Disposition) {
                  const contact =
                    task.contract.manager_account_vendor?.manager_account_vendor_contacts.find(
                      contact => contact.type === type
                    );
                  return (
                    <ManagerAccountVendorContactCard
                      key={type}
                      managerAccountVendorContact={contact}
                      type={type}
                      className="mt-5 lg:mt-0"
                    />
                  );
                }
                return null;
              })}
            </div>
          </section>
          {alternativeProducts.length > 0 && (
            <section className="mt-5 overflow-hidden bg-white rounded-md shadow p-7">
              <div className="flex flex-col lg:flex-row justify-between items-center space-y-3 lg:space-y-0">
                <h2 className="text-lg lg:text-2xl font-semibold leading-tight">
                  Revyse Community Recommends
                </h2>
                <div>
                  <CTA fillStyle="outline" variant="sky" to="/categories">
                    View more alternatives
                  </CTA>
                </div>
              </div>
              <hr className="my-5" />
              <div className="text-sm lg:text-base mt-4">
                View the top-rated alternative products and services across
                similar categories, and read reviews from verified users.
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-8 p-2 my-5">
                {alternativeProducts.map(p => (
                  <ProductTile
                    key={p.id}
                    onClick={() => navigate(`/products/${p.slug}`)}
                    product={{
                      name: p.title,
                      avgRating: p.avg_score,
                      totalRatings: p.cnt,
                      logo_file: { id: p.logo_file_id },
                      slug: p.slug,
                    }}
                    showCTA={true}
                  ></ProductTile>
                ))}
              </div>
            </section>
          )}
        </div>
      </div>
      <ChatBubble
        isOpen={openChat}
        sendMessage={handleSendMessage}
        users={userMentionOptions}
        onClose={() => {
          setOpenChat(false);
          toggleCollapse();
        }}
        messages={messages}
        actionUrl={actionUrl}
        fetcher={fetcher}
        senderId={senderId}
        allowSend={userCanSendTaskChatMessage}
      ></ChatBubble>
    </>
  );
}
