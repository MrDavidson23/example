import { ProductState, Role } from "@prisma/client";
import { useLoaderData } from "@remix-run/react";
import { PortalPage } from "~/components/portal-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";

export async function loader() {
  const {
    userService,
    productService,
    reviewService,
    productSubscriptionService,
  } = await WebDIContainer();
  const userCount = await userService.getUsersCount({});

  const verifiedBuyerCount = await userService.getUsersCount({
    where: {
      user_roles: {
        some: {
          role: Role.BUYER,
        },
      },
    },
  });

  const publishedListings = await productService.getProductsCount({
    where: { approved_at: { not: null }, state: ProductState.discovery },
  });

  const publishedReviews = await reviewService.getReviewsCount({
    where: { approved_at: { not: null } },
  });

  const subscriptionCountByPlan =
    await productSubscriptionService.getSubscriptionCountByPlan();

  return {
    userCount,
    verifiedBuyerCount,
    publishedListings,
    publishedReviews,
    subscriptionCountByPlan,
  };
}

export default function AdminIndexRoute() {
  const {
    userCount,
    verifiedBuyerCount,
    publishedListings,
    publishedReviews,
    subscriptionCountByPlan,
  } = useLoaderData<typeof loader>();
  return (
    <PortalPage crumbs={[{ name: "Dashboard", to: "/admin" }]}>
      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-white shadow p-4 rounded grid grid-cols-2">
          <div className="col-span-2 font-bold mb-4 text-xl">Totals</div>
          <div>Users:</div>
          <div>{userCount}</div>

          <div>Verified Buyers:</div>
          <div>{verifiedBuyerCount}</div>

          <div>Published Listings:</div>
          <div>{publishedListings}</div>

          <div>Published Reviews:</div>
          <div>{publishedReviews}</div>
        </div>

        <div className="bg-white shadow p-4 rounded grid grid-cols-2">
          <div className="col-span-2 font-bold mb-4 text-xl">
            Subscriptions by Plan
          </div>
          {subscriptionCountByPlan.map(s => (
            <>
              <div>{s.name}</div>
              <div>{s.cnt}</div>
            </>
          ))}
        </div>
      </div>
    </PortalPage>
  );
}
