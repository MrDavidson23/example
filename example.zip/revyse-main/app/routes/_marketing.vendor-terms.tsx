import type { MetaFunction } from "@remix-run/node";
import { Legalese } from "~/components/legalese.component";

export const meta: MetaFunction = () => [
  { title: "Vendor Terms | Revyse" },
  {
    name: "description",
    content:
      "Review the commercial terms for vendor subscribers on Revyse’s multifamily vendor discovery platform and user review site.",
  },
];

export default function PrivacyPolicyRoute() {
  return (
    <Legalese title="Vendor Terms">
      <p>Effective as of June 1, 2023</p>
      <p>
        These Vendor Terms (“Terms”) govern the use of Revyse Inc’s (“Revyse”)
        website (“Site”) and services (“Services”) by merchants or vendors
        (“Vendors”) who desire to promote their products or services on the
        Site, or acquire leads from users of the Site who express an interest in
      </p>
      <p>
        Vendor’s products or services. Vendors who desire to use the Site or
        Services to promote their products or services must register for a
        subscription package. By acquiring a subscription to use the Site, you
        agree to be bound by these Terms.
      </p>
      <h2>1. Subscription Options and Vendor Account</h2>
      <p>
        At the time of registration, you were required to select a subscription
        package. Pricing and the features of your subscription package are set
        forth on the Site.
      </p>
      <p>
        All subscription packages include the right to create a Vendor profile
        and account to list your products or services on the Site (“Vendor
        Account”). You are responsible for creating and maintaining your Vendor
        Account, including the accuracy of all information connected to your
        Vendor Account. Revyse is not responsible for ensuring the accuracy of
        your Vendor Account.
      </p>
      <h2>2. Vendor Content</h2>
      <p>
        If you purchased one of the premium subscription options, it may include
        the right to post content, photos, audio, video or product demos on the
        Site to promote your products or services (“Vendor Content”). All Vendor
        Content shall be subject to and comply with the provisions in this
        Section 2.
      </p>
      <p>
        By posting any Vendor Content, you grant us an unrestricted, unlimited,
        irrevocable, perpetual, non-exclusive, transferable, royalty-free,
        fully-paid, worldwide right, and license to: use, copy, reproduce,
        distribute, sell, resell, publish, broadcast, retitle, store, publicly
        perform, publicly display, reformat, translate, excerpt (in whole or in
        part), and exploit your Vendor Content (including, without limitation,
        your image, name, and voice) for any purpose, commercial, advertising,
        or otherwise, to prepare derivative works of, or incorporate into other
        works, your Vendor Content, and to sublicense the licenses granted in
        this section. Our use and distribution may occur in any media formats
        and through any media channels. This license includes our use of your
        name, company name, and franchise name, as applicable, and any of the
        copyrights, trademarks, service marks, trade names, logos, and personal
        and commercial images you provide.
      </p>
      <p>
        You understand that Vendor Content may be viewable by users of the Site
        and Services, and possibly through third-party websites.
      </p>
      <p>Vendor Content shall comply with the following:</p>
      <ul>
        <li>
          it shall not contain any false, deceptive or materially misleading
          statements or representations, whether about Vendor’s products or
          services, or those of any of Vendor’s competitors;
        </li>
        <li>
          it shall comply with all applicable laws, rules and regulations;
        </li>
        <li>
          it shall not contain any content or statement is illegal, harassing,
          hateful, harmful, defamatory, obscene, bullying, abusive,
          discriminatory, threatening to any person or group, or sexually
          explicit;
        </li>
        <li>
          it shall not contain any text, material, logo, image or other content
          that infringes upon the intellectual property rights, publicity rights
          or privacy rights of any third party;
        </li>
      </ul>
      <p>
        You are solely responsible for your Vendor Content and you expressly
        agree to indemnify, defend and reimburse us for any and all losses or
        damages that we may incur or suffer as a result of your breach of the
        provisions contained in this Section 2.
      </p>
      <p>
        Although we have no obligation to monitor Vendor Content, we shall have
        the right to remove or edit any Vendor Content at any time without
        notice if in our reasonable opinion we consider such Vendor Content
        harmful or in breach of these Terms. If we remove or edit any such
        Vendor Content, we may also suspend or disable your account and report
        you to the authorities.
      </p>
      <p>
        If you believe that any material available on or through the Site
        infringes upon any copyright you own or control, please immediately
        refer to the "Digital Millennium Copyright Act (DMCA) Notice And Policy"
        section in the Terms of Use contained on the Site.
      </p>
      <h2>3. Leads</h2>
      <p>
        If you purchased one of the premium subscription options, it may include
        the right to receive leads from users of the Site who express an
        interest in your products or services (“Leads”).
      </p>
      <p>
        Any Leads provided to you in connection with your subscription are
        provided “As Is” and without any representations or warranties. Revyse
        disclaims any and all liability for the accuracy of the Leads, and makes
        no representations nor warranties whatsoever regarding Lead performance
        or profitability.
      </p>
      <h2>4. Representations and Warranties</h2>
      <p>
        You represent and warrant that (i) you are authorized to enter into
        these Terms, (ii) your use of the Site and Leads, and any Vendor
        Content, shall comply with all applicable laws, rules and regulations,
        and (iii) any business or website that you own or operate, which you
        link to the Site, shall comply with all applicable laws, rules and
        regulations
      </p>
      <h2>5. Term and Cancellation</h2>
      <p>
        The initial subscription term (“Term”) will be one year, billed annually
        or monthly, depending upon which option you selected at the time of your
        subscription. At the end of the Term, your subscription will
        automatically renew (a “Renewal Term”) for an additional one year,
        unless you provide Revyse with written notice of your intent not to
        renew at least 30 days before the end of the Term or Renewal Term.
      </p>
      <p>
        You may cancel your subscription at any time, provided (i) you must
        provide at least thirty (30) days prior written notice, and (ii)
        cancellations will only take effect at the end of the Term or Renewal
        Term, as applicable. You are responsible for all subscription fees due
        through the effective date of cancellation. To cancel your subscription,
        you may contact us at support@revyse.com.
      </p>
      <p>
        All purchases are non-refundable. If you cancel your subscription before
        the end of the Term or any Renewal Term, you remain liable for
        subscription fees up through the effective date of cancellation as set
        forth above.
      </p>
      <p>
        Revyse may immediately cancel your subscription and these Terms in its
        sole and absolute discretion upon written notice. If Revyse cancels your
        subscription or these Terms, then (i) your responsibility for paying
        further subscription fees shall terminate immediately, (ii) you shall
        not be entitled to any refund of fees if Revyse terminates your
        subscription due to a breach of these Terms, and (iii) Revyse will
        refund a pro rata portion of your fees if it terminates your
        subscription without cause.
      </p>
      <h2>6. Subscription Fees And Payment</h2>
      <p>
        You agree to pay us all subscription fees due for the duration of the
        Term or Renewal Term, as applicable.
      </p>
      <p>
        We may change subscription prices by providing you written notice before
        the end of the applicable Term or Renewal Term, as applicable. Unless
        mutually agreed to in writing, fee changes become effective upon the
        date of the next Renewal Term.
      </p>
      <p>We accept the following forms of payment: credit card and ACH.</p>
      <p>
        You agree to provide current, complete, and accurate purchase and
        account information for all subscriptions you acquire. You further agree
        to promptly update account and payment information, including email
        address, payment method, and payment card expiration date, so that we
        can complete your transactions and contact you as needed. Sales tax will
        be added to the price of purchases as required by law. All payments
        shall be in US dollars.
      </p>
      <p>
        You agree to pay all subscription fees at the prices then in effect, and
        you authorize us to charge your chosen payment provider for any such
        amounts upon placing your order.
      </p>
      <p>
        If your subscription is subject to recurring charges, or when your
        subscription automatically renews, then you consent to our charging your
        payment method on a recurring basis without requiring your prior
        approval for each recurring charge, until such time as you cancel the
        subscription.
      </p>
      <p>
        We reserve the right to correct any errors or mistakes in pricing, even
        if we have already requested or received payment. We also reserve the
        right to refuse, cancel or limit any subscription or order placed
        through the Site in our sole and absolute discretion.
      </p>
      <h2>7. Prohibited Activities</h2>
      <p>
        You may not access or use the Site or Services for any purpose other
        than that for which we make the Services available. The Services may not
        be used in connection with any commercial endeavors except as expressly
        set forth in these Terms.
      </p>
      <p>Without limiting the foregoing, you expressly agree not to:</p>
      <ul>
        <li>
          Systematically retrieve data or other content from the Services to
          create or compile, directly or indirectly, a collection, compilation,
          database, or directory without written permission from us;
        </li>
        <li>
          Trick, defraud, or mislead us or Site users, especially in any attempt
          to learn sensitive account information such as user passwords;
        </li>
        <li>
          Circumvent, disable, or otherwise interfere with security-related
          features of the Services, including features that prevent or restrict
          the use or copying of any content or enforce limitations on the use of
          the Services and/or the content contained therein;
        </li>
        <li>
          Disparage, tarnish, or otherwise harm, in our opinion, us and/or the
          Services;
        </li>
        <li>
          Use any information obtained from the Services in order to harass,
          abuse, or harm any Site user or Vendor;
        </li>
        <li>
          Make improper use of our support services or submit false reports of
          abuse or misconduct;
        </li>
        <li>
          Use the Services in a manner inconsistent with any applicable laws or
          regulations;
        </li>
        <li>Engage in unauthorized framing of or linking to the Services;</li>
        <li>
          Upload or transmit (or attempt to upload or to transmit) viruses,
          Trojan horses, or other material, including excessive use of capital
          letters and spamming (continuous posting of repetitive text), that
          interferes with any party’s uninterrupted use and enjoyment of the
          Services or modifies, impairs, disrupts, alters, or interferes with
          the use, features, functions, operation, or maintenance of the
          Services;
        </li>
        <li>
          Engage in any automated use of the system, such as using scripts to
          send comments or messages, or using any data mining, robots, or
          similar data gathering and extraction tools;
        </li>
        <li>
          Delete the copyright or other proprietary rights notice from any
          content;
        </li>
        <li>
          Attempt to impersonate a Site user or Vendor, or use the username of a
          Site user or Vendor.
        </li>
        <li>
          Upload or transmit (or attempt to upload or to transmit) any material
          that acts as a passive or active information collection or
          transmission mechanism, including without limitation, clear graphics
          interchange formats ("gifs"), 1×1 pixels, web bugs, cookies, or other
          similar devices (sometimes referred to as "spyware" or "passive
          collection mechanisms" or "pcms");
        </li>
        <li>
          Interfere with, disrupt, or create an undue burden on the Services or
          the networks or services connected to the Services;
        </li>
        <li>
          Harass, annoy, intimidate, or threaten any of our employees or agents
          engaged in providing any portion of the Services to you;
        </li>
        <li>
          Attempt to bypass any measures of the Services designed to prevent or
          restrict access to the Services, or any portion of the Services;
        </li>
        <li>
          Copy or adapt the Services' software, including but not limited to
          Flash, PHP, HTML, JavaScript, or other code;
        </li>
        <li>
          Except as permitted by applicable law, decipher, decompile,
          disassemble, or reverse engineer any of the software comprising or in
          any way making up a part of the Services;
        </li>
        <li>
          Except as may be the result of standard search engine or Internet
          browser usage, use, launch, develop, or distribute any automated
          system, including without limitation, any spider, robot, cheat
          utility, scraper, or offline reader that accesses the Services, or use
          or launch any unauthorized script or other software;
        </li>
        <li>
          Use a buying agent or purchasing agent to make purchases on the
          Services;
        </li>
        <li>
          Make any unauthorized use of the Services, including collecting
          usernames and/or email addresses of users by electronic or other means
          for the purpose of sending unsolicited email, or creating user
          accounts by automated means or under false pretenses;
        </li>
        <li>
          Use the Services as part of any effort to compete with us or otherwise
          use the Services and/or the Site for any revenue-generating endeavor
          or commercial enterprise other than expressly authorized herein;
        </li>
        <li>
          Sell or otherwise transfer your profile, other than in connection with
          a merger, acquisition, asset sale or other change of control.
        </li>
      </ul>
      <h2>8. Modifications And Interruptions</h2>
      <p>
        We reserve the right to change, modify, or remove the contents of the
        Services at any time or for any reason at our sole discretion without
        notice. We have no obligation to update any information on our Services.
        We will not be liable to you or any third party for any modification,
        price change, suspension, or discontinuance of the Services.
      </p>
      <p>
        We cannot guarantee the Site or Services will be available at all times.
        We may experience hardware, software, or other problems or need to
        perform maintenance related to the Site or Services, resulting in
        interruptions, delays, or errors. We reserve the right to change,
        revise, update, suspend, discontinue, or otherwise modify the Services
        at any time or for any reason without notice to you. You agree that we
        have no liability whatsoever for any loss, damage, or inconvenience
        caused by your inability to access or use the Site or Services during
        any downtime or discontinuance of the Services. Nothing in these Terms
        will be construed to obligate us to maintain and support the Site or
        Services or to supply any corrections, updates, or releases in
        connection therewith.
      </p>
      <h2>9. Governing Law</h2>
      <p>
        These Terms and your use of the Site and Services are governed by and
        construed in accordance with the laws of the State of Oregon applicable
        to agreements made and to be entirely performed within the State of
        Oregon, without regard to its conflict of law principles.
      </p>
      <h2>10. Dispute Resolution</h2>
      <p>
        Any legal action of whatever nature brought by either you or us
        (collectively, the "Parties" and individually, a "Party") shall be
        commenced or prosecuted in the state and federal courts located in
        Deschutes, Oregon, and the Parties hereby consent to, and waive all
        defenses of lack of personal jurisdiction and forum non conveniens with
        respect to venue and jurisdiction in such state and federal courts.
        Application of the United Nations Convention on Contracts for the
        International Sale of Goods and the Uniform Computer Information
        Transaction Act (UCITA) are excluded from these Legal Terms. In no event
        shall any claim, action, or proceeding brought by either Party related
        in any way to the Services be commenced more than one (1) years after
        the cause of action arose.
      </p>
      <h2>11. Attorneys’ Fees</h2>
      <p>
        In any dispute that arises from or involves a breach of Section 4, 6 or
        7 of these Terms, or in connection with any action for indemnification
        pursuant to Section 15, the prevailing party shall be entitled to
        recover its attorneys’ fees and costs.
      </p>
      <h2>12. Corrections</h2>
      <p>
        There may be information on the Site or Services that contains
        typographical errors, inaccuracies, or omissions, including
        descriptions, pricing, availability, and various other information. We
        reserve the right to correct any errors, inaccuracies, or omissions and
        to change or update the information on the Site or Services at any time,
        without prior notice.
      </p>
      <h2>13. DISCLAIMER</h2>
      <p>
        THE SITE AND SERVICES ARE PROVIDED ON AN AS-IS AND AS-AVAILABLE BASIS.
        YOU AGREE THAT YOUR USE OF THE SITE AND SERVICES WILL BE AT YOUR SOLE
        RISK. TO THE FULLEST EXTENT PERMITTED BY LAW, WE DISCLAIM ALL
        WARRANTIES, EXPRESS OR IMPLIED, IN CONNECTION WITH THE SITE AND SERVICES
        AND YOUR USE THEREOF, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
        WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
        NON-INFRINGEMENT. WE MAKE NO WARRANTIES OR REPRESENTATIONS ABOUT THE
        ACCURACY OR COMPLETENESS OF THE SITE OR SERVICES' CONTENT OR THE CONTENT
        OF ANY WEBSITES OR MOBILE APPLICATIONS LINKED TO THE SERVICES AND WE
        WILL ASSUME NO LIABILITY OR RESPONSIBILITY FOR ANY (1) ERRORS, MISTAKES,
        OR INACCURACIES OF CONTENT, LEADS OR MATERIALS, (2) PERSONAL INJURY OR
        PROPERTY DAMAGE, OF ANY NATURE WHATSOEVER, RESULTING FROM YOUR ACCESS TO
        AND USE OF THE SITE, THE SERVICES OR ANY LEAD, (3) ANY UNAUTHORIZED
        ACCESS TO OR USE OF OUR SECURE SERVERS AND/OR ANY AND ALL PERSONAL
        INFORMATION AND/OR FINANCIAL INFORMATION STORED THEREIN, (4) ANY
        INTERRUPTION OR CESSATION OF TRANSMISSION TO OR FROM THE SITE OR
        SERVICES, (5) ANY BUGS, VIRUSES, TROJAN HORSES, OR THE LIKE WHICH MAY BE
        TRANSMITTED TO OR THROUGH THE SITE OR SERVICES BY ANY THIRD PARTY,
        AND/OR (6) ANY ERRORS OR OMISSIONS IN ANY CONTENT OR FOR ANY LOSS OR
        DAMAGE OF ANY KIND INCURRED AS A RESULT OF THE USE OF ANY CONTENT
        POSTED, TRANSMITTED, OR OTHERWISE MADE AVAILABLE VIA THE SITE OR
        SERVICES. WE DO NOT WARRANT, ENDORSE, GUARANTEE, OR ASSUME
        RESPONSIBILITY FOR ANY PRODUCT OR SERVICE ADVERTISED OR OFFERED BY A
        THIRD PARTY THROUGH THE SITE OR SERVICES, ANY HYPERLINKED WEBSITE, OR
        ANY WEBSITE OR MOBILE APPLICATION FEATURED IN ANY BANNER OR OTHER
        ADVERTISING, AND WE WILL NOT BE A PARTY TO OR IN ANY WAY BE RESPONSIBLE
        FOR MONITORING ANY TRANSACTION BETWEEN YOU AND ANY THIRD-PARTY PROVIDERS
        OF PRODUCTS OR SERVICES. AS WITH THE PURCHASE OF A PRODUCT OR SERVICE
        THROUGH ANY MEDIUM OR IN ANY ENVIRONMENT, YOU SHOULD USE YOUR BEST
        JUDGMENT AND EXERCISE CAUTION WHERE APPROPRIATE.
      </p>
      <h2>14. Limitations Of Liability</h2>
      <p>
        IN NO EVENT WILL WE OR OUR DIRECTORS, EMPLOYEES, OR AGENTS BE LIABLE TO
        YOU OR ANY THIRD PARTY FOR ANY DIRECT, INDIRECT, CONSEQUENTIAL,
        EXEMPLARY, INCIDENTAL, SPECIAL, OR PUNITIVE DAMAGES, INCLUDING LOST
        PROFIT, LOST REVENUE, LOSS OF DATA, OR OTHER DAMAGES ARISING FROM YOUR
        USE OF THE SITE OR SERVICES, EVEN IF WE HAVE BEEN ADVISED OF THE
        POSSIBILITY OF SUCH DAMAGES. NOTWITHSTANDING ANYTHING TO THE CONTRARY
        CONTAINED HEREIN, OUR LIABILITY TO YOU FOR ANY CAUSE WHATSOEVER AND
        REGARDLESS OF THE FORM OF THE ACTION, WILL AT ALL TIMES BE LIMITED TO
        THE AMOUNT PAID, IF ANY, BY YOU TO US DURING THE THREE (3) MONTH PERIOD
        PRIOR TO ANY CAUSE OF ACTION ARISING. CERTAIN US STATE LAWS AND
        INTERNATIONAL LAWS DO NOT ALLOW LIMITATIONS ON IMPLIED WARRANTIES OR THE
        EXCLUSION OR LIMITATION OF CERTAIN DAMAGES. IF THESE LAWS APPLY TO YOU,
        SOME OR ALL OF THE ABOVE DISCLAIMERS OR LIMITATIONS MAY NOT APPLY TO
        YOU, AND YOU MAY HAVE ADDITIONAL RIGHTS.
      </p>
      <h2>15. Indemnification</h2>
      <p>
        You agree to defend, indemnify, and hold us harmless, including our
        subsidiaries, affiliates, and all of our respective officers, agents,
        partners, and employees, from and against any loss, damage, liability,
        claim, or demand, including reasonable attorneys’ fees and expenses,
        made by any third party due to or arising out of: (1) your Vendor
        Content; (2) use of the Site or Services; (3) breach of these Terms,
        including any breach of your representations and warranties set forth in
        these Terms; (4) your violation of or infringement on the rights of a
        third party, including but not limited to intellectual property, privacy
        or publicity rights; or (5) any overt harmful act toward any other user
        of the Services with whom you connected via the Services.
        Notwithstanding the foregoing, we reserve the right, at your expense, to
        assume the exclusive defense and control of any matter for which you are
        required to indemnify us, and you agree to cooperate, at your expense,
        with our defense of such claims. We will use reasonable efforts to
        notify you of any such claim, action, or proceeding which is subject to
        this indemnification upon becoming aware of it.
      </p>
      <h2>16. Electronic Communications, Transactions, And Signatures</h2>
      <p>
        Visiting the Site, using the Services, sending us emails, and completing
        online forms constitute electronic communications. You consent to
        receive electronic communications, and you agree that all agreements,
        notices, disclosures, and other communications we provide to you
        electronically, via email and on the Site, satisfy any legal requirement
        that such communication be in writing. YOU HEREBY AGREE TO THE USE OF
        ELECTRONIC SIGNATURES, CONTRACTS, ORDERS, AND OTHER RECORDS, AND TO
        ELECTRONIC DELIVERY OF NOTICES, POLICIES, AND RECORDS OF TRANSACTIONS
        INITIATED OR COMPLETED BY US OR VIA THE SITE OR SERVICES. You hereby
        waive any rights or requirements under any statutes, regulations, rules,
        ordinances, or other laws in any jurisdiction which require an original
        signature or delivery or retention of non-electronic records, or to
        payments or the granting of credits by any means other than electronic
        means.
      </p>
      <h2>17. Miscellaneous</h2>
      <p>
        These Terms and any policies or operating rules posted by us on the Site
        or in respect to the Services constitute the entire agreement and
        understanding between you and us. Our failure to exercise or enforce any
        right or provision of these Terms shall not operate as a waiver of such
        right or provision. These Terms operate to the fullest extent
        permissible by law. We may assign any or all of our rights and
        obligations to others at any time. We shall not be responsible or liable
        for any loss, damage, delay, or failure to act caused by any cause
        beyond our reasonable control. If any provision or part of a provision
        of these Terms is determined to be unlawful, void, or unenforceable,
        that provision or part of the provision is deemed severable from these
        Terms and does not affect the validity and enforceability of any
        remaining provisions. There is no joint venture, partnership, employment
        or agency relationship created between you and us as a result of these
        Terms or use of the Site or Services. You agree that these Terms will
        not be construed against us by virtue of having drafted them. You hereby
        waive any and all defenses you may have based on the electronic form of
        these Terms and the lack of signing by the parties hereto to execute
        these Terms.
      </p>
    </Legalese>
  );
}
