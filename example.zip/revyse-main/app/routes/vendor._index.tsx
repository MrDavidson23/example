import { PhotoIcon } from "@heroicons/react/20/solid";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Link, useLoaderData } from "@remix-run/react";
import dayjs from "dayjs";
import { Avatar } from "~/components/avatar.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assertAuthenticatedOrRedirect } from "~/utils/auth.utils.server";
import relativeTime from "dayjs/plugin/relativeTime";
dayjs.extend(relativeTime);

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await assertAuthenticatedOrRedirect(request);
  const { db, productSubscriptionService } = await WebDIContainer();
  const subscriptions =
    await productSubscriptionService.getSubscriptionsForUser(user);
  const reviews = await db.productReview.findMany({
    where: {
      product_id: { in: subscriptions.map(s => s.product_id) },
      approved_at: { not: null },
    },
    include: {
      user: {
        select: {
          first_name: true,
          last_name: true,
        },
      },
    },
    orderBy: {
      created_at: "desc",
    },
    take: 5,
  });
  return json({
    user,
    reviews,
    subscriptions: subscriptions.slice(0, 5),
  });
}

export default function VendorDashboardRoute() {
  const { user, subscriptions, reviews } = useLoaderData<typeof loader>();
  return (
    <div className="flex justify-center">
      <div className="md:max-w-7xl w-full px-4 sm:px-6 lg:px-8 py-4">
        <h2 className="font-bold my-6">Welcome back, {user.first_name}</h2>
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-white overflow-hidden shadow rounded-lg p-6">
            <h3 className="flex justify-between items-center">
              Recent Reviews{" "}
              <Link
                id="all-reviews"
                to="/vendor/reviews"
                className="text-sky-600 text-sm"
              >
                All Reviews
              </Link>
            </h3>
            {reviews.length === 0 && (
              <div className="text-gray-500 text-sm text-center py-12">
                No Reviews Yet
              </div>
            )}
            {reviews.map((review, i) => (
              <div key={review.id} className="flex items-center my-4">
                <Avatar
                  first_name={review.user.first_name!}
                  last_name={review.user.last_name!}
                />
                <div className="flex-grow ml-4">
                  <div>
                    {review.user.first_name} {review.user.last_name![0]}.{" "}
                    <Link
                      to={`/vendor/reviews/${review.id}`}
                      className="text-sky-600"
                    >
                      submitted a review
                    </Link>
                  </div>
                  <div className="text-gray-500 text-sm">
                    {dayjs(review.created_at).fromNow()}
                  </div>
                </div>
              </div>
            ))}
          </div>
          <div className="bg-white overflow-hidden shadow rounded-lg p-6">
            <h3 className="flex justify-between items-center">
              Recent Listings{" "}
              <Link
                id="all-listings"
                to="/vendor/products"
                className="text-sky-600 text-sm"
              >
                All Listings
              </Link>
            </h3>
            {subscriptions.length === 0 && (
              <div className="text-gray-500 text-sm text-center py-12">
                No Listings Yet
                <Link
                  id="create-product"
                  to={"products/new"}
                  className="text-sky-600 block mt-4"
                >
                  + Create One
                </Link>
              </div>
            )}
            {subscriptions.map((sub, i) => (
              <div key={i} className="flex items-center my-4">
                {sub.product.logo_file_id ? (
                  <img
                    src={`images/${sub.product.logo_file_id}`}
                    className="h-12 w-12 rounded"
                    alt="logo"
                    width="48"
                    height="48"
                  />
                ) : (
                  <PhotoIcon className="h-12 w-12 text-gray-400" />
                )}
                <div className="flex-grow ml-4">
                  <div>
                    <Link
                      id={`sub_${sub.id}`}
                      to={`/vendor/products/${sub.product.id}`}
                      className="text-sky-600"
                    >
                      {sub.product.title}
                    </Link>
                  </div>
                  <div className="text-gray-500 text-sm">
                    Created {dayjs(sub.product.created_at).fromNow()}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
