import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { EnvelopeIcon } from "@heroicons/react/24/outline";
import { assertAuthenticatedOrRedirect } from "~/utils/auth.utils.server";
import { useLoaderData } from "@remix-run/react";

export const meta: MetaFunction = () => [
  { title: "Revyse | Sign-Up Complete" },
  {
    name: "description",
    content: "Sign-Up is complete. Now you need to verify your email.",
  },
];

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const user = await assertAuthenticatedOrRedirect(request);
  return json({ user });
};

export default function ForgotPasswordRoute() {
  const { user } = useLoaderData<typeof loader>();
  return (
    <div className="flex justify-center">
      <div className="max-w-3xl bg-white text-center rounded-3xl border border-gray-100 p-12 mt-6">
        <EnvelopeIcon className="h-12 inline mb-6" />
        <h1 className="text-3xl">We're glad you're here, {user.first_name}!</h1>
        <p className="my-4">
          Your registration is almost complete. Just one more quick step - head
          over to your inbox and{" "}
          <strong className="font-bold">verify your account</strong> for added
          security.
        </p>
        <p className="my-4">Welcome to the Revyse community!</p>
      </div>
    </div>
  );
}
