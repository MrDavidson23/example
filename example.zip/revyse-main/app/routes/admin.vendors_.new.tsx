import type { ActionFunctionArgs } from "@remix-run/node";
import { useActionData } from "@remix-run/react";
import { isNil } from "lodash";
import { jsonWithError, redirectWithSuccess } from "remix-toast";
import { z } from "zod";
import { CrudFormPage } from "~/components/form/crud-form-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import { assertAuthorized } from "~/utils/assert.utils.server";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import { getUser } from "~/utils/session.server";
import { castFormFields } from "~/utils/type.utils";

const MB = 1024 * 1024;
const LOGO_BYTE_LIMIT = 0.5 * MB;

const NewVendorForm = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().min(1, "Description is required"),
  slug: z.string(),
  logo_file_id: z
    .string()
    .min(1)
    .nullable()
    .transform(v => (v === "--" ? undefined : v ?? undefined)),
});

export const action = async ({ request }: ActionFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));
  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "logo_file_id", byteLimit: LOGO_BYTE_LIMIT },
  ]);

  const fields = {
    name: form.get("name"),
    description: form.get("description"),
    slug: form.get("slug"),
    logo_file_id: form.get("logo_file_id"),
  };
  const validation = NewVendorForm.safeParse(fields);

  if (validation.success) {
    const { vendorService } = await WebDIContainer();
    const vendor = await vendorService.createVendor(validation.data);

    return redirectWithSuccess(
      `/admin/vendors/${vendor.id}`,
      "Vendor created successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);
  return jsonWithError(
    { fields: castFormFields(fields), errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
};

export default function AdminVendorsNewRoute() {
  const actionData = useActionData<typeof action>();
  return (
    <CrudFormPage
      crumbs={[{ name: "Vendors", to: "/admin/vendors", active: false }]}
      config={{
        sections: [
          {
            title: "Create New Vendor",
            subtitle: "",
            fields: [
              {
                name: "name",
                label: "Name",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.name ?? undefined
                  : undefined,
                errors: actionData?.errors.name ?? [],
              },
              {
                name: "description",
                label: "Description",
                description: "A full description of the vendor",
                type: "textarea",
                defaultValue: actionData
                  ? actionData.fields.description ?? undefined
                  : undefined,
                errors: actionData?.errors.description ?? [],
              },
              {
                name: "slug",
                label: "Slug",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.slug ?? undefined
                  : undefined,
                errors: actionData?.errors.slug ?? [],
              },
              {
                name: "logo_file_id",
                label: "Logo (192 x 192)",
                buttonLabel: "",
                type: "image-upload",
                defaultValue: undefined,
                errors: actionData?.errors.logo_file_id ?? [],
                maxFileSize: LOGO_BYTE_LIMIT,
                allowRemoval: true,
                defaultNoValue: (
                  <img
                    src="/assets/default-logo.png"
                    className="w-12 h-12 aspect-square"
                    alt="Vendor default logo"
                    height="600"
                    width="600"
                  />
                ),
                square: true,
              },
            ],
          },
        ],
      }}
    />
  );
}
