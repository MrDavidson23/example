import { useCallback, useMemo, useState } from "react";
import { json } from "@remix-run/node";
import { ContractLineItemStatus, ContractStatus } from "@prisma/client";
import { Link, useLoaderData, useSearchParams } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { CTA } from "~/components/cta.component";
import { Pagination } from "~/components/intelligence/pagination.component";
import { Modal } from "~/components/modal.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { IntelligenceFilter } from "~/components/intelligence/intelligence-filter.component";
import type { ModalFilters } from "~/components/intelligence/filters-modal.component";
import { Table } from "~/components/intelligence/table.component";
import StatusChip from "~/components/status-chip.component";
import DocumentCard from "~/components/intelligence/document-card.component";
import {
  getFiltersFromSearchParams,
  getOrderByFromSearchParams,
  getPaginationFromSearchParams,
  updateSearchParams,
} from "~/utils/filtering.utils";
import { Button } from "~/components/button.component";
import {
  ArrowTopRightOnSquareIcon,
  FolderArrowDownIcon,
} from "@heroicons/react/24/outline";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { isEmpty } from "lodash";
dayjs.extend(utc);

const PER_PAGE = 10;

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewLocationDetails],
      locationId: params.location_id,
    }
  );

  const { managerAccountVendorService, locationService } =
    await WebDIContainer();
  const managerAccountId = account.id;

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);

  const filters = getFiltersFromSearchParams(search, [
    "contract_status", // array field
    "current_term_end_date",
    "vendors", // array field
  ]);

  const pagination = getPaginationFromSearchParams(search, {
    perPage: PER_PAGE, // default perPage
  });

  const orderBy = getOrderByFromSearchParams(search);

  const location = await locationService.getLocation(params.location_id!);

  if (!location) {
    throw new Response("Location not found", { status: 404 });
  }

  const vendors = await managerAccountVendorService.getVendorOptions(
    managerAccountId
  );

  const { data: items, count: itemsCount } =
    await locationService.getLocationContractsWithDocuments(
      user,
      account,
      params.location_id!,
      {
        filters,
        pagination,
        orderBy,
        canceledAtEnd: isEmpty(orderBy),
      },
    );

  return json({
    user,
    account,
    location,
    vendors: vendors.map(vendor => ({
      value: vendor.id,
      label: vendor.name,
    })),
    items,
    itemsCount,
  });
}

export default function LocationDocuments() {
  const { user, account, vendors, location, items, itemsCount } =
    useLoaderData<typeof loader>();

  const [contractDocumentsModal, setContractDocumentsModal] = useState<
    (typeof items)[number] | null
  >(null);
  const [exportAllFiles, setExportAllFiles] = useState(false);

  const [searchParams, setSearchParams] = useSearchParams();

  const currentFilters = useMemo(
    () => Object.fromEntries(searchParams.entries()),
    [searchParams]
  );

  const pagination = getPaginationFromSearchParams(searchParams, {
    perPage: PER_PAGE,
  });

  const onOrderBy = useCallback(
    (orderBy: Record<string, string>) => {
      const orderByString = Object.entries(orderBy)
        .map(([key, value]) => `${value == "desc" ? "-" : ""}${key}`)
        .join(",");

      setSearchParams(oldSearchParams => {
        updateSearchParams(oldSearchParams, {
          orderBy: orderByString,
          page: "1",
        });
        return oldSearchParams;
      });
    },
    [setSearchParams]
  );

  const handleFilter = ({
    filters,
    searchQuery,
  }: {
    filters?: ModalFilters;
    searchQuery?: string;
  }) => {
    setSearchParams(oldSearchParams => {
      if (searchQuery !== undefined) {
        updateSearchParams(oldSearchParams, { searchQuery, page: "1" });
      }

      if (filters !== undefined) {
        updateSearchParams(oldSearchParams, { ...filters, page: "1" });
      }

      return oldSearchParams;
    });
  };

  const onClickRow = (contract: (typeof items)[number]) => {
    if (contract.documents.length > 0) {
      setContractDocumentsModal(contract);
    }
  };

  const handlePageChange = (page: number) => {
    setSearchParams(oldSearchParams => {
      updateSearchParams(oldSearchParams, { page: String(page) });
      return oldSearchParams;
    });
  };

  const userCanExportDocuments = canDoOnAccount(
    user,
    account,
    Permission.ExportLocationDocuments
  );

  const dropdownItems = userCanExportDocuments
    ? [
        {
          onClick: () => {
            setExportAllFiles(!exportAllFiles);
          },
          label: "Export all files",
          icon: FolderArrowDownIcon,
          id: "export-files",
        },
      ]
    : undefined;

  const canceledItems = useMemo(() => {
    return items.filter(item => item._count.contract_line_items === 0);
  }, [items]);

  return (
    <>
      <Modal
        isOpen={!!exportAllFiles}
        onClose={() => setExportAllFiles(false)}
        manager={true}
        size="medium-small"
      >
        <div className="p-4">
          <h1 className="text-xl">Export all files for {location.name}</h1>
          <div>
            Click the “Export Files” button below to download all of the files
            shown in the Documents table for {location.name}.
          </div>
          <div className="flex justify-end space-x-2 mt-8">
            <CTA variant="sky-shadow" onClick={() => setExportAllFiles(false)}>
              Cancel
            </CTA>
            <CTA
              id="remove-line-item-product"
              variant="coral-shadow"
              type="submit"
              target="_blank"
              to={`/intelligence/${account.id}/locations/${location.id}/location-documents/download-zip/`}
            >
              Export files
            </CTA>
          </div>
        </div>
      </Modal>
      <Modal
        isOpen={!!contractDocumentsModal}
        onClose={() => setContractDocumentsModal(null)}
        manager={true}
        size="medium-small"
      >
        <div className="p-4">
          <h1 className="text-xl">
            Documents for {contractDocumentsModal?.name}
          </h1>
          <div
            className="space-y-4 max-h-96 overflow-y-auto pr-2"
            key={contractDocumentsModal?.id}
          >
            {contractDocumentsModal?.documents.map(doc => (
              <DocumentCard
                key={`${doc.id}-${doc.created_at}`}
                document={{ ...doc, status: "uploaded" }}
                onCardClick={e => {
                  window.open(`/images/${doc.file_id}`, "_blank");
                }}
                isContract={true}
              />
            ))}
          </div>
        </div>
      </Modal>
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
          },
          {
            name: "Documents",
            to: `/intelligence/${account.id}/locations/${location.id}/location-documents`,
            active: true,
          },
        ]}
        title={
          <>
            Documents: <br /> {location.name}
          </>
        }
        description={`View the documents specific to ${location.name}, including individual order forms attached to corporate agreements and MSAs.`}
        ellipsisItems={dropdownItems}
      />
      <IntelligenceFilter
        filterBar={{
          inputPlaceholder: "Search contract name or vendor name",
        }}
        onFilter={handleFilter}
        currentFilters={currentFilters}
        modalFilters={[
          {
            type: "MultiAutocomplete",
            name: "vendors",
            label: "Vendors",
            options: vendors,
          },
          {
            type: "DateRange",
            name: "current_term_end_date",
            label: "Current Term End Date Range",
          },
          {
            type: "MultiSelect",
            name: "contract_status",
            label: "Contract Status",
            options: Object.values(ContractStatus).map(status => ({
              value: status,
              label: status,
            })),
          },
        ]}
      />

      <Table
        cols={[
          {
            label: "Vendor Name",
            name: "manager_account_vendor.vendor.name",
            sortable: true,
            renderer: (contract: (typeof items)[number]) => (
              <div onClick={e => e.stopPropagation()}>
                <Link
                  to={`/intelligence/${account.id}/vendors/${contract.manager_account_vendor_id}`}
                  className="text-sky-600"
                >
                  {contract.manager_account_vendor.vendor.name}
                </Link>
              </div>
            ),
          },
          {
            label: "Contract Name",
            name: "name",
            sortable: true,
            renderer: (contract: (typeof items)[number]) => (
              <div onClick={e => e.stopPropagation()}>
                <Link
                  to={`/intelligence/${account.id}/contract/${contract.id}/details`}
                  className="flex items-center"
                >
                  {contract.name}
                  <Button color="transparent">
                    <ArrowTopRightOnSquareIcon className="h-4 w-4" />
                  </Button>
                </Link>
              </div>
            ),
          },
          {
            label: "Current Term Ends",
            name: "current_term_end_date",
            sortable: true,
            renderer: (contract: (typeof items)[number]) => {
              return (
                <div
                  className={
                    dayjs.utc(contract.current_term_end_date).toDate() <
                    new Date()
                      ? "text-red-500"
                      : ""
                  }
                >
                  {contract.current_term_end_date
                    ? dayjs
                        .utc(contract.current_term_end_date)
                        .format("MMM D, YYYY")
                    : "No Data"}
                </div>
              );
            },
          },
          {
            label: "Documents",
            name: "document_files",
            renderer: (contract: (typeof items)[number]) => {
              if (!contract.documents?.length) return "--";

              return (
                <CTA>
                  View {contract.documents.length} file
                  {contract.documents.length != 1 && "s"}
                </CTA>
              );
            },
          },
          {
            label: "Status",
            name: "status",
            renderer: (contract: (typeof items)[number]) => {
              const status = canceledItems.includes(contract)
                ? ContractLineItemStatus.Canceled
                : ContractLineItemStatus.Active;
              return (
                <StatusChip
                  status={status}
                  model="ContractLineItemStatus"
                  label={status}
                />
              );
            },
          },
        ]}
        data={items}
        showAddButton={false}
        showSelectBox={false}
        onClickRow={onClickRow ?? (() => {})}
        onOrderBy={onOrderBy}
        allowSorting={true}
        alignment="middle"
        rowIdPrefix="contract"
        disabledRows={canceledItems}
      />

      <Pagination
        resultsText={`${items.length} out of ${itemsCount} results`}
        pageNumbers={Array.from(
          { length: Math.ceil(itemsCount / pagination.perPage) },
          (_, i) => i + 1
        )}
        currentPage={pagination.page}
        totalPages={Math.ceil(itemsCount / pagination.perPage)}
        handleCallback={handlePageChange}
      />
    </>
  );
}
