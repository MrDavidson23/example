import { EnvelopeOpenIcon } from "@heroicons/react/24/outline";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { CTA } from "~/components/cta.component";

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  return {};
};

export default function CheckoutSuccessRoute() {
  return (
    <div className="flex justify-center">
      <div className="max-w-3xl bg-white text-center rounded-3xl border border-gray-100 p-12 mt-6">
        <EnvelopeOpenIcon className="h-12 inline mb-6" />
        <h1 className="text-3xl">Your checkout has been canceled.</h1>
        <p className="my-4">Come back anytime to subscribe.</p>
        <p className="mt-6">
          <CTA to={`/vendor`}>Go to Vendor Portal</CTA>
        </p>
      </div>
    </div>
  );
}
