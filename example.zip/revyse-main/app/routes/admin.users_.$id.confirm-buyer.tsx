import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { jsonWithSuccess } from "remix-toast";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";

const ConfirmBuyerForm = z.object({
  confirmed: z.string().transform(val => val === "true"),
});

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const form = await request.formData();
  const { userService } = await WebDIContainer();
  const fields = {
    confirmed: form.get("confirmed"),
  };
  const validation = ConfirmBuyerForm.safeParse(fields);
  if (!validation.success) {
    console.error(JSON.stringify(validation.error.issues));
    throw new Error("Invalid form");
  }

  await userService.updateBuyerVerifiedUserRole({
    userId: params.id!,
    verified: validation.data.confirmed,
  });

  return jsonWithSuccess(
    null,
    validation.data.confirmed ? "Buyer confirmed" : "Buyer revoked"
  );
};

export const loader = async ({ params, request }: LoaderFunctionArgs) => {
  return { json: { hello: "world" } };
};
