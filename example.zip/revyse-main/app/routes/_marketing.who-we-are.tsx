import type { ActionFunctionArgs, MetaFunction } from "@remix-run/node";
import { redirect, json } from "@remix-run/node";
import { Form, Link, useActionData } from "@remix-run/react";
import { z } from "zod";
import { CTA } from "~/components/cta.component";
import { ContentStripe } from "~/components/discovery/content-stripe.component";
import { CrudTextField } from "~/components/form/crud-form.component";
import { CrudTextAreaField } from "~/components/form/textarea.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { castFormFields } from "~/utils/type.utils";
import { NonEmptyString } from "~/utils/validation.utils.server";

type JsonData = {
  fields?: Record<string, string | null> | null;
  errors?: Record<string, string[] | null>;
};

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  return [
    { title: "Revyse | Meet the Team" },
    {
      name: "description",
      content:
        "Get to know the team at Revyse, where our mission is to make discovering, buying, and managing multifamily software easier for everyone. ",
    },
  ];
};

export async function action({ request }: ActionFunctionArgs) {
  const { customerSupportService } = await WebDIContainer();

  const ConnectForm = z.object({
    first_name: NonEmptyString,
    last_name: NonEmptyString,
    email: NonEmptyString.email(),
    company: NonEmptyString,
    message: NonEmptyString,
    honeypot: z.string().max(0),
  });

  const form = await request.formData();

  const fields = {
    first_name: form.get("first_name"),
    last_name: form.get("last_name"),
    email: form.get("email"),
    company: form.get("company"),
    message: form.get("message"),
    honeypot: form.get("honeypot"), // Help us fight spam!
  };
  const validation = ConnectForm.safeParse(fields);

  if (validation.success) {
    await customerSupportService.sendCSEmail(
      "New Connect Request",
      JSON.stringify(validation.data)
    );
    throw redirect("/connect-success");
  }

  return json<JsonData>(
    {
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    { status: 400 }
  );
}

export async function loader() {
  return json({});
}

export default function WhoWeAreRoute() {
  const actionData = useActionData<typeof action>();
  return (
    <>
      <div className="bg-sky-500 flex justify-center md:py-12 py-12 px-6 bg-center bg-contain bg-no-repeat hero-stripe relative">
        <div className="max-w-3xl text-white text-center">
          <h1 className="font-bold">
            We should probably get better at selling ourselves
          </h1>
          <p className="my-6 text-lg text-white md:px-24">
            But we’ve been too busy connecting multifamily vendors and
            operators, helping the best products and services get found.
          </p>
          <img
            src="/assets/cloud-1.png"
            className="absolute bottom-0 md:right-16 right-28 xl:mr-32 h-24 w-auto hidden md:block"
            alt="cloud"
            height="206"
            width="414"
          />
          <img
            src="/assets/cloud-2.png"
            className="absolute -bottom-4 md:right-2 xl:mr-36 h-16 w-auto hidden md:block"
            alt="cloud"
            height="70"
            width="169"
          />
        </div>
      </div>
      <ContentStripe
        color="white"
        tag="OUR MISSION"
        heading=" Make discovering, buying, and managing multifamily software easier for everyone"
        imageUrl="/assets/buy-manage-3.png"
        layout="left"
        imageWidth="2000"
        imageHeight="1500"
      >
        <p>
          Moving into a new home should feel more like winning the lottery and
          less like a trip to the DMV, but legacy systems and outdated software
          have weighed the real estate industry down. Constrained by manual
          processes and mediocre integrations, owners and operators have little
          time left to implement the right tech and tools needed to level-up the
          renter experience.
        </p>
        <p className="my-6">Revyse exists to change that. </p>

        <p>
          We're here to help vendors drop new products like they're hot, to free
          up property managers to deliver earth-shatteringly great customer
          service, and to help renters find a place to call home, hassle-free.
        </p>
      </ContentStripe>
      <ContentStripe
        color="blue"
        tag="WHAT WE DO"
        heading="Helping the multifamily industry build better technology stacks"
        imageUrl="/assets/mobile-graphic-tilted.png"
        layout="right"
        imageWidth="400"
        imageHeight="300"
      >
        <p>
          Software buying today has gone mainstream, no longer confined to the
          IT department. From Ops to Marketing to HR, business leaders across
          the C-Suite are under pressure to select the right vendors and run
          successful software implementation projects on time, on scope, and on
          budget.
        </p>
        <p className="my-6">
          Your business has processes to disrupt and prospects to reach, and
          Revyse is here to help. We’ve created the multifamily industry’s
          easiest vendor discovery and review platform that companies of every
          size can use to find the best software and services. We’ll help you
          select a vendor that meets all your requirements, negotiate the best
          pricing and terms, and keep track of your software contract renewals
          with ease. Your team gets the tools they need, and you get to rest
          easy.
        </p>
      </ContentStripe>

      <div className={`flex justify-center md:py-12 py-8 bg-white`}>
        <div className="max-w-2xl flex-grow md:px-8 px-4 flex flex-col items-center relative">
          <p className="uppercase font-bold text-sm mb-4">WHO WE ARE</p>
          <h2 className="text-3xl font-bold mb-8">Meet the team</h2>
          <img
            src="/assets/bobbi-steward.png"
            alt="Bobbi Steward"
            className="w-72 mb-6"
            width="800"
            height="800"
          />
          <h2 className="text-3xl font-bold mb-2">Bobbi Steward</h2>
          <p className="uppercase font-bold text-sm mb-4">PRODUCT</p>
          <Link to="https://www.linkedin.com/in/bobbisteward/" target="_blank">
            <img
              src="/assets/linkedin-icon.png"
              alt="linkedin"
              className="w-8"
              width="32"
              height="32"
            />
          </Link>
          <div>
            <p className="my-4">
              Maybe it is the constant motion. Or the always-evolving tech. But
              Bobbi says that her favorite thing about her work is that it’s the
              perfect mashup of science and heart. With a few well-chosen words
              and a couple lines of code, she can influence the decisions needed
              to change the world.{" "}
            </p>

            <p>
              One part tech-nerd, one part storyteller, Bobbi has worked in real
              estate marketing and technology for the last decade, partnering
              with start-ups, software vendors, marketplaces, and property
              management owners and operators, to help renters and home buyers
              find a place to call home.
            </p>
          </div>
          <img
            src="/assets/cloud-2.png"
            className="absolute -right-48 -bottom-20 h-24 w-auto hidden md:block"
            alt="cloud"
            height="70"
            width="169"
          />
          <img
            src="/assets/cloud-1.png"
            className="absolute -left-48 -top-32 h-24 w-auto hidden md:block"
            alt="cloud"
            height="206"
            width="414"
          />
        </div>
      </div>

      <div className={`flex justify-center md:py-12 py-8 bg-sky-50`}>
        <div className="max-w-2xl flex-grow md:px-8 px-4 flex flex-col items-center relative">
          <img
            src="/assets/jonathan-samples.png"
            alt="Jonathan Samples"
            className="w-72 mb-6 h-auto"
            width="800"
            height="800"
          />
          <h2 className="text-3xl font-bold mb-2">Jonathan Samples</h2>
          <p className="uppercase font-bold text-sm mb-4">TECHNOLOGY</p>
          <Link
            to="https://www.linkedin.com/in/jonathansamples/"
            target="_blank"
          >
            <img
              src="/assets/linkedin-icon.png"
              alt="linkedin"
              className="w-8 h-auto"
              width="32"
              height="32"
            />
          </Link>
          <div>
            <p className="my-4">
              Bridging the gap between well-structured code and revenue-driving
              business strategy, Jonathan helps companies build smarter, more
              efficient ways to connect people with the places they call home.
            </p>

            <p>
              Navigating through the fast-paced proptech and construction tech
              industries, Jonathan has held engineering leadership roles at
              companies like Divvy Homes, G5 and Poly successfully partnering
              with industry frontrunners to reshape the world of real estate
              technology.
            </p>
          </div>
        </div>
      </div>

      <div className={`flex justify-center md:py-12 py-8 bg-white`}>
        <div className="max-w-2xl flex-grow md:px-8 px-4 flex flex-col items-center relative">
          <img
            src="/assets/ben-steward.png"
            alt="Ben Steward"
            className="w-72 mb-6"
          />
          <h2 className="text-3xl font-bold mb-2">Ben Steward</h2>
          <p className="uppercase font-bold text-sm mb-4">REVENUE</p>
          <Link to="https://www.linkedin.com/in/stewardben/" target="_blank">
            <img
              src="/assets/linkedin-icon.png"
              alt="linkedin"
              className="w-8 h-auto"
              width="32"
              height="32"
            />
          </Link>
          <div>
            <p className="my-4">
              Revenue-architect meets entrepreneurial-spirit, Ben has made his
              mark in the world of multifamily real estate over the past decade.
            </p>

            <p>
              As VP of Revenue and Head of Strategic Accounts at G5, and most
              recently as Chief Revenue Officer at Funnel Leasing, he formed
              valuable partnerships with industry operators and drove business
              growth for best-in-class SaaS companies. Whether infusing
              voice-of-customer into products and pricing, or developing
              partnerships to accelerate business growth for both sides of the
              contract, Ben brings palpable energy and integrity to the
              multifamily vendor-client relationship.
            </p>
          </div>
          <img
            src="/assets/cloud-2.png"
            className="absolute -right-48 -bottom-20 h-24 w-auto hidden md:block"
            alt="cloud"
            height="70"
            width="169"
          />
          <img
            src="/assets/cloud-1.png"
            className="absolute -left-48 -top-32 h-24 w-auto hidden md:block"
            alt="cloud"
            height="206"
            width="414"
          />
        </div>
      </div>

      <div className={`flex justify-center md:py-16 py-8 bg-sky-50`}>
        <div className="max-w-2xl flex-grow md:px-8 px-4 flex flex-col items-center relative">
          <h2 className="text-3xl font-bold mb-8 text-center">
            Connect with Revyse
          </h2>
          <Form method="post" className="w-full">
            <div className="grid grid-cols-2 gap-4 w-full">
              <div>
                <CrudTextField
                  field={{
                    name: "first_name",
                    label: "First Name *",
                    type: "text",
                    errors: actionData
                      ? actionData.errors?.first_name ?? []
                      : [],
                    defaultValue:
                      (actionData?.fields?.first_name as string) ?? "",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    name: "last_name",
                    label: "Last Name *",
                    type: "text",
                    errors: actionData
                      ? actionData.errors?.last_name ?? []
                      : [],
                    defaultValue: actionData?.fields?.last_name ?? "",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    name: "email",
                    label: "Email *",
                    type: "text",
                    errors: actionData ? actionData.errors?.email ?? [] : [],
                    defaultValue: actionData?.fields?.email ?? "",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    name: "company",
                    label: "Company *",
                    type: "text",
                    errors: actionData ? actionData.errors?.company ?? [] : [],
                    defaultValue: actionData?.fields?.company ?? "",
                  }}
                />
              </div>
              <div className="col-span-2">
                <CrudTextAreaField
                  field={{
                    name: "message",
                    label: "Message *",
                    type: "textarea",
                    errors: actionData ? actionData.errors?.message ?? [] : [],
                    defaultValue: actionData?.fields?.message ?? "",
                    rows: 4,
                  }}
                />
              </div>
              <div
                style={{ position: "absolute", left: "-5000px" }}
                aria-hidden="true"
              >
                <input
                  type="text"
                  name="honeypot"
                  tabIndex={-1}
                  defaultValue=""
                />
              </div>
              <CTA className="col-span-2" fillStyle="outline" type="submit">
                Submit
              </CTA>
            </div>
          </Form>
        </div>
      </div>
    </>
  );
}
