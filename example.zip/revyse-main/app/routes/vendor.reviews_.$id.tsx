import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { redirect, json } from "@remix-run/node";
import {
  Form,
  useActionData,
  useLoaderData,
  useNavigation,
} from "@remix-run/react";
import dayjs from "dayjs";
import { isNil } from "lodash";
import { useEffect } from "react";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { z } from "zod";
import { Button } from "~/components/button.component";
import { CrudTextAreaField } from "~/components/form/textarea.component";
import { PortalPage } from "~/components/portal-page.component";
import { Review } from "~/components/review-component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assert, assertAuthorized } from "~/utils/assert.utils.server";
import { assertAuthenticatedOrRedirect } from "~/utils/auth.utils.server";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import { tierHasPermission } from "~/utils/permission.utils";
import { castFormFields } from "~/utils/type.utils";
import { NonEmptyString } from "~/utils/validation.utils.server";

const ReviewForm = z.object({
  response: NonEmptyString,
});

export const action = async ({
  params: { id },
  request,
}: ActionFunctionArgs) => {
  const user = await assertAuthenticatedOrRedirect(request);

  const form = await request.formData();

  const fields = {
    response: form.get("response"),
  };
  const validation = ReviewForm.safeParse(fields);

  if (validation.success) {
    const { reviewService } = await WebDIContainer();
    try {
      await reviewService.updateReviewResponse(
        id!,
        validation.data.response,
        user.id
      );
    } catch (error) {
      console.log(error);
      if (error instanceof Error) {
        if (error.message.includes("Unauthorized")) {
          assertAuthorized(false, error.message);
        }
        if (error.message.includes("Review not found")) {
          throw redirect("/vendor/reviews");
        }
        assert(false, "Unknown error");
      }
    }

    return jsonWithSuccess(
      {
        success: true,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      },
      "Response submitted"
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return jsonWithError(
    { success: false, fields: castFormFields(fields), errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { reviewService } = await WebDIContainer();
  const user = await assertAuthenticatedOrRedirect(request);
  const review = await reviewService.getReviewWithHelpfuls({
    reviewId: params.id,
  });

  if (isNil(review)) {
    throw redirect("..");
  }
  const tier = review.product.subscriptions[0]?.stripe_price.product.tier;
  return json({ review, user, tier });
}

export default function AdminUserIdRoute() {
  const actionData = useActionData<typeof action>();
  const { review, user, tier } = useLoaderData<typeof loader>();
  const navigation = useNavigation();

  useEffect(() => {
    if (navigation.state == "idle") {
      window.scrollTo(0, 0);
    }
  }, [navigation.state]);

  return (
    <>
      <PortalPage
        crumbs={[
          { name: "Reviews", to: "/vendor/reviews", active: false },
          {
            name: `${review.product.title} : ${review.user.first_name} ${review.user.last_name}`,
            to: `/vendor/reviews/${review.id}`,
            active: true,
          },
        ]}
      >
        <div>
          <Review
            product={review.product}
            review={review}
            user={user}
            defaultExpanded={true}
            aggRating={undefined}
          />
          {tierHasPermission(tier, "show_custom_review_questions") && (
            <div className="my-8">
              <div className="font-bold my-4">Custom Questions</div>
              <div className="text-sm grid gap-4">
                {review.product.review_questions[0] && (
                  <div>
                    <div className="font-medium">
                      {review.product.review_questions[0]}
                    </div>
                    <div>{review.custom_question_1}</div>
                  </div>
                )}
                {review.product.review_questions[1] && (
                  <div>
                    <div className="font-medium">
                      {review.product.review_questions[1]}
                    </div>
                    <div>{review.custom_question_2}</div>
                  </div>
                )}
                {review.product.review_questions[2] && (
                  <div>
                    <div className="font-medium">
                      {review.product.review_questions[2]}
                    </div>
                    <div>{review.custom_question_3}</div>
                  </div>
                )}
              </div>
            </div>
          )}
          {tierHasPermission(tier, "respond_to_reviews") && (
            <Form method="post" encType="multipart/form-data">
              <div className="my-8">
                <div className="font-bold mt-4">Response</div>
                <CrudTextAreaField
                  field={{
                    name: "response",
                    label: "",
                    defaultValue:
                      actionData?.fields.response ??
                      review.response ??
                      undefined,
                    errors: actionData?.errors.response ?? [],
                    type: "textarea",
                    rows: 5,
                  }}
                />
                <div className="mb-4 text-sm">
                  Last response:{" "}
                  {review.responded_at
                    ? dayjs(review.responded_at).fromNow()
                    : "--"}
                </div>
                <Button type="submit">Submit Response</Button>
              </div>
            </Form>
          )}
        </div>
      </PortalPage>
    </>
  );
}
