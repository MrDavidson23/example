import { json, type ActionFunctionArgs } from "@remix-run/node";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import { jsonWithError } from "remix-toast";
import { castFormFields } from "~/utils/type.utils";
import { getEnv } from "~/services/env.service.server";
import { Permission } from "~/utils/intelligence-permission.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

type JsonData = {
  success?: boolean;
  fields?: Record<string, string | null> | null;
  errors?: Record<string, string[] | null>;
  url?: string | null;
};

const MB = 1024 * 1024;
const FILE_BYTE_LIMIT = 50 * MB;

const UploadChatFileForm = z.object({
  file: z.string(),
});

export async function action({ params, request }: ActionFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.SendTaskChatMessage],
    }
  );

  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "file", byteLimit: FILE_BYTE_LIMIT },
  ]);

  return uploadChatFile({ form });
}

async function uploadChatFile({ form }: { form: FormData }) {
  const origin = getEnv().REVYSE_UI_ORIGIN;
  const fields = {
    file: form.get("file"),
  };

  const validation = UploadChatFileForm.safeParse(fields);

  if (validation.success) {
    return json<JsonData>({
      success: true,
      url: `${origin}/images/${validation.data.file}`,
      fields: castFormFields(fields),
      errors: issuesByKey([]),
    });
  }
  return jsonWithError<JsonData>(
    {
      success: false,
      url: null,
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    "Error updating document."
  );
}
