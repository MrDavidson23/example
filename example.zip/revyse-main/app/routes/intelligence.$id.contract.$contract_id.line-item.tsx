import { CTA } from "~/components/cta.component";
import { useLoaderData, useNavigate } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import {
  ContractPricingType,
  ContractLineItemStatus,
  ContractStatus,
} from "@prisma/client";
import { Table } from "~/components/intelligence/table.component";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import {
  ContractLineItemPriceCadenceLabels,
  ContractPricingTypeLabels,
} from "~/utils/constants.utils";
import { Tooltip } from "~/components/tooltip.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import StatusChip from "~/components/status-chip.component";
import { useMemo } from "react";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(relativeTime);

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewContractProductsAndContractLineItemsTable],
    }
  );
  const { contractService, managerAccountService } = await WebDIContainer();

  const contractId = params.contract_id!;
  const contract = await contractService.getContractWithLineItemDetails(
    contractId
  );

  if (!contract) {
    throw new Response("Not found", { status: 404 });
  }

  const annualValuePromises = contract.contract_line_items.map(
    async contractLineItem => ({
      ...contractLineItem,
      annual_assigned_value:
        await managerAccountService.getContractLineItemAnnualAssignedValue(
          contractLineItem.id
        ),
    })
  );

  const contractLineItemsWithAnnualValue = await Promise.all(
    annualValuePromises
  );

  return json({
    user,
    account,
    contractLineItems: contractLineItemsWithAnnualValue,
    contract,
  });
}
export default function PriceConfig() {
  const navigate = useNavigate();
  const { contractLineItems, contract, user, account } =
    useLoaderData<typeof loader>();

  // Permissions
  const userCanManageContractLineItem = canDoOnAccount(
    user,
    account,
    Permission.ManageContractLineItem
  );
  const userCanViewContractLineItem = canDoOnAccount(
    user,
    account,
    Permission.ViewContractLineItem
  );

  const contractCanceled = useMemo(
    () => contract.status === ContractStatus.Canceled,
    [contract.status]
  );

  const disabledRows = useMemo(() => {
    return contractLineItems.filter(
      item =>
        contractCanceled || item.status === ContractLineItemStatus.Canceled
    );
  }, [contractLineItems, contractCanceled]);

  return (
    <>
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All contracts",
            to: `/intelligence/${account.id}/contracts`,
          },
          {
            name: contract.name,
            to: `/intelligence/${account.id}/contract/${contract.id}/details`,
          },
          {
            name: "Products and line items",
            to: `/intelligence/${account.id}/contract/${contract.id}/line-item`,
            active: true,
          },
        ]}
        title={
          <>
            All line items:
            <br /> {contract.name}
          </>
        }
        description="Configure and view the line items on this contract. Entering itemized
          price information will allow you to quickly understand spend by product,
          category, and department. To add a new line item, click “Add Line Item”.
          To edit an existing line item, click on the corresponding row."
        buttonsSlot={
          userCanManageContractLineItem && (
            <CTA
              type="button"
              to={`/intelligence/${account.id}/contract/${contract.id}/line-item/new`}
              variant="coral-shadow"
              className="text-sm md:text-base h-min w-fit mt-3 lg:mt-0"
              id="add-line-item-button"
            >
              Add Line Item
            </CTA>
          )
        }
      />
      <div>
        <Table
          cols={[
            { name: "name", label: "Line Item Name" },
            {
              renderer: lineItem => (
                <div className="flex flex-col">
                  <div>
                    {lineItem?.contract_line_item_products.length > 0 ? (
                      <>
                        <div>Products:</div>
                        {lineItem?.contract_line_item_products.map(product => (
                          <div className="font-light" key={product.id}>
                            {product.product.title}
                          </div>
                        ))}
                      </>
                    ) : null}
                    {lineItem?.contract_line_item_fees.length > 0 ? (
                      <>
                        <div>Fees and other charges:</div>
                        {lineItem?.contract_line_item_fees.map(fee => (
                          <div className="font-light" key={fee.id}>
                            {fee.fee?.name}
                          </div>
                        ))}
                      </>
                    ) : null}
                  </div>
                </div>
              ),
              label: "Products Included",
            },
            {
              renderer: lineItem => (
                <div className="flex items-center space-x-2">
                  <div className="font-light">
                    {lineItem?.contract_line_item_products.length > 0 ||
                    lineItem?.contract_line_item_fees.length > 0 ? (
                      <div>
                        <div className="text-md font-semibold">
                          {lineItem.price.toLocaleString(undefined, {
                            style: "currency",
                            currency: "USD",
                          })}{" "}
                          /{" "}
                          {lineItem.cadence
                            ? ContractLineItemPriceCadenceLabels[
                                lineItem.cadence
                              ]
                            : ""}{" "}
                          /{" "}
                          {lineItem.pricing_type
                            ? `${
                                ContractPricingTypeLabels[lineItem.pricing_type]
                              }
                              ${
                                lineItem.pricing_type ===
                                ContractPricingType.PerSeat
                                  ? ` (${lineItem.seats_number})` // Show '(seats_number)' if pricing type is per seat
                                  : ""
                              }`
                            : ""}
                        </div>
                        {lineItem?.contract_line_item_products.length +
                          lineItem?.contract_line_item_fees.length >
                          1 && (
                          <div>
                            {lineItem?.contract_line_item_products.map(
                              product => (
                                <div key={product.id}>
                                  {product.product.title}:{" "}
                                  <b>${product.price}</b>{" "}
                                </div>
                              )
                            )}
                            {lineItem?.contract_line_item_fees.map(fee => (
                              <div key={fee.id}>
                                {fee.fee?.name}: <b>${fee.price}</b>{" "}
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                    ) : (
                      <div>$0</div>
                    )}
                  </div>
                </div>
              ),
              label: "Price Value",
            },
            {
              renderer: lineItem => (
                <div className="flex items-center space-x-2">
                  <div className="font-light">
                    {lineItem.is_corporate_only
                      ? lineItem._count.contract_line_item_locations > 0
                        ? lineItem._count.contract_line_item_locations
                        : "Corporate"
                      : lineItem._count.contract_line_item_locations}
                  </div>
                </div>
              ),
              label: "Contracted Locations",
            },
            {
              renderer: lineItem => {
                return (
                  <div className="flex items-center space-x-2 font-normal">
                    {lineItem.annual_assigned_value.toLocaleString(undefined, {
                      style: "currency",
                      currency: "USD",
                    })}
                  </div>
                );
              },
              name: "annual_assigned_value",
              label: (
                <Tooltip
                  position="left"
                  text="The estimated annual value of this line item as configured today."
                >
                  Est. Annual Value
                </Tooltip>
              ),
            },
            {
              label: "Status",
              name: "status",
              renderer: lineItem => {
                const status = contractCanceled
                  ? ContractLineItemStatus.Canceled
                  : lineItem.status;

                return (
                  <div className="flex flex-col justify-center items-center w-min">
                    <StatusChip
                      model="ContractLineItemStatus"
                      status={status}
                      label={status}
                    />
                    {lineItem.status === ContractLineItemStatus.Canceled &&
                      lineItem.canceled_at && (
                        <div className="text-xs mt-2">
                          {dayjs
                            .utc(lineItem.canceled_at)
                            .format("MMM D, YYYY")}
                        </div>
                      )}
                  </div>
                );
              },
            },
          ]}
          data={contractLineItems}
          addButtonLabel="add line item"
          handleCallback={() => {
            userCanManageContractLineItem && navigate(`./new`);
          }}
          disabledRows={disabledRows}
          showAddButton={true}
          showSelectBox={false}
          onClickRow={contractLineItem =>
            userCanViewContractLineItem &&
            navigate(
              `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem.id}/summary`
            )
          }
        ></Table>
      </div>
    </>
  );
}
