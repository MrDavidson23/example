import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { CTA } from "~/components/cta.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Permission } from "~/utils/intelligence-permission.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import React, { useMemo, useState } from "react";
import { IntelligenceDetailsSection } from "~/components/intelligence/intelligence-details-section.component";
import { ContractPricingType, LocationNoticeStatus } from "@prisma/client";
import { UserWithEmail } from "~/components/intelligence/location-notices/user-with-email.component";
import {
  LocationNoticeLinkPrefixes,
  LocationNoticeType,
} from "~/utils/location-notice.utils";
import { TrashIcon } from "@heroicons/react/24/outline";
import { Button } from "~/components/button.component";
import { ConfirmDeleteModal } from "~/components/modals/confirm-delete-modal.component";
import { redirectWithSuccess } from "remix-toast";
import { CanDo } from "~/components/intelligence/can-do.component";
import { LocationNoticeServiceTerminationBanner } from "~/components/intelligence/location-notices/location-notice-service-termination-banner";
import {
  ContractLineItemPriceCadenceLabels,
  ContractPricingTypeLabels,
} from "~/utils/constants.utils";
dayjs.extend(utc);

export async function action({ request, params }: ActionFunctionArgs) {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocationNotices],
      locationId: params.location_id,
    }
  );

  const { locationServiceTerminationService } = await WebDIContainer();

  const locationNoticeId = params.location_notice_id!;

  await locationServiceTerminationService.deleteLocationNoticeServiceTermination(
    locationNoticeId
  );

  return redirectWithSuccess(
    `/intelligence/${account.id}/locations/${params.location_id}/notices`,
    "Service termination notice deleted successfully"
  );
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewLocationNotices],
      locationId: params.location_id,
    }
  );

  const { locationService, locationServiceTerminationService } =
    await WebDIContainer();

  const location = await locationService.getLocation(params.location_id!);

  if (!location) {
    throw new Response("Location not found", { status: 404 });
  }

  const locationNoticeId = params.location_notice_id!;

  const locationNotice =
    await locationServiceTerminationService.getLocationServiceTermination(
      locationNoticeId,
      location.id,
      user,
      account,
    );

  if (!locationNotice) {
    throw new Response("Location notice not found", { status: 404 });
  }

  return json({
    account,
    location,
    locationNotice,
  });
}

export default function LocationServiceTerminationNoticeSummary() {
  const { account, location, locationNotice } = useLoaderData<typeof loader>();

  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  const completeLink = useMemo(
    () =>
      `/intelligence/${account.id}/locations/${location.id}/notices/${
        locationNotice.id
      }/${
        LocationNoticeLinkPrefixes[
          LocationNoticeType.LocationServiceTermination
        ]
      }/${locationNotice.step.toLocaleLowerCase()}`,
    [account, location, locationNotice]
  );

  const isUpdatedServiceTerminationNotice = useMemo(
    () => locationNotice.original_location_notice_id !== null,
    [locationNotice]
  );

  const sendUpdatedNoticeLink = useMemo(
    () =>
      `/intelligence/${account.id}/locations/${location.id}/notices/new/${
        LocationNoticeLinkPrefixes[
          LocationNoticeType.LocationServiceTermination
        ]
      }/details?original_location_notice_id=${locationNotice.id}`,
    [account, location, locationNotice]
  );

  return (
    <>
      <ConfirmDeleteModal
        isOpen={!!confirmDeleteOpen}
        onClose={() => setConfirmDeleteOpen(false)}
        submitOnConfirm={true}
        title="Delete Service Termination Notice"
        message="Are you sure you want to permanently delete this service termination notice?"
      />
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
          },
          {
            name: "Notices",
            to: `/intelligence/${account.id}/locations/${location.id}/notices`,
          },
          {
            name: isUpdatedServiceTerminationNotice
              ? "Updated service termination notice"
              : "Service termination notice",
            to: `/intelligence/${account.id}/locations/${location.id}/notices/${
              locationNotice.id
            }/${
              LocationNoticeLinkPrefixes[
                LocationNoticeType.LocationServiceTermination
              ]
            }/${locationNotice.step.toLocaleLowerCase()}`,
            active: true,
          },
        ]}
        title={
          isUpdatedServiceTerminationNotice ? (
            <>
              Updated service termination notice details: <br /> {location.name}
            </>
          ) : (
            <>
              Service termination notice details: <br /> {location.name}
            </>
          )
        }
        buttonsSlot={
          <CanDo permission={Permission.ManageLocationNotices}>
            {locationNotice.status === LocationNoticeStatus.Sent ? (
              <CTA to={sendUpdatedNoticeLink}>Send Updated Notice</CTA>
            ) : (
              <>
                <Button
                  color="transparent"
                  onClick={() => setConfirmDeleteOpen(true)}
                  className="px-0"
                >
                  <TrashIcon className="h-6 w-6" />
                </Button>
                <CTA to={completeLink}>Complete Notice Now</CTA>
              </>
            )}
          </CanDo>
        }
      />
      <LocationNoticeServiceTerminationBanner
        locationNoticeServiceTermination={locationNotice}
      />
      <main className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min gap-y-40 divide-y divide-gray-200">
        <IntelligenceDetailsSection title="Notice Information">
          <div className="grid grid-cols-1 gap-x-4 gap-y-4 md:grid-cols-3 md:gap-x-6 md:gap-y-6">
            <div className="col-span-1 font-medium">Date of Activity</div>
            <div className="col-span-1 md:col-span-2">
              {dayjs.utc(locationNotice.status_updated_at).format("MM/DD/YYYY")}
            </div>

            <div className="col-span-1 font-medium">
              {locationNotice.status === LocationNoticeStatus.Sent
                ? "Sent by"
                : "Created by"}
            </div>
            <div className="col-span-1 md:col-span-2">
              <UserWithEmail
                email={locationNotice.manager_account_role.user.email}
                name={`${locationNotice.manager_account_role.user.first_name} ${locationNotice.manager_account_role.user.last_name}`}
              />
            </div>
          </div>
        </IntelligenceDetailsSection>
        <IntelligenceDetailsSection
          title="Service Termination Information"
          className="pt-10"
        >
          <div className="grid grid-cols-1 gap-x-4 gap-y-4 md:grid-cols-3 md:gap-x-6 md:gap-y-6">
            <div className="col-span-1 font-medium">Vendor Name</div>
            <div className="col-span-1 md:col-span-2">
              {locationNotice.manager_account_vendor.vendor.name}
            </div>

            <div className="col-span-1 font-medium">Contact</div>
            <div className="col-span-1 md:col-span-2">
              <UserWithEmail
                email={locationNotice.contact_email}
                name={locationNotice.contact_name}
              />
            </div>

            <div className="col-span-1 font-medium">
              Requested Service Termination Date
            </div>
            <div className="col-span-1 md:col-span-2">
              {dayjs.utc(locationNotice.termination_date).format("MM/DD/YYYY")}
            </div>

            <div className="col-span-1 font-medium">
              Services Included in Request
            </div>
            <div className="col-span-1 md:col-span-2">
              <div className="grid grid-cols-1 gap-x-4 gap-y-4 md:grid-cols-2">
                {locationNotice.services_to_terminate.map(lineItem => (
                  <React.Fragment key={`${lineItem.id}`}>
                    <div>{lineItem.name}</div>
                    <div>
                      {lineItem.price.toLocaleString(undefined, {
                        style: "currency",
                        currency: "USD",
                      })}{" "}
                      /{" "}
                      {lineItem.cadence
                        ? ContractLineItemPriceCadenceLabels[lineItem.cadence]
                        : ""}{" "}
                      /{" "}
                      {lineItem.pricing_type
                        ? `${ContractPricingTypeLabels[lineItem.pricing_type]}
                              ${
                                lineItem.pricing_type ===
                                ContractPricingType.PerSeat
                                  ? ` (${lineItem.seats_number})` // Show '(seats_number)' if pricing type is per seat
                                  : ""
                              }`
                        : ""}
                    </div>
                  </React.Fragment>
                ))}
              </div>
            </div>

            <div className="col-span-1 md:col-span-3"></div>

            <div className="col-span-1 font-medium">
              Instructions for Final Invoices
            </div>
            <div className="col-span-1 md:col-span-2">
              {locationNotice.termination_instructions ?? "--"}
            </div>

            <div className="col-span-1 font-medium">Task Owner</div>
            <div className="col-span-1 md:col-span-2">
              <UserWithEmail
                email={locationNotice.task_owner.user.email}
                name={`${locationNotice.task_owner.user.first_name} ${locationNotice.task_owner.user.last_name}`}
              />
            </div>
          </div>
        </IntelligenceDetailsSection>
      </main>
    </>
  );
}
