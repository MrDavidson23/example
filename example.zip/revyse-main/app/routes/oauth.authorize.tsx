import type { LoaderFunctionArgs } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { isNil } from "lodash";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { assertAuthorizedOrRedirect } from "../utils/assert.utils.server";
import { getUser } from "../utils/session.server";
import type { OAuthCode } from "@prisma/client";
import { useLoaderData } from "@remix-run/react";

interface OAuthCodeResponse {
  oauthCode: OAuthCode;
}
interface ErrorResponse {
  error: string;
}

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const url = new URL(request.url);
  const response_type = url.searchParams.get("response_type");
  const client_id = url.searchParams.get("client_id") ?? "";
  const redirect_uri = url.searchParams.get("redirect_uri") ?? "";
  const scope = url.searchParams.get("scope");

  const user = await getUser(request);

  assertAuthorizedOrRedirect(
    !isNil(user),
    `/login?redirectTo=${encodeURIComponent(
      `/oauth/authorize?response_type=code&client_id=${client_id}&redirect_uri=${encodeURIComponent(
        redirect_uri
      )}&scope=${scope}`
    )}`
  );

  const { ssoService } = await WebDIContainer();
  const response = await ssoService.generateAuthCode(
    response_type,
    client_id,
    redirect_uri,
    scope,
    user
  );

  if (response.ok) {
    const data = (await response.json()) as OAuthCodeResponse;
    const oauthCode = data.oauthCode as OAuthCode;
    return redirect(`${oauthCode.redirect_uri}?code=${oauthCode.code}`);
  } else {
    const data = (await response.json()) as ErrorResponse;
    return json({ error: data.error });
  }
};

export default function Page() {
  const { error } = useLoaderData<typeof loader>();
  throw new Error(error);
}
