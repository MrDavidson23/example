import { WebDIContainer } from "../di-containers/web.di-container.server";
import type { ActionFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";

export async function action({ request }: ActionFunctionArgs) {
  try {
    const formData = await request.formData();
    const data = {
      client_id: formData.get("client_id"),
      client_secret: formData.get("client_secret"),
      grant_type: formData.get("grant_type"),
      code: formData.get("code"),
      redirect_uri: formData.get("redirect_uri"),
    };
    const { ssoService } = await WebDIContainer();
    const response = await ssoService.generateAccessToken(
      data.client_id?.toString(),
      data.client_secret?.toString(),
      data.grant_type?.toString(),
      data.code?.toString(),
      data.redirect_uri?.toString()
    );
    return response;
  } catch (error) {
    console.error(error);
    return json({ error: error }, { status: 500 });
  }
}
