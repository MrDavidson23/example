import { useCallback, useEffect, useState } from "react";
import { useLoaderData, useNavigate, useSearchParams } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { isEmpty } from "lodash";
import {
  ArrowRightIcon,
  ClipboardDocumentIcon,
  CurrencyDollarIcon,
  InformationCircleIcon,
} from "@heroicons/react/24/outline";
import type { Prisma } from "@prisma/client";
import {
  ManagerAccountVendorBusinessCriticalityRating,
  ManagerAccountVendorStatus,
} from "@prisma/client";
import { CTA } from "~/components/cta.component";
import { Table } from "~/components/intelligence/table.component";
import { Modal } from "~/components/modal.component";
import { Pagination } from "~/components/intelligence/pagination.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { VendorPreferredIcon } from "~/components/intelligence/vendors/preferred-icon.component";
import { VendorGridCard } from "~/components/intelligence/vendors/vendor-grid-card.component";
import StatusChip from "~/components/status-chip.component";
import { ManagerAccountVendorBusinessCriticalityRatingLabels } from "~/utils/constants.utils";
import { Tooltip } from "~/components/tooltip.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { VendorImport } from "~/components/intelligence/vendors/vendor-import.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { CanDo } from "~/components/intelligence/can-do.component";
import { IntelligenceFilter } from "~/components/intelligence/intelligence-filter.component";
import {
  getFiltersFromSearchParams,
  getPaginationFromSearchParams,
  updateSearchParams,
} from "~/utils/filtering.utils";
dayjs.extend(utc);

const PER_PAGE = "12";

export async function loader({ request, params }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewVendorsTable],
    }
  );
  const { managerAccountVendorService } = await WebDIContainer();

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);

  const filtersFromParams = getFiltersFromSearchParams(search, [
    "locationQuantity",
    "annualSpend",
    "vendorStatus",
  ]);

  const pagination = getPaginationFromSearchParams(search, {
    perPage: Number(PER_PAGE),
  });

  const orderBy = search.getAll("orderBy").reduce((obj, value) => {
    const [key, direction] = value.split(":");
    obj[key] = direction as Prisma.SortOrder;
    return obj;
  }, {} as Record<string, Prisma.SortOrder>);

  // Default order by
  if (isEmpty(orderBy)) {
    orderBy["vendor_name"] = "asc";
  }

  const locationsQuantityFilter = !isEmpty(filtersFromParams.locationQuantity)
    ? ((filtersFromParams.locationQuantity as string[]).map(range => {
        const [min, max] = range.split("-").map(Number);

        return [min, max ?? Number.MAX_SAFE_INTEGER];
      }) as [number, number][])
    : undefined;

  const { total_count, rows: vendorsTableData } =
    await managerAccountVendorService.getManagerAccountVendorsTableData(
      user,
      account,
      {
        query: filtersFromParams.searchQuery as string | undefined,
        status: filtersFromParams.vendorStatus as
          | ManagerAccountVendorStatus[]
          | undefined,
        is_preferred:
          filtersFromParams.preferredVendor === "true" ? true : undefined,
        business_criticality_rating:
          filtersFromParams.businessCriticalityRating as
            | ManagerAccountVendorBusinessCriticalityRating
            | undefined,
        location_count_ranges: locationsQuantityFilter,
        annual_value_start: filtersFromParams.annualSpend?.[0]
          ? parseInt(filtersFromParams.annualSpend[0])
          : undefined,
        annual_value_end: filtersFromParams.annualSpend?.[1]
          ? parseInt(filtersFromParams.annualSpend[1])
          : undefined,
      },
      pagination.perPage,
      (pagination.page - 1) * pagination.perPage,
      orderBy
    );

  return json({
    user,
    account,
    vendors: vendorsTableData ?? [],
    page: pagination.page,
    vendorsCount: total_count,
  });
}

export default function Vendors() {
  const navigate = useNavigate();
  const { user, account, vendors, page, vendorsCount } =
    useLoaderData<typeof loader>();
  const [, setSearchParams] = useSearchParams();
  const [importGLModalOpen, setImportGLModalOpen] = useState(false);
  const [perPage] = useState(parseInt(PER_PAGE));

  const [viewMode, setViewMode] = useState<"grid" | "list" | undefined>(
    undefined
  );

  const handleAddButton = () => {
    navigate(`/intelligence/${account.id}/vendors/new/`);
  };

  const handlePageChange = (newPage: number) => {
    setSearchParams(oldSearchParams => {
      updateSearchParams(oldSearchParams, { page: String(newPage) });
      return oldSearchParams;
    });
  };

  const onOrderBy = useCallback(
    (value: Record<string, string>) => {
      const newOrderBy = Object.entries(value).map(
        ([key, value]) => `${key}:${value}`
      );
      setSearchParams((oldSearchParams: any) => ({
        ...Object.fromEntries(oldSearchParams),
        orderBy: newOrderBy,
      }));
    },
    [setSearchParams]
  );

  let totalPages = Math.ceil(vendorsCount / perPage);
  if (totalPages === 0) {
    totalPages = 1;
  }
  const pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);
  const resultsText = `${vendors.length} out of ${vendorsCount} results`;

  useEffect(() => {
    setViewMode(
      (window.localStorage.getItem("userPreferredViewMode") as
        | "grid"
        | "list") ?? "list"
    );
  }, []);

  // Permissions
  const userCanManageVendors = canDoOnAccount(
    user,
    account,
    Permission.ManageVendors
  );

  return (
    <>
      <Modal
        isOpen={importGLModalOpen}
        onClose={() => setImportGLModalOpen(false)}
        size="medium"
        manager={true}
      >
        <VendorImport
          managerAccountId={account.id}
          onCancel={() => setImportGLModalOpen(false)}
        />
      </Modal>
      <div className="space-y-8 pb-12">
        <IntelligenceScreenHeader
          title="All vendors"
          description="View and manage all vendors associated with this account."
          buttonsSlot={
            <CanDo permission={Permission.ManageVendors}>
              <CTA
                id="add-vendor-button"
                type="button"
                to={`/intelligence/${account.id}/vendors/new/`}
                variant="coral-shadow"
              >
                Add Vendor
              </CTA>
            </CanDo>
          }
          ellipsisItems={[
            {
              label: "Import Vendors from General Ledger",
              onClick: () => setImportGLModalOpen(true),
            },
            {
              label: `${viewMode === "list" ? "Grid" : "List"} View`,
              onClick: () => {
                setViewMode(viewMode === "list" ? "grid" : "list");
                window.localStorage.setItem(
                  "userPreferredViewMode",
                  viewMode === "list" ? "grid" : "list"
                );
              },
            },
          ]}
        />
        <IntelligenceFilter
          handleOnSearchParams={true}
          modalFilters={[
            {
              label: "# of Locations Assigned",
              name: "locationQuantity",
              type: "MultiSelect" as const,
              options: [
                { value: "1-50", label: "1-50" },
                { value: "50-100", label: "50-100" },
                { value: "100-200", label: "100-200" },
                { value: "200-500", label: "200-500" },
                { value: "500", label: "500+" },
              ],
            },
            {
              label: "Annual Spend Range",
              name: "annualSpend",
              type: "NumberRange",
            },

            {
              label: "Business Criticality Rating",
              name: "businessCriticalityRating",
              type: "Select" as const,
              options: Object.values(
                ManagerAccountVendorBusinessCriticalityRating
              ).map(option => ({
                value: option,
                label:
                  ManagerAccountVendorBusinessCriticalityRatingLabels[option],
              })),
            },
            {
              label: "Preferred Vendor Status",
              name: "preferredVendor",
              type: "MultiSelect",
              options: [
                { value: "true", label: "Show preferred vendors only" },
              ],
            },
            {
              label: "Vendor Status",
              name: "vendorStatus",
              type: "MultiSelect",
              options: Object.values(ManagerAccountVendorStatus).map(
                option => ({
                  value: option,
                  label: option,
                })
              ),
            },
          ]}
          filterBar={{
            inputPlaceholder: "Search for a vendor",
          }}
        />
        <div>
          {viewMode === "list" && (
            <Table
              variant="white"
              alignment="middle"
              cols={[
                {
                  renderer: managerAccountVendor => {
                    return (
                      <div className="flex items-center space-x-5">
                        <VendorPreferredIcon
                          vendorName={managerAccountVendor.vendor_name}
                          active={Boolean(managerAccountVendor.is_preferred)}
                          className="h-7"
                        />
                        <div className="bg-white rounded-md border border-gray-200 overflow-hidden hidden lg:block">
                          {managerAccountVendor.vendor_logo_file_id ? (
                            <img
                              className="w-12 h-12"
                              src={`/images/${managerAccountVendor.vendor_logo_file_id}`}
                              alt="Vendor Logo"
                              width="48"
                              height="48"
                            />
                          ) : (
                            <img
                              className="w-12 h-12"
                              src="/assets/default-logo.png"
                              alt="Vendor Logo"
                              width="48"
                              height="48"
                            />
                          )}
                        </div>
                        <div>{managerAccountVendor.vendor_name}</div>
                      </div>
                    );
                  },
                  name: "vendor_name",
                  label: "Vendor",
                  sortable: true,
                },
                {
                  name: "active_contracts_count",
                  label: "Active Contracts",
                  sortable: true,
                },
                {
                  renderer: managerAccountVendor => {
                    return managerAccountVendor.is_corporate_only
                      ? "Corporate"
                      : managerAccountVendor.contracted_locations_count;
                  },
                  label: "Contracted Locations",
                  name: "contracted_locations_count",
                  sortable: true,
                },
                {
                  renderer: managerAccountVendor => {
                    return (
                      <div className="flex items-center space-x-2">
                        <div className="font-light">
                          {managerAccountVendor?.annual_value?.toLocaleString(
                            undefined,
                            {
                              style: "currency",
                              currency: "USD",
                            }
                          )}
                        </div>
                      </div>
                    );
                  },
                  label: (
                    <span>
                      Annual Contract Value
                      <Tooltip
                        position="bottom"
                        text="The current estimated annual value of all active contracts for the vendor as configured today."
                        size="small"
                      >
                        <InformationCircleIcon className="h-5 ml-1 text-gray-400" />
                      </Tooltip>
                    </span>
                  ),
                  name: "annual_value",
                  sortable: true,
                },
                {
                  renderer: managerAccountVendor => {
                    return (
                      <div className="flex items-center space-x-2">
                        <StatusChip
                          model="ManagerAccountVendorStatus"
                          label={managerAccountVendor.status}
                          status={managerAccountVendor.status}
                        />
                      </div>
                    );
                  },
                  label: "Status",
                },
                {
                  renderer: () => {
                    return (
                      <div className="text-sky-500 text-bold">
                        <ArrowRightIcon className="h-5 w-5 ml-4" />
                      </div>
                    );
                  },
                  label: "",
                },
              ]}
              data={vendors}
              addButtonLabel="add vendor"
              showAddButton={userCanManageVendors}
              handleCallback={handleAddButton}
              showSelectBox={false}
              onOrderBy={onOrderBy}
              onClickRow={vendor =>
                navigate(`/intelligence/${account.id}/vendors/${vendor.id}`)
              }
            ></Table>
          )}
          {viewMode === "grid" && (
            <div className="grid lg:grid-cols-4 gap-8">
              {vendors.map(vendor => (
                <div key={vendor.id}>
                  <VendorGridCard
                    vendor={vendor}
                    onClickCard={() =>
                      navigate(
                        `/intelligence/${account.id}/vendors/${vendor.id}`
                      )
                    }
                    data={[
                      {
                        icon: ClipboardDocumentIcon,
                        label: "Active Contracts",
                        renderer: () => {
                          return (
                            <div className="font-bold lg:text-lg">
                              {vendor.active_contracts_count}
                            </div>
                          );
                        },
                      },
                      {
                        icon: CurrencyDollarIcon,
                        label: "Annual Spend",
                        renderer: () => {
                          return (
                            <div className="flex items-center space-x-2">
                              <div className="font-bold lg:text-lg">
                                {vendor?.annual_value.toLocaleString(
                                  undefined,
                                  {
                                    style: "currency",
                                    currency: "USD",
                                  }
                                )}
                              </div>
                            </div>
                          );
                        },
                      },
                    ]}
                  ></VendorGridCard>
                </div>
              ))}
            </div>
          )}
          <Pagination
            resultsText={resultsText}
            pageNumbers={pageNumbers}
            currentPage={page}
            totalPages={totalPages}
            handleCallback={handlePageChange}
          ></Pagination>
        </div>
      </div>
    </>
  );
}
