import type { VendorValueTags } from "@prisma/client";
import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Link, useLoaderData, useSearchParams } from "@remix-run/react";
import { useMemo } from "react";
import { DiscoveryHeader } from "~/components/discovery/discovery-header.component";
import { CrudCheckboxField } from "~/components/form/crud-form.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { FeatureFlag } from "~/services/feature-flag.service.server";
import { VendorValueTagsLabels } from "~/utils/constants.utils";

const PRODUCT_PERKS = {
  promos: "Promos and discounts",
  demos: "Product demos",
  pricing: "Published pricing",
  videos: "Videos",
} as const;

export async function loader({ request }: LoaderFunctionArgs) {
  const { vendorService, featureFlagService } = await WebDIContainer();

  const { search } = new URL(request.url);
  const searchParams = new URLSearchParams(search);

  const valueTags =
    (searchParams.get("valueTags")?.split(",") as VendorValueTags[]) ?? [];
  const productPerks =
    (searchParams
      .get("productPerks")
      ?.split(",") as (keyof typeof PRODUCT_PERKS)[]) ?? [];

  const vendors = await vendorService.getVendorsForAllVendorsPage({
    valueTags,
    productPerks,
  });

  const vendorsByLetters = vendors.reduce((acc, vendor) => {
    const digit = /^\d/.test(vendor.name);
    const letter = digit ? "#" : vendor.name[0].toUpperCase();
    if (!acc[letter]) {
      acc[letter] = [];
    }
    acc[letter].push(vendor);
    return acc;
  }, {} as Record<string, typeof vendors>);

  const showFilters = featureFlagService.isEnabled(
    FeatureFlag.ShowVendorFilters
  );

  return json({
    vendorsByLetters,
    showFilters,
  });
}

export const meta: MetaFunction<typeof loader> = () => {
  return [
    { title: `View All Multifamily Proptech Vendors` },
    {
      name: "description",
      content: `Explore a wide range of vendors and suppliers on Revyse and shop for multifamily software and services like a pro`,
    },
  ];
};

export default function MarketingVendors() {
  const { vendorsByLetters, showFilters } = useLoaderData<typeof loader>();

  const [searchParams, setSearchParams] = useSearchParams();

  const setFilters = (filters: {
    valueTags: VendorValueTags[];
    productPerks: string[];
  }) => {
    const searchParams = new URLSearchParams();
    if (filters.valueTags.length > 0) {
      searchParams.set("valueTags", filters.valueTags.join(","));
    }
    if (filters.productPerks.length > 0) {
      searchParams.set("productPerks", filters.productPerks.join(","));
    }
    setSearchParams(searchParams);
  };

  const filters = useMemo<{
    valueTags: VendorValueTags[];
    productPerks: string[];
  }>(
    () => ({
      valueTags:
        (searchParams.get("valueTags")?.split(",") as VendorValueTags[]) ?? [],
      productPerks: searchParams.get("productPerks")?.split(",") ?? [],
    }),
    [searchParams]
  );

  return (
    <>
      <DiscoveryHeader
        title="Browse All Vendors"
        description="From marketing and leasing services, to back office software providers, explore the wide range of vendors and suppliers listed on Revyse and shop for multifamily products and services like a pro."
        crumbs={[
          { label: "HOME", link: "/", active: false },
          { label: "ALL VENDORS", link: "/vendors", active: true },
        ]}
      />
      <div className="flex justify-center bg-white w-full">
        <div
          className={`md:px-8 grid grid-cols-4 my-16 ${
            showFilters ? "max-w-7xl" : "w-full lg:w-2/3"
          }`}
        >
          {showFilters && (
            <aside className="col-span-1 lg:w-64 pr-4 hidden md:block">
              <h3 className="text-lg font-bold">Filter By</h3>
              <section className="my-5">
                <h4 className="text-base font-semibold mb-4">Value Tags</h4>
                {Object.entries(VendorValueTagsLabels).map(([key, label]) => (
                  <CrudCheckboxField
                    key={key}
                    field={{
                      name: "filter_by",
                      value: key,
                      label: label,
                      errors: [],
                      description: "",
                      defaultChecked: filters.valueTags.includes(
                        key as VendorValueTags
                      ),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilters({
                          ...filters,
                          valueTags: [
                            ...filters.valueTags,
                            key as VendorValueTags,
                          ],
                        });
                      } else {
                        setFilters({
                          ...filters,
                          valueTags: filters.valueTags.filter(v => v !== key),
                        });
                      }
                    }}
                  />
                ))}
              </section>
              <section className="my-5">
                <h4 className="text-base font-semibold mb-4">Product Perks</h4>
                {Object.entries(PRODUCT_PERKS).map(([key, label]) => (
                  <CrudCheckboxField
                    key={key}
                    field={{
                      name: "filter_by",
                      value: key,
                      label: label,
                      errors: [],
                      description: "",
                      defaultChecked: filters.productPerks.includes(key),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilters({
                          ...filters,
                          productPerks: [...filters.productPerks, key],
                        });
                      } else {
                        setFilters({
                          ...filters,
                          productPerks: filters.productPerks.filter(
                            v => v !== key
                          ),
                        });
                      }
                    }}
                  />
                ))}
              </section>
            </aside>
          )}
          <main
            className={` ${
              showFilters
                ? "md:border-l border-gray-300 pl-6 col-span-3"
                : "col-span-4 px-8 lg:px-0"
            }`}
          >
            {vendorsByLetters &&
              Object.entries(vendorsByLetters).map(([letter, vendors]) => (
                <section key={letter} className="mb-8">
                  <h2 className="text-lg font-bold">{letter}</h2>
                  <ol className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 grid-flow-row">
                    {vendors.map(vendor => (
                      <li key={vendor.id} className="my-2 col-span-1 text-base">
                        <Link
                          to={`/vendors/${vendor.slug}`}
                          className="text-sky-600 font-medium"
                        >
                          {vendor.name}
                        </Link>
                      </li>
                    ))}
                  </ol>
                </section>
              ))}
          </main>
        </div>
      </div>
    </>
  );
}
