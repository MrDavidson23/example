import { json } from "@remix-run/node";
import { Link, useFetcher, useLoaderData } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { CTA } from "~/components/cta.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Permission } from "~/utils/intelligence-permission.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import {
  ContractLineItemPriceCadenceLabels,
  ContractPricingTypeLabels,
  DEFAULT_FORM_ERROR_MESSAGE,
} from "~/utils/constants.utils";
import { Button } from "~/components/button.component";
import { ArrowLeftIcon } from "@heroicons/react/20/solid";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import {
  jsonWithError,
  redirectWithSuccess,
  redirectWithWarning,
} from "remix-toast";
import { IntelligenceFilter } from "~/components/intelligence/intelligence-filter.component";
import { Table } from "~/components/intelligence/table.component";
import { useMemo, useState } from "react";
import { LocationNoticeStatus } from "@prisma/client";
import { WizardModal } from "~/components/modals/wizard-modal.component";
import { isEmpty } from "lodash";
dayjs.extend(utc);

const ContinueForm = z.object({
  servicesIds: z.array(z.string().uuid()),
});

export async function action({ request, params }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocationNotices],
      locationId: params.location_id,
    }
  );

  const { locationServiceTerminationService } = await WebDIContainer();

  const form = await request.formData();

  const intent = form.get("intent") as string;

  const locationNoticeId = params.location_notice_id!;

  if (intent === "continue" || intent === "save-progress") {
    const servicesIds = form.get("servicesIds") as string;

    const fields = {
      servicesIds: !isEmpty(servicesIds) ? servicesIds.split(",") : [],
    };

    const validation = ContinueForm.safeParse(fields);

    if (!validation.success) {
      return jsonWithError(
        { success: false, errors: issuesByKey(validation.error.errors) },
        DEFAULT_FORM_ERROR_MESSAGE
      );
    }

    const managerAccountRoleId = user.manager_account_roles.find(
      role => role.manager_account_id === account.id
    )!.id;

    await locationServiceTerminationService.upsertLocationServiceTerminationServices(
      locationNoticeId,
      validation.data.servicesIds,
      managerAccountRoleId,
      intent === "save-progress"
    );

    if (intent === "save-progress") {
      return redirectWithSuccess(
        `/intelligence/${account.id}/locations/${params.location_id}/notices`,
        "Progress saved successfully"
      );
    }

    return redirectWithSuccess(
      `/intelligence/${account.id}/locations/${params.location_id}/notices/${locationNoticeId}/service-termination/emailtemplate`,
      "Services configured successfully"
    );
  }
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocationNotices],
      locationId: params.location_id,
    }
  );

  const { locationService, locationServiceTerminationService } =
    await WebDIContainer();

  const location = await locationService.getLocation(params.location_id!);

  if (!location) {
    throw new Response("Location not found", { status: 404 });
  }

  const locationNoticeId = params.location_notice_id!;

  const locationNotice =
    await locationServiceTerminationService.getLocationServiceTermination(
      locationNoticeId,
      location.id,
      user,
      account
    );

  if (!locationNotice) {
    throw new Response("Location notice not found", { status: 404 });
  }

  if (locationNotice?.status === LocationNoticeStatus.Sent) {
    return redirectWithWarning(
      `/intelligence/${account.id}/locations/${location.id}/notices/${locationNoticeId}/service-termination`,
      "Location notice has already been sent"
    );
  }

  if (locationNotice.original_location_notice_id) {
    return redirectWithWarning(
      `/intelligence/${account.id}/locations/${location.id}/notices/${locationNoticeId}/service-termination`,
      "This is an updated notice, and you cannot change the selected services"
    );
  }

  const services = await locationServiceTerminationService.getServices(
    locationNotice.location_id,
    locationNotice.manager_account_vendor_id
  );

  return json({
    user,
    account,
    location,
    services,
    locationNotice,
  });
}

export default function LocationServiceTerminationSelect() {
  const { account, location, services, locationNotice } =
    useLoaderData<typeof loader>();

  const [selectedServices, setSelectedServices] = useState<typeof services>(
    locationNotice.services_to_terminate
  );

  const fetcher = useFetcher<{ success: boolean }>();

  const [confirmationModalStep, setConfirmationModalStep] = useState<
    "missing-services-info" | "not-all-services-selected" | undefined
  >(undefined);

  const submit = (intent: string, skipChecks?: boolean) => {
    if (intent === "continue" && !skipChecks) {
      if (selectedServices.length < services.length) {
        setConfirmationModalStep("not-all-services-selected");
        return;
      }
    }

    const formData = new FormData();

    formData.append("servicesIds", selectedServices.map(v => v.id).join(","));
    formData.append("intent", intent);

    fetcher.submit(formData, {
      method: "POST",
    });
  };

  const [searchQuery, setSearchQuery] = useState<string>("");

  const filteredVendors = useMemo(
    () =>
      services.filter(
        v => v.name && v.name.toLowerCase().includes(searchQuery.toLowerCase())
      ),
    [services, searchQuery]
  );

  return (
    <>
      <WizardModal
        isOpen={!!confirmationModalStep}
        onClose={() => setConfirmationModalStep(undefined)}
        steps={[
          {
            id: "not-all-services-selected",
            icon: "warningRed",
            title: (
              <span className="text-xl">
                You have selected{" "}
                <span className="text-red-500">{selectedServices.length}</span>/
                {services.length} assigned line items for{" "}
                {locationNotice.manager_account_vendor.vendor.name}. Do you wish
                to proceed?
              </span>
            ),
            body: `Not all services assigned to ${location.name} have been selected. To select additional line items, click “Return to select services.” To continue as is, click “I’m sure.” You can always add additional notes in the body of your email.`,
            ctas: {
              primary: {
                label: "Yep, I’m sure",
                onClick: () => {
                  setConfirmationModalStep(undefined);
                  submit("continue", true);
                },
              },
              secondary: {
                label: "Return to select services",
              },
            },
          },
        ]}
        initialStepId={confirmationModalStep}
        fetcher={fetcher}
      />
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
          },
          {
            name: "Notices",
            to: `/intelligence/${account.id}/locations/${location.id}/notices`,
          },
          {
            name: "Configure service termination details",
            to: `/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/service-termination/details`,
          },
          {
            name: "Select services",
            to: `/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/service-termination/selectservices`,
            active: true,
          },
        ]}
        title={
          <>
            Select services to terminate: <br /> {location.name}
          </>
        }
        description={`Review the line items currently assigned to ${location.name} in Revyse. Select the services that you are requesting to terminate, and we’ll include these line items in the email template on the next screen.`}
        buttonsSlot={<CTA onClick={() => submit("continue")}>Continue</CTA>}
      />
      <IntelligenceFilter
        filterBar={{
          inputPlaceholder: "Search services",
        }}
        onFilter={({ searchQuery }) => {
          setSearchQuery(searchQuery || "");
        }}
      ></IntelligenceFilter>
      <Table
        selectColumnPosition="start"
        selectAllInColumn={true}
        alignment="middle"
        cols={[
          {
            label: "Line Item Name",
            name: "name",
          },
          {
            label: "Price Value",
            renderer: contract_line_item => (
              <div className="flex items-center space-x-2">
                <div className="font-light">
                  {contract_line_item?.contract_line_item_products.length > 0 ||
                  contract_line_item?.contract_line_item_fees.length > 0 ? (
                    <div>
                      <div className="text-md font-semibold">
                        ${contract_line_item?.price} /{" "}
                        {contract_line_item?.cadence
                          ? ContractLineItemPriceCadenceLabels[
                              contract_line_item?.cadence
                            ]
                          : ""}{" "}
                        /{" "}
                        {contract_line_item?.pricing_type
                          ? ContractPricingTypeLabels[
                              contract_line_item.pricing_type
                            ]
                          : ""}
                      </div>
                      {contract_line_item?.contract_line_item_products.length +
                        contract_line_item?.contract_line_item_fees.length >
                        1 && (
                        <div>
                          {contract_line_item?.contract_line_item_products.map(
                            product => (
                              <div key={product.id}>
                                {product.product.title}: <b>${product.price}</b>{" "}
                              </div>
                            )
                          )}
                          {contract_line_item?.contract_line_item_fees.map(
                            fee => (
                              <div key={fee.id}>
                                {fee.fee?.name}: <b>${fee.price}</b>{" "}
                              </div>
                            )
                          )}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div>$0</div>
                  )}
                </div>
              </div>
            ),
          },
          {
            label: "Current Term End Date",
            renderer: contract_line_item => (
              <div className="font-light">
                {dayjs
                  .utc(
                    contract_line_item.contract_line_item_locations[0]
                      .expires_at ??
                      contract_line_item.contract.current_term_end_date
                  )
                  .format("M/D/YYYY")}
              </div>
            ),
          },
        ]}
        data={searchQuery ? filteredVendors : services}
        initialSelectedRows={selectedServices}
        onSelectRows={setSelectedServices}
      />
      <footer className="flex justify-between items-center mt-4">
        <div>
          <Link
            to={`/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/service-termination/details`}
            className="text-sky-500 flex items-center text-sm"
          >
            <ArrowLeftIcon className="h-5 mr-2" /> Back to service termination
            notice details
          </Link>
        </div>
        <div className="flex gap-x-2">
          <Button color="transparent" onClick={() => submit("save-progress")}>
            Save Progress
          </Button>
          <CTA onClick={() => submit("continue")}>Continue</CTA>
        </div>
      </footer>
    </>
  );
}
