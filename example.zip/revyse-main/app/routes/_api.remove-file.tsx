import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";

const RemoveFileForm = z.object({
  file_id: z.string().min(1),
});

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const form = await request.formData();
  const { fileService } = await WebDIContainer();
  const fields = {
    file_id: form.get("file_id"),
  };
  const validation = RemoveFileForm.safeParse(fields);
  if (!validation.success) {
    console.error(JSON.stringify(validation.error.issues));
    throw new Error("Invalid form");
  }

  await fileService.deleteFile(validation.data.file_id);

  return null;
};

export const loader = async ({ params, request }: LoaderFunctionArgs) => {
  return { json: { hello: "world" } };
};
