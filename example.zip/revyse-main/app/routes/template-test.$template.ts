import { WebDIContainer } from "~/di-containers/web.di-container.server";
import type { LoaderFunctionArgs } from "@remix-run/node";

export async function loader({ params }: LoaderFunctionArgs) {
  const { templateService } = await WebDIContainer();
  let responseBody = "Unsupported";
  switch (params.template) {
    case "forgot-password":
      responseBody = templateService.renderForgotPasswordEmail({
        token: "beepboop",
      });
      break;
    case "email-verification":
      responseBody = templateService.renderEmailVerificationEmail({
        token: "beepboop",
        email: "jonathan@revyse.com",
      });
      break;
    case "listing-approved":
      responseBody = templateService.renderListingApprovedEmail({
        product_id: "beepboop",
        product_name: "G5 Websites",
      });
      break;
    case "buyer-contact":
      responseBody = templateService.renderBuyerContactEmail({
        recipient: {
          first_name: "Gandalf",
        },
        request: {
          description: "Hey oh! Gimme da info man!",
          product_id: "aaaa-prod-uct-id",
          product: {
            title: "A Groovy Product",
          },
          user: {
            first_name: "Frodo",
            last_name: "Baggins",
            email: "frodo@baggins.org",
            title: "Hobbit",
            company_name: "Bag End LLC",
          },
        },
      } as any);
      break;
    case "buyer-verified":
      responseBody = templateService.renderBuyerVerifiedEmail({});
      break;
    case "review-approved":
      responseBody = templateService.renderReviewApprovedEmail({
        review: {
          id: "a-review-id",
          title: "This product is pretty good",
          product: {
            title: "A Good Product",
            vendor: { name: "Yardi" },
          },
        },
      } as any);
      break;
    case "review-responded":
      responseBody = templateService.renderReviewRespondedEmail({
        review: {
          id: "a-review-id",
          title: "This product is pretty good",
          response:
            "Thanks for the review! We're glad you like the product. We're working on making it even better!",
          product: {
            slug: "a-good-product",
            title: "A Good Product",
            vendor: { name: "Yardi" },
          },
        },
      } as any);
      break;
    case "intelligence-consolidated-notifications":
      const notifications = [
        {
          message: "You have a new task to complete <b>ASAP</b>!",
        },
        {
          message: "You have a task due soon",
        },
      ];

      responseBody =
        templateService.renderIntelligenceConsolidatedNotificationsEmail({
          notifications,
          manager_account_id: "",
        });
  }
  return new Response(responseBody, {
    status: 200,
    headers: {
      "Content-Type": "text/html",
    },
  });
}
