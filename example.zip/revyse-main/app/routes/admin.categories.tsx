import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { CrudListPage } from "~/components/crud-list-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { db } = await WebDIContainer();
  return json({
    categories: await db.productCategory.findMany({
      orderBy: { name: "asc" },
    }),
  });
}

export default function AdminCategoriesRoute() {
  const { categories } = useLoaderData<typeof loader>();

  return (
    <CrudListPage
      crumbs={[
        {
          name: "Categories",
          to: "/admin/categories",
          active: true,
        },
      ]}
      cols={[
        // { name: "id", label: "ID" },
        { name: "name", label: "Name" },
        { name: "created_at", label: "Created", type: "date" },
      ]}
      data={categories}
      title="Categories"
      subtitle="A list of all the product categories."
    />
  );
}
