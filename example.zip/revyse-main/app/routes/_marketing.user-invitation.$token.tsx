import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { isNil } from "lodash";
import { CTA } from "../components/cta.component";
import { EnvelopeOpenIcon } from "@heroicons/react/24/outline";
import { getUser } from "../utils/session.server";
import { assertAuthorizedOrRedirect } from "../utils/assert.utils.server";
import type { ManagerAccountRoleType } from "@prisma/client";
import { useLoaderData } from "@remix-run/react";
import type { RoleJson } from "~/services/product-subscription.service.server";

export const meta: MetaFunction = () => [
  { title: "Revyse | User Invitation" },
  {
    name: "description",
    content: "User Invitation",
  },
];

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const { managerAccountRoleService, productSubscriptionService } =
    await WebDIContainer();
  const token = params.token as string;
  const user = await getUser(request);

  const redirectUrl = encodeURIComponent(`/user-invitation/${token}`);
  const invitation = await productSubscriptionService.getUserInvitationByToken(
    token
  );

  assertAuthorizedOrRedirect(
    !isNil(invitation) && !isNil(user),
    `/login?redirectTo=${redirectUrl}`
  );

  const role = invitation.role as RoleJson;

  if (role.resource_id) {
    // Product invitation}
    await productSubscriptionService.acceptSubscriptionInvite(
      role,
      user,
      token
    );
  } else if (role.manager_account_id) {
    // Intelligence ManagerAccountRole invitation
    const success =
      await managerAccountRoleService.acceptManagerAccountUserInvitation(
        user,
        token,
        role as { manager_account_id: string; role: ManagerAccountRoleType }
      );

    if (!success) {
      return json({
        invitation,
        success,
        errorMessage:
          "This user is already associated with this Revyse Intelligence Account, please try accepting the invitation by login in with another user",
      });
    }
  }

  return json({
    invitation,
    success: true,
    errorMessage: null,
  });
};

export default function UserInviteRoute() {
  const { invitation, errorMessage, success } = useLoaderData<typeof loader>();
  const role = invitation?.role as RoleJson;

  const isManagerAccountInvite = role?.manager_account_id;

  const message = !isManagerAccountInvite
    ? "Now, head over to the vendor portal to view and update your listing"
    : "Now, head over to Revyse Intelligence and start managing your vendors like a pro.";

  const linkTo = !isManagerAccountInvite
    ? { to: "/vendor/", label: "Vendor Portal" }
    : {
        to: `/intelligence/${role?.manager_account_id}`,
        label: "Go to Revyse Intelligence",
      };

  return invitation && success ? (
    <div className="flex justify-center">
      <div className="max-w-3xl bg-white text-center rounded-3xl border border-gray-100 p-12 mt-6">
        <EnvelopeOpenIcon className="h-12 inline mb-6" />
        <h1 className="text-3xl">Invitation Accepted!</h1>
        <div className="my-4">{message}</div>
        <p className="my-8 flex items-center justify-center">
          <CTA
            id="user-invitation-redirect"
            to={linkTo.to}
            className="flex items-center"
          >
            {linkTo.label}
          </CTA>
        </p>
      </div>
    </div>
  ) : (
    <div className="flex justify-center">
      <div className="max-w-3xl bg-white text-center rounded-3xl border border-gray-100 p-12 mt-6">
        <EnvelopeOpenIcon className="h-12 inline mb-6" />
        <h1 className="text-3xl">
          {!success ? `Couldn't accept the invitation` : "Invitation expired"}
        </h1>
        <div className="my-4">
          {errorMessage ||
            "Your invitation has been canceled or is now expired"}
        </div>
        <p className="my-8 flex items-center justify-center">
          <CTA
            id="invalid-invitation-redirect"
            to={linkTo.to}
            className="flex items-center"
          >
            {linkTo.label}
          </CTA>
        </p>
      </div>
    </div>
  );
}
