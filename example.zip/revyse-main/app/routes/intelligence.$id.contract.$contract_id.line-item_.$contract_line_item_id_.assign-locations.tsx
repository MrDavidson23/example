import { CTA } from "~/components/cta.component";
import {
  Form,
  useActionData,
  useLoaderData,
  useNavigate,
  useNavigation,
} from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import {
  ChevronDownIcon,
  ChevronUpIcon,
  InformationCircleIcon,
  XMarkIcon,
} from "@heroicons/react/24/outline";
import { useCallback, useEffect, useRef, useState } from "react";
import dayjs from "dayjs";
import {
  LocationClass,
  LocationPropertyType,
  LocationStatus,
} from "@prisma/client";
import { Modal } from "~/components/modal.component";
import {
  CrudCheckboxField,
  CrudDateField,
} from "~/components/form/crud-form.component";
import { Table } from "~/components/intelligence/table.component";
import { AutocompleteFilter } from "~/components/intelligence/autocomplete-filter.component";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import { Tooltip } from "~/components/tooltip.component";
import utc from "dayjs/plugin/utc";
import { Permission } from "~/utils/intelligence-permission.utils";
import { FilterTag } from "~/components/filter-tag.component";
import { jsonWithError, redirectWithSuccess } from "remix-toast";
import { FilterBar } from "~/components/filter-bar.component";
import { ConfirmAssignedLocationsModal } from "~/components/modals/confirm-assigned-locations-modal";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import type { LocationsFilterType } from "~/services/location.service.server";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

dayjs.extend(utc);

type FilterType =
  | "unitCount"
  | "propertyClass"
  | "propertyType"
  | "region"
  | "owner";

const SelectedLocationIdsSchema = z.object({
  locations: z.array(
    z.object({
      id: z.string().uuid(),
      expires_at: z.date(),
    })
  ),
});

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContractLineItemLocations],
    }
  );
  const id = params.contract_line_item_id;

  const { contractLineItemService } = await WebDIContainer();

  const form = await request.formData();

  const contractLineItem = await loadContractLineItem(id);

  const locationIds = form.getAll("locations.id") as string[];
  const locationExpireAts = form.getAll("locations.expires_at") as string[];

  const locations = locationIds.map((location, j) => {
    return {
      id: location,
      expires_at: new Date(locationExpireAts[j]),
    };
  });

  const fields = {
    locations,
  };
  const validation = SelectedLocationIdsSchema.safeParse(fields);

  if (validation.success && contractLineItem) {
    await contractLineItemService.assignContractLineItemLocations(
      contractLineItem,
      validation.data
    );

    return redirectWithSuccess(
      `/intelligence/${account.id}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/summary`,
      "Locations assigned successfully"
    );
  }

  return jsonWithError(
    { success: false, errors: issuesByKey([]) },
    "There was an error assigning locations",
    { status: 400 }
  );
};

async function loadContractLineItem(id: string | undefined) {
  const { contractLineItemService } = await WebDIContainer();
  return await contractLineItemService.loadContractLineItem(id);
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContractLineItemLocations],
    }
  );
  const { locationService } = await WebDIContainer();

  const managerAccountId = account.id;

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const searchTerm = search.get("query");
  const contractLineItem = await loadContractLineItem(
    params.contract_line_item_id
  );
  const unitCountParam = search.getAll("unit_count");
  const propertyClassParam = search.getAll("property_class");
  const propertyTypeParam = search.getAll("property_type");
  const regionParam = search.getAll("region");
  const ownerParam = search.getAll("owner");

  const locationsFilters: LocationsFilterType = {
    query: searchTerm ?? undefined,
    unitCount: unitCountParam,
    propertyClass: propertyClassParam as LocationClass[],
    propertyType: propertyTypeParam as LocationPropertyType[],
    region: regionParam,
    owner: ownerParam,
    status: [LocationStatus.Active, LocationStatus.Pending],
  };

  const locations = await locationService.getLocations(
    user,
    account,
    locationsFilters
  );

  const locationsCount = await locationService.getLocationsCount(
    user,
    account,
    locationsFilters
  );

  const regions = await locationService.getLocationsRegions(managerAccountId);
  const owners = await locationService.getLocationsOwners(managerAccountId);

  if (!contractLineItem) {
    throw new Response("Not found", { status: 404 });
  }

  return json({
    contractLineItem,
    contract: contractLineItem.contract,
    searchTerm,
    locations,
    regions,
    owners,
    locationsCount,
    unitCountParam,
    propertyClassParam,
    propertyTypeParam,
    regionParam,
    ownerParam,
    account,
  });
}

type Region = { region: string | undefined | null };
type Owner = { owner_name: string | undefined | null };

export default function PriceConfigLocations() {
  const navigate = useNavigate();
  const actionData = useActionData<typeof action>();

  const {
    contractLineItem,
    searchTerm,
    locations,
    regions,
    owners,
    unitCountParam,
    propertyClassParam,
    propertyTypeParam,
    regionParam,
    ownerParam,
    account,
  } = useLoaderData<typeof loader>();
  const navigation = useNavigation();

  const baseUrl = `/intelligence/${account.id}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/assign-locations/`;
  const [filterByPropertyClass, setFilterByPropertyClass] = useState<string[]>(
    []
  );
  const [filterByPropertyType, setFilterByPropertyType] = useState<string[]>(
    []
  );
  const [filterByRegion, setFilterByRegion] = useState<string[]>([]);
  const [filterByOwnerName, setFilterByOwnerName] = useState<string[]>([]);
  const [filterByUnitCount, setFilterByUnitCount] = useState<string[]>([]);
  const [selectedRegions, setSelectedRegions] = useState<Region[]>([]);
  const [selectedOwners, setSelectedOwners] = useState<Owner[]>([]);

  const [autocompleteValue, setAutocompleteValue] = useState<string>("");
  const [autocompleteOwnerName, setAutocompleteOwnerName] =
    useState<string>("");
  const [errorMessage, setErrorMessage] = useState<string>("");
  const [ownerErrorMessage, setOwnerErrorMessage] = useState<string>("");

  const [openFilteringModal, setOpenFilteringModal] = useState(false);
  const [handleRow, setHandleRow] = useState("");
  const [overrideDate, setOverrideDate] = useState(false);
  const [showAllSelectedLocations, setShowAllSelectedLocations] =
    useState(false);
  const [selectedLocations, setSelectedLocations] = useState<
    { id: string; name: string; expires_at: string | null }[]
  >(
    contractLineItem.contract_line_item_locations.map(item => ({
      id: item.location_id,
      name: item.location.name,
      expires_at:
        item.expires_at ?? contractLineItem.contract.current_term_end_date,
    }))
  );
  const [selectedLocationToOverride, setSelectedLocationToOverride] = useState<{
    id: string | null;
    name: string | null;
    expires_at?: string | null;
  }>({ id: null, name: null, expires_at: null });
  const [newExpirationDate, setNewExpirationDate] = useState("");

  const [selectedFilters, setSelectedFilters] = useState({
    unitCount: filterByUnitCount,
    propertyClass: filterByPropertyClass,
    propertyType: filterByPropertyType,
    owner: filterByOwnerName,
    region: filterByRegion,
  });

  const unitCountFilter = [
    { value: "1-50", name: "1-50" },
    { value: "50-100", name: "50-100" },
    { value: "100-200", name: "100-200" },
    { value: "200-500", name: "200-500" },
    { value: "500", name: "500+" },
  ];

  const propertyClassFilter = [
    { name: "A+", value: LocationClass.APlus },
    { name: LocationClass.A, value: LocationClass.A },
    { name: LocationClass.B, value: LocationClass.B },
    { name: LocationClass.C, value: LocationClass.C },
    { name: LocationClass.D, value: LocationClass.D },
  ];

  const propertyTypeFilter = [
    {
      name: "Conventional Multifamily",
      value: LocationPropertyType.ConventionalMultifamily,
    },
    {
      name: LocationPropertyType.Affordable,
      value: LocationPropertyType.Affordable,
    },
    {
      name: LocationPropertyType.Student,
      value: LocationPropertyType.Student,
    },
    { name: LocationPropertyType.Senior, value: LocationPropertyType.Senior },
    { name: "Self Storage", value: LocationPropertyType.SelfStorage },
    {
      name: "Office/Commercial",
      value: LocationPropertyType.OfficeCommercial,
    },
    { name: "Build-to-Rent", value: LocationPropertyType.BuildToRent },
    { name: "Single Family", value: LocationPropertyType.SingleFamily },
    { name: LocationPropertyType.Other, value: LocationPropertyType.Other },
  ];

  function constructNewURL(
    baseUrl: string,
    searchQuery: string,
    filterByUnitCount: string[],
    filterByPropertyClass: string[],
    filterByPropertyType: string[],
    filterByRegion: string[],
    filterByOwnerName: string[]
  ): string {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchQuery);

    if (filterByUnitCount.length > 0) {
      searchParams.append("unit_count", filterByUnitCount.join(","));
    }
    if (filterByPropertyClass.length > 0) {
      searchParams.append("property_class", filterByPropertyClass.join(","));
    }
    if (filterByPropertyType.length > 0) {
      searchParams.append("property_type", filterByPropertyType.join(","));
    }
    if (filterByRegion.length > 0) {
      searchParams.append("region", filterByRegion.join(","));
    }
    if (filterByOwnerName.length > 0) {
      searchParams.append("owner", filterByOwnerName.join(","));
    }

    return `${baseUrl}?${searchParams.toString()}`;
  }
  const [showingResults, setShowingResults] = useState(false);

  // Handle filtering & name searching
  const handleFiltering = (newSearchQuery?: string) => {
    const newURL = constructNewURL(
      baseUrl,
      newSearchQuery ?? searchTerm ?? "",
      filterByUnitCount,
      filterByPropertyClass,
      filterByPropertyType,
      filterByRegion,
      filterByOwnerName
    );
    setOpenFilteringModal(false);
    setShowingResults(false);
    navigate(newURL);
  };

  const clearFilters = () => {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchTerm ?? "");

    setFilterByPropertyClass([]);
    setFilterByPropertyType([]);
    setFilterByUnitCount([]);
    setFilterByRegion([]);
    setFilterByOwnerName([]);
    setSelectedRegions([]);
    setSelectedOwners([]);

    searchParams.delete("unit_count");
    searchParams.delete("property_class");
    searchParams.delete("property_type");
    searchParams.delete("region");
    searchParams.delete("owner");

    const newURL = `${baseUrl}?${searchParams.toString()}`;

    setOpenFilteringModal(false);
    navigate(newURL);
  };

  useEffect(() => {
    if (unitCountParam.length > 0) {
      const unitCounts = unitCountParam.flatMap(value => value.split(","));
      setFilterByUnitCount(unitCounts);
    }

    if (propertyClassParam.length > 0) {
      const propertyClasses = propertyClassParam.flatMap(value =>
        value.split(",")
      );
      setFilterByPropertyClass(propertyClasses);
    }

    if (propertyTypeParam.length > 0) {
      const propertyTypes = propertyTypeParam.flatMap(value =>
        value.split(",")
      );
      setFilterByPropertyType(propertyTypes);
    }

    if (regionParam.length > 0) {
      const regionFilters = regionParam.flatMap(value => value.split(","));
      setFilterByRegion(regionFilters);

      const initialSelectedRegions = regions
        .filter(region => regionFilters.includes(region?.region || ""))
        .filter(Boolean);

      setSelectedRegions(initialSelectedRegions);
    }

    if (ownerParam.length > 0) {
      const ownerFilters = ownerParam.flatMap(value => value.split(","));
      setFilterByOwnerName(ownerFilters);

      const initialSelectedOwners = owners
        .filter(owner => ownerFilters.includes(owner?.owner_name || ""))
        .filter(Boolean);

      setSelectedOwners(initialSelectedOwners);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleAddTag = (region: Region) => {
    if (region.region && !filterByRegion.includes(region.region)) {
      setSelectedRegions([...selectedRegions, region]);
      setFilterByRegion([...filterByRegion, region.region || ""]);
      setAutocompleteValue("");
    } else {
      setErrorMessage("Filter is already selected");
    }
  };

  const handleAddOwnerName = (owner: Owner) => {
    if (owner.owner_name && !filterByOwnerName.includes(owner.owner_name)) {
      setSelectedOwners([...selectedOwners, owner]);
      setFilterByOwnerName([...filterByOwnerName, owner.owner_name || ""]);
      setAutocompleteOwnerName("");
    } else {
      setOwnerErrorMessage("Filter is already selected");
    }
  };

  const handleRemoveTag = (region: Region) => {
    const updatedVendors = selectedRegions.filter(
      selectedRegion => selectedRegion.region !== region.region
    );
    setSelectedRegions(updatedVendors);
    setFilterByRegion(filterByRegion.filter(r => r !== region.region));
    setErrorMessage("");
  };

  const handleRemoveOwner = (owner: Owner) => {
    const updatedOwners = selectedOwners.filter(
      selectedOwner => selectedOwner.owner_name !== owner.owner_name
    );
    setSelectedOwners(updatedOwners);
    setFilterByOwnerName(filterByOwnerName.filter(o => o !== owner.owner_name));
    setOwnerErrorMessage("");
  };
  const filteredRegions = regions.filter(region =>
    region?.region.toLowerCase().includes(autocompleteValue.toLowerCase())
  );

  const filteredOwners = owners.filter(owner =>
    owner?.owner_name
      ?.toLowerCase()
      .includes(autocompleteOwnerName.toLowerCase())
  );

  useEffect(() => {
    setSelectedFilters({
      unitCount: filterByUnitCount,
      propertyClass: filterByPropertyClass,
      propertyType: filterByPropertyType,
      owner: filterByOwnerName,
      region: filterByRegion,
    });
  }, [
    filterByUnitCount,
    filterByPropertyClass,
    filterByPropertyType,
    filterByOwnerName,
    filterByRegion,
  ]);

  useEffect(() => {
    if (showingResults) {
      handleFiltering();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [
    filterByUnitCount,
    filterByPropertyClass,
    filterByPropertyType,
    filterByRegion,
    filterByOwnerName,
  ]);

  // Handle removing a filter
  const removeFilter = (filterType: FilterType, filterValue: string) => {
    const updatedFilters = { ...selectedFilters };
    updatedFilters[filterType] = updatedFilters[filterType].filter(
      value => value !== filterValue
    );
    setShowingResults(true);
    if (filterType === "unitCount") {
      setFilterByUnitCount(updatedFilters.unitCount);
    } else if (filterType === "propertyClass") {
      setFilterByPropertyClass(updatedFilters.propertyClass);
    } else if (filterType === "propertyType") {
      setFilterByPropertyType(updatedFilters.propertyType);
    } else if (filterType === "owner") {
      setFilterByOwnerName(updatedFilters.owner);
    } else if (filterType === "region") {
      setFilterByRegion(updatedFilters.region);
    }
    setSelectedFilters(updatedFilters);
  };

  const renderRegion = (option: Region) => {
    return option.region;
  };

  const renderOwner = (option: Owner) => {
    return option.owner_name;
  };

  const renderSelectedFilters = () => {
    const tags = [];
    for (const filterType in selectedFilters) {
      const typedFilterType = filterType as FilterType;
      for (const filterValue of selectedFilters[typedFilterType]) {
        tags.push(
          <FilterTag
            key={`${typedFilterType}-${filterValue}`}
            text={filterValue}
            onRemove={() => {
              removeFilter(typedFilterType, filterValue);
            }}
          />
        );
      }
    }
    return tags;
  };

  const handleSelectRows = (selectedRows: any[]) => {
    const newSelectedLocations = selectedRows.map(location => {
      const isLocationSelected = selectedLocations.some(
        selectedLocation => selectedLocation.id === location.id
      );
      const contractLineItemLocation =
        contractLineItem.contract_line_item_locations.find(
          selectedLocation => selectedLocation.location_id === location.id
        );
      const existingLocation = selectedLocations.find(
        selectedLocation => selectedLocation.id === location.id
      );
      const locations = {
        ...location,
        id: location.id,
        name: location.name,
        expires_at: isLocationSelected
          ? existingLocation?.expires_at ??
            contractLineItemLocation?.expires_at ??
            contractLineItem.contract.current_term_end_date
          : contractLineItem.contract.current_term_end_date,
      };
      return locations;
    });
    setSelectedLocations(newSelectedLocations);
  };

  const handleDeselectLocation = (locationId: string) => {
    setHandleRow(locationId);
    setSelectedLocations(prevSelectedLocations =>
      prevSelectedLocations.filter(location => location.id !== locationId)
    );
  };

  useEffect(() => {
    if (navigation.state == "idle") {
      window.scrollTo(0, 0);
    }
  }, [navigation.state]);

  const visibleSelectedLocations = showAllSelectedLocations
    ? selectedLocations
    : selectedLocations.slice(0, 12);

  const [showConfirmChangeCorporateOnly, setShowConfirmChangeCorporateOnly] =
    useState(false);

  const [
    showConfirmAssignedLocationsModal,
    setShowConfirmAssignedLocationsModal,
  ] = useState(false);

  const handleOnSaveClick = useCallback(
    (e: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
      if (contractLineItem.is_corporate_only) {
        setShowConfirmChangeCorporateOnly(true);
        return;
      }
      setShowConfirmAssignedLocationsModal(true);
    },
    [contractLineItem.is_corporate_only]
  );

  const submitAssignedLocations = useCallback(() => {
    $form.current?.requestSubmit();
  }, []);

  const $form = useRef<HTMLFormElement | null>(null);

  return (
    <>
      <Modal
        isOpen={openFilteringModal}
        onClose={() => setOpenFilteringModal(false)}
        size="medium"
        manager={true}
      >
        <div className="p-2 lg:p-6">
          <h4 className="font-bold">Filter By</h4>
          <div className="divide divide-y divide-2 ">
            <div>
              <div className="my-4 font-semibold">Unit Count</div>
              <div className="flex justify-around">
                {unitCountFilter.map((option, index) => (
                  <CrudCheckboxField
                    key={index}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: filterByUnitCount.includes(option.value),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterByUnitCount([
                          ...filterByUnitCount,
                          option.value,
                        ]);
                      } else {
                        setFilterByUnitCount(
                          filterByUnitCount.filter(i => i !== option.value)
                        );
                      }
                    }}
                  />
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Property Class</div>
              <div className="flex justify-around">
                {propertyClassFilter.map((option, index) => (
                  <CrudCheckboxField
                    key={index}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: filterByPropertyClass.includes(
                        option.value
                      ),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterByPropertyClass([
                          ...filterByPropertyClass,
                          option.value,
                        ]);
                      } else {
                        setFilterByPropertyClass(
                          filterByPropertyClass.filter(i => i !== option.value)
                        );
                      }
                    }}
                  />
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Regions</div>
              <AutocompleteFilter
                initialValue={autocompleteValue}
                options={filteredRegions}
                onFilterChange={setAutocompleteValue}
                onAddTag={handleAddTag}
                onRemoveTag={handleRemoveTag}
                selectedTags={selectedRegions}
                errorMessage={errorMessage}
                renderOption={renderRegion}
              />
            </div>
            <div>
              <div className="my-4 font-semibold">Property Type</div>
              <div className="grid grid-cols-3">
                {propertyTypeFilter.map((option, index) => (
                  <div key={index}>
                    <CrudCheckboxField
                      key={index}
                      field={{
                        name: "filter_by",
                        value: option.value,
                        label: option.name,
                        errors: [],
                        description: "",
                        defaultChecked: filterByPropertyType.includes(
                          option.value
                        ),
                        type: "checkbox",
                      }}
                      onChange={evt => {
                        const checked = evt.target.checked;
                        if (checked) {
                          setFilterByPropertyType([
                            ...filterByPropertyType,
                            option.value,
                          ]);
                        } else {
                          setFilterByPropertyType(
                            filterByPropertyType.filter(i => i !== option.value)
                          );
                        }
                      }}
                    />
                  </div>
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Owner Name</div>
              <AutocompleteFilter
                initialValue={autocompleteOwnerName}
                options={filteredOwners}
                onFilterChange={setAutocompleteOwnerName}
                onAddTag={handleAddOwnerName}
                onRemoveTag={handleRemoveOwner}
                selectedTags={selectedOwners}
                errorMessage={ownerErrorMessage}
                renderOption={renderOwner}
              />
            </div>
          </div>
          <div className="flex justify-end mt-8 items-center space-x-3">
            <button
              className="text-sky-500"
              onClick={() => {
                clearFilters();
              }}
            >
              Clear filters
            </button>
            <CTA
              variant="coral-shadow"
              onClick={() => {
                setShowingResults(true);
                handleFiltering();
              }}
            >
              Show results
            </CTA>
          </div>
        </div>
      </Modal>
      <Modal
        isOpen={overrideDate}
        onClose={() => setOverrideDate(false)}
        size="medium"
        manager={true}
      >
        <div className="p-3 space-y-7">
          <Form method="post">
            <div className="flex items-center space-x-2 my-3">
              <div className="text-2xl font-semibold">Override Date</div>
              <Tooltip
                position="right"
                text="The override date allows you to set a current term end date at the location-level, that is separate from the contract-level end date."
              >
                <div className="flex flex-row items-center cursor-pointer">
                  <InformationCircleIcon className="h-5" />
                </div>
              </Tooltip>
            </div>
            <CrudDateField
              field={{
                name: "newExpiresAt",
                type: "text",
                errors: actionData?.errors?.expires_at ?? [],
                label: "Current Term End Date for This Location",
                defaultValue:
                  dayjs
                    .utc(
                      selectedLocations.find(
                        selectedLocation =>
                          selectedLocation.id === selectedLocationToOverride.id
                      )?.expires_at
                    )
                    .format("YYYY-MM-DD") ??
                  dayjs
                    .utc(contractLineItem.contract.current_term_end_date)
                    .format("YYYY-MM-DD") ??
                  newExpirationDate,
                onChange: event => setNewExpirationDate(event.target.value),
              }}
            />
            <div className="flex justify-end space-x-6 py-3">
              <CTA
                variant="coral-shadow"
                type="button"
                onClick={() => {
                  const updatedLocations = selectedLocations.map(location => {
                    if (
                      selectedLocationToOverride &&
                      location.id === selectedLocationToOverride.id
                    ) {
                      return { ...location, expires_at: newExpirationDate };
                    }
                    return location;
                  });
                  setSelectedLocations(updatedLocations);
                  setOverrideDate(false);
                }}
              >
                Save
              </CTA>
            </div>
          </Form>
        </div>
      </Modal>
      <ConfirmAssignedLocationsModal
        isOpen={showConfirmAssignedLocationsModal}
        onClose={() => setShowConfirmAssignedLocationsModal(false)}
        onConfirm={submitAssignedLocations}
        contractLineItem={contractLineItem}
        originalItems={contractLineItem.contract_line_item_locations.map(
          item => item.location_id
        )}
        updatedItems={selectedLocations.map(item => item.id)}
        managerAccountId={
          contractLineItem.contract.manager_account_vendor.manager_account_id
        }
      />
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All contracts",
            to: `/intelligence/${account.id}/contracts`,
          },
          {
            name: contractLineItem.contract.name,
            to: `/intelligence/${account.id}/contract/${contractLineItem.contract_id}/details`,
          },
          {
            name: "Products and line items",
            to: `/intelligence/${account.id}/contract/${contractLineItem.contract_id}/line-item`,
          },
          {
            name: `${contractLineItem.name}`,
            to: `/intelligence/${account.id}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/summary`,
          },
          {
            name: `Assign locations`,
            to: `/intelligence/${account.id}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/assign-locations`,
            active: true,
          },
        ]}
        title={
          <>
            Assign locations:
            <br /> {contractLineItem.name}
          </>
        }
        description="Select the locations that have contracted this line item by checking the box in 
          the corresponding row. Click “Save & Assign Locations” to confirm your selections."
        buttonsSlot={
          <Form method="post">
            {selectedLocations.map(location => (
              <div key={location.id}>
                <input type="hidden" name="locations.id" value={location.id} />
                <input
                  type="hidden"
                  name="locations.expires_at"
                  value={
                    location.expires_at ??
                    contractLineItem.contract.current_term_end_date ??
                    contractLineItem.contract.expires_at ??
                    undefined
                  }
                />
              </div>
            ))}
            <CTA
              id="save-locations-button"
              type="button"
              variant="coral-shadow"
              className="text-sm md:text-base w-fit mt-3 lg:mt-0"
              onClick={handleOnSaveClick}
            >
              Save & Assign Locations
            </CTA>
          </Form>
        }
      />
      <FilterBar
        inputPlaceholder="Search locations"
        defaultSearchQuery={searchTerm ?? ""}
        onFilter={(searchQuery: string) => {
          setShowingResults(true);
          handleFiltering(searchQuery);
        }}
        filters={{
          onOpenFilteringModal: setOpenFilteringModal,
          filtersCount:
            filterByUnitCount.length +
            filterByPropertyClass.length +
            filterByRegion.length +
            filterByPropertyType.length +
            filterByOwnerName.length,
        }}
      />
      <div className="grid grid-cols-8 gap-2 mb-6">
        {renderSelectedFilters()}
      </div>
      <hr />
      <div>
        <div className="flex items-center justify-between my-4">
          <div>Selected Locations ({selectedLocations.length})</div>
          {selectedLocations.length > 12 && (
            <div>
              {showAllSelectedLocations ? (
                <button
                  className="font-light text-sky-500 flex items-center"
                  onClick={() => setShowAllSelectedLocations(false)}
                >
                  Show Less
                  <ChevronUpIcon className="h-5" />
                </button>
              ) : (
                <button
                  className="font-light text-sky-500 flex items-center"
                  onClick={() => setShowAllSelectedLocations(true)}
                >
                  Show More
                  <ChevronDownIcon className="h-5" />
                </button>
              )}
            </div>
          )}
        </div>
        <div className="flex flex-wrap gap-x-4 mb-6">
          {visibleSelectedLocations.map(location => (
            <div
              className="flex justify-center items-center w-max mt-3"
              key={location.id}
            >
              <div className="gap-x-2 w-full bg-transparent border-2 border-sky-500 rounded-full px-3 py-1.5 flex items-center text-sm">
                <button
                  id={`removeTag-${location.id}`}
                  className="font-light"
                  onClick={() => handleDeselectLocation(location.id)}
                >
                  <XMarkIcon className="h-5 text-sky-500" />
                </button>
                <div className="text-center w-full">{location.name}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
      <div>
        <Table
          cols={[
            { name: "name", label: "Location Name" },
            {
              name: "unit_count",
              label: "Unit Count",
              columnClassName: "font-normal",
            },
            {
              name: "class",
              label: "Property Class",
              columnClassName: "font-normal",
            },
            {
              renderer: location => (
                <div className="flex items-center space-x-2">
                  <div className="whitespace-normal line-clamp-3 truncate font-normal">
                    {(() => {
                      switch (location.property_type) {
                        case LocationPropertyType.ConventionalMultifamily:
                          return "Conventional Multifamily";
                        case LocationPropertyType.SelfStorage:
                          return "Self Storage";
                        case LocationPropertyType.OfficeCommercial:
                          return "Office/Commercial";
                        case LocationPropertyType.BuildToRent:
                          return "Build-to-Rent";
                        case LocationPropertyType.SingleFamily:
                          return "Single Family";
                        default:
                          return location.property_type;
                      }
                    })()}
                  </div>
                </div>
              ),
              label: "Property Type",
            },
            {
              name: "owner_name",
              label: "Owner Name",
              columnClassName: "font-normal",
            },
            {
              renderer: location => {
                const selectedLocation = selectedLocations.find(
                  selectedLocation => selectedLocation.id === location.id
                );
                return (
                  <div className="space-x-2 flex">
                    <div>
                      {selectedLocation
                        ? selectedLocation.expires_at
                          ? dayjs
                              .utc(selectedLocation.expires_at)
                              .format("M/D/YYYY")
                          : "No date provided:"
                        : contractLineItem.contract.current_term_end_date
                        ? dayjs
                            .utc(
                              contractLineItem.contract.current_term_end_date
                            )
                            .format("M/D/YYYY")
                        : "--"}
                    </div>
                    {selectedLocation && (
                      <button
                        className="text-sky-500 underline"
                        onClick={e => {
                          e.stopPropagation();
                          setSelectedLocationToOverride({
                            id: location.id,
                            name: location.name,
                          });
                          setOverrideDate(true);
                        }}
                      >
                        Override Date
                      </button>
                    )}
                  </div>
                );
              },
              label: "Current Term Ends",
            },
          ]}
          data={locations}
          addButtonLabel="add location"
          handleCallback={() => {
            redirect(`/intelligence/${account.id}/locations`);
          }}
          showSelectBox={true}
          initialSelectedRows={selectedLocations}
          onSelectRows={handleSelectRows}
          parentHandleRow={handleRow}
        ></Table>
      </div>
      <Form
        method="post"
        className="flex justify-end space-x-6 py-3"
        ref={$form}
      >
        <Modal
          isOpen={showConfirmChangeCorporateOnly}
          onClose={() => setShowConfirmChangeCorporateOnly(false)}
          size="medium"
          manager={true}
        >
          <div className="p-3 space-y-7">
            <h1 className="text-2xl">
              This line item was marked as corporate-only
            </h1>
            <div>
              By assigning one or more locations, the corporate-only setting
              will be turned off. Are you sure you want to assign locations and
              revert the corporate-only setting?
            </div>
            <input type="hidden" name="intent" value="delete" />
            <div className="flex justify-end space-x-2">
              <CTA
                variant="sky-shadow"
                onClick={() => setShowConfirmChangeCorporateOnly(false)}
              >
                Cancel
              </CTA>
              <CTA
                type="submit"
                className="ml-2"
                onClick={() => setShowConfirmAssignedLocationsModal(true)}
              >
                Yep!
              </CTA>
            </div>
          </div>
        </Modal>
        {selectedLocations.map(location => (
          <div key={location.id}>
            <input type="hidden" name="locations.id" value={location.id} />
            <input
              type="hidden"
              name="locations.expires_at"
              value={
                location.expires_at ??
                contractLineItem.contract.current_term_end_date ??
                contractLineItem.contract.expires_at ??
                undefined
              }
            />
          </div>
        ))}
        <CTA
          type="button"
          variant="coral-shadow"
          className="text-sm md:text-base w-fit mt-3 lg:mt-0"
          onClick={handleOnSaveClick}
        >
          Save & Assign Locations
        </CTA>
      </Form>
    </>
  );
}
