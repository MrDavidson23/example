import { CheckBadgeIcon, NoSymbolIcon } from "@heroicons/react/20/solid";
import type { Prisma } from "@prisma/client";
import { Role } from "@prisma/client";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { useMemo } from "react";
import { CrudListPage } from "~/components/crud-list-page.component";
import type { TableStateConfig } from "~/components/crud-table.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { getTableState } from "~/utils/table-state.server";

const PAGE_SIZE = 20;

export async function loader({ request }: LoaderFunctionArgs) {
  const { userService } = await WebDIContainer();

  const { pagination, orderBy, search } = getTableState({
    request,
    defaults: {
      pageSize: PAGE_SIZE,
      orderBy: "created_at:desc",
    },
  });

  const where: Prisma.UserWhereInput = search
    ? {
        OR: [
          { first_name: { contains: search, mode: "insensitive" } },
          { last_name: { contains: search, mode: "insensitive" } },
          { email: { contains: search, mode: "insensitive" } },
        ],
      }
    : {};

  const users = await userService.getUsers({
    where,
    orderBy: orderBy as Prisma.UserOrderByWithRelationInput,
    take: pagination.take,
    skip: pagination.skip,
  });

  const total = await userService.getUsersCount({ where });

  return json({ users, total });
}

export default function AdminUsersRoute() {
  const { users, total } = useLoaderData<typeof loader>();

  const tableStateConfig: TableStateConfig = useMemo(
    () => ({
      pagination: {
        useSearchParams: true,
        total,
      },
      orderBy: {
        useSearchParams: true,
      },
      search: {
        useSearchParams: true,
        resetPageOnSearch: true,
        inputPlaceholder: "Search by name or email",
      },
    }),
    [total]
  );

  return (
    <CrudListPage
      crumbs={[
        {
          name: "Users",
          to: "/admin/users",
          active: true,
        },
      ]}
      cols={[
        { name: "last_name", label: "Last Name", sortable: true },
        { name: "first_name", label: "First Name", sortable: true },
        { name: "created_at", label: "Created", type: "date", sortable: true },
        { name: "sign_up_intent", label: "Intent" },
        {
          label: "Email Verified",
          renderer: user =>
            user.email_verification_tokens.some(
              evt => evt.email === user.email
            ) ? (
              <CheckBadgeIcon className="h-6 text-green-600" />
            ) : (
              <NoSymbolIcon className="h-6 text-gray-400" />
            ),
        },
        {
          label: "Buyer",
          renderer: user => (
            <div>
              {user.user_roles.some(role => role.role === Role.BUYER) ? (
                <CheckBadgeIcon className="h-6 text-green-600" />
              ) : (
                <NoSymbolIcon className="h-6 text-gray-400" />
              )}
            </div>
          ),
        },
      ]}
      showAddButton={false}
      data={users}
      title="Users"
      subtitle=""
      tableStateConfig={tableStateConfig}
    />
  );
}
