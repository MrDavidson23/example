import type { MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { CategoryLink } from "~/components/discovery/category-link.component";
import { DiscoveryHeader } from "~/components/discovery/discovery-header.component";
import { PopularCategory } from "~/components/discovery/popular-category.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";

export async function loader() {
  const { productCategoryService } = await WebDIContainer();

  const categories = await productCategoryService.getAllCategories();

  const popularCategories = await productCategoryService.getPopularCategories();

  return json({
    categories,
    popularCategories,
  });
}

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  return [
    { title: `Revyse | Explore proptech products by category` },
    {
      name: "description",
      content: `Revyse helps multifamily operators discover, buy, and manage software, connecting the best products and services with the teams who need them most.`,
    },
  ];
};

export default function CategoriesRoute() {
  const { categories, popularCategories } = useLoaderData<typeof loader>();
  const categoriesByVendorType = categories.reduce((acc, cat) => {
    acc[cat.secondary_vendor_type] = acc[cat.secondary_vendor_type] || [];
    acc[cat.secondary_vendor_type].push(cat);
    return acc;
  }, {} as Record<string, typeof categories>);

  return (
    <>
      <DiscoveryHeader
        title="Browse All Categories"
        description="From leasing and marketing solutions to maintenance technology and resident services, discover best-in-class products and services designed to streamline your operations and enhance the resident experience."
        crumbs={[
          { label: "HOME", link: "/", active: false, id: "crumb-home" },
          { label: "ALL CATEGORIES", link: "/categories", active: true },
        ]}
      />

      <div className="flex justify-center md:py-12 py-12 bg-white">
        <div className="max-w-7xl flex-grow px-8" id="technology">
          <h2 className="font-bold">Technology</h2>
          <div className="flex gap-6 mt-6 flex-wrap md:flex-nowrap">
            <div className="max-w-sm border-r border-gray-200 pr-6">
              <h3 className="text-lg font-bold mb-3">Popular Categories</h3>
              {popularCategories.technology.map((cat, i) => (
                <PopularCategory key={cat.id} cat={cat} borderTop={i !== 0} />
              ))}
            </div>
            <div id="software-section">
              <h3 className="text-lg font-bold mb-3">Software</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                {categoriesByVendorType["Software"].map(cat => (
                  <CategoryLink key={cat.id} cat={cat} />
                ))}
              </div>
            </div>
            <div className="w-64" id="hardware-section">
              <h3 className="text-lg font-bold mb-3">Hardware</h3>
              <div className="grid grid-cols-1 gap-2">
                {categoriesByVendorType["Hardware"].map(cat => (
                  <CategoryLink key={cat.id} cat={cat} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-center md:py-12 py-12 bg-sky-50 bg-right bg-no-repeat">
        <div className="max-w-7xl flex-grow px-8" id="services">
          <h2 className="font-bold">Services</h2>
          <div className="flex flex-wrap gap-6 mt-6">
            <div className="max-w-sm border-r border-gray-200 pr-6">
              <h3 className="text-lg font-bold mb-3">Popular Categories</h3>

              {popularCategories.services.map((cat, i) => (
                <PopularCategory key={cat.id} cat={cat} borderTop={i !== 0} />
              ))}
            </div>
            <div className="w-64" id="agencies-section">
              <h3 className="text-lg font-bold mb-3">Agencies</h3>
              <div className="grid grid-cols-1 gap-2">
                {categoriesByVendorType["Agencies"].map(cat => (
                  <CategoryLink key={cat.id} cat={cat} />
                ))}
              </div>
            </div>
            <div className="w-64" id="professional-services-section">
              <h3 className="text-lg font-bold mb-3">Professional Services</h3>
              <div className="grid grid-cols-1 gap-2">
                {categoriesByVendorType["Professional Services"].map(cat => (
                  <CategoryLink key={cat.id} cat={cat} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-center md:py-12 py-12 bg-white">
        <div className="max-w-7xl flex-grow px-8" id="suppliers">
          <h2 className="font-bold">Suppliers</h2>
          <div className="flex gap-6 mt-6 flex-wrap">
            <div className="max-w-sm border-r border-gray-200 pr-6">
              <h3 className="text-lg font-bold mb-3">Popular Categories</h3>

              {popularCategories.suppliers.map((cat, i) => (
                <PopularCategory key={cat.id} cat={cat} borderTop={i !== 0} />
              ))}
            </div>
            <div id="materials-section">
              <h3 className="text-lg font-bold mb-3">Materials</h3>
              <div className="grid grid-cols-1 gap-2">
                {categoriesByVendorType["Materials"].map(cat => (
                  <CategoryLink key={cat.id} cat={cat} />
                ))}
              </div>
            </div>
            <div className="w-64" id="onsite-services-section">
              <h3 className="text-lg font-bold mb-3">Onsite Services</h3>
              <div className="grid grid-cols-1 gap-2">
                {categoriesByVendorType["Onsite Services"].map(cat => (
                  <CategoryLink key={cat.id} cat={cat} />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-center md:py-12 py-12 bg-sky-50 bg-right bg-no-repeat">
        <div className="max-w-7xl flex-grow px-8" id="all-categories">
          <h2 className="font-bold">All Categories</h2>
          <div className="flex flex-wrap gap-6 mt-6">
            <div className="flex flex-col gap-6 grow-[1]">
              <div>
                <h3 className="text-lg font-bold mb-3">Agencies</h3>
                <div className="flex flex-col flex-wrap gap-2">
                  {categoriesByVendorType["Agencies"].map(cat => (
                    <CategoryLink key={cat.id} cat={cat} />
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-3">Hardware</h3>
                <div className="flex flex-col flex-wrap gap-2">
                  {categoriesByVendorType["Hardware"].map(cat => (
                    <CategoryLink key={cat.id} cat={cat} />
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-lg font-bold mb-3">Materials</h3>
                <div className="flex flex-col flex-wrap gap-2">
                  {categoriesByVendorType["Materials"].map(cat => (
                    <CategoryLink key={cat.id} cat={cat} />
                  ))}
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-6 grow-[1]">
              <div>
                <h3 className="text-lg font-bold mb-3">Onsite Services</h3>
                <div className="flex flex-col flex-wrap gap-2">
                  {categoriesByVendorType["Onsite Services"].map(cat => (
                    <CategoryLink key={cat.id} cat={cat} />
                  ))}
                </div>
              </div>
              <div>
                <h3 className="text-lg font-bold mb-3">
                  Professional Services
                </h3>
                <div className="flex flex-col flex-wrap gap-2">
                  {categoriesByVendorType["Professional Services"].map(cat => (
                    <CategoryLink key={cat.id} cat={cat} />
                  ))}
                </div>
              </div>
            </div>
            <div className="grow-[3]">
              <h3 className="text-lg font-bold mb-3">Software</h3>
              <div className="flex flex-wrap gap-4">
                <div className="flex flex-col flex-wrap gap-2">
                  {categoriesByVendorType["Software"]
                    .slice(0, categoriesByVendorType["Software"].length / 2)
                    .map(cat => (
                      <CategoryLink key={cat.id} cat={cat} />
                    ))}
                </div>
                <div className="flex flex-col flex-wrap gap-2">
                  {categoriesByVendorType["Software"]
                    .slice(categoriesByVendorType["Software"].length / 2)
                    .map(cat => (
                      <CategoryLink key={cat.id} cat={cat} />
                    ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
