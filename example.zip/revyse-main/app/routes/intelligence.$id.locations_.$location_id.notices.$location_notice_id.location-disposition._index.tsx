import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { CTA } from "~/components/cta.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  Permission,
} from "~/utils/intelligence-permission.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { useMemo, useState } from "react";
import { IntelligenceDetailsSection } from "~/components/intelligence/intelligence-details-section.component";
import { LocationNoticeStatus } from "@prisma/client";
import { UserWithEmail } from "~/components/intelligence/location-notices/user-with-email.component";
import {
  LocationNoticeLinkPrefixes,
  LocationNoticeType,
} from "~/utils/location-notice.utils";
import { ChevronUpIcon, TrashIcon } from "@heroicons/react/24/outline";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
import { Button } from "~/components/button.component";
import { ConfirmDeleteModal } from "~/components/modals/confirm-delete-modal.component";
import { redirectWithSuccess } from "remix-toast";
import { CanDo } from "~/components/intelligence/can-do.component";
import { LocationNoticeDispositionBanner } from "~/components/intelligence/location-notices/location-notice-disposition-banner";
dayjs.extend(utc);

const defaultVendorsToShow = 8;

export async function action({ request, params }: ActionFunctionArgs) {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocationNotices],
      locationId: params.location_id,
    }
  );

  const { locationNoticeService } = await WebDIContainer();

  const locationNoticeId = params.location_notice_id!;

  await locationNoticeService.deleteLocationNoticeDisposition(locationNoticeId);

  return redirectWithSuccess(
    `/intelligence/${account.id}/locations/${params.location_id}/notices`,
    "Disposition notice deleted successfully"
  );
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewLocationNotices],
      locationId: params.location_id,
    }
  );

  const { locationService, locationNoticeService } = await WebDIContainer();

  const location = await locationService.getLocation(params.location_id!);

  if (!location) {
    throw new Response("Location not found", { status: 404 });
  }

  const locationNoticeId = params.location_notice_id!;

  const locationNotice =
    await locationNoticeService.getLocationNoticeDisposition(
      locationNoticeId,
      location.id,
      user,
      account
    );

  if (!locationNotice) {
    throw new Response("Location notice not found", { status: 404 });
  }

  return json({
    account,
    location,
    locationNotice,
  });
}

export default function LocationDispositionNoticeDetails() {
  const { account, location, locationNotice } = useLoaderData<typeof loader>();

  const [showAllVendors, setShowAllVendors] = useState(false);

  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  const vendorsToShow = useMemo(() => {
    if (showAllVendors) {
      return locationNotice.location_notice_recipients;
    }
    return locationNotice.location_notice_recipients.slice(
      0,
      defaultVendorsToShow
    );
  }, [showAllVendors, locationNotice.location_notice_recipients]);

  const completeLink = useMemo(
    () =>
      `/intelligence/${account.id}/locations/${location.id}/notices/${
        locationNotice.id
      }/${
        LocationNoticeLinkPrefixes[LocationNoticeType.LocationNoticeDisposition]
      }/${locationNotice.step.toLocaleLowerCase()}`,
    [account, location, locationNotice]
  );

  const isUpdatedDispositionNotice = useMemo(
    () => locationNotice.original_location_notice_id !== null,
    [locationNotice]
  );

  const sendUpdatedNoticeLink = useMemo(
    () =>
      `/intelligence/${account.id}/locations/${location.id}/notices/new/${
        LocationNoticeLinkPrefixes[LocationNoticeType.LocationNoticeDisposition]
      }/details?original_location_notice_id=${locationNotice.id}`,
    [account, location, locationNotice]
  );

  return (
    <>
      <ConfirmDeleteModal
        isOpen={!!confirmDeleteOpen}
        onClose={() => setConfirmDeleteOpen(false)}
        submitOnConfirm={true}
        title="Delete Location Notice"
        message="Are you sure you want to permanently delete this location notice?"
      />
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
          },
          {
            name: "Notices",
            to: `/intelligence/${account.id}/locations/${location.id}/notices`,
          },
          {
            name: "Disposition notice details",
            to: `/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/location-disposition`,
            active: true,
          },
        ]}
        title={
          isUpdatedDispositionNotice ? (
            <>
              Updated disposition notice details: <br /> {location.name}
            </>
          ) : (
            <>
              Disposition notice details: <br /> {location.name}
            </>
          )
        }
        buttonsSlot={
          <CanDo permission={Permission.ManageLocationNotices}>
            {locationNotice.status === LocationNoticeStatus.Sent ? (
              <CTA to={sendUpdatedNoticeLink}>Send Updated Notice</CTA>
            ) : (
              <>
                <Button
                  color="transparent"
                  onClick={() => setConfirmDeleteOpen(true)}
                  className="px-0"
                >
                  <TrashIcon className="h-6 w-6" />
                </Button>
                <CTA to={completeLink}>Complete Notice Now</CTA>
              </>
            )}
          </CanDo>
        }
      />
      <LocationNoticeDispositionBanner
        locationNoticeDisposition={locationNotice}
      />
      <main className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min gap-y-40 divide-y divide-gray-200">
        <IntelligenceDetailsSection title="Notice Information">
          <div className="grid grid-cols-1 gap-x-4 gap-y-4 md:grid-cols-3 md:gap-x-6 md:gap-y-6">
            <div className="col-span-1 font-medium">Date of Activity</div>
            <div className="col-span-1 md:col-span-2">
              {dayjs.utc(locationNotice.status_updated_at).format("MM/DD/YYYY")}
            </div>

            <div className="col-span-1 font-medium">
              {locationNotice.status === LocationNoticeStatus.Sent
                ? "Sent by"
                : "Created by"}
            </div>
            <div className="col-span-1 md:col-span-2">
              <UserWithEmail
                email={locationNotice.manager_account_role.user.email}
                name={`${locationNotice.manager_account_role.user.first_name} ${locationNotice.manager_account_role.user.last_name}`}
              />
            </div>
          </div>
        </IntelligenceDetailsSection>
        <IntelligenceDetailsSection
          title="Disposition Information"
          className="pt-10"
        >
          <div className="grid grid-cols-1 gap-x-4 gap-y-4 md:grid-cols-3 md:gap-x-6 md:gap-y-6">
            <div className="col-span-1 font-medium">
              Expected Disposition Date
            </div>
            <div className="col-span-1 md:col-span-2">
              {dayjs.utc(locationNotice.disposition_date).format("MM/DD/YYYY")}
            </div>

            <div className="col-span-1 font-medium">
              Requested Service Termination Date
            </div>
            <div className="col-span-1 md:col-span-2">
              {dayjs.utc(locationNotice.termination_date).format("MM/DD/YYYY")}
            </div>

            <div className="col-span-1 font-medium">
              Instructions for Final Invoices
            </div>
            <div className="col-span-1 md:col-span-2">
              {locationNotice.termination_instructions ?? "--"}
            </div>

            <div className="col-span-1 font-medium">Task Owner</div>
            <div className="col-span-1 md:col-span-2">
              <UserWithEmail
                email={locationNotice.task_owner.user.email}
                name={`${locationNotice.task_owner.user.first_name} ${locationNotice.task_owner.user.last_name}`}
              />
            </div>
          </div>
        </IntelligenceDetailsSection>
        <IntelligenceDetailsSection
          title={`Vendors Notified (${
            locationNotice.status === LocationNoticeStatus.Sent
              ? locationNotice.location_notice_recipients.length
              : 0
          })`}
          className="pt-10"
        >
          <div className="grid grid-cols-1 gap-x-4 gap-y-4 md:grid-cols-3 md:gap-x-6 md:gap-y-6">
            {locationNotice.status === LocationNoticeStatus.Sent ? (
              <>
                {vendorsToShow.map(recipient => (
                  <>
                    <div className="col-span-1 font-medium">
                      {recipient.manager_account_vendor.vendor.name}
                    </div>
                    <div
                      key={recipient.id}
                      className="col-span-1 md:col-span-2"
                    >
                      <UserWithEmail
                        email={recipient.email!}
                        name={recipient.name ?? undefined}
                      />
                    </div>
                  </>
                ))}
                {locationNotice.location_notice_recipients.length >
                  defaultVendorsToShow && (
                  <div className="col-span-full">
                    <Button
                      color="transparent"
                      onClick={() => setShowAllVendors(!showAllVendors)}
                      className="gap-x-2 px-0"
                    >
                      {showAllVendors ? (
                        <>
                          Show less vendors
                          <ChevronUpIcon className="h-5 w-5" />
                        </>
                      ) : (
                        <>
                          Show all vendors
                          <ChevronDownIcon className="h-5 w-5" />
                        </>
                      )}
                    </Button>
                  </div>
                )}
              </>
            ) : (
              <div className="col-span-full">None </div>
            )}
          </div>
        </IntelligenceDetailsSection>
      </main>
    </>
  );
}
