import type { ActionFunctionArgs } from "@remix-run/node";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { castFormFields } from "~/utils/type.utils";
import { Permission } from "~/utils/intelligence-permission.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const MB = 1024 * 1024;
const FILE_BYTE_LIMIT = 50 * MB;

const UpdateContractFileForm = z.object({
  id: z.string(),
  name: z.string(),
  file: z.string().nullable(),
});

const DeleteContractFileForm = z.object({
  id: z.string().uuid(),
});

export async function action({ params, request }: ActionFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContracts],
    }
  );

  const contractId = params.contract_id as string;

  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "file", byteLimit: FILE_BYTE_LIMIT },
  ]);

  if (form.get("intent") === "delete") {
    return deleteContractFile({ form });
  }

  return updateContractFile({ form, contractId });
}

async function deleteContractFile({ form }: { form: FormData }) {
  const { contractService } = await WebDIContainer();
  const fields = {
    id: form.get("id"),
  };

  const validation = DeleteContractFileForm.safeParse(fields);

  if (validation.success) {
    const response = await contractService.deleteContractDocument(
      validation.data.id
    );

    if (response.success) {
      return jsonWithSuccess(
        {
          success: true,
          fields: castFormFields(fields),
          contractFile: null,
          errors: issuesByKey([]),
        },
        "Document deleted"
      );
    } else {
      return jsonWithError(
        {
          success: false,
          fields: null,
          contractFile: null,
          errors: { server: [response.error] } as Record<string, string[]>,
        },
        "Error deleting document"
      );
    }
  }
}

async function updateContractFile({
  form,
  contractId,
}: {
  form: FormData;
  contractId: string;
}) {
  const { contractService } = await WebDIContainer();

  const fields = {
    id: form.get("id"),
    name: form.get("name"),
    file: form.get("file"),
  };

  const validation = UpdateContractFileForm.safeParse(fields);
  if (validation.success) {
    const contractFile = await contractService.handleContractDocument({
      ...validation.data,
      contractId,
    });

    return jsonWithSuccess(
      {
        success: true,
        contractFile,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      },
      `Document ${validation.data.id?.includes("new_") ? "created" : "updated"}`
    );
  }
  return jsonWithError(
    {
      success: false,
      contractFile: null,
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    "Error updating document"
  );
}
