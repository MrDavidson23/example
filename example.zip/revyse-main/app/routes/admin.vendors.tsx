import type { Prisma } from "@prisma/client";
import { VendorState } from "@prisma/client";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { useMemo } from "react";
import { CrudListPage } from "~/components/crud-list-page.component";
import type { TableStateConfig } from "~/components/crud-table.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { getTableState } from "~/utils/table-state.server";

const PAGE_SIZE = 20;

const VendorStateLabels: {
  [key in VendorState]: string;
} = {
  [VendorState.ApprovedForPublishing]: "Approved for Publishing",
  [VendorState.NotApproved]: "Not Approved",
  [VendorState.RevyseIntelligenceOnly]: "Revyse Intelligence-Only",
} as const;

export async function loader({ request }: LoaderFunctionArgs) {
  const { vendorService } = await WebDIContainer();

  const { pagination, orderBy, search } = getTableState({
    request,
    defaults: {
      pageSize: PAGE_SIZE,
      orderBy: "name:asc",
    },
  });

  const where: Prisma.VendorWhereInput = search
    ? {
        name: { contains: search, mode: "insensitive" },
      }
    : {};

  const vendors = await vendorService.getVendors({
    filters: where,
    orderBy,
    take: pagination.take,
    skip: pagination.skip,
  });

  const total = await vendorService.getVendorsCount({
    filters: where,
  });

  return json({
    vendors,
    total,
  });
}

export default function AdminVendorsRoute() {
  const { vendors, total } = useLoaderData<typeof loader>();

  const tableStateConfig: TableStateConfig = useMemo(
    () => ({
      pagination: {
        useSearchParams: true,
        total,
      },
      orderBy: {
        useSearchParams: true,
      },
      search: {
        useSearchParams: true,
        resetPageOnSearch: true,
        inputPlaceholder: "Search Vendors",
      },
    }),
    [total]
  );

  return (
    <CrudListPage
      crumbs={[
        {
          name: "Vendors",
          to: "/admin/vendors",
          active: true,
        },
      ]}
      cols={[
        // { name: "id", label: "ID" },
        { name: "name", label: "Name", sortable: true },
        { name: "created_at", label: "Created", type: "date", sortable: true },
        {
          name: "state",
          label: "State",
          renderer: vendor => VendorStateLabels[vendor.state],
          sortable: true,
        },
      ]}
      data={vendors}
      title="Vendors"
      subtitle="A list of all vendors."
      tableStateConfig={tableStateConfig}
    />
  );
}
