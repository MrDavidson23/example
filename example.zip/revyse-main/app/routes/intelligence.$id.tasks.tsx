import { useLoaderData, useNavigate, useSearchParams } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { isEmpty } from "lodash";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import PageTabs from "~/components/intelligence/page-tabs.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Permission } from "~/utils/intelligence-permission.utils";
import { Toggle } from "~/components/toggle.component";
import { TasksTable } from "~/components/intelligence/tasks/tasks-table.component";
import { useCallback, useMemo } from "react";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import type { ModalFilters } from "~/components/intelligence/filters-modal.component";
import { TaskScheduleStatusLabels } from "~/utils/constants.utils";
import { ManagerAccountRoleType } from "@prisma/client";
import { IntelligenceFilter } from "~/components/intelligence/intelligence-filter.component";
import { Pagination } from "~/components/intelligence/pagination.component";
import type { TasksFilters } from "~/services/manager-account-task.service.server";
import {
  getFiltersFromSearchParams,
  getOrderByFromSearchParams,
  getPaginationFromSearchParams,
  updateSearchParams,
} from "~/utils/filtering.utils";
import { TaskType, getTaskType } from "~/utils/tasks.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const PER_PAGE = 10;

enum CustomStatusFilter {
  Active = "active",
  Upcoming = "upcoming",
  Archived = "archived",
}

const ColumnsToShowByStatus = {
  [CustomStatusFilter.Active]: [
    "taskName",
    "dueDate",
    "taskOwner",
    "scheduleStatus",
  ],
  [CustomStatusFilter.Upcoming]: [
    "taskName",
    "dueDate",
    "taskOwner",
    "startDateAway",
  ],
  [CustomStatusFilter.Archived]: [
    "taskName",
    "dueDate",
    "taskOwner",
    "completionStatus",
  ],
};

export async function loader({ request, params }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewTasks],
    }
  );

  const managerAccountId = account.id;

  const { managerAccountTaskService, managerAccountRoleService } =
    await WebDIContainer();

  const { searchParams } = new URL(request.url);

  const filters: TasksFilters = getFiltersFromSearchParams(searchParams, [
    "schedule_status",
    "start_date",
    "due_date",
    "completion_status",
  ]);

  const pagination = getPaginationFromSearchParams(searchParams, {
    perPage: PER_PAGE,
  });

  const orderBy = getOrderByFromSearchParams(searchParams, "due_date");

  const status = (searchParams.get("status") ??
    CustomStatusFilter.Active) as CustomStatusFilter | null;

  const onlyMyTasks =
    isEmpty(searchParams.get("onlyMyTasks")) ||
    searchParams.get("onlyMyTasks") === "true";

  if (status) {
    filters.custom_status = status;
  }

  const activeTasksCount = await managerAccountTaskService.getTasksCount(
    user,
    account,
    undefined,
    { custom_status: "active" }
  );

  const upcomingTasksCount = await managerAccountTaskService.getTasksCount(
    user,
    account,
    undefined,
    { custom_status: "upcoming" }
  );

  const tasks = await managerAccountTaskService.getTasks(
    user,
    account,
    onlyMyTasks ? user.id : undefined,
    filters,
    pagination,
    orderBy
  );
  const tasksCount = await managerAccountTaskService.getTasksCount(
    user,
    account,
    onlyMyTasks ? user.id : undefined,
    filters
  );

  const tasksOwners = await managerAccountRoleService.getManagerAccountRoles(
    managerAccountId,
    {
      permissionLevel: [
        ManagerAccountRoleType.Owner,
        ManagerAccountRoleType.Editor,
      ],
      page: 1,
      perPage: 500,
      status: [],
    }
  );

  return {
    user,
    account,
    tasks,
    tasksOwners,
    tasksCount,
    activeTasksCount,
    upcomingTasksCount,
  };
}

export default function Tasks() {
  const navigate = useNavigate();
  const {
    account,
    tasks,
    tasksOwners,
    tasksCount,
    activeTasksCount,
    upcomingTasksCount,
  } = useLoaderData<typeof loader>();

  const [searchParams, setSearchParams] = useSearchParams();

  const pagination = getPaginationFromSearchParams(searchParams, {
    perPage: PER_PAGE,
  });

  const status: CustomStatusFilter = useMemo(() => {
    return (searchParams.get("status") ??
      CustomStatusFilter.Active) as CustomStatusFilter;
  }, [searchParams]);

  const onlyMyTasks: boolean = useMemo(() => {
    return (
      isEmpty(searchParams.get("onlyMyTasks")) ||
      searchParams.get("onlyMyTasks") === "true"
    );
  }, [searchParams]);

  const handlePageChange = (page: number) => {
    setSearchParams(oldSearchParams => {
      updateSearchParams(oldSearchParams, { page: String(page) });
      return oldSearchParams;
    });
  };

  const changeStatus = (status: CustomStatusFilter) => {
    setSearchParams(oldSearchParams => {
      updateSearchParams(oldSearchParams, {
        status: status === CustomStatusFilter.Active ? undefined : status,
        page: "1",
      });
      return oldSearchParams;
    });
  };

  const handleOnFilter = ({
    searchQuery,
    filters,
  }: {
    searchQuery?: string;
    filters?: ModalFilters;
  }) => {
    setSearchParams(oldSearchParams => {
      if (searchQuery !== undefined) {
        updateSearchParams(oldSearchParams, { searchQuery, page: "1" });
      }

      if (filters !== undefined) {
        updateSearchParams(oldSearchParams, { ...filters, page: "1" });
      }

      return oldSearchParams;
    });
  };

  const toggleOnlyMyTasks = (newValue: boolean) => {
    setSearchParams(oldSearchParams => {
      updateSearchParams(oldSearchParams, {
        onlyMyTasks: newValue ? undefined : "false",
        page: "1",
      });
      return oldSearchParams;
    });
  };

  const onOrderBy = useCallback(
    (orderBy: string) => {
      setSearchParams(oldSearchParams => {
        updateSearchParams(oldSearchParams, { orderBy, page: "1" });
        return oldSearchParams;
      });
    },
    [setSearchParams]
  );

  const description = useMemo(() => {
    if (status === CustomStatusFilter.Active) {
      return `View and manage the active tasks for ${account.name}. Tasks help to keep your contracts,
      vendors, and account information up to date.`;
    } else if (status === CustomStatusFilter.Upcoming) {
      return `View and manage the upcoming tasks for ${account.name}.`;
    } else if (status === CustomStatusFilter.Archived) {
      return `View and manage the archived tasks for ${account.name}.`;
    }
  }, [status, account.name]);

  return (
    <>
      <div className="space-y-8 pb-12">
        <PageTabs
          validationType="urlParams"
          options={[
            {
              currentParam: status,
              expectedResult: CustomStatusFilter.Active,
              onNavigate: () => changeStatus(CustomStatusFilter.Active),
              label: "Active Tasks",
              badgeCount: activeTasksCount,
            },
            {
              currentParam: status,
              expectedResult: CustomStatusFilter.Upcoming,
              onNavigate: () => changeStatus(CustomStatusFilter.Upcoming),
              label: "Upcoming Tasks",
              badgeCount: upcomingTasksCount,
            },
            {
              currentParam: status,
              expectedResult: CustomStatusFilter.Archived,
              onNavigate: () => changeStatus(CustomStatusFilter.Archived),
              label: "Archived Tasks",
            },
          ]}
          columns={3}
        ></PageTabs>
        <IntelligenceScreenHeader
          title={`All ${status} tasks`}
          description={description}
        />
        <div className="w-full grid grid-cols-1 md:grid-cols-4 items-center gap-4">
          <IntelligenceFilter
            modalFilters={[
              {
                name: "schedule_status",
                type: "MultiSelect",
                label: "Schedule Status",
                options: Object.entries(TaskScheduleStatusLabels).map(
                  ([value, label]) => ({
                    label,
                    value,
                  })
                ),
              },
              {
                name: "start_date",
                type: "DateRange",
                label: "Start Date",
              },
              {
                name: "due_date",
                type: "DateRange",
                label: "Due Date",
              },
              {
                name: "task_owner",
                type: "Select",
                label: "Task Owner",
                options: tasksOwners.map(owner => ({
                  label: `${owner.user.first_name} ${owner.user.last_name} - ${owner.role}`,
                  value: owner.id,
                })),
              },
            ]}
            filterBar={{
              inputPlaceholder: "Search contract name or vendor name",
              className: "md:col-span-3",
            }}
            currentFilters={Object.fromEntries(searchParams.entries())}
            onFilter={handleOnFilter}
          />
          <div className="flex space-x-2 place-self-center">
            <Toggle checked={onlyMyTasks} onChange={toggleOnlyMyTasks} />
            <div>Only show my tasks</div>
          </div>
        </div>
        <TasksTable
          items={tasks}
          onClickRow={task => {
            if (getTaskType(task) === TaskType.TaskContractRenewal) {
              navigate(
                `/intelligence/${account.id}/tasks/contract-renewal/${task.id}`
              );
            } else if (getTaskType(task) === TaskType.TaskLocationDisposition) {
              navigate(
                `/intelligence/${account.id}/tasks/location-disposition/${task.id}`
              );
            }
          }}
          columnsToShow={ColumnsToShowByStatus[status]}
          onOrderBy={onOrderBy}
          accountId={account.id}
        />
        <Pagination
          resultsText={`${tasks.length} out of ${tasksCount} results`}
          pageNumbers={Array.from(
            { length: Math.ceil(tasksCount / pagination.perPage) },
            (_, i) => i + 1
          )}
          currentPage={pagination.page}
          totalPages={Math.ceil(tasksCount / pagination.perPage)}
          handleCallback={handlePageChange}
        />
      </div>
    </>
  );
}
