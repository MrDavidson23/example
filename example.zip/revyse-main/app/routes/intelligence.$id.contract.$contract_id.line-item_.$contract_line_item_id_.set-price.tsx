import { Form, useLoaderData, useNavigation } from "@remix-run/react";
import type {
  ActionFunctionArgs,
  LinksFunction,
  LoaderFunctionArgs,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { isEmpty, isNil } from "lodash";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import {
  ContractPricingType,
  ContractLineItemPriceCadence,
  ContractLineItemPriceIncreaseCadence,
} from "@prisma/client";
import { z } from "zod";
import {
  Boolean,
  Currency,
  NonEmptyString,
} from "~/utils/validation.utils.server";
import { issuesByKey } from "~/utils/form.utils.server";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import {
  jsonWithError,
  redirectWithError,
  redirectWithSuccess,
} from "remix-toast";
import { castFormFields } from "~/utils/type.utils";
import { SetPriceForm } from "~/components/intelligence/set-price-form.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { CTA } from "~/components/cta.component";
import stylesheetQuill from "react-quill/dist/quill.snow.css";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

export const links: LinksFunction = () => [
  { rel: "stylesheet", href: stylesheetQuill },
];

const SearchDepartmentForm = z.object({
  term: NonEmptyString,
});

type JsonData = {
  fields?: Record<string, string>;
  success?: boolean;
  errors?: Record<string, string[] | null>;
  departments?:
    | {
        department: string;
      }[]
    | null;
};

const ContractLineItem = z
  .object({
    name: z.string().min(1, "Line Item name is required"),
    is_corporate_only: Boolean,
    pricing_type: z.nativeEnum(ContractPricingType).nullish(),
    id: z.string().uuid().optional(),
    cadence: z.nativeEnum(ContractLineItemPriceCadence).nullish(),
    price: Currency,
    setup_fee: Currency,
    discount: Currency,
    price_increase_percent: z.number().optional().nullable(),
    price_increase_cadence: z
      .nativeEnum(ContractLineItemPriceIncreaseCadence)
      .or(z.literal("null").transform(v => (v === "null" ? null : v))),
    notes: z.string().optional(),
    contract_line_item_products: z.array(
      z.object({
        id: z.string().uuid().optional(),
        department: z.string().transform(v => v.trim()),
        price: Currency,
        product_id: z.string().uuid(),
      })
    ),
    contract_line_item_fees: z.array(
      z.object({
        id: z.string().uuid().optional(),
        department: z.string().transform(v => v.trim()),
        price: Currency,
      })
    ),
    estimated_cost: Currency,
    seats_number: z.number().int().optional().nullable(),
    contract_line_item_items: z.array(
      z.object({
        item_name: z.string().min(1, "Required"),
        quantity: z
          .number({ invalid_type_error: "Required" })
          .int()
          .min(1, "Should be positive"),
        price: Currency,
      })
    ),
  })
  .superRefine((values, ctx) => {
    if (
      values.price_increase_percent !== null &&
      values.price_increase_percent !== 0 &&
      !values.price_increase_cadence
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message:
          "When Contracted Price Increase Percentage is provided, Contracted Price Increase Cadence is required",
        path: ["price_increase_cadence"],
      });
    }

    if (
      values.pricing_type === ContractPricingType.PerSeat &&
      !values.seats_number
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Seats number is required for 'Per Seat' pricing type",
        path: ["seats_number"],
      });
    }
  });

export const searchDepartment = async ({
  form,
  id,
  accountId,
}: {
  form: FormData;
  id: string;
  accountId: string;
}) => {
  const { managerAccountService } = await WebDIContainer();

  const fields = {
    term: form.get("term"),
  };
  const validation = SearchDepartmentForm.safeParse(fields);

  if (validation.success) {
    const departments = await managerAccountService.getAccountDepartmentList(
      accountId,
      { query: validation.data.term }
    );

    return json<JsonData>({
      success: true,
      fields: castFormFields(fields),
      departments,
      errors: issuesByKey([]),
    });
  }
  return json<JsonData>({
    success: false,
    fields: castFormFields(fields),
    departments: null,
    errors: issuesByKey(validation.error.issues),
  });
};

export const updateAction = async ({
  form,
  id,
  account_id,
  contract_id,
}: {
  form: FormData;
  id: string;
  account_id: string;
  contract_id: string;
}) => {
  const { contractLineItemService } = await WebDIContainer();

  const tierProductsIds = form.getAll(
    `contract_line_item.${id}.contract_line_item_products.id`
  ) as string[];
  const tierProductsDepartments = form.getAll(
    `contract_line_item.${id}.contract_line_item_products.department`
  ) as string[];
  const tierProductsPrices = form.getAll(
    `contract_line_item.${id}.contract_line_item_products.price`
  ) as string[];
  const tierContractLineItemProductIds = form.getAll(
    `contract_line_item.${id}.contract_line_item_products.contract_line_item_product_id`
  ) as string[];

  const contract_line_item_products = tierProductsIds.map(
    (tierProductId, j) => {
      return {
        id: tierProductId.indexOf("new") === 0 ? undefined : tierProductId,
        department: tierProductsDepartments[j],
        price: tierProductsPrices[j],
        product_id: tierContractLineItemProductIds[j],
      };
    }
  );

  const tierFeesIds = form.getAll(
    `contract_line_item.${id}.contract_line_item_fees.id`
  ) as string[];
  const tierFeesFees = form.getAll(
    `contract_line_item.${id}.contract_line_item_fees.department`
  ) as string[];
  const tierFeesPrices = form.getAll(
    `contract_line_item.${id}.contract_line_item_fees.price`
  ) as string[];

  const contract_line_item_fees = tierFeesIds.map((tierFeeId, j) => {
    return {
      id: tierFeeId.indexOf("new") === 0 ? undefined : tierFeeId,
      department: tierFeesFees[j],
      price: tierFeesPrices[j],
    };
  });

  const seats = form.get("contract_line_item.seats_number") as string;
  const increasePercent = form.get(
    "contract_line_item.price_increase_percent"
  ) as string;

  const contractLineItemItemNames = form.getAll(
    `contract_line_item.contract_line_item_items.item_name`
  ) as string[];

  const contractLineItemItemQuantities = form.getAll(
    `contract_line_item.contract_line_item_items.quantity`
  ) as string[];

  const contractLineItemItemPrices = form.getAll(
    `contract_line_item.contract_line_item_items.price`
  ) as string[];

  const contract_line_item_items = contractLineItemItemNames
    .map((itemName, j) => {
      const quantity = contractLineItemItemQuantities[j];
      const price = contractLineItemItemPrices[j];

      if (
        isEmpty(itemName) &&
        (isEmpty(quantity) || quantity === "0") &&
        (isEmpty(price) || price === "$0")
      ) {
        return null;
      }

      return {
        item_name: itemName,
        quantity: parseInt(quantity),
        price,
      };
    })
    .filter(item => item !== null);

  const fields = {
    id: id,
    name: form.get("name") as string,
    is_corporate_only: form.get("is_corporate_only"),
    cadence: form.get("contract_line_item.cadence") as string,
    pricing_type: form.get("contract_line_item.pricing_type") as string,
    seats_number: seats ? parseInt(seats) : null,
    price: form.get("contract_line_item.price") as string,
    estimated_cost: form.get("contract_line_item.estimated_cost") as string,
    setup_fee: form.get("contract_line_item.setup_fee") as string,
    discount: form.get("contract_line_item.discount") as string,
    price_increase_percent: increasePercent
      ? parseFloat(increasePercent)
      : null,
    price_increase_cadence: form.get(
      "contract_line_item.price_increase_cadence"
    ) as string,
    notes: form.get("notes") as string,
    contract_line_item_products,
    contract_line_item_fees,
    contract_line_item_items,
  };

  const validation = await ContractLineItem.safeParseAsync(fields);

  if (validation.success) {
    try {
      const contractLineItem =
        await contractLineItemService.updateContractLineItem({
          id,
          data: validation.data,
        });

      if (isNil(contractLineItem)) {
        throw new Response("No contract contractLineItem found", {
          status: 404,
        });
      }

      return redirectWithSuccess(
        `/intelligence/${account_id}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/summary`,
        "Pricing updated successfully"
      );
    } catch (e: any) {
      console.error(e);
      let issue = { path: ["general"], message: e.message };
      return jsonWithError(
        {
          success: false,
          fields,
          errors: issuesByKey([issue]),
          departments: null,
        },
        DEFAULT_FORM_ERROR_MESSAGE,
        { status: 400 }
      );
    }
  }
  return jsonWithError(
    {
      success: false,
      fields,
      errors: issuesByKey(validation.error.issues),
      departments: null,
    },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
};

async function deleteAction({
  id,
  contractId,
  account_id,
}: {
  id: string;
  contractId: string;
  account_id: string;
}) {
  const { contractLineItemService } = await WebDIContainer();
  const response = await contractLineItemService.deleteContractLineItem(id);

  if (response.success) {
    return redirectWithSuccess(
      `/intelligence/${account_id}/contract/${contractId}/line-item/`,
      "Line item deleted successfully"
    );
  } else {
    return redirectWithError(
      `/intelligence/${account_id}/contract/${contractId}/line-item/`,
      "Cannot discard the line item"
    );
  }
}

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContractLineItem],
    }
  );
  const id = params.contract_line_item_id!;
  const contractId = params.contract_id!;

  const form = await request.formData();
  const intent = form.get("intent");
  if (intent === "delete") {
    return deleteAction({ id, contractId, account_id: account.id });
  } else if (id && intent === "updateContractLineItem") {
    return updateAction({
      form,
      id,
      account_id: account.id,
      contract_id: contractId,
    });
  } else if (id && intent === "searchDepartment") {
    return searchDepartment({ form, id, accountId: account.id });
  }
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContractLineItem],
    }
  );

  const { contractLineItemService } = await WebDIContainer();

  const id = params.contract_line_item_id!;
  const loadedContractLineItem =
    await contractLineItemService.loadContractLineItem(id);

  if (!loadedContractLineItem) {
    throw new Response("Not found", { status: 404 });
  }

  return json({
    user,
    account,
    loadedContractLineItem,
  });
}

export default function PriceConfigProducts() {
  const { loadedContractLineItem, user, account } =
    useLoaderData<typeof loader>();

  const navigation = useNavigation();

  // Permissions
  const userCanManageContractLineItemProducts = canDoOnAccount(
    user,
    account,
    Permission.ManageContractLineItem
  );
  return (
    <Form className="space-y-8" method="post">
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All contracts",
            to: `/intelligence/${account.id}/contracts`,
          },
          {
            name: loadedContractLineItem.contract.name,
            to: `/intelligence/${account.id}/contract/${loadedContractLineItem.contract_id}/details`,
          },
          {
            name: "Products and line items",
            to: `/intelligence/${account.id}/contract/${loadedContractLineItem.contract_id}/line-item`,
          },
          {
            name: loadedContractLineItem.name ?? "Create new line item",
            to: loadedContractLineItem.name
              ? `/intelligence/${account.id}/contract/${loadedContractLineItem.contract_id}/line-item/${loadedContractLineItem.id}/summary`
              : `/intelligence/${account.id}/contract/${loadedContractLineItem.contract_id}/line-item/${loadedContractLineItem.id}`,
            id: "line-item-crumb",
          },
          {
            name: `Set pricing`,
            to: `/intelligence/${account.id}/contract/${loadedContractLineItem.contract_id}/line-item/${loadedContractLineItem.id}/set-price`,
            active: true,
          },
        ]}
        title="Set pricing for this line item"
        description="Entering detailed pricing information will allow you to visualize your contracted spend by product, department, location, and resident lifecycle phase, helping you optimize your vendors and spend."
        classNames={{ buttons: "space-x-4 items-center" }}
        buttonsSlot={
          <>
            {userCanManageContractLineItemProducts && (
              <CTA
                type="button"
                to={`/intelligence/${account.id}/contract/${loadedContractLineItem.contract_id}/line-item/${loadedContractLineItem.id}/`}
                variant="coral"
                fillStyle="outline"
                className="w-2/4 lg:w-fit my-3 lg:my-0"
              >
                Edit Products
              </CTA>
            )}
            <CTA type="submit" id="save-button">
              {navigation.state === "submitting"
                ? "Submitting..."
                : "Save Line Item"}
            </CTA>
          </>
        }
      />
      <SetPriceForm
        account={account}
        user={user}
        contractLineItem={loadedContractLineItem}
      />
    </Form>
  );
}
