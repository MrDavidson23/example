import type { User } from "@prisma/client";
import type { ActionFunctionArgs } from "@remix-run/node";
import {
  json,
  unstable_composeUploadHandlers,
  unstable_createMemoryUploadHandler,
  unstable_parseMultipartFormData,
} from "@remix-run/node";
import csvToJson from "csvtojson";
import { pick } from "lodash";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { mapGeneralLedgerRows } from "~/utils/general-ledger.utils.server";
import { Permission } from "~/utils/intelligence-permission.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

export async function action({ request, params }: ActionFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );

  const managerAccountId = account.id;

  const uploadHandler = unstable_composeUploadHandlers(
    unstable_createMemoryUploadHandler()
  );

  const formData = await unstable_parseMultipartFormData(
    request,
    uploadHandler
  );

  const intent = formData.get("intent");

  if (intent == "upload") {
    const file = formData.get("file");

    if (!file) {
      return json({ error: "No file uploaded", vendors: [] });
    }

    if (file instanceof File) {
      return await handleGeneralLedgerUpload(file, managerAccountId);
    } else {
      return json({ error: "Invalid file uploaded", vendors: [] });
    }
  } else if (intent == "add-vendors") {
    return await handleAssociateVendors(formData, managerAccountId, user);
  }

  return json({ error: "Invalid intent" });
}

async function handleGeneralLedgerUpload(file: File, managerAccountId: string) {
  const { managerAccountVendorService } = await WebDIContainer();
  const csvData = await file.text();
  const jsonData = await csvToJson().fromString(csvData);

  const generalLedgerRowsData = mapGeneralLedgerRows(jsonData);

  await managerAccountVendorService.createGeneralLedgerImport({
    manager_account: { connect: { id: managerAccountId } },
    general_ledger_import_rows: {
      createMany: {
        data: generalLedgerRowsData,
      },
    },
  });

  const vendorNamesSet = Array.from(
    new Set(generalLedgerRowsData.map(row => row.parsed_vendor_name))
  );
  vendorNamesSet.sort();

  const vendors = await Promise.all(
    vendorNamesSet.map(async vendor => {
      const vendors = await managerAccountVendorService.searchVendorNameMatches(
        vendor,
        managerAccountId
      );

      const options = vendors.map(vendor =>
        pick(vendor, [
          "id",
          "name",
          "slug",
          "vendor_associated",
          "description",
          "logo_file_id",
        ])
      );

      return {
        fromGL: vendor,
        options: [
          ...options,
          {
            name: vendor,
            id: "new",
            slug: null,
            vendor_associated: false,
            description: `Add a previously unknown vendor`,
            logo_file_id: undefined,
          },
        ],
      };
    })
  );
  return json({ vendors, errors: [], intent: "upload" });
}

async function handleAssociateVendors(
  formData: FormData,
  managerAccountId: string,
  user: User
) {
  const { managerAccountVendorService } = await WebDIContainer();
  const vendors = Object.entries(Object.fromEntries(formData))
    .filter(([key]) => key !== "intent")
    .map(([vendorName, value]) => {
      return {
        new_vendor_name: vendorName,
        vendor_id: value as string,
      };
    });

  const insertedVendors =
    await managerAccountVendorService.createManagerAccountVendors(
      managerAccountId,
      vendors,
      user
    );

  const errors: string[] = [];

  return json({ vendors: insertedVendors, errors, intent: "add-vendors" });
}
