import type { ActionFunctionArgs } from "@remix-run/node";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { Permission } from "~/utils/intelligence-permission.utils";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  type ManagerAccountVendorDocument,
  ManagerAccountVendorDocumentType,
} from "@prisma/client";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { castFormFields } from "~/utils/type.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

type JsonData = {
  success?: boolean;
  fields?: Record<string, string | null> | null;
  errors?: Record<string, string[] | null>;
  vendorDocument?: ManagerAccountVendorDocument | null;
};

const MB = 1024 * 1024;
const FILE_BYTE_LIMIT = 50 * MB;

const UpdateVendorDocumentForm = z.object({
  id: z.string(),
  name: z.string().nullable(),
  type: z
    .enum([
      ManagerAccountVendorDocumentType.Other,
      ...Object.keys(ManagerAccountVendorDocumentType),
    ])
    .nullable(),
  file: z.string().nullable(),
});

const DeleteVendorDocumentForm = z.object({
  id: z.string().uuid(),
});

export async function action({ params, request }: ActionFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );
  const managerAccountVendorId = params.vendor_id as string;
  const { managerAccountVendorService } = await WebDIContainer();

  const accountVendor =
    await managerAccountVendorService.getManagerAccountVendor(
      managerAccountVendorId,
      {
        manager_account: true,
      }
    );

  if (!accountVendor) {
    throw new Response("Not found", { status: 404 });
  }

  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "file", byteLimit: FILE_BYTE_LIMIT },
  ]);

  if (form.get("intent") === "delete") {
    return deleteVendorDocument({ form });
  }

  return updateVendorDocument({ form, managerAccountVendorId });
}

async function deleteVendorDocument({ form }: { form: FormData }) {
  const { managerAccountVendorService } = await WebDIContainer();
  const fields = {
    id: form.get("id"),
  };

  const validation = DeleteVendorDocumentForm.safeParse(fields);

  if (validation.success) {
    const response = await managerAccountVendorService.deleteVendorDocument(
      validation.data.id
    );

    if (response.success) {
      return jsonWithSuccess<JsonData>(
        {
          success: true,
          fields: castFormFields(fields),
          errors: issuesByKey([]),
        },
        "Document deleted"
      );
    } else {
      return jsonWithError<JsonData>(
        {
          success: false,
          fields: null,
          errors: { server: [response.error] } as Record<string, string[]>,
        },
        "Error deleting document"
      );
    }
  }
}

async function updateVendorDocument({
  form,
  managerAccountVendorId,
}: {
  form: FormData;
  managerAccountVendorId: string;
}) {
  const { managerAccountVendorService } = await WebDIContainer();

  const fields = {
    id: form.get("id"),
    name: form.get("name"),
    type: form.get("type"),
    file: form.get("file"),
  };

  const validation = UpdateVendorDocumentForm.safeParse(fields);

  if (validation.success) {
    const vendorDocument =
      await managerAccountVendorService.handleVendorDocument({
        ...validation.data,
        managerAccountVendorId,
      });

    return jsonWithSuccess<JsonData>(
      {
        success: true,
        vendorDocument,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      },
      `Document ${
        validation.data.id?.includes("new_") ? "created" : "updated"
      }.`
    );
  }

  return jsonWithError<JsonData>(
    {
      success: false,
      vendorDocument: null,
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    "Error updating document."
  );
}
