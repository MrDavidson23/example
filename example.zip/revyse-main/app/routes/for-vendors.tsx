/* eslint-disable jsx-a11y/anchor-is-valid */
import { Link, useLoaderData, useNavigate } from "@remix-run/react";
import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { getUser } from "~/utils/session.server";
import { Footer } from "~/components/footer.component";
import { CTA, CTARedirect } from "~/components/cta.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { PlanChooser } from "~/components/plan-chooser.component";
import { useCallback, useRef } from "react";
import { ProductSectorBlock } from "~/components/discovery/product-sector-block.component";

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  return [
    { title: "Revyse | Multifamily vendor discovery platform" },
    {
      name: "description",
      content:
        "Revyse helps multifamily vendors get in front of ready-to-buy customers with better brand exposure and faster deal cycles.",
    },
  ];
};

export const loader = async ({ request }: LoaderFunctionArgs) => {
  const user = await getUser(request);
  const { productService, stripeService } = await WebDIContainer();

  const techProducts = await productService.getProductsByCategoryVendorType(
    "Technology",
    4
  );
  const serviceProducts = await productService.getProductsByCategoryVendorType(
    "Services",
    4
  );
  const supplierProducts = await productService.getProductsByCategoryVendorType(
    "Suppliers",
    4
  );
  const stripeProducts = await stripeService.getPlanChooserStripeProducts();

  return json({
    user,
    techProducts,
    serviceProducts,
    supplierProducts,
    stripeProducts,
  });
};

export default function ForVendorsRoute() {
  const {
    user,
    techProducts,
    serviceProducts,
    supplierProducts,
    stripeProducts,
  } = useLoaderData<typeof loader>();
  const navigate = useNavigate();

  const comparePlansSection = useRef<HTMLDivElement>(null);

  const handleLinkClick = useCallback(
    (ref: React.RefObject<HTMLElement>, position?: ScrollLogicalPosition) => {
      if (ref.current) {
        ref.current.scrollIntoView({
          behavior: "smooth",
          block: position ?? "start",
        });
      }
    },
    []
  );

  return (
    <div className="flex flex-col min-h-full">
      <header className="bg-white">
        <nav
          className="mx-auto flex gap-2 max-w-7xl items-center justify-between p-6 lg:px-8"
          aria-label="Global"
        >
          <div className="flex lg:flex-1">
            <Link to="/" className="-m-1.5 p-1.5">
              <span className="sr-only">Revyse</span>
              <img
                className="h-8 w-auto"
                src="/assets/revyse-logo-color-black.png"
                alt=""
                width="320"
                height="112"
              />
            </Link>
          </div>
          <div className="flex gap-2">
            <CTARedirect
              userLoggedIn={!!user}
              loginOrSignUp="login"
              to="/vendor"
              fillStyle="outline"
              className="hidden md:block text-sm"
            >
              Vendor Portal
            </CTARedirect>
            <CTA onClick={() => handleLinkClick(comparePlansSection)}>
              Get Started
            </CTA>
          </div>
        </nav>
      </header>
      <div className="flex-grow">
        <div
          className="bg-sky-500 flex justify-center md:py-6 py-3 bg-cover"
          style={{ backgroundImage: `url(/assets/for-vendors-hero.png)` }}
        >
          <div className="max-w-7xl flex-grow text-white px-8">
            <div className="my-5 md:my-20 md:w-1/2">
              <h1 className="text-5xl font-bold pr-20 md:pr-0">
                Sell the way your customers want to buy
              </h1>
              <p className="pt-6 text-lg">
                Get in front of ready-to-buy PMCs and supercharge your sales
                efficiency with better brand exposure and faster deal cycles.
              </p>
            </div>
          </div>
        </div>
        <div className="flex justify-center md:pt-16 py-8 bg-sky-50 bg-left bg-no-repeat bg-none relative">
          <div className="max-w-7xl flex-grow px-8">
            <img
              src="/assets/product-screenshot-2.png"
              className="w-full h-auto md:hidden"
              alt="screenshot"
              width="926"
              height="875"
            />
            <h3 className="font-bold my-4 text-center">
              Your next best customer is already researching the competition
            </h3>
            <div className="flex mt-16 flex-grow">
              <div className="md:w-2/3 w-0">
                <img
                  src="/assets/product-screenshot-2.png"
                  className="w-full h-auto hidden md:block"
                  alt="screenshot"
                  width="926"
                  height="875"
                />
              </div>
              <div className="md:w-1/3">
                <h4 className="mb-1 font-medium">Drive more inbound leads</h4>
                <p className="[text-wrap:pretty]">
                  Align your GTM strategy with the way in-market buyers shop,
                  and watch the inbounds roll in. Claim your listing and add
                  self-serve demos with zero dev time.
                </p>

                <h4 className="mt-8 mb-1 font-medium">
                  Build instant credibility
                </h4>
                <p className="[text-wrap:pretty]">
                  With 86% of software purchases influenced by reviews, win over
                  the next wave of buyers with a chorus of rave reviews from
                  your happiest customers.
                </p>

                <h4 className="mt-8 mb-1 font-medium">Sell more efficiently</h4>
                <p className="[text-wrap:pretty]">
                  Get from first-contact to closed-won faster with Revyse.
                  Increase rep productivity, decrease your CAC, and meet your
                  next best customer on Revyse.
                </p>

                <h4 className="mt-8 mb-1 font-medium">
                  Feature flex on the competition
                </h4>
                <p className="[text-wrap:pretty]">
                  Show in-market buyers how your product stacks up against its
                  rivals. Call out your best features, flaunt key integrations,
                  and claim your spot on buyers’ short lists.
                </p>
                <CTA
                  onClick={() => handleLinkClick(comparePlansSection)}
                  className="mt-8"
                >
                  Get Started
                </CTA>
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-center md:py-16 py-4 bg-white bg-left bg-no-repeat">
          <div className="max-w-6xl flex-grow p-8">
            <div className="flex flex-col items-center">
              <h3 className="font-bold mb-4 text-center md:w-96">
                What products or services can I list on Revyse?
              </h3>
              <p className="max-w-xl text-center text-lg mb-10">
                From leasing technology to resident amenities, Revyse helps the
                best multifamily products and services get found.
              </p>
              <div className="grid md:grid-cols-3 md:gap-6 gap-4 w-full">
                <ProductSectorBlock
                  title="Technology"
                  products={techProducts}
                />
                <ProductSectorBlock
                  title="Services"
                  products={serviceProducts}
                />
                <ProductSectorBlock
                  title="Suppliers"
                  products={supplierProducts}
                />
              </div>
              <CTA
                onClick={() => handleLinkClick(comparePlansSection)}
                className="mt-10"
              >
                Get Started
              </CTA>
              <Link to="/categories" className="mt-4 text-sm text-sky-600">
                See all categories
              </Link>
            </div>
          </div>
        </div>

        <div className="flex justify-center py-20 bg-sky-50">
          <div className="max-w-3xl flex-grow flex flex-col items-center gap-10 relative p-8">
            <div className="text-xl lg:text-2xl text-center">
              &quot;Revyse is overhauling the connective tissue between buyers
              and vendors in multifamily. The Revyse platform ensures that we
              are educating in-market buyers about the power of our product
              suite while also selling in the most efficient manner - lowering
              CaC, shortening sales cycles, and increasing sales
              productivity.&quot;
            </div>

            <img
              src="/assets/mike-wolber-headshot.jpeg"
              alt="profile pic"
              className="w-24 h-24 mr-4 rounded-full"
              width="400"
              height="400"
            />
            <div className="flex flex-col items-center gap-1">
              <strong>Mike Wolber</strong>
              <p className="text-gray-400 text-xs">
                Chief Sales Officer at Apartment List
              </p>
            </div>
            <img
              src="/assets/cloud-2.png"
              className="absolute -left-32 -bottom-12 h-24 w-auto hidden md:block"
              alt="cloud"
              height="70"
              width="169"
            />
            <img
              src="/assets/cloud-1.png"
              className="absolute -right-32 -top-32 h-24 w-auto hidden md:block"
              alt="cloud"
              height="206"
              width="414"
            />
          </div>
        </div>

        <div
          className="flex justify-center py-6 md:py-20 bg-white px-4"
          ref={comparePlansSection}
        >
          <PlanChooser
            title="Choose your plan to get started"
            stripeProducts={stripeProducts}
            onChoose={(plan, price) => {
              navigate(`/vendor/products/new?stripePriceId=${price.id}`);
            }}
          />
        </div>

        <div className="flex justify-center md:py-16 py-4 bg-sky-50">
          <div className="max-w-6xl flex-grow p-8">
            <div className="flex flex-col items-center">
              <h3 className="font-bold mb-4 text-center md:w-96">
                Ready to become a Revyse vendor?
              </h3>
              <p className="max-w-xl text-center text-lg mb-6">
                Claim your product listing for free or sign-up for a
                subscription plan to supercharge your sales efficiency and close
                more deals.
              </p>
              <CTA onClick={() => handleLinkClick(comparePlansSection)}>
                Become a Vendor
              </CTA>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
