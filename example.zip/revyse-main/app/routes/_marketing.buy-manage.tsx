import type { ActionFunctionArgs, MetaFunction } from "@remix-run/node";
import { redirect, json } from "@remix-run/node";
import { Form, useActionData } from "@remix-run/react";
import { jsonWithError } from "remix-toast";
import { z } from "zod";
import { CTA } from "~/components/cta.component";
import { ContentStripe } from "~/components/discovery/content-stripe.component";
import { CrudTextField } from "~/components/form/crud-form.component";
import { CrudTextAreaField } from "~/components/form/textarea.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import { castFormFields } from "~/utils/type.utils";
import { NonEmptyString } from "~/utils/validation.utils.server";

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  return [
    { title: "Revyse | Multifamily software procurement" },
    {
      name: "description",
      content:
        "Goodbye tech headaches, hello ROI. Revyse makes discovering, buying, and managing multifamily software easier for everyone.",
    },
  ];
};

export async function action({ request }: ActionFunctionArgs) {
  const { customerSupportService } = await WebDIContainer();

  const ConnectForm = z.object({
    first_name: NonEmptyString,
    last_name: NonEmptyString,
    email: NonEmptyString.email(),
    company: NonEmptyString,
    message: NonEmptyString,
    honeypot: z.string().max(0),
  });

  const form = await request.formData();

  const fields = {
    first_name: form.get("first_name"),
    last_name: form.get("last_name"),
    email: form.get("email"),
    company: form.get("company"),
    message: form.get("message"),
    honeypot: form.get("honeypot"), // Help us fight spam!
  };
  const validation = ConnectForm.safeParse(fields);

  if (validation.success) {
    await customerSupportService.sendCSEmail(
      "New Connect Request",
      JSON.stringify(validation.data)
    );
    throw redirect("/connect-success");
  }

  return jsonWithError(
    {
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
}
export async function loader() {
  return json({});
}

export default function BuyManageRoute() {
  const actionData = useActionData<typeof action>();
  return (
    <>
      <div className="bg-sky-500 flex justify-center md:py-12 py-12 px-6 bg-center bg-contain bg-no-repeat hero-stripe">
        <div className="max-w-3xl text-white text-center">
          <h1 className="font-bold">Vendor management made easier.</h1>
          <p className="my-6 text-lg text-white md:px-24">
            Centralize and streamline the growing roster of vendors required to
            operate today’s multifamily portfolio with Revyse Vendor
            Intelligence.
          </p>
        </div>
      </div>
      <ContentStripe
        color="white"
        heading="Map and manage your tech stack and spend"
        imageUrl="/assets/buy-manage-1.png"
        layout="left"
        imageWidth="2000"
        imageHeight="1471"
      >
        <p>
          With <strong>Revyse Vendor Intelligence</strong>, you get a unified
          view of all your third-party contracts. Collect and manage vendor
          details, including business, legal, and risk information. This single
          system helps you gain visibility into annual spend across the
          enterprise by resident lifecycle stage, department, region, and
          ownership group - even down to the location level. And, Revyse
          delivers insights into potential product redundancies and overlaps
          that you can use to optimize your tech stack and control costs.
        </p>
      </ContentStripe>
      <ContentStripe
        color="blue"
        heading="Turn contract renewals into opportunities to save"
        imageUrl="/assets/buy-manage-2.png"
        layout="right"
        imageWidth="2000"
        imageHeight="2000"
      >
        <p className="pb-10">
          Never miss a contract renewal date again. With{" "}
          <strong>Revyse Vendor Intelligence</strong>, all vendor-related tasks
          get scheduled and assigned so you’ll know exactly when you need to
          start preparing for re-negotiation, shopping for replacement
          solutions, or canceling a contract before auto-renewals lock you in.
          One click sends location disposition notices to all associated vendors
          making transitions a breeze. Contract renewals go from burdens to
          opportunities to save.
        </p>
      </ContentStripe>

      <ContentStripe
        color="white"
        heading="Make data-backed buying decisions"
        imageUrl="/assets/buy-manage-3.png"
        layout="left"
        imageWidth="2000"
        imageHeight="1500"
      >
        <p className="pb-10">
          Replace products that don't integrate with your business-critical
          systems or satisfy your budget requirements. Powered by the Revyse
          Discovery Marketplace - the largest unbiased database of multifamily
          proptech vendors and ratings -{" "}
          <strong>Revyse Vendor Intelligence</strong> surfaces recommendations
          to help you shop confidently. Discover top-rated vendors and trending
          alternatives across more than 75 categories of software, hardware,
          agencies, professional services, materials and onsite services.
        </p>
      </ContentStripe>

      <div className={`flex justify-center md:py-12 py-8 bg-sky-50`}>
        <div className="max-w-2xl flex-grow md:px-8 px-4 flex flex-col items-center relative">
          <h2 className="text-3xl font-bold mb-8 text-center">
            Lean on us to help whip your tech stack into shape
          </h2>
          <p className="text-center">
            Our quick start onboarding team makes implementation easy and our
            contract concierge keeps things running smoothly post go-live. Along
            the way you can call upon the expertise of{" "}
            <strong>Revyse Stack Advisors</strong> to rightsize agreements,
            eliminate shadow spend, and optimize your existing tech stack to
            control costs.{" "}
          </p>
          <img
            src="/assets/cloud-2.png"
            className="absolute -right-48 -bottom-20 h-24 w-auto hidden md:block"
            alt="cloud"
            height="70"
            width="169"
          />
          <img
            src="/assets/cloud-1.png"
            className="absolute -left-48 -top-32 h-24 w-auto hidden md:block"
            alt="cloud"
            height="206"
            width="414"
          />
        </div>
      </div>

      <div className={`flex justify-center md:py-16 py-8 bg-white`}>
        <div className="max-w-2xl flex-grow md:px-8 px-4 flex flex-col items-center relative">
          <h2 className="text-3xl font-bold mb-8 text-center">
            Learn more about Revyse Vendor Intelligence
          </h2>
          <Form method="post" className="w-full">
            <div className="grid grid-cols-2 gap-4 w-full">
              <div>
                <CrudTextField
                  field={{
                    name: "first_name",
                    label: "First Name *",
                    type: "text",
                    errors: actionData
                      ? actionData.errors?.first_name ?? []
                      : [],
                    defaultValue: actionData?.fields?.first_name ?? "",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    name: "last_name",
                    label: "Last Name *",
                    type: "text",
                    errors: actionData
                      ? actionData.errors?.last_name ?? []
                      : [],
                    defaultValue: actionData?.fields?.last_name ?? "",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    name: "email",
                    label: "Email *",
                    type: "text",
                    errors: actionData ? actionData.errors?.email ?? [] : [],
                    defaultValue: actionData?.fields?.email ?? "",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    name: "company",
                    label: "Company *",
                    type: "text",
                    errors: actionData ? actionData.errors?.company ?? [] : [],
                    defaultValue: actionData?.fields?.company ?? "",
                  }}
                />
              </div>
              <div className="col-span-2">
                <CrudTextAreaField
                  field={{
                    name: "message",
                    label: "Message *",
                    type: "textarea",
                    errors: actionData ? actionData.errors?.message ?? [] : [],
                    defaultValue: actionData?.fields?.message ?? "",
                    rows: 4,
                  }}
                />
              </div>
              <div
                style={{ position: "absolute", left: "-5000px" }}
                aria-hidden="true"
              >
                <input
                  type="text"
                  name="honeypot"
                  tabIndex={-1}
                  defaultValue=""
                />
              </div>
              <CTA className="col-span-2" fillStyle="outline" type="submit">
                Submit
              </CTA>
            </div>
          </Form>
        </div>
      </div>
    </>
  );
}
