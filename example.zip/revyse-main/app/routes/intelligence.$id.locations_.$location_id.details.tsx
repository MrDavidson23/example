import { CTA } from "~/components/cta.component";
import { useActionData, useLoaderData } from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { isEmpty } from "lodash";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { Modal } from "~/components/modal.component";
import {
  LocationClass,
  LocationCountry,
  LocationPropertyStage,
  LocationPropertyType,
  LocationStatus,
  Prisma,
} from "@prisma/client";
import { TrashIcon } from "@heroicons/react/24/outline";
import { useEffect, useState } from "react";
import { LocationForm } from "~/components/intelligence/locations-form.component";
import { Permission } from "~/utils/intelligence-permission.utils";
import {
  jsonWithError,
  jsonWithSuccess,
  redirectWithError,
  redirectWithSuccess,
} from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { ConfirmDeleteModal } from "~/components/modals/confirm-delete-modal.component";
import StatusChip from "~/components/status-chip.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { LocationNoticeDispositionBanner } from "~/components/intelligence/location-notices/location-notice-disposition-banner";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { CanDo } from "~/components/intelligence/can-do.component";

const LocationDataForm = z.object({
  name: z.string().min(1, "Name is required"),
  unit_count: z.number().int().min(1, "Unit count is required"),
  class: z.nativeEnum(LocationClass),
  property_stage: z.nativeEnum(LocationPropertyStage).optional().nullable(),
  property_type: z.nativeEnum(LocationPropertyType),
  owner_name: z.string(),
  pms_id: z.string(),
  street_1: z.string().min(1, "Street 1 is required"),
  street_2: z.string(),
  city: z.string().min(1, "City is required"),
  state: z.string().min(1, "State is required"),
  country: z
    .nativeEnum(LocationCountry)
    .or(z.literal("null"))
    .transform(v => (v === "null" ? null : v)),
  zip: z.string().min(1, "Zip code name is required"),
  region: z
    .string()
    .min(1, "Region is required")
    .or(z.literal(""))
    .transform(r => (!isEmpty(r) ? r : null)),
  status: z.nativeEnum(LocationStatus),
  manager_account_id: z
    .string()
    .uuid()
    .min(1, "Manager account id is required"),
});

export const updateAction = async ({
  id,
  form,
  managerAccountId,
}: {
  id: string;
  form: FormData;
  managerAccountId: string;
}) => {
  const unitCount = form.get("unit_count") as string;
  const fields = {
    name: form.get("name"),
    unit_count: parseInt(unitCount),
    class: form.get("class"),
    property_stage: form.get("property_stage"),
    property_type: form.get("property_type"),
    owner_name: form.get("owner_name"),
    pms_id: form.get("pms_id"),
    street_1: form.get("street_1"),
    street_2: form.get("street_2"),
    city: form.get("city"),
    state: form.get("state"),
    country: form.get("country"),
    zip: form.get("zip"),
    region: form.get("region"),
    status: form.get("status"),
    manager_account_id: managerAccountId,
  };

  const validation = LocationDataForm.safeParse(fields);

  if (validation.success) {
    const { locationService } = await WebDIContainer();
    try {
      await locationService.updateLocation(id, validation.data);
    } catch (e) {
      if (
        e instanceof Prisma.PrismaClientKnownRequestError &&
        e.code === "P2025"
      ) {
        redirectWithError(
          `/intelligence/${managerAccountId}/locations/`,
          "Location not found",
          { status: 404 }
        );
      }
    }
    return jsonWithSuccess(
      {
        success: true,
        fields,
        errors: issuesByKey([]),
      },
      "Location updated successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return jsonWithError(
    { success: false, fields, errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
};

async function deleteAction({
  id,
  account_id,
}: {
  id: string;
  account_id: string;
}) {
  const { locationService } = await WebDIContainer();
  try {
    await locationService.deleteLocation(id);
  } catch (e) {
    if (
      e instanceof Prisma.PrismaClientKnownRequestError &&
      e.code === "P2025"
    ) {
      redirectWithError(
        `/intelligence/${account_id}/locations/`,
        "Location not found",
        { status: 404 }
      );
    }
  }

  return redirectWithSuccess(
    `/intelligence/${account_id}/locations`,
    "Location deleted successfully"
  );
}

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const location_id = params.location_id!;

  const form = await request.formData();
  const intent = form.get("intent");
  if (location_id && intent === "delete") {
    const { account } = await verifyIntelligenceRequest(
      { request, params },
      {
        permissions: [Permission.DeleteLocations],
        locationId: params.location_id,
      }
    );
    const managerAccountId = account.id;
    // Handle delete locations
    return deleteAction({ id: location_id, account_id: managerAccountId });
  } else {
    const { account } = await verifyIntelligenceRequest(
      { request, params },
      {
        permissions: [Permission.ManageLocations],
        locationId: params.location_id,
      }
    );
    const managerAccountId = account.id;
    // Handle Update location
    return updateAction({ id: location_id, form, managerAccountId });
  }
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewLocationDetails],
      locationId: params.location_id,
    }
  );

  const { locationService, locationNoticeService } = await WebDIContainer();

  const location = await locationService.getLocation(params.location_id!);
  if (!location) {
    throw new Response("Not found", { status: 404 });
  }

  const regions = await locationService.getLocationsRegions(account.id);

  const owners = await locationService.getLocationsOwners(account.id);
  const sentLocationNoticeDisposition =
    await locationNoticeService.getLastLocationDispositionNotice(location.id);

  return json({
    user,
    account,
    location,
    regions,
    owners,
    sentLocationNoticeDisposition,
  });
}

export default function Location() {
  const actionData = useActionData<typeof action>();
  const { account, location, regions, owners, sentLocationNoticeDisposition } =
    useLoaderData<typeof loader>();

  const [editLocation, setEditLocation] = useState(false);
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  useEffect(() => {
    if (actionData?.success) {
      setEditLocation(false);
      setConfirmDeleteOpen(false);
    }
  }, [actionData]);

  return (
    <>
      <CanDo permission={Permission.ManageLocations} locationId={location.id}>
        <Modal
          isOpen={editLocation}
          onClose={() => setEditLocation(false)}
          size="medium"
          manager={true}
        >
          <LocationForm
            actionData={actionData}
            location={location}
            account_id={account.id}
            regionOptions={regions}
            ownerOptions={owners.map(owner => owner.owner_name)}
          ></LocationForm>
        </Modal>
      </CanDo>
      {confirmDeleteOpen && (
        <CanDo permission={Permission.DeleteLocations} locationId={location.id}>
          <ConfirmDeleteModal
            isOpen={confirmDeleteOpen}
            onClose={() => setConfirmDeleteOpen(false)}
            title="Delete this location and its corresponding data"
            message="Are you sure you want to delete this location and all associated contract and line item assignments? This data is not recoverable."
            intent="delete"
            submitOnConfirm={true}
          />
        </CanDo>
      )}
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
            active: true,
          },
        ]}
        title={
          <>
            Location details: <br /> {location.name}
          </>
        }
        buttonsSlot={
          <>
            <CanDo
              permission={Permission.DeleteLocations}
              locationId={location.id}
            >
              <button
                onClick={() => {
                  setConfirmDeleteOpen(!confirmDeleteOpen);
                }}
                className="text-sky-500"
              >
                <div className="flex">
                  <TrashIcon className="h-5 mr-1" />
                  Delete
                </div>
              </button>
            </CanDo>
            <CanDo
              permission={Permission.ManageLocations}
              locationId={location.id}
            >
              <CTA
                type="submit"
                variant="coral-shadow"
                onClick={() => setEditLocation(true)}
              >
                Edit Location
              </CTA>
            </CanDo>
          </>
        }
      />
      {sentLocationNoticeDisposition && (
        <LocationNoticeDispositionBanner
          locationNoticeDisposition={sentLocationNoticeDisposition}
          resendNoticeLink={`/intelligence/${account.id}/locations/${location.id}/notices/${sentLocationNoticeDisposition.id}/location-disposition`}
        />
      )}
      <div className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min divide divide-y divide-2 divide-gray-200">
        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Location Status</div>
          <StatusChip
            model="LocationStatus"
            status={location.status}
            label={location.status}
          />
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Property Management System ID</div>
          <div>{location.pms_id}</div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Location Name</div>
          <div>{location.name}</div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Street 1</div>
          <div>{location.street_1}</div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Street 2</div>
          <div>{location.street_2}</div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">City</div>
          <div>{location.city}</div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">State</div>
          <div>{location.state}</div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Country</div>
          <div>{location.country}</div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Zip</div>
          <div>{location.zip}</div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Region</div>
          <div>{location.region ?? "--"}</div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Unit Count</div>
          <div>{location.unit_count}</div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Property Class</div>
          <div>{location.class}</div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Property Type</div>
          <div>
            {(() => {
              switch (location.property_type) {
                case LocationPropertyType.ConventionalMultifamily:
                  return "Conventional Multifamily";
                case LocationPropertyType.SelfStorage:
                  return "Self Storage";
                case LocationPropertyType.OfficeCommercial:
                  return "Office/Commercial";
                case LocationPropertyType.BuildToRent:
                  return "Build-to-Rent";
                case LocationPropertyType.SingleFamily:
                  return "Single Family";
                default:
                  return location.property_type;
              }
            })()}
          </div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Property Stage</div>
          <div>
            {location.property_stage === LocationPropertyStage.LeaseUp
              ? "Lease-Up"
              : location.property_stage}
          </div>
        </div>

        <div className="grid grid-cols-2 py-4">
          <div className="font-bold">Owner Name</div>
          <div>{location.owner_name}</div>
        </div>
      </div>
    </>
  );
}
