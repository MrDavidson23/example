import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { orderBy } from "lodash";
import { useEffect, useState } from "react";
import { DiscoveryHeader } from "~/components/discovery/discovery-header.component";
import { FAQ } from "~/components/discovery/faq.component";
import { CrudCheckboxField } from "~/components/form/crud-form.component";
import { ProductCard } from "~/components/product-card.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";

export async function loader({ params }: LoaderFunctionArgs) {
  const { db, productCategoryService } = await WebDIContainer();

  const category = await productCategoryService.getCategory({
    slug: params.slug,
  });

  const categoryProducts = await productCategoryService.getCategoryProducts(
    category.id
  );
  // Unclaimed and free listings only show up in the primary category selected
  const products = categoryProducts.filter(product => {
    const {
      primary_category_id,
      secondary_category_id,
      tertiary_category_id,
      tier,
      vendor,
    } = product;

    const isMatchingCategory =
      primary_category_id === category.id ||
      secondary_category_id === category.id ||
      tertiary_category_id === category.id;

    const isTierValid =
      (tier !== "free" && tier !== null && tier !== undefined) ||
      vendor?.slug === "zipcode-creative";

    return (
      (isMatchingCategory && isTierValid) ||
      (primary_category_id === category.id &&
        (tier === "free" || tier === null || tier === undefined))
    );
  });

  const industries = await db.industry.findMany();

  return json({
    category,
    industries,
    products,
  });
}

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  const category = data!.category;
  return [
    { title: category.page_title },
    {
      name: "description",
      content: category.meta_description,
    },
  ];
};

export default function CategorySlugRoute() {
  const { category, industries, products } = useLoaderData<typeof loader>();
  const [productList, setProductList] = useState(products);
  const [sort, setSort] = useState<"reviews" | "ratings" | "name">("reviews");
  const [filterIndustries, setFilterIndustries] = useState<string[]>([]);
  const featuredContentFilter = [
    { value: "pricing", name: "Has Pricing" },
    { value: "videos", name: "Has Videos" },
    { value: "demos", name: "Has Product Demos" },
  ];
  const [filterFeaturedContent, setFilterFeaturedContent] = useState<string[]>(
    []
  );

  useEffect(() => {
    let items = [...products];
    if (filterIndustries.length > 0) {
      items = products.filter(product => {
        return filterIndustries.some(industry =>
          product.industries.find(i => i.id === industry)
        );
      });
    }

    // Sort by tier and claimed listing whenver most reviews or high ratings sort is selected
    if (sort === "name") {
      items = orderBy(items, "title");
    } else {
      items = orderBy(
        items,
        [
          sort === "reviews" ? "totalReviews" : "avgReview",
          "name",
          product => {
            switch (product.tier) {
              case "tier_3":
                return 1;
              case "tier_2":
                return 2;
              case "tier_1":
                return 3;
              case "free":
                return 4;
              default:
                return 5;
            }
          },
        ],
        ["desc", "asc", "asc"]
      );
    }

    // If "Featured Content filters" are selected then filter supporting multiple filtering
    if (filterFeaturedContent.length > 0) {
      items = items.filter(product => {
        // Iterate through each selected filter and evaluate the condition
        return filterFeaturedContent.every(feature => {
          // Return true if the product satisfies the specific feature conditions
          return (
            (feature === "pricing" && product._count.packages > 0) ||
            (feature === "videos" && product._count.brand_video_files > 0) ||
            (feature === "demos" &&
              ((product.demo_storylane_url !== null &&
                product.demo_storylane_url.length > 0) ||
                product._count.demo_files > 0))
          );
        });
      });
    }
    setProductList(items);
  }, [sort, filterIndustries, filterFeaturedContent, products]);

  return (
    <>
      <DiscoveryHeader
        title={category.name}
        description={category.description}
        crumbs={[
          { label: "HOME", link: "/", active: false },
          { label: "CATEGORIES", link: "/categories", active: false },
          {
            label: category.name,
            link: `/categories/${category.slug}`,
            active: true,
          },
        ]}
      />

      <div className="flex justify-center bg-white">
        <div className="max-w-7xl flex-grow md:px-8">
          <div className="flex my-12 gap-12">
            <div className="w-64 pr-4 flex-col hidden md:flex">
              <strong>All Results ({products.length})</strong>
              <strong className="mt-8 mb-2">Sort By</strong>

              <select
                id="sort-by-select"
                className="rounded-3xl border-sky-600 text-sky-600"
                onChange={evt => {
                  setSort(evt.target.value as any);
                }}
              >
                <option value="reviews">Most Reviews</option>
                <option value="ratings">Highest Ratings</option>
                <option value="name">Name</option>
              </select>

              <strong className="mt-12">Filter By</strong>
              <div className="my-4">Featured Content</div>
              <div>
                {featuredContentFilter.map(option => (
                  <CrudCheckboxField
                    key={option.value}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: filterFeaturedContent.includes(
                        option.value
                      ),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterFeaturedContent([
                          ...filterFeaturedContent,
                          option.value,
                        ]);
                      } else {
                        setFilterFeaturedContent(
                          filterFeaturedContent.filter(i => i !== option.value)
                        );
                      }
                    }}
                  />
                ))}
              </div>
              <div className="my-4">Industries Served</div>
              <div>
                {industries.map(industry => (
                  <CrudCheckboxField
                    key={industry.id}
                    field={{
                      name: "filter_by",
                      value: industry.id,
                      label: industry.name,
                      errors: [],
                      description: "",
                      defaultChecked: filterIndustries.includes(industry.id),
                      type: "checkbox",
                    }}
                    onChange={(evt: any) => {
                      if (evt.target.checked) {
                        setFilterIndustries([...filterIndustries, industry.id]);
                      } else {
                        setFilterIndustries(
                          filterIndustries.filter(i => i !== industry.id)
                        );
                      }
                    }}
                  />
                ))}
              </div>
            </div>
            <div className="px-2 lg:px-0 flex-grow flex flex-col gap-8">
              {productList.map(product => {
                const p = {
                  ...product,
                  vendor_name: product.vendor!.name,
                  vendor_slug: product.vendor!.slug,
                  avg_score: product.avgReview,
                  cnt: product.totalReviews,
                };
                return <ProductCard key={product.id} product={p} />;
              })}
              {productList.length === 0 && (
                <div className="text-center text-gray-500 py-20 border border-gray-200 border-dashed rounded-3xl">
                  No Products Found. Try changing your filters.
                </div>
              )}

              {/* TODO: uncomment when we implement pagination
              <div className="flex justify-between text-xs ">
                <div>Showing 1 to 15 of 36 results | View all Results</div>
                <div className="flex items-center gap-8">
                  <div className="flex items-center">
                    <ChevronLeftIcon className="h-5" /> Previous
                  </div>
                  <div className="flex items-center">
                    Next <ChevronRightIcon className="h-5" />
                  </div>
                </div>
              </div> */}
            </div>
          </div>

          <div className="border-t border-gray-200 py-20 px-4 md:px-0">
            <h2 className="text-4xl font-medium pb-6 border-b border-gray-200">
              Frequently asked questions
            </h2>
            <FAQ
              question={category.faq_1}
              answer={category.faq_1_answer}
              defaultOpen={true}
            />
            <FAQ
              question={category.faq_2}
              answer={category.faq_2_answer}
              defaultOpen={true}
            />
            <FAQ
              question={category.faq_3}
              answer={category.faq_3_answer}
              defaultOpen={true}
            />
          </div>
        </div>
      </div>
    </>
  );
}
