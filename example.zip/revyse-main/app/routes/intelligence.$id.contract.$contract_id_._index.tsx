import { useLoaderData } from "@remix-run/react";
import type {
  ActionFunctionArgs,
  LinksFunction,
  LoaderFunctionArgs,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { isEmpty } from "lodash";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import type { Contract, Vendor } from "@prisma/client";
import {
  ContractLineItemLocationStatus,
  ContractLineItemStatus,
  ContractStatus,
  LocationStatus,
  ManagerAccountRoleType,
} from "@prisma/client";
import { ContractForm } from "~/components/intelligence/contract-form.component";
import { Boolean as Bool } from "~/utils/validation.utils.server";
import { Breadcrumbs } from "~/components/breadcrumbs.component";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import { calculateRenewalReminderDate } from "~/utils/contracts.utils";
import { Permission } from "~/utils/intelligence-permission.utils";
import { castFormFields } from "~/utils/type.utils";
import { jsonWithError, redirectWithSuccess } from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import stylesheetQuill from "react-quill/dist/quill.snow.css";
import { FeatureFlag } from "~/services/feature-flag.service.server";
import type { CrudFormFieldSelect } from "~/components/form/crud-form.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

type JsonData = {
  fields?: Record<string, string | null | number>;
  success?: boolean;
  errors?: Record<string, string[] | null> | null;
  vendor?: Vendor | null;
  vendors?: Vendor[] | null;
  contract?: Contract | null;
};

export const links: LinksFunction = () => [
  { rel: "stylesheet", href: stylesheetQuill },
];

const DocumentFileSchema = z.object({
  id: z.string(),
  name: z.string(),
  file: z.string(),
});

const ContractDetailsSchema = z.object({
  name: z.string().min(1, "Contract name is required"),
  term_length_months: z.number().int().nullable(),
  auto_renew_term_length: z.number().int().nullable(),
  renewal_reminder_lead_time_months: z.number().int().nullable(),
  renewal_reminder_date: z.date().nullable(),
  status: z.nativeEnum(ContractStatus),
  canceled_at: z.date().optional().nullable(),
  expires_at: z.date().nullable(),
  current_term_end_date: z.date().nullable(),
  effective_date: z.date().nullable(),
  termination_notice_period: z.number().int().nullable(),
  termination_notice_details: z.string().optional(),
  task_owner_id: z
    .string()
    .uuid()
    .or(z.literal("null").transform(v => (v === "null" ? null : v))),
  contract_owner_name: z
    .string()
    .transform(v => (v === "" ? null : v))
    .optional(),
  approver: z
    .string()
    .transform(v => (v === "" ? null : v))
    .optional(),
  is_msa: Bool,
  is_month_to_month: Bool,
  will_auto_renew: Bool,
  renewal_reminder_emails: z
    .array(z.string().transform(v => (v === "--" ? "" : v)))
    .optional(),
  document_files: z.array(DocumentFileSchema),
  notes: z.string().optional(),
  location_id: z
    .string()
    .uuid()
    .or(z.literal("null"))
    .transform(v => (v === "null" ? null : v))
    .optional(),
  is_sensitive: Bool?.optional(),
});

const AddContractDetailsForm = z
  .discriminatedUnion("new_vendor", [
    ContractDetailsSchema.merge(
      z.object({
        new_vendor: z.literal("true"),
        vendor_name: z.string().min(1, "Vendor name is required"),
        description: z.string().min(1, "Vendor description is required"),
        vendor_id: z.string().nullable(),
      })
    ),
    ContractDetailsSchema.merge(
      z.object({
        new_vendor: z.literal("false"),
        vendor_id: z.string({
          required_error: "Select a vendor or create a new one",
          invalid_type_error: "Select a vendor or create a new one",
        }),
        vendor_name: z.string(),
        description: z.string(),
      })
    ),
  ])
  .superRefine((data, ctx) => {
    if (data.renewal_reminder_lead_time_months && !data.task_owner_id) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Responsible user is required",
        path: ["task_owner_id"],
      });
    }
    if (data.renewal_reminder_date && !data.task_owner_id) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Responsible user is required",
        path: ["task_owner_id"],
      });
    }
  });

const MB = 1024 * 1024;
const CONTRACT_BYTE_LIMIT = 50 * MB;

async function upsertContract({
  form,
  user,
  managerAccountId,
  id,
}: {
  form: FormData;
  user: { id: string; email: string };
  managerAccountId: string;
  id: string;
}) {
  const { contractService, contractLineItemLocationService, locationService } =
    await WebDIContainer();

  const termLength = form.get("term_length_months") as string;
  const autoRenewLength = form.get("auto_renew_term_length") as string;
  const renewalLength = form.get("renewal_reminder_lead_time_months") as string;
  const terminationNoticePeriod = form.get(
    "termination_notice_period"
  ) as string;
  const formCurrentTermEndDate = form.get("current_term_end_date") as string;
  const expiresAt = form.get("expires_at") as string;
  const canceledAt = form.get("canceled_at") as string;
  const effectiveDate = form.get("effective_date") as string;
  const willAutoRenew = form.get("will_auto_renew") as string;
  const renewalReminderDate = form.get("renewal_reminder_date") as string;
  const isMonthToMonth = form.get("is_month_to_month");
  const renewalReminderEmails = form.getAll(
    "renewal_reminder_emails.email"
  ) as string[];

  const fileIds = form.getAll("document_files.id") as string[];
  const fileNames = form.getAll("document_files.name") as string[];
  const files = form.getAll("document_files.file") as string[];

  const document_files = fileIds.map((file, j) => {
    return {
      id: file,
      name: fileNames[j],
      file: files[j],
    };
  });
  const fields = {
    name: form.get("name"),
    term_length_months: termLength ? parseInt(termLength) : null,
    auto_renew_term_length: autoRenewLength ? parseInt(autoRenewLength) : null,
    status: form.get("status"),
    canceled_at: canceledAt ? new Date(canceledAt) : null,
    expires_at: expiresAt ? new Date(expiresAt) : null,
    current_term_end_date: formCurrentTermEndDate
      ? new Date(formCurrentTermEndDate)
      : null,
    effective_date: effectiveDate ? new Date(effectiveDate) : null,
    termination_notice_period: terminationNoticePeriod
      ? parseInt(terminationNoticePeriod)
      : null,
    termination_notice_details: form.get("termination_notice_details"),
    task_owner_id: form.get("task_owner_id"),
    contract_owner_name: form.get("contract_owner_name") ?? undefined,
    approver: form.get("approver") ?? undefined,
    department: form.get("department"),
    is_msa: form.get("is_msa"),
    will_auto_renew: willAutoRenew,
    is_month_to_month: isMonthToMonth,
    notes: form.get("notes"),
    renewal_reminder_lead_time_months: renewalLength
      ? parseInt(renewalLength)
      : null,
    renewal_reminder_date:
      renewalReminderDate && Boolean(isMonthToMonth)
        ? new Date(renewalReminderDate ?? expiresAt)
        : calculateRenewalReminderDate(
            parseInt(renewalLength) || null,
            new Date(formCurrentTermEndDate)
          ),
    renewal_reminder_emails: !isEmpty(renewalReminderEmails)
      ? renewalReminderEmails
      : [],
    document_files,
    vendor_id: form.get("vendor_id"),
    vendor_name: form.get("vendor_name") ?? "",
    description: form.get("description") ?? "",
    new_vendor: form.get("new_vendor") ?? "false",
    location_id: form.get("location_id") ?? undefined,
    is_sensitive: form.get("is_sensitive") ?? undefined,
  };

  const validation = AddContractDetailsForm.safeParse(fields);

  if (validation.success) {
    // When the user sets the contract location
    // show error message if there are line items that are not associated with the location selected
    if (id !== "new" && validation.data.location_id) {
      const location = await locationService.getLocation(
        validation.data.location_id
      );

      if (location) {
        const lineItemsLocations =
          await contractLineItemLocationService.getLocationContractLineItems(
            undefined,
            {
              location_id: {
                not: validation.data.location_id,
              },
              contract_line_item: {
                contract_id: id,
                status: ContractLineItemStatus.Active,
              },
              status: { in: [ContractLineItemLocationStatus.Active, ContractLineItemLocationStatus.Pending] },
            }
          );
        if (lineItemsLocations.length > 0) {
          const errorMessage = `The contract cannot be set as a single location, because multiple locations are assigned to active line items in this contract.`;
          return jsonWithError<JsonData>(
            {
              success: false,
              contract: null,
              fields: castFormFields(fields),
              errors: issuesByKey([
                {
                  path: ["location_id"],
                  message: errorMessage,
                },
              ]),
            },
            DEFAULT_FORM_ERROR_MESSAGE
          );
        }
      }
    }

    const contract = await contractService.upsertContract(
      id,
      user,
      validation.data,
      managerAccountId
    );
    return redirectWithSuccess(
      `/intelligence/${managerAccountId}/contract/${contract.id}/details/`,
      "Contract saved successfully"
    );
  }
  return jsonWithError<JsonData>(
    {
      success: false,
      contract: null,
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE
  );
}
export async function action({ params, request }: ActionFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContracts],
    }
  );
  const managerAccountId = account.id;

  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "document_files.file", byteLimit: CONTRACT_BYTE_LIMIT },
  ]);
  const contract_id = params.contract_id || "new";

  return upsertContract({ form, user, managerAccountId, id: contract_id });
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContracts],
    }
  );

  const {
    managerAccountRoleService,
    featureFlagService,
    locationService,
    contractService,
    vendorService,
    managerAccountVendorService,
  } = await WebDIContainer();
  const managerAccountId = account.id;

  const contract_id = params.contract_id!;
  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const status = search.get("status");

  const vendorOptions = await managerAccountVendorService.getVendorOptions(
    account.id
  );

  const accountRoles = await managerAccountRoleService.getManagerAccountRoles(
    managerAccountId,
    {
      status: [],
      perPage: 100,
      page: 1,
      permissionLevel: [
        ManagerAccountRoleType.Owner,
        ManagerAccountRoleType.Editor,
      ],
    }
  );
  const accountUsers = accountRoles.map(user => ({
    id: user.id,
    first_name: user.user.first_name,
    last_name: user.user.last_name,
    email: user.user.email,
  }));

  const contract =
    contract_id === "new"
      ? ({
          id: "new",
          name: "",
          created_at: new Date(),
          updated_at: new Date(),
          term_length_months: null,
          expires_at: new Date(),
          canceled_at: new Date(),
          contract_owner_name: null,
          is_msa: false,
          renewal_reminder_lead_time_months: null,
          renewal_reminder_emails: [],
          will_auto_renew: false,
          is_corporate_only: false,
          status: ContractStatus.Active,
          manager_account_vendor_id: "",
          notes: null,
          approver: null,
          auto_renew_term_length: null,
          current_term_end_date: null,
          effective_date: null,
          termination_notice_period: null,
          termination_notice_details: null,
          task_owner_id: null,
          is_month_to_month: false,
          renewal_reminder_date: new Date(),
          document_files: [],
          contract_ai_extracts: [],
          manager_account_vendor: {
            vendor: {} as Vendor,
            manager_account_id: managerAccountId,
          },
          location_id: null,
          is_sensitive: false,
        } as Awaited<
          ReturnType<typeof contractService.getContractWithAiExtracts>
        >)
      : await contractService.getContractWithAiExtracts(contract_id);
  let vendor = null;
  const managerAccountVendor =
    contract_id !== "new"
      ? await managerAccountVendorService.getManagerAccountVendorWithFilters(
          {
            contracts: {
              some: {
                id: contract_id,
              },
            },
          },
          {
            vendor: {
              select: {
                id: true,
                name: true,
                description: true,
                logo_file_id: true,
              },
            },
          }
        )
      : null;
  vendor = managerAccountVendor?.vendor;
  if (search.has("vendor_id")) {
    vendor = await vendorService.getVendor(search.get("vendor_id") ?? "");
  }

  const locations = await locationService.getLocations(user, account, {
    status: [LocationStatus.Active, LocationStatus.Pending],
  });

  const locationOptions: CrudFormFieldSelect["options"] = locations.map(
    location => ({
      value: location.id,
      label: location.name,
    })
  );

  return json({
    account,
    status,
    contract,
    vendor,
    id: contract_id,
    vendorOptions,
    accountUsers,
    ffClippy: featureFlagService.isEnabled(FeatureFlag.Clippy),
    locationOptions,
    ffShowContractingParty: featureFlagService.isEnabled(
      FeatureFlag.IntelligenceShowContractingParty
    ),
  });
}

export default function CreateUpdateContractRoute() {
  const {
    id,
    contract,
    vendor,
    vendorOptions,
    accountUsers,
    account,
    ffClippy,
    ffShowContractingParty,
    locationOptions,
  } = useLoaderData<typeof loader>();
  return (
    <div className="space-y-8 pb-12">
      <Breadcrumbs
        className="grow"
        crumbs={[
          {
            name: "All contracts",
            to: `/intelligence/${account.id}/contracts`,
            active: false,
          },
          {
            name: contract.id !== "new" ? contract.name : "New contract",
            to: `/intelligence/${account.id}/contract/${
              contract.id !== "new" ? `${contract.id}/details` : "new"
            }`,
            active: false,
          },
        ].concat(
          contract.id !== "new"
            ? [
                {
                  name: "Edit contract",
                  to: `/intelligence/${account.id}/contract/${contract.id}/`,
                  active: true,
                },
              ]
            : []
        )}
      />
      <ContractForm
        contract={contract}
        vendor={vendor}
        actionUrl={`/intelligence/${account.id}/contract/${id}`}
        vendorOptions={vendorOptions}
        accountUsers={accountUsers}
        last_ai_extract={contract?.contract_ai_extracts[0]}
        show_ai_assistant={ffClippy}
        locationOptions={locationOptions}
        show_contracting_party={ffShowContractingParty}
      ></ContractForm>
    </div>
  );
}
