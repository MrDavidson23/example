import type { Prisma } from "@prisma/client";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { useMemo } from "react";
import { CrudListPage } from "~/components/crud-list-page.component";
import type { TableStateConfig } from "~/components/crud-table.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { getTableState } from "~/utils/table-state.server";

const PAGE_SIZE = 20;

export async function loader({ request }: LoaderFunctionArgs) {
  const { reviewService } = await WebDIContainer();

  const { pagination, orderBy, search } = getTableState({
    request,
    defaults: {
      pageSize: PAGE_SIZE,
      orderBy: "created_at:desc",
    },
  });

  const where: Prisma.ProductReviewWhereInput = {
    OR: search
      ? [
          { product: { title: { contains: search, mode: "insensitive" } } },
          {
            product: {
              vendor: { name: { contains: search, mode: "insensitive" } },
            },
          },
          { user: { first_name: { contains: search, mode: "insensitive" } } },
          { user: { last_name: { contains: search, mode: "insensitive" } } },
        ]
      : undefined,
  };

  const reviews = await reviewService.getReviews({
    where,
    orderBy,
    take: pagination.take,
    skip: pagination.skip,
    include: {
      product: true,
      user: true,
      approved_by: true,
      responded_by: true,
    },
  });

  const total = await reviewService.getReviewsCount({ where });

  return json({
    reviews,
    total,
  });
}

export default function AdminUsersRoute() {
  const { reviews, total } = useLoaderData<typeof loader>();

  const tableStateConfig: TableStateConfig = useMemo(
    () => ({
      pagination: {
        useSearchParams: true,
        total,
      },
      orderBy: {
        useSearchParams: true,
      },
      search: {
        useSearchParams: true,
        resetPageOnSearch: true,
        inputPlaceholder: "Search by product, author or vendor",
      },
    }),
    [total]
  );

  return (
    <CrudListPage
      crumbs={[
        {
          name: "Reviews",
          to: "/admin/reviews",
          active: true,
        },
      ]}
      cols={[
        {
          label: "Product",
          renderer: review => review.product.title,
          name: "product.title",
          sortable: true,
        },
        {
          name: "created_at",
          label: "Submitted",
          type: "date",
          sortable: true,
        },
        {
          label: "Author",
          renderer: review => {
            const ab = review.user;
            return `${ab.first_name} ${ab.last_name}`;
          },
          name: "user.first_name",
          sortable: true,
        },
        {
          label: "Approved By",
          renderer: review => {
            const ab = review.approved_by;
            return ab ? `${ab.first_name} ${ab.last_name}` : "Not approved";
          },
        },
        {
          label: "Responded",
          renderer: review => {
            const ab = review.responded_by;
            return ab ? `${ab.first_name} ${ab.last_name}` : "No Response";
          },
        },
      ]}
      showAddButton={false}
      data={reviews}
      title="Reviews"
      subtitle=""
      tableStateConfig={tableStateConfig}
    />
  );
}
