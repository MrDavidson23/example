import { useCallback, useEffect, useMemo, useState } from "react";
import { json } from "@remix-run/node";
import {
  Form,
  useActionData,
  useLoaderData,
  useNavigate,
  useNavigation,
  useSearchParams,
} from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { map } from "lodash";
import { CTA } from "~/components/cta.component";
import { Pagination } from "~/components/intelligence/pagination.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Permission } from "~/utils/intelligence-permission.utils";
import { LocationContractLineItemsTable } from "~/components/intelligence/locations/contract-line-item-location-table.component";
import { Button } from "~/components/button.component";
import { LocationsFilter } from "~/components/intelligence/locations/locations-filter.component";
import type { LocationsFilterType } from "~/services/location.service.server";
import { LocationsTable } from "~/components/intelligence/locations/locations-table.component";
import { CopyLocationAssignmentsEndModal } from "~/components/intelligence/locations/copy-location-assignments-end-modal.component";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { ChevronDownIcon, ChevronUpIcon } from "@heroicons/react/24/outline";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const DEFAULT_PER_PAGE = "50";
const DEFAULT_ITEMS_TO_COPY_TO_SHOW = 3;

export async function action({ request, params }: ActionFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocations],
      locationId: params.location_id,
    }
  );
  const { contractLineItemLocationService } = await WebDIContainer();

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);

  const itemsToCopyIds = search.get("itemsToCopy")?.split(",");

  const form = await request.formData();

  if (!itemsToCopyIds) {
    throw json({}, { status: 404 });
  }

  const locationIds = form.getAll("locationIds") as string[];

  const success =
    await contractLineItemLocationService.copyContractLineItemsToLocations(
      itemsToCopyIds,
      locationIds
    );

  const data = { itemsToCopyIds, locationIds };

  if (success) {
    return jsonWithSuccess(
      { success: true, data },
      "Items copied successfully"
    );
  } else {
    return jsonWithError(
      { success: false, data },
      "Error. Something went wrong when copying the line items. Please try again",
      { status: 400 }
    );
  }
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { account, user } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocations],
      locationId: params.location_id,
    }
  );
  const { contractLineItemLocationService, locationService } =
    await WebDIContainer();
  const managerAccountId = account.id;

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);

  const itemsToCopyIds = search.get("itemsToCopy")?.split(",");

  if (!itemsToCopyIds) {
    throw json({}, { status: 404 });
  }

  const location = await locationService.getLocation(params.location_id!);

  if (!location) {
    throw json({}, { status: 404 });
  }

  const itemsToCopy =
    await contractLineItemLocationService.getLocationContractLineItems(
      location.id,
      {
        location_id: location.id,
        id: { in: itemsToCopyIds },
      }
    );

  const page = parseInt(search.get("page") || "1");
  const perPage = parseInt(search.get("perPage") || DEFAULT_PER_PAGE);

  const locationsFilter: LocationsFilterType = {
    query: search.get("query") || "",
    unitCount: (search.getAll("unitCount") ||
      []) as LocationsFilterType["unitCount"],
    propertyClass: (search.getAll("propertyClass") ||
      []) as LocationsFilterType["propertyClass"],
    region: search.getAll("region") || [],
    propertyType: (search.getAll("propertyType") ||
      []) as LocationsFilterType["propertyType"],
    owner: search.getAll("owner") || [],
  };

  const offset = (page - 1) * perPage;

  const locations = await locationService.getLocations(
    user,
    account,
    locationsFilter,
    offset,
    perPage
  );

  const locationsCount = await locationService.getLocationsCount(
    user,
    account,
    locationsFilter
  );

  const regions = await locationService.getLocationsRegions(managerAccountId);

  const owners = await locationService.getLocationsOwners(managerAccountId);

  const paginationParams = {
    page: String(page),
    perPage: String(perPage),
  };

  return json({
    location,
    itemsToCopy,
    locations,
    locationsCount,
    paginationParams,
    locationsFilter,
    regions,
    owners,
    account,
  });
}

export default function CopyLocationAssignmentsTo() {
  const navigate = useNavigate();
  const {
    location,
    itemsToCopy,
    locations,
    locationsCount,
    paginationParams: initialPaginationParams,
    locationsFilter: initialLocationsFilter,
    regions,
    owners,
    account,
  } = useLoaderData<typeof loader>();

  const navigation = useNavigation();

  const actionData = useActionData<typeof action>();

  const [selectedLocations, setSelectedLocations] = useState<string[]>([]);

  const [, setSearchParams] = useSearchParams();

  const [paginationParams, setPaginationParams] = useState(
    initialPaginationParams
  );

  const [locationsFilter, setLocationsFilter] = useState(
    initialLocationsFilter
  );

  const [openEndModal, setOpenEndModal] = useState(false);

  const [showAllLineItems, setShowAllLineItems] = useState(false);

  const totalPages = useMemo(
    () => Math.ceil(locationsCount / Number(paginationParams.perPage)),
    [locationsCount, paginationParams.perPage]
  );
  const pageNumbers = useMemo(
    () => Array.from({ length: totalPages }, (_, i) => i + 1),
    [totalPages]
  );
  const resultsText = useMemo(
    () => `${locations.length} out of ${locationsCount} results`,
    [locations, locationsCount]
  );

  const copiedItemsCount = useMemo(
    () =>
      actionData?.success
        ? itemsToCopy.filter(item =>
            actionData.data.itemsToCopyIds.includes(item.id)
          ).length
        : 0,
    [actionData, itemsToCopy]
  );
  const toLocationsCount = useMemo(
    () =>
      actionData?.success
        ? locations.filter(location =>
            actionData.data.locationIds.includes(location.id)
          ).length
        : 0,
    [actionData, locations]
  );

  const onFilter = useCallback((locationSearchParams: LocationsFilterType) => {
    setPaginationParams(old => ({ ...old, page: "1" }));
    setLocationsFilter(locationSearchParams);
  }, []);

  const handlePageChange = useCallback((page: Number) => {
    setPaginationParams(old => ({ ...old, page: String(page) }));
  }, []);

  useEffect(() => {
    setSearchParams(oldSearchParams => ({
      ...Object.fromEntries(oldSearchParams),
      ...paginationParams,
      ...locationsFilter,
    }));
  }, [locationsFilter, paginationParams, setSearchParams]);

  useEffect(() => {
    setOpenEndModal(actionData?.success === true);
  }, [actionData]);

  const itemsToCopyToShow = useMemo(
    () =>
      showAllLineItems
        ? itemsToCopy
        : itemsToCopy.slice(0, DEFAULT_ITEMS_TO_COPY_TO_SHOW),
    [itemsToCopy, showAllLineItems]
  );

  const itemsToCopyCount = itemsToCopy.length;

  const renderActionButtons = useCallback(
    () => (
      <Form method="post">
        {selectedLocations.map(locationId => (
          <input
            type="hidden"
            name="locationIds"
            value={locationId}
            key={locationId}
          />
        ))}
        <div className="flex justify-end">
          <Button
            onClick={() =>
              navigate(
                `/intelligence/${account.id}/locations/${location.id}/assigned-vendors/copy`
              )
            }
            color="transparent"
            className="mr-3"
          >
            Go Back
          </Button>

          <CTA
            id="copy-to-locations-button"
            type="submit"
            disabled={navigation.state !== "idle"}
          >
            Copy to {selectedLocations.length} Location
            {selectedLocations.length !== 1 ? "s" : ""}
          </CTA>
        </div>
      </Form>
    ),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [location.id, navigation.state, selectedLocations, navigate]
  );

  return (
    <>
      <CopyLocationAssignmentsEndModal
        isOpen={openEndModal}
        onClose={() => setOpenEndModal(false)}
        onGoBack={() =>
          navigate(
            `/intelligence/${account.id}/locations/${location.id}/assigned-vendors`
          )
        }
        locationName={location.name}
        copiedItemsCount={copiedItemsCount}
        toLocationsCount={toLocationsCount}
      />
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
          },
          {
            name: "Assigned line items",
            to: `/intelligence/${account.id}/locations/${location.id}/assigned-vendors`,
          },
          {
            name: "Copy assignments",
            to: `/intelligence/${account.id}/locations/${location.id}/assigned-vendors/copy`,
          },
          {
            name: "Assign configuration",
            to: `#`,
            active: true,
          },
        ]}
        title={
          <>
            Copy {itemsToCopyCount} line item
            {itemsToCopyCount !== 1 ? "s" : ""}
          </>
        }
        buttonsSlot={renderActionButtons()}
      />
      <LocationContractLineItemsTable
        columnsToShow={[
          "vendorNameWithContractName",
          "contractLineItemName",
          "price",
          "currentTermEnds",
          "contractLineItemStatus",
        ]}
        items={itemsToCopyToShow}
      />
      {itemsToCopyCount > DEFAULT_ITEMS_TO_COPY_TO_SHOW && (
        <div className="flex justify-center">
          <Button
            onClick={() => setShowAllLineItems(!showAllLineItems)}
            color="transparent"
          >
            See {showAllLineItems ? "less" : `all ${itemsToCopyCount}`} line
            items
            {showAllLineItems ? (
              <ChevronUpIcon className="h-5 w-5 ml-2" />
            ) : (
              <ChevronDownIcon className="h-5 w-5 ml-2" />
            )}
          </Button>
        </div>
      )}

      <section className="mt-10">
        <h3 className="font-semibold text-lg lg:text-2xl">Select locations</h3>
        <div className="mt-4">
          <span>
            Select the locations to assign this configuration to by checking the
            box in the corresponding row.
          </span>
        </div>
        <div className="mt-4">
          <LocationsFilter
            initialSearchParams={locationsFilter}
            onFilter={onFilter}
            regionOptions={map(regions, "region")}
            ownerOptions={map(owners, "owner_name") as string[]}
          />
        </div>
        <div className="mt-4">
          <LocationsTable
            items={locations}
            columnsToShow={[
              "name",
              "city",
              "state",
              "region",
              "contractLineItems",
            ]}
            showSelectBox={true}
            onSelectRows={setSelectedLocations}
          />
        </div>
        <Pagination
          resultsText={resultsText}
          pageNumbers={pageNumbers}
          currentPage={Number(paginationParams.page) || 1}
          totalPages={totalPages}
          handleCallback={handlePageChange}
        ></Pagination>
      </section>
      {renderActionButtons()}
    </>
  );
}
