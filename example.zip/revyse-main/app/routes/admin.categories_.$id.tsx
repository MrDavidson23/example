import { TrashIcon } from "@heroicons/react/20/solid";
import { Prisma, ResidentLifecyclePhase } from "@prisma/client";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import {
  Form,
  useActionData,
  useLoaderData,
  useNavigation,
} from "@remix-run/react";
import { isNil } from "lodash";
import { useEffect, useState } from "react";
import {
  jsonWithError,
  redirectWithError,
  redirectWithSuccess,
} from "remix-toast";
import { z } from "zod";
import { Button, DangerButton } from "~/components/button.component";
import { CrudFormPage } from "~/components/form/crud-form-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assertAuthorized } from "~/utils/assert.utils.server";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import { getUser } from "~/utils/session.server";
import { castFormFields } from "~/utils/type.utils";
import { NonEmptyString } from "~/utils/validation.utils.server";

const CategoryForm = z.object({
  name: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  highlighted: z
    .string()
    .optional()
    .nullable()
    .transform(h => !!h),
  primary_vendor_type: z.string(),
  secondary_vendor_type: z.string(),
  slug: NonEmptyString,
  faq_1: NonEmptyString,
  faq_1_answer: NonEmptyString,
  faq_2: NonEmptyString,
  faq_2_answer: NonEmptyString,
  faq_3: NonEmptyString,
  faq_3_answer: NonEmptyString,
  page_title: NonEmptyString,
  meta_description: NonEmptyString,
  resident_lifecycle_phase: z.nativeEnum(ResidentLifecyclePhase),
});

async function updateAction({
  id,
  form,
}: {
  id: string | undefined;
  form: FormData;
}) {
  const fields = {
    name: form.get("name"),
    description: form.get("description"),
    highlighted: form.get("highlighted"),
    primary_vendor_type: form.get("primary_vendor_type"),
    secondary_vendor_type: form.get("secondary_vendor_type"),
    slug: form.get("slug"),
    faq_1: form.get("faq_1"),
    faq_1_answer: form.get("faq_1_answer"),
    faq_2: form.get("faq_2"),
    faq_2_answer: form.get("faq_2_answer"),
    faq_3: form.get("faq_3"),
    faq_3_answer: form.get("faq_3_answer"),
    page_title: form.get("page_title"),
    meta_description: form.get("meta_description"),
    resident_lifecycle_phase: form.get("resident_lifecycle_phase"),
  };

  const validation = CategoryForm.safeParse(fields);

  if (validation.success) {
    const { productCategoryService } = await WebDIContainer();
    await productCategoryService.updateCategory(id!, validation.data);

    return redirectWithSuccess(
      "/admin/categories",
      "Category updated successfully"
    );
  }

  return jsonWithError(
    {
      fields: castFormFields(fields),
      success: false,
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
}

async function deleteAction({ id }: { id: string | undefined }) {
  const { productCategoryService } = await WebDIContainer();
  try {
    await productCategoryService.deleteCategory(id!);

    return redirectWithSuccess(
      "/admin/categories",
      "Category deleted successfully"
    );
  } catch (e) {
    if (e instanceof Error && e.message === "Category has products") {
      return jsonWithError(
        {
          success: false,
          errors: issuesByKey([]),
          fields: castFormFields({}),
        },
        "This category has assigned products, and cannot be deleted. To delete this category, first unassign all products.",
        { status: 400 }
      );
    }

    if (
      e instanceof Prisma.PrismaClientKnownRequestError &&
      e.code === "P2025"
    ) {
      return redirectWithError("/admin/categories", "Category not found");
    }

    throw new Response("Internal Server Error", { status: 500 });
  }
}

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));
  const form = await request.formData();
  const intent = form.get("intent");
  if (intent === "delete") {
    return deleteAction({ id: params.id });
  }

  return updateAction({ id: params.id, form });
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { productCategoryService } = await WebDIContainer();
  const category = await productCategoryService.getCategory({ id: params.id });
  if (isNil(category)) {
    throw json(undefined, { status: 404 });
  }
  return json({ category });
}

export default function AdminCategoryIdRoute() {
  const actionData = useActionData<typeof action>();
  const { category } = useLoaderData<typeof loader>();
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const navigation = useNavigation();

  useEffect(() => {
    if (navigation.state == "idle") {
      window.scrollTo(0, 0);
    }
  }, [navigation.state]);

  useEffect(() => {
    if (actionData?.success === false) {
      setConfirmDeleteOpen(false);
    }
  }, [actionData]);

  return (
    <>
      <CrudFormPage
        crumbs={[
          { name: "Categories", to: "/admin/categories", active: false },
          {
            name: category.name,
            to: `/admin/categories/${category.id}`,
            active: true,
          },
        ]}
        config={{
          submitSuccess: actionData?.success,
          showToast: false,
          sections: [
            {
              title: "Update Category",
              subtitle: "",
              fields: [
                {
                  name: "name",
                  label: "Name",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.name ?? undefined
                    : category.name,
                  errors: actionData?.errors?.name ?? [],
                },
                {
                  name: "slug",
                  label: "Slug",
                  type: "text",
                  defaultValue: category.slug,
                  description:
                    "The slug should only be changed for a very good reason. It will mess up SEO.",
                  errors: actionData?.errors?.name ?? [],
                },
                {
                  name: "description",
                  label: "Description",
                  description: "A full description of the category",
                  type: "textarea",
                  defaultValue: actionData
                    ? actionData.fields?.description ?? undefined
                    : category.description,
                  errors: actionData?.errors?.description ?? [],
                },
                {
                  name: "highlighted",
                  label: "Highlighted",
                  description:
                    "Should this category be highlighted on the home page?",
                  type: "checkbox",
                  defaultChecked: actionData
                    ? actionData.fields?.highlighted === "true"
                    : category.highlighted,
                  value: "true",
                  errors: actionData?.errors?.highlighted ?? [],
                },

                {
                  name: "resident_lifecycle_phase",
                  label: "Revyse Intelligence Phase",
                  type: "select",
                  options: Object.values(ResidentLifecyclePhase).map(phase => ({
                    label: phase.replace(/([A-Z])/g, " $1").trim(),
                    value: phase,
                  })),
                  defaultValue: actionData
                    ? actionData.fields?.resident_lifecycle_phase ?? undefined
                    : category.resident_lifecycle_phase,
                  errors: actionData?.errors?.resident_lifecycle_phase ?? [],
                },

                {
                  name: "primary_vendor_type",
                  label: "Primary Vendor Type",
                  type: "select",
                  options: [
                    { label: "Technology", value: "Technology" },
                    { label: "Suppliers", value: "Suppliers" },
                    { label: "Services", value: "Services" },
                  ],
                  defaultValue: actionData
                    ? actionData.fields?.primary_vendor_type ?? undefined
                    : category.primary_vendor_type,
                  errors: actionData?.errors?.primary_vendor_type ?? [],
                },

                {
                  name: "secondary_vendor_type",
                  label: "Secondary Vendor Type",
                  type: "select",
                  options: [
                    { label: "Hardware", value: "Hardware" },
                    { label: "Software", value: "Software" },
                    {
                      label: "Professional Services",
                      value: "Professional Services",
                    },
                    { label: "Consulting", value: "Consulting" },
                    { label: "Agencies", value: "Agencies" },
                    { label: "Freelancers", value: "Freelancers" },
                    { label: "Materials", value: "Materials" },
                    { label: "Onsite Services", value: "Onsite Services" },
                  ],
                  defaultValue: actionData
                    ? actionData.fields?.secondary_vendor_type ?? undefined
                    : category.secondary_vendor_type,
                  errors: actionData?.errors?.secondary_vendor_type ?? [],
                },

                {
                  name: "faq_1",
                  label: "FAQ 1",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.faq_1 ?? undefined
                    : category.faq_1,
                  errors: actionData?.errors?.faq_1 ?? [],
                },
                {
                  name: "faq_1_answer",
                  label: "FAQ 1 Answer",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.faq_1_answer ?? undefined
                    : category.faq_1_answer,
                  errors: actionData?.errors?.faq_1_answer ?? [],
                },
                {
                  name: "faq_2",
                  label: "FAQ 2",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.faq_2 ?? undefined
                    : category.faq_2,
                  errors: actionData?.errors?.faq_2 ?? [],
                },
                {
                  name: "faq_2_answer",
                  label: "FAQ 2 Answer",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.faq_2_answer ?? undefined
                    : category.faq_2_answer,
                  errors: actionData?.errors?.faq_2_answer ?? [],
                },
                {
                  name: "faq_3",
                  label: "FAQ 3",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.faq_3 ?? undefined
                    : category.faq_3,
                  errors: actionData?.errors?.faq_3 ?? [],
                },
                {
                  name: "faq_3_answer",
                  label: "FAQ 3 Answer",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.faq_3_answer ?? undefined
                    : category.faq_3_answer,
                  errors: actionData?.errors?.faq_3_answer ?? [],
                },
                {
                  name: "page_title",
                  label: "Page Title",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.page_title ?? undefined
                    : category.page_title,
                  errors: actionData?.errors?.page_title ?? [],
                },
                {
                  name: "meta_description",
                  label: "Meta Description",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.meta_description ?? undefined
                    : category.meta_description,
                  errors: actionData?.errors?.meta_description ?? [],
                },
              ],
            },
          ],
        }}
        buttonsSlot={
          confirmDeleteOpen ? (
            <Form className="flex justify-between  items-center" method="post">
              Are you sure you want to delete this category?
              <input type="hidden" name="intent" value="delete" />
              <Button
                onClick={() => setConfirmDeleteOpen(false)}
                className="ml-2 bg-gray-300 hover:bg-gray-400"
              >
                Cancel
              </Button>
              <DangerButton type="submit" className="ml-2">
                Yep!
              </DangerButton>
            </Form>
          ) : (
            <DangerButton
              onClick={() => {
                setConfirmDeleteOpen(!confirmDeleteOpen);
              }}
            >
              <div className="flex">
                <TrashIcon className="h-5 mr-1" />
                Delete
              </div>
            </DangerButton>
          )
        }
      />
    </>
  );
}
