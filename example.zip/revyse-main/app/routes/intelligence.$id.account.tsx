import { json, redirect, type LoaderFunctionArgs } from "@remix-run/node";
import { Outlet, useLoaderData } from "@remix-run/react";
import { first, flatMap } from "lodash";
import { IntelligenceAccountTabs } from "~/components/intelligence/account/intelligence-account-tabs.component";
import {
  canDoSomeOnAccount,
  canDoSomeOnAccountOrThrow,
  type PermissionType,
  Permission,
} from "~/utils/intelligence-permission.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { equalPathnames } from "~/utils/string.utils";

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account: managerAccount } = await verifyIntelligenceRequest(
    { request, params },
    {}
  );

  const { id: managerAccountId } = params as { id: string };

  const options: {
    navigateTo: string;
    label: string;
    expectedResult: string;
    permissions: PermissionType[];
    id?: string;
  }[] = [
    {
      id: "account-tab",
      expectedResult: "account",
      navigateTo: `/intelligence/${managerAccountId}/account`,
      label: "Account Information",
      permissions: [Permission.ViewAccountInformation],
    },
    {
      id: "users-tab",
      expectedResult: "users",
      navigateTo: `/intelligence/${managerAccountId}/account/users`,
      label: "User Management",
      permissions: [Permission.ViewAccountUsers],
    },
    // {
    //   label: "Region Configurations",
    // },
    // {
    //   label: "Email Templates",
    // },
  ];

  const url = new URL(request.url);
  const authorizedOptions = options.filter(option =>
    canDoSomeOnAccount(user, managerAccount, option.permissions)
  );

  // If the current url is any of the links
  if (options.some(option => equalPathnames(option.navigateTo, url.pathname))) {
    // If no permissions to any tab, throw 403
    canDoSomeOnAccountOrThrow(
      user,
      managerAccount,
      flatMap(options, "permissions")
    );

    // If no permissions to the requested tab, navigate to the first available
    if (
      !authorizedOptions.some(link =>
        equalPathnames(link.navigateTo, url.pathname)
      )
    ) {
      throw redirect(first(authorizedOptions)?.navigateTo || "/", 303);
    }
  }

  return json({
    options: authorizedOptions,
  });
}

export default function IntelligenceManagerAccount() {
  const { options } = useLoaderData<typeof loader>();

  return (
    <>
      <div className="space-y-8 pb-12">
        <IntelligenceAccountTabs options={options} />
        <Outlet />
      </div>
    </>
  );
}
