import { Form, Link, useLoaderData, useNavigate } from "@remix-run/react";
import { json } from "@remix-run/node";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { isNil } from "lodash";
import { getUser } from "../utils/session.server";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { Role } from "@prisma/client";
import { assert } from "../utils/assert.utils.server";
import { CrudListPage } from "../components/crud-list-page.component";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import { Button, DangerButton } from "~/components/button.component";
import { userHasPermission } from "~/utils/permission.utils";
import { jsonWithError, jsonWithSuccess } from "remix-toast";

async function cancelInvite({ id }: { id: string }) {
  const { productSubscriptionService } = await WebDIContainer();
  await productSubscriptionService.cancelSubscriptionInvite(id);
  return jsonWithSuccess(
    { success: true },
    "User invitation has been cancelled"
  );
}

async function resendInvite({
  email,
  token,
}: {
  email: string;
  token: string;
}) {
  const { productSubscriptionService } = await WebDIContainer();
  await productSubscriptionService.generateUserInviteEmail(email, token);
  return jsonWithSuccess({ success: true }, "User invitation has been resent");
}

const CancelInviteForm = z.object({
  id: z.string(),
});

const ResendInviteForm = z.object({
  email: z.string(),
});

export async function action({ params, request }: ActionFunctionArgs) {
  const form = await request.formData();
  const id = form.get("id");
  const email = form.get("email");
  const fields = { id, email };
  if (id) {
    const validation = CancelInviteForm.safeParse(fields);
    if (validation.success) {
      return cancelInvite({ id: validation.data.id });
    }
    return jsonWithError(
      {
        success: false,
        fields,
        errors: issuesByKey(validation.error.issues),
      },
      "Something went wrong. Please try again",
      { status: 400 }
    );
  } else {
    const validation = ResendInviteForm.safeParse(fields);
    if (validation.success) {
      return resendInvite({
        email: validation.data.email,
        token: params?.id as string,
      });
    }
    return jsonWithError(
      {
        success: false,
        fields,
        errors: issuesByKey(validation.error.issues),
      },
      "Something went wrong. Please try again",
      { status: 400 }
    );
  }
}

export async function loader({ request, params }: LoaderFunctionArgs) {
  const user = await getUser(request);
  assert(!isNil(user), "User must be logged in to see user list");

  const { db, productSubscriptionService } = await WebDIContainer();
  const userRole = await productSubscriptionService.getResourceUserRole({
    filters: {
      user_id: user.id,
      resource_id: params.id,
    },
  });

  assert(
    user.id === userRole?.user_id,
    "User must have authorization to see user list"
  );

  const pendingUsers = await db.userInvitation.findMany({
    where: {
      role: {
        path: ["resource_id"],
        equals: params.id,
      },
      accepted_by_id: null,
    },
  });
  const loggedInUser = user.user_roles.find(
    r => r.resource_id === params.id
  )?.role;

  const product = userRole?.product_subscription?.product;
  const users = await productSubscriptionService.getSubscriptionUsers(
    params.id
  );

  return json({
    users,
    pendingUsers,
    product,
    resourceId: params.id,
    loggedInUser,
  });
}

export default function VendorUsersRoute() {
  const { users, pendingUsers, product, resourceId, loggedInUser } =
    useLoaderData<typeof loader>();
  const navigate = useNavigate();
  return (
    <>
      <CrudListPage
        crumbs={[
          { name: "Product Listing", to: `/vendor/products/${product?.id}` },
          {
            name: "Users",
            to: `/vendor/product/${resourceId}/users`,
            active: true,
          },
        ]}
        cols={[
          { name: "user.first_name", label: "First name" },
          { name: "user.last_name", label: "Last name" },
          { name: "user.email", label: "Email" },
          {
            name: "role",
            label: "Role",
            renderer: user =>
              user.role === Role.OWNER &&
              !userHasPermission(loggedInUser, "assign_new_owners") ? (
                <span>{user.role}</span>
              ) : (
                <Link
                  onClick={e => e.stopPropagation()}
                  to={`/vendor/product/${resourceId}/users/${user.id}`}
                  className="text-sky-600 underline"
                >
                  {user.role}
                </Link>
              ),
          },
        ]}
        data={users}
        title={`${product?.title} contributors`}
        subtitle=""
        onClickRow={user => {
          if (
            user.role === Role.OWNER &&
            !userHasPermission(loggedInUser, "assign_new_owners")
          ) {
            return null;
          }
          navigate(`/vendor/product/${resourceId}/users/${user.id}`);
        }}
      />
      <CrudListPage
        crumbs={[]}
        cols={[
          { name: "email", label: "Email" },
          { name: "role.role", label: "Role" },
          {
            label: "Action",
            renderer: sub => (
              <div className="flex flex-row space-x-2">
                <Form method="post">
                  <input defaultValue={sub.id} name="id" hidden={true} />
                  <DangerButton id={`cancel_${sub.id}`} type="submit">
                    Cancel Invite
                  </DangerButton>
                </Form>

                <Form method="post">
                  <input defaultValue={sub.email} name="email" hidden={true} />
                  <Button id={`resend_${sub.id}`} type="submit">
                    Resend Invite
                  </Button>
                </Form>
              </div>
            ),
          },
        ]}
        data={pendingUsers}
        title={`${product?.title} pending user invitations`}
        subtitle=""
        showAddButton={false}
        onClickRow={() => {
          return null;
        }}
      />
    </>
  );
}
