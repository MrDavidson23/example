import { useCallback, useEffect, useMemo, useState } from "react";
import { json, redirect } from "@remix-run/node";
import { every, isEmpty } from "lodash";
import { z } from "zod";
import type { Location, Prisma, File as PrismaFile } from "@prisma/client";
import {
  ContractLineItemLocationStatus,
  ContractStatus,
  LocationClass,
  LocationPropertyType,
  LocationStatus,
} from "@prisma/client";
import {
  ArrowUpOnSquareIcon,
  ChevronDownIcon,
  ChevronUpIcon,
  InformationCircleIcon,
  PlusIcon,
} from "@heroicons/react/24/outline";
import { CTA } from "~/components/cta.component";
import { Table } from "~/components/intelligence/table.component";
import { Link, useFetcher, useLoaderData, useNavigate } from "@remix-run/react";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  SerializeFrom,
} from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { Modal } from "~/components/modal.component";
import { CrudCheckboxField } from "~/components/form/crud-form.component";
import { Pagination } from "~/components/intelligence/pagination.component";
import { NonEmptyString } from "~/utils/validation.utils.server";
import { AutocompleteFilter } from "~/components/intelligence/autocomplete-filter.component";
import {
  canDoOnAccount,
  Permission,
} from "~/utils/intelligence-permission.utils";
import { FilterBar } from "~/components/filter-bar.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import DocumentCard from "~/components/intelligence/document-card.component";
import { ConfirmDeleteModal } from "~/components/modals/confirm-delete-modal.component";
import DocumentModal from "~/components/intelligence/document-modal.component";
import type { action as locationDocumentsAction } from "../routes/intelligence.$id.contract.$contract_id.contracted-locations.documents";
import { Tooltip } from "~/components/tooltip.component";
import { encodeFilename } from "~/utils/file.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { CanDo } from "~/components/intelligence/can-do.component";

export type ContractLocationFile = {
  id?: string;
  name?: string | null;
  created_at?: string | Date;
  file?: SerializeFrom<PrismaFile> | null;
  new_file?: File;
  status?: "uploading" | "uploaded" | "success";
};

type Region = { region: string | undefined | null };
type Owner = { owner_name: string | undefined | null };

const SearchRegionForm = z.object({
  term: NonEmptyString,
});

export const action = async ({ request, params }: ActionFunctionArgs) => {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewContractLocations],
    }
  );

  const managerAccountId = account.id;

  const form = await request.formData();

  const { locationService } = await WebDIContainer();

  const fields = {
    term: form.get("term"),
  };
  const validation = SearchRegionForm.safeParse(fields);

  if (validation.success) {
    const regions = await locationService.getLocationsRegions(managerAccountId);
    return json({ success: true, fields: fields, regions });
  }
  return json({
    success: false,
    vendor: null,
    vendors: null,
    errors: issuesByKey(validation.error.issues),
  });
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewContractLocations],
    }
  );

  const managerAccountId = account.id;
  const contractId = params.contract_id!;

  const { locationService, contractService } = await WebDIContainer();

  const contract = await contractService.getContractById(contractId);

  // This route is inaccessible if the contract have a location assigned
  if (contract.location_id) {
    throw redirect(
      `/intelligence/${managerAccountId}/contract/${contractId}/details/`
    );
  }

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const searchTerm = search.get("query");
  const unitCountParam = search.getAll("unit_count");
  const propertyClassParam = search.getAll("property_class");
  const propertyTypeParam = search.getAll("property_type");

  const regionParam = search.getAll("region");
  const ownerParam = search.getAll("owner");
  const page = parseInt(search.get("page") || "1");
  const perPage = parseInt(search.get("perPage") || "50");

  const offset = (page - 1) * perPage;

  const filters: Prisma.ContractLineItemLocationWhereInput = {
    contract_line_item: {
      contract_id: params.contract_id,
    },
    AND: [
      {
        OR: [
          {
            location: {
              name: {
                contains: searchTerm ?? "",
                mode: "insensitive",
              },
            },
          },
          {
            location: {
              street_1: {
                contains: searchTerm ?? "",
                mode: "insensitive",
              },
            },
          },
          {
            location: {
              street_2: {
                contains: searchTerm ?? "",
                mode: "insensitive",
              },
            },
          },
          {
            location: {
              city: {
                contains: searchTerm ?? "",
                mode: "insensitive",
              },
            },
          },
          {
            location: {
              state: {
                contains: searchTerm ?? "",
                mode: "insensitive",
              },
            },
          },
          {
            location: {
              region: {
                contains: searchTerm ?? "",
                mode: "insensitive",
              },
            },
          },
          {
            location: {
              owner_name: {
                contains: searchTerm ?? "",
                mode: "insensitive",
              },
            },
          },
        ],
      },
    ],
  };

  if (regionParam.length > 0) {
    const regions = regionParam[0].split(",");

    const regionFilters: Prisma.ContractLineItemLocationWhereInput[] =
      regions.map(term => ({
        location: {
          region: {
            contains: term,
            mode: "insensitive",
          },
        },
      }));

    if (regionFilters.length > 0) {
      filters.AND = [
        ...(filters.AND as Prisma.ContractLineItemLocationWhereInput[]),
        {
          OR: regionFilters,
        },
      ];
    }
  }

  if (ownerParam.length > 0) {
    const owners = ownerParam[0].split(",");

    const ownerFilters: Prisma.ContractLineItemLocationWhereInput[] =
      owners.map(term => ({
        location: {
          owner_name: {
            contains: term,
            mode: "insensitive",
          },
        },
      }));

    if (ownerFilters.length > 0) {
      filters.AND = [
        ...(filters.AND as Prisma.ContractLineItemLocationWhereInput[]),
        {
          OR: ownerFilters,
        },
      ];
    }
  }

  // Handle multiple unit_count ranges on filtering
  if (unitCountParam.length > 0) {
    const unitCountFilter = unitCountParam
      .flatMap(range => {
        const ranges = range.split(",");
        return ranges.map(singleRange => {
          if (singleRange.includes("-")) {
            const [min, max] = singleRange.split("-").map(Number);
            if (!isNaN(min) && !isNaN(max)) {
              return { location: { unit_count: { gte: min, lte: max } } };
            }
          } else if (singleRange === "500") {
            return { location: { unit_count: { gte: 500 } } };
          } else {
            const min = Number(singleRange);
            if (!isNaN(min)) {
              return { location: { unit_count: { equals: min } } };
            }
          }
          return null;
        });
      })
      .filter(Boolean);

    if (unitCountFilter.length > 0) {
      filters.AND = [
        ...(filters.AND as Prisma.ContractLineItemLocationWhereInput[]),
        {
          OR: unitCountFilter as Prisma.ContractLineItemLocationWhereInput[],
        },
      ];
    }
  }
  // Handle multiple property_class values on filtering
  if (propertyClassParam.length > 0) {
    filters.location = {
      class: {
        in: propertyClassParam.flatMap(value =>
          value.split(",")
        ) as LocationClass[],
      },
    };
  }

  if (propertyTypeParam.length > 0) {
    filters.location = {
      property_type: {
        in: propertyTypeParam.flatMap(value =>
          value.split(",")
        ) as LocationPropertyType[],
      },
    };
  }
  const locations = await contractService.loadContractedLocations(
    params.contract_id,
    filters,
    offset,
    perPage
  );

  const locationsCount = (
    await contractService.loadContractedLocations(params.contract_id, filters)
  ).length;

  const regions = await locationService.getLocationsRegions(managerAccountId);

  const owners = await locationService.getLocationsOwners(managerAccountId);

  return json({
    user,
    account,
    locations,
    regions,
    owners,
    url,
    contract,
    locationsCount,
    unitCountParam,
    propertyClassParam,
    propertyTypeParam,
    searchTerm,
    regionParam,
    ownerParam,
    page,
  });
}

export default function AssociatedLocations() {
  const navigate = useNavigate();
  const {
    user,
    account,
    contract,
    locations,
    regions,
    owners,
    locationsCount,
    unitCountParam,
    propertyClassParam,
    propertyTypeParam,
    searchTerm,
    regionParam,
    ownerParam,
    page,
  } = useLoaderData<typeof loader>();
  const baseUrl = `/intelligence/${account.id}/contract/${contract.id}/contracted-locations/`;
  const fetcher = useFetcher<SerializeFrom<typeof locationDocumentsAction>>();

  const [showAllContractLineItems, setShowAllContractLineItems] = useState(() =>
    Array(locations.length).fill(false)
  );
  const [openFilteringModal, setOpenFilteringModal] = useState(false);
  const [filterByPropertyClass, setFilterByPropertyClass] = useState<string[]>(
    []
  );
  const [filterByPropertyType, setFilterByPropertyType] = useState<string[]>(
    []
  );
  const [filterByRegion, setFilterByRegion] = useState<string[]>([]);
  const [filterByOwnerName, setFilterByOwnerName] = useState<string[]>([]);
  const [selectedRegions, setSelectedRegions] = useState<Region[]>([]);
  const [selectedOwners, setSelectedOwners] = useState<Owner[]>([]);

  const [autocompleteValue, setAutocompleteValue] = useState<string>("");
  const [autocompleteOwnerName, setAutocompleteOwnerName] =
    useState<string>("");
  const [regionErrorMessage, setRegionErrorMessage] = useState<string>("");
  const [ownerErrorMessage, setOwnerErrorMessage] = useState<string>("");

  const [currentPage, setCurrentPage] = useState(page ?? 1);
  const perPage = 50; // [perPage, setPerPage] = useState(50);

  const [documentModal, setDocumentModal] = useState<{
    open: boolean;
    locationId?: string;
    document?: ContractLocationFile;
  }>({ open: false, document: undefined, locationId: undefined });

  const [documentToDelete, setDocumentToDelete] = useState<string | undefined>(
    undefined
  );
  const [openFilesModal, setOpenFilesModal] = useState(false);

  const [selectedLocation, setSelectedLocation] = useState<
    | (SerializeFrom<Location> & {
        contracted_location_files: ContractLocationFile[];
      })
    | undefined
  >(undefined);

  const unitCountFilter = [
    { value: "1-50", name: "1-50" },
    { value: "50-100", name: "50-100" },
    { value: "100-200", name: "100-200" },
    { value: "200-500", name: "200-500" },
    { value: "500", name: "500+" },
  ];
  const [filterByUnitCount, setFilterByUnitCount] = useState<string[]>([]);

  const propertyClassFilter = [
    { name: "A+", value: LocationClass.APlus },
    { name: LocationClass.A, value: LocationClass.A },
    { name: LocationClass.B, value: LocationClass.B },
    { name: LocationClass.C, value: LocationClass.C },
    { name: LocationClass.D, value: LocationClass.D },
  ];

  const propertyTypeFilter = [
    {
      name: "Conventional Multifamily",
      value: LocationPropertyType.ConventionalMultifamily,
    },
    {
      name: LocationPropertyType.Affordable,
      value: LocationPropertyType.Affordable,
    },
    {
      name: LocationPropertyType.Student,
      value: LocationPropertyType.Student,
    },
    { name: LocationPropertyType.Senior, value: LocationPropertyType.Senior },
    { name: "Self Storage", value: LocationPropertyType.SelfStorage },
    {
      name: "Office/Commercial",
      value: LocationPropertyType.OfficeCommercial,
    },
    { name: "Build-to-Rent", value: LocationPropertyType.BuildToRent },
    { name: "Single Family", value: LocationPropertyType.SingleFamily },
    { name: LocationPropertyType.Other, value: LocationPropertyType.Other },
  ];

  function constructNewURL(
    baseUrl: string,
    searchQuery: string,
    filterByUnitCount: string[],
    filterByPropertyClass: string[],
    filterByPropertyType: string[],
    filterByRegion: string[],
    filterByOwnerName: string[],
    newPage: number,
    perPage: number
  ): string {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchQuery);

    if (filterByUnitCount.length > 0) {
      searchParams.append("unit_count", filterByUnitCount.join(","));
    }
    if (filterByPropertyClass.length > 0) {
      searchParams.append("property_class", filterByPropertyClass.join(","));
    }
    if (filterByPropertyType.length > 0) {
      searchParams.append("property_type", filterByPropertyType.join(","));
    }
    if (filterByRegion.length > 0) {
      searchParams.append("region", filterByRegion.join(","));
    }

    if (filterByOwnerName.length > 0) {
      searchParams.append("owner", filterByOwnerName.join(","));
    }

    searchParams.append("page", newPage.toString());
    searchParams.append("perPage", perPage.toString());

    return `${baseUrl}?${searchParams.toString()}`;
  }

  // Handle filtering, name searching and pagination
  const handleFiltering = (newPage?: number, newSearchQuery?: string) => {
    const newURL = constructNewURL(
      baseUrl,
      newSearchQuery ?? searchTerm ?? "",
      filterByUnitCount,
      filterByPropertyClass,
      filterByPropertyType,
      filterByRegion,
      filterByOwnerName,
      newPage ? newPage : currentPage,
      perPage
    );
    setOpenFilteringModal(false);
    navigate(newURL);
  };

  const clearFilters = () => {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchTerm ?? "");

    setFilterByPropertyClass([]);
    setFilterByPropertyType([]);
    setFilterByUnitCount([]);
    setFilterByRegion([]);
    setFilterByOwnerName([]);
    setSelectedRegions([]);
    setSelectedOwners([]);

    searchParams.delete("unit_count");
    searchParams.delete("property_class");
    searchParams.delete("property_type");
    searchParams.delete("region");
    searchParams.delete("owner");

    const newURL = `${baseUrl}?${searchParams.toString()}`;

    setOpenFilteringModal(false);
    navigate(newURL);
  };

  useEffect(() => {
    if (unitCountParam.length > 0) {
      const unitCounts = unitCountParam.flatMap(value => value.split(","));
      setFilterByUnitCount(unitCounts);
    }

    if (propertyClassParam.length > 0) {
      const propertyClasses = propertyClassParam.flatMap(value =>
        value.split(",")
      );
      setFilterByPropertyClass(propertyClasses);
    }

    if (propertyTypeParam.length > 0) {
      const propertyTypes = propertyTypeParam.flatMap(value =>
        value.split(",")
      );
      setFilterByPropertyType(propertyTypes);
    }

    if (regionParam.length > 0) {
      const regionFilters = regionParam.flatMap(value => value.split(","));
      setFilterByRegion(regionFilters);

      const initialSelectedRegions = regions
        .filter(region => regionFilters.includes(region?.region || ""))
        .filter(Boolean);

      setSelectedRegions(initialSelectedRegions);
    }

    if (ownerParam.length > 0) {
      const ownerFilters = ownerParam.flatMap(value => value.split(","));
      setFilterByOwnerName(ownerFilters);

      const initialSelectedOwners = owners
        .filter(owner => ownerFilters.includes(owner?.owner_name || ""))
        .filter(Boolean);

      setSelectedOwners(initialSelectedOwners);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handlePageChange = (newPage: number) => {
    const newURL = constructNewURL(
      baseUrl,
      searchTerm ?? "",
      filterByUnitCount,
      filterByPropertyClass,
      filterByPropertyType,
      filterByRegion,
      filterByOwnerName,
      newPage,
      perPage
    );
    navigate(newURL);
    setCurrentPage(newPage);
  };

  const handleOnDocumentChange = useCallback(
    ({
      id,
      name,
      file,
    }: {
      id: string | undefined;
      name?: string;
      file?: File;
    }) => {
      const newId = `new_${new Date().getTime()}`;
      const formData = new FormData();

      formData.append("id", id ?? newId);
      if (name) formData.append("name", name);
      if (documentModal.locationId)
        formData.append("locationId", documentModal.locationId);

      if (file) formData.append("file", file, encodeFilename(file.name));

      if (contract.id !== "new") {
        fetcher.submit(formData, {
          action: `${baseUrl}documents`,
          method: "post",
          encType: "multipart/form-data",
        });
      }
    },
    [fetcher, baseUrl, contract, documentModal.locationId]
  );

  const handleDocumentDelete = useCallback(() => {
    if (!documentToDelete) return;

    const formData = new FormData();

    formData.append("id", documentToDelete);
    formData.append("intent", "delete");

    fetcher.submit(formData, {
      action: `${baseUrl}documents`,
      method: "post",
      encType: "multipart/form-data",
    });

    setDocumentToDelete(undefined);
  }, [documentToDelete, baseUrl, fetcher]);

  const handleDocumentClick = useCallback((doc: ContractLocationFile) => {
    if (doc.new_file) {
      window.open(URL.createObjectURL(doc.new_file), "_blank");
    } else if (doc.file) {
      window.open(`/images/${doc.file.id}`, "_blank");
    }
  }, []);

  const handleAddRegion = (region: Region) => {
    if (region.region && !filterByRegion.includes(region.region)) {
      setSelectedRegions([...selectedRegions, region]);

      setFilterByRegion([...filterByRegion, region.region || ""]);
      setAutocompleteValue("");
    } else {
      setRegionErrorMessage("Filter is already selected");
    }
  };

  const handleAddOwnerName = (owner: Owner) => {
    if (owner.owner_name && !filterByOwnerName.includes(owner.owner_name)) {
      setSelectedOwners([...selectedOwners, owner]);
      setFilterByOwnerName([...filterByOwnerName, owner.owner_name || ""]);
      setAutocompleteOwnerName("");
    } else {
      setOwnerErrorMessage("Filter is already selected");
    }
  };

  const handleRemoveRegion = (option: Region) => {
    const updatedVendors = selectedRegions.filter(
      selectedRegion => selectedRegion.region !== option.region
    );
    setSelectedRegions(updatedVendors);
    setFilterByRegion(
      filterByRegion.filter(region => region !== option.region)
    );
    setRegionErrorMessage("");
  };

  const handleRemoveOwner = (option: Owner) => {
    const updatedOwners = selectedOwners.filter(
      selectedOwner => selectedOwner.owner_name !== option.owner_name
    );
    setSelectedOwners(updatedOwners);
    setFilterByOwnerName(
      filterByOwnerName.filter(owner => owner !== option.owner_name)
    );
    setOwnerErrorMessage("");
  };

  const filteredRegions = regions.filter(region =>
    region?.region.toLowerCase().includes(autocompleteValue.toLowerCase())
  );

  const filteredOwners = owners.filter(owner =>
    owner?.owner_name
      ?.toLowerCase()
      .includes(autocompleteOwnerName.toLowerCase())
  );

  const renderRegion = (option: Region) => {
    return option.region;
  };

  const renderOwner = (option: Owner) => {
    return option.owner_name;
  };

  const totalPages = Math.ceil(locationsCount / perPage);
  const pageNumbers = Array.from({ length: totalPages }, (_, i) => i + 1);
  const resultsText = `${locations.length} out of ${locationsCount} results`;

  const contractCanceled = contract.status === ContractStatus.Canceled;

  const disabledRows = useMemo(() => {
    return locations.filter(location =>
      location.contract_line_item_locations.some(
        item =>
          item.location.status === LocationStatus.Disposed ||
          every(location.contract_line_item_locations, [
            "status",
            ContractLineItemLocationStatus.Canceled,
          ])
      )
    );
  }, [locations]);

  // Permissions
  const userCanViewLocationDetails = canDoOnAccount(
    user,
    account,
    Permission.ViewLocationDetails
  );

  const userCanManageContractLocationsDocuments = canDoOnAccount(
    user,
    account,
    Permission.ManageContractLocationsDocuments
  );

  const handleViewFiles = (
    location: SerializeFrom<Location> & {
      contracted_location_files: ContractLocationFile[];
    }
  ) => {
    setOpenFilesModal(true);
    setSelectedLocation(location);
  };

  return (
    <>
      <Modal
        isOpen={openFilesModal}
        onClose={() => setOpenFilesModal(false)}
        manager={true}
        size="medium-small"
      >
        <div className="p-4">
          <h1 className="text-xl">Files for {selectedLocation?.name}</h1>
          {!isEmpty(selectedLocation?.contracted_location_files) && (
            <div
              className="space-y-4 max-h-96 overflow-y-auto overflow-x-hidden w-full pr-2"
              key={selectedLocation?.id}
            >
              {selectedLocation?.contracted_location_files.map(doc => (
                <DocumentCard
                  key={`${doc.id}-${doc.created_at}`}
                  document={{ ...doc, status: "uploaded" }}
                  onEditClick={
                    userCanManageContractLocationsDocuments
                      ? e => {
                          e.stopPropagation();
                          setOpenFilesModal(false);
                          setDocumentModal({
                            open: true,
                            document: doc,
                            locationId: selectedLocation?.id,
                          });
                        }
                      : undefined
                  }
                  onDeleteClick={
                    userCanManageContractLocationsDocuments
                      ? e => {
                          e.stopPropagation();
                          setOpenFilesModal(false);

                          setDocumentToDelete(doc.id);
                        }
                      : undefined
                  }
                  onCardClick={e => {
                    e.stopPropagation();
                    e.preventDefault();
                    handleDocumentClick(doc);
                  }}
                  isContract={true}
                />
              ))}
            </div>
          )}
          <div className="flex my-4 justify-end">
            <CanDo permission={Permission.ManageContractLocationsDocuments}>
              <CTA
                id="add-location-document-button"
                fillStyle="outline"
                variant="sky"
                className="flex items-center"
                onClick={e => {
                  e.stopPropagation();
                  e.preventDefault();
                  setOpenFilesModal(false);

                  setDocumentModal({
                    open: true,
                    document: undefined,
                    locationId: selectedLocation?.id,
                  });
                }}
              >
                <PlusIcon className="mr-2 h-5" />
                Add files
              </CTA>
            </CanDo>
          </div>
        </div>
      </Modal>
      <ConfirmDeleteModal
        isOpen={!!documentToDelete}
        onClose={() => setDocumentToDelete(undefined)}
        onConfirm={handleDocumentDelete}
        title="Delete this file"
        message="Are you sure you want to permanently delete this file forever?"
      />
      <CanDo permission={Permission.ManageContractLocationsDocuments}>
        <DocumentModal
          title={
            documentModal.document
              ? `Edit file for ${selectedLocation?.name}`
              : `Upload file for ${selectedLocation?.name}`
          }
          buttonLabel={
            documentModal.document ? "Save Document" : "Add Document"
          }
          description={
            documentModal.document
              ? ""
              : `Upload any documents or order forms for ${selectedLocation?.name} that are related to this ${contract.manager_account_vendor.vendor.name} contract. `
          }
          isOpen={documentModal.open}
          document={documentModal.document}
          onClose={() => {
            setDocumentModal({
              open: false,
              document: undefined,
            });
          }}
          modalType="location"
          onChange={handleOnDocumentChange}
        />
      </CanDo>
      <Modal
        isOpen={openFilteringModal}
        onClose={() => setOpenFilteringModal(false)}
        size="medium"
        manager={true}
      >
        <div className="p-2 lg:p-6">
          <h4 className="font-bold">Filter By</h4>
          <div className="divide divide-y divide-2 ">
            <div>
              <div className="my-4 font-semibold">Unit Count</div>
              <div className="flex justify-around">
                {unitCountFilter.map((option, index) => (
                  <CrudCheckboxField
                    key={index}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: filterByUnitCount.includes(option.value),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterByUnitCount([
                          ...filterByUnitCount,
                          option.value,
                        ]);
                      } else {
                        setFilterByUnitCount(
                          filterByUnitCount.filter(i => i !== option.value)
                        );
                      }
                    }}
                  />
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Property Class</div>
              <div className="flex justify-around">
                {propertyClassFilter.map((option, index) => (
                  <CrudCheckboxField
                    key={index}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: filterByPropertyClass.includes(
                        option.value
                      ),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterByPropertyClass([
                          ...filterByPropertyClass,
                          option.value,
                        ]);
                      } else {
                        setFilterByPropertyClass(
                          filterByPropertyClass.filter(i => i !== option.value)
                        );
                      }
                    }}
                  />
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Regions</div>
              <AutocompleteFilter
                initialValue={autocompleteValue}
                options={filteredRegions}
                onFilterChange={setAutocompleteValue}
                onAddTag={handleAddRegion}
                onRemoveTag={handleRemoveRegion}
                selectedTags={selectedRegions}
                errorMessage={regionErrorMessage}
                renderOption={renderRegion}
              />
            </div>
          </div>
          <div>
            <div className="my-4 font-semibold">Property Type</div>
            <div className="grid grid-cols-3">
              {propertyTypeFilter.map((option, index) => (
                <div key={index}>
                  <CrudCheckboxField
                    key={index}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: filterByPropertyType.includes(
                        option.value
                      ),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setFilterByPropertyType([
                          ...filterByPropertyType,
                          option.value,
                        ]);
                      } else {
                        setFilterByPropertyType(
                          filterByPropertyType.filter(i => i !== option.value)
                        );
                      }
                    }}
                  />
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="my-4 font-semibold">Owner Name</div>
            <AutocompleteFilter
              initialValue={autocompleteOwnerName}
              options={filteredOwners}
              onFilterChange={setAutocompleteOwnerName}
              onAddTag={handleAddOwnerName}
              onRemoveTag={handleRemoveOwner}
              selectedTags={selectedOwners}
              errorMessage={ownerErrorMessage}
              renderOption={renderOwner}
            />
          </div>
          <div className="flex justify-end mt-8 items-center space-x-3">
            <button
              className="text-sky-500"
              onClick={() => {
                setCurrentPage(1);
                clearFilters();
              }}
            >
              Clear filters
            </button>
            <CTA
              variant="coral-shadow"
              onClick={() => {
                handleFiltering(1);
              }}
            >
              Show results
            </CTA>
          </div>
        </div>
      </Modal>
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All contracts",
            to: `/intelligence/${account.id}/contracts`,
          },
          {
            name: contract.name,
            to: `/intelligence/${account.id}/contract/${contract.id}/details`,
          },
          {
            name: "Contracted locations",
            to: `/intelligence/${account.id}/contract/${contract.id}/contracted-locations`,
            active: true,
          },
        ]}
        title={
          <>
            Contracted locations:
            <br /> {contract.name}
          </>
        }
        description="View the line items assigned to each location included on this contract. To upload a location-specific document or order form, click on the upload icon to add your file. To add a new location to the contract, assign the location at the line item-level."
      />
      <FilterBar
        inputPlaceholder="Search locations"
        onFilter={searchQuery => {
          handleFiltering(1, searchQuery);
        }}
        filters={{
          onOpenFilteringModal: setOpenFilteringModal,
          filtersCount:
            filterByUnitCount.length +
            filterByPropertyClass.length +
            filterByRegion.length +
            filterByPropertyType.length +
            filterByOwnerName.length,
        }}
      />
      <div>
        <Table
          cols={[
            { name: "name", label: "Location Name" },
            {
              renderer: location => (
                <div className="flex items-center space-x-2">
                  <div className="whitespace-normal line-clamp-3 truncate">
                    {[location.city, location.state].filter(Boolean).join(", ")}
                  </div>
                </div>
              ),
              label: "Address",
              columnClassName: "font-normal",
            },
            {
              name: "unit_count",
              label: "Unit Count",
              columnClassName: "font-normal",
            },
            {
              renderer: location => (
                <div className="flex items-center space-x-2">
                  <div className="whitespace-normal line-clamp-3 truncate">
                    {(() => {
                      switch (location.property_type) {
                        case LocationPropertyType.ConventionalMultifamily:
                          return "Conventional Multifamily";
                        case LocationPropertyType.SelfStorage:
                          return "Self Storage";
                        case LocationPropertyType.OfficeCommercial:
                          return "Office/Commercial";
                        case LocationPropertyType.BuildToRent:
                          return "Build-to-Rent";
                        case LocationPropertyType.SingleFamily:
                          return "Single Family";
                        default:
                          return location.property_type;
                      }
                    })()}
                  </div>
                </div>
              ),
              label: "Property Type",
              columnClassName: "font-normal",
            },
            {
              renderer: (location, index) => {
                const isDisposed = disabledRows.some(
                  disposedLocation => disposedLocation.id === location.id
                );

                return (
                  <div className="flex items-center space-x-2">
                    <div className="flex flex-col gap-y-2">
                      {location.contract_line_item_locations
                        .slice(
                          0,
                          showAllContractLineItems[index] ? undefined : 3
                        )
                        .map((csl, cslIndex) => {
                          const contractLineItemLocationCanceled =
                            csl.status ===
                            ContractLineItemLocationStatus.Canceled;

                          const locationNameClasses =
                            contractLineItemLocationCanceled ||
                            contractCanceled ||
                            isDisposed
                              ? "text-gray-500"
                              : "text-sky-600 underline";
                          const nameSuffix =
                            contractLineItemLocationCanceled ||
                            contractCanceled ||
                            isDisposed
                              ? " - Canceled"
                              : "";

                          return (
                            <Link
                              key={cslIndex}
                              to={`/intelligence/${account.id}/contract/${csl.contract_line_item.contract_id}/line-item/${csl.contract_line_item_id}/summary`}
                              onClick={e => e.stopPropagation()}
                              className={`font-medium ${locationNameClasses}`}
                            >
                              {csl.contract_line_item.name}
                              {nameSuffix}
                            </Link>
                          );
                        })}
                      {location.contract_line_item_locations.length > 3 && (
                        <div>
                          {showAllContractLineItems[index] ? (
                            <button
                              className="font-light text-sky-500 flex items-center"
                              onClick={e => {
                                e.stopPropagation();
                                setShowAllContractLineItems(prevState => {
                                  const newState = [...prevState];
                                  newState[index] = false;
                                  return [...newState];
                                });
                              }}
                            >
                              Show Less
                              <ChevronUpIcon className="h-5" />
                            </button>
                          ) : (
                            <button
                              className="font-light text-sky-500 flex items-center"
                              onClick={e => {
                                e.stopPropagation();
                                setShowAllContractLineItems(prevState => {
                                  const newState = [...prevState];
                                  newState[index] = true;
                                  return [...newState];
                                });
                              }}
                            >
                              Show More
                              <ChevronDownIcon className="h-5" />
                            </button>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                );
              },
              label: "Line Items",
            },

            {
              renderer: location => {
                const fileCount = location.contracted_location_files.length;
                return (
                  <div className=" w-full">
                    <div className="lg:flex gap-x-2 space-y-2 lg:space-y-0">
                      <CanDo
                        permission={Permission.ManageContractLocationsDocuments}
                      >
                        <CTA
                          id="add-location-document-button"
                          fillStyle="outline"
                          variant="sky"
                          className={`flex items-center ${
                            fetcher.state === "submitting" &&
                            location.id === selectedLocation?.id
                              ? "animate-bounce"
                              : ""
                          }`}
                          onClick={e => {
                            e.stopPropagation();
                            e.preventDefault();
                            setOpenFilesModal(false);
                            setSelectedLocation(location);
                            setDocumentModal({
                              open: true,
                              document: undefined,
                              locationId: location.id,
                            });
                          }}
                        >
                          {selectedLocation &&
                          location.id === selectedLocation?.id ? (
                            fetcher.state === "submitting" ? (
                              <>
                                <ArrowUpOnSquareIcon className="mr-2 h-5 w-5" />
                                Adding files...
                              </>
                            ) : (
                              <>
                                <PlusIcon className="mr-2 h-5 lg:block hidden" />
                                Add files
                              </>
                            )
                          ) : (
                            <>
                              <PlusIcon className="mr-2 h-5 lg:block hidden" />
                              Add files
                            </>
                          )}{" "}
                        </CTA>
                      </CanDo>
                      {!isEmpty(location.contracted_location_files) && (
                        <CTA
                          variant="coral"
                          className="w-auto lg:w-32"
                          onClick={e => {
                            e.stopPropagation();
                            e.preventDefault();
                            handleViewFiles(location);
                          }}
                        >
                          View {fileCount} {fileCount > 1 ? "Files" : "File"}
                        </CTA>
                      )}
                    </div>
                    {/* )} */}
                  </div>
                );
              },
              label: (
                <span>
                  Uploads
                  <Tooltip
                    position="leftBottom"
                    text="Upload any location-specific documents associated with this contract, such as order forms or addendums."
                    size="small"
                  >
                    <InformationCircleIcon className="h-5 ml-1" />
                  </Tooltip>
                </span>
              ),
            },
          ]}
          data={locations}
          showAddButton={false}
          showSelectBox={false}
          onClickRow={location =>
            userCanViewLocationDetails &&
            navigate(
              `/intelligence/${account.id}/locations/${location.id}/details`
            )
          }
          disabledRows={contractCanceled ? locations : disabledRows}
        ></Table>
        <Pagination
          resultsText={resultsText}
          pageNumbers={pageNumbers}
          currentPage={currentPage}
          totalPages={totalPages}
          handleCallback={handlePageChange}
        ></Pagination>
      </div>
    </>
  );
}
