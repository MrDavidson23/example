import type { ActionFunctionArgs, MetaFunction } from "@remix-run/node";
import { redirect, json } from "@remix-run/node";
import { Form, useActionData } from "@remix-run/react";
import { z } from "zod";
import { CTA } from "~/components/cta.component";
import { ContentStripe } from "~/components/discovery/content-stripe.component";
import { CrudTextField } from "~/components/form/crud-form.component";
import { CrudTextAreaField } from "~/components/form/textarea.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { castFormFields } from "~/utils/type.utils";
import { NonEmptyString } from "~/utils/validation.utils.server";

type JsonData = {
  fields?: Record<string, string | null> | null;
  errors?: Record<string, string[] | null>;
};

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  return [
    { title: "Revyse | Vendor Intelligence" },
    {
      name: "description",
      content:
        "Revyse Vendor Intelligence helps you track your SaaS contracts, manage renewals, and discover new software.",
    },
  ];
};

export async function action({ request }: ActionFunctionArgs) {
  const ConnectForm = z.object({
    first_name: NonEmptyString,
    last_name: NonEmptyString,
    email: NonEmptyString.email(),
    company: NonEmptyString,
    message: NonEmptyString,
    honeypot: z.string().max(0),
  });

  const form = await request.formData();
  const { customerSupportService } = await WebDIContainer();

  const fields = {
    first_name: form.get("first_name"),
    last_name: form.get("last_name"),
    email: form.get("email"),
    company: form.get("company"),
    message: form.get("message"),
    honeypot: form.get("honeypot"), // Help us fight spam!
  };
  const validation = ConnectForm.safeParse(fields);

  if (validation.success) {
    await customerSupportService.sendCSEmail(
      "New Vendor Intelligence Request",
      JSON.stringify(validation.data)
    );
    throw redirect("/connect-success");
  }

  return json<JsonData>(
    {
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    { status: 400 }
  );
}

export async function loader() {
  return json({});
}

export default function VendorIntelligenceLanding() {
  const actionData = useActionData<typeof action>();
  return (
    <>
      <div className="bg-sky-500 flex justify-center md:py-12 py-12 px-6 bg-center bg-contain bg-no-repeat hero-stripe relative">
        <div className="max-w-3xl text-white text-center">
          <h1 className="font-bold">Revyse Vendor Intelligence</h1>
          <p className="my-6 text-lg text-white md:px-24">
            Vendor Intelligence helps you track vendors and spend, manage
            contract renewals, and discover new software.
          </p>
          <img
            src="/assets/cloud-1.png"
            className="absolute bottom-0 md:right-16 right-28 xl:mr-32 h-24 w-auto hidden md:block"
            alt="cloud"
            height="206"
            width="414"
          />
          <img
            src="/assets/cloud-2.png"
            className="absolute -bottom-4 md:right-2 xl:mr-36 h-16 w-auto hidden md:block"
            alt="cloud"
            height="70"
            width="169"
          />
        </div>
      </div>
      <ContentStripe
        color="white"
        tag="SAVE ON SOFTWARE SPEND"
        heading="Get a unified view of all your vendors, contracts, and spend"
        imageUrl="/assets/buy-manage-3.png"
        layout="left"
        imageWidth="2000"
        imageHeight="1500"
      >
        <p>
          Revyse Vendor Intelligence gives you visibility into spend across the
          enterprise, by resident lifecycle stage, department, region, and
          ownership group - even down to the location level. Know exactly when
          to start preparing for re-negotiation or canceling a contract before
          auto-renewals lock you in.
        </p>
      </ContentStripe>
      <ContentStripe
        color="blue"
        tag="DE-RISK YOUR TECH STACK"
        heading="Streamline your vendor ecosystem and control costs"
        imageUrl="/assets/mobile-graphic-tilted.png"
        layout="right"
        imageWidth="400"
        imageHeight="300"
      >
        <p>
          With Revyse Vendor Intelligence, you can identify product overlap and
          redundancies, eliminate shadow spend, and track cybersecurity risk and
          incident reports in one system.
        </p>
      </ContentStripe>

      <div className={`flex justify-center md:py-16 py-8 bg-sky-50`}>
        <div className="max-w-2xl flex-grow md:px-8 px-4 flex flex-col items-center relative">
          <h2 className="text-3xl font-bold mb-8 text-center">
            Interested in learning more?
          </h2>
          <Form method="post" className="w-full">
            <div className="grid grid-cols-2 gap-4 w-full">
              <div>
                <CrudTextField
                  field={{
                    name: "first_name",
                    label: "First Name *",
                    type: "text",
                    errors: actionData
                      ? actionData.errors?.first_name ?? []
                      : [],
                    defaultValue: actionData?.fields?.first_name ?? "",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    name: "last_name",
                    label: "Last Name *",
                    type: "text",
                    errors: actionData
                      ? actionData.errors?.last_name ?? []
                      : [],
                    defaultValue: actionData?.fields?.last_name ?? "",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    name: "email",
                    label: "Email *",
                    type: "text",
                    errors: actionData ? actionData.errors?.email ?? [] : [],
                    defaultValue: actionData?.fields?.email ?? "",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    name: "company",
                    label: "Company *",
                    type: "text",
                    errors: actionData ? actionData.errors?.company ?? [] : [],
                    defaultValue: actionData?.fields?.company ?? "",
                  }}
                />
              </div>
              <div className="col-span-2">
                <CrudTextAreaField
                  field={{
                    name: "message",
                    label: "Message *",
                    type: "textarea",
                    errors: actionData ? actionData.errors?.message ?? [] : [],
                    defaultValue: actionData?.fields?.message ?? "",
                    rows: 4,
                  }}
                />
              </div>
              <div
                style={{ position: "absolute", left: "-5000px" }}
                aria-hidden="true"
              >
                <input
                  type="text"
                  name="honeypot"
                  tabIndex={-1}
                  defaultValue=""
                />
              </div>
              <CTA
                id="submit-intelligence-form"
                className="col-span-2"
                fillStyle="outline"
                type="submit"
              >
                Submit
              </CTA>
            </div>
          </Form>
        </div>
      </div>
    </>
  );
}
