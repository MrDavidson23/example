import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { redirect, json } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { isNil } from "lodash";
import { CTA } from "~/components/cta.component";
import { EnvelopeOpenIcon } from "@heroicons/react/24/outline";

export const meta: MetaFunction = () => [
  { title: "Revyse | Email Verification Complete" },
  {
    name: "description",
    content: "Email Verification Complete",
  },
];

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const token = params.token;
  if (isNil(token)) {
    return redirect("/login");
  }
  const { authService } = await WebDIContainer();
  const user = await authService.verifyEmailVerification(token);

  return json({ user });
};

export default function EmailVerificationRoute() {
  return (
    <div className="flex justify-center">
      <div className="max-w-3xl bg-white text-center rounded-3xl border border-gray-100 p-12 mt-6">
        <EnvelopeOpenIcon className="h-12 inline mb-6" />
        <h1 className="text-3xl">You did it! Nice work.</h1>
        <p className="my-4">
          Thanks for verifying your email address with Revyse.
        </p>
        <p className="my-4">
          Now, go take a spin around marketplace, where buying and selling
          products and services is both transparent <i>and</i> rewarding.
        </p>
        <p className="mt-12">
          <CTA id="browse-categories-button" to={`/categories`}>
            Browse All Categories
          </CTA>
        </p>
      </div>
    </div>
  );
}
