import { ArrowRightIcon } from "@heroicons/react/24/outline";
import { Role } from "@prisma/client";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Link, useLoaderData, useNavigate } from "@remix-run/react";
import { isNil } from "lodash";
import { CrudListPage } from "~/components/crud-list-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assert } from "~/utils/assert.utils.server";
import { getUser } from "~/utils/session.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const user = await getUser(request);
  assert(!isNil(user), "User must be logged in to see vendor dashboard");

  const { productSubscriptionService } = await WebDIContainer();
  const subscriptions =
    await productSubscriptionService.getSubscriptionsForUser(user);

  // Check if the user is an OWNER for any of the subscriptions
  const isOwner = subscriptions.some(sub => {
    const userRoles = sub.user_roles;
    return userRoles.some(
      role => role.role === Role.OWNER && role.user_id === user.id
    );
  });

  return json({
    subscriptions,
    isOwner,
  });
}

export default function VendorProductsRoute() {
  const { subscriptions, isOwner } = useLoaderData<typeof loader>();
  const navigate = useNavigate();

  return (
    <CrudListPage
      crumbs={[
        {
          name: "Dashboard",
          to: "/vendor",
        },
        {
          name: "Products",
          to: "/vendor/products",
          active: true,
        },
      ]}
      cols={[
        {
          name: "product.title",
          renderer: sub => (
            <Link
              onClick={e => e.stopPropagation()}
              to={`/vendor/products/${sub.product_id}`}
              className="text-sky-600"
            >
              {sub.product.title}
            </Link>
          ),
          label: "Product Name",
        },
        {
          name: "stripe_price.product.name",
          label: "Manage Subscription",
          renderer: sub =>
            // If the user is not the owner, render the text as plain text instead of a link
            isOwner ? (
              <Link
                onClick={e => e.stopPropagation()}
                to={`/stripe_portal/${sub.id}`}
                className="flex items-center space-x-1"
              >
                <div>{sub.stripe_price.product.name}</div>
                <ArrowRightIcon className="h-3 w-3" />
              </Link>
            ) : (
              <span>{sub.stripe_price.product.name}</span>
            ),
        },
        { name: "product.created_at", label: "Created", type: "date" },
        { name: "product.approved_at", label: "Approved", type: "date" },
      ]}
      data={subscriptions}
      title="Product Listings"
      subtitle=""
      onClickRow={sub => navigate(`/vendor/products/${sub.product_id}`)}
    />
  );
}
