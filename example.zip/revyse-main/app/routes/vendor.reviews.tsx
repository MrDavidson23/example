import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { CrudListPage } from "~/components/crud-list-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assertAuthenticatedOrRedirect } from "~/utils/auth.utils.server";

export async function loader({ request }: LoaderFunctionArgs) {
  const { reviewService, productSubscriptionService } = await WebDIContainer();
  const user = await assertAuthenticatedOrRedirect(request);
  const subscriptions =
    await productSubscriptionService.getSubscriptionsForUser(user);
  const reviews = await reviewService.getReviewsByProductIds(
    subscriptions.map(s => s.product_id)
  );
  return json({
    reviews,
  });
}

export default function AdminUsersRoute() {
  const { reviews: users } = useLoaderData<typeof loader>();

  return (
    <CrudListPage
      crumbs={[
        {
          name: "Dashboard",
          to: "/vendor",
        },
        {
          name: "Reviews",
          to: "/vendor/reviews",
          active: true,
        },
      ]}
      cols={[
        {
          label: "Product Listing",
          renderer: review => review.product.title,
        },
        { name: "created_at", label: "Submitted", type: "date" },
        {
          label: "Author",
          renderer: review => {
            const ab = review.user;
            return `${ab.first_name} ${ab.last_name}`;
          },
        },
        {
          label: "Responded",
          renderer: review => {
            const ab = review.responded_by;
            return ab ? `${ab.first_name} ${ab.last_name}` : "No Response";
          },
        },
      ]}
      showAddButton={false}
      data={users}
      title="Reviews"
      subtitle=""
    />
  );
}
