import { useLoaderData } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { Empty } from "~/components/empty.component";
import { Permission } from "~/utils/intelligence-permission.utils";
import { isEmpty } from "lodash";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { DepartmentCard } from "~/components/intelligence/reports/department-card.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewSpendByDepartment],
    }
  );

  const { managerAccountService } = await WebDIContainer();

  const counts = await managerAccountService.getCountsByDepartment(
    user,
    account
  );
  const spend = await managerAccountService.getSpend(user, account, {
    byDepartment: true,
  });

  return json({
    spendByDepartment: spend.byDepartment,
    contractLineItemsByDepartment: counts.contractLineItems,
    contractsByDepartment: counts.contracts,
    vendorsByDepartment: counts.vendors,
    account,
  });
}

export default function SpendByDepartment() {
  const {
    spendByDepartment,
    contractLineItemsByDepartment,
    contractsByDepartment,
    vendorsByDepartment,
    account,
  } = useLoaderData<typeof loader>();
  return (
    <div className="flex flex-col gap-4">
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "Reports",
            to: `/intelligence/${account.id}`,
            active: false,
          },
          {
            name: "Contract Insights by Department",
            to: `/intelligence/${account.id}/spend-by-department`,
            active: true,
          },
        ]}
        title="Contract Insights by Department"
        description="Get a clear breakdown of your contracted spend by department, and visualize how vendors and contracts are managed across your organization."
      />
      {Object.values(spendByDepartment).length == 0 && <Empty />}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-4">
        {Object.entries(spendByDepartment)
          .sort(([a], [b]) => {
            if (isEmpty(a)) return 1;
            if (isEmpty(b)) return -1;
            return a.localeCompare(b);
          })
          .map(([name, spend]) => (
            <DepartmentCard
              key={name}
              name={name}
              accountId={account.id}
              annualSpend={spend}
              contractCount={contractsByDepartment[name] ?? 0}
              description="High-level department metrics based on assigned line items."
              contractLineItemsCount={contractLineItemsByDepartment[name] ?? 0}
              vendorsCount={vendorsByDepartment[name] ?? 0}
              account={account}
            ></DepartmentCard>
          ))}
      </div>
    </div>
  );
}
