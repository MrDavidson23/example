import {
  CheckBadgeIcon,
  CheckIcon,
  TrashIcon,
} from "@heroicons/react/20/solid";
import { EnvelopeIcon, XMarkIcon } from "@heroicons/react/24/outline";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import {
  Form,
  useActionData,
  useFetcher,
  useLoaderData,
  useResolvedPath,
} from "@remix-run/react";
import { isNil } from "lodash";
import { useMemo, useState } from "react";
import {
  jsonWithError,
  jsonWithSuccess,
  redirectWithSuccess,
} from "remix-toast";
import { z } from "zod";
import { Button, DangerButton } from "~/components/button.component";
import { CrudFormPage } from "~/components/form/crud-form-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assertAuthorized } from "~/utils/assert.utils.server";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import { getUser } from "~/utils/session.server";
import { castFormFields } from "~/utils/type.utils";
import { tv } from "tailwind-variants";

const tvButton = tv({
  base: "",
  variants: {
    status: {
      loading: "cursor-not-allowed animate-bounce",
      success: "bg-green-600 hover:bg-green-700",
      error: "bg-red-500 hover:bg-red-600",
    },
  },
});

type JsonData = {
  fields?: Record<string, string | null> | null;
  success?: boolean;
  errors?: Record<string, string[] | null>;
};

const UserForm = z.object({
  first_name: z.string().min(1, "First Name is required"),
  last_name: z.string().min(1, "Last Name is required"),
  email: z.string(),
});

async function updateAction({ id, form }: { id: string; form: FormData }) {
  const fields = {
    first_name: form.get("first_name"),
    last_name: form.get("last_name"),
    email: form.get("email"),
  };
  const validation = UserForm.safeParse(fields);

  if (validation.success) {
    const { userService } = await WebDIContainer();

    await userService.updateUser({
      id,
      data: validation.data,
    });

    return redirectWithSuccess("/admin/users", "User updated successfully");
  }

  const errors = issuesByKey(validation.error.issues);

  return jsonWithError<JsonData>(
    { fields: castFormFields(fields), errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
}

async function deleteAction({ id }: { id: string }) {
  const {
    reviewService,
    productSubscriptionService,
    managerAccountService,
    userService,
  } = await WebDIContainer();

  const existsProductReview = await reviewService.getProductReview({
    userId: id,
  });
  if (existsProductReview) {
    return jsonWithError(
      { success: false, fields: null, errors: null },
      "Cannot delete user, please remove the associated product reviews first",
      { status: 400 }
    );
  }

  const userSubscriptions =
    await productSubscriptionService.getSubscriptionsForUser({
      id,
    });

  if (userSubscriptions.length > 0) {
    return jsonWithError(
      { success: false, fields: null, errors: null },
      "Cannot delete user that has been assigned a role on a product listing",
      { status: 400 }
    );
  }

  const existsManagerAccounts =
    await managerAccountService.getManagerAccountsForUser({
      id,
      user_roles: [],
    });
  if (existsManagerAccounts.length > 0) {
    return jsonWithError(
      { success: false, fields: null, errors: null },
      "Cannot delete user that has been assigned a role on an Intelligence account",
      { status: 400 }
    );
  }

  await userService.deleteUser({ id });
  return redirectWithSuccess("/admin/users", "User deleted successfully");
}

async function resendVerificationEmailAction({ id }: { id: string }) {
  const { authService } = await WebDIContainer();
  await authService.generateEmailVerificationEmail(id, false);

  return jsonWithSuccess<JsonData>(
    {
      fields: castFormFields({
        intent: "resend-verification-email",
      }),
      errors: {},
      success: true,
    },
    "Verification email sent successfully",
    { status: 200 }
  );
}

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));
  const form = await request.formData();
  const intent = form.get("intent");
  if (intent === "delete") {
    return deleteAction({ id: params.id! });
  }
  if (intent === "resend-verification-email" && params.id) {
    return resendVerificationEmailAction({ id: params.id });
  }

  return updateAction({ id: params.id!, form });
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { userService } = await WebDIContainer();
  const user = await userService.getUserById({ id: params.id! });
  const verifiedEmailToken = user?.email_verification_tokens.find(
    evt => evt.email === user.email
  );
  if (isNil(user)) {
    throw new Response(undefined, { status: 404 });
  }
  return json({ user, verifiedEmailToken });
}

export default function AdminUserIdRoute() {
  const actionData = useActionData<typeof action>();
  const { user, verifiedEmailToken } = useLoaderData<typeof loader>();
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const fetcher = useFetcher<typeof action>();
  const { pathname: actionPath } = useResolvedPath("confirm-buyer");
  const isBuyer = user.user_roles.find(
    ur => ur.role === "BUYER" && ur.type === "GLOBAL"
  );

  const resendVerificationEmailActionState = useMemo(() => {
    if (
      fetcher.formData?.get("intent") === "resend-verification-email" ||
      (fetcher.data?.fields?.intent === "resend-verification-email" &&
        fetcher.state === "idle")
    ) {
      return fetcher.state == "idle"
        ? fetcher.data?.success
          ? "success"
          : "error"
        : "loading";
    }
    return undefined;
  }, [fetcher]);

  return (
    <>
      <CrudFormPage
        crumbs={[
          { name: "Users", to: "/admin/users", active: false },
          {
            name: `${user.first_name} ${user.last_name}`,
            to: `/admin/users/${user.id}`,
            active: true,
          },
        ]}
        config={{
          sections: [
            {
              title: "Update User",
              subtitle: "",
              fields: [
                {
                  name: "first_name",
                  label: "First Name",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.first_name ?? undefined
                    : user.first_name ?? undefined,
                  errors: actionData?.errors?.first_name ?? [],
                },
                {
                  name: "last_name",
                  label: "Last Name",
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.last_name ?? undefined
                    : user.last_name ?? undefined,
                  errors: actionData?.errors?.last_name ?? [],
                },
                {
                  name: "email",
                  label: (
                    <div className="flex">
                      Email{" "}
                      {verifiedEmailToken ? (
                        <CheckBadgeIcon className="h-6 text-green-600" />
                      ) : (
                        <span className="ml-1 text-gray-400">
                          (Not Verified)
                        </span>
                      )}
                    </div>
                  ),
                  type: "text",
                  defaultValue: actionData
                    ? actionData.fields?.email ?? undefined
                    : user.email,
                  errors: actionData?.errors?.email ?? [],
                },
              ],
            },
          ],
        }}
        buttonsSlot={
          <div className="flex justify-between gap-2">
            {confirmDeleteOpen ? (
              <Form
                className="flex justify-between  items-center"
                method="post"
              >
                Are you sure you want to delete this user?
                <input type="hidden" name="intent" value="delete" />
                <Button
                  onClick={() => setConfirmDeleteOpen(false)}
                  className="ml-2"
                >
                  Cancel
                </Button>
                <DangerButton type="submit" className="ml-2">
                  Yep!
                </DangerButton>
              </Form>
            ) : (
              <>
                {user.id !== "new" && !verifiedEmailToken && (
                  <Button
                    className={tvButton({
                      status: resendVerificationEmailActionState,
                    })}
                    disabled={resendVerificationEmailActionState === "loading"}
                    onClick={() => {
                      fetcher.submit(
                        {
                          intent: "resend-verification-email",
                        },
                        {
                          method: "post",
                          encType: "multipart/form-data",
                        }
                      );
                      return false;
                    }}
                  >
                    {resendVerificationEmailActionState === "success" ? (
                      <>
                        <CheckIcon className="h-6 mr-2" /> Verification Email
                        Sent
                      </>
                    ) : resendVerificationEmailActionState === "error" ? (
                      <>
                        <XMarkIcon className="h-6 mr-2" /> Error sending email
                      </>
                    ) : resendVerificationEmailActionState === "loading" ? (
                      <>
                        <EnvelopeIcon className="h-6 mr-2" /> Resending Email...
                      </>
                    ) : (
                      <>
                        <EnvelopeIcon className="h-6 mr-2" /> Resend
                        Verification Email
                      </>
                    )}
                  </Button>
                )}
                {user.id !== "new" && (
                  <Button
                    onClick={() => {
                      fetcher.submit(
                        {
                          confirmed: isBuyer ? "false" : "true",
                        },
                        {
                          method: "post",
                          action: actionPath,
                          encType: "multipart/form-data",
                        }
                      );
                      return false;
                    }}
                  >
                    <CheckIcon className="h-6 mr-2" />{" "}
                    {isBuyer ? "Revoke" : "Confirm"} Buyer
                  </Button>
                )}
                <DangerButton
                  onClick={() => {
                    setConfirmDeleteOpen(!confirmDeleteOpen);
                  }}
                >
                  <div className="flex">
                    <TrashIcon className="h-5 mr-1" />
                    Delete
                  </div>
                </DangerButton>
              </>
            )}
          </div>
        }
      />
    </>
  );
}
