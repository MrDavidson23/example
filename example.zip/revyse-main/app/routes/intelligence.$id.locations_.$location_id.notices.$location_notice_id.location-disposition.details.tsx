import { json } from "@remix-run/node";
import { Link, useFetcher, useLoaderData } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { CTA } from "~/components/cta.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Permission } from "~/utils/intelligence-permission.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import {
  CrudDateField,
  CrudSelectField,
  FormSection,
} from "~/components/form/crud-form.component";
import {
  DEFAULT_FORM_ERROR_MESSAGE,
  LocationPropertyTypeLabels,
} from "~/utils/constants.utils";
import { CrudTextAreaField } from "~/components/form/textarea.component";
import { Button } from "~/components/button.component";
import { ArrowLeftIcon } from "@heroicons/react/20/solid";
import { useMemo, useRef } from "react";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import {
  jsonWithError,
  redirectWithSuccess,
  redirectWithWarning,
} from "remix-toast";
import { LocationNoticeStatus } from "@prisma/client";
dayjs.extend(utc);

const NewDispositionNoticeForm = z.object({
  disposition_date: z.date(),
  termination_date: z.date(),
  termination_instructions: z.string().nullish(),
  task_owner_id: z.string(),
  original_location_notice_id: z.string().uuid().nullish(),
  intent: z.string().nullish(),
});

export async function action({ request, params }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocationNotices],
      locationId: params.location_id,
    }
  );

  const locationId = params.location_id!;
  const locationNoticeId = params.location_notice_id!;

  const { locationNoticeService } = await WebDIContainer();

  const form = await request.formData();

  const fields = {
    disposition_date: dayjs
      .utc(form.get("disposition_date") as string)
      .toDate(),
    termination_date: dayjs
      .utc(form.get("termination_date") as string)
      .toDate(),
    termination_instructions: form.get("termination_instructions") as string,
    task_owner_id: form.get("task_owner_id") as string,
    original_location_notice_id: form.get(
      "original_location_notice_id"
    ) as string,
    intent: form.get("intent") as string,
  };

  const validation = NewDispositionNoticeForm.safeParse(fields);

  if (!validation.success) {
    return jsonWithError(
      { errors: issuesByKey(validation.error.issues), fields },
      DEFAULT_FORM_ERROR_MESSAGE
    );
  }

  const manager_account_role_id = user.manager_account_roles.find(
    role => role.manager_account_id === account.id
  )!.id;

  const { intent, ...data } = validation.data;

  const saveProgress = intent === "save-progress";

  let locationNoticeDisposition = null;
  if (locationNoticeId === "new") {
    locationNoticeDisposition =
      await locationNoticeService.createLocationNoticeDisposition(
        locationId,
        {
          ...data,
          manager_account_role_id,
        },
        saveProgress
      );
  } else {
    locationNoticeDisposition =
      await locationNoticeService.updateLocationNoticeDisposition(
        locationNoticeId,
        {
          ...data,
          manager_account_role_id,
        },
        saveProgress
      );
  }

  if (saveProgress) {
    return redirectWithSuccess(
      `/intelligence/${account.id}/locations/${locationId}/notices`,
      "Disposition notice saved successfully"
    );
  }

  // If the location notice is an updated one, we need to redirect to the email template page
  if (locationNoticeDisposition.original_location_notice_id) {
    return redirectWithSuccess(
      `/intelligence/${account.id}/locations/${locationId}/notices/${locationNoticeDisposition.id}/location-disposition/emailtemplate`,
      "Disposition notice updated successfully"
    );
  }

  return redirectWithSuccess(
    `/intelligence/${account.id}/locations/${locationId}/notices/${locationNoticeDisposition.id}/location-disposition/recipients`,
    "Disposition notice saved successfully"
  );
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocationNotices],
      locationId: params.location_id,
    }
  );

  const { managerAccountService, locationService, locationNoticeService } =
    await WebDIContainer();
  const managerAccountId = account.id;

  const location = await locationService.getLocation(params.location_id!);

  if (!location) {
    throw new Response("Location not found", { status: 404 });
  }

  const locationNoticeId = params.location_notice_id!;

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);

  const locationNotice =
    locationNoticeId !== "new"
      ? await locationNoticeService.getLocationNoticeDisposition(
          locationNoticeId,
          location.id,
          user,
          account
        )
      : null;

  if (locationNoticeId !== "new" && !locationNotice) {
    throw new Response("Location notice not found", { status: 404 });
  }

  if (locationNotice?.status === LocationNoticeStatus.Sent) {
    return redirectWithWarning(
      `/intelligence/${account.id}/locations/${location.id}/notices/${locationNoticeId}/location-disposition`,
      "Location notice has already been sent"
    );
  }

  // If the location notice is a new one and original_location_notice_id is set, we are creating an updated notice
  const originalLocationNoticeId =
    locationNoticeId === "new"
      ? search.get("original_location_notice_id")
      : locationNotice?.original_location_notice_id;

  const originalLocationNotice = originalLocationNoticeId
    ? await locationNoticeService.getLocationNoticeDisposition(
        originalLocationNoticeId,
        location.id,
        user,
        account
      )
    : null;

  const taskOwnerOptions = await managerAccountService.getTaskOwnerOptions(
    managerAccountId
  );

  return json({
    user,
    account,
    location,
    taskOwnerOptions,
    userManagerAccountRole: user?.manager_account_roles.find(
      role => role.manager_account_id === managerAccountId
    ),
    locationNotice,
    originalLocationNotice,
  });
}

export default function LocationDispositionNoticeDetails() {
  const {
    account,
    location,
    taskOwnerOptions,
    userManagerAccountRole,
    locationNotice,
    originalLocationNotice,
  } = useLoaderData<typeof loader>();

  const fetcher = useFetcher<typeof action>();
  const formRef = useRef<HTMLFormElement>(null);

  const submit = (intent?: string) => {
    const formData = formRef.current && new FormData(formRef.current);

    if (intent) {
      formData?.append("intent", intent);
    }

    if (originalLocationNotice) {
      formData?.append(
        "original_location_notice_id",
        originalLocationNotice.id
      );
    }

    fetcher.submit(formData, {
      method: "POST",
    });
  };

  const formErrors = useMemo(() => fetcher.data?.errors ?? {}, [fetcher.data]);

  const defaultDispositionDate =
    locationNotice?.disposition_date ??
    originalLocationNotice?.disposition_date ??
    undefined;
  const defaultTerminationDate =
    locationNotice?.termination_date ??
    originalLocationNotice?.termination_date ??
    undefined;

  return (
    <>
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
          },
          {
            name: "Notices",
            to: `/intelligence/${account.id}/locations/${location.id}/notices`,
          },
          {
            name: originalLocationNotice
              ? "Updated disposition details"
              : "Configure disposition details",
            to: `/intelligence/${account.id}/locations/${location.id}/notices/${
              locationNotice?.id ?? "new"
            }/disposition`,
            active: true,
          },
        ]}
        title={
          <>
            {originalLocationNotice
              ? "Updated disposition notice details"
              : "Disposition notice details"}
            :
            <br /> {location.name}
          </>
        }
        description={
          originalLocationNotice
            ? `Update the important details and dates for ${location.name}’s upcoming disposition. Next, you’ll confirm your changes in the disposition notice email template.`
            : `Configure the important details and dates for ${location.name}’s upcoming disposition. Next, you’ll choose your recipients.`
        }
        buttonsSlot={<CTA onClick={() => submit()}>Continue</CTA>}
      />
      <fetcher.Form ref={formRef}>
        <main className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min gap-y-40">
          <FormSection
            title="Disposition Notice Information"
            subtitle={
              <div className="text-gray-400">
                Location Name: {location.name}
                <br />
                City, State: {location.city}, {location.state}
                <br />
                Unit Count: {location.unit_count}
                <br />
                Property Type:{" "}
                {LocationPropertyTypeLabels[location.property_type]}
                <br />
                Owner: {location.owner_name ?? "--"}
              </div>
            }
            spacing="compact"
            border={false}
          >
            <CrudDateField
              field={{
                name: "disposition_date",
                label: "Expected Disposition Date",
                tooltipText:
                  "The expected disposition date is typically the scheduled transaction date for this location.",
                type: "text",
                defaultValue: defaultDispositionDate
                  ? dayjs.utc(defaultDispositionDate).format("YYYY-MM-DD")
                  : undefined,
                errors: formErrors.disposition_date ?? [],
              }}
              minDate={dayjs().subtract(1, "year").format("YYYY-MM-DD")}
            />
            <CrudDateField
              field={{
                name: "termination_date",
                label: "Requested Service Termination Date",
                tooltipText:
                  "The requested service termination date is the date that you are requesting that all services be canceled for this location.",
                type: "text",
                defaultValue: defaultTerminationDate
                  ? dayjs.utc(defaultTerminationDate).format("YYYY-MM-DD")
                  : undefined,
                errors: formErrors.termination_date ?? [],
              }}
              minDate={dayjs().format("YYYY-MM-DD")}
            />
            <CrudTextAreaField
              field={{
                name: "termination_instructions",
                label: "Instructions for Final Invoices",
                type: "textarea",
                placeholder:
                  "Enter any specific instructions on where you’d like final invoices to be sent, whom they should be sent to, and/or timelines for submitting final invoices.",
                defaultValue:
                  locationNotice?.termination_instructions ??
                  originalLocationNotice?.termination_instructions ??
                  "",
                errors: formErrors.termination_instructions ?? [],
                showOptional: true,
                rows: 4,
              }}
            />
            <CrudSelectField
              field={{
                name: "task_owner_id",
                label: "Assign Disposition Notice Task Owner",
                tooltipText:
                  "This is who the vendor should reach out to with questions about the upcoming disposition. We’ll also send an auto-reminder to this user to set the location’s status to disposed in Revyse, once the transaction is complete.",
                type: "select",
                defaultValue:
                  locationNotice?.task_owner_id ??
                  originalLocationNotice?.task_owner_id ??
                  userManagerAccountRole?.id,
                errors: formErrors.task_owner_id ?? [],
                options: taskOwnerOptions,
              }}
            />
          </FormSection>
        </main>
        <footer className="flex justify-between items-center mt-4">
          <div>
            <Link
              to={`/intelligence/${account.id}/locations/${location.id}/notices`}
              className="text-sky-500 flex items-center text-sm"
            >
              <ArrowLeftIcon className="h-5 mr-2" /> Back to all notices
            </Link>
          </div>
          <div className="flex gap-x-2">
            {!originalLocationNotice && (
              <Button
                color="transparent"
                onClick={() => submit("save-progress")}
              >
                Save Progress
              </Button>
            )}
            <CTA onClick={() => submit()}>Continue</CTA>
          </div>
        </footer>
      </fetcher.Form>
    </>
  );
}
