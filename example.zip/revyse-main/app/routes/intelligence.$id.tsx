import {
  BuildingOffice2Icon,
  ComputerDesktopIcon,
  DocumentTextIcon,
  UserCircleIcon,
  BuildingStorefrontIcon,
  QuestionMarkCircleIcon,
  ArrowLeftOnRectangleIcon,
  PresentationChartLineIcon,
} from "@heroicons/react/24/outline";
import type {
  SerializeFrom,
  LoaderFunctionArgs,
  MetaFunction,
  ActionFunctionArgs,
} from "@remix-run/node";
import { json, redirect } from "@remix-run/node";
import {
  Outlet,
  useFetcher,
  useLoaderData,
  useLocation,
} from "@remix-run/react";
import { first, isNil } from "lodash";
import { useState } from "react";
import { TasksIcon } from "~/components/icons/tasks.icon";
import { SideNav } from "~/components/intelligence/side-nav.component";
import { TopBar } from "~/components/intelligence/top-bar.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import {
  FeatureFlag,
  FeatureFlagService,
} from "~/services/feature-flag.service.server";
import { assertAuthorized } from "~/utils/assert.utils.server";
import {
  Permission,
  canDoSomeOnAccount,
  type PermissionType,
} from "~/utils/intelligence-permission.utils";
import {
  setActiveEntityId,
  verifyIntelligenceRequest,
  type IntelligenceOutletContext,
} from "~/utils/intelligence.utils.server";
import { equalPathnames } from "~/utils/string.utils";

export const meta: MetaFunction = () => [
  { title: "Revyse | Manager Dashboard" },
  {
    name: "description",
    content: "Revyse Manager Tool",
  },
];

export type IntelligenceModuleLink = {
  to?: string;
  isActive?: boolean;
  label: string;
  iconComponent: JSX.ElementType | keyof typeof icons;
  permissions?: PermissionType[];
  withQueryParams?: Record<string, string>;
  id?: string;
  featureFlag?: (typeof FeatureFlag)[keyof typeof FeatureFlag];
  badgeCount?: number;
  options?: {
    to: string;
    label: string;
    permissions?: PermissionType[];
    iconComponent?:
      | JSX.ElementType
      | keyof typeof icons
      | SerializeFrom<JSX.ElementType | keyof typeof icons>;
    id?: string;
  }[];
};

export const action = async ({ request, params }: ActionFunctionArgs) => {
  await verifyIntelligenceRequest({ request, params }, {});

  const form = await request.formData();
  const intent = form.get("intent");

  if (intent === "set-active-location") {
    const id = form.get("id") as string;
    const isLocation = form.get("isLocation") as "false" | "true";

    return await setActiveEntityId(id, isLocation === "true", request);
  }
  return json({});
};

const icons = {
  ComputerDesktopIcon,
  BuildingOffice2Icon,
  DocumentTextIcon,
  UserCircleIcon,
  BuildingStorefrontIcon,
  TasksIcon,
  QuestionMarkCircleIcon,
  ArrowLeftOnRectangleIcon,
  PresentationChartLineIcon,
};

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const { user, account, activeLocationId } = await verifyIntelligenceRequest(
    { request, params },
    {}
  );
  const {
    managerAccountService,
    managerAccountTaskService,
    featureFlagService,
  } = await WebDIContainer();

  const accountOptions = await managerAccountService.getManagerAccountsForUser(
    user
  );

  const pendingTasksCount =
    await managerAccountTaskService.getPendingTasksCount(
      account?.id || "",
      user.id
    );

  const links: IntelligenceModuleLink[] = [
    {
      to: `/intelligence/${account?.id}`,
      id: "dashboard-link",
      label: "Dashboard",
      iconComponent: "ComputerDesktopIcon",
      permissions: [Permission.ViewDashboard],
    },
    {
      to: `/intelligence/${account?.id}/tasks`,
      id: "tasks-link",
      label: "Tasks",
      iconComponent: "TasksIcon",
      permissions: [Permission.ViewVendorsTable],
      badgeCount: pendingTasksCount > 0 ? pendingTasksCount : undefined,
    },
    {
      to: `/intelligence/${account?.id}/vendors`,
      id: "vendors-link",
      label: "Vendors",
      iconComponent: "BuildingStorefrontIcon",
      permissions: [Permission.ViewVendorsTable],
    },
    {
      to: `/intelligence/${account?.id}/contracts`,
      id: "contracts-link",
      label: "Contracts",
      iconComponent: "DocumentTextIcon",
      permissions: [Permission.ViewContractsTable],
    },
    {
      to: `/intelligence/${account?.id}/locations`,
      id: "locations-link",
      label: "Locations",
      iconComponent: "BuildingOffice2Icon",
      permissions: [Permission.ViewLocationsTable],
    },
    {
      id: "reports-link",
      label: "Reports",
      iconComponent: "PresentationChartLineIcon",
      options: [
        {
          id: "spend-by-resident-phase-link",
          to: `/intelligence/${account?.id}/spend-by-resident-phase`,
          label: "Contract Insights: Resident",
          permissions: [Permission.ViewSpendByResidentPhase],
        },
        {
          id: "spend-by-enterprise-category-link",
          to: `/intelligence/${account?.id}/spend-by-enterprise-category`,
          label: "Contract Insights: Enterprise",
          permissions: [Permission.ViewSpendByEnterpriseCategory],
        },
        {
          id: "spend-by-department-link",
          to: `/intelligence/${account?.id}/spend-by-department`,
          label: "Contract Insights: Department",
          permissions: [Permission.ViewSpendByDepartment],
        },
        {
          id: "spendByLocationLink",
          to: `/intelligence/${account?.id}/spend-by-location`,
          label: "Contract Insights: Location",
          permissions: [Permission.ViewSpendByDepartment],
        },
      ],
      permissions: [Permission.ViewReports],
    },
    {
      to: `/intelligence/${account?.id}/account`,
      id: "account-link",
      label: "Account",
      iconComponent: "UserCircleIcon",
      permissions: [
        Permission.ViewAccountInformation,
        Permission.ViewAccountUsers,
      ],
    },
  ];

  if (!account) {
    throw redirect("/vendor-intelligence", 303);
  }

  const url = new URL(request.url);

  const authorizedLinks = links.filter(link => {
    const featureFlagEnabled =
      !link.featureFlag || new FeatureFlagService().isEnabled(link.featureFlag);

    const hasPermission =
      !link.permissions || canDoSomeOnAccount(user, account, link.permissions);

    return featureFlagEnabled && hasPermission;
  });

  const getActiveLink = (links: IntelligenceModuleLink[]) => {
    const activeLink = links.find(link =>
      link.to ? equalPathnames(link.to, url.pathname) : false
    );
    if (activeLink) return activeLink;
    return links.find(link =>
      link.options?.some(option => equalPathnames(option.to, url.pathname))
    );
  };

  // If the current url is any of the links
  if (getActiveLink(links)) {
    // If no permissions to any tab, throw 403
    assertAuthorized(
      authorizedLinks.length > 0,
      "You are not authorized to go into this Intelligence Account"
    );

    // If no permissions to the requested tab, navigate to the first available
    if (!getActiveLink(authorizedLinks)) {
      throw redirect(first(authorizedLinks)?.to || "/", 303);
    }
  }

  const locationOptions = await managerAccountService.getLocationsForUser(
    account.id,
    user
  );

  const allUsersLinks: IntelligenceModuleLink[] = [
    {
      to: "mailto:support@revyse.com",
      id: "help-link",
      label: "Need some help?",
      iconComponent: "QuestionMarkCircleIcon",
    },
    {
      to: "/logout",
      id: "logout-link",
      label: "Log out",
      iconComponent: "ArrowLeftOnRectangleIcon",
    },
  ];

  const showEntitiesSelector = featureFlagService.isEnabled(
    FeatureFlag.IntelligenceShowEntitiesSelector
  );

  return json({
    managerAccount: account,
    user,
    links: [...authorizedLinks, ...allUsersLinks],
    accountOptions,
    locationOptions,
    activeLocationId,
    showEntitiesSelector,
  });
};

export default function Manager() {
  const {
    user,
    managerAccount,
    links,
    accountOptions,
    locationOptions,
    activeLocationId,
    showEntitiesSelector,
  } = useLoaderData<typeof loader>();
  const basePath = `/intelligence/${managerAccount.id}/`;
  const fetcher = useFetcher();

  const location = useLocation();
  const linksWithIconsAndQueryParams = links.map(link => {
    let isActive = false;

    switch (link.id) {
      case "dashboard-link":
        isActive = !isNil(link.to) && location.pathname === link.to;
        break;
      case "reports-link":
        isActive = location.pathname.includes("spend-by");
        break;
      case "help-link":
      case "logout-link":
        isActive = false;
        break;
      case "contracts-link":
        isActive =
          location.pathname.slice(basePath.length).startsWith("contracts") ||
          location.pathname.slice(basePath.length).startsWith("contract");
        break;
      case "locations-link":
        isActive = location.pathname
          .slice(basePath.length)
          .startsWith("locations");
        break;
      case "vendors-link":
        isActive = location.pathname
          .slice(basePath.length)
          .startsWith("vendors");
        break;
      default:
        isActive =
          !isNil(link.to) &&
          location.pathname
            .slice(location.pathname.indexOf(basePath) + basePath.length)
            .includes(
              link.to.slice(link.to.indexOf(basePath) + basePath.length)
            );
        break;
    }

    return {
      ...link,
      isActive,
      iconComponent: icons[link.iconComponent as keyof typeof icons],
      to: link.withQueryParams
        ? `${link.to}?${new URLSearchParams(link.withQueryParams).toString()}`
        : link.to,
    };
  });
  const [isCollapsed, setIsCollapsed] = useState(false);

  const toggleCollapse = () => {
    setIsCollapsed(!isCollapsed);
  };

  if (!managerAccount) return <div>Manager account not found</div>;

  const outletContext: IntelligenceOutletContext = {
    toggleCollapse,
    isCollapsed,
    user,
    managerAccount,
  };

  const setActiveEntityId = (id: string, isLocation: boolean) => {
    fetcher.submit(
      {
        intent: "set-active-location",
        id,
        isLocation,
      },
      {
        method: "post",
      }
    );
  };

  return (
    <>
      <TopBar
        links={linksWithIconsAndQueryParams}
        user={user}
        activeManagerAccount={managerAccount}
        managerAccountOptions={accountOptions}
        locationOptions={locationOptions}
        activeEntityId={activeLocationId ?? managerAccount.id}
        setActiveEntityId={setActiveEntityId}
        showEntitiesSelector={showEntitiesSelector}
      ></TopBar>
      <SideNav
        links={linksWithIconsAndQueryParams}
        isCollapsed={isCollapsed}
        toggleCollapse={toggleCollapse}
      />
      <div
        className={`${
          isCollapsed ? "w-full pl-36 p-12" : "p-3 w-full lg:w-10/12 lg:p-12"
        } float-right  mt-20 overflow-y-auto overflow-x-hidden`}
      >
        <Outlet context={outletContext} />
      </div>
    </>
  );
}
