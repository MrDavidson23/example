import { Form, Link, useLoaderData } from "@remix-run/react";
import type {
  ActionFunctionArgs,
  LoaderFunctionArgs,
  SerializeFrom,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { isEmpty, map } from "lodash";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { Permission } from "~/utils/intelligence-permission.utils";
import { FormSection } from "~/components/form/crud-form.component";
import { CTA } from "~/components/cta.component";
import { ArrowLeftIcon } from "@heroicons/react/20/solid";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import React, { useState } from "react";
import { jsonWithError, redirectWithSuccess } from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { castFormFields } from "~/utils/type.utils";
import {
  type IntelligenceVendorIntegration,
  IntelligenceVendorIntegrationStatus,
} from "@prisma/client";
import { ConfirmDeleteModal } from "~/components/modals/confirm-delete-modal.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import VendorIntegrationsManager from "~/components/admin/vendor/vendor-integrations-manager.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const IntegrationMapForm = z.object({
  intelligence_vendor_integrations: z.array(
    z.object({
      id: z.string(),
      integrated_vendor_id: z.string().nullable(),
      integrated_product_id: z.string().nullable(),
      notes: z.string().optional().or(z.string().nullable()),
      status: z.nativeEnum(IntelligenceVendorIntegrationStatus),
    })
  ),
});

async function updateIntegrationMap({
  form,
  id,
}: {
  form: FormData;
  id: string;
}) {
  const { managerAccountVendorService } = await WebDIContainer();

  const fields = {
    intelligence_vendor_integrations: form
      .getAll("intelligence_vendor_integrations_id[]")
      .map((id, i) => ({
        id,
        integrated_vendor_id: !isEmpty(
          form.getAll(
            "intelligence_vendor_integrations_integrated_vendor_id[]"
          )[i]
        )
          ? form.getAll(
              "intelligence_vendor_integrations_integrated_vendor_id[]"
            )[i]
          : null,
        integrated_product_id: !isEmpty(
          form.getAll(
            "intelligence_vendor_integrations_integrated_product_id[]"
          )[i]
        )
          ? form.getAll(
              "intelligence_vendor_integrations_integrated_product_id[]"
            )[i]
          : null,

        status: form.getAll(
          "intelligence_vendor_integrations_integration_status[]"
        )[i] as IntelligenceVendorIntegrationStatus,
        notes: form.getAll(
          "intelligence_vendor_integrations_integration_notes[]"
        )[i],
      })),
  };

  const validation = IntegrationMapForm.safeParse(fields);

  if (validation.success) {
    const accountVendor =
      await managerAccountVendorService.updateManagerAccountVendorIntegrationMap(
        id,
        validation.data
      );

    return redirectWithSuccess(
      `/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}/integration-map`,
      "Vendor integration map updated successfully"
    );
  }

  return jsonWithError(
    {
      success: false,
      accountVendor: null,
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE
  );
}

export async function action({ params, request }: ActionFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );

  const id = params.vendor_id as string;

  const form = await request.formData();

  return updateIntegrationMap({ form, id });
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );

  const id = params.vendor_id!;
  const { managerAccountVendorService } = await WebDIContainer();

  const accountVendor =
    await managerAccountVendorService.getManagerAccountVendorWithIntegrations(
      id
    );

  const vendorIntegrationVendorOptions =
    await managerAccountVendorService.getVendorIntegrationVendorOptions({
      id: {
        not: {
          in: [
            accountVendor.vendor.id,
            ...(map(
              accountVendor.intelligence_vendor_integrations,
              "integrated_vendor_id"
            ).filter(Boolean) as string[]),
          ],
        },
      },
    });

  const vendorIntegrationProductOptions =
    await managerAccountVendorService.getVendorIntegrationProductOptions({
      id: {
        not: {
          in: [
            ...(map(
              accountVendor.intelligence_vendor_integrations,
              "integrated_product_id"
            ).filter(Boolean) as string[]),
          ],
        },
      },
    });

  const integrationOptionGroups = [
    {
      group: "Vendors",
      options: vendorIntegrationVendorOptions.map(vendor => ({
        label: vendor.vendor.name,
        value: vendor.id,
        logo_file_id: vendor.vendor.logo_file_id,
      })),
    },
    {
      group: "Products",
      options: vendorIntegrationProductOptions.map(product => ({
        label: product.title,
        value: product.id,
        logo_file_id: product.logo_file_id,
      })),
    },
  ];

  return json({
    accountVendor,
    integrationOptionGroups,
  });
}

export default function VendorIntegrationMapRoute() {
  const { accountVendor, integrationOptionGroups } =
    useLoaderData<typeof loader>();

  const [openConfirmDelete, setOpenConfirmDelete] = useState(false);

  const [vendorIntegrations, setVendorIntegrations] = useState<
    Partial<SerializeFrom<IntelligenceVendorIntegration>>[]
  >(accountVendor.intelligence_vendor_integrations);
  return (
    <>
      <ConfirmDeleteModal
        isOpen={openConfirmDelete}
        onClose={() => setOpenConfirmDelete(false)}
        onConfirm={() => setOpenConfirmDelete(false)}
        title="Remove this vendor and its data"
        message="Are you sure you want to permanently remove this vendor from your account?"
        submitOnConfirm={true}
      />
      <div className="space-y-8 pb-12">
        <IntelligenceScreenHeader
          crumbs={[
            {
              name: "Vendors",
              to: `/intelligence/${accountVendor.manager_account_id}/vendors`,
            },
            {
              name: accountVendor.vendor.name,
              to: `/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}`,
            },
            {
              name: "Integration map",
              to: `/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}/integration-map`,
              active: true,
            },
          ]}
          title="Integration map"
          description="Keep a record of the system integrations in place for each vendor in your ecosystem, including integration status, date of implementation, or current version in use."
        />
        <div className="space-y-8 pb-12">
          <Form className="space-y-8" method="post">
            <div
              className={`bg-white shadow-lg shadow-gray-200/50 p-3 md:p-8 rounded-lg h-min`}
            >
              <div>
                <FormSection
                  title={`${accountVendor.vendor.name} Integration Map`}
                  subtitle={`Add a new integration record for ${accountVendor.vendor.name}, or edit an existing record.`}
                  spacing="compact"
                >
                  <div className="col-span-full">
                    <VendorIntegrationsManager
                      vendorIntegrations={vendorIntegrations}
                      onChange={setVendorIntegrations}
                      options={integrationOptionGroups}
                      intelligence={true}
                    />
                    {vendorIntegrations.map(vendorIntegration => (
                      <React.Fragment key={vendorIntegration.id}>
                        <input
                          type="hidden"
                          name="intelligence_vendor_integrations_id[]"
                          value={vendorIntegration.id}
                        />
                        <input
                          type="hidden"
                          name="intelligence_vendor_integrations_integrated_vendor_id[]"
                          value={
                            vendorIntegration.integrated_vendor_id ?? undefined
                          }
                        />
                        <input
                          type="hidden"
                          name="intelligence_vendor_integrations_integrated_product_id[]"
                          value={
                            vendorIntegration.integrated_product_id ?? undefined
                          }
                        />
                        <input
                          type="hidden"
                          name="intelligence_vendor_integrations_integration_status[]"
                          value={vendorIntegration.status ?? undefined}
                        />
                        <input
                          type="hidden"
                          name="intelligence_vendor_integrations_integration_notes[]"
                          value={vendorIntegration.notes ?? ""}
                        />
                      </React.Fragment>
                    ))}
                  </div>
                </FormSection>
              </div>
            </div>
            <div className="mt-10 flex justify-around md:justify-between flex-wrap lg:flex-nowrap gap-x-3">
              <Link
                to={`/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}`}
                className="text-sky-600 flex items-center"
              >
                <ArrowLeftIcon className="h-5 mr-2" /> Back to vendor overview
              </Link>
              <div className="flex gap-x-3 items-center">
                <CTA type="submit" id="save-button">
                  Save Changes
                </CTA>
              </div>
            </div>
          </Form>
        </div>
      </div>
    </>
  );
}
