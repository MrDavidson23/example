import { CheckCircleIcon } from "@heroicons/react/20/solid";
import { ProductState } from "@prisma/client";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { isNil } from "lodash";
import { CTA } from "~/components/cta.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assert } from "~/utils/assert.utils.server";

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const session_id = search.get("session_id");
  assert(!isNil(session_id), "No session_id provided");
  const { stripeService } = await WebDIContainer();

  try {
    const product = await stripeService.getProductFromSession(session_id);
    return json({ product });
  } catch (error) {
    if (error instanceof Error) assert(false, error.message);
    assert(false, "Unknown Error");
  }
};

export default function CheckoutSuccessRoute() {
  const { product } = useLoaderData<typeof loader>();
  return (
    <div className="flex justify-center">
      <div className="max-w-3xl bg-white text-center rounded-3xl border border-gray-100 p-12 mt-6">
        <CheckCircleIcon className="h-12 inline mb-6" />

        {product &&
        product.approved_at &&
        product.state === ProductState.discovery ? ( // User claimed an existing listing
          <>
            <h1 className="text-3xl">Your listing has been claimed!</h1>
            <p className="my-4">
              Ready to meet your next best customer on Revyse? Get started by
              updating your new product listing. Flaunt your best features and
              claim your spot on buyers’ shortlists.
            </p>
            <p>
              <CTA to={`/vendor/products/${product.id}`}>Manage Listing</CTA>
            </p>
          </>
        ) : (
          // User created a new listing
          <>
            <h1 className="text-3xl">You're on your way!</h1>
            <p className="my-4">
              The Revyse team is fired up and ready to review your fresh product
              listing. Once it gets the green light, we’ll send you an email
              notification to mark its official platform debut.{" "}
            </p>
            <p>
              While you wait, get familiar with the Revyse Vendor Portal and
              take a spin around your dashboard.
            </p>
            <p className="mt-6">
              <CTA to={`/vendor`}>Vendor Portal</CTA>
            </p>
          </>
        )}
      </div>
    </div>
  );
}
