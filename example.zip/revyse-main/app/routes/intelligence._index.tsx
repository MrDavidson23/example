import type { LoaderFunctionArgs } from "@remix-run/node";
import { redirect } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { getUser } from "~/utils/session.server";
import { assertAuthorizedOrRedirect } from "~/utils/assert.utils.server";

export async function loader({ params, request }: LoaderFunctionArgs) {
  const user = await getUser(request);
  assertAuthorizedOrRedirect(user);

  const { db } = await WebDIContainer();

  const account = await db.managerAccount.findFirst({
    where: {
      manager_account_roles: {
        some: {
          user_id: user.id,
          deleted_at: null,
        },
      },
    },
  });

  if (!account) {
    throw redirect("/vendor-intelligence", 303);
  }

  return redirect(`/intelligence/${account?.id}`);
}
