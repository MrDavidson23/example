import type { ActionFunctionArgs } from "@remix-run/node";
import { isNil } from "lodash";
import { z } from "zod";
import { WizardTaskContractRenewalStep } from "~/components/intelligence/tasks/contract-renewal-wizard.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import { assert, assertAuthorized } from "~/utils/assert.utils.server";
import { MB } from "~/utils/constants.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import {
  Permission,
  canDoOnAccountOrThrow,
} from "~/utils/intelligence-permission.utils";
import { getUser } from "~/utils/session.server";

export enum WizardTaskContractRenewalStatus {
  Renewed = "renewed",
  Pending = "pending",
  Canceled = "canceled",
}

export const zWizardTaskContractRenewalStepsForm = {
  [WizardTaskContractRenewalStep.RenewedTermsAndPricing]: z.object({
    current_term_end_date: z
      .string()
      .regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date")
      .transform(v => new Date(v)),
    contract_file: z
      .string()
      .nullable()
      .or(z.instanceof(File).transform(v => v.name)),
    contract_file_name: z.string().nullable(),
  }),
  [WizardTaskContractRenewalStep.RenewedNewReminder]: z.object({
    renewal_reminder_lead_time_months: z
      .string()
      .transform(v => Number(v))
      .nullish(),
    renewal_reminder_date: z
      .literal("")
      .transform(v => null)
      .nullish()
      .or(
        z
          .string()
          .regex(/^\d{4}-\d{2}-\d{2}$/, "Invalid date")
          .transform(v => new Date(v))
      ),
    task_owner_id: z.string().nullable(),
  }),
  [WizardTaskContractRenewalStep.PendingDueDate]: z.object({
    due_date: z
      .string()
      .min(1, "Due date is required")
      .regex(/^\d{4}-\d{2}-\d{2}$/, "Due date is required")
      .transform(v => new Date(v)),
  }),
};

const zWizardTaskContractRenewalForm = z
  .object({
    task_id: z.string(),
    manager_account_id: z.string(),
  })
  .and(
    z.discriminatedUnion("status", [
      // Renewed
      z
        .object({
          status: z.literal(WizardTaskContractRenewalStatus.Renewed),
        })
        .merge(
          zWizardTaskContractRenewalStepsForm[
            WizardTaskContractRenewalStep.RenewedTermsAndPricing
          ]
        )
        .merge(
          zWizardTaskContractRenewalStepsForm[
            WizardTaskContractRenewalStep.RenewedNewReminder
          ]
        ),
      // Pending
      z
        .object({
          status: z.literal(WizardTaskContractRenewalStatus.Pending),
        })
        .merge(
          zWizardTaskContractRenewalStepsForm[
            WizardTaskContractRenewalStep.PendingDueDate
          ]
        ),
      // Canceled
      z.object({
        status: z.literal(WizardTaskContractRenewalStatus.Canceled),
      }),
    ])
  );

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));

  const { intent } = params;

  let form: FormData;

  if (intent === "submit") {
    form = await parseMultiPartFormDataS3Upload(request, [
      { field: "contract_file", byteLimit: 50 * MB },
    ]);
  } else if (intent === "check-errors") {
    form = await request.formData();
  } else {
    throw new Error("Invalid intent");
  }

  const fields = Object.fromEntries(form.entries());

  const { managerAccountService, db, managerAccountTaskService } =
    await WebDIContainer();
  const managerAccountId = fields.manager_account_id as string;

  const account = await managerAccountService.getManagerAccount(
    managerAccountId
  );
  assert(!isNil(account), "Manager account not found");
  canDoOnAccountOrThrow(user, account, Permission.ManageTasks);

  if (intent === "check-errors") {
    return await handleCheckErrors({ fields });
  }

  const validation = zWizardTaskContractRenewalForm.safeParse(fields);
  if (!validation.success) {
    return {
      success: false,
      errors: issuesByKey(validation.error.errors),
      fields,
    };
  }

  const { task_id, status } = validation.data;
  const task = await db.taskContractRenewal.findUniqueOrThrow({
    where: { id: task_id },
  });

  if (status === WizardTaskContractRenewalStatus.Renewed) {
    await managerAccountTaskService.handleWizardContractRenewalTaskRenewed({
      task,
      fields: validation.data,
    });
  } else if (status === WizardTaskContractRenewalStatus.Pending) {
    await managerAccountTaskService.handleWizardContractRenewalTaskPending({
      fields: validation.data,
      task,
    });
  } else if (status === WizardTaskContractRenewalStatus.Canceled) {
    await managerAccountTaskService.handleWizardContractRenewalTaskCanceled({
      task,
    });
  }

  return {
    success: true,
    fields,
  };
};

async function handleCheckErrors({
  fields,
}: {
  fields: Record<string, FormDataEntryValue>;
}) {
  const validation =
    zWizardTaskContractRenewalStepsForm[
      fields.step_id as keyof typeof zWizardTaskContractRenewalStepsForm
    ].safeParse(fields);

  if (!validation.success) {
    return {
      success: false,
      errors: issuesByKey(validation.error.errors),
      fields,
    };
  }
  return {
    success: true,
    fields,
  };
}
