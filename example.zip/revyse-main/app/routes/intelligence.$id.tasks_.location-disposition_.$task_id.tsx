import { json } from "@remix-run/node";
import {
  Form,
  useActionData,
  useFetcher,
  useLoaderData,
  useNavigation,
  useOutletContext,
} from "@remix-run/react";
import type {
  ActionFunctionArgs,
  LinksFunction,
  LoaderFunctionArgs,
} from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { isEmpty } from "lodash";
import { CTA } from "~/components/cta.component";
import StatusChip from "~/components/status-chip.component";
import { useEffect, useState } from "react";
import { Button, DangerButton } from "~/components/button.component";
import { RevysePencilIcon } from "~/components/revyse-pencil-icon.component";
import {
  ArrowLeftIcon,
  ChatBubbleOvalLeftEllipsisIcon,
  ExclamationCircleIcon,
} from "@heroicons/react/24/outline";
import { Tooltip } from "~/components/tooltip.component";
import { ManagerAccountRoleType } from "@prisma/client";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { Modal } from "~/components/modal.component";
import {
  CrudDateField,
  CrudSelectField,
} from "~/components/form/crud-form.component";
import { z } from "zod";
import { jsonWithSuccess, redirectWithSuccess } from "remix-toast";
import { issuesByKey } from "~/utils/form.utils.server";
import { castFormFields } from "~/utils/type.utils";
import { ChatBubble } from "~/components/intelligence/tasks/chat-bubble.component";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
// import { LocationDispositionWizard } from "~/components/intelligence/tasks/location-disposition-wizard.component";
import stylesheetQuill from "react-quill/dist/quill.snow.css";
import stylesheetEmoji from "quill-emoji/dist/quill-emoji.css";
import stylesheetQuillMention from "quill-mention/dist/quill.mention.css";
import chatStyle from "../styles/chat.css";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { CanDo } from "~/components/intelligence/can-do.component";

dayjs.extend(utc);

const MB = 1024 * 1024;
const MAX_BYTE_LIMIT = 60 * MB;

type JsonData = {
  fields?: Record<string, string | null> | null;
  success?: boolean;
  errors?: Record<string, string[] | null>;
};

export const links: LinksFunction = () => [
  { rel: "stylesheet", href: chatStyle },
  { rel: "stylesheet", href: stylesheetQuill },
  { rel: "stylesheet", href: stylesheetEmoji },
  { rel: "stylesheet", href: stylesheetQuillMention },
];

const LocationDataForm = z.object({
  due_date: z.date().nullable(),
  task_owner_id: z
    .string()
    .uuid()
    .or(z.literal("null").transform(v => (v === "null" ? null : v))),
});

async function archiveTask({
  id,
  accountId,
}: {
  id: string;
  accountId: string;
}) {
  const { managerAccountTaskService } = await WebDIContainer();

  await managerAccountTaskService.archiveLocationDispositionTask(id);

  return redirectWithSuccess(
    `/intelligence/${accountId}/tasks/location-disposition/${id}`,
    "Task archived successfully"
  );
}

async function activateTask({
  id,
  accountId,
}: {
  id: string;
  accountId: string;
}) {
  const { managerAccountTaskService } = await WebDIContainer();

  await managerAccountTaskService.activateLocationDispositionTask(id);

  return redirectWithSuccess(
    `/intelligence/${accountId}/tasks/location-disposition/${id}`,
    "Task reactivated successfully"
  );
}

async function updateAction({ id, form }: { id: string; form: FormData }) {
  const dueDate = form.get("due_date") as string;

  const fields = {
    due_date: dueDate ? new Date(dueDate) : null,
    task_owner_id: form.get("task_owner_id"),
  };

  const validation = LocationDataForm.safeParse(fields);

  if (validation.success) {
    const { managerAccountTaskService } = await WebDIContainer();

    await managerAccountTaskService.updateLocationDispositionTask(
      id,
      validation.data.due_date,
      validation.data.task_owner_id
    );
    return jsonWithSuccess<JsonData>(
      {
        success: true,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      },
      "Task updated successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);

  return json<JsonData>(
    { success: false, fields: castFormFields(fields), errors },
    { status: 400 }
  );
}

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageTasks],
    }
  );
  const managerAccountId = account.id;

  const task_id = params.task_id!;

  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "message_files.file", byteLimit: MAX_BYTE_LIMIT },
  ]);
  const intent = form.get("intent");

  if (task_id && intent === "cancelTask") {
    return archiveTask({ id: task_id, accountId: managerAccountId });
  }
  if (task_id && intent === "activateTask") {
    return activateTask({ id: task_id, accountId: managerAccountId });
  }
  return updateAction({ id: task_id, form });
};

async function getManagerAccountRolesWithPermissions(
  managerAccountId: string,
  permissionLevels: ManagerAccountRoleType[]
) {
  const { managerAccountRoleService } = await WebDIContainer();
  const taskOwners = await managerAccountRoleService.getManagerAccountRoles(
    managerAccountId,
    {
      permissionLevel: permissionLevels,
      page: 1,
      perPage: 500,
      status: [],
    }
  );
  return taskOwners;
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewTaskDetails],
    }
  );
  const managerAccountId = account.id;

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const chatParam = Boolean(search.get("chat"));

  const { managerAccountRoleService, managerAccountTaskService } =
    await WebDIContainer();

  const task = await managerAccountTaskService.loadLocationDispositionTask(
    params.task_id
  );

  if (!task) {
    throw new Response("Not found", { status: 404 });
  }

  const sender = await managerAccountRoleService.getManagerAccountRole({
    manager_account_id: managerAccountId,
    user_id: user.id,
  });
  if (!sender) {
    throw new Response("Not manager account role found", { status: 404 });
  }

  const messages = await managerAccountTaskService.getGroupChatMessages(
    task.group_chat_id
  );

  const taskOwnerOptions = (
    await getManagerAccountRolesWithPermissions(managerAccountId, [
      ManagerAccountRoleType.Owner,
      ManagerAccountRoleType.Editor,
    ])
  ).map(role => ({
    label: `${role.user.first_name} ${role.user.last_name} - ${role.user.email}`,
    value: role.id,
  }));

  const userMentionOptions = (
    await getManagerAccountRolesWithPermissions(managerAccountId, [
      ManagerAccountRoleType.Owner,
      ManagerAccountRoleType.Editor,
      ManagerAccountRoleType.Viewer,
    ])
  ).map(role => ({
    value: `${role.user.first_name} ${role.user.last_name}`,
    id: role.id,
  }));

  return json({
    user,
    account,
    task,
    messages,
    taskOwnerOptions,
    userMentionOptions,
    senderId: sender.id,
    chatParam,
  });
}

export default function IntelligenceLocationDispositionTaskInfo() {
  const {
    task,
    account,
    user,
    messages,
    taskOwnerOptions,
    userMentionOptions,
    senderId,
    chatParam,
  } = useLoaderData<typeof loader>();

  const actionData = useActionData<typeof action>();
  const fetcher = useFetcher<typeof action>();

  const navigation = useNavigation();

  const baseUrl = `/intelligence/${account.id}/tasks/location-disposition/${task.id}`;
  const actionUrl = `/chat-action/${senderId}`;

  const [editTask, setEditTask] = useState(false);
  const [openChat, setOpenChat] = useState(false);

  const [
    confirmCancelLocationDisposition,
    setConfirmCancelLocationDisposition,
  ] = useState(false);

  // const [wizardOpen, setWizardOpen] = useState(false);

  const { toggleCollapse, isCollapsed } = useOutletContext() as {
    toggleCollapse: () => void;
    isCollapsed: boolean;
  };

  // Permissions
  const userCanManageTasks = canDoOnAccount(
    user,
    account,
    Permission.ManageTasks
  );

  const userCanSendTaskChatMessage = canDoOnAccount(
    user,
    account,
    Permission.SendTaskChatMessage
  );

  const logoSrc = "/assets/location-default-logo.png";

  const handleSendMessage = async (formData: FormData) => {
    formData.append("intent", "sendMessage");
    formData.append("group_chat_id", `${task.group_chat_id}`);

    await fetcher.submit(formData, {
      action: actionUrl,
      method: "post",
      encType: "multipart/form-data",
    });
  };

  useEffect(() => {
    if (navigation.state == "idle") {
      setEditTask(false);
    }
  }, [navigation.state]);

  useEffect(() => {
    if (chatParam) {
      if (!isCollapsed) toggleCollapse();
      setOpenChat(true);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // const renderPrimaryCTA = () => {
  //   if (
  //     userCanViewLocationDetails &&
  //     (task.completion_status === TaskCompletionStatus.Completed ||
  //       task.completion_status === TaskCompletionStatus.Canceled)
  //   ) {
  //     return (
  //       <CTA
  //         id="view-contract-details"
  //         variant="sky-shadow"
  //         to={`/intelligence/${account.id}/contract/${task.contract_id}/details`}
  //       >
  //         View Contract Details
  //       </CTA>
  //     );
  //   } else if (userCanManageTasks) {
  //     return (
  //       <CTA
  //         id="complete-task"
  //         type="submit"
  //         variant="coral-shadow"
  //         onClick={() => setWizardOpen(true)}
  //       >
  //         Complete Task
  //       </CTA>
  //     );
  //   }

  //   return <></>;
  // };

  const renderCancelReactivateButton = () => {
    const isCanceled = task.completion_status === "Canceled";

    const buttonText = isCanceled ? "Activate Task" : "Cancel Task";
    const confirmVerbiage = isCanceled
      ? "Are you sure you want to reactivate this task?"
      : "Are you sure you want to archive this task and mark it as “Canceled”?";
    const intent = isCanceled ? "activateTask" : "cancelTask";

    if (confirmCancelLocationDisposition) {
      return (
        <div className="flex justify-between items-center">
          {confirmVerbiage}
          <Button
            color="transparent"
            onClick={() => setConfirmCancelLocationDisposition(false)}
            className="ml-2 rounded-full"
          >
            <ArrowLeftIcon className="h-5 mr-2" /> No, go back
          </Button>
          <DangerButton
            type="submit"
            className="ml-2 rounded-full bg-coral"
            onClick={() => {
              fetcher.submit(
                {
                  intent,
                },
                {
                  action: baseUrl,
                  method: "post",
                  encType: "multipart/form-data",
                }
              );
              setEditTask(false);
              setConfirmCancelLocationDisposition(false);
            }}
          >
            Yep!
          </DangerButton>
        </div>
      );
    }
    return (
      <div>
        <CTA
          type="button"
          fillStyle="outline"
          onClick={() => {
            setConfirmCancelLocationDisposition(
              !confirmCancelLocationDisposition
            );
          }}
        >
          {buttonText}
        </CTA>
      </div>
    );
  };

  return (
    <>
      <div
        className={`${
          openChat ? "grid grid-cols-3 gap-x-8" : "space-y-8 pb-12"
        }`}
      >
        {userCanManageTasks && (
          <Modal
            isOpen={editTask}
            onClose={() => setEditTask(false)}
            size="medium"
            manager={true}
          >
            <div className="p-3 space-y-5">
              <h1 className="text-2xl">Edit task details</h1>
              <div>
                Update the details of this {task.location.name} location
                disposition task.
              </div>
              <Form method="post" encType="multipart/form-data">
                <CrudDateField
                  field={{
                    name: "due_date",
                    label: "Task Due Date",
                    type: "text",
                    errors: [],
                    defaultValue:
                      dayjs.utc(task.due_date as string).format("YYYY-MM-DD") ??
                      dayjs
                        .utc(actionData?.fields?.due_date as string)
                        .format("YYYY-MM-DD") ??
                      dayjs.utc().format("YYYY-MM-DD"),
                  }}
                  minDate={new Date().toISOString().split("T")[0]}
                />
                <CrudSelectField
                  field={{
                    name: "task_owner_id",
                    type: "select",
                    options: taskOwnerOptions,
                    errors: actionData?.errors?.task_owner_id ?? [],
                    label: "Task Owner",
                    defaultValue: task.task_owner_id
                      ? task.task_owner_id
                      : actionData?.fields?.task_owner_id ?? undefined,
                  }}
                />
                <div className="space-x-4 flex justify-end py-3">
                  {renderCancelReactivateButton()}
                  {!confirmCancelLocationDisposition && (
                    <div>
                      <CTA type="submit">
                        <>
                          {navigation.state === "submitting"
                            ? "Submitting..."
                            : "Save Task"}
                        </>
                      </CTA>
                    </div>
                  )}
                </div>
              </Form>
            </div>
          </Modal>
        )}
        <div className={`${openChat ? "col-span-2" : "flex flex-col"}`}>
          <IntelligenceScreenHeader
            crumbs={[
              {
                name: "Tasks",
                to: `/intelligence/${account.id}/tasks`,
                active: false,
              },
              {
                name: `Update location status: ${task.location.name}` || "",
                to: `/intelligence/${account.id}/tasks/location-disposition/${task.id}`,
                active: true,
              },
            ]}
            chip={
              <StatusChip
                model="TaskCompletionStatus"
                status={task.completion_status}
                label={task.completion_status}
                suffix="Task"
              />
            }
            title={
              <>
                Update location status:
                <br />
                {task.location.name}
              </>
            }
            description="View the details of your upcoming disposition, including due date, task owner, and status. After the location has transitioned, click “Complete Task” to set the location status to ‘disposed’ and mark this task as done."
            buttonsSlot={
              <div className="flex lg:justify-end lg:my-0 my-4 justify-center items-center space-x-3">
                {/* {renderPrimaryCTA()} */}
                <Button
                  className="col-span-1 flex justify-end"
                  color="transparent"
                  onClick={e => {
                    e.preventDefault();
                    e.stopPropagation();
                    setOpenChat(!openChat);
                    toggleCollapse();
                  }}
                >
                  <div className="relative">
                    <ChatBubbleOvalLeftEllipsisIcon className="w-8 h-8" />
                    {!isEmpty(messages) && (
                      <div className="absolute top-0.5 right-0.5 w-2.5 h-2.5 rounded-full bg-yellow-400 border border-white"></div>
                    )}
                  </div>
                </Button>
              </div>
            }
          />
          <section className="mt-5 overflow-hidden bg-white rounded-md shadow">
            <div className="grid grid-cols-1 p-7 lg:grid-cols-2 space-y-5 lg:space-y-0">
              <div className="grid justify-start grid-cols-1 lg:grid-cols-3 gap-x-7 items-center">
                <div className="relative flex lg:justify-center col-span-1 max-w-24 lg:max-w-[unset]">
                  <img
                    src={logoSrc}
                    alt="Vendor Logo"
                    className="w-24 lg:w-48 h-auto rounded-md aspect-square"
                    width="192"
                    height="192"
                  />
                </div>
                <div className="w-full lg:max-w-md col-span-2 space-y-4">
                  <div>
                    <h1
                      className="mt-2 lg:mt-0 text-xl xl:text-3xl font-bold"
                      id="location-name"
                    >
                      {task.location.name}
                    </h1>
                    <div className="text-lg font-light">
                      {task.location.city}, {task.location.state}
                    </div>
                  </div>
                  <div className="lg:w-3/4 gap-2">
                    <div className="grid grid-cols-2">
                      <div className="font-semibold">Unit Count</div>
                      <div className="font-light">
                        {task.location.unit_count}
                      </div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-semibold">Property Type</div>
                      <div className="font-light">
                        {task.location.property_type}
                      </div>
                    </div>
                    <div className="grid grid-cols-2">
                      <div className="font-semibold">Owner Name</div>
                      <div className="font-light">
                        {task.location.owner_name}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="relative space-y-5 border-gray-200 lg:border-l lg:mx-7 lg:pl-7 ">
                <div className="text-xl font-semibold">Task Info</div>
                <div className="grid lg:grid-cols-2 gap-x-4 gap-y-4 lg:mt-0">
                  <div className="font-semibold">
                    Start Date
                    <Tooltip
                      position="left"
                      text="The task start date is the date that you’ll begin working on this task. For location disposition tasks, the best start date is typically the date when the disposition notice has been sent to vendors."
                    >
                      <div className="flex flex-row items-center space-x-1 cursor-pointer">
                        <ExclamationCircleIcon className="ml-2 text-gray-500 h-5" />
                      </div>
                    </Tooltip>
                  </div>
                  <div>
                    {task.start_date
                      ? dayjs.utc(task.start_date).format("MMM D, YYYY")
                      : "--"}
                  </div>

                  <div className="font-semibold">
                    Due Date
                    <Tooltip
                      position="left"
                      text="The task due date is the date when all work on the task should be completed. For location disposition tasks, the best task due date is typically the day after the location has transitioned out of your portfolio."
                    >
                      <div className="flex flex-row items-center space-x-1 cursor-pointer">
                        <ExclamationCircleIcon className="ml-2 text-gray-500 h-5" />
                      </div>
                    </Tooltip>
                  </div>
                  <div>
                    {task.due_date
                      ? dayjs.utc(task.due_date).format("MMM D, YYYY")
                      : "--"}
                  </div>
                  <div className="font-semibold">
                    Task Owner
                    <Tooltip
                      position="left"
                      text="The Task Owner is the user that is responsible for completing action-items in Revyse when the location disposition date has passed."
                    >
                      <div className="flex flex-row items-center space-x-1 cursor-pointer">
                        <ExclamationCircleIcon className="ml-2 text-gray-500 h-5" />
                      </div>
                    </Tooltip>
                  </div>
                  <div>
                    {task.task_owner?.user.first_name}{" "}
                    {task.task_owner?.user.last_name}
                  </div>

                  {userCanManageTasks && (
                    <Button
                      className="absolute top-[-1rem] right-[-2rem] text-md font-medium"
                      color="transparent"
                      onClick={() => setEditTask(true)}
                    >
                      <RevysePencilIcon className="mr-2" /> Edit
                    </Button>
                  )}
                </div>
              </div>
            </div>
          </section>
          <section className="mt-5 overflow-hidden bg-white rounded-md shadow p-7">
            <div className="flex flex-col lg:flex-row justify-between items-center space-y-3 lg:space-y-0">
              <h2 className="text-lg lg:text-2xl font-semibold leading-tight">
                Disposition Notice Info
              </h2>
              <div className="flex">
                <CanDo permission={Permission.ManageTasks} locationId={task.location.id}>
                  <Button
                    color="transparent"
                    className="text-md font-medium"
                    to=""
                  >
                    <RevysePencilIcon className="mr-2" /> Edit
                  </Button>
                </CanDo>
              </div>
            </div>
            <hr className="my-5" />

            <div className="grid grid-flow-row grid-cols-1 lg:grid-cols-3 gap-5 mt-8">
              <div className="flex">
                <div>
                  <span className="font-semibold">
                    Last Disposition Notice Send Date
                  </span>
                  <Tooltip
                    position="right"
                    size="medium"
                    text="This is the date that the most recent disposition notice was sent to vendors."
                  >
                    <div className="flex flex-row items-center space-x-1 cursor-pointer">
                      <ExclamationCircleIcon className="ml-2 text-gray-500 h-5" />
                    </div>
                  </Tooltip>
                  <br />
                  <span>Lorem Ipsum</span>
                </div>
              </div>
              <div className="flex">
                <div>
                  <span className="font-semibold">
                    Expected Disposition Date
                  </span>
                  <Tooltip
                    position="left"
                    size="medium"
                    text="This is the most recent expected disposition date for this location."
                  >
                    <div className="flex flex-row items-center space-x-1 cursor-pointer">
                      <ExclamationCircleIcon className="ml-2 text-gray-500 h-5" />
                    </div>
                  </Tooltip>
                  <br />
                  <span>Lorem Ipsum</span>
                </div>
              </div>
              <div className="flex">
                <div>
                  <span className="font-semibold">
                    Service Termination Date
                  </span>
                  <Tooltip
                    position="left"
                    size="medium"
                    text="The service termination date is the most recent date that all services were requested to be canceled."
                  >
                    <div className="flex flex-row items-center space-x-1 cursor-pointer">
                      <ExclamationCircleIcon className="ml-2 text-gray-500 h-5" />
                    </div>
                  </Tooltip>
                  <br />
                  <span>Lorem Ipsum</span>
                </div>
              </div>
              <div className="flex">
                <div>
                  <span className="font-semibold">
                    Instructions for Final Invoices
                  </span>
                  <br />
                  <span>Lorem Ipsum</span>
                </div>
              </div>
            </div>
          </section>
        </div>
      </div>
      <ChatBubble
        isOpen={openChat}
        sendMessage={handleSendMessage}
        users={userMentionOptions}
        onClose={() => {
          setOpenChat(false);
          toggleCollapse();
        }}
        messages={messages}
        actionUrl={actionUrl}
        fetcher={fetcher}
        senderId={senderId}
        allowSend={userCanSendTaskChatMessage}
      ></ChatBubble>
    </>
  );
}
