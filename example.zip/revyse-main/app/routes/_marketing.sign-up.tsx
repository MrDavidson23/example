import type { ActionFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import {
  Form,
  Link,
  useActionData,
  useNavigation,
  useSearchParams,
} from "@remix-run/react";

import { badRequest } from "~/utils/request.server";
import { createUserSession } from "~/utils/session.server";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { z } from "zod";
import { NonEmptyString } from "~/utils/validation.utils.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { CrudTextField } from "~/components/form/crud-form.component";
import { Toast } from "~/components/toast.component";
import { Button } from "~/components/button.component";
import { SignUpIntent } from "@prisma/client";
import { useEffect, useRef, useState } from "react";
import { getLogger } from "~/services/logger.factory";
import { castFormFields } from "~/utils/type.utils";
import { EyeIcon, EyeSlashIcon } from "@heroicons/react/24/outline";
import { tvField } from "~/utils/global-tailwind-variants.utils";

export const meta: MetaFunction = () => [
  { title: "Revyse | Sign-Up" },
  {
    name: "description",
    content: "Sign-up for Revyse",
  },
];

const SignUpForm = z
  .object({
    first_name: NonEmptyString,
    last_name: NonEmptyString,
    title: NonEmptyString,
    company_name: NonEmptyString,
    phone: NonEmptyString,
    email: z.string().email(),
    password: z.string().min(6, "Password must be at least 6 characters long"),
    passwordConfirmation: z.string(),
    redirectTo: z.string().optional().default("/sign-up-success"),
    recaptchaToken: z.string(),
    intent: z
      .enum([SignUpIntent.BUYER, SignUpIntent.VENDOR, SignUpIntent.ORGANIC])
      .optional()
      .default(SignUpIntent.ORGANIC),
  })
  .superRefine((data, ctx) => {
    if (data.password !== data.passwordConfirmation) {
      return ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "Passwords do not match",
        path: ["passwordConfirmation"],
      });
    }
  });

export const action = async ({ request }: ActionFunctionArgs) => {
  const form = await request.formData();

  const fields = {
    first_name: form.get("first_name"),
    last_name: form.get("last_name"),
    title: form.get("title"),
    company_name: form.get("company_name"),
    phone: form.get("phone"),
    email: form.get("email"),
    password: form.get("password"),
    passwordConfirmation: form.get("passwordConfirmation"),
    redirectTo: form.get("redirectTo") ?? undefined,
    intent: form.get("intent") ?? undefined,
    recaptchaToken: form.get("g-recaptcha-response"),
  };

  const { authService, recaptchaService } = await WebDIContainer();
  const validation = SignUpForm.safeParse(fields);

  if (validation.success) {
    // Verify reCAPTCHA token
    const validRecaptcha = await recaptchaService.verifyToken(
      validation.data.recaptchaToken
    );
    if (!validRecaptcha) {
      return badRequest({
        success: false,
        errors: issuesByKey([
          {
            path: ["general"],
            message: "reCAPTCHA verification failed.",
          },
        ]),
        fields: castFormFields(fields),
      });
    }

    let invitedUser = false;
    if (validation.data.redirectTo.includes("user-invitation")) {
      invitedUser = true;
    }
    const result = await authService.register(validation.data, invitedUser);
    if (!result.ok) {
      return badRequest({
        success: false,
        fields: castFormFields(fields),
        errors: { email: [result.error] } as { [key: string]: string[] },
      });
    } else {
      // Avoid decoding the redirectTo when being related to Circle SSO
      if (validation.data.redirectTo.includes("client_id")) {
        return createUserSession(result.value.id, validation.data.redirectTo);
      }
      return createUserSession(
        result.value.id,
        decodeURI(validation.data.redirectTo)
      );
    }
  }
  const logger = getLogger("sign-up");
  logger.error("Validation error", validation.error);
  return json({
    success: false,
    errors: issuesByKey(validation.error.issues),
    fields: castFormFields(fields),
  });
};

export default function SignUpRoute() {
  const actionData = useActionData<typeof action>();
  const [searchParams] = useSearchParams();
  const recaptchaResponseRef = useRef<HTMLInputElement | null>(null);
  const navigation = useNavigation();

  const [showPassword, setShowPassword] = useState(false);

  const togglePasswordVisibility = () => {
    setShowPassword(prev => !prev);
  };

  useEffect(() => {
    const script = document.createElement("script");
    script.src =
      "https://www.google.com/recaptcha/api.js?render=6LeSGi4pAAAAAHsPHdCM8xT3Us4NGNYsSioOeyyA";
    script.async = true;
    document.head.appendChild(script);

    script.onload = () => {
      const grecaptcha = (window as any).grecaptcha;

      grecaptcha.ready(() => {
        grecaptcha
          .execute("6LeSGi4pAAAAAHsPHdCM8xT3Us4NGNYsSioOeyyA", {
            action: "login",
          })
          .then((token: string) => {
            if (recaptchaResponseRef.current) {
              recaptchaResponseRef.current.value = token;
            }
          });
      });
    };

    return () => {
      document.head.removeChild(script);
    };
  }, [recaptchaResponseRef, actionData]);

  return (
    <>
      <div className="flex min-h-full items-center justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-3xl space-y-8">
          <div>
            <img
              className="mx-auto h-12 w-auto"
              src="/assets/revyse-logo-color-black.png"
              alt=""
              width="320"
              height="112"
            />
            <h1 className="mt-6 text-center text-3xl font-bold tracking-tight text-gray-900">
              Sign up for your account
            </h1>
            <p className="mt-2 text-center text-sm text-gray-600">
              Or{" "}
              <Link
                to={
                  searchParams.get("redirectTo")?.includes("client_id")
                    ? `../login?redirectTo=${encodeURIComponent(
                        searchParams.get("redirectTo") ?? ""
                      )}`
                    : `../login?redirectTo=${
                        searchParams.get("redirectTo") ?? ""
                      }`
                }
                className="font-medium text-sky-600 hover:text-sky-500"
              >
                Login
              </Link>
            </p>
          </div>
          {actionData !== undefined && (
            <Toast
              variant={actionData.success ? "success" : "error"}
              message={
                actionData.success
                  ? "Success!"
                  : actionData.errors?.general
                  ? actionData.errors?.general[0]
                  : "There were problems registering. Please try again."
              }
            />
          )}
          <Form className="mt-8 space-y-6" method="post">
            {searchParams.get("redirectTo") && (
              <input
                type="hidden"
                name="redirectTo"
                value={searchParams.get("redirectTo") ?? undefined}
              />
            )}
            {searchParams.get("intent") && (
              <input
                type="hidden"
                name="intent"
                value={searchParams.get("intent") ?? undefined}
              />
            )}
            <div className="-space-y-px rounded-md shadow-sm border border-gray-100 bg-white p-6 grid md:grid-cols-2 gap-6">
              <div>
                <CrudTextField
                  field={{
                    label: "First Name *",
                    name: "first_name",
                    errors: actionData?.errors?.first_name ?? [],
                    defaultValue: actionData?.fields?.first_name ?? undefined,
                    type: "text",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    label: "Last Name *",
                    name: "last_name",
                    errors: actionData?.errors?.last_name ?? [],
                    defaultValue: actionData?.fields?.last_name ?? undefined,
                    type: "text",
                  }}
                />
              </div>

              <div>
                <CrudTextField
                  field={{
                    label: "Job Title *",
                    name: "title",
                    errors: actionData?.errors?.title ?? [],
                    defaultValue: actionData?.fields?.title ?? undefined,
                    type: "text",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    label: "Company Name *",
                    name: "company_name",
                    errors: actionData?.errors?.company_name ?? [],
                    defaultValue: actionData?.fields?.company_name ?? undefined,
                    type: "text",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    label: "Work Email Address *",
                    name: "email",
                    errors: actionData?.errors?.email ?? [],
                    defaultValue: actionData?.fields?.email ?? undefined,
                    type: "text",
                  }}
                />
              </div>
              <div>
                <CrudTextField
                  field={{
                    label: "Phone *",
                    name: "phone",
                    errors: actionData?.errors?.phone ?? [],
                    defaultValue: actionData?.fields?.phone ?? undefined,
                    type: "text",
                  }}
                />
              </div>
              <div>
                <label
                  htmlFor="password"
                  className="text-sm font-medium mb-2 block"
                >
                  Password *
                </label>
                <div className="relative">
                  <input
                    id="password"
                    name="password"
                    type={showPassword ? "text" : "password"}
                    autoComplete="current-password"
                    // required
                    className={tvField({
                      className: "shadow-sm relative",
                      error: (actionData?.errors?.password?.length ?? 0) > 0,
                    })}
                    placeholder="Password"
                    defaultValue={actionData?.fields?.password ?? undefined}
                  />
                  <button
                    type="button"
                    className="absolute inset-y-0 right-0 flex items-center pr-3 z-10"
                    onClick={togglePasswordVisibility}
                  >
                    {showPassword ? (
                      <EyeSlashIcon
                        className="h-5 w-5 text-gray-400 hover:text-gray-500"
                        aria-hidden="true"
                      />
                    ) : (
                      <EyeIcon
                        className="h-5 w-5 text-gray-400 hover:text-gray-500"
                        aria-hidden="true"
                      />
                    )}
                  </button>
                </div>
                <div className="text-red-500 mt-2 text-sm">
                  {actionData?.errors?.password?.join(", ")}
                </div>
              </div>
              <div>
                <label
                  htmlFor="passwordConfirmation"
                  className="text-sm font-medium mb-2 block"
                >
                  Confirm Password *
                </label>
                <input
                  id="password-confirmation"
                  name="passwordConfirmation"
                  type="password"
                  autoComplete="current-password"
                  className={tvField({
                    className: "shadow-sm relative",
                    error:
                      (actionData?.errors?.passwordConfirmation?.length ?? 0) >
                      0,
                  })}
                  placeholder="Confirm Password"
                  defaultValue={
                    actionData?.fields?.passwordConfirmation ?? undefined
                  }
                />
                <div
                  className="text-red-500 mt-2 text-sm"
                  id="errors-password-confirmation"
                >
                  {actionData?.errors?.passwordConfirmation?.join(", ")}
                </div>
              </div>
            </div>
            <div>
              <div id="inline-badge"></div>
            </div>
            <input
              type="hidden"
              id="g-recaptcha-response"
              name="g-recaptcha-response"
              ref={recaptchaResponseRef}
            />
            <div className="flex justify-end pr-6">
              <Button type="submit">
                {navigation.state === "submitting"
                  ? "Signing Up..."
                  : "Sign Up"}
              </Button>
            </div>
          </Form>
        </div>
      </div>
    </>
  );
}
