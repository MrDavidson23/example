import { CTA } from "~/components/cta.component";
import {
  useFetcher,
  useLoaderData,
  useNavigate,
  useNavigation,
} from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { TrashIcon } from "@heroicons/react/24/outline";
import type { FormEvent, MouseEvent } from "react";
import { useCallback, useEffect, useRef, useState } from "react";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import type { Fee, Prisma } from "@prisma/client";
import { z } from "zod";
import { Modal } from "~/components/modal.component";
import { issuesByKey } from "~/utils/form.utils.server";
import {
  CrudSelectField,
  CrudTextField,
} from "~/components/form/crud-form.component";
import { Permission } from "~/utils/intelligence-permission.utils";
import { Button, DangerButton } from "~/components/button.component";
import {
  jsonWithError,
  jsonWithSuccess,
  redirectWithSuccess,
} from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { castFormFields } from "~/utils/type.utils";
import { FilterBar } from "~/components/filter-bar.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { ProductsAndFeesTable } from "~/components/intelligence/contracts/contract-line-item-products-table.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(relativeTime);

type JsonData = {
  fields?: Record<string, string> | null;
  success?: boolean;
  errors?: Record<string, string[] | null>;
  feeSuccess?: boolean;
  createFeeErrors?: Record<string, string[] | null>;
  editFeeSuccess?: boolean;
  editFeeErrors?: Record<string, string[] | null>;
  fee?: Fee | null;
};

const SelectProductsForm = z
  .object({
    products: z.array(
      z.object({
        id: z.string().uuid(),
      })
    ),
    fees: z.array(
      z.object({
        id: z.string().uuid(),
      })
    ),
  })
  .superRefine((values, ctx) => {
    if (
      !(values.products && values.products.length) &&
      !(values.fees && values.fees.length)
    ) {
      ctx.addIssue({
        code: z.ZodIssueCode.custom,
        message: "At least one product or one fee is required",
        path: ["general"],
      });
    }
  });

const AddFeeForm = z.object({
  fee_name: z
    .string()
    .max(55, "Name must be maximum 55 characters")
    .min(1, "Fee name is required"),
  fee_category_id: z.string(),
});

async function createFeeAction({
  form,
  vendorId,
  managerAccountId,
}: {
  form: FormData;
  vendorId: string;
  managerAccountId: string;
}) {
  const { feeService } = await WebDIContainer();

  const fields = {
    fee_name: form.get("fee_name"),
    fee_category_id: form.get("fee_category_id"),
  };

  const validation = await AddFeeForm.safeParseAsync(fields);

  if (validation.success) {
    const newFee = await feeService.createFee(
      validation.data.fee_name,
      validation.data.fee_category_id,
      vendorId,
      managerAccountId
    );

    return jsonWithSuccess<JsonData>(
      {
        feeSuccess: true,
        fields: castFormFields(fields),
        createFeeErrors: issuesByKey([]),
        fee: newFee,
      },
      "Fee created successfully"
    );
  }
  return jsonWithError<JsonData>(
    {
      feeSuccess: false,
      fields: castFormFields(fields),
      createFeeErrors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE
  );
}

async function editFeeAction({ form }: { form: FormData }) {
  const { feeService } = await WebDIContainer();

  const fields = {
    fee_id: form.get("fee_id"),
    fee_name: form.get("fee_name"),
    fee_category_id: form.get("fee_category_id"),
  };
  const validation = z
    .object({
      fee_id: z.string().uuid(),
      fee_name: z
        .string()
        .max(55, "Name must be maximum 55 characters")
        .min(1, "Fee name is required"),
      fee_category_id: z.string(),
    })
    .safeParse(fields);

  if (validation.success) {
    await feeService.updateFee(
      validation.data.fee_id,
      validation.data.fee_name,
      validation.data.fee_category_id
    );

    return jsonWithSuccess<JsonData>(
      {
        editFeeSuccess: true,
        fields: null,
        editFeeErrors: issuesByKey([]),
      },
      "Fee updated successfully"
    );
  }
  return jsonWithError<JsonData>(
    {
      editFeeSuccess: false,
      fields: null,
      editFeeErrors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE
  );
}

async function deleteFeeAction({ form }: { form: FormData }) {
  const { feeService } = await WebDIContainer();

  const fields = {
    fee_id: form.get("fee_id"),
  };
  const validation = z
    .object({
      fee_id: z.string().uuid(),
    })
    .safeParse(fields);

  if (validation.success) {
    const response = await feeService.deleteFee(validation.data.fee_id);
    if (!response.success) {
      return jsonWithError<JsonData>(
        {
          success: false,
          fee: response.fee,
          fields: null,
        },
        response.error ?? ""
      );
    }
    return jsonWithSuccess<JsonData>(
      {
        success: true,
        fields: castFormFields(fields),
        fee: null,
        errors: issuesByKey([]),
      },
      "Fee deleted successfully"
    );
  }
  return jsonWithError<JsonData>(
    {
      success: false,
      fields: null,
      fee: null,
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE
  );
}

async function createEditContractLineItemAction({
  id,
  contractId,
  form,
  accountId,
}: {
  id: string;
  contractId: string;
  form: FormData;
  accountId: string;
}) {
  const { contractLineItemService } = await WebDIContainer();

  const productIds = form.getAll("products.id") as string[];
  const feeIds = form.getAll("fees.id") as string[];

  const products = productIds.map((id, index) => {
    return {
      id: id,
    };
  });
  const fees = feeIds.map((id, index) => {
    return {
      id: id,
    };
  });
  const fields = {
    products,
    fees,
  };

  const validation = await SelectProductsForm.safeParseAsync(fields);

  if (validation.success) {
    try {
      const contractLineItem =
        await contractLineItemService.selectContractLineItemProductsAndFees({
          id,
          data: validation.data,
          contractId,
          productIds,
          feeIds,
        });

      return redirectWithSuccess(
        `/intelligence/${accountId}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/set-price`,
        "Line item saved successfully\nContinue to set pricing"
      );
    } catch (e: any) {
      console.error(e);
      let issue = { path: ["general"], message: e.message };
      return jsonWithError<JsonData>(
        {
          success: false,
          fields: castFormFields(fields),
          errors: issuesByKey([issue]),
        },
        DEFAULT_FORM_ERROR_MESSAGE,
        { status: 400 }
      );
    }
  }
  const errors = issuesByKey(validation.error.issues);
  return jsonWithError<JsonData>(
    { success: false, fields: castFormFields(fields), errors },
    DEFAULT_FORM_ERROR_MESSAGE
  );
}

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContractLineItem],
    }
  );
  const { contractService } = await WebDIContainer();

  const id = params.contract_line_item_id!;
  const contractId = params.contract_id!;
  const accountId = account.id;
  const contract = await contractService.getContractById(contractId);

  const form = await request.formData();
  const intent = form.get("intent");

  switch (intent) {
    case "createContractLineItemProducts":
      return createEditContractLineItemAction({
        id,
        contractId,
        form,
        accountId,
      });
    case "editFee":
      return editFeeAction({ form });
    case "deleteFee":
      return deleteFeeAction({ form });
    case "addNewFee":
      return createFeeAction({
        form,
        vendorId: contract.manager_account_vendor.vendor_id,
        managerAccountId: accountId,
      });
    default:
      return null;
  }
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContractLineItem],
    }
  );

  const {
    feeService,
    contractService,
    contractLineItemService,
    productCategoryService,
  } = await WebDIContainer();

  const contractId = params.contract_id!;
  const id = params.contract_line_item_id;

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const searchTerm = search.get("query");

  const contract = await contractService.getContractById(contractId);

  const filters: Prisma.ProductWhereInput = {
    title: {
      contains: searchTerm ?? "",
      mode: "insensitive",
    },
    vendor_id: contract.manager_account_vendor.vendor_id,
    OR: [
      {
        approved_at: { not: null },
      },
      {
        manager_account_id: account.id,
      },
    ],
  };

  const products = await contractLineItemService.getContractLineItemProducts(
    filters,
    contract.manager_account_vendor.vendor_id
  );

  const feeFilters: Prisma.FeeWhereInput = {
    name: {
      contains: searchTerm ?? "",
      mode: "insensitive",
    },
    vendor_id: contract.manager_account_vendor.vendor_id,
    manager_account_id: account.id,
  };

  const fees = await feeService.getFees(feeFilters);

  if (id !== "new") {
    const contractLineItem = await contractLineItemService.loadContractLineItem(
      id
    );
    const contractLineItemsProducts =
      contractLineItem?.contract_line_item_products
        ? contractLineItem.contract_line_item_products.map(
            product => product.product_id
          )
        : [];
    const contractLineItemsFees = contractLineItem?.contract_line_item_fees
      ? (contractLineItem.contract_line_item_fees.map(
          fee => fee.fee_id
        ) as string[])
      : [];
    return json({
      id,
      contractLineItem,
      contract,
      products,
      fees,
      categories: await productCategoryService.getAllCategories(),
      contractLineItemsProducts,
      contractLineItemsFees,
      url,
      searchTerm,
      account,
    });
  }

  return json({
    id,
    contractLineItem: null,
    contract,
    products,
    fees,
    categories: await productCategoryService.getAllCategories(),
    contractLineItemsProducts: null,
    contractLineItemsFees: null,
    searchTerm,
    account,
  });
}

export default function PriceConfigProducts() {
  const {
    id,
    contractLineItem,
    contract,
    searchTerm,
    products,
    fees,
    contractLineItemsProducts,
    contractLineItemsFees,
    categories,
    account,
  } = useLoaderData<typeof loader>();
  const navigate = useNavigate();
  const navigation = useNavigation();
  const fetcher = useFetcher<typeof action>();

  const baseUrl = `/intelligence/${account.id}/contract/${
    contract.id
  }/line-item/${contractLineItem?.id ?? "new"}`;
  const formRef = useRef<HTMLFormElement | null>(null);

  const crumbs = [
    {
      name: "All contracts",
      to: `/intelligence/${account.id}/contracts`,
      active: false,
    },
    {
      name: contract.name,
      to: `/intelligence/${account.id}/contract/${contract.id}/details`,
      active: false,
    },
    {
      name: "Products and line items",
      to: `/intelligence/${account.id}/contract/${contract.id}/line-item`,
      active: false,
    },
  ];
  if (contractLineItem?.name) {
    crumbs.push(
      {
        name: contractLineItem?.name,
        to: contractLineItem
          ? `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem?.id}/summary`
          : "",
        active: false,
      },
      {
        name: "Select products",
        to: contractLineItem
          ? `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem?.id}`
          : "",
        active: true,
      }
    );
  } else {
    crumbs.push({
      name: "Create new line item",
      to: contractLineItem
        ? `/intelligence/${account.id}/contract/${contract.id}/line-item/${contractLineItem?.id}`
        : "",
      active: true,
    });
  }

  const [selectedFees, setSelectedFees] = useState<string[]>(
    contractLineItemsFees ?? []
  );
  const [selectedProducts, setSelectedProducts] = useState<string[]>(
    contractLineItemsProducts ?? []
  );

  const mergedList = [
    ...products.map((product: any) => ({
      ...product,
      id: `product_${product.id}`,
    })),
    ...fees.map((fee: Fee) => ({
      ...fee,
      id: `fee_${fee.id}`,
      new: true,
    })),
  ];

  // Added fee or product prefix so we can avoid issues when selecting and deselecting if a product and fee have the same uuid
  // and when sending the hidden inputs in the form as fees and products
  const [selectedItems, setSelectedItems] = useState(
    selectedFees
      ? [
          ...selectedProducts.map(productId => ({
            id: `product_${productId}`,
          })),
          ...selectedFees.map(feeId => ({ id: `fee_${feeId}` })),
        ]
      : selectedProducts.map(productId => ({ id: `product_${productId}` }))
  );

  const sortedList = mergedList.sort((a, b) =>
    (a.name || a.title).localeCompare(b.name || b.title)
  );

  const [deselectConfirmation, setDeselectConfirmation] = useState({
    productId: "",
    message: "",
  });
  const [deselectFeeConfirmation, setDeselectFeeConfirmation] = useState({
    feeId: "",
    message: "",
  });
  const [confirmDeleteFeeOpen, setConfirmDeleteFeeOpen] = useState(false);

  const [confirmationModal, setConfirmationModal] = useState(false);
  const [feeConfirmationModal, setFeeConfirmationModal] = useState(false);

  const [createFeeModal, setCreateFeeModal] = useState(false);
  const [editFeeModal, setEditFeeModal] = useState(false);
  const [editingFee, setEditingFee] = useState<{
    id: string;
    name: string | undefined;
    category_id: string | undefined;
  }>();

  const handleSelection = useCallback(
    (rowId: string) => {
      if (rowId.startsWith("product_")) {
        const productId = rowId.replace("product_", "");
        const isSelected = selectedProducts.includes(productId);
        const isItemSelected = selectedItems.some(item => item.id === rowId);
        if (isSelected && isItemSelected) {
          if (
            contractLineItemsProducts &&
            contractLineItemsProducts.includes(productId)
          ) {
            setConfirmationModal(true);
            setDeselectConfirmation({
              productId: rowId,
              message:
                "Deselecting this product may result in Line Item data loss. Are you sure you want to proceed?",
            });
          } else {
            setSelectedProducts(
              selectedProducts.filter(id => id !== productId)
            );
            setSelectedItems(prevSelectedItems =>
              prevSelectedItems.filter(item => item.id !== rowId)
            );
          }
        } else {
          setSelectedProducts(
            isSelected ? selectedProducts : [...selectedProducts, productId]
          );
          setSelectedItems(
            isItemSelected ? selectedItems : [...selectedItems, { id: rowId }]
          );
        }
      } else {
        const feeId = rowId.replace("fee_", "");
        const isSelected = selectedFees.includes(feeId);
        const isItemSelected = selectedItems.some(item => item.id === rowId);
        if (isSelected && isItemSelected) {
          if (contractLineItemsFees && contractLineItemsFees.includes(feeId)) {
            setFeeConfirmationModal(true);
            setDeselectFeeConfirmation({
              feeId: rowId,
              message:
                "Deselecting this fee may result in Line Item data loss. Are you sure you want to proceed?",
            });
          } else {
            setSelectedFees(selectedFees.filter(id => id !== feeId));
            setSelectedItems(prevSelectedItems =>
              prevSelectedItems.filter(item => item.id !== rowId)
            );
          }
        } else {
          setSelectedFees(isSelected ? selectedFees : [...selectedFees, feeId]);
          setSelectedItems(
            isItemSelected ? selectedItems : [...selectedItems, { id: rowId }]
          );
        }
      }
    },
    [
      selectedFees,
      selectedProducts,
      contractLineItemsFees,
      contractLineItemsProducts,
      selectedItems,
    ]
  );

  const handleNewFee = () => {
    setCreateFeeModal(true);
  };

  const confirmDeselect = () => {
    setSelectedProducts(
      selectedProducts.filter(
        id => id !== deselectConfirmation.productId.replace("product_", "")
      )
    );
    setSelectedItems(prevSelectedItems =>
      prevSelectedItems.filter(
        item => item.id !== deselectConfirmation.productId
      )
    );
    setDeselectConfirmation({ productId: "", message: "" });
    setConfirmationModal(false);
  };

  const confirmFeeDeselect = () => {
    setSelectedFees(
      selectedFees.filter(
        id => id !== deselectFeeConfirmation.feeId.replace("fee_", "")
      )
    );
    setSelectedItems(prevSelectedItems =>
      prevSelectedItems.filter(
        item => item.id !== deselectFeeConfirmation.feeId
      )
    );
    setDeselectFeeConfirmation({ feeId: "", message: "" });
    setFeeConfirmationModal(false);
  };

  function constructNewURL(baseUrl: string, searchQuery: string): string {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchQuery);

    return `${baseUrl}?${searchParams.toString()}`;
  }

  const handleFiltering = (newSearchQuery?: string) => {
    const newURL = constructNewURL(baseUrl, newSearchQuery ?? searchTerm ?? "");
    return navigate(newURL);
  };

  const handleMainFormSubmit = (
    e: FormEvent<HTMLFormElement> | MouseEvent<HTMLButtonElement>
  ) => {
    if (e.target === formRef.current) {
      e.preventDefault();
      return false;
    }
    fetcher.submit(formRef.current, { method: "post" });
  };

  useEffect(() => {
    if (navigation.state == "idle") {
      window.scrollTo(0, 0);
    }
  }, [navigation.state]);

  useEffect(() => {
    if (fetcher.data?.success || fetcher.data?.editFeeSuccess) {
      setConfirmDeleteFeeOpen(false);
      setEditFeeModal(false);
    }
  }, [fetcher.data]);

  useEffect(() => {
    if (fetcher.data?.feeSuccess) {
      setCreateFeeModal(false);
      if (fetcher.data?.fee) {
        const feeId = fetcher.data.fee.id;
        setSelectedFees(selectedFees => [...selectedFees, feeId]);
        setSelectedItems(selectedItems => [
          ...selectedItems,
          { id: `fee_${feeId}` },
        ]);
      }
    }
  }, [fetcher.data]);

  return (
    <>
      <Modal
        isOpen={confirmationModal}
        onClose={() => setConfirmationModal(false)}
        manager={true}
        size="medium"
      >
        <div className="p-3 space-y-7" id="remove-product-confirmation">
          <h1 className="text-2xl">Do you want to remove this product?</h1>
          <div>{deselectConfirmation.message}</div>
          <div className="flex justify-end space-x-2">
            <CTA
              variant="sky-shadow"
              onClick={() => setConfirmationModal(false)}
            >
              Cancel
            </CTA>
            <CTA
              id="remove-line-item-product"
              variant="coral-shadow"
              onClick={confirmDeselect}
            >
              Confirm Deselect
            </CTA>
          </div>
        </div>
      </Modal>
      <Modal
        isOpen={feeConfirmationModal}
        onClose={() => setFeeConfirmationModal(false)}
        manager={true}
        size="medium"
      >
        <div className="p-3 space-y-7">
          <h1 className="text-2xl">Do you want to remove this fee?</h1>
          <div>{deselectFeeConfirmation.message}</div>
          <div className="flex justify-end space-x-2">
            <CTA
              variant="sky-shadow"
              onClick={() => setFeeConfirmationModal(false)}
            >
              Cancel
            </CTA>
            <CTA variant="coral-shadow" onClick={confirmFeeDeselect}>
              Confirm Deselect
            </CTA>
          </div>
        </div>
      </Modal>
      <Modal
        isOpen={createFeeModal}
        onClose={() => setCreateFeeModal(false)}
        manager={true}
        size="medium"
      >
        <div className="p-3 space-y-7">
          <fetcher.Form method="post">
            <h1 className="text-2xl">Add fees or other charges</h1>
            <input type="hidden" name="intent" value="addNewFee" />
            <CrudTextField
              field={{
                name: "fee_name",
                type: "text",
                errors: fetcher.data?.createFeeErrors?.fee_name ?? [],
                label: "Give the fee a recognizable name",
                placeholder: "Fee name",
                defaultValue: fetcher.data?.fields?.fee_name ?? "",
                maxCharacters: 55,
              }}
            />
            <CrudSelectField
              field={{
                name: "fee_category_id",
                label: "Category",
                type: "select",
                options: categories.map(c => ({ label: c.name, value: c.id })),
                defaultValue: fetcher.data?.fields?.fee_category_id ?? "",
                errors: fetcher.data?.createFeeErrors?.fee_category_id ?? [],
                description:
                  "Don't see your category listed? Reach out to support@revyse.com and we'll get you squared away.",
              }}
            />
            <div className="flex justify-end space-x-6 py-3">
              <button
                type="button"
                className="text-sky-500"
                onClick={() => setCreateFeeModal(false)}
              >
                Cancel
              </button>
              <CTA id="save-new-fee" variant="coral-shadow" type="submit">
                Save
              </CTA>
            </div>
          </fetcher.Form>
        </div>
      </Modal>
      <Modal
        isOpen={editFeeModal}
        onClose={() => setEditFeeModal(false)}
        manager={true}
        size="medium"
      >
        <div className="p-3 space-y-7">
          <fetcher.Form method="post">
            <h1 className="text-2xl">Edit your fee</h1>
            <input type="hidden" name="intent" value="editFee" />
            <input type="hidden" name="fee_id" value={editingFee?.id} />
            <CrudTextField
              field={{
                name: "fee_name",
                type: "text",
                errors: fetcher.data?.editFeeErrors?.fee_name ?? [],
                label: "Give the fee a recognizable name",
                placeholder: "Fee name",
                defaultValue:
                  editingFee?.name ?? fetcher?.data?.fee?.name ?? "",
                maxCharacters: 55,
              }}
            />
            <CrudSelectField
              field={{
                name: "fee_category_id",
                label: "Category",
                type: "select",
                options: categories.map(c => ({ label: c.name, value: c.id })),
                defaultValue:
                  editingFee?.category_id ??
                  fetcher?.data?.fee?.category_id ??
                  "",
                errors: fetcher.data?.editFeeErrors?.fee_category_id ?? [],
                description:
                  "Don't see your category listed? Reach out to support@revyse.com and we'll get you squared away.",
              }}
            />
            <div className="w-full flex justify-between space-x-6 py-3">
              <div>
                <button
                  type="button"
                  className="text-sky-500"
                  onClick={() => setEditFeeModal(false)}
                >
                  Go Back
                </button>
              </div>
              <div className="space-x-6 flex justify-end">
                {confirmDeleteFeeOpen ? (
                  <div className="flex justify-between items-center">
                    Are you sure you want to delete this fee?
                    <input type="hidden" name="intent" value="deleteFee" />
                    <input type="hidden" name="fee_id" value={editingFee?.id} />
                    <Button
                      onClick={() => setConfirmDeleteFeeOpen(false)}
                      className="ml-2 rounded-full"
                    >
                      Cancel
                    </Button>
                    <DangerButton
                      type="button"
                      className="ml-2 rounded-full"
                      onClick={() => {
                        fetcher.submit(
                          {
                            intent: "deleteFee",
                            fee_id: editingFee?.id ?? fetcher.data?.fee?.id,
                          } as JsonData,
                          {
                            action: baseUrl,
                            method: "post",
                            encType: "multipart/form-data",
                          }
                        );
                        if (fetcher.data?.success) {
                          setEditFeeModal(false);
                          setConfirmDeleteFeeOpen(false);
                        }
                      }}
                    >
                      Yep!
                    </DangerButton>
                  </div>
                ) : (
                  <button
                    type="button"
                    onClick={() => {
                      setConfirmDeleteFeeOpen(!confirmDeleteFeeOpen);
                    }}
                    className="text-sky-500"
                  >
                    <div className="flex">
                      <TrashIcon className="h-5 mr-1" />
                      Delete
                    </div>
                  </button>
                )}

                {!confirmDeleteFeeOpen && (
                  <CTA variant="coral-shadow" type="submit">
                    Save
                  </CTA>
                )}
              </div>
            </div>
          </fetcher.Form>
        </div>
      </Modal>
      <IntelligenceScreenHeader
        crumbs={crumbs}
        title={
          id === "new"
            ? "Create a new line item"
            : "Select the products in this line item"
        }
        description="Line items are the individual items listed on a contract. A line item can represent a single product or service, or a bundle of products, services, and fees. Select the products or fees in this line item and click continue."
        buttonsSlot={
          <CTA
            id="save-contract-line-item-button"
            type="button"
            onClick={handleMainFormSubmit}
          >
            <>
              {navigation.state === "submitting"
                ? "Submitting..."
                : "Continue to Pricing"}
            </>
          </CTA>
        }
      />
      <FilterBar
        inputPlaceholder="Search products or fees"
        defaultSearchQuery={searchTerm ?? ""}
        onFilter={handleFiltering}
      />
      <fetcher.Form
        ref={formRef}
        className="space-y-8"
        method="post"
        onSubmit={handleMainFormSubmit}
      >
        <input
          type="hidden"
          name="intent"
          value="createContractLineItemProducts"
        />
        <div>
          <ProductsAndFeesTable
            items={sortedList}
            columnsToShow={["title", "category", "new"]}
            handleSelection={handleSelection}
            handleFee={setEditingFee}
            selectedRows={selectedItems}
            handleEditModal={setEditFeeModal}
            confirmEditOpen={editFeeModal}
            handleAddButton={handleNewFee}
          />
          {selectedItems.map(item => (
            <div key={item.id}>
              {item.id.startsWith("product_") && (
                <input
                  type="hidden"
                  name={`products.id`}
                  value={item.id.replace("product_", "")}
                />
              )}
              {item.id.startsWith("fee_") && (
                <input
                  type="hidden"
                  name={`fees.id`}
                  value={item.id.replace("fee_", "")}
                />
              )}
            </div>
          ))}
        </div>
        <div className="flex justify-end">
          <CTA type="button" onClick={handleMainFormSubmit}>
            <>
              {navigation.state === "submitting"
                ? "Submitting..."
                : "Continue to Pricing"}
            </>
          </CTA>
        </div>
      </fetcher.Form>
    </>
  );
}
