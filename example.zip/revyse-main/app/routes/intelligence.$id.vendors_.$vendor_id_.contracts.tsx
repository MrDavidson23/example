import { json } from "@remix-run/node";
import {
  useLoaderData,
  useLocation,
  useNavigate,
  useSearchParams,
} from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import {
  Permission,
  canDoOnAccount,
} from "~/utils/intelligence-permission.utils";
import { pickBy, identity, isEmpty } from "lodash";
import { useCallback, useEffect, useMemo, useState } from "react";
import { CTA } from "~/components/cta.component";
import { ContractsTable } from "~/components/intelligence/contracts/contracts-table.component";
import type { Contract, ContractStatus } from "@prisma/client";
import type { ManagerAccountVendorContractFilters } from "~/services/manager-account-vendor.service.server";
import { ContractsFilter } from "~/components/intelligence/contracts/contracts-filter.component";
import { Pagination } from "~/components/intelligence/pagination.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

type Filters = {
  query?: string;
  status?: ContractStatus[];
  annual_value_start?: string;
  annual_value_end?: string;
  current_term_end_date_start?: string;
  current_term_end_date_end?: string;
};

const DEFAULT_PAGE_SIZE = 10;

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewVendorDetails],
    }
  );

  const { managerAccountVendorService } = await WebDIContainer();

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);

  const page = parseInt(search.get("page") || "1");
  const pageSize = parseInt(
    search.get("pageSize") || String(DEFAULT_PAGE_SIZE)
  );

  const filters = {
    query: search.get("query") || undefined,
    status: !isEmpty(search.getAll("status"))
      ? ((search.getAll("status") || []) as ContractStatus[])
      : undefined,
    annual_value_start: search.get("annual_value_start") || undefined,
    annual_value_end: search.get("annual_value_end") || undefined,
    current_term_end_date_start:
      search.get("current_term_end_date_start") || undefined,
    current_term_end_date_end:
      search.get("current_term_end_date_end") || undefined,
  };

  const formattedFilters: ManagerAccountVendorContractFilters = {
    ...filters,
    annual_value_start: Number(filters.annual_value_start) || undefined,
    annual_value_end: Number(filters.annual_value_end) || undefined,
    current_term_end_date_start: filters.current_term_end_date_start
      ? new Date(filters.current_term_end_date_start)
      : undefined,
    current_term_end_date_end: filters.current_term_end_date_end
      ? new Date(filters.current_term_end_date_end)
      : undefined,
  };

  const orderByString = search.getAll("orderBy");

  const orderBy = !isEmpty(orderByString)
    ? orderByString.map(value => {
        const [key, direction] = value.split(":");
        return { [key]: direction };
      })
    : [
        {
          status: "asc",
        },
        {
          current_term_end_date: "asc",
        },
      ];

  const vendor =
    await managerAccountVendorService.getManagerAccountVendorIdAndName(
      params.vendor_id || ""
    );

  const managerAccountVendorContracts =
    await managerAccountVendorService.getManagerAccountVendorContracts(
      user,
      account,
      params.vendor_id || "",
      formattedFilters,
      pageSize,
      (page - 1) * pageSize,
      orderBy
    );

  const contractsCount =
    await managerAccountVendorService.getManagerAccountVendorContractsCount(
      params.vendor_id || "",
      formattedFilters
    );

  return json({
    managerAccountVendorContracts,
    contractsCount,
    user,
    account,
    vendor,
    currentFilters: filters,
    managerAccountVendorId: params.vendor_id,
  });
}

export default function IntelligenceVendorContracts() {
  const location = useLocation();
  const navigate = useNavigate();

  const {
    managerAccountVendorContracts,
    contractsCount,
    user,
    account,
    vendor,
    currentFilters,
    managerAccountVendorId,
  } = useLoaderData<typeof loader>();

  const [searchParams, setSearchParams] = useSearchParams();

  const [filters, setFilters] = useState<Filters>(currentFilters);

  const [paginationParams, setPaginationParams] = useState<{
    page: string;
    pageSize: string;
  }>();

  const totalPages = useMemo(
    () =>
      Math.ceil(
        contractsCount /
          (Number(paginationParams?.pageSize) || DEFAULT_PAGE_SIZE)
      ),
    [contractsCount, paginationParams?.pageSize]
  );
  const pageNumbers = useMemo(
    () => Array.from({ length: totalPages }, (_, i) => i + 1),
    [totalPages]
  );
  const resultsText = useMemo(
    () =>
      `${managerAccountVendorContracts.length} out of ${contractsCount} results`,
    [managerAccountVendorContracts, contractsCount]
  );

  const handlePageChange = useCallback(
    (page: number) => {
      setPaginationParams(prev =>
        prev
          ? {
              ...prev,
              page: String(page),
            }
          : {
              page: String(page),
              pageSize: String(DEFAULT_PAGE_SIZE),
            }
      );
    },
    [setPaginationParams]
  );

  const searchParamsPaginationString = useMemo(
    () =>
      searchParams.get("page")
        ? JSON.stringify({
            page: searchParams.get("page"),
            pageSize: searchParams.get("pageSize"),
          })
        : undefined,
    [searchParams]
  );

  useEffect(() => {
    const paginationChanged =
      searchParamsPaginationString !== JSON.stringify(paginationParams);
    const filtersChanged =
      JSON.stringify(filters) !== JSON.stringify(currentFilters);
    // Avoid redundant updates causing loader to be called again
    if (paginationChanged || filtersChanged) {
      setSearchParams(oldSearchParams => ({
        ...Object.fromEntries(oldSearchParams),
        ...paginationParams,
        ...pickBy(filters, identity),
      }));
    }
  }, [
    filters,
    paginationParams,
    setSearchParams,
    searchParamsPaginationString,
    currentFilters,
  ]);

  const handleOrderBy = useCallback(
    (newOrderBy: Partial<Record<keyof Contract, "asc" | "desc">>) => {
      const orderByParam = Object.entries(newOrderBy).map(
        ([key, value]) => `${key}:${value}`
      );
      setSearchParams(oldSearchParams => ({
        ...Object.fromEntries(oldSearchParams),
        orderBy: orderByParam,
      }));
    },
    [setSearchParams]
  );

  // Permissions
  const canManageContracts = useMemo(
    () => canDoOnAccount(user, account, Permission.ManageContracts),
    [user, account]
  );

  return (
    <>
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All vendors",
            to: `/intelligence/${account.id}/vendors`,
          },
          {
            name: vendor?.name || "",
            to: `/intelligence/${account.id}/vendors/${managerAccountVendorId}`,
          },
          {
            name: "Contract management",
            to: location.pathname,
            active: true,
          },
        ]}
        title="Contract management"
        description={`View all company-managed contracts for ${vendor?.name}, including term end dates and annual contract values.`}
        buttonsSlot={
          canManageContracts && (
            <CTA
              to={`/intelligence/${account.id}/contract/new?vendor_id=${vendor?.id}`}
              id="add-new-contract"
            >
              Add New Contract
            </CTA>
          )
        }
      />
      <div className="mt-8">
        <ContractsFilter onFilter={setFilters} />
      </div>
      <div className="mt-8">
        <ContractsTable
          items={managerAccountVendorContracts ?? []}
          columnsToShow={[
            "name",
            "currentTermEnds",
            "contractLineItems",
            "locationsAssigned",
            "annualValue",
            "status",
            "arrowRight",
          ]}
          onClickRow={contract =>
            navigate(
              `/intelligence/${account.id}/contract/${contract.id}/details`
            )
          }
          onOrderBy={handleOrderBy}
        />
      </div>
      <Pagination
        resultsText={resultsText}
        pageNumbers={pageNumbers}
        currentPage={Number(paginationParams?.page) || 1}
        totalPages={totalPages}
        handleCallback={handlePageChange}
      />
    </>
  );
}
