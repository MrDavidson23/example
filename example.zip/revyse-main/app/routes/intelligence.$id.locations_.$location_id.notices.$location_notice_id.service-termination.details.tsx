import { json } from "@remix-run/node";
import { Link, useFetcher, useLoaderData } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { CTA } from "~/components/cta.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Permission } from "~/utils/intelligence-permission.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import {
  CrudAutocompleteField,
  CrudDateField,
  CrudSelectField,
  CrudTextField,
  FormSection,
} from "~/components/form/crud-form.component";
import {
  DEFAULT_FORM_ERROR_MESSAGE,
  LocationPropertyTypeLabels,
} from "~/utils/constants.utils";
import { CrudTextAreaField } from "~/components/form/textarea.component";
import { Button } from "~/components/button.component";
import { ArrowLeftIcon, XMarkIcon } from "@heroicons/react/20/solid";
import { useCallback, useMemo, useRef, useState } from "react";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import {
  jsonWithError,
  redirectWithSuccess,
  redirectWithWarning,
} from "remix-toast";
import { find } from "lodash";
import { Tooltip } from "~/components/tooltip.component";
import { InformationCircleIcon } from "@heroicons/react/24/outline";
import { LocationNoticeStatus } from "@prisma/client";
dayjs.extend(utc);

const NewServiceTerminationNoticeForm = z.object({
  manager_account_vendor_id: z.string().uuid(),
  termination_date: z.date(),
  termination_instructions: z.string().nullish(),
  contact_name: z.string().min(1, "Contact name is required"),
  contact_email: z.string().min(1, "Contact email is required"),
  task_owner_id: z.string(),
  original_location_notice_id: z.string().uuid().nullish(),
  intent: z.string().nullish(),
});

export async function action({ request, params }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocationNotices],
      locationId: params.location_id,
    }
  );

  const locationId = params.location_id!;
  const locationNoticeId = params.location_notice_id!;

  const { locationServiceTerminationService } = await WebDIContainer();

  const form = await request.formData();

  const fields = {
    manager_account_vendor_id: form.get("manager_account_vendor_id") as string,
    termination_date: new Date(form.get("termination_date") as string),
    termination_instructions: form.get("termination_instructions") as string,
    contact_name: form.get("contact_name") as string,
    contact_email: form.get("contact_email") as string,
    task_owner_id: form.get("task_owner_id") as string,
    original_location_notice_id: form.get(
      "original_location_notice_id"
    ) as string,
    intent: form.get("intent") as string,
  };

  const validation = NewServiceTerminationNoticeForm.safeParse(fields);

  if (!validation.success) {
    return jsonWithError(
      { errors: issuesByKey(validation.error.issues), fields },
      DEFAULT_FORM_ERROR_MESSAGE
    );
  }

  const manager_account_role_id = user.manager_account_roles.find(
    role => role.manager_account_id === account.id
  )!.id;

  const { intent, ...data } = validation.data;

  const saveProgress = intent === "save-progress";

  let locationServiceTermination = null;
  if (locationNoticeId === "new") {
    locationServiceTermination =
      await locationServiceTerminationService.createLocationServiceTermination(
        locationId,
        {
          ...data,
          manager_account_role_id,
        },
        saveProgress
      );
  } else {
    locationServiceTermination =
      await locationServiceTerminationService.updateLocationServiceTermination(
        locationNoticeId,
        {
          ...data,
          manager_account_role_id,
        },
        saveProgress
      );
  }

  if (saveProgress) {
    return redirectWithSuccess(
      `/intelligence/${account.id}/locations/${locationId}/notices`,
      "Service termination notice saved successfully"
    );
  }

  // If the location notice is an updated one, we need to redirect to the email template page
  if (locationServiceTermination.original_location_notice_id) {
    return redirectWithSuccess(
      `/intelligence/${account.id}/locations/${locationId}/notices/${locationServiceTermination.id}/service-termination/emailtemplate`,
      "Service termination notice updated successfully"
    );
  }

  return redirectWithSuccess(
    `/intelligence/${account.id}/locations/${locationId}/notices/${locationServiceTermination.id}/service-termination/selectservices`,
    "Service termination notice saved successfully"
  );
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocationNotices],
      locationId: params.location_id,
    }
  );

  const {
    managerAccountService,
    locationService,
    locationServiceTerminationService,
  } = await WebDIContainer();
  const managerAccountId = account.id;

  const location = await locationService.getLocation(params.location_id!);

  if (!location) {
    throw new Response("Location not found", { status: 404 });
  }

  const locationNoticeId = params.location_notice_id!;

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);

  const locationNotice =
    locationNoticeId !== "new"
      ? await locationServiceTerminationService.getLocationServiceTermination(
          locationNoticeId,
          location.id,
          user,
          account
        )
      : null;

  if (locationNoticeId !== "new" && !locationNotice) {
    throw new Response("Location notice not found", { status: 404 });
  }

  if (locationNotice?.status === LocationNoticeStatus.Sent) {
    return redirectWithWarning(
      `/intelligence/${account.id}/locations/${location.id}/notices/${locationNoticeId}/service-termination`,
      "Location notice has already been sent"
    );
  }

  const originalLocationNoticeId =
    locationNoticeId === "new"
      ? search.get("original_location_notice_id")
      : locationNotice?.original_location_notice_id;

  const originalLocationNotice = originalLocationNoticeId
    ? await locationServiceTerminationService.getLocationServiceTermination(
        originalLocationNoticeId,
        location.id,
        user,
        account
      )
    : null;

  const taskOwnerOptions = await managerAccountService.getTaskOwnerOptions(
    managerAccountId
  );

  const vendorOptions =
    await locationServiceTerminationService.getVendorOptions(location.id);

  const vendor = locationNotice
    ? {
        ...locationNotice.manager_account_vendor,
        contact: {
          name: locationNotice.contact_name,
          email: locationNotice.contact_email,
        },
      }
    : originalLocationNotice
    ? {
        ...originalLocationNotice.manager_account_vendor,
        contact: {
          name: originalLocationNotice.contact_name,
          email: originalLocationNotice.contact_email,
        },
      }
    : null;
  return json({
    user,
    account,
    location,
    taskOwnerOptions,
    userManagerAccountRole: user?.manager_account_roles.find(
      role => role.manager_account_id === managerAccountId
    ),
    locationNotice,
    originalLocationNotice,
    vendorOptions,
    vendor,
  });
}

export default function LocationServiceTerminationDetails() {
  const {
    account,
    location,
    taskOwnerOptions,
    userManagerAccountRole,
    locationNotice,
    originalLocationNotice,
    vendorOptions,
    vendor,
  } = useLoaderData<typeof loader>();

  const [selectedVendor, setSelectedVendor] = useState<
    (typeof vendorOptions)[number] | undefined
  >(vendor || undefined);

  const onSelectVendor = useCallback(
    (vendorId: string) => {
      setSelectedVendor(find(vendorOptions, ["id", vendorId]));
    },
    [vendorOptions]
  );

  const fetcher = useFetcher<typeof action>();
  const formRef = useRef<HTMLFormElement>(null);

  const submit = (intent?: string) => {
    const formData = formRef.current && new FormData(formRef.current);

    if (intent) {
      formData?.append("intent", intent);
    }

    if (originalLocationNotice) {
      formData?.append(
        "original_location_notice_id",
        originalLocationNotice.id
      );
    }

    fetcher.submit(formData, {
      method: "POST",
    });
  };

  const formErrors = useMemo(() => fetcher.data?.errors ?? {}, [fetcher.data]);

  return (
    <>
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
          },
          {
            name: "Notices",
            to: `/intelligence/${account.id}/locations/${location.id}/notices`,
          },
          {
            name: originalLocationNotice
              ? "Updated service termination details"
              : "Configure service termination details",
            to: `/intelligence/${account.id}/locations/${location.id}/notices/${
              locationNotice?.id ?? "new"
            }/service-termination`,
            active: true,
          },
        ]}
        title={
          <>
            {originalLocationNotice
              ? "Updated service termination notice"
              : "Service termination notice"}
            :
            <br /> {location.name}
          </>
        }
        description={
          originalLocationNotice
            ? `Update the important details and dates for ${location.name}’s upcoming service termination. Next, you’ll confirm your changes in the service termination notice email template.`
            : `Configure the important details and dates for ${location.name}’s new service termination notice. Next, you’ll review and select the assigned services to be canceled.`
        }
        buttonsSlot={<CTA onClick={() => submit()}>Continue</CTA>}
      />
      <fetcher.Form ref={formRef}>
        <main className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min gap-y-40">
          <FormSection
            title="Vendor Contact Information"
            subtitle={
              <div className="text-gray-400">
                Select the vendor to be notified. If the vendor’s contact info
                has previously been saved, it will auto-populate in the required
                fields.
              </div>
            }
            spacing="compact"
            border={false}
          >
            {!selectedVendor && (
              <div className="relative col-span-full">
                <CrudAutocompleteField
                  field={{
                    name: "",
                    label: "Select Vendor",
                    type: "autocomplete" as const,
                    defaultValue: undefined,
                    errors: formErrors.manager_account_vendor_id ?? [],
                    options: vendorOptions.map(vendor => ({
                      label: vendor.vendor.name,
                      value: vendor.id,
                    })),
                    optionsContainerClass: "z-50",
                    onSelect: onSelectVendor,
                  }}
                />
              </div>
            )}
            {selectedVendor && (
              <div className="relative col-span-full">
                <CrudTextField
                  field={{
                    name: "",
                    label: "Select Vendor",
                    type: "text" as const,
                    defaultValue: selectedVendor?.vendor?.name,
                    errors: formErrors.manager_account_vendor_id ?? [],
                    disabled: true,
                  }}
                />
                {!originalLocationNotice && (
                  <Button
                    className="absolute right-0 top-8"
                    color="transparent"
                    onClick={() => setSelectedVendor(undefined)}
                  >
                    <XMarkIcon className="h-5 w-5" />
                  </Button>
                )}
              </div>
            )}
            {selectedVendor && (
              <>
                <input
                  name="manager_account_vendor_id"
                  value={selectedVendor?.id}
                  type="hidden"
                />
                {originalLocationNotice && (
                  <>
                    <input
                      name="contact_name"
                      value={selectedVendor?.contact.name ?? undefined}
                      type="hidden"
                    />
                    <input
                      name="contact_email"
                      value={selectedVendor?.contact.email ?? undefined}
                      type="hidden"
                    />
                  </>
                )}
              </>
            )}
            <div className="col-span-full">
              <CrudTextField
                field={{
                  name: "contact_name",
                  label: (
                    <span>
                      Cancellation Notice Contact Name
                      <Tooltip
                        text="If the Cancellation Notice Contact has been populated, we’ll display that info here. If it hasn’t, we’ll display your Main Contact’s info. If neither contact has been populated, this column will be blank."
                        position="top"
                      >
                        <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
                      </Tooltip>
                    </span>
                  ),
                  type: "text",
                  placeholder: "Contact Name",
                  defaultValue: selectedVendor?.contact?.name ?? undefined,
                  errors: formErrors.contact_name ?? [],
                  disabled: originalLocationNotice ? true : false,
                }}
              />
            </div>
            <div className="col-span-full">
              <CrudTextField
                field={{
                  name: "contact_email",
                  label: (
                    <span>
                      Cancellation Notice Contact Email
                      <Tooltip
                        text="If the Cancellation Notice Contact has been populated, we’ll display that info here. If it hasn’t, we’ll display your Main Contact’s info. If neither contact has been populated, this column will be blank."
                        position="top"
                      >
                        <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
                      </Tooltip>
                    </span>
                  ),
                  type: "text",
                  placeholder: "Contact Email",
                  defaultValue: selectedVendor?.contact?.email ?? undefined,
                  errors: formErrors.contact_email ?? [],
                  disabled: originalLocationNotice ? true : false,
                }}
              />
            </div>
          </FormSection>
          <hr />
          <FormSection
            title="Termination Information"
            subtitle={
              <div className="text-gray-400">
                Location Name: {location.name}
                <br />
                City, State: {location.city}, {location.state}
                <br />
                Unit Count: {location.unit_count}
                <br />
                Property Type:{" "}
                {LocationPropertyTypeLabels[location.property_type]}
                <br />
                Owner: {location.owner_name ?? "--"}
              </div>
            }
            spacing="compact"
            border={false}
          >
            <CrudDateField
              field={{
                name: "termination_date",
                label: "Requested Service Termination Date",
                tooltipText:
                  "The requested service termination date is the date that you are requesting that all services be canceled for this location.",
                type: "text",
                defaultValue: locationNotice?.termination_date
                  ? dayjs
                      .utc(locationNotice.termination_date)
                      .format("YYYY-MM-DD")
                  : originalLocationNotice?.termination_date
                  ? dayjs
                      .utc(originalLocationNotice.termination_date)
                      .format("YYYY-MM-DD")
                  : "",
                errors: formErrors.termination_date ?? [],
              }}
              minDate={dayjs().format("YYYY-MM-DD")}
            />

            <CrudTextAreaField
              field={{
                name: "termination_instructions",
                label: "Instructions for Final Invoices",
                type: "textarea",
                placeholder:
                  "Enter any specific instructions on where you’d like final invoices to be sent, whom they should be sent to, and/or timelines for submitting final invoices.",
                defaultValue:
                  locationNotice?.termination_instructions ??
                  originalLocationNotice?.termination_instructions ??
                  "",
                errors: formErrors.termination_instructions ?? [],
                showOptional: true,
                rows: 4,
              }}
            />
            <CrudSelectField
              field={{
                name: "task_owner_id",
                label: "Assign Service termination notice Task Owner",
                tooltipText:
                  "This is who the vendor should reach out to with questions about the upcoming service cancellation. We’ll also send an auto-reminder to this user to set the vendor’s assignment status to canceled in Revyse, once the request is complete.",
                type: "select",
                defaultValue:
                  locationNotice?.task_owner_id ??
                  originalLocationNotice?.task_owner_id ??
                  userManagerAccountRole?.id,
                errors: formErrors.task_owner_id ?? [],
                options: taskOwnerOptions,
              }}
            />
          </FormSection>
        </main>
        <footer className="flex justify-between items-center mt-4">
          <div>
            <Link
              to={`/intelligence/${account.id}/locations/${location.id}/notices`}
              className="text-sky-500 flex items-center text-sm"
            >
              <ArrowLeftIcon className="h-5 mr-2" /> Back to all notices
            </Link>
          </div>
          <div className="flex gap-x-2">
            <Button color="transparent" onClick={() => submit("save-progress")}>
              Save Progress
            </Button>
            <CTA onClick={() => submit()}>Continue</CTA>
          </div>
        </footer>
      </fetcher.Form>
    </>
  );
}
