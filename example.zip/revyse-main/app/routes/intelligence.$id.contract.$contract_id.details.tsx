import { CTA } from "~/components/cta.component";
import { Link, useLoaderData } from "@remix-run/react";
import type {
  ActionFunctionArgs,
  LinksFunction,
  LoaderFunctionArgs,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { every, startCase } from "lodash";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import {
  ArrowRightIcon,
  ChevronDownIcon,
  ChevronUpIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";
import { useCallback, useMemo, useState } from "react";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { ContractStatus } from "@prisma/client";
import {
  canDoOnAccount,
  Permission,
} from "~/utils/intelligence-permission.utils";
import { Button } from "~/components/button.component";
import DocumentCard from "~/components/intelligence/document-card.component";
import { redirectWithSuccess } from "remix-toast";
import HTMLReactParser from "html-react-parser";
import richtext from "../styles/richtext.css";
import { Avatar } from "~/components/avatar.component";
import { ConfirmDeleteModal } from "~/components/modals/confirm-delete-modal.component";
import StatusChip from "~/components/status-chip.component";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { Banner } from "~/components/intelligence/banner.component";
import { ExclamationTriangleIcon } from "@heroicons/react/24/solid";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const CancellationFormSchema = z.object({
  canceled_at: z.date().nullable(),
});

async function deleteAction({
  id,
  account_id,
}: {
  id: string;
  account_id: string;
}) {
  const { contractService } = await WebDIContainer();

  await contractService.deleteContract(id);

  return redirectWithSuccess(
    `/intelligence/${account_id}/contracts`,
    "Contract deleted successfully"
  );
}

async function archiveAction({
  id,
  account_id,
  form,
}: {
  id: string;
  account_id: string;
  form: FormData;
}) {
  const cancelationDate = form.get("canceled_at") as string;
  const fields = {
    canceled_at: cancelationDate ? new Date(cancelationDate) : null,
  };
  const validation = CancellationFormSchema.safeParse(fields);

  if (validation.success) {
    const { contractService } = await WebDIContainer();
    await contractService.archiveContract(id, validation.data.canceled_at);

    return redirectWithSuccess(
      `/intelligence/${account_id}/contracts?status=archived`,
      "Contract archived successfully"
    );
  }

  return json({
    success: false,
    errors: issuesByKey(validation.error.issues),
  });
}

export const links: LinksFunction = () => {
  return [
    {
      rel: "stylesheet",
      href: richtext,
    },
  ];
};

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContracts],
    }
  );

  const id = params.contract_id!;

  const form = await request.formData();
  const intent = form.get("intent");

  if (id && intent === "delete") {
    return deleteAction({ id, account_id: account.id });
  } else if (id && intent === "archive") {
    return archiveAction({
      id,
      account_id: account.id,
      form,
    });
  }
  return json({});
};

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewContractDetails],
    }
  );

  const { contractService } = await WebDIContainer();

  const contract = await contractService.getContractDetails(
    params.contract_id!
  );
  if (!contract) {
    throw new Response("Not found", { status: 404 });
  }
  const { managerAccountService } = await WebDIContainer();

  const contractAnnualValue =
    await managerAccountService.getContractAnnualAssignedValue(contract.id);

  const extraContractData = {
    annual_assigned_value: contractAnnualValue,
  };
  return json({
    contract: {
      ...contract,
      ...extraContractData,
    },
    user,
    account,
  });
}

export default function Contract() {
  const { contract, user, account } = useLoaderData<typeof loader>();
  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);
  const [confirmArchiveOpen, setConfirmArchiveOpen] = useState(false);

  const [
    showMoreContractLineItemsIncreasing,
    setShowMoreContractLineItemsIncreasing,
  ] = useState(false);

  const handleDocumentClick = useCallback((id: string | null) => {
    window.open(`/images/${id}`, "_blank");
  }, []);

  const filteredContractsLineItems = contract.contract_line_items.filter(
    contractLineItem =>
      contractLineItem.price_increase_percent &&
      contractLineItem.price_increase_percent > 0
  );

  const lineItemsPriceIncreasing = useMemo(() => {
    if (!showMoreContractLineItemsIncreasing) {
      return filteredContractsLineItems.slice(0, 2);
    }
    return filteredContractsLineItems;
  }, [filteredContractsLineItems, showMoreContractLineItemsIncreasing]);

  // Permissions
  const userCanManageContract = canDoOnAccount(
    user,
    account,
    Permission.ManageContracts
  );

  const contractedLocations = () => {
    const allCorporateOnly =
      contract.contract_line_items.length > 0 &&
      every(contract.contract_line_items, "is_corporate_only");
    if (allCorporateOnly) {
      return <div className="font-normal">Corporate</div>;
    }

    if (
      contract.status === ContractStatus.Pending ||
      contract.status === ContractStatus.Canceled
    ) {
      return "--";
    }

    let totalCount = new Set(
      contract.contract_line_items
        .flatMap(
          contractLineItem => contractLineItem?.contract_line_item_locations
        )
        .filter(location => location !== null && location !== undefined)
        .map(location => location.location_id)
    ).size;
    return <div>{totalCount}</div>;
  };

  const canceledContract = contract.status === ContractStatus.Canceled;

  const renderBanner = () => {
    if (contract.is_sensitive) {
      return (
        <Banner
          title="This contract has been marked as sensitive."
          description="Only users assigned the Owner role can view this contract and all of its corresponding data."
          actions={{
            secondary: {
              children: (
                <>
                  Change this setting
                  <ArrowRightIcon className="h-5 w-5 ml-1.5" />
                </>
              ),
              color: "transparent",
              to: `/intelligence/${account.id}/contract/${contract.id}`,
            },
          }}
          icon={<ExclamationTriangleIcon className="h-full w-full" />}
          color="amber"
        />
      );
    }
  };

  return (
    <>
      {((canceledContract && confirmDeleteOpen) ||
        (!canceledContract && confirmArchiveOpen)) && (
        <ConfirmDeleteModal
          isOpen={true}
          onClose={() =>
            canceledContract
              ? setConfirmDeleteOpen(false)
              : setConfirmArchiveOpen(false)
          }
          onConfirm={() =>
            canceledContract
              ? setConfirmDeleteOpen(false)
              : setConfirmArchiveOpen(false)
          }
          title={
            canceledContract
              ? "Delete this contract and its corresponding data"
              : "Set contract status to “Canceled”"
          }
          message={
            canceledContract
              ? "Are you sure you want to permanently delete this contract forever?"
              : `Are you sure you want to cancel and archive ${contract.name}? You can always access it again later in the archived contracts tab.`
          }
          submitOnConfirm={true}
          intent={canceledContract ? "delete" : "archive"}
        />
      )}
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All contracts",
            to: `/intelligence/${account.id}/contracts`,
          },
          {
            name: contract.name,
            to: `/intelligence/${account.id}/contract/${contract.id}/details`,
            active: true,
          },
        ]}
        title={
          <>
            Contract details:
            <br /> {contract.name}
          </>
        }
        description="View important contract information, including term end dates and
        scheduled renewal reminders. To edit these details, click the “Edit
        Contract” button."
        buttonsSlot={
          userCanManageContract && (
            <>
              {contract.status === ContractStatus.Canceled ? (
                <button
                  onClick={() => {
                    setConfirmDeleteOpen(!confirmDeleteOpen);
                  }}
                  className="text-sky-500"
                  id="delete-contract-button"
                >
                  <div className="flex">
                    <TrashIcon className="h-5 mr-1" />
                    Delete
                  </div>
                </button>
              ) : (
                <CTA
                  type="button"
                  variant="coral"
                  fillStyle="outline"
                  onClick={() => {
                    setConfirmArchiveOpen(!confirmArchiveOpen);
                  }}
                  id="cancel-contract-button"
                >
                  Cancel & Archive
                </CTA>
              )}
              <CTA
                type="button"
                variant="coral-shadow"
                to={`/intelligence/${account.id}/contract/${contract.id}`}
              >
                Edit Contract
              </CTA>
            </>
          )
        }
      />
      {renderBanner()}
      <div className="bg-white shadow-lg shadow-gray-200/50 p-8 rounded-lg h-min space-y-8">
        <div className="font-bold text-lg lg:text-xl leading-tight mb-4">
          Primary Contract Information
        </div>
        <div className="grid grid-cols-2 gap-y-8 gap-x-2 md:gap-x-0">
          <div className="font-medium">Contract Name</div>
          <div>{contract.name}</div>

          <div className="font-medium">Vendor Name</div>
          <div>
            <Link
              to={`/intelligence/${account.id}/vendors/${contract.manager_account_vendor.id}`}
              className="text-sky-600"
            >
              {contract.manager_account_vendor.vendor.name}
            </Link>
          </div>

          <div className="font-medium">Contract Status</div>
          <div>
            <StatusChip
              model="ContractStatus"
              status={contract.status}
              label={contract.status}
            />
          </div>

          {contract.canceled_at && (
            <>
              <div className="font-medium">Contract Cancellation Date</div>
              <div>{dayjs.utc(contract.canceled_at).format("MMM D, YYYY")}</div>
            </>
          )}
          {contract.location && (
            <>
              <div className="font-medium">Location-Level Contract</div>
              <div>{contract.location.name}</div>
            </>
          )}

          <div className="font-medium">Contract Owner</div>
          <div>
            {contract.contract_owner_name ? contract.contract_owner_name : "--"}
          </div>

          <div className="font-medium">Contract Approver</div>
          <div>{contract.approver ? contract.approver : "--"}</div>

          <div className="font-medium">Line Items</div>
          <div>{contract.contract_line_items.length}</div>

          <div className="font-medium">Contracted Locations</div>
          <div>{contractedLocations()}</div>

          <div className="font-medium">Est. Annual Contract Value</div>
          <div>
            {contract.annual_assigned_value.toLocaleString(undefined, {
              style: "currency",
              currency: "USD",
            })}
          </div>
        </div>
        <hr />
        <div className="font-bold text-lg lg:text-xl leading-tight mb-4">
          Contract Terms
        </div>
        <div className="grid grid-cols-2 gap-y-8 gap-x-2 md:gap-x-0">
          {contract.is_msa && (
            <>
              <div className="font-medium">Master Service Agreement</div>
              <div>Yes</div>
            </>
          )}
          <div className="font-medium">Contract Length</div>
          <div>
            {contract.term_length_months
              ? `${contract.term_length_months} months`
              : "--"}
          </div>

          <div className="font-medium">Contract Effective Date</div>
          <div>
            {contract.effective_date
              ? dayjs.utc(contract.effective_date).format("MMM D, YYYY")
              : "--"}
          </div>

          <div className="font-medium">Initial Term End Date</div>
          <div>
            {contract.expires_at
              ? dayjs.utc(contract.expires_at).format("MMM D, YYYY")
              : "--"}
          </div>

          <div className="font-medium">Current Term End Date</div>
          <div>
            {contract.current_term_end_date
              ? dayjs.utc(contract.current_term_end_date).format("MMM D, YYYY")
              : "--"}
          </div>

          <div className="font-medium">Month-to-Month Contract</div>
          <div>{contract.is_month_to_month ? "Yes" : "No"}</div>

          <div className="font-medium">Contracted Auto-Renewal</div>
          <div>{contract.will_auto_renew ? "Yes" : "No"}</div>

          <div className="font-medium">Auto-Renewal Term Length</div>
          <div>
            {contract.auto_renew_term_length
              ? `${contract.auto_renew_term_length} months`
              : "--"}
          </div>

          <div className="font-medium">Contracted Price Increases</div>
          <div className="flex flex-col">
            {lineItemsPriceIncreasing.length > 0 ? (
              <>
                {lineItemsPriceIncreasing.map(lineItem => (
                  <div key={lineItem.id}>
                    {lineItem.name} / {lineItem.price_increase_percent}% /{" "}
                    {startCase(lineItem.price_increase_cadence || "")}
                  </div>
                ))}
                {filteredContractsLineItems.length > 2 && (
                  <Button
                    color="transparent"
                    className="px-0 w-max"
                    onClick={() =>
                      setShowMoreContractLineItemsIncreasing(
                        !showMoreContractLineItemsIncreasing
                      )
                    }
                  >
                    {showMoreContractLineItemsIncreasing ? (
                      <ChevronUpIcon className="h-5 mr-1" />
                    ) : (
                      <ChevronDownIcon className="h-5 mr-1" />
                    )}
                    Show {showMoreContractLineItemsIncreasing ? "less" : "more"}
                  </Button>
                )}
              </>
            ) : (
              "--"
            )}
          </div>

          <div className="font-medium">Termination Notice Period</div>
          <div>
            {contract.termination_notice_period
              ? `${contract.termination_notice_period} days`
              : "--"}
          </div>

          <div className="font-medium">Termination Notice Details</div>
          <div className="richtext">
            {HTMLReactParser(contract.termination_notice_details ?? "--")}
          </div>
        </div>
        <hr />
        <div className="font-bold text-lg lg:text-xl leading-tight mb-4">
          Scheduled Renewal Reminder
        </div>

        <div className="grid grid-cols-2 gap-y-8 gap-x-2 md:gap-x-0">
          <div className="font-medium">Renewal Reminder Scheduled</div>
          <div>
            {contract.is_month_to_month
              ? contract.renewal_reminder_date
                ? dayjs
                    .utc(contract.renewal_reminder_date)
                    .format("MMM D, YYYY")
                : "--"
              : contract.renewal_reminder_lead_time_months
              ? `${contract.renewal_reminder_lead_time_months} month(s) out`
              : "--"}
          </div>

          <div className="font-medium">Renewal Reminder Recipients</div>
          <div className="lg:flex lg:flex-wrap gap-2">
            {contract.renewal_reminder_emails.length > 0
              ? contract.renewal_reminder_emails.map((email, index) => (
                  <div
                    className="bg-sky-50 rounded-full flex items-center mr-1 m-2 lg:m-0 p-1 lg:p-2 h-min w-min text-xs lg:text-sm whitespace-nowrap"
                    key={index}
                  >
                    {email}
                  </div>
                ))
              : "--"}
          </div>

          <div className="font-medium">Renewal Task Owner</div>
          <div>
            {contract.task_owner ? (
              <div className="flex items-center gap-x-1">
                <Avatar
                  first_name={contract.task_owner.user.first_name!}
                  last_name={contract.task_owner.user.last_name!}
                  className="h-8 w-8 text-sm"
                />
                {contract.task_owner.user.first_name}{" "}
                {contract.task_owner.user.last_name}
              </div>
            ) : (
              "--"
            )}
          </div>
        </div>
        <hr />
        <div className="grid grid-cols-2 gap-x-2 md:gap-x-0">
          <div className="font-bold text-lg lg:text-xl leading-tight mb-4">
            Contract Notes
          </div>
          <div className="richtext">
            {HTMLReactParser(contract.notes ?? "--")}
          </div>
        </div>
        <hr />
        <div className="grid grid-cols-2 gap-x-2 md:gap-x-0">
          <div className="font-bold text-lg lg:text-xl leading-tight mb-4">
            Contract Uploads
          </div>
          <div className="space-y-3">
            {contract.document_files.map(doc => (
              <DocumentCard
                key={`${doc.id}-${doc.created_at}`}
                document={doc}
                onCardClick={() => handleDocumentClick(doc.file_id)}
                isContract={true}
              />
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
