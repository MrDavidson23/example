import { ArrowLeftIcon, ChevronLeftIcon } from "@heroicons/react/20/solid";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { redirect, json } from "@remix-run/node";
import {
  Form,
  Link,
  useActionData,
  useLoaderData,
  useNavigation,
} from "@remix-run/react";
import { isNil } from "lodash";
import {
  CrudCheckboxField,
  CrudSelectField,
  CrudTextField,
} from "~/components/form/crud-form.component";
import { getUser } from "~/utils/session.server";
import { assertAuthorized } from "~/utils/assert.utils.server";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import { useEffect } from "react";
import {
  Boolean as Bool,
  NonEmptyString,
  Score,
} from "~/utils/validation.utils.server";
import { CrudTextAreaField } from "~/components/form/textarea.component";
import { CTA } from "~/components/cta.component";
import { tierHasPermission } from "~/utils/permission.utils";
import { assertAuthenticatedOrRedirect } from "~/utils/auth.utils.server";
import { PhotoIcon } from "@heroicons/react/24/solid";
import { castFormFields } from "~/utils/type.utils";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { WebDIContainer } from "~/di-containers/web.di-container.server";

export async function action({
  params: { slug, id },
  request,
}: ActionFunctionArgs) {
  const { reviewService, productService } = await WebDIContainer();

  const ReviewForm = z.object({
    title: NonEmptyString,
    decision_maker: z.string({ invalid_type_error: "Required" }).nullable(),
    who_uses: z.array(NonEmptyString).min(0, "Required"),
    primary_use_case: NonEmptyString,
    like_most: NonEmptyString,
    dislike_most: NonEmptyString,
    recommend_to: z.string({ invalid_type_error: "Required" }).nullable(),
    custom_question_1: z.string({ invalid_type_error: "Required" }).nullable(),
    custom_question_2: z.string({ invalid_type_error: "Required" }).nullable(),
    custom_question_3: z.string({ invalid_type_error: "Required" }).nullable(),
    customer_service_score: Score,
    customer_service_desc: z.string(),
    value_score: Score,
    value_desc: z.string(),
    onboarding_score: Score,
    onboarding_desc: z.string(),
    compatibility_score: Score,
    compatibility_desc: z.string(),
    show_last_name: Bool,
    show_job_title: Bool,
    show_company: Bool,
  });

  const user = await getUser(request);
  assertAuthorized(!isNil(user));

  const product = await productService.getReviewedProductWithSubscriptions(
    slug
  );

  if (!product) {
    return redirect("/");
  }

  const form = await request.formData();
  const fields = {
    title: form.get("title"),
    decision_maker: form.get("decision_maker"),
    who_uses: form.getAll("who_uses") as string[],
    primary_use_case: form.get("primary_use_case"),
    like_most: form.get("like_most"),
    dislike_most: form.get("dislike_most"),
    recommend_to: form.get("recommend_to"),
    custom_question_1: form.get("custom_question_1"),
    custom_question_2: form.get("custom_question_2"),
    custom_question_3: form.get("custom_question_3"),
    customer_service_score: form.get("customer_service_score"),
    customer_service_desc: form.get("customer_service_desc"),
    value_score: form.get("value_score"),
    value_desc: form.get("value_desc"),
    onboarding_score: form.get("onboarding_score"),
    onboarding_desc: form.get("onboarding_desc"),
    compatibility_score: form.get("compatibility_score"),
    compatibility_desc: form.get("compatibility_desc"),
    show_last_name: form.get("show_last_name"),
    show_job_title: form.get("show_job_title"),
    show_company: form.get("show_company"),
  };

  const validation = ReviewForm.safeParse(fields);
  if (validation.success) {
    const reviewExists = await reviewService.getProductReview({
      productId: product.id,
      userId: user.id,
    });

    if (reviewExists) {
      return jsonWithError(
        {
          success: false,
          fields: castFormFields(fields),
          errors: issuesByKey([
            {
              path: ["general"],
              message: "You have already submitted a review for this product.",
            },
          ]),
        },
        "You have already submitted a review for this product.",
        { status: 400 }
      );
    }
    await reviewService.createProductReview(
      id,
      product,
      user.id,
      validation.data
    );
    return jsonWithSuccess(
      {
        success: true,
        fields: castFormFields(fields),
        errors: issuesByKey([]),
      },
      "Review submitted"
    );
  }

  const errors = issuesByKey(validation.error.issues);
  return jsonWithError(
    { success: false, fields: castFormFields(fields), errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { productService } = await WebDIContainer();

  const user = await assertAuthenticatedOrRedirect(request, "BUYER");
  const product = await productService.getReviewedProductWithSubscriptions(
    params.slug
  );

  const tier = product?.subscriptions[0]?.stripe_price?.product?.tier;

  if (isNil(product)) {
    throw redirect("/");
  }
  return json({ product, user, tier });
}

export default function ProductReviewsRoute() {
  const { product, tier } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();
  const navigation = useNavigation();

  useEffect(() => {
    if (navigation.state == "idle") {
      window.scrollTo(0, 0);
    }
  }, [navigation.state]);

  const scoreOptions = [
    { label: "0 - Couldn't be worse", value: 0 },
    { label: "1 - Not so great", value: 1 },
    { label: "2 - Below average", value: 2 },
    { label: "3 - No complaints", value: 3 },
    { label: "4 - Above average", value: 4 },
    { label: "5 - Totally awesome", value: 5 },
  ];

  return (
    <div className="flex justify-center my-16">
      <div className="md:max-w-7xl flex-grow md:px-6 overflow-clip">
        <div className="md:rounded-2xl shadow-sm bg-white overflow-hidden pb-6 mb-5">
          {tierHasPermission(tier, "show_custom_banner_image") &&
          product.banner_file_id ? (
            <div
              className="lg:h-48 bg-cover"
              style={{
                backgroundImage: `url(/images/${product.banner_file_id})`,
              }}
            ></div>
          ) : (
            <div className="bg-sky-600 lg:h-20"></div>
          )}
          <div className="lg:flex px-2 md:px-12">
            <div className="lg:flex flex-col text-sm hidden bg-white gap-2">
              <div className="-mt-8 bg-white rounded-md border border-gray-200 overflow-hidden">
                {!product.logo_file_id ? (
                  <PhotoIcon className="w-48 h-48 text-gray-200" />
                ) : (
                  <div
                    className="w-48 h-48 bg-center bg-cover bg-no-repeat bg-white"
                    style={{
                      backgroundImage: `url(/images/${product.logo_file_id})`,
                    }}
                  ></div>
                )}
              </div>
              <Link
                to={`/products/${product.slug}`}
                className="font-bold hyphens-auto [text-wrap:pretty] text-xs inline-flex items-center uppercase py-4 px-2 md:px-0 w-48"
              >
                <ChevronLeftIcon className="h-8 mr-1" />
                Back to {product.title}
              </Link>
            </div>
            <div className="flex justify-center w-full">
              {actionData?.success ? (
                <div className="p-12 text-center flex flex-col items-center">
                  <div className="text-2xl font-bold mb-6">
                    Thanks for sharing your feedback with the Revyse community!
                  </div>
                  <p>
                    To ensure the authenticity of reviews, we'll check your
                    account status to verify that you belong to a company that
                    has used the products listed on Revyse before your review is
                    published.
                  </p>
                  <p className="my-6">
                    Already have an account but haven't become a verified buyer
                    yet? Reach out to{" "}
                    <Link
                      to="mailto:support@revyse.com"
                      className="text-sky-600"
                    >
                      support@revyse.com
                    </Link>{" "}
                    and we'll get you verified in no time.
                  </p>
                  <CTA to={`/products/${product.slug}`} className="mt-6 flex">
                    <ArrowLeftIcon className="h-6" /> Back to {product.title}
                  </CTA>
                </div>
              ) : (
                <div className="w-10/12 p-6 flex-grow">
                  <Form method="post" id="review-form">
                    <header className="mb-6 pb-2 border-b border-b-gray-100">
                      <h1
                        id="reviews"
                        className="w-full hyphens-auto break-words font-bold justify-between text-3xl mb-2"
                      >
                        Write a Review for {product.title}
                      </h1>
                      <span className="text-sm [text-wrap:pretty] text-gray-500">
                        Fields marked with an asterisk (*) are required. You’ll
                        get to choose how your information is displayed before
                        submitting your review.
                      </span>
                    </header>
                    <div className="grid grid-cols-1 gap-y-14">
                      <section className="grid grid-cols-1 gap-y-6">
                        <CrudTextField
                          field={{
                            type: "text",
                            name: "title",
                            label: `Give your review a short title. *`,
                            errors: actionData?.errors?.title ?? [],
                            defaultValue:
                              actionData?.fields?.title ?? undefined,
                          }}
                        />
                        <CrudTextAreaField
                          field={{
                            type: "textarea",
                            name: "primary_use_case",
                            label: `What was your company’s primary use case for ${product.title}? *`,
                            errors: actionData?.errors?.primary_use_case ?? [],
                            defaultValue:
                              actionData?.fields?.primary_use_case ?? undefined,
                            rows: 3,
                            placeholder: `Describe how ${product.title} helped your company do business.`,
                          }}
                        />

                        <CrudTextAreaField
                          field={{
                            type: "textarea",
                            name: "like_most",
                            label: `What do you like most about ${product.title}? *`,
                            errors: actionData?.errors?.like_most ?? [],
                            defaultValue:
                              actionData?.fields?.like_most ?? undefined,
                            rows: 3,
                            placeholder: `List your favorite features of this product.`,
                          }}
                        />

                        <CrudTextAreaField
                          field={{
                            type: "textarea",
                            name: "dislike_most",
                            label: `What could ${product.title} do better? *`,
                            errors: actionData?.errors?.dislike_most ?? [],
                            defaultValue:
                              actionData?.fields?.dislike_most ?? undefined,
                            rows: 3,
                            placeholder: `List any dislikes about this product.`,
                          }}
                        />

                        <CrudTextAreaField
                          field={{
                            type: "textarea",
                            name: "recommend_to",
                            label: `Who would you recommend ${product.title} to?`,
                            showOptional: true,
                            errors: actionData?.errors?.recommend_to ?? [],
                            defaultValue:
                              actionData?.fields?.recommend_to ?? undefined,
                            rows: 3,
                            placeholder: `List any type of businesses that would benefit from using this product.`,
                          }}
                        />
                      </section>
                      <section className="grid grid-cols-1 gap-y-6">
                        <header className="border-b border-b-gray-100 pb-2">
                          <h3 id="reviews" className="font-medium mb-1.5">
                            Rate {product.title}
                          </h3>
                          <span className="text-sm text-gray-500">
                            The scores that you give {product.title} below will
                            be included in your public review.
                          </span>
                        </header>

                        <div>
                          <CrudSelectField
                            field={{
                              label: `Customer support and service *`,
                              name: "customer_service_score",
                              type: "select",
                              errors:
                                actionData?.errors?.customer_service_score ??
                                [],
                              options: scoreOptions,
                              defaultValue:
                                actionData?.fields?.customer_service_score ??
                                undefined,
                            }}
                          />

                          <CrudTextAreaField
                            field={{
                              type: "textarea",
                              name: "customer_service_desc",
                              label: `Why did you assign it that score?`,
                              errors:
                                actionData?.errors?.customer_service_desc ?? [],
                              defaultValue:
                                actionData?.fields?.customer_service_desc ??
                                undefined,
                              rows: 2,
                              showOptional: true,
                            }}
                            className="pl-4"
                          />
                        </div>

                        <div>
                          <CrudSelectField
                            field={{
                              label: `Value for money *`,
                              name: "value_score",
                              type: "select",
                              errors: actionData?.errors?.value_score ?? [],
                              options: scoreOptions,
                              defaultValue:
                                actionData?.fields?.value_score ?? undefined,
                            }}
                          />

                          <CrudTextAreaField
                            field={{
                              type: "textarea",
                              name: "value_desc",
                              label: `Why did you assign it that score?`,
                              errors: actionData?.errors?.value_desc ?? [],
                              defaultValue:
                                actionData?.fields?.value_desc ?? undefined,
                              rows: 2,
                              showOptional: true,
                            }}
                            className="pl-4"
                          />
                        </div>

                        <div>
                          <CrudSelectField
                            field={{
                              label: `Ease of onboarding *`,
                              name: "onboarding_score",
                              type: "select",
                              errors:
                                actionData?.errors?.onboarding_score ?? [],
                              options: scoreOptions,
                              defaultValue:
                                actionData?.fields?.onboarding_score ??
                                undefined,
                            }}
                          />

                          <CrudTextAreaField
                            field={{
                              type: "textarea",
                              name: "onboarding_desc",
                              label: `Why did you assign it that score?`,
                              errors: actionData?.errors?.onboarding_desc ?? [],
                              defaultValue:
                                actionData?.fields?.onboarding_desc ??
                                undefined,
                              rows: 2,
                              showOptional: true,
                            }}
                            className="pl-4"
                          />
                        </div>

                        <div>
                          <CrudSelectField
                            field={{
                              label: `Compatibility with your existing solutions *`,
                              name: "compatibility_score",
                              type: "select",
                              errors:
                                actionData?.errors?.compatibility_score ?? [],
                              options: scoreOptions,
                              defaultValue:
                                actionData?.fields?.compatibility_score ??
                                undefined,
                            }}
                          />

                          <CrudTextAreaField
                            field={{
                              type: "textarea",
                              name: "compatibility_desc",
                              label: `Why did you assign it that score?`,
                              errors:
                                actionData?.errors?.compatibility_desc ?? [],
                              defaultValue:
                                actionData?.fields?.compatibility_desc ??
                                undefined,
                              rows: 2,
                              showOptional: true,
                            }}
                            className="pl-4"
                          />
                        </div>
                      </section>
                      <section className="grid grid-cols-1 gap-y-6">
                        <header className="border-b border-b-gray-100 pb-2">
                          <h3 id="reviews" className="font-medium mb-1.5">
                            Optional Information
                          </h3>
                          <span className="text-sm text-gray-500">
                            Your responses to these questions are private and
                            won't be included in your public review.
                          </span>
                        </header>

                        <CrudSelectField
                          field={{
                            label: `Did you select ${product.title}, or was someone else at your company the decision maker?`,
                            name: "decision_maker",
                            type: "select",
                            errors: actionData?.errors?.decision_maker ?? [],
                            options: [
                              { label: "I selected the vendor.", value: "ME" },
                              {
                                label: "My supervisor selected the vendor.",
                                value: "SUPERVISOR",
                              },
                              {
                                label: "My onsite team selected the vendor.",
                                value: "ONSITE_TEAM",
                              },
                              {
                                label: "My corporate team selected the vendor",
                                value: "CORP_TEAM",
                              },
                              {
                                label: "My client selected the vendor.",
                                value: "CLIENT",
                              },
                              {
                                label: "Someone else selected the vendor.",
                                value: "OTHER",
                              },
                            ],
                            defaultValue: undefined,
                            showOptional: true,
                          }}
                        />
                        <div>
                          <p className="py-4">
                            Did you use {product.title} directly, or did someone
                            else at your company use it?
                            <span className="text-md font-normal text-gray-400 text-sm ml-1.5">
                              (Optional)
                            </span>
                          </p>
                          <CrudCheckboxField
                            field={{
                              label: "I used the product myself.",
                              value: "ME",
                              errors: [],
                              name: "who_uses",
                              defaultChecked: Array.isArray(
                                actionData?.fields?.who_uses
                              )
                                ? !!actionData?.fields.who_uses.find(
                                    v => v === "ME"
                                  )
                                : false,
                              type: "checkbox",
                              description: "",
                            }}
                          />

                          <CrudCheckboxField
                            field={{
                              label:
                                "My team used the product, but I did not personally use it.",
                              value: "MY_TEAM",
                              errors: [],
                              name: "who_uses",
                              defaultChecked: Array.isArray(
                                actionData?.fields?.who_uses
                              )
                                ? !!actionData?.fields.who_uses.find(
                                    v => v === "MY_TEAM"
                                  )
                                : false,
                              type: "checkbox",
                              description: "",
                            }}
                          />
                          <CrudCheckboxField
                            field={{
                              label: "My onsite team used the product.",
                              value: "ONSITE_TEAM",
                              errors: [],
                              name: "who_uses",
                              defaultChecked: Array.isArray(
                                actionData?.fields?.who_uses
                              )
                                ? !!actionData?.fields.who_uses.find(
                                    v => v === "ONSITE_TEAM"
                                  )
                                : false,
                              type: "checkbox",
                              description: "",
                            }}
                          />
                          <CrudCheckboxField
                            field={{
                              label: "My corporate team used the product.",
                              value: "CORP_TEAM",
                              errors: [],
                              name: "who_uses",
                              defaultChecked: Array.isArray(
                                actionData?.fields?.who_uses
                              )
                                ? !!actionData?.fields?.who_uses.find(
                                    v => v === "CORP_TEAM"
                                  )
                                : false,

                              type: "checkbox",
                              description: "",
                            }}
                          />
                          <CrudCheckboxField
                            field={{
                              label: "Someone else used the product.",
                              value: "OTHER",
                              errors: [],
                              name: "who_uses",
                              defaultChecked: Array.isArray(
                                actionData?.fields?.who_uses
                              )
                                ? !!actionData?.fields?.who_uses.find(
                                    v => v === "OTHER"
                                  )
                                : false,
                              type: "checkbox",
                              description: "",
                            }}
                          />
                          <div className="text-sm leading-6 text-red-600">
                            {(actionData?.errors?.who_uses ?? []).join(", ")}
                          </div>
                        </div>

                        {tierHasPermission(
                          tier,
                          "show_custom_review_questions"
                        ) && (
                          <>
                            {product.review_questions[0] && (
                              <CrudTextAreaField
                                field={{
                                  type: "textarea",
                                  name: `custom_question_1`,
                                  label: product.review_questions[0],
                                  errors:
                                    actionData?.errors?.custom_question_1 ?? [],
                                  defaultValue:
                                    actionData?.fields?.custom_question_1 ??
                                    undefined,
                                  rows: 3,
                                }}
                              />
                            )}
                            {product.review_questions[1] && (
                              <CrudTextAreaField
                                field={{
                                  type: "textarea",
                                  name: `custom_question_2`,
                                  label: product.review_questions[1],
                                  errors:
                                    actionData?.errors?.custom_question_2 ?? [],
                                  defaultValue:
                                    actionData?.fields?.custom_question_2 ??
                                    undefined,
                                  rows: 3,
                                }}
                              />
                            )}
                            {product.review_questions[2] && (
                              <CrudTextAreaField
                                field={{
                                  type: "textarea",
                                  name: `custom_question_3`,
                                  label: product.review_questions[2],
                                  errors:
                                    actionData?.errors?.custom_question_3 ?? [],
                                  defaultValue:
                                    actionData?.fields?.custom_question_3 ??
                                    undefined,
                                  rows: 3,
                                }}
                              />
                            )}
                          </>
                        )}
                      </section>
                      <section className="grid grid-cols-1 gap-y-6">
                        <header className="border-b border-b-gray-100 pb-2">
                          <h3 id="reviews" className="font-medium mb-1.5">
                            Your Information
                          </h3>
                          <span className="text-sm text-gray-500">
                            Choose how your information is displayed in your
                            public review.
                          </span>
                        </header>

                        <div className="text-sm mb-3">
                          <span className="font-medium text-gray-900">
                            First Name
                          </span>
                          <em className="text-gray-500">
                            {" "}
                            (always shows up and cannot be changed)
                          </em>
                        </div>

                        <CrudSelectField
                          field={{
                            label: `Last Name *`,
                            name: "show_last_name",
                            type: "select",
                            errors: actionData?.errors?.show_last_name ?? [],
                            options: [
                              { label: "Last Name", value: "true" },
                              { label: "Last Initial", value: "false" },
                            ],
                            defaultValue:
                              actionData?.fields?.show_last_name ?? undefined,
                          }}
                        />

                        <CrudSelectField
                          field={{
                            label: `Current Job Title *`,
                            name: "show_job_title",
                            type: "select",
                            errors: actionData?.errors?.show_job_title ?? [],
                            options: [
                              { label: "Show", value: "true" },
                              { label: "Don't Show", value: "false" },
                            ],
                            defaultValue:
                              actionData?.fields?.show_job_title ?? undefined,
                          }}
                        />

                        <CrudSelectField
                          field={{
                            label: `Current Company *`,
                            name: "show_company",
                            type: "select",
                            errors: actionData?.errors?.show_company ?? [],
                            options: [
                              { label: "Show", value: "true" },
                              { label: "Don't Show", value: "false" },
                            ],
                            defaultValue:
                              actionData?.fields?.show_company ?? undefined,
                          }}
                        />
                      </section>

                      <div>
                        <CTA id="submit-review-button" type="submit">
                          Submit Review
                        </CTA>
                      </div>
                    </div>
                  </Form>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
