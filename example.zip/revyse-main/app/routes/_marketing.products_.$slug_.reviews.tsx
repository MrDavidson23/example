import { ChevronRightIcon } from "@heroicons/react/20/solid";
import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { redirect, json } from "@remix-run/node";
import { Link, useLoaderData } from "@remix-run/react";
import { isNil } from "lodash";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { ReviewListComponent } from "~/components/review-list.component";
import { getUser } from "~/utils/session.server";
import { ProductState, VendorState } from "@prisma/client";

export async function loader({ params, request }: LoaderFunctionArgs) {
  const user = await getUser(request);
  const { db, reviewService } = await WebDIContainer();
  const product = await db.product.findFirst({
    where: {
      slug: params.slug,
      approved_at: { not: null },
      state: ProductState.discovery,
      vendor: { state: VendorState.ApprovedForPublishing },
    },
    include: {
      primary_category: true,
      vendor: true,
    },
  });
  if (isNil(product)) {
    return redirect("/");
  }
  const reviews = await reviewService.getReviewsWithRatings({
    productId: product.id,
  });
  return json({ product, reviews, user });
}

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  const product = data!.product;
  return [
    { title: `Read all reviews for ${product.title}` },
    {
      name: "description",
      content: `See all of the verified reviews for ${product.title} on Revyse.`,
    },
  ];
};

export default function ProductReviewsRoute() {
  const { product, reviews, user } = useLoaderData<typeof loader>();

  return (
    <div className="flex justify-center">
      <div className="md:max-w-7xl flex-grow md:px-6 overflow-clip">
        <div className="flex flex-wrap items-center uppercase text-sm py-6 px-2 md:px-0">
          <Link to="/">HOME</Link>
          <ChevronRightIcon className="h-4" />
          <Link to={`/categories/${product.primary_category.slug}`}>
            {product.primary_category.name}
          </Link>
          <ChevronRightIcon className="h-4" />
          <Link to={`/products/${product.slug}`} className="" rel="canonical">
            {product.title}
          </Link>
          <ChevronRightIcon className="h-4" />
          <Link to={`/products/${product.slug}/reviews`} className="font-bold">
            Reviews
          </Link>
        </div>

        <h1 className="hidden">{product.title} Reviews</h1>

        <div className="md:rounded-2xl shadow-sm bg-white overflow-hidden pb-6 mb-5">
          <div className="flex px-4">
            <div className="hidden flex-col w-72 text-sm bg-white pt-4">
              <a href="#product-overview" className="text-sky-500 my-1.5">
                Product Overview
              </a>
              <a href="#company-info" className="text-sky-500 my-1.5">
                Company Info
              </a>
              <a href="#pricing" className="text-sky-500 my-1.5">
                Pricing
              </a>
              <a href="#product-demo" className="text-sky-500 my-1.5">
                Product Demo
              </a>
              <a href="#images" className="text-sky-500 my-1.5">
                Product Images
              </a>
              <a href="#videos" className="text-sky-500 my-1.5">
                Brand Videos
              </a>
              <a href="#downloads" className="text-sky-500 my-1.5">
                Downloads
              </a>
              {/* TODO: uncomment when implemented 
              <a href="#consultants" className="text-sky-500 my-1.5">
                Consultants
              </a> */}
              <a href="#reviews" className="text-sky-500 my-1.5">
                Reviews
              </a>
            </div>
            <ReviewListComponent
              product={product}
              reviews={reviews}
              user={user}
              className="my-4"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
