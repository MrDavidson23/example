import { ArrowLeftIcon, ChevronRightIcon } from "@heroicons/react/20/solid";
import { ProductState, VendorState } from "@prisma/client";
import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Link, useLoaderData, useNavigate } from "@remix-run/react";
import { CTA } from "~/components/cta.component";
import { Modal } from "~/components/modal.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { getUser } from "~/utils/session.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { VendorHeader } from "~/components/vendor-header.component";
import { FilterBar } from "~/components/filter-bar.component";
import { CrudCheckboxField } from "~/components/form/crud-form.component";
import { useEffect, useState } from "react";
import {
  CurrencyDollarIcon,
  TagIcon,
  TvIcon,
  VideoCameraIcon,
} from "@heroicons/react/24/outline";
import { VendorProductCard } from "~/components/vendor-product-card.component";
import { orderBy } from "lodash";
import { tierHasPermission } from "~/utils/permission.utils";
dayjs.extend(utc);

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { db, productService, managerAccountVendorService, vendorService } =
    await WebDIContainer();
  const user = await getUser(request);

  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);
  const searchTerm = search.get("query");
  const featuredContentParam = search.getAll("featured_content");

  const vendor = await vendorService.getVendorForDiscovery({
    slug: params.slug!,
  });
  const vendorRating = await managerAccountVendorService.getVendorRating(
    vendor.id
  );

  const productIds = (
    await db.product.findMany({
      select: { id: true },
      where: {
        vendor_id: vendor.id,
        approved_at: { not: null },
        state: ProductState.discovery,
        vendor: { state: VendorState.ApprovedForPublishing },
        AND: [
          {
            OR: [
              {
                title: {
                  contains: searchTerm ?? "",
                  mode: "insensitive",
                },
              },
              {
                description: {
                  contains: searchTerm ?? "",
                  mode: "insensitive",
                },
              },
            ],
          },
        ],
      },
    })
  ).map(p => p.id);
  const productsWithRatings = await productService.getProductsWithRatings({
    ids: productIds,
  });

  return json({
    user,
    searchTerm,
    vendor,
    vendorRating,
    products: productsWithRatings,
    featuredContentParam,
  });
}

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  const vendor = data!.vendor;
  return [
    { title: `Shop All ${vendor.name} Products` },
    {
      name: "description",
      content: `Discover all of the products and services offered by ${vendor.name} on Revyse.`,
    },
  ];
};

export default function VendorSlugRoute() {
  const { vendor, searchTerm, vendorRating, products, featuredContentParam } =
    useLoaderData<typeof loader>();
  const navigate = useNavigate();
  const [openFilteringModal, setOpenFilteringModal] = useState(false);
  const [filterFeaturedContent, setFilterFeaturedContent] = useState<string[]>(
    []
  );
  const [productList, setProductList] = useState(products);

  const baseUrl = `/vendors/${vendor.slug}/products/`;

  function constructNewURL(
    baseUrl: string,
    searchQuery: string,
    filterByFeaturedContent: string[]
  ): string {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchQuery);
    if (filterByFeaturedContent.length > 0) {
      searchParams.append(
        "featured_content",
        filterByFeaturedContent.join(",")
      );
    }
    return `${baseUrl}?${searchParams.toString()}`;
  }

  const handleFiltering = (newSearchQuery?: string) => {
    const newURL = constructNewURL(
      baseUrl,
      newSearchQuery ?? searchTerm ?? "",
      filterFeaturedContent
    );
    return navigate(newURL);
  };

  const featuredContentFilterValues = [
    { value: "pricing", name: "Products with published pricing" },
    { value: "videos", name: "Products with videos" },
    { value: "demos", name: "Products with self-guided demos" },
    { value: "promos", name: "Products with featured promotions" },
  ];

  const clearFilters = () => {
    const searchParams = new URLSearchParams();
    searchParams.append("query", searchTerm ?? "");

    setFilterFeaturedContent([]);
    searchParams.delete("featured_content");

    const newURL = `${baseUrl}?${searchParams.toString()}`;

    setOpenFilteringModal(false);
    navigate(newURL);
  };

  useEffect(() => {
    let items = [...products];
    items = orderBy(items, "title");

    if (featuredContentParam.length > 0) {
      items = items.filter(product => {
        return featuredContentParam.every(feature => {
          return (
            (feature === "pricing" && product._count.packages > 0) ||
            (feature === "promos" && product.promo_text) ||
            (feature === "videos" && product._count.brand_video_files > 0) ||
            (feature === "demos" &&
              ((product.demo_storylane_url !== null &&
                product.demo_storylane_url.length > 0) ||
                product._count.demo_files > 0))
          );
        });
      });
    }

    setProductList(items);
  }, [featuredContentParam, products]);

  useEffect(() => {
    if (featuredContentParam) {
      setFilterFeaturedContent(
        featuredContentParam.flatMap(value => value.split(","))
      );
    }
  }, [featuredContentParam]);

  return (
    <>
      <Modal
        isOpen={openFilteringModal}
        onClose={() => setOpenFilteringModal(false)}
        size="medium"
        manager={true}
      >
        <div className="p-2 lg:p-6">
          <h4 className="font-bold">Filter By</h4>
          <div className="grid md:grid-cols-2 gap-2 col-span-full">
            <div>
              <div className="my-4 font-semibold">Options:</div>
              <div>
                <div>
                  {featuredContentFilterValues.map(option => (
                    <CrudCheckboxField
                      key={option.value}
                      field={{
                        name: "filter_by",
                        value: option.value,
                        label: option.name,
                        errors: [],
                        description: "",
                        defaultChecked: filterFeaturedContent.includes(
                          option.value
                        ),
                        type: "checkbox",
                      }}
                      onChange={evt => {
                        const checked = evt.target.checked;
                        if (checked) {
                          setFilterFeaturedContent([
                            ...filterFeaturedContent,
                            option.value,
                          ]);
                        } else {
                          setFilterFeaturedContent(
                            filterFeaturedContent.filter(
                              i => i !== option.value
                            )
                          );
                        }
                      }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
          <div className="flex justify-end mt-8 items-center space-x-3">
            <button
              className="text-sky-500"
              onClick={() => {
                clearFilters();
              }}
            >
              Clear filters
            </button>
            <CTA
              variant="coral-shadow"
              onClick={() => {
                setOpenFilteringModal(false);
                handleFiltering();
              }}
            >
              Show results
            </CTA>
          </div>
        </div>
      </Modal>
      <div className="flex justify-center">
        <div className="w-full lg:max-w-7xl md:px-6 overflow-clip">
          <div className="w-full lg:max-w-7xl md:px-6 overflow-clip">
            <div className="flex flex-wrap items-center uppercase text-sm py-6 px-2 md:px-0">
              <Link to="/">HOME</Link>
              <ChevronRightIcon className="h-4" />
              <Link to="/vendors">ALL VENDORS</Link>
              <ChevronRightIcon className="h-4" />
              <Link to={`/vendors/${vendor.slug}`}>{vendor.name}</Link>
              <ChevronRightIcon className="h-4" />
              <Link
                to={`/vendors/${vendor.slug}/products`}
                className="font-bold"
              >
                ALL PRODUCTS
              </Link>
            </div>
          </div>
          <div className="md:rounded-2xl shadow-sm bg-white pb-6 mb-5">
            <div className="rounded-t-2xl overflow-clip mb-10">
              <VendorHeader vendor={vendor} vendorRating={vendorRating} />
            </div>

            <div className="px-2 lg:px-12 w-full space-y-7">
              <div>
                <Link
                  to={`/vendors/${vendor.slug}`}
                  className="text-sky-600 flex items-center w-fit"
                >
                  <ArrowLeftIcon className="h-5 mr-2" />
                  Back to vendor details
                </Link>
              </div>
              <FilterBar
                inputPlaceholder="Search products"
                defaultSearchQuery={searchTerm ?? ""}
                onFilter={searchQuery => {
                  handleFiltering(searchQuery);
                }}
                filters={{
                  onOpenFilteringModal: setOpenFilteringModal,
                  filtersCount: filterFeaturedContent.length,
                }}
              />
              <div className="grid lg:grid-cols-2 gap-6 ">
                {productList.map(p => (
                  <VendorProductCard
                    buttonLabel="View"
                    key={p.id}
                    product={{
                      ...p,
                      vendor_name: p.vendor!.name,
                      vendor_logo_file_id: p.vendor!.logo_file_id,
                      logo_file_id: p.logo_file_id,
                      avg_score: p.avgReview,
                      cnt: p.totalReviews,
                    }}
                    tags={[
                      ...(p._count.packages > 0 &&
                      tierHasPermission(p.tier, "show_pricing")
                        ? [
                            {
                              label: "Published Pricing",
                              icon: CurrencyDollarIcon,
                            },
                          ]
                        : []),
                      ...(p.promo_text &&
                      tierHasPermission(p.tier, "show_promo")
                        ? [{ label: "Featured Promotions", icon: TagIcon }]
                        : []),
                      ...(p._count.brand_video_files > 0 &&
                      tierHasPermission(p.tier, "show_brand_videos")
                        ? [{ label: "Has Videos", icon: VideoCameraIcon }]
                        : []),
                      ...(tierHasPermission(p.tier, "show_demos") &&
                      ((p.demo_storylane_url !== null &&
                        p.demo_storylane_url.length > 0) ||
                        p._count.demo_files > 0)
                        ? [{ label: "Self-Guided Demos", icon: TvIcon }]
                        : []),
                    ]}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
