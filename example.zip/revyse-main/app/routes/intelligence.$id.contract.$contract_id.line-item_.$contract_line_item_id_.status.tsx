import type { ActionFunctionArgs } from "@remix-run/node";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { ContractLineItemStatus } from "@prisma/client";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { Permission } from "~/utils/intelligence-permission.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const UpdateContractLineItemForm = z.object({
  status: z.enum([
    ContractLineItemStatus.Active,
    ContractLineItemStatus.Canceled,
  ]),
  canceled_at: z.date().optional().nullable(),
});

export async function action({ params, request }: ActionFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageContractLineItem],
    }
  );
  const contractLineItemId = params.contract_line_item_id as string;
  const { contractLineItemService } = await WebDIContainer();

  const form = await request.formData();
  const canceledAt = form.get("canceled_at") as string;

  const fields = {
    id: contractLineItemId,
    status: form.get("status") as string,
    canceled_at: canceledAt ? new Date(canceledAt) : null,
  };

  const validation = UpdateContractLineItemForm.safeParse(fields);

  if (!validation.success) {
    return jsonWithError(
      { success: false, fields, errors: issuesByKey(validation.error.issues) },
      DEFAULT_FORM_ERROR_MESSAGE
    );
  }

  const newCanceledDate =
    validation.data.status === ContractLineItemStatus.Canceled
      ? validation.data.canceled_at
      : null;

  await contractLineItemService.updateContractLineItemStatus({
    contractLineItemId,
    status: validation.data.status,
    newCanceledDate,
  });

  return jsonWithSuccess(
    { success: true, fields, errors: issuesByKey([]) },
    "Status updated successfully"
  );
}
