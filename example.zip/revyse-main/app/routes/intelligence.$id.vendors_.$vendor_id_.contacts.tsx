import { json } from "@remix-run/node";
import {
  Form,
  Link,
  useActionData,
  useLoaderData,
  useNavigation,
} from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { Permission } from "~/utils/intelligence-permission.utils";
import { useCallback, useEffect, useMemo, useState } from "react";
import { isEmpty, isNil } from "lodash";
import {
  CrudCheckboxField,
  CrudTextField,
  FormSection,
} from "~/components/form/crud-form.component";
import { z } from "zod";
import { ArrowLeftIcon } from "@heroicons/react/24/outline";
import { CTA } from "~/components/cta.component";
import { issuesByKey } from "~/utils/form.utils.server";
import type { Prisma } from "@prisma/client";
import { ManagerAccountVendorContactType } from "@prisma/client";
import { CrudTextAreaField } from "~/components/form/textarea.component";
import { jsonWithError, redirectWithSuccess } from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { capitalize } from "~/utils/string.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

type ContactField = {
  name: FormDataEntryValue | null;
  job_title: FormDataEntryValue | null;
  email: FormDataEntryValue | null;
  phone: FormDataEntryValue | null;
  link?: FormDataEntryValue | null;
  type?: FormDataEntryValue | null;
  notes?: FormDataEntryValue | null;
};

const contactTypes = [
  ManagerAccountVendorContactType.Main,
  ManagerAccountVendorContactType.Support,
  ManagerAccountVendorContactType.Billing,
  ManagerAccountVendorContactType.Internal,
  ManagerAccountVendorContactType.Disposition,
];

const contactTypeTitles = {
  Main: "Main Contact",
  Support: "Support Contact",
  Billing: "Billing Contact",
  Internal: "Internal Relationship Owner",
  Disposition: "Cancellation Notice Contact",
};

const contactTypeDescriptions = {
  Main: "The main contact is typically your account manager or a customer service representative who manages day-to-day requests.",
  Support:
    "The support contact is where you would go for help with the vendor’s product or service.",
  Billing:
    "The billing contact is where you would go with questions about invoicing or payments.",
  Internal:
    "The internal relationship owner is the person at your company who is responsible for managing the vendor relationship.",
  Disposition:
    "The Cancellation Notice Contact is where you would send service cancellation requests or advanced notice for upcoming location dispositions and transitions.",
};

const CommonContactFieldsSchema = {
  name: z.string().optional().or(z.string().nullable()),
  email: z.string().email().or(z.string().max(0)).nullable(),
};

const OtherContactFieldsSchema = {
  job_title: z.string().optional().or(z.string().nullable()),
  phone: z.string().optional().or(z.string().nullable()),
};

const SupportContactFieldsSchema = {
  job_title: z.string().optional().or(z.string().nullable()),
  phone: z.string().optional().or(z.string().nullable()),
  link: z.string().url().or(z.string().max(0)).nullable(),
};

const DispositionContactFieldsContractLineItem = {
  notes: z.string().optional().or(z.string().nullable()),
};

const ManagerAccountVendorContactSchema = z.object({
  contacts: z.object({
    ...Object.fromEntries(
      contactTypes.map(type => [
        type,
        type === ManagerAccountVendorContactType.Support
          ? z
              .object({
                ...CommonContactFieldsSchema,
                ...OtherContactFieldsSchema,
                ...SupportContactFieldsSchema,
              })
              .optional()
          : type === ManagerAccountVendorContactType.Disposition
          ? z.object({
              ...CommonContactFieldsSchema,
              ...DispositionContactFieldsContractLineItem,
            })
          : z
              .object({
                ...CommonContactFieldsSchema,
                ...OtherContactFieldsSchema,
              })
              .optional(),
      ])
    ),
  }),
});

export async function action({ params, request }: ActionFunctionArgs) {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );
  const { managerAccountVendorService } = await WebDIContainer();

  const id = params.vendor_id!;
  const managerAccountId = account.id;

  const form = await request.formData();
  const contactFields: Record<string, ContactField> = {};

  for (const type of contactTypes) {
    contactFields[type] = {
      name: form.get(`contacts.${type}.name`),
      job_title: form.get(`contacts.${type}.job_title`),
      email: form.get(`contacts.${type}.email`),
      phone: form.get(`contacts.${type}.phone`),
      link: form.get(`contacts.${type}.link`),
      notes: form.get(`contacts.${type}.notes`),
      type: type as ManagerAccountVendorContactType,
    };
  }

  const validation = ManagerAccountVendorContactSchema.safeParse({
    contacts: contactFields,
  });

  if (validation.success) {
    await managerAccountVendorService.updateManagerAccountVendorContacts(
      id,
      validation.data.contacts as Record<
        ManagerAccountVendorContactType,
        Prisma.ManagerAccountVendorContactCreateInput
      >
    );

    return redirectWithSuccess(
      `/intelligence/${managerAccountId}/vendors/${id}`,
      "Contacts saved successfully"
    );
  }

  return jsonWithError(
    {
      errors: issuesByKey(validation.error.issues),
      success: false,
      fields: contactFields,
    },
    DEFAULT_FORM_ERROR_MESSAGE
  );
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );
  const { managerAccountVendorService } = await WebDIContainer();

  const id = params.vendor_id!;

  const accountVendor =
    await managerAccountVendorService.getManagerAccountVendor(id, {
      manager_account_vendor_contacts: true,
      vendor: true,
    });

  if (isNil(accountVendor)) {
    throw json("Not Found", { status: 404 });
  }

  let initialValues = {
    contacts: {} as Record<
      "Main" | "Support" | "Billing" | "Internal" | "Disposition",
      ContactField
    >,
  };

  for (const contact of accountVendor.manager_account_vendor_contacts) {
    const type = contact.type;
    initialValues.contacts[type] = {
      name: contact.name,
      job_title: contact.job_title,
      email: contact.email,
      phone: contact.phone,
      link: contact.link,
      notes: contact.notes,
    };
  }

  return json({
    accountVendor,
    initialValues,
  });
}

export default function IntelligenceVendorContactsForm() {
  const { accountVendor, initialValues } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  const navigation = useNavigation();

  const submitting = useMemo(
    () => navigation.state === "submitting",
    [navigation.state]
  );

  const [fields, setFields] = useState(initialValues);

  const [mainAsDispositionChecked, setMainAsDispositionChecked] = useState(
    !isEmpty(initialValues.contacts.Main?.name) &&
      !isEmpty(initialValues.contacts.Main?.email) &&
      initialValues.contacts.Main?.name ===
        initialValues.contacts.Disposition?.name &&
      initialValues.contacts.Main?.email ===
        initialValues.contacts.Disposition?.email
  );

  useEffect(() => {
    if (navigation.state == "idle") {
      window.scrollTo(0, 0);
    }
  }, [navigation.state]);

  const handleFieldUpdate = useCallback(
    (field: string, value: string, type: ManagerAccountVendorContactType) => {
      if (mainAsDispositionChecked && (field === "name" || field === "email")) {
        if (type === ManagerAccountVendorContactType.Main) {
          setFields(oldFields => ({
            ...oldFields,
            contacts: {
              ...oldFields.contacts,
              [ManagerAccountVendorContactType.Disposition]: {
                ...oldFields.contacts[
                  ManagerAccountVendorContactType.Disposition
                ],
                [field]: value,
              },
            },
          }));
        }

        if (type === ManagerAccountVendorContactType.Disposition) {
          setMainAsDispositionChecked(false);
        }
      }

      setFields(oldFields => ({
        ...oldFields,
        contacts: {
          ...oldFields.contacts,
          [type]: {
            ...oldFields.contacts[type],
            [field]: value,
          },
        },
      }));
    },
    [mainAsDispositionChecked]
  );

  const handleMainAsDispositionChecked = (checked: boolean) => {
    setMainAsDispositionChecked(checked);
    if (checked) {
      setFields(oldFields => ({
        ...oldFields,
        contacts: {
          ...oldFields.contacts,
          [ManagerAccountVendorContactType.Disposition]: {
            ...oldFields.contacts[ManagerAccountVendorContactType.Disposition],
            name:
              oldFields.contacts[ManagerAccountVendorContactType.Main]?.name ||
              "",
            email:
              oldFields.contacts[ManagerAccountVendorContactType.Main]?.email ||
              "",
          },
        },
      }));
    }
  };

  return (
    <>
      <div className="space-y-8">
        <IntelligenceScreenHeader
          crumbs={[
            {
              name: "All vendors",
              to: `/intelligence/${accountVendor.manager_account_id}/vendors`,
            },
            {
              name: `${accountVendor.vendor.name}`,
              to: `/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}/`,
            },
            {
              name: "Contacts",
              to: `/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}/contacts`,
              active: true,
            },
          ]}
          title="Contacts"
          description={
            <>
              Manage contact information and document relationships between your
              company and {accountVendor.vendor.name}, including who to reach
              out to for billing questions or where to go for support.
            </>
          }
        />
        <Form method="post">
          <div className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg">
            {contactTypes.map(type => (
              <FormSection
                key={type}
                title={
                  <div className="font-light">
                    <span className="font-semibold">
                      {contactTypeTitles[type]}{" "}
                    </span>
                    <span className="text-gray-400">(Optional)</span>
                  </div>
                }
                subtitle={contactTypeDescriptions[type]}
                spacing="compact"
              >
                {Object.keys(
                  type === ManagerAccountVendorContactType.Support
                    ? {
                        ...CommonContactFieldsSchema,
                        ...OtherContactFieldsSchema,
                        ...SupportContactFieldsSchema,
                      }
                    : type === ManagerAccountVendorContactType.Disposition
                    ? {
                        ...CommonContactFieldsSchema,
                        ...DispositionContactFieldsContractLineItem,
                      }
                    : {
                        ...CommonContactFieldsSchema,
                        ...OtherContactFieldsSchema,
                      }
                ).map((field: string) =>
                  field == "notes" ? (
                    <CrudTextAreaField
                      key={field}
                      field={{
                        name: `contacts.${type}.${field}`,
                        label: capitalize(field),
                        placeholder: `Type your ${field}`,
                        type: "textarea",
                        defaultValue: fields?.contacts?.[
                          type as ManagerAccountVendorContactType
                        ]?.[field] as string,
                        errors:
                          actionData?.errors[`contacts.${type}.${field}`] || [],
                        onChange: e => {
                          handleFieldUpdate(field, e.target.value, type);
                        },
                      }}
                    />
                  ) : (
                    <CrudTextField
                      key={field}
                      field={{
                        name: `contacts.${type}.${field}`,
                        label:
                          field === "job_title"
                            ? "Job Title"
                            : field === "phone"
                            ? "Phone Number"
                            : capitalize(field),
                        type: "text",
                        placeholder:
                          field === "job_title"
                            ? `Type a job title`
                            : field === "phone"
                            ? `Type a phone number`
                            : /[aeiou]/i.test(field[0]) // if vowel
                            ? `Type an ${field}`
                            : `Type a ${field}`,
                        defaultValue: (
                          fields?.contacts?.[
                            type as ManagerAccountVendorContactType
                          ] as Record<string, string>
                        )?.[field],
                        reactiveDefaultValue: true,
                        errors:
                          actionData?.errors[`contacts.${type}.${field}`] || [],
                        maxCharacters: 55,
                        onChange: e => {
                          handleFieldUpdate(field, e.target.value, type);
                        },
                      }}
                    />
                  )
                )}
                {type === ManagerAccountVendorContactType.Main && (
                  <div className="mt-2 col-span-full">
                    <CrudCheckboxField
                      field={{
                        name: `main_as_disposition_contact`,
                        label:
                          "This contact is also the Cancellation Notice Contact",
                        type: "checkbox",
                        defaultChecked: mainAsDispositionChecked,
                        reactiveDefaultChecked: true,
                        errors: actionData?.errors[`main_as_disposition`] || [],
                        tooltipText:
                          "The Cancellation Notice Contact is where you would send service cancellation requests or advanced notice for upcoming location dispositions and transitions.",
                      }}
                      onChange={e => {
                        handleMainAsDispositionChecked(e.target.checked);
                      }}
                    />
                  </div>
                )}
              </FormSection>
            ))}
          </div>
          <div
            className={`my-10 flex justify-around md:justify-between flex-wrap lg:flex-nowrap gap-x-3 ${
              submitting ? "animate-bounce" : ""
            }`}
          >
            <Link
              to={`/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}/`}
              className="text-sky-600 flex items-center"
            >
              <ArrowLeftIcon className="h-5 mr-2" /> Back to vendor overview
            </Link>

            <CTA type="submit" id="save-button" disabled={submitting}>
              {submitting ? "Saving..." : "Save Changes"}
            </CTA>
          </div>
        </Form>
      </div>
    </>
  );
}
