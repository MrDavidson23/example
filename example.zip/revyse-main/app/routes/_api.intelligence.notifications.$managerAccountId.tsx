import { IntelligenceNotificationType } from "@prisma/client";
import {
  json,
  type ActionFunctionArgs,
  type LoaderFunctionArgs,
} from "@remix-run/node";
import { isNil } from "lodash";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assert, assertAuthorized } from "~/utils/assert.utils.server";
import { getUser } from "~/utils/session.server";

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));

  const managerAccountId = params.managerAccountId!;

  const { managerAccountService, intelligenceNotificationService } =
    await WebDIContainer();

  const account = await managerAccountService.getManagerAccount(
    managerAccountId
  );
  assert(!isNil(account), "Account not found");

  const { searchParams } = new URL(request.url);

  const types = (searchParams.get("type")?.split(",") ??
    []) as IntelligenceNotificationType[];
  const archived = searchParams.get("archived") === "true";
  const take = searchParams.get("take")
    ? Number(searchParams.get("take"))
    : undefined;

  const notifications = await intelligenceNotificationService.getNotifications({
    managerAccountId,
    userId: user.id,
    types,
    take,
    archived,
  });

  const notificationCounts =
    await intelligenceNotificationService.getNotificationsCounts({
      managerAccountId,
      userId: user.id,
      types: [IntelligenceNotificationType.TaskMessageMention],
    });

  return json({
    notifications,
    notificationCounts,
  });
};

export const action = async ({ params, request }: ActionFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));

  const managerAccountId = params.managerAccountId!;

  const { managerAccountService, intelligenceNotificationService } =
    await WebDIContainer();

  const account = await managerAccountService.getManagerAccount(
    managerAccountId
  );
  assert(!isNil(account), "Account not found");

  const form = await request.formData();

  const intent = form.get("intent") as string;

  if (intent === "markAllAsRead") {
    await intelligenceNotificationService.markAllNotificationsAsRead(
      managerAccountId,
      user.id
    );
    return json({ success: true });
  }

  const notificationId = form.get("notificationId") as string;

  if (intent === "markAsRead") {
    await intelligenceNotificationService.updateReadNotification(
      notificationId,
      true
    );
  } else if (intent === "markAsUnread") {
    await intelligenceNotificationService.updateReadNotification(
      notificationId,
      false
    );
  } else if (intent === "archive") {
    await intelligenceNotificationService.updateArchivedNotification(
      notificationId,
      true
    );
  } else if (intent === "unarchive") {
    await intelligenceNotificationService.updateArchivedNotification(
      notificationId,
      false
    );
  } else {
    throw new Error("Invalid intent");
  }

  return json({ success: true });
};
