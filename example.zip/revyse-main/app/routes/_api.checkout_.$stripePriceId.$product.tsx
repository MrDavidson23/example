import type { LoaderFunctionArgs } from "@remix-run/node";
import { redirect } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { isNil } from "lodash";
import { getUser } from "~/utils/session.server";

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  try {
    const user = await getUser(request);
    const productId = params.product;
    const stripePriceId = params.stripePriceId;
    const { db, productSubscriptionService } = await WebDIContainer();

    if (!productId) {
      console.log("Cannot checkout for unknown product: ", productId);
      return redirect("/for-vendors");
    }

    const searchParams = new URLSearchParams(new URL(request.url).search);

    const newProductFields = {
      title: searchParams.get("title") || "",
      description: searchParams.get("description") || "",
      slug: searchParams.get("slug") || "",
      primary_category_id: searchParams.get("primary_category_id") || "",
      vendor_id: searchParams.get("vendor_id") || "",
    };

    const stripePrice = await db.stripePrice.findFirst({
      where: { id: stripePriceId, active: true },
    });

    if (isNil(stripePriceId) || isNil(stripePrice)) {
      console.log("Cannot checkout for unknown stripe price", {
        stripePriceId,
      });
      return redirect("/for-vendors");
    }

    if (isNil(user)) {
      return redirect(
        `/sign-up?redirectTo=${encodeURIComponent(
          `/checkout/${stripePriceId}/${productId}`
        )}`
      );
    }
    const session =
      await productSubscriptionService.createSubscriptionCheckoutSession(
        stripePriceId,
        productId,
        user,
        newProductFields
      );

    return redirect(session.url!);
  } catch (error) {
    console.error("Error occurred:", error);
    return redirect("/for-vendors");
  }
};
