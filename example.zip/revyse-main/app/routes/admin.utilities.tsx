import { PortalPage } from "../components/portal-page.component";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { CTA } from "~/components/cta.component";
import type { ActionFunctionArgs } from "@remix-run/node";
import { Form } from "@remix-run/react";
import { UploadCSVForm } from "~/components/intelligence/upload-csv.component";
import { Modal } from "~/components/modal.component";
import { useState } from "react";
import { jsonWithError, jsonWithSuccess } from "remix-toast";
import { AdminUtilityCard } from "~/components/admin/admin-utility-card.component";

export const action = async ({ request }: ActionFunctionArgs) => {
  const {
    circleService,
    contractRenewalService,
    syncCurrentTermEndDateService,
    managerAccountTaskService,
    propexoService,
  } = await WebDIContainer();
  const form = await request.formData();

  if (form.get("syncPosts")) {
    circleService.syncPosts();
    return jsonWithSuccess({ success: true }, "Syncing blog posts from Circle");
  }

  if (form.get("syncContracts")) {
    await syncCurrentTermEndDateService.syncNewCurrentTermEndDates();
    await managerAccountTaskService.updateContractRenewalTaskScheduleStatuses();
    await contractRenewalService.handleContractRenewal();
    return jsonWithSuccess(
      { success: true },
      "Syncing contracts and sending renewal reminders"
    );
  }

  const intent = form.get("intent");
  if (intent === "uploadCSV") {
    const file = form.get("formData");
    const formData = file?.toString() || "";
    const data = JSON.parse(formData);
    const response = await propexoService.syncIntegrationPartners(data);

    if (!response.success) {
      return jsonWithError(
        {
          success: false,
          error: response.message,
        },
        response.message,
        { status: 400 }
      );
    }
    return jsonWithSuccess({ success: true }, response.message);
  }

  return jsonWithError(
    { success: false },
    "There was an error performing the requested action"
  );
};

export default function AdminUtilitiesRoute() {
  const [uploadCSVIntegrations, setUploadCSVIntegrations] = useState(false);

  return (
    <PortalPage
      crumbs={[
        {
          name: "Utilities",
          to: "/admin/utilities",
          active: true,
        },
      ]}
    >
      <Modal
        isOpen={uploadCSVIntegrations}
        onClose={() => setUploadCSVIntegrations(false)}
        size="medium-small"
        manager={true}
      >
        <UploadCSVForm
          actionUrl="/admin/utilities"
          template="/assets/integration_example.csv"
          requiredHeaders="Name, PM Software"
        ></UploadCSVForm>
      </Modal>
      <div className="sm:flex sm:items-center">
        <div className="sm:flex-auto">
          <h1 className="text-base font-semibold leading-6 text-gray-900">
            Utilities
          </h1>
          <p className="mt-1 text-sm text-gray-700">
            Perform actions from the system
          </p>
          <AdminUtilityCard
            title="Sync blog posts from Circle"
            cta={
              <Form method="post">
                <input type="hidden" name="syncPosts" value="syncPosts" />
                <CTA
                  id="sync-posts-button"
                  variant="coral-shadow"
                  className="w-min m-4 font-bold p-4 flex float-left"
                  type="submit"
                >
                  Sync posts
                </CTA>
              </Form>
            }
          />
          <AdminUtilityCard
            title="Sync contracts"
            subtitle="Sync current term end dates and send renewal reminders"
            cta={
              <Form method="post">
                <input
                  type="hidden"
                  name="syncContracts"
                  value="syncContracts"
                />
                <CTA
                  id="sync-contracts-button"
                  variant="coral-shadow"
                  className="w-min m-4 font-bold p-4 flex float-left"
                  type="submit"
                >
                  Sync contracts
                </CTA>
              </Form>
            }
          />
          <AdminUtilityCard
            title="Sync Propexo Integrations"
            cta={
              <CTA
                variant="coral-shadow"
                className="w-min m-4 font-bold p-4 flex float-left"
                type="button"
                onClick={() => setUploadCSVIntegrations(true)}
              >
                Upload CSV
              </CTA>
            }
          />
          <AdminUtilityCard
            title="BullMQ Dashboard"
            subtitle="View and manage BullMQ jobs"
            cta={
              <CTA
                variant="coral-shadow"
                className="w-min m-4 font-bold p-4 flex float-left"
                type="button"
                onClick={() => (window.location.href = "/admin/bull-board")}
              >
                BullMQ Dashboard
              </CTA>
            }
          />
        </div>
      </div>
    </PortalPage>
  );
}
