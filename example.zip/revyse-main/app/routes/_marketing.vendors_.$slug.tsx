import {
  ArrowRightIcon,
  ChevronDownIcon,
  ChevronRightIcon,
  ChevronUpIcon,
} from "@heroicons/react/20/solid";
import {
  BriefcaseIcon,
  CalendarIcon,
  ComputerDesktopIcon,
  MapPinIcon,
  UsersIcon,
  CurrencyDollarIcon,
  TagIcon,
  TvIcon,
  VideoCameraIcon,
} from "@heroicons/react/24/outline";
import {
  IntegrationProvider,
  ProductState,
  Role,
  VendorLastFundingRound,
  VendorState,
} from "@prisma/client";
import type { LoaderFunctionArgs, MetaFunction } from "@remix-run/node";
import { json } from "@remix-run/node";
import { Link, useFetcher, useLoaderData, useNavigate } from "@remix-run/react";
import { useCallback, useEffect, useRef, useState } from "react";
import { Button } from "~/components/button.component";
import { BuyerContactModal } from "~/components/contact-modal.component";
import { CTA } from "~/components/cta.component";
import { Modal } from "~/components/modal.component";
import { Tooltip } from "~/components/tooltip.component";
import { VerifiedIcon } from "~/components/verified-icon.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { getUser } from "~/utils/session.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { isEmpty, orderBy } from "lodash";
import type { action } from "app/routes/_marketing.products_.$slug";
import { Toast } from "~/components/toast.component";
import StatusChip from "~/components/status-chip.component";
import { money } from "~/utils/number.utils";
import {
  tierHasPermission,
  vendorHasPermission,
} from "~/utils/permission.utils";
import { VendorHeader } from "~/components/vendor-header.component";
import {
  type PRODUCT_PERKS_KEYS,
  VendorLastFundingRoundLabels,
  VendorTotalRoundsLabels,
} from "~/utils/constants.utils";
import { VendorProductCard } from "~/components/vendor-product-card.component";
import { ListingCard } from "~/components/discovery/listing-card.component";
dayjs.extend(utc);

export async function loader({ params, request }: LoaderFunctionArgs) {
  const {
    db,
    productService,
    managerAccountVendorService,
    vendorService,
    stripeService,
  } = await WebDIContainer();
  const user = await getUser(request);

  const vendor = await vendorService.getVendorForDiscovery({
    slug: params.slug!,
  });

  const vendorRating = await managerAccountVendorService.getVendorRating(
    vendor.id
  );

  const freePrice = await stripeService.getFreeStripePriceId();

  const hasUpgradedListing = await vendorHasPermission(
    vendor,
    "can_be_contacted"
  );

  const productIds = (
    await db.product.findMany({
      select: { id: true },
      where: {
        vendor_id: vendor.id,
        approved_at: { not: null },
        state: ProductState.discovery,
        vendor: { state: VendorState.ApprovedForPublishing },
      },
    })
  ).map(p => p.id);
  const productsWithRatings = await productService.getProductsWithRatings({
    ids: productIds,
  });

  const product = await vendorService.getVendorProductWithSpecialOffer({
    vendorId: vendor.id,
  });

  const vendorProductPerks: (keyof typeof PRODUCT_PERKS_KEYS)[] = [];

  const productsWithSubscription = productsWithRatings.filter(
    p => p.subscriptions.length > 0
  );

  if (
    productsWithSubscription.find(
      p => p.promo_text && tierHasPermission(p.tier, "show_promo")
    )
  ) {
    vendorProductPerks.push("promos");
  }
  if (
    productsWithSubscription.find(
      p =>
        ((p.demo_storylane_url !== null && p.demo_storylane_url.length > 0) ||
          p._count.demo_files > 0) &&
        tierHasPermission(p.tier, "show_demos")
    )
  ) {
    vendorProductPerks.push("demos");
  }
  if (
    productsWithSubscription.find(
      p => p._count.packages > 0 && tierHasPermission(p.tier, "show_pricing")
    )
  ) {
    vendorProductPerks.push("pricing");
  }
  if (
    productsWithSubscription.find(
      p =>
        p._count.brand_video_files > 0 &&
        tierHasPermission(p.tier, "show_brand_videos")
    )
  ) {
    vendorProductPerks.push("videos");
  }

  const userRole = user?.id
    ? await db.userRole.findFirst({
        where: {
          user_id: user.id,
          resource_id: product.activeSubscription?.id,
        },
        orderBy: { created_at: "desc" },
        include: { product_subscription: { include: { product: true } } },
      })
    : null;

  const verifiedBuyer =
    user?.user_roles.some(ur => ur.role === Role.BUYER) || userRole;

  const lastVerified = new Date(
    Math.max(
      ...(vendor.vendor_integrations?.map(integration =>
        (integration.last_verified_at || new Date(0)).getTime()
      ) || []),
      new Date(0).getTime()
    )
  );

  return json({
    user,
    verifiedBuyer,
    lastVerified,
    vendor: {
      ...vendor,
      product_perks: vendorProductPerks,
    },
    vendorRating,
    product: product.product,
    products: productsWithRatings,
    activePlan: product.activeSubscription?.stripe_price.product,
    hasUpgradedListing,
    freePrice,
  });
}

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  const vendor = data!.vendor;
  return [
    { title: `${vendor.name} Products and Services` },
    {
      name: "description",
      content: `Shop for ${vendor.name} products and services on Revyse. Compare features, read verified reviews, and view popular alternatives`,
    },
  ];
};

export default function VendorSlugRoute() {
  const {
    vendor,
    vendorRating,
    lastVerified,
    product,
    products,
    user,
    verifiedBuyer,
    activePlan,
    hasUpgradedListing,
    freePrice,
  } = useLoaderData<typeof loader>();
  const navigate = useNavigate();

  const integrationPartnersSection = useRef<HTMLHeadingElement>(null);
  const companyInfoSection = useRef<HTMLHeadingElement>(null);
  const productsSection = useRef<HTMLHeadingElement>(null);
  const financialsSection = useRef<HTMLHeadingElement>(null);

  const [contactModalOpen, setContactModalOpen] = useState(false);
  const [contactModalText, setContactModalText] = useState<
    string | undefined
  >();
  const hasFinancialInfo =
    vendor.last_funding_round !== VendorLastFundingRound.NotSet ||
    vendor.total_funding !== null ||
    vendor.total_rounds !== null;
  const [verifiedBuyerModalOpen, setVerifiedBuyerModalOpen] = useState(false);
  const [showAllIntegrationPartners, setShowAllIntegrationPartners] =
    useState(false);
  const [productList, setProductList] = useState(products);

  const fetcher = useFetcher<typeof action>();

  const visibleIntegrationPartners = showAllIntegrationPartners
    ? vendor.vendor_integrations
    : vendor.vendor_integrations.slice(0, 8);

  const onContactClick = (altText?: string) => {
    if (verifiedBuyer) {
      setContactModalText(altText);
      setContactModalOpen(true);
    } else if (user) {
      setVerifiedBuyerModalOpen(true);
    } else {
      navigate(
        `/sign-up?intent=BUYER&redirectTo=${encodeURIComponent(
          `/products/${product?.slug}`
        )}`
      );
    }
  };

  const handleLinkClick = useCallback(
    (ref: React.RefObject<HTMLElement>, position?: ScrollLogicalPosition) => {
      if (ref.current) {
        ref.current.scrollIntoView({
          behavior: "smooth",
          block: position ?? "center",
        });
      }
    },
    []
  );

  useEffect(() => {
    let items = [...products];
    items = orderBy(
      items,
      [
        product => {
          switch (product.tier) {
            case "tier_3":
              return 1;
            case "tier_2":
              return 2;
            case "tier_1":
              return 3;
            case "free":
              return 4;
            default:
              return 5;
          }
        },
        "totalReviews",
        "avgReview",
      ],
      ["asc", "desc", "desc"]
    );
    setProductList(items.slice(0, 4));
  }, [products]);

  return (
    <>
      <Modal
        isOpen={verifiedBuyerModalOpen}
        onClose={() => setVerifiedBuyerModalOpen(false)}
        size="medium-small"
      >
        {fetcher.data?.success !== undefined && (
          <Toast
            variant={fetcher.data?.success ? "success" : "error"}
            message={
              fetcher.data?.success
                ? "Success! Buyer Verification Request has been sent"
                : "There were requesting your Buyer Verification. Please try again."
            }
          />
        )}
        <fetcher.Form method="post" action={`/products/${product?.slug}`}>
          <input type="hidden" name="intent" value="verify-account" />
          <h2 className="text-2xl font-bold mb-4">Verify My Account </h2>
          <div>
            Are you a real estate professional shopping for software and
            services?
          </div>
          <br />
          <div>
            Become a verified buyer on Revyse (it’s free!) and get unrestricted
            access to product listings across the platform. Easily see pricing,
            view self-guided product tours, and schedule demos with the click of
            a button.
          </div>
          <br />
          <div>
            Click “Request Buyer Verification” below to submit your info and
            we’ll get you access in no time.
          </div>
          <div className="flex justify-center py-8">
            <CTA
              type="submit"
              variant="coral-shadow"
              className={`${
                fetcher.state === "submitting" ? "animate-bounce" : ""
              }`}
            >
              {fetcher.state === "submitting"
                ? "Sending your request..."
                : "Request Buyer Verification"}
            </CTA>
          </div>
        </fetcher.Form>
      </Modal>
      {contactModalOpen && (
        <BuyerContactModal
          isOpen={contactModalOpen}
          onClose={() => setContactModalOpen(false)}
          activePlan={activePlan}
          product={product}
          descriptionText={contactModalText}
        />
      )}
      <div className="flex justify-center">
        <div className="w-full lg:max-w-7xl md:px-6 overflow-clip">
          <div className="flex flex-wrap items-center uppercase text-sm py-6 px-2 md:px-0">
            <Link to="/">HOME</Link>
            <ChevronRightIcon className="h-4" />
            <Link to="/vendors">ALL VENDORS</Link>
            <ChevronRightIcon className="h-4" />
            <Link to={`/vendors/${vendor.slug}`} className="font-bold">
              {vendor.name}
            </Link>
          </div>
          <div className="md:rounded-2xl shadow-sm bg-white pb-6 mb-5">
            <div className="rounded-t-2xl overflow-clip mb-10">
              <VendorHeader
                showCTA={true}
                vendor={vendor}
                vendorRating={vendorRating}
              />
            </div>
            <div className="md:flex px-2 md:px-12 w-full justify-center gap-x-4 md:gap-x-8">
              <div className="md:flex flex-col text-sm hidden bg-white gap-4">
                <Button
                  color="transparent"
                  onClick={() => handleLinkClick(companyInfoSection)}
                  className="text-left text-sky-500 font-normal flex justify-start p-0"
                >
                  Company Information
                </Button>
                {hasFinancialInfo && (
                  <Button
                    color="transparent"
                    onClick={() => handleLinkClick(financialsSection)}
                    className="text-left text-sky-500 font-normal flex justify-start p-0"
                  >
                    Financials
                  </Button>
                )}
                {visibleIntegrationPartners &&
                  visibleIntegrationPartners.length > 0 && (
                    <Button
                      color="transparent"
                      onClick={() =>
                        handleLinkClick(integrationPartnersSection)
                      }
                      className="text-left text-sky-500 font-normal flex justify-start p-0"
                    >
                      Integration Partners
                    </Button>
                  )}
                <Link
                  id="view-all-products-link"
                  to={`/vendors/${vendor.slug}/products`}
                  className="flex items-center text-coral mt-10"
                >
                  View All Products <ArrowRightIcon className="h-4 ml-2" />
                </Link>
              </div>
              <div className="px-6 lg:px-8 w-full md:w-9/12 lg:w-10/12 space-y-7">
                {product && product.promo_text && (
                  <div className="bg-themeLightYellow border-l-4 border-themeYellow p-4 flex flex-wrap md:flex-nowrap justify-between items-center">
                    <div>
                      <p>Exclusive offer for {product.title} through Revyse</p>
                      <p className="text-2xl font-medium italic text-montserrat">
                        {product.promo_text}
                      </p>
                    </div>
                    <CTA
                      className="mt-4 md:mt-0"
                      fillStyle="outline"
                      onClick={() =>
                        onContactClick(
                          `Reach out to ${vendor.name} and let them know that you’re interested in learning more about ${product.title}’s featured offer on Revyse.`
                        )
                      }
                    >
                      Claim Offer
                    </CTA>
                  </div>
                )}
                <ListingCard>
                  <>
                    <h2
                      className="text-lg lg:text-2xl font-medium leading-tight"
                      ref={companyInfoSection}
                    >
                      Company Information
                    </h2>
                    <hr className="my-5" />
                    <div className="text-sm lg:text-base font-normal text-balance">
                      {vendor.description}
                    </div>
                    <div className="grid grid-flow-row grid-cols-1 mt-7 lg:grid-cols-3">
                      <div className="pl-8 relative mb-2 md:mb-6">
                        <MapPinIcon className="h-6 absolute left-0" />
                        <div className="font-medium mb-1">HQ Location</div>
                        <div className="text-sm">
                          {vendor.hq_location ?? "--"}
                        </div>
                      </div>

                      <div className="pl-8 relative mb-2 md:mb-6">
                        <CalendarIcon className="h-6 absolute left-0" />
                        <div className="font-medium mb-1">Year Founded</div>
                        <div className="text-sm">
                          {vendor.founded_year ?? "--"}
                        </div>
                      </div>

                      <div className="pl-8 relative mb-2 md:mb-6">
                        <UsersIcon className="h-6 absolute left-0" />
                        <div className="font-medium mb-1">
                          Number of Employees
                        </div>
                        <div className="text-sm">
                          {vendor.number_employees ?? "--"}
                        </div>
                      </div>

                      <div className="pl-8 relative mb-2 md:mb-6">
                        <BriefcaseIcon className="h-6 absolute left-0" />
                        <div className="font-medium mb-1">Company Status</div>
                        <div className="text-sm">
                          {vendor.company_status ?? "--"}
                        </div>
                      </div>

                      <div className="pl-8 relative mb-2 md:mb-6">
                        <ComputerDesktopIcon className="h-6 absolute left-0" />
                        <div className="font-medium mb-1">Company Website</div>
                        {vendor.website ? (
                          <Link
                            to={vendor.website}
                            className="text-sm text-sky-500"
                            target="_blank"
                          >
                            <p className="w-full truncate">
                              {vendor.website.replace(/https?:\/\//, "")}
                            </p>
                          </Link>
                        ) : (
                          <span>--</span>
                        )}
                      </div>

                      <div className="pl-8 relative mb-2 md:mb-6">
                        <img
                          src="/assets/linkedin-icon.png"
                          alt="linkedin icon"
                          className="h-6 w-auto absolute left-0"
                          width="32"
                          height="32"
                        />
                        <div className="font-medium mb-1">LinkedIn Profile</div>
                        {vendor.linkedin_profile_url ? (
                          <Link
                            to={vendor.linkedin_profile_url}
                            className="text-sm text-sky-500"
                          >
                            <p className="w-full truncate">
                              {vendor.linkedin_profile_url.replace(
                                /https?:\/\//,
                                ""
                              )}
                            </p>
                          </Link>
                        ) : (
                          <span>--</span>
                        )}
                      </div>
                    </div>
                  </>
                </ListingCard>
                {hasFinancialInfo && (
                  <ListingCard>
                    <>
                      <h2
                        className="text-lg lg:text-2xl font-medium leading-tight"
                        ref={financialsSection}
                      >
                        Financials
                      </h2>
                      <hr className="my-5" />
                      <div className="grid grid-flow-row space-y-3 mt-7 lg:grid-cols-3 lg:space-y-0 lg:space-x-2">
                        {vendor.last_funding_round !==
                          VendorLastFundingRound.NotSet && (
                          <div className="flex flex-col space-y-2 items-center justify-center ">
                            <div className="font-medium mb-1">
                              Last Funding Round
                            </div>
                            <StatusChip
                              color="black"
                              label={
                                VendorLastFundingRoundLabels[
                                  vendor.last_funding_round
                                ]
                              }
                              className="font-normal"
                            />
                          </div>
                        )}
                        {vendor.total_rounds !== null && (
                          <div className="flex flex-col space-y-2 items-center justify-center ">
                            <div className="font-medium mb-1">Total Rounds</div>
                            <StatusChip
                              color="black"
                              label={
                                VendorTotalRoundsLabels[vendor.total_rounds]
                              }
                              className="font-normal"
                            />
                          </div>
                        )}
                        {vendor.total_funding !== null && (
                          <div className="flex flex-col space-y-2 items-center justify-center ">
                            <div className="font-medium mb-1">
                              Total Funding
                            </div>
                            <StatusChip
                              color="black"
                              label={money(vendor.total_funding)}
                              className="font-normal"
                            />
                          </div>
                        )}
                      </div>
                    </>
                  </ListingCard>
                )}
                {visibleIntegrationPartners &&
                  visibleIntegrationPartners.length > 0 && (
                    <ListingCard>
                      <>
                        <h2
                          className="text-lg lg:text-2xl font-medium leading-tight"
                          ref={integrationPartnersSection}
                        >
                          Integration Partners
                        </h2>
                        <hr className="my-5" />
                        <div className="text-sm lg:text-base font-normal text-balance">
                          See if {vendor.name} connects with your favorite
                          tools. For product-to-product integrations or
                          technical questions, reach out to {vendor.name} for
                          more information.
                        </div>
                        <div className="grid lg:grid-cols-2 gap-3 mt-7">
                          {visibleIntegrationPartners.map((t, i) => (
                            <div
                              key={i}
                              className="rounded-lg border border-gray-100 p-6 flex mb-2 space-x-3"
                            >
                              <div className="relative row-span-2 w-max">
                                {t.integrated_vendor?.logo_file_id ||
                                t.integrated_product?.logo_file_id ? (
                                  <img
                                    className="w-12 h-12 lg:w-16 lg:h-16 rounded-lg"
                                    src={`/images/${
                                      t.integrated_vendor?.logo_file_id ||
                                      t.integrated_product?.logo_file_id
                                    }`}
                                    alt="Vendor Logo"
                                    width="64"
                                    height="64"
                                  />
                                ) : (
                                  <img
                                    className="w-12 h-12 lg:w-16 lg:h-16 rounded-lg"
                                    src="/assets/default-logo.png"
                                    alt="Vendor Logo"
                                    width="64"
                                    height="64"
                                  />
                                )}
                                <VerifiedIcon className="h-5 lg:h-6 absolute top-[-0.5rem] right-[-0.5rem]" />
                              </div>
                              <div className="flex flex-col justify-center">
                                <div className="font-medium">
                                  {t.integrated_vendor?.name ||
                                    t.integrated_product?.title}
                                </div>
                                <div className="font-light text-sm text-gray-400">
                                  <span className="inline-block align-middle mr-1">
                                    Data provided by{" "}
                                  </span>
                                  <Tooltip
                                    position="top"
                                    text={
                                      <div>
                                        {t.integration_provider ===
                                        IntegrationProvider.Propexo ? (
                                          <div>
                                            This integration data is provided by
                                            Propexo, a third-party vendor who
                                            verifies and updates industry data
                                            quarterly. <br /> <br /> Learn more
                                            at{" "}
                                            <a
                                              className="underline"
                                              href="https://www.propexo.com/"
                                              target="_blank"
                                              rel="noreferrer"
                                            >
                                              propexo.com
                                            </a>
                                          </div>
                                        ) : (
                                          <div>
                                            This integration data is validated
                                            by the vendor and updated by Revyse.
                                          </div>
                                        )}
                                      </div>
                                    }
                                  >
                                    <div className="cursor-pointer w-max">
                                      <b className="text-sky-500">
                                        {t.integration_provider}
                                      </b>
                                    </div>
                                  </Tooltip>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="flex justify-between items-center">
                          <div className="font-light text-sm text-gray-400">
                            Last verified{" "}
                            {dayjs.utc(lastVerified).format("MM/DD/YYYY")}
                          </div>
                          {vendor.vendor_integrations &&
                            vendor.vendor_integrations?.length > 8 && (
                              <div>
                                {showAllIntegrationPartners ? (
                                  <button
                                    className="font-medium text-sky-500 flex items-center"
                                    onClick={() => {
                                      handleLinkClick(
                                        integrationPartnersSection
                                      );
                                      setShowAllIntegrationPartners(false);
                                    }}
                                  >
                                    Show Less
                                    <ChevronUpIcon className="h-5" />
                                  </button>
                                ) : (
                                  <button
                                    className="font-medium text-sky-500 flex items-center"
                                    onClick={() =>
                                      setShowAllIntegrationPartners(true)
                                    }
                                  >
                                    Show More
                                    <ChevronDownIcon className="h-5" />
                                  </button>
                                )}
                              </div>
                            )}
                        </div>
                      </>
                    </ListingCard>
                  )}
                <ListingCard>
                  <>
                    <div className="flex flex-row justify-between items-center">
                      <h2
                        className="text-lg lg:text-2xl font-medium leading-tight"
                        ref={productsSection}
                      >
                        Products and Services
                      </h2>
                      <div className="flex flex-wrap lg:flex-nowrap justify-center space-y-2 lg:space-y-0">
                        {isEmpty(vendor.products) ? (
                          <Link
                            className="text-sm text-sky-500 lg:ml-3"
                            to={`/vendor/products/new?stripePriceId=${freePrice?.id}&vendor_id=${vendor.id}`}
                          >
                            Is this your business? Click here to create your
                            first product listing.
                          </Link>
                        ) : (
                          <CTA
                            className="lg:ml-3"
                            to={`/vendors/${vendor.slug}/products`}
                            id="view-all-products-secondary"
                          >
                            View All Products
                          </CTA>
                        )}
                      </div>
                    </div>
                    <hr className="my-5" />
                    <div className="text-sm lg:text-base font-normal text-balance">
                      Shop the products and services offered by {vendor.name}.
                      Compare features, read verified user reviews,{" "}
                      {hasUpgradedListing
                        ? `and contact ${vendor.name} directly with the click of a button.`
                        : "and view popular alternatives."}
                    </div>
                    <div className="space-y-8 mt-7">
                      {productList.map(p => (
                        <VendorProductCard
                          key={p.id}
                          product={{
                            ...p,
                            vendor_name: p.vendor!.name,
                            vendor_logo_file_id: p.vendor!.logo_file_id,
                            logo_file_id: p.logo_file_id,
                            avg_score: p.avgReview,
                            cnt: p.totalReviews,
                          }}
                          tags={[
                            ...(p._count.packages > 0 &&
                            tierHasPermission(p.tier, "show_pricing")
                              ? [
                                  {
                                    label: "Published Pricing",
                                    icon: CurrencyDollarIcon,
                                  },
                                ]
                              : []),
                            ...(p.promo_text &&
                            tierHasPermission(p.tier, "show_promo")
                              ? [
                                  {
                                    label: "Featured Promotions",
                                    icon: TagIcon,
                                  },
                                ]
                              : []),
                            ...(p._count.brand_video_files > 0 &&
                            tierHasPermission(p.tier, "show_brand_videos")
                              ? [{ label: "Has Videos", icon: VideoCameraIcon }]
                              : []),
                            ...(tierHasPermission(p.tier, "show_demos") &&
                            ((p.demo_storylane_url !== null &&
                              p.demo_storylane_url.length > 0) ||
                              p._count.demo_files > 0)
                              ? [{ label: "Self-Guided Demos", icon: TvIcon }]
                              : []),
                          ]}
                        />
                      ))}
                    </div>
                    <div className="flex items-center justify-between mt-9">
                      <span className="text-sm font-light">
                        Showing {productList.length} of <b>{products.length}</b>{" "}
                        results
                      </span>

                      <Link
                        id="view-all-products-pagination"
                        to={`/vendors/${vendor.slug}/products`}
                        className="flex items-center text-sky-500"
                      >
                        View All Products{" "}
                        <ArrowRightIcon className="h-4 ml-2" />
                      </Link>
                    </div>
                  </>
                </ListingCard>
              </div>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
