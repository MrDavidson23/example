import { json } from "@remix-run/node";
import { Link, useFetcher, useLoaderData } from "@remix-run/react";
import type { LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { CTA } from "~/components/cta.component";
import { Permission } from "~/utils/intelligence-permission.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { Button } from "~/components/button.component";
import { ArrowLeftIcon } from "@heroicons/react/20/solid";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import {
  jsonWithError,
  jsonWithSuccess,
  redirectWithSuccess,
  redirectWithWarning,
} from "remix-toast";
import { IntelligenceFilter } from "~/components/intelligence/intelligence-filter.component";
import { Table } from "~/components/intelligence/table.component";
import {
  CheckCircleIcon,
  ExclamationTriangleIcon,
} from "@heroicons/react/24/solid";
import { Tooltip } from "~/components/tooltip.component";
import { RevysePencilIcon } from "~/components/revyse-pencil-icon.component";
import { EditContactModal } from "~/components/intelligence/location-notices/edit-contact-modal.component";
import { useMemo, useState } from "react";
import { InformationCircleIcon } from "@heroicons/react/24/outline";
import {
  LocationNoticeStatus,
  ManagerAccountVendorContactType,
} from "@prisma/client";
import { WizardModal } from "~/components/modals/wizard-modal.component";
import { isEmpty } from "lodash";

const UpdateContactForm = z.object({
  name: z.string().nullish(),
  email: z.string().email(),
  managerAccountVendorId: z.string().uuid(),
});

const ContinueForm = z.object({
  vendorIds: z.array(z.string().uuid()),
});

export async function action({ request, params }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocationNotices],
      locationId: params.location_id,
    }
  );

  const { locationNoticeService, managerAccountVendorService } =
    await WebDIContainer();

  const form = await request.formData();

  const intent = form.get("intent") as string;

  const locationNoticeId = params.location_notice_id!;

  if (intent === "update-contact") {
    const fields = {
      name: form.get("name") as string,
      email: form.get("email") as string,
      managerAccountVendorId: form.get("managerAccountVendorId") as string,
    };

    const validation = UpdateContactForm.safeParse(fields);

    if (!validation.success) {
      return jsonWithError(
        { success: false, errors: issuesByKey(validation.error.errors) },
        DEFAULT_FORM_ERROR_MESSAGE
      );
    }

    await managerAccountVendorService.updateManagerAccountVendorContacts(
      fields.managerAccountVendorId,
      {
        [ManagerAccountVendorContactType.Disposition]: {
          name: fields.name,
          email: fields.email,
        },
      }
    );

    return jsonWithSuccess(
      {
        success: true,
        fields,
      },
      "Contact updated successfully"
    );
  }

  if (intent === "continue" || intent === "save-progress") {
    const vendorIds = form.get("vendorIds") as string;

    const fields = {
      vendorIds: !isEmpty(vendorIds) ? vendorIds.split(",") : [], // comma separated string
    };

    const validation = ContinueForm.safeParse(fields);

    if (!validation.success) {
      return jsonWithError(
        { success: false, errors: issuesByKey(validation.error.errors) },
        DEFAULT_FORM_ERROR_MESSAGE
      );
    }

    const managerAccountRoleId = user.manager_account_roles.find(
      role => role.manager_account_id === account.id
    )!.id;

    await locationNoticeService.upsertLocationNoticeDispositionRecipients(
      locationNoticeId,
      validation.data.vendorIds,
      managerAccountRoleId,
      intent === "save-progress"
    );

    if (intent === "save-progress") {
      return redirectWithSuccess(
        `/intelligence/${account.id}/locations/${params.location_id}/notices`,
        "Progress saved successfully"
      );
    }

    return redirectWithSuccess(
      `/intelligence/${account.id}/locations/${params.location_id}/notices/${locationNoticeId}/location-disposition/emailtemplate`,
      "Recipients configured successfully"
    );
  }
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocationNotices],
      locationId: params.location_id,
    }
  );

  const { locationService, locationNoticeService } = await WebDIContainer();

  const location = await locationService.getLocation(params.location_id!);

  if (!location) {
    throw new Response("Location not found", { status: 404 });
  }

  const locationNoticeId = params.location_notice_id!;

  const locationNotice =
    await locationNoticeService.getLocationNoticeDisposition(
      locationNoticeId,
      location.id,
      user,
      account
    );

  if (!locationNotice) {
    throw new Response("Location notice not found", { status: 404 });
  }

  if (locationNotice?.status === LocationNoticeStatus.Sent) {
    return redirectWithWarning(
      `/intelligence/${account.id}/locations/${location.id}/notices/${locationNoticeId}/location-disposition`,
      "Location notice has already been sent"
    );
  }

  if (locationNotice.original_location_notice_id) {
    return redirectWithWarning(
      `/intelligence/${account.id}/locations/${location.id}/notices/${locationNoticeId}/location-disposition`,
      "This is an updated notice, and you cannot edit the recipients"
    );
  }

  const vendors = await locationNoticeService.getVendorRecipientsOptions(
    location.id,
    user,
    account
  );

  return json({
    user,
    account,
    location,
    vendors,
    locationNotice,
  });
}

export default function LocationDispositionNoticeRecipients() {
  const { account, location, vendors, locationNotice } =
    useLoaderData<typeof loader>();

  const [vendorToEdit, setVendorToEdit] = useState<
    (typeof vendors)[number] | null
  >(null);

  const [selectedVendors, setSelectedVendors] = useState<typeof vendors>(
    vendors.filter(v =>
      locationNotice.location_notice_recipients.some(
        r => r.manager_account_vendor_id === v.id
      )
    )
  );

  const fetcher = useFetcher<{ success: boolean }>();

  const [confirmationModalStep, setConfirmationModalStep] = useState<
    "missing-vendors-info" | "not-all-vendors-selected" | undefined
  >(undefined);

  const selectedVendorContacts = useMemo(
    () =>
      selectedVendors.map(v => {
        const contact = vendors.find(vendor => vendor.id === v.id)?.contact;
        return contact;
      }),
    [selectedVendors, vendors]
  );

  const submit = (intent: string, skipChecks?: boolean) => {
    if (intent === "continue" && !skipChecks) {
      if (selectedVendorContacts.some(v => !v || !v.email)) {
        setConfirmationModalStep("missing-vendors-info");
        return;
      }

      if (selectedVendors.length < vendors.length) {
        setConfirmationModalStep("not-all-vendors-selected");
        return;
      }
    }

    const formData = new FormData();

    formData.append("vendorIds", selectedVendors.map(v => v.id).join(","));
    formData.append("intent", intent);

    fetcher.submit(formData, {
      method: "POST",
    });
  };

  const [searchQuery, setSearchQuery] = useState<string>("");

  const filteredVendors = useMemo(
    () =>
      vendors.filter(v =>
        v.vendor.name.toLowerCase().includes(searchQuery.toLowerCase())
      ),
    [vendors, searchQuery]
  );

  return (
    <>
      <WizardModal
        isOpen={!!confirmationModalStep}
        onClose={() => setConfirmationModalStep(undefined)}
        steps={[
          {
            id: "missing-vendors-info",
            icon: "warningRed",
            title: (
              <span className="text-xl">
                There is missing contact info for{" "}
                <span className="text-red-500">
                  {
                    selectedVendors.filter(v => !v.contact || !v.contact.email)
                      .length
                  }
                </span>{" "}
                of your selected vendors. Please review and update the contacts.
              </span>
            ),
            body: "To add missing contact information for your vendors, click on the blue “Edit” icon in the corresponding row, and add an email address.",
            ctas: {
              primary: {
                label: "Add contact info",
                onClick: () => {
                  setConfirmationModalStep(undefined);
                },
              },
              secondary: {
                label: "Return to select recipients",
              },
            },
          },
          {
            id: "not-all-vendors-selected",
            icon: "warningRed",
            title: (
              <span className="text-xl">
                You have selected{" "}
                <span className="text-red-500">{selectedVendors.length}</span>/
                {vendors.length} vendors to receive the location disposition
                notice. Do you wish to proceed?
              </span>
            ),
            body: `Not all vendors assigned to ${location.name} will receive the notice. To select additional vendors, click “Return to select recipients.” To include only the vendors currently selected, click “I’m sure.” `,
            ctas: {
              primary: {
                label: "Yep, I’m sure",
                onClick: () => {
                  setConfirmationModalStep(undefined);
                  submit("continue", true);
                },
              },
              secondary: {
                label: "Return to select recipients",
              },
            },
          },
        ]}
        initialStepId={confirmationModalStep}
        fetcher={fetcher}
      />
      <EditContactModal
        open={!!vendorToEdit}
        onClose={() => setVendorToEdit(null)}
        contract={vendorToEdit?.contact || { name: null, email: null }}
        vendorName={vendorToEdit?.vendor.name || ""}
        managerAccountVendorId={vendorToEdit?.id || ""}
      />
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
          },
          {
            name: "Notices",
            to: `/intelligence/${account.id}/locations/${location.id}/notices`,
          },
          {
            name: "Configure disposition details",
            to: `/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/location-disposition/details`,
          },
          {
            name: "Select recipients",
            to: `/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/location-disposition/recipients`,
            active: true,
          },
        ]}
        title={
          <>
            Select vendor recipients: <br /> {location.name}
          </>
        }
        description={`Select the vendors to be notified from the list of active assigned vendors below. If a vendor’s contact information has not yet been added, click “Edit” in the corresponding row to add it.`}
        buttonsSlot={<CTA onClick={() => submit("continue")}>Continue</CTA>}
      />
      <IntelligenceFilter
        filterBar={{
          inputPlaceholder: "Search vendors",
        }}
        onFilter={({ searchQuery }) => {
          setSearchQuery(searchQuery || "");
        }}
      ></IntelligenceFilter>
      <Table
        selectColumnPosition="start"
        selectAllInColumn={true}
        alignment="middle"
        cols={[
          {
            label: "Vendor Name",
            name: "vendor.name",
          },
          {
            label: (
              <span>
                Contact Name
                <Tooltip
                  position="bottom"
                  text="If the Cancellation Notice Contact has been populated, we’ll display that info here. If it hasn’t, we’ll display your Main Contact’s info. If neither contact has been populated, this column will be blank."
                >
                  <InformationCircleIcon className="h-5 ml-1" />
                </Tooltip>
              </span>
            ),
            name: "contact.name",
          },
          {
            label: (
              <span>
                Contact Email
                <Tooltip
                  position="bottom"
                  text="If the Cancellation Notice Contact has been populated, we’ll display that info here. If it hasn’t, we’ll display your Main Contact’s info. If neither contact has been populated, this column will be blank."
                >
                  <InformationCircleIcon className="h-5 ml-1" />
                </Tooltip>
              </span>
            ),
            name: "contact.email",
          },
          {
            label: "",
            renderer: vendor => {
              if (vendor.contact && vendor.contact.email) {
                return <CheckCircleIcon className="h-7 w-7 text-green-500" />;
              } else {
                return (
                  <Tooltip
                    text="Missing contact info"
                    position="top"
                    size="small"
                  >
                    <ExclamationTriangleIcon className="h-7 w-7 text-red-500" />
                  </Tooltip>
                );
              }
            },
          },
          {
            label: "",
            renderer: vendor => {
              return (
                <div className="flex h-full justify-end pr-4 sm:pr-6">
                  <Button
                    onClick={e => {
                      e.stopPropagation();
                      setVendorToEdit(vendor);
                    }}
                    color="transparent"
                    className="gap-x-2 px-0"
                  >
                    <RevysePencilIcon className="h-5" />
                    Edit
                  </Button>
                </div>
              );
            },
            columnClassName: "w-sm",
          },
        ]}
        data={searchQuery ? filteredVendors : vendors}
        initialSelectedRows={selectedVendors}
        onSelectRows={setSelectedVendors}
      />
      <footer className="flex justify-between items-center mt-4">
        <div>
          <Link
            to={`/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/location-disposition/details`}
            className="text-sky-500 flex items-center text-sm"
          >
            <ArrowLeftIcon className="h-5 mr-2" /> Back to disposition notice
            details
          </Link>
        </div>
        <div className="flex gap-x-2">
          <Button color="transparent" onClick={() => submit("save-progress")}>
            Save Progress
          </Button>
          <CTA onClick={() => submit("continue")}>Continue</CTA>
        </div>
      </footer>
    </>
  );
}
