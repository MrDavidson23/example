import type { LoaderFunctionArgs } from "@remix-run/node";
import dayjs from "dayjs";
import JSZip from "jszip";
import type { Readable } from "stream";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { Permission } from "~/utils/intelligence-permission.utils";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ExportLocationDocuments],
      locationId: params.location_id,
    }
  );
  const { locationService, s3Service } = await WebDIContainer();
  const location = await locationService.getLocation(params.location_id!);

  if (!location) {
    throw new Response("Location not found", { status: 404 });
  }

  const { data: items } =
    await locationService.getLocationContractsWithDocuments(
      user,
      account,
      params.location_id!,
      {}
    );

  const allDocuments = items.flatMap(item => item.documents);
  const zip = new JSZip();
  let zipData = null;
  const today = dayjs().format("YYYY-MM-DD");

  const folder = zip.folder(`${location.name}_Documents_${today}.zip`);

  if (!folder) {
    throw new Error("Error creating folder");
  }

  for (const document of allDocuments) {
    const fileName = document.name;
    const file = document.file;

    const response = await s3Service.getObject(file.uri);
    const chunks: Uint8Array[] = [];
    for await (const chunk of response.Body as Readable) {
      chunks.push(chunk);
    }
    const ext = file.uri.split(".").pop() ?? "";
    const buffer = Buffer.concat(chunks);

    folder.file(`${fileName}.${ext}`, buffer, { binary: true });
  }
  const folderName = `${location.name}_Documents_Date${today}.zip`;

  zipData = await folder.generateAsync({ type: "nodebuffer" });

  throw new Response(zipData, {
    status: 200,
    statusText: "success",
    headers: {
      "Content-Type": "application/zip",
      "Content-Disposition": `attachment; filename="${folderName}"`,
    },
  });
}
