import { ResidentLifecyclePhase } from "@prisma/client";
import type { ActionFunctionArgs } from "@remix-run/node";
import { useActionData } from "@remix-run/react";
import { isNil } from "lodash";
import { jsonWithError, redirectWithSuccess } from "remix-toast";
import { z } from "zod";
import { CrudFormPage } from "~/components/form/crud-form-page.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assertAuthorized } from "~/utils/assert.utils.server";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import { getUser } from "~/utils/session.server";
import { castFormFields } from "~/utils/type.utils";
import { NonEmptyString } from "~/utils/validation.utils.server";

const NewCategoryForm = z.object({
  name: z.string().min(1, "Name is required"),
  description: z.string().min(1, "Description is required"),
  highlighted: z
    .string()
    .optional()
    .nullable()
    .transform(h => !!h),
  primary_vendor_type: z.string(),
  secondary_vendor_type: z.string(),
  slug: NonEmptyString,
  faq_1: NonEmptyString,
  faq_1_answer: NonEmptyString,
  faq_2: NonEmptyString,
  faq_2_answer: NonEmptyString,
  faq_3: NonEmptyString,
  faq_3_answer: NonEmptyString,
  page_title: NonEmptyString,
  meta_description: NonEmptyString,
  resident_lifecycle_phase: z.nativeEnum(ResidentLifecyclePhase),
});

export const action = async ({ request }: ActionFunctionArgs) => {
  const user = await getUser(request);
  assertAuthorized(!isNil(user));
  const form = await request.formData();

  const fields = {
    name: form.get("name"),
    description: form.get("description"),
    highlighted: form.get("highlighted"),
    primary_vendor_type: form.get("primary_vendor_type"),
    secondary_vendor_type: form.get("secondary_vendor_type"),
    slug: form.get("slug"),
    faq_1: form.get("faq_1"),
    faq_1_answer: form.get("faq_1_answer"),
    faq_2: form.get("faq_2"),
    faq_2_answer: form.get("faq_2_answer"),
    faq_3: form.get("faq_3"),
    faq_3_answer: form.get("faq_3_answer"),
    page_title: form.get("page_title"),
    meta_description: form.get("meta_description"),
    resident_lifecycle_phase: form.get("resident_lifecycle_phase"),
  };
  const validation = NewCategoryForm.safeParse(fields);

  if (validation.success) {
    const { productCategoryService } = await WebDIContainer();
    await productCategoryService.createCategory(validation.data);

    return redirectWithSuccess(
      `/admin/categories`,
      "Category created successfully"
    );
  }

  const errors = issuesByKey(validation.error.issues);
  return jsonWithError(
    { fields: castFormFields(fields), errors },
    DEFAULT_FORM_ERROR_MESSAGE,
    { status: 400 }
  );
};

export default function AdminVendorsNewRoute() {
  const actionData = useActionData<typeof action>();
  return (
    <CrudFormPage
      crumbs={[{ name: "Categories", to: "/admin/categories", active: false }]}
      config={{
        sections: [
          {
            title: "Create New Category",
            subtitle: "",
            fields: [
              {
                name: "name",
                label: "Name",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.name ?? undefined
                  : undefined,
                errors: actionData?.errors.name ?? [],
              },
              {
                name: "slug",
                label: "Slug",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.slug ?? undefined
                  : undefined,
                errors: actionData?.errors.name ?? [],
              },
              {
                name: "description",
                label: "Description",
                description: "A full description of the category",
                type: "textarea",
                defaultValue: actionData
                  ? actionData.fields.description ?? undefined
                  : undefined,
                errors: actionData?.errors.description ?? [],
              },
              {
                name: "highlighted",
                label: "Highlighted",
                description:
                  "Should this category be highlighted on the home page?",
                type: "checkbox",
                defaultChecked: actionData?.fields?.highlighted === "true",
                value: "true",
                errors: actionData?.errors?.highlighted ?? [],
              },
              {
                name: "resident_lifecycle_phase",
                label: "Revyse Intelligence Phase",
                type: "select",
                options: Object.values(ResidentLifecyclePhase).map(phase => ({
                  label: phase.replace(/([A-Z])/g, " $1").trim(),
                  value: phase,
                })),
                defaultValue: actionData?.fields?.resident_lifecycle_phase,
                errors: actionData?.errors?.resident_lifecycle_phase ?? [],
              },

              {
                name: "primary_vendor_type",
                label: "Primary Vendor Type",
                type: "select",
                options: [
                  { label: "Technology", value: "Technology" },
                  { label: "Suppliers", value: "Suppliers" },
                  { label: "Services", value: "Services" },
                ],
                defaultValue: actionData?.fields?.primary_vendor_type,
                errors: actionData?.errors?.primary_vendor_type ?? [],
              },

              {
                name: "secondary_vendor_type",
                label: "Secondary Vendor Type",
                type: "select",
                options: [
                  { label: "Hardware", value: "Hardware" },
                  { label: "Software", value: "Software" },
                  {
                    label: "Professional Services",
                    value: "Professional Services",
                  },
                  { label: "Consulting", value: "Consulting" },
                  { label: "Agencies", value: "Agencies" },
                  { label: "Freelancers", value: "Freelancers" },
                  { label: "Materials", value: "Materials" },
                  { label: "Onsite Services", value: "Onsite Services" },
                ],
                defaultValue: actionData?.fields?.secondary_vendor_type,
                errors: actionData?.errors?.secondary_vendor_type ?? [],
              },
              {
                name: "faq_1",
                label: "FAQ 1",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.faq_1 ?? undefined
                  : undefined,
                errors: actionData?.errors.faq_1 ?? [],
              },
              {
                name: "faq_1_answer",
                label: "FAQ 1 Answer",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.faq_1_answer ?? undefined
                  : undefined,
                errors: actionData?.errors.faq_1_answer ?? [],
              },
              {
                name: "faq_2",
                label: "FAQ 2",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.faq_2 ?? undefined
                  : undefined,
                errors: actionData?.errors.faq_2 ?? [],
              },
              {
                name: "faq_2_answer",
                label: "FAQ 2 Answer",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.faq_2_answer ?? undefined
                  : undefined,
                errors: actionData?.errors.faq_2_answer ?? [],
              },
              {
                name: "faq_3",
                label: "FAQ 3",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.faq_3 ?? undefined
                  : undefined,
                errors: actionData?.errors.faq_3 ?? [],
              },
              {
                name: "faq_3_answer",
                label: "FAQ 3 Answer",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.faq_3_answer ?? undefined
                  : undefined,
                errors: actionData?.errors.faq_3_answer ?? [],
              },
              {
                name: "page_title",
                label: "Page Title",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.page_title ?? undefined
                  : undefined,
                errors: actionData?.errors.page_title ?? [],
              },
              {
                name: "meta_description",
                label: "Meta Description",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.meta_description ?? undefined
                  : undefined,
                errors: actionData?.errors.meta_description ?? [],
              },
            ],
          },
        ],
      }}
    />
  );
}
