import type {
  LinksFunction,
  LoaderFunctionArgs,
  MetaFunction,
} from "@remix-run/node";
import { json } from "@remix-run/node";
import { useLoaderData } from "@remix-run/react";
import { Legalese } from "~/components/legalese.component";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import HTMLReactParser from "html-react-parser";
import { slugify } from "~/utils/string.utils";
import article from "../styles/article.css";

export const links: LinksFunction = () => {
  return [
    {
      rel: "stylesheet",
      href: article,
    },
  ];
};

export const meta: MetaFunction<typeof loader> = ({ data }) => {
  const doc = data!.doc;
  return [
    { title: doc.meta_title },
    {
      name: "description",
      content: doc.meta_description,
    },
  ];
};

export async function loader({ request }: LoaderFunctionArgs) {
  const { circleService } = await WebDIContainer();
  const slug = new URL(request.url).pathname;
  const slugged = slugify(slug);
  const doc = await circleService.getLegalDoc(slugged);
  return json({
    doc,
    slug: slugged as string,
  });
}

export default function TermsOfUseRoute() {
  const { doc } = useLoaderData<typeof loader>();

  return (
    <Legalese title={doc.name}>
      <div className="whitespace-normal font-light font-lg leading-relaxed text-md">
        {HTMLReactParser(doc.body || "...")}
      </div>
    </Legalese>
  );
}
