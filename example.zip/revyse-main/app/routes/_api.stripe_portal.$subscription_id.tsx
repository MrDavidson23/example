import type { LoaderFunctionArgs } from "@remix-run/node";
import { redirect } from "@remix-run/node";
import { isNil } from "lodash";
import { getUser } from "~/utils/session.server";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assertAuthorizedOrRedirect } from "~/utils/assert.utils.server";
import { UserRoleType } from "@prisma/client";

export const loader = async ({ request, params }: LoaderFunctionArgs) => {
  const user = await getUser(request);
  const subscription_id = params.subscription_id;
  if (!subscription_id) {
    return redirect("/for-vendors");
  }
  if (isNil(user)) {
    return redirect(
      `/login?redirectTo=${encodeURIComponent(
        `/stripe_portal/${subscription_id}`
      )}`
    );
  }

  const { db, productSubscriptionService } = await WebDIContainer();
  const subscription = await db.productSubscription.findFirst({
    where: {
      id: subscription_id,
      user_roles: {
        some: {
          type: UserRoleType.PRODUCT_SUBSCRIPTION,
          user: {
            id: user.id,
          },
        },
      },
    },
  });

  assertAuthorizedOrRedirect(!isNil(subscription), "/vendor");
  const session =
    await productSubscriptionService.createSubscriptionBillingPortalSession(
      subscription.stripe_id
    );

  return redirect(session.url!);
};
