import { json } from "@remix-run/node";
import { Link, useFetcher, useLoaderData } from "@remix-run/react";
import type { LinksFunction, LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { CTA } from "~/components/cta.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Permission } from "~/utils/intelligence-permission.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
import { Button } from "~/components/button.component";
import { ArrowLeftIcon } from "@heroicons/react/20/solid";
import { useMemo, useRef, useState } from "react";
import stylesheetQuill from "react-quill/dist/quill.snow.css";
import stylesQuillToolbarBottom from "../styles/quill-toolbar-bottom.css";
import stylesQuillEmailEditor from "../styles/quill-email-editor.css";
import { isEmpty } from "lodash";
import { encodeFilename } from "~/utils/file.utils";
import { z } from "zod";
import { parseMultiPartFormDataS3Upload } from "~/services/s3.service.server";
import { MB } from "~/utils/constants.utils";
import { issuesByKey } from "~/utils/form.utils.server";
import { WizardModal } from "~/components/modals/wizard-modal.component";
import {
  jsonWithError,
  jsonWithSuccess,
  redirectWithSuccess,
  redirectWithWarning,
} from "remix-toast";
import { EnvelopeIcon } from "@heroicons/react/24/outline";
import {
  getLocationNoticeEmailDefaultBody,
  LocationNoticeType,
} from "~/utils/location-notice.utils";
import { LocationNoticeStatus } from "@prisma/client";
import { EmailDraftComponent } from "~/components/intelligence/location-notices/email-draft.component";
dayjs.extend(utc);

export const links: LinksFunction = () => [
  { rel: "stylesheet", href: stylesheetQuill },
  { rel: "stylesheet", href: stylesQuillToolbarBottom },
  { rel: "stylesheet", href: stylesQuillEmailEditor },
];

const MAX_BYTE_LIMIT = 60 * MB;

const zEmailTemplateForm = z.object({
  subject: z.string().min(1),
  body: z.string(),
  cc_emails: z.array(z.string().email()),
  attachments: z.array(z.string().uuid()),
  uploaded_attachments_to_remove: z.array(z.string().uuid()),
});

export async function action({ request, params }: LoaderFunctionArgs) {
  const { account, user } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageLocationNotices],
      locationId: params.location_id,
    }
  );
  const locationId = params.location_id!;
  let locationNoticeId = params.location_notice_id!;
  const { locationNoticeService } = await WebDIContainer();

  const locationNotice =
    await locationNoticeService.getLocationNoticeDisposition(
      locationNoticeId,
      locationId,
      user,
      account
    );

  if (locationNotice?.status === LocationNoticeStatus.Sent) {
    return redirectWithWarning(
      `/intelligence/${account.id}/locations/${locationId}/notices/${locationNoticeId}/location-disposition`,
      "Location notice has already been sent"
    );
  }

  // Check if there's no any recipient empty (may have changed while editing email)
  if (locationNotice?.location_notice_recipients.some(r => !r.email)) {
    return redirectWithWarning(
      `/intelligence/${account.id}/locations/${locationId}/notices/${locationNoticeId}/location-disposition/recipients`,
      "Some recipients don't have an email address. Redirecting to select recipients page."
    );
  }

  const form = await parseMultiPartFormDataS3Upload(request, [
    { field: "attachments", byteLimit: MAX_BYTE_LIMIT },
  ]);

  const intent = form.get("intent");

  const ccEmails = form.get("cc_emails") as string;
  const uploadedAttachmentsToRemove = form.get(
    "uploaded_attachments_to_remove"
  ) as string;

  const fields = {
    subject: form.get("subject"),
    body: form.get("body"),
    cc_emails: !isEmpty(ccEmails) ? ccEmails.split(",").map(e => e.trim()) : [],
    attachments: form.getAll("attachments"),
    uploaded_attachments_to_remove: !isEmpty(uploadedAttachmentsToRemove)
      ? uploadedAttachmentsToRemove.split(",").map(e => e.trim())
      : [],
  };

  const validation = zEmailTemplateForm.safeParse(fields);

  if (!validation.success) {
    return json({
      success: false,
      errors: issuesByKey(validation.error.issues),
      fields,
    });
  }

  const managerAccountRoleId = user.manager_account_roles.find(
    role => role.manager_account_id === account.id
  )!.id;

  if (intent === "save-progress") {
    await locationNoticeService.saveLocationNoticeDispositionDraftEmail(
      locationNoticeId,
      {
        ...validation.data,
        manager_account_role_id: managerAccountRoleId,
      },
      true
    );

    return redirectWithSuccess(
      `/intelligence/${account.id}/locations/${locationId}/notices`,
      "Progress saved successfully"
    );
  } else {
    await locationNoticeService.saveLocationNoticeDispositionDraftEmail(
      locationNoticeId,
      {
        ...validation.data,
        manager_account_role_id: managerAccountRoleId,
      }
    );
    try {
      await locationNoticeService.sendLocationNoticeDispositionEmail(
        locationNoticeId,
        managerAccountRoleId
      );
    } catch (error) {
      console.error(error);
      return jsonWithError(
        {
          success: false,
          errors: issuesByKey([
            {
              path: ["email"],
              message: (error as Error).message,
            },
          ]),
        },
        "Error sending email",
        { status: 400 }
      );
    }

    return jsonWithSuccess(
      { success: true, errors: issuesByKey([]) },
      "Email sent successfully"
    );
  }
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ViewLocationNotices],
      locationId: params.location_id,
    }
  );

  const { locationService, locationNoticeService } = await WebDIContainer();

  const location = await locationService.getLocation(params.location_id!);

  if (!location) {
    throw new Response("Location not found", { status: 404 });
  }

  const locationNoticeId = params.location_notice_id!;

  const locationNotice =
    await locationNoticeService.getLocationNoticeDisposition(
      locationNoticeId,
      location.id,
      user,
      account
    );

  const vendorOptions = await locationNoticeService.getVendorRecipientsOptions(
    location.id,
    user,
    account
  );

  const totalVendorsCount = vendorOptions.length;

  if (!locationNotice) {
    throw new Response("Location notice not found", {
      status: 404,
    });
  }

  return json({
    user,
    account,
    location,
    locationNotice,
    totalVendorsCount,
  });
}

export default function LocationDispositionNoticeEmail() {
  const { account, location, locationNotice, totalVendorsCount } =
    useLoaderData<typeof loader>();

  const fetcher = useFetcher<typeof action>();
  const formRef = useRef<HTMLFormElement>(null);

  const [attachments, setAttachments] = useState<File[]>([]);
  const [uploadedAttachmentsToRemove, setUploadedAttachmentsToRemove] =
    useState<string[]>([]);
  const [body, setBody] = useState<string>(
    locationNotice.email_body ??
      getLocationNoticeEmailDefaultBody(
        {
          ...locationNotice,
          type: LocationNoticeType.LocationNoticeDisposition,
        },
        location,
        account
      )
  );

  const [reviewAndSendModalOpen, setReviewAndSendModalOpen] = useState(false);

  const submit = (intent?: string) => {
    if (intent === "review-and-send") {
      setReviewAndSendModalOpen(true);
      return;
    }

    const formData = formRef.current && new FormData(formRef.current);

    if (intent) {
      formData?.append("intent", intent);
    }

    formData?.append("body", body);

    attachments.forEach(attachment => {
      formData?.append(
        "attachments",
        attachment,
        encodeFilename(attachment.name)
      );
    });

    formData?.append(
      "uploaded_attachments_to_remove",
      uploadedAttachmentsToRemove.join(",")
    );

    fetcher.submit(formData, {
      method: "POST",
      encType: "multipart/form-data",
    });
  };

  const formErrors = useMemo(() => fetcher.data?.errors ?? {}, [fetcher.data]);

  const submitting = useMemo(
    () => fetcher.state === "submitting",
    [fetcher.state]
  );

  const wizardStep = useMemo(() => {
    if (submitting) {
      return "sending";
    }
    if (fetcher.data?.success) {
      return "sent";
    }
    return "review";
  }, [fetcher.data, submitting]);

  const isUpdatedDispositionNotice = useMemo(() => {
    return locationNotice.original_location_notice_id !== null;
  }, [locationNotice]);

  return (
    <>
      <WizardModal
        isOpen={reviewAndSendModalOpen}
        onClose={() => setReviewAndSendModalOpen(false)}
        initialStepId={wizardStep}
        steps={[
          {
            id: "review",
            title: `Let’s review & send your disposition${
              isUpdatedDispositionNotice ? " updated" : ""
            } notice.`,
            body: (
              <div className="flex flex-col gap-y-3">
                <div className="flex gap-x-2">
                  <span className="font-semibold">Location Name:</span>
                  <span>{location.name}</span>
                </div>
                <div className="flex gap-x-2">
                  <span className="font-semibold">Vendors To Be Notified:</span>
                  <span>
                    {locationNotice.location_notice_recipients.length}/
                    {totalVendorsCount}
                  </span>
                </div>
                <div className="flex gap-x-2">
                  <span className="font-semibold">
                    Expected Disposition Date:
                  </span>
                  <span>
                    {dayjs
                      .utc(locationNotice.disposition_date)
                      .format("MM/DD/YYYY")}
                  </span>
                </div>
                <div className="flex gap-x-2">
                  <span className="font-semibold">
                    Requested Service Termination Date:
                  </span>
                  <span>
                    {dayjs
                      .utc(locationNotice.termination_date)
                      .format("MM/DD/YYYY")}
                  </span>
                </div>
                <div className="flex gap-x-2">
                  <span className="font-semibold">Task Owner:</span>
                  <span>
                    {locationNotice.task_owner.user.first_name}{" "}
                    {locationNotice.task_owner.user.last_name}
                  </span>
                </div>
              </div>
            ),
            ctas: {
              primary: {
                label: `Send${
                  isUpdatedDispositionNotice ? " Updated" : ""
                } Notice Now`,
                onClick: () => {
                  submit();
                  return {
                    to: "sending",
                  };
                },
              },
              secondary: {
                label: "Return to email template",
              },
            },
          },
          {
            id: "sending",
            body: (
              <div className="flex flex-col gap-y-3 justify-center items-center">
                <EnvelopeIcon className="h-16 w-16 text-sky-500 animate-bounce" />
                <div className="text-lg font-semibold">
                  Sending your{isUpdatedDispositionNotice ? " updated" : ""}{" "}
                  disposition notice...
                </div>
              </div>
            ),
          },
          {
            id: "sent",
            icon: "success",
            title: `Your${
              isUpdatedDispositionNotice ? " updated" : ""
            } location disposition notice was sent to ${
              locationNotice.location_notice_recipients.length
            } vendors!`,
            body: `Nice work! Your${
              isUpdatedDispositionNotice ? " updated" : ""
            } email notice has been sent, and we’ve recorded this activity for safe keeping.`,
            ctas: {
              primary: {
                label: "Return to all notices",
                toLink: `/intelligence/${account.id}/locations/${location.id}/notices`,
              },
            },
          },
        ]}
      />
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All locations",
            to: `/intelligence/${account.id}/locations`,
          },
          {
            name: location.name,
            to: `/intelligence/${account.id}/locations/${location.id}/details`,
          },
          {
            name: "Notices",
            to: `/intelligence/${account.id}/locations/${location.id}/notices`,
          },
          ...(isUpdatedDispositionNotice
            ? [
                {
                  name: "Updated disposition details",
                  to: `/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/location-disposition/details`,
                },
                {
                  name: "Draft updated email",
                  to: `/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/location-disposition/emailtemplate`,
                  active: true,
                },
              ]
            : [
                {
                  name: "Configure disposition details",
                  to: `/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/location-disposition/details`,
                },
                {
                  name: "Select recipients",
                  to: `/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/location-disposition/recipients`,
                },
                {
                  name: "Draft email",
                  to: `/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/location-disposition/emailtemplate`,
                  active: true,
                },
              ]),
        ]}
        title={
          <>
            {isUpdatedDispositionNotice
              ? "Updated disposition notice email"
              : "Draft disposition notice email"}
            : <br /> {location.name}
          </>
        }
        description={`View and edit the${
          isUpdatedDispositionNotice ? " updated" : ""
        } disposition notice email that will be sent to your selected vendor contacts.`}
        buttonsSlot={
          <CTA onClick={() => submit("review-and-send")}>
            Review Notice & Send
          </CTA>
        }
      />
      <fetcher.Form ref={formRef}>
        <EmailDraftComponent
          location={location}
          locationNotice={{
            ...locationNotice,
            type: LocationNoticeType.LocationNoticeDisposition,
          }}
          account={account}
          formErrors={formErrors}
          onAttachmentsChange={setAttachments}
          onRemoveAttachments={setUploadedAttachmentsToRemove}
          uploadedAttachmentsToRemove={uploadedAttachmentsToRemove}
          onBodyChange={setBody}
        ></EmailDraftComponent>
        <footer className="flex justify-between items-center mt-4">
          <div>
            {isUpdatedDispositionNotice ? (
              <Link
                to={`/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/location-disposition/details`}
                className="text-sky-500 flex items-center text-sm"
              >
                <ArrowLeftIcon className="h-5 mr-2" /> Back to notice details
              </Link>
            ) : (
              <Link
                to={`/intelligence/${account.id}/locations/${location.id}/notices/${locationNotice.id}/location-disposition/recipients`}
                className="text-sky-500 flex items-center text-sm"
              >
                <ArrowLeftIcon className="h-5 mr-2" /> Back to select recipients
              </Link>
            )}
          </div>
          <div className="flex gap-x-2">
            {!isUpdatedDispositionNotice && (
              <Button
                color="transparent"
                onClick={() => submit("save-progress")}
              >
                Save Progress
              </Button>
            )}
            <CTA onClick={() => submit("review-and-send")}>
              Review Notice & Send
            </CTA>
          </div>
        </footer>
      </fetcher.Form>
    </>
  );
}
