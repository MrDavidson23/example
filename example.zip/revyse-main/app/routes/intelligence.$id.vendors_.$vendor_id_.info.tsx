import { Form, Link, useActionData, useLoaderData } from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { Permission } from "~/utils/intelligence-permission.utils";
import {
  CrudDateField,
  CrudRadioButtonField,
  CrudSelectField,
  CrudTextField,
  FormSection,
} from "~/components/form/crud-form.component";
import { Tooltip } from "~/components/tooltip.component";
import { InformationCircleIcon, TrashIcon } from "@heroicons/react/24/outline";
import { usaStates } from "~/utils/state.enum";
import { CTA } from "~/components/cta.component";
import { ArrowLeftIcon } from "@heroicons/react/20/solid";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Button } from "~/components/button.component";
import { useState } from "react";
import {
  jsonWithError,
  redirectWithError,
  redirectWithSuccess,
} from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { castFormFields } from "~/utils/type.utils";
import { ManagerAccountVendorStatus, Prisma } from "@prisma/client";
import { ConfirmDeleteModal } from "~/components/modals/confirm-delete-modal.component";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const UpdateVendorInfoForm = z.object({
  is_preferred: z.boolean().optional(),
  vendor_since: z.preprocess(
    val => (val === "" ? null : dayjs.utc(val as string).toDate()),
    z.date().nullable()
  ),
  internal_vendor_code: z.string().optional(),
  street_1: z.string().optional(),
  street_2: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional().nullable(),
  zip: z.string().optional(),
  country: z.string().optional(),
  phone: z.string().optional(),
  status: z.nativeEnum(ManagerAccountVendorStatus),
});

async function updateVendorInfo({ form, id }: { form: FormData; id: string }) {
  const { managerAccountVendorService } = await WebDIContainer();

  const fields = {
    is_preferred: form.get("is_preferred") === "1",
    vendor_since: form.get("vendor_since"),
    internal_vendor_code: form.get("internal_vendor_code"),
    street_1: form.get("street_1"),
    street_2: form.get("street_2"),
    city: form.get("city"),
    state: form.get("state"),
    zip: form.get("zip"),
    country: form.get("country"),
    phone: form.get("phone"),
    status: form.get("status"),
  };

  const validation = UpdateVendorInfoForm.safeParse(fields);

  if (validation.success) {
    const accountVendor =
      await managerAccountVendorService.updateManagerAccountVendor(
        id,
        validation.data
      );

    return redirectWithSuccess(
      `/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}`,
      "Vendor info updated successfully"
    );
  }

  return jsonWithError(
    {
      success: false,
      accountVendor: null,
      fields: castFormFields(fields),
      errors: issuesByKey(validation.error.issues),
    },
    DEFAULT_FORM_ERROR_MESSAGE
  );
}

async function deleteAccountVendor({
  id,
  managerAccountId,
}: {
  id: string;
  managerAccountId: string;
}) {
  const { managerAccountVendorService } = await WebDIContainer();

  try {
    await managerAccountVendorService.deleteManagerAccountVendor(id);
  } catch (error) {
    if (error instanceof Error && error.message === "Vendor has contracts") {
      return redirectWithError(
        `/intelligence/${managerAccountId}/vendors/${id}`,
        "Cannot delete vendor with contracts"
      );
    }

    if (
      error instanceof Prisma.PrismaClientKnownRequestError &&
      error.name === "NotFoundError"
    ) {
      return redirectWithError(
        `/intelligence/${managerAccountId}/vendors`,
        "Vendor not found"
      );
    }

    throw new Response("Internal server error", { status: 500 });
  }

  return redirectWithSuccess(
    `/intelligence/${managerAccountId}/vendors`,
    "Vendor removed successfully"
  );
}

export async function action({ params, request }: ActionFunctionArgs) {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );
  const id = params.vendor_id as string;
  const managerAccountId = account.id;

  const form = await request.formData();

  const intent = form.get("intent");

  if (intent === "delete") {
    return deleteAccountVendor({ id, managerAccountId });
  }
  return updateVendorInfo({ form, id });
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );
  const id = params.vendor_id!;
  const { managerAccountVendorService } = await WebDIContainer();

  const accountVendor =
    await managerAccountVendorService.getManagerAccountVendor(id, {
      vendor: true,
      _count: {
        select: {
          contracts: true,
        },
      },
    });

  return json({
    accountVendor,
  });
}

export default function VendorInfoRoute() {
  const actionData = useActionData<typeof action>();
  const { accountVendor } = useLoaderData<typeof loader>();

  const [openConfirmDelete, setOpenConfirmDelete] = useState(false);
  return (
    <>
      <ConfirmDeleteModal
        isOpen={openConfirmDelete}
        onClose={() => setOpenConfirmDelete(false)}
        onConfirm={() => setOpenConfirmDelete(false)}
        title="Remove this vendor and its data"
        message="Are you sure you want to permanently remove this vendor from your account?"
        submitOnConfirm={true}
      />
      <div className="space-y-8 pb-12">
        <IntelligenceScreenHeader
          crumbs={[
            {
              name: "Vendors",
              to: `/intelligence/${accountVendor.manager_account_id}/vendors`,
            },
            {
              name: accountVendor.vendor.name,
              to: `/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}`,
            },
            {
              name: "Vendor info",
              to: `/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}/info`,
              active: true,
            },
          ]}
          title="Vendor info"
          description={
            <>
              View and manage the primary information for{" "}
              {accountVendor.vendor.name}, including vendor status, internal
              reference number, and mailing address.
            </>
          }
        />
        <div className="space-y-8 pb-12">
          <Form className="space-y-8" method="post">
            <div
              className={`bg-white shadow-lg shadow-gray-200/50 p-3 md:p-8 rounded-lg h-min`}
            >
              <div>
                <FormSection
                  title="Primary Info"
                  subtitle="Configure the primary info for this vendor"
                  spacing="compact"
                >
                  <div className="col-span-full">
                    <CrudSelectField
                      field={{
                        name: "status",
                        label: "Vendor Status",
                        type: "select",
                        options: Object.entries(ManagerAccountVendorStatus).map(
                          ([key, value]) => ({ value: key, label: value })
                        ),
                        defaultValue: actionData
                          ? actionData?.fields.status ??
                            ManagerAccountVendorStatus.Active
                          : accountVendor.status ??
                            ManagerAccountVendorStatus.Active,
                        errors: [],
                      }}
                    />
                  </div>
                  <div className="col-span-full space-y-2">
                    <div className="flex items-center gap-1 font-medium text-sm">
                      Is this a preferred vendor?{" "}
                      <span className="font-light text-gray-400">
                        (Optional)
                      </span>{" "}
                      <Tooltip text="A preferred vendor is a vendor or supplier that your organization prefers to work with, and often, buyers are encouraged to prioritize these vendors when procuring new products or services.">
                        <div className="flex flex-row items-center cursor-pointer">
                          <InformationCircleIcon className="h-5 text-gray-400" />
                        </div>
                      </Tooltip>
                    </div>
                    <div className="flex space-x-3">
                      <CrudRadioButtonField
                        field={{
                          label: "No",
                          value: 0,
                          errors: [],
                          name: "is_preferred",
                          defaultChecked: actionData
                            ? !actionData?.fields.is_preferred ?? undefined
                            : !accountVendor.is_preferred ?? false,
                          type: "radio",
                          description: "",
                        }}
                      />
                      <CrudRadioButtonField
                        field={{
                          label: "Yes",
                          value: 1,
                          errors: [],
                          name: "is_preferred",
                          defaultChecked: actionData
                            ? actionData?.fields.is_preferred ?? undefined
                            : accountVendor.is_preferred ?? false,
                          type: "radio",
                          description: "",
                        }}
                      />
                    </div>
                  </div>
                  <CrudDateField
                    field={{
                      label: (
                        <>
                          Vendor Since{" "}
                          <span className="font-light text-gray-400">
                            (Optional)
                          </span>{" "}
                        </>
                      ),
                      defaultValue: actionData
                        ? actionData?.fields.vendor_since ?? undefined
                        : dayjs
                            .utc(accountVendor.vendor_since)
                            .format("YYYY-MM-DD") ?? undefined,
                      errors: actionData?.errors.vendor_since ?? [],
                      name: "vendor_since",
                      type: "text",
                      description: "",
                    }}
                  ></CrudDateField>
                  <CrudTextField
                    field={{
                      label: (
                        <div className="flex items-center gap-1">
                          Internal Vendor Code{"  "}
                          <span className="font-light text-gray-400">
                            (Optional)
                          </span>{" "}
                          <Tooltip text="An internal vendor code is a specific reference number that your company uses to identify this vendor.">
                            <div className="flex flex-row items-center cursor-pointer">
                              <InformationCircleIcon className="h-5 text-gray-400" />
                            </div>
                          </Tooltip>
                        </div>
                      ),
                      defaultValue: actionData
                        ? actionData?.fields.internal_vendor_code ?? undefined
                        : accountVendor.internal_vendor_code ?? undefined,
                      errors: actionData?.errors.internal_vendor_code ?? [],
                      name: "internal_vendor_code",
                      type: "text",
                      description: "",
                      placeholder: "e.g. 123456",
                    }}
                  ></CrudTextField>
                  <CrudTextField
                    field={{
                      label: (
                        <>
                          Street Address{" "}
                          <span className="font-light text-gray-400">
                            (Optional)
                          </span>{" "}
                        </>
                      ),
                      defaultValue: actionData
                        ? actionData?.fields.street_1 ?? undefined
                        : accountVendor.street_1 ?? undefined,
                      errors: actionData?.errors.street_1 ?? [],
                      name: "street_1",
                      type: "text",
                      description: "",
                      placeholder: "1234 Main Street",
                    }}
                  ></CrudTextField>
                  <CrudTextField
                    field={{
                      label: (
                        <>
                          Apt, Suite, etc.{" "}
                          <span className="font-light text-gray-400">
                            (Optional)
                          </span>{" "}
                        </>
                      ),
                      defaultValue: actionData
                        ? actionData?.fields.street_2 ?? undefined
                        : accountVendor.street_2 ?? undefined,
                      errors: actionData?.errors.street_2 ?? [],
                      name: "street_2",
                      type: "text",
                      description: "",
                      placeholder: "Suite 100",
                    }}
                  ></CrudTextField>
                  <CrudTextField
                    field={{
                      label: (
                        <>
                          City{" "}
                          <span className="font-light text-gray-400">
                            (Optional)
                          </span>{" "}
                        </>
                      ),
                      defaultValue: actionData
                        ? actionData?.fields.city ?? undefined
                        : accountVendor.city ?? undefined,
                      errors: actionData?.errors.city ?? [],
                      name: "city",
                      type: "text",
                      description: "",
                      placeholder: "Bend",
                    }}
                  ></CrudTextField>
                  <div className="col-span-3 mr-2">
                    <CrudSelectField
                      field={{
                        name: "state",
                        label: (
                          <>
                            <>
                              State{" "}
                              <span className="font-light text-gray-400">
                                (Optional)
                              </span>{" "}
                            </>
                          </>
                        ),
                        type: "select",
                        options: Object.values(usaStates).map(state => ({
                          label: state.label,
                          value: state.value,
                        })),
                        defaultValue:
                          actionData?.fields?.state ??
                          accountVendor.state ??
                          undefined,
                        errors: actionData?.errors.state ?? [],
                      }}
                    />
                  </div>
                  <div className="col-span-3">
                    <CrudTextField
                      field={{
                        label: (
                          <>
                            Zip Code{" "}
                            <span className="font-light text-gray-400">
                              (Optional)
                            </span>{" "}
                          </>
                        ),
                        defaultValue: actionData
                          ? actionData?.fields.zip ?? undefined
                          : accountVendor.zip ?? undefined,
                        errors: actionData?.errors.zip ?? [],
                        name: "zip",
                        type: "text",
                        description: "",
                        placeholder: "11111",
                      }}
                    />
                  </div>
                  <CrudTextField
                    field={{
                      label: (
                        <>
                          Country{" "}
                          <span className="font-light text-gray-400">
                            (Optional)
                          </span>{" "}
                        </>
                      ),
                      defaultValue: actionData
                        ? actionData?.fields.country ?? undefined
                        : accountVendor.country ?? undefined,
                      errors: actionData?.errors.country ?? [],
                      name: "country",
                      type: "text",
                      description: "",
                      placeholder: "USA",
                    }}
                  ></CrudTextField>
                  <CrudTextField
                    field={{
                      label: (
                        <>
                          Phone{" "}
                          <span className="font-light text-gray-400">
                            (Optional)
                          </span>{" "}
                        </>
                      ),
                      defaultValue: actionData
                        ? actionData?.fields.phone ?? undefined
                        : accountVendor.phone ?? undefined,
                      errors: actionData?.errors.phone ?? [],
                      name: "phone",
                      type: "text",
                      description: "",
                      placeholder: "(555) 456-7890",
                    }}
                  ></CrudTextField>
                </FormSection>
              </div>
            </div>
            <div className="mt-10 flex justify-around md:justify-between flex-wrap lg:flex-nowrap gap-x-3">
              <Link
                to={`/intelligence/${accountVendor.manager_account_id}/vendors/${accountVendor.id}`}
                className="text-sky-600 flex items-center"
              >
                <ArrowLeftIcon className="h-5 mr-2" /> Back to vendor overview
              </Link>
              <div className="flex gap-x-3 items-center">
                {accountVendor._count.contracts === 0 && (
                  <Button
                    color="transparent"
                    onClick={() => setOpenConfirmDelete(true)}
                  >
                    <TrashIcon className="h-5 mr-2" />
                    Remove Vendor
                  </Button>
                )}
                <CTA type="submit" id="save-button">
                  Save Changes
                </CTA>
              </div>
            </div>
          </Form>
        </div>
      </div>
    </>
  );
}
