import { json } from "@remix-run/node";
import {
  Form,
  useActionData,
  useLoaderData,
  useLocation,
  useNavigation,
} from "@remix-run/react";
import type { ActionFunctionArgs, LoaderFunctionArgs } from "@remix-run/node";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assert, assertAuthorized } from "~/utils/assert.utils.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { Permission } from "~/utils/intelligence-permission.utils";
import { useCallback, useEffect, useMemo, useState } from "react";
import { find, isNil } from "lodash";
import {
  CrudAutocompleteField,
  CrudTextField,
  FormSection,
} from "~/components/form/crud-form.component";
import { Button } from "~/components/button.component";
import {
  ExclamationCircleIcon,
  PlusIcon,
  XMarkIcon,
} from "@heroicons/react/24/outline";
import { CrudTextAreaField } from "~/components/form/textarea.component";
import { CTA } from "~/components/cta.component";
import { z } from "zod";
import { issuesByKey } from "~/utils/form.utils.server";
import { jsonWithError, redirectWithSuccess } from "remix-toast";
import { DEFAULT_FORM_ERROR_MESSAGE } from "~/utils/constants.utils";
import { IntelligenceScreenHeader } from "~/components/intelligence/intelligence-screen-header.component";
import { verifyIntelligenceRequest } from "~/utils/intelligence.utils.server";
dayjs.extend(utc);

const FormConfig = z
  .object({
    vendor_id: z.string({
      required_error: "Select a vendor or create a new one",
      invalid_type_error: "Select a vendor or create a new one",
    }),
    new_vendor_name: z.string().nullable(),
    new_vendor_description: z.string().nullable(),
  })
  .superRefine((values, ctx) => {
    if (values.vendor_id === "new") {
      if (!values.new_vendor_name) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Vendor name is required",
          path: ["new_vendor_name"],
        });
      }
      if (!values.new_vendor_description) {
        ctx.addIssue({
          code: z.ZodIssueCode.custom,
          message: "Vendor description is required",
          path: ["new_vendor_description"],
        });
      }
    }
  });

export async function action({ request, params }: ActionFunctionArgs) {
  const { user, account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );
  const { managerAccountVendorService } = await WebDIContainer();

  assertAuthorized(!isNil(user));
  const managerAccountId = account.id;

  const form = await request.formData();

  const fields = {
    vendor_id: form.get("vendor_id"),
    new_vendor_name: form.get("new_vendor_name"),
    new_vendor_description: form.get("new_vendor_description"),
  };

  const validation = FormConfig.safeParse(fields);

  if (!validation.success) {
    return jsonWithError(
      {
        errors: issuesByKey(validation.error.issues),
        fields,
        success: false,
      },
      DEFAULT_FORM_ERROR_MESSAGE
    );
  }

  try {
    const newManagerAccountVendor =
      await managerAccountVendorService.createManagerAccountVendor(
        {
          manager_account_id: managerAccountId,
          ...validation.data,
        },
        user
      );

    return redirectWithSuccess(
      `/intelligence/${managerAccountId}/vendors/${newManagerAccountVendor.id}`,
      "Vendor added successfully"
    );
  } catch (error) {
    console.log(error);
    if (
      error instanceof Error &&
      error.message === "Vendor already exists in account"
    ) {
      return jsonWithError(
        {
          errors: issuesByKey([
            {
              message: "Whoops! This vendor is already in your account list.",
              path: ["vendor_id"],
            },
          ]),
          fields,
          success: false,
        },
        "Whoops! This vendor is already in your account list"
      );
    } else {
      assert(false, "Failed to add vendor");
    }
  }
}

export async function loader({ params, request }: LoaderFunctionArgs) {
  const { account } = await verifyIntelligenceRequest(
    { request, params },
    {
      permissions: [Permission.ManageVendors],
    }
  );
  const { managerAccountVendorService } = await WebDIContainer();

  const vendorOptions = await managerAccountVendorService.getVendorOptions(
    account.id
  );

  return json({
    vendorOptions,
    account,
  });
}

export default function IntelligenceVendorsCreate() {
  const location = useLocation();

  const { vendorOptions, account } = useLoaderData<typeof loader>();
  const actionData = useActionData<typeof action>();

  const navigation = useNavigation();

  const [selectedVendor, setSelectedVendor] = useState<
    (typeof vendorOptions)[number] | undefined
  >(undefined);

  const [newVendorNameInput, setNewVendorNameInput] = useState<
    string | undefined
  >(undefined);

  const onSelectVendor = useCallback(
    (vendorId: string) => {
      setSelectedVendor(find(vendorOptions, ["id", vendorId]));
    },
    [vendorOptions]
  );

  const showError = useMemo(
    () => selectedVendor?.id == actionData?.fields.vendor_id,
    [actionData, selectedVendor]
  );

  const newVendor = useMemo(
    () => ({
      id: "new",
      name: "",
      description: null,
      logo_file_id: null,
    }),
    []
  );

  const submitting = useMemo(
    () => navigation.state === "submitting",
    [navigation.state]
  );

  const vendorWithSameName = useMemo(
    () =>
      vendorOptions.find(
        vendor =>
          vendor.name.toLowerCase() === newVendorNameInput?.toLocaleLowerCase()
      ),
    [vendorOptions, newVendorNameInput]
  );

  useEffect(() => {
    if (selectedVendor != newVendor) {
      setNewVendorNameInput(undefined);
    }
  }, [selectedVendor, newVendor]);

  return (
    <>
      <IntelligenceScreenHeader
        crumbs={[
          {
            name: "All vendors",
            to: `/intelligence/${account.id}/vendors`,
          },
          { name: "Add vendor", to: location.pathname, active: true },
        ]}
        title="Add new vendor"
        description={
          "Add a vendor to your account using the drop-down menu below. If your vendor isn’t yet listed, create a new vendor."
        }
      />
      <Form className="mt-10 mx-5" method="post">
        <FormSection
          title={"Select your vendor"}
          subtitle={"Choose a vendor from the drop-down menu"}
        >
          <div className="relative col-span-full">
            {(!selectedVendor || selectedVendor == newVendor) && (
              <div className="relative col-span-full">
                <CrudAutocompleteField
                  field={{
                    name: "",
                    label: "Select Vendor",
                    type: "autocomplete" as const,
                    defaultValue: undefined,
                    errors:
                      (showError && actionData?.errors["vendor_id"]) || [],
                    options: vendorOptions.map(vendor => ({
                      label: vendor.name,
                      value: vendor.id,
                    })),
                    onSelect: onSelectVendor,
                  }}
                />
              </div>
            )}

            {selectedVendor && selectedVendor != newVendor && (
              <div className="relative col-span-full">
                <CrudTextField
                  field={{
                    name: "",
                    label: "Select Vendor",
                    type: "text" as const,
                    defaultValue: selectedVendor.name,
                    errors:
                      (showError && actionData?.errors["vendor_id"]) || [],
                    disabled: true,
                  }}
                />
                <Button
                  className="absolute right-0 top-8"
                  color="transparent"
                  onClick={() => setSelectedVendor(undefined)}
                >
                  <XMarkIcon className="h-5 w-5" />
                </Button>
              </div>
            )}

            {selectedVendor && (
              <input name="vendor_id" value={selectedVendor.id} type="hidden" />
            )}
            <Button
              color="transparent"
              onClick={() => setSelectedVendor(newVendor)}
              className="text-xs"
            >
              <PlusIcon className="h-4 w-4" />
              &nbsp;Can’t find your vendor? Create one
            </Button>
            {selectedVendor && selectedVendor != newVendor && (
              <div className="col-span-full flex align-center my-5">
                <img
                  className="w-24 h-24 rounded-lg"
                  src={
                    selectedVendor.logo_file_id
                      ? `/images/${selectedVendor.logo_file_id}`
                      : "/assets/default-logo.png"
                  }
                  alt={`${selectedVendor.name} logo`}
                  width="96"
                  height="96"
                />
                <div className="ml-5 my-auto">
                  <div className="text-lg font-bold">{selectedVendor.name}</div>
                  <div className="text-sm mt-1">
                    {selectedVendor.description}
                  </div>
                </div>
              </div>
            )}
          </div>
        </FormSection>
        {selectedVendor === newVendor && (
          <FormSection
            title={"Create a new vendor"}
            subtitle={
              "Name your new vendor and describe the products or services they provide"
            }
          >
            <CrudTextField
              field={{
                name: "new_vendor_name",
                label: "Vendor Name",
                type: "text" as const,
                placeholder: "Type vendor name",
                defaultValue: undefined,
                errors: actionData?.errors["new_vendor_name"] || [],
                maxCharacters: 55,
                showMaxCharacters: !vendorWithSameName,
                onChange: e => {
                  setNewVendorNameInput(e.target.value);
                },
              }}
            />
            {vendorWithSameName && (
              <div className="text-sm text-amber-500 col-span-full -mt-8 flex">
                <ExclamationCircleIcon className="h-6 mr-2 my-auto" />
                <span className="my-auto">
                  There is already a vendor with this name.{" "}
                  <b
                    className="cursor-pointer hover:underline"
                    onClick={() => {
                      setSelectedVendor(vendorWithSameName);
                    }}
                  >
                    Select it here
                  </b>{" "}
                  or continue creating a new one.
                </span>
              </div>
            )}
            <CrudTextAreaField
              className="w-full"
              field={{
                name: "new_vendor_description",
                label: "Describe the products or services this vendor provides",
                type: "textarea" as const,
                placeholder: "Type here",
                defaultValue: undefined,
                errors:
                  (showError && actionData?.errors["new_vendor_description"]) ||
                  [],
                maxCharacters: 350,
                rows: 4,
              }}
            />
          </FormSection>
        )}
        <div
          className={`mt-10 flex justify-end ${
            submitting ? "animate-bounce" : ""
          }`}
        >
          <CTA type="submit" disabled={submitting}>
            {submitting ? "Saving..." : "Save"}
          </CTA>
        </div>
      </Form>
    </>
  );
}
