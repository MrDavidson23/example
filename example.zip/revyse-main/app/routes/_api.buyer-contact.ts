import { Role } from "@prisma/client";
import type { ActionFunctionArgs } from "@remix-run/node";
import { json } from "@remix-run/node";
import { some } from "lodash";
import { z } from "zod";
import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assertAuthenticatedOrRedirect } from "~/utils/auth.utils.server";
import { issuesByKey } from "~/utils/form.utils.server";
import { NonEmptyString } from "~/utils/validation.utils.server";

const ContactForm = z.object({
  product_id: z.string().uuid({ message: "Product ID Required" }),
  description: NonEmptyString,
});

export async function action({ request }: ActionFunctionArgs) {
  const user = await assertAuthenticatedOrRedirect(request);
  const verifiedBuyer = user?.user_roles.some(ur => ur.role === Role.BUYER);
  const form = await request.formData();
  const fields = {
    description: form.get("description"),
    product_id: form.get("product_id"),
  };

  const validation = ContactForm.safeParse(fields);

  if (validation.success) {
    const { buyerContactRequestService, productSubscriptionService } =
      await WebDIContainer();

    const userSubscriptions =
      await productSubscriptionService.getSubscriptionsForUser(user);
    const isTestRequest = some(userSubscriptions, [
      "product_id",
      validation.data.product_id,
    ]);

    if (!verifiedBuyer && !isTestRequest) {
      throw json({ error: "You are not a verified buyer" }, { status: 403 });
    }

    try {
      await buyerContactRequestService.createRequest(
        user,
        validation.data.product_id,
        validation.data.description,
        isTestRequest
      );
    } catch (e: any) {
      console.error(e);
      return json({
        success: false,
        errors: { server: [e.message] } as Record<string, string[]>,
      });
    }

    return json({ success: true, errors: issuesByKey([]) });
  }

  return json(
    { success: false, errors: issuesByKey(validation.error.issues) },
    { status: 400 }
  );
}
