import type { PrismaClient, SignUpIntent, User } from "@prisma/client";
import { Role, UserRoleType } from "@prisma/client";
import * as crypto from "crypto";
import { isNil } from "lodash";
import type { DIContainer } from "../di-containers/di-container.server";
import type { Result } from "../utils/type.utils";
import type { PrismaTransaction } from "./db.server";
import type { MailService } from "./mail.service.server";
import type { TemplateService } from "./template.service.server";
import type { INotificationService } from "./notification.service.server";
import type { IMailChimpService } from "./mail-chimp.service";

type LoginParams = {
  email: string;
  password: string;
};

type SignUpParams = LoginParams & {
  first_name: string;
  last_name: string;
  company_name: string;
  phone: string;
  title: string;
  intent: SignUpIntent;
};
export class AuthService {
  db!: PrismaClient;
  templateService!: TemplateService;
  mailService!: MailService;
  notificationService!: INotificationService;
  mailChimpService!: IMailChimpService;

  constructor(
    deps: Pick<
      DIContainer,
      | "db"
      | "templateService"
      | "mailService"
      | "notificationService"
      | "mailChimpService"
    >
  ) {
    Object.assign(this, deps);
  }

  findUserByEmailPassword(params: LoginParams) {
    return this.db.$transaction(tx =>
      this.findUserByEmailPasswordInTx(params, tx)
    );
  }

  async findUserByEmailPasswordInTx(
    { email, password }: LoginParams,
    tx: PrismaTransaction
  ) {
    const user = await tx.user.findFirst({
      where: { email: { equals: email, mode: "insensitive" } },
    });
    if (!user) return null;

    const userCredential = await tx.userCredential.findUnique({
      where: { user_id: user.id },
    });

    const hash = crypto
      .pbkdf2Sync(
        password,
        userCredential?.password_salt ?? "",
        1000,
        64,
        `sha512`
      )
      .toString(`hex`);

    if (hash !== userCredential?.password_hash) return null;
    return { id: user.id, email };
  }

  async register(params: SignUpParams, invitedUser: Boolean) {
    return this.db.$transaction(async tx => {
      return this.registerInTx(params, tx, invitedUser);
    });
  }

  async registerInTx(
    {
      email,
      password,
      first_name,
      last_name,
      company_name,
      phone,
      title,
      intent,
    }: SignUpParams,
    tx: PrismaTransaction,
    invitedUser: Boolean
  ): Promise<Result<User>> {
    const lowercaseEmail = email.toLowerCase();
    const userExists = await tx.user.findFirst({
      where: { email: lowercaseEmail },
    });

    if (userExists) {
      return { ok: false, error: `User with email ${email} already exists` };
    }

    const password_salt = crypto.randomBytes(16).toString("hex");
    const password_hash = crypto
      .pbkdf2Sync(password, password_salt, 1000, 64, `sha512`)
      .toString(`hex`);

    const user = await tx.user.create({
      data: {
        email: lowercaseEmail,
        first_name,
        last_name,
        company_name,
        phone,
        title,
        sign_up_intent: intent,
      },
    });

    await tx.userCredential.create({
      data: {
        password_hash,
        password_salt,
        user_id: user.id,
      },
    });

    if (!user) {
      return {
        ok: false,
        error: `Something went wrong trying to create a new user.`,
      };
    }

    // Don't await this call because we don't want to block the request/transaction from completing
    this.mailChimpService.addOrUpdateContact(user).catch(err => {
      console.error(err);
    });

    await this.generateEmailVerificationEmailInTx(user.id, tx, invitedUser);

    return { ok: true, value: user };
  }

  generateEmailVerificationEmail(userId: string, invitedUser: Boolean) {
    return this.db.$transaction(tx => {
      return this.generateEmailVerificationEmailInTx(userId, tx, invitedUser);
    });
  }

  async generateEmailVerificationEmailInTx(
    userId: string,
    tx: PrismaTransaction,
    invitedUser?: Boolean
  ) {
    const user = await tx.user.findFirst({
      where: { id: userId },
    });
    if (!user) {
      return null;
    } else {
      const existingToken = await tx.emailVerificationToken.findFirst({
        where: { user_id: user.id, email: user.email },
      });

      const token =
        existingToken ??
        (await tx.emailVerificationToken.create({
          data: { user_id: user.id, email: user.email },
        }));

      if (!invitedUser) {
        const body = this.templateService.renderEmailVerificationEmail({
          email: user.email,
          token: token.id,
        });
        await this.mailService.send({
          to: [user.email],
          subject: "Verify Your Email",
          body,
        });
      }
      return token;
    }
  }

  generateForgotPasswordEmail(email: string) {
    return this.db.$transaction(tx => {
      return this.generateForgotPasswordEmailInTx(email, tx);
    });
  }

  async generateForgotPasswordEmailInTx(email: string, tx: PrismaTransaction) {
    const lowercaseEmail = email.toLowerCase();
    const user = await tx.user.findFirst({
      where: { email: { equals: lowercaseEmail, mode: "insensitive" } },
    });
    if (!user) {
      return null;
    } else {
      const token = await tx.forgotPasswordToken.create({
        data: { user_id: user.id },
      });

      const body = this.templateService.renderForgotPasswordEmail({
        token: token.id,
      });
      await this.mailService.send({
        to: [email],
        subject: "Reset your password",
        body,
      });
      return token;
    }
  }

  resetPassword(token: string, password: string) {
    return this.db.$transaction(tx =>
      this.resetPasswordInTx(token, password, tx)
    );
  }

  async resetPasswordInTx(
    token: string,
    password: string,
    tx: PrismaTransaction
  ) {
    try {
      const fpToken = await tx.forgotPasswordToken.findFirst({
        where: {
          id: token,
          used_at: null,
        },
        include: { user: true },
      });

      if (fpToken === null) {
        return null;
      } else {
        const user = fpToken.user;
        const password_salt = crypto.randomBytes(16).toString("hex");
        const password_hash = crypto
          .pbkdf2Sync(password, password_salt, 1000, 64, `sha512`)
          .toString(`hex`);

        await tx.userCredential.update({
          where: { user_id: user.id },
          data: { password_hash, password_salt },
        });
        await tx.forgotPasswordToken.update({
          where: { id: fpToken.id },
          data: { used_at: new Date() },
        });
        return user;
      }
    } catch (e) {
      console.error(e);
      return null;
    }
  }

  async findUserByForgotPasswordToken(token: string) {
    return this.db.$transaction(tx =>
      this.findUserByForgotPasswordTokenInTx(token, tx)
    );
  }

  async findUserByForgotPasswordTokenInTx(
    token: string,
    tx: PrismaTransaction
  ) {
    const fpToken = await tx.forgotPasswordToken.findFirst({
      where: {
        id: token,
        used_at: null,
      },
      include: { user: true },
    });
    return fpToken?.user;
  }

  async verifyEmailVerification(token: string) {
    return this.db.$transaction(tx =>
      this.verifyEmailVerificationInTx(token, tx)
    );
  }

  async verifyEmailVerificationInTx(token: string, tx: PrismaTransaction) {
    try {
      const evToken = await tx.emailVerificationToken.findFirst({
        where: { id: token },
        include: { user: true },
      });

      if (!isNil(evToken) && evToken.verified_at === null) {
        await tx.emailVerificationToken.update({
          where: { id: token },
          data: { verified_at: new Date() },
        });

        const domain = evToken.user.email.split("@")[1].toLowerCase();
        const domainExists = await tx.buyerDomain.findFirst({
          where: { domain },
        });
        if (!isNil(domainExists)) {
          await tx.userRole.create({
            data: {
              user_id: evToken.user.id,
              role: Role.BUYER,
              type: UserRoleType.GLOBAL,
            },
          });
          await this.notificationService.sendBuyerVerifiedEmail(
            evToken.user.email
          );
        }
      }

      return evToken?.user;
    } catch (e) {
      console.error(e);
    }

    return null;
  }
}
