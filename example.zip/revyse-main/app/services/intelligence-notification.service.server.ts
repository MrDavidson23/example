import type {
  IntelligenceNotification,
  PrismaClient,
  User,
} from "@prisma/client";
import { IntelligenceNotificationType } from "@prisma/client";
import { isEmpty } from "lodash";
import {
  getNotificationIcon,
  getNotificationMessage,
  type IntelligenceNotificationMetadataByType,
  type IntelligenceNotificationMetadataIncludes,
} from "../utils/intelligence-notification.utils";
import { TaskType } from "../utils/tasks.utils";
import type { Task } from "../utils/tasks.utils";
import { z } from "zod";
import type { MockMailService } from "./mail.service.server";
import type { TemplateService } from "./template.service.server";

export class IntelligenceNotificationService {
  constructor(
    private db: PrismaClient,
    private mailService: MockMailService,
    private templateService: TemplateService
  ) {}

  /**
   * Creates a new notification for the given manager account role
   * @param managerAccountRoleId Manager account role id who will receive the notification
   * @param type Notification type
   * @param metadata Notification metadata based on the type
   * @returns Created notification
   */
  async createNotification(
    managerAccountRoleId: string,
    type: IntelligenceNotificationType,
    metadata: IntelligenceNotificationMetadataByType[typeof type]
  ) {
    return await this.db.intelligenceNotification.create({
      data: {
        manager_account_role_id: managerAccountRoleId,
        type,
        metadata,
      },
    });
  }

  async updateReadNotification(notificationId: string, read: boolean) {
    return await this.db.intelligenceNotification.update({
      where: {
        id: notificationId,
      },
      data: {
        read,
      },
    });
  }

  async markAllNotificationsAsRead(managerAccountId: string, userId: string) {
    return await this.db.intelligenceNotification.updateMany({
      where: {
        manager_account_role: {
          manager_account_id: managerAccountId,
          user_id: userId,
        },
        read: false,
      },
      data: {
        read: true,
      },
    });
  }

  async updateArchivedNotification(notificationId: string, archived: boolean) {
    return await this.db.intelligenceNotification.update({
      where: {
        id: notificationId,
      },
      data: {
        archived,
        archived_at: archived ? new Date() : null,
        read: archived ? true : undefined,
      },
    });
  }

  async getNotificationsCounts({
    managerAccountId,
    userId,
    types,
  }: {
    managerAccountId: string;
    userId: string;
    types?: IntelligenceNotificationType[];
  }) {
    const results: Partial<
      Record<"all" | "archived" | IntelligenceNotificationType, number>
    > = {
      all: await this.db.intelligenceNotification.count({
        where: {
          manager_account_role: {
            manager_account_id: managerAccountId,
            user_id: userId,
          },
          archived: false,
          read: false,
        },
      }),
    };

    if (types) {
      await Promise.all(
        types.map(async type => {
          results[type] = await this.db.intelligenceNotification.count({
            where: {
              manager_account_role: {
                manager_account_id: managerAccountId,
                user_id: userId,
              },
              archived: false,
              read: false,
              type,
            },
          });
        })
      );
    }

    return results;
  }

  async getNotifications({
    managerAccountId,
    userId,
    types,
    take,
    skip,
    archived,
  }: {
    managerAccountId: string;
    userId: string;
    types?: IntelligenceNotificationType[];
    take?: number;
    skip?: number;
    archived?: boolean;
  }) {
    const notifications = await this.db.intelligenceNotification.findMany({
      where: {
        manager_account_role: {
          manager_account_id: managerAccountId,
          user_id: userId,
        },
        type: types && !isEmpty(types) ? { in: types } : undefined,
        archived: archived ?? false,
      },
      orderBy: archived
        ? {
            archived_at: "desc",
          }
        : {
            created_at: "desc",
          },
      take,
      skip,
    });

    const notificationsWithData = await Promise.all(
      notifications.map(this.getNotificationWithData.bind(this))
    );

    return notificationsWithData;
  }

  async getNotificationWithData(
    notification: IntelligenceNotification
  ): Promise<IntelligenceNotificationMetadataIncludes | undefined> {
    if (notification.type === IntelligenceNotificationType.TaskMessageMention) {
      const metadata =
        notification.metadata as IntelligenceNotificationMetadataByType[typeof notification.type];
      const task = await this.getTaskWithNeededData(
        metadata.task_id,
        metadata.task_type
      );
      const sender = await this.getSender(metadata.sender_id);

      return {
        ...notification,
        metadata: {
          ...metadata,
          task,
          sender,
        },
      } as IntelligenceNotificationMetadataIncludes;
    }
    if (notification.type === IntelligenceNotificationType.TaskMessageOwner) {
      const metadata =
        notification.metadata as IntelligenceNotificationMetadataByType[typeof notification.type];
      const task = await this.getTaskWithNeededData(
        metadata.task_id,
        metadata.task_type
      );
      const sender = await this.getSender(metadata.sender_id);
      return {
        ...notification,
        metadata: {
          ...metadata,
          task,
          sender,
        },
      } as IntelligenceNotificationMetadataIncludes;
    }
    if (
      notification.type ===
      IntelligenceNotificationType.TaskScheduleStatusChange
    ) {
      const metadata =
        notification.metadata as IntelligenceNotificationMetadataByType[typeof notification.type];
      const task = await this.getTaskWithNeededData(
        metadata.task_id,
        metadata.task_type
      );
      return {
        ...notification,
        metadata: {
          ...metadata,
          task,
        },
      } as IntelligenceNotificationMetadataIncludes;
    }
    if (
      notification.type ===
      IntelligenceNotificationType.TaskCompletionStatusChange
    ) {
      const metadata =
        notification.metadata as IntelligenceNotificationMetadataByType[typeof notification.type];
      const task = await this.getTaskWithNeededData(
        metadata.task_id,
        metadata.task_type
      );
      return {
        ...notification,
        metadata: {
          ...metadata,
          task,
        },
      } as IntelligenceNotificationMetadataIncludes;
    }
    if (notification.type === IntelligenceNotificationType.TaskDueDateChange) {
      const metadata =
        notification.metadata as IntelligenceNotificationMetadataByType[typeof notification.type];
      const task = await this.getTaskWithNeededData(
        metadata.task_id,
        metadata.task_type
      );
      return {
        ...notification,
        metadata: {
          ...metadata,
          new_due_date: new Date(metadata.new_due_date),
          task,
        },
      } as IntelligenceNotificationMetadataIncludes;
    }

    return undefined;
  }

  async getTaskWithNeededData(
    taskId: string,
    taskType: TaskType
  ): Promise<Task | null> {
    const { success } = z.string().uuid().safeParse(taskId);
    if (!success) {
      return null;
    }
    if (taskType === TaskType.TaskContractRenewal) {
      return (await this.db.taskContractRenewal.findUnique({
        include: {
          contract: {
            include: {
              manager_account_vendor: {
                include: {
                  vendor: true,
                },
              },
            },
          },
        },
        where: {
          id: taskId,
        },
      })) as Task;
    } else if (taskType === TaskType.TaskLocationDisposition) {
      return (await this.db.taskLocationDisposition.findUnique({
        include: {
          location: true,
        },
        where: {
          id: taskId,
        },
      })) as Task;
    }
    return null;
  }

  async getSender(
    userId: string
  ): Promise<Pick<
    User,
    "id" | "first_name" | "last_name" | "avatar_url"
  > | null> {
    const managerAccountRole = await this.db.managerAccountRole.findUnique({
      where: {
        id: userId,
      },
      select: {
        user: {
          select: {
            id: true,
            first_name: true,
            last_name: true,
            avatar_url: true,
          },
        },
      },
    });

    return managerAccountRole?.user ?? null;
  }

  async sendConsolidatedNotificationsEmail() {
    const managerAccountRolesWithUnreadNotifications =
      await this.db.managerAccountRole.findMany({
        where: {
          daily_notification_email: true,
          notifications: {
            some: {
              read: false,
            },
          },
          deleted_at: null,
        },
        include: {
          notifications: {
            where: {
              read: false,
            },
            take: 5, // Only get 5 notifications to send in the email
            orderBy: {
              created_at: "desc",
            },
          },
          manager_account: true,
          user: true,
          _count: {
            // Get count of unread notifications
            select: {
              notifications: {
                where: {
                  read: false,
                },
              },
            },
          },
        },
      });

    await Promise.all(
      managerAccountRolesWithUnreadNotifications.map(
        async managerAccountRole => {
          const notificationsWithData = await Promise.all(
            managerAccountRole.notifications.map(
              this.getNotificationWithData.bind(this)
            )
          );

          const notifications = await Promise.all(
            notificationsWithData.map(async notification => {
              if (!notification) return null;
              const message = getNotificationMessage(notification);
              const icon = await getNotificationIcon(notification);
              return { message, icon };
            })
          );
          const filteredNotifications = notifications.filter(Boolean) as {
            message: string;
            icon?: string;
          }[];

          const emailBody =
            this.templateService.renderIntelligenceConsolidatedNotificationsEmail(
              {
                notifications: filteredNotifications,
                manager_account_id: managerAccountRole.manager_account_id,
                manager_account_avatar_id:
                  managerAccountRole.manager_account.avatar_id ?? undefined,
                notifications_count: managerAccountRole._count.notifications,
              }
            );

          await this.mailService.send({
            to: [managerAccountRole.user.email],
            subject: `You have ${
              managerAccountRole._count.notifications
            } unread notification${
              managerAccountRole._count.notifications == 1 ? "" : "s"
            }.`,
            body: emailBody,
          });
        }
      )
    );
  }
}
