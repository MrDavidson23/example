import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { withFixtureFactory } from "../utils/test.utils.server";
import pug from "pug";
import {
  ContractStatus,
  ManagerAccountRoleType,
  ProductState,
  UserRoleType,
} from "@prisma/client";
import { slugify } from "../utils/string.utils";
import dayjs from "dayjs";

const TEST_REVYSE_UI_ORIGIN =
  process.env.REVYSE_UI_ORIGIN || "http://localhost:3000";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const renderLayout = pug.compileFile("app/email-templates/layout.pug");
    return { renderLayout };
  },
});

// Path: app/services/template.service.server.ts
describe("TemplateService", () => {
  describe("renderForgotPasswordEmail", () => {
    it(
      "should render forgot password email",
      withFixtures(async ({ renderLayout }, tx) => {
        const { templateService } = await TestDIContainer(tx);

        const params = {
          token: faker.string.uuid(),
        };

        const forgotPasswordRender = pug.renderFile(
          "app/email-templates/forgot-password.pug",
          {
            REVYSE_UI_ORIGIN: TEST_REVYSE_UI_ORIGIN,
            ...params,
          }
        );

        const email = renderLayout({
          pre_header_text: "Reset your password",
          body: forgotPasswordRender,
        });

        const response = templateService.renderForgotPasswordEmail(params);

        expect(response).toBe(email);
      })
    );
  });

  describe("renderEmailVerificationEmail", () => {
    it(
      "should render email verification email",
      withFixtures(async ({ renderLayout }, tx) => {
        const { templateService } = await TestDIContainer(tx);

        const params = {
          email: faker.internet.email(),
          token: faker.string.uuid(),
        };

        const emailVerificationRender = pug.renderFile(
          "app/email-templates/email-verification.pug",
          {
            REVYSE_UI_ORIGIN: TEST_REVYSE_UI_ORIGIN,
            ...params,
          }
        );

        const email = renderLayout({
          pre_header_text:
            "One more step is required to verify your Revyse account.",
          body: emailVerificationRender,
        });

        const response = templateService.renderEmailVerificationEmail(params);

        expect(response).toBe(email);
      })
    );
  });

  describe("renderListingApprovedEmail", () => {
    it(
      "should render listing approved email",
      withFixtures(async ({ renderLayout }, tx) => {
        const { templateService } = await TestDIContainer(tx);

        const params = {
          product_id: faker.string.uuid(),
          product_name: faker.commerce.productName(),
        };

        const listingApprovedRender = pug.renderFile(
          "app/email-templates/listing-approved.pug",
          {
            REVYSE_UI_ORIGIN: TEST_REVYSE_UI_ORIGIN,
            ...params,
          }
        );

        const email = renderLayout({
          pre_header_text: "Product listing approved",
          body: listingApprovedRender,
        });

        const response = templateService.renderListingApprovedEmail(params);

        expect(response).toBe(email);
      })
    );
  });

  describe("renderBuyerContactEmail", () => {
    it(
      "should render buyer contact email",
      withFixtures(async ({ renderLayout }, tx) => {
        const { templateService } = await TestDIContainer(tx);

        const recipient = await tx.user.create({
          data: {
            email: faker.internet.email(),
            first_name: faker.person.firstName(),
            last_name: faker.person.lastName(),
          },
        });

        const request = await tx.buyerContactRequest.create({
          include: {
            user: true,
            product: true,
          },
          data: {
            description: faker.lorem.paragraph(),
            user: {
              create: {
                email: faker.internet.email(),
                first_name: faker.person.firstName(),
                last_name: faker.person.lastName(),
              },
            },
            product: {
              create: {
                title: `${faker.commerce.productName()} ${faker.string.alphanumeric(
                  5
                )}`,
                description: "description",
                state: ProductState.discovery,
                approved_at: new Date(),
                slug: slugify(
                  `${faker.commerce.productName()} ${faker.string.alphanumeric(
                    5
                  )}`
                ),
                page_title: "page title",
                positioning: "positioning",
                meta_description: "meta description",
                primary_category: {
                  create: {
                    name: `${faker.commerce.department()} ${faker.string.alphanumeric(
                      5
                    )}`,
                    description: "description",
                    slug: "category",
                    faq_1: "faq 1",
                    faq_2: "faq 2",
                    faq_3: "faq 3",
                    faq_1_answer: "faq 1 answer",
                    faq_2_answer: "faq 2 answer",
                    faq_3_answer: "faq 3 answer",
                    meta_description: "meta description",
                    page_title: "page title",
                  },
                },
              },
            },
          },
        });

        const params = {
          recipient,
          request,
        };

        const buyerContactRender = pug.renderFile(
          "app/email-templates/buyer-contact.pug",
          {
            REVYSE_UI_ORIGIN: TEST_REVYSE_UI_ORIGIN,
            ...params,
          }
        );

        const email = renderLayout({
          pre_header_text: "A buyer wants more information about your product",
          body: buyerContactRender,
        });

        const response = templateService.renderBuyerContactEmail(params);

        expect(response).toBe(email);
      })
    );
  });

  describe("renderBuyerVerifiedEmail", () => {
    it(
      "should render buyer verified email",
      withFixtures(async ({ renderLayout }, tx) => {
        const { templateService } = await TestDIContainer(tx);

        const params = {};

        const verifiedBuyerRender = pug.renderFile(
          "app/email-templates/buyer-verified.pug",
          {
            REVYSE_UI_ORIGIN: TEST_REVYSE_UI_ORIGIN,
            ...params,
          }
        );

        const email = renderLayout({
          pre_header_text: "You're a verified buyer!",
          body: verifiedBuyerRender,
        });

        const response = templateService.renderBuyerVerifiedEmail(params);

        expect(response).toBe(email);
      })
    );
  });

  describe("renderReviewApprovedEmail", () => {
    it(
      "should render review approved email",
      withFixtures(async ({ renderLayout }, tx) => {
        const { templateService } = await TestDIContainer(tx);

        const review = await tx.productReview.create({
          include: {
            product: {
              include: {
                vendor: true,
              },
            },
          },
          data: {
            compatibility_score: faker.number.int({ min: 2, max: 5 }),
            customer_service_score: faker.number.int({ min: 2, max: 5 }),
            onboarding_score: faker.number.int({ min: 2, max: 5 }),
            value_score: faker.number.int({ min: 2, max: 5 }),
            compatibility_desc: faker.lorem.sentence(),
            customer_service_desc: faker.lorem.sentence(),
            decision_maker: faker.person.firstName(),
            dislike_most: faker.lorem.sentence(),
            like_most: faker.lorem.sentence(),
            onboarding_desc: faker.lorem.sentence(),
            primary_use_case: faker.lorem.sentence(),
            recommend_to: faker.lorem.sentence(),
            show_company: faker.datatype.boolean(),
            show_job_title: faker.datatype.boolean(),
            show_last_name: faker.datatype.boolean(),
            value_desc: faker.lorem.sentence(),
            product: {
              create: {
                title: `${faker.commerce.productName()} ${faker.string.alphanumeric(
                  5
                )}`,
                description: "description",
                state: ProductState.discovery,
                approved_at: new Date(),
                slug: slugify(
                  `${faker.commerce.productName()} ${faker.string.alphanumeric(
                    5
                  )}`
                ),
                page_title: "page title",
                positioning: "positioning",
                meta_description: "meta description",
                primary_category: {
                  create: {
                    name: `${faker.commerce.department()} ${faker.string.alphanumeric(
                      5
                    )}`,
                    description: "description",
                    slug: "category",
                    faq_1: "faq 1",
                    faq_2: "faq 2",
                    faq_3: "faq 3",
                    faq_1_answer: "faq 1 answer",
                    faq_2_answer: "faq 2 answer",
                    faq_3_answer: "faq 3 answer",
                    meta_description: "meta description",
                    page_title: "page title",
                  },
                },
                vendor: {
                  create: {
                    name: faker.company.name(),
                    description: "description",
                    slug: slugify(faker.company.name()),
                  },
                },
              },
            },
            user: {
              create: {
                email: faker.internet.email(),
                first_name: faker.person.firstName(),
                last_name: faker.person.lastName(),
              },
            },
          },
        });

        const params = {
          review,
        };

        const reviewApprovedRender = pug.renderFile(
          "app/email-templates/review-approved.pug",
          {
            REVYSE_UI_ORIGIN: TEST_REVYSE_UI_ORIGIN,
            ...params,
          }
        );

        const email = renderLayout({
          pre_header_text: "You've got a new Review",
          body: reviewApprovedRender,
        });

        const response = templateService.renderReviewApprovedEmail(params);

        expect(response).toBe(email);
      })
    );
  });

  describe("renderReviewRespondedEmail", () => {
    it(
      "should render review responded email",
      withFixtures(async ({ renderLayout }, tx) => {
        const { templateService } = await TestDIContainer(tx);

        const review = await tx.productReview.create({
          include: {
            product: {
              include: {
                vendor: true,
              },
            },
          },
          data: {
            compatibility_score: faker.number.int({ min: 2, max: 5 }),
            customer_service_score: faker.number.int({ min: 2, max: 5 }),
            onboarding_score: faker.number.int({ min: 2, max: 5 }),
            value_score: faker.number.int({ min: 2, max: 5 }),
            compatibility_desc: faker.lorem.sentence(),
            customer_service_desc: faker.lorem.sentence(),
            decision_maker: faker.person.firstName(),
            dislike_most: faker.lorem.sentence(),
            like_most: faker.lorem.sentence(),
            onboarding_desc: faker.lorem.sentence(),
            primary_use_case: faker.lorem.sentence(),
            recommend_to: faker.lorem.sentence(),
            show_company: faker.datatype.boolean(),
            show_job_title: faker.datatype.boolean(),
            show_last_name: faker.datatype.boolean(),
            value_desc: faker.lorem.sentence(),
            product: {
              create: {
                title: `${faker.commerce.productName()} ${faker.string.alphanumeric(
                  5
                )}`,
                description: "description",
                state: ProductState.discovery,
                approved_at: new Date(),
                slug: slugify(
                  `${faker.commerce.productName()} ${faker.string.alphanumeric(
                    5
                  )}`
                ),
                page_title: "page title",
                positioning: "positioning",
                meta_description: "meta description",
                primary_category: {
                  create: {
                    name: `${faker.commerce.department()} ${faker.string.alphanumeric(
                      5
                    )}`,
                    description: "description",
                    slug: "category",
                    faq_1: "faq 1",
                    faq_2: "faq 2",
                    faq_3: "faq 3",
                    faq_1_answer: "faq 1 answer",
                    faq_2_answer: "faq 2 answer",
                    faq_3_answer: "faq 3 answer",
                    meta_description: "meta description",
                    page_title: "page title",
                  },
                },
                vendor: {
                  create: {
                    name: faker.company.name(),
                    description: "description",
                    slug: slugify(faker.company.name()),
                  },
                },
              },
            },
            user: {
              create: {
                email: faker.internet.email(),
                first_name: faker.person.firstName(),
                last_name: faker.person.lastName(),
              },
            },
          },
        });

        const params = {
          review,
        };

        const reviewRespondedRender = pug.renderFile(
          "app/email-templates/review-responded.pug",
          {
            REVYSE_UI_ORIGIN: TEST_REVYSE_UI_ORIGIN,
            ...params,
          }
        );

        const email = renderLayout({
          pre_header_text: "You've got a response to your review",
          body: reviewRespondedRender,
        });

        const response = templateService.renderReviewRespondedEmail(params);

        expect(response).toBe(email);
      })
    );
  });

  describe("renderUserInvitationEmail", () => {
    it(
      "should render user invitation email",
      withFixtures(async ({ renderLayout }, tx) => {
        const { templateService } = await TestDIContainer(tx);

        const invitation = await tx.userInvitation.create({
          data: {
            email: faker.internet.email(),
            role: {
              role: UserRoleType.PRODUCT_SUBSCRIPTION,
              resource_id: faker.string.uuid(),
            },
          },
        });

        const product = await tx.product.create({
          data: {
            title: `${faker.commerce.productName()} ${faker.string.alphanumeric(
              5
            )}`,
            description: "description",
            state: ProductState.discovery,
            approved_at: new Date(),
            slug: slugify(
              `${faker.commerce.productName()} ${faker.string.alphanumeric(5)}`
            ),
            page_title: "page title",
            positioning: "positioning",
            meta_description: "meta description",
            primary_category: {
              create: {
                name: `${faker.commerce.department()} ${faker.string.alphanumeric(
                  5
                )}`,
                description: "description",
                slug: "category",
                faq_1: "faq 1",
                faq_2: "faq 2",
                faq_3: "faq 3",
                faq_1_answer: "faq 1 answer",
                faq_2_answer: "faq 2 answer",
                faq_3_answer: "faq 3 answer",
                meta_description: "meta description",
                page_title: "page title",
              },
            },
          },
        });

        const params = {
          invitation,
          product,
          email: faker.internet.email(),
          token: faker.string.uuid(),
        };

        const userInvitationRender = pug.renderFile(
          "app/email-templates/user-invitation.pug",
          {
            REVYSE_UI_ORIGIN: TEST_REVYSE_UI_ORIGIN,
            ...params,
          }
        );

        const email = renderLayout({
          pre_header_text:
            "You've been invited to manage a product listing on Revyse ⚒️",
          body: userInvitationRender,
        });

        const response = templateService.renderUserInvitationEmail(params);

        expect(response).toBe(email);
      })
    );
  });

  describe("renderRenewalReminderEmail", () => {
    it(
      "should render renewal reminder email",
      withFixtures(async ({ renderLayout }, tx) => {
        const { templateService } = await TestDIContainer(tx);

        const contract = await tx.contract.create({
          include: {
            manager_account_vendor: {
              include: {
                vendor: true,
                manager_account: true,
              },
            },
          },
          data: {
            name: faker.company.name(),
            status: ContractStatus.Active,
            current_term_end_date: faker.date.future(),
            manager_account_vendor: {
              create: {
                manager_account: {
                  create: {
                    name: faker.company.name(),
                  },
                },
                vendor: {
                  create: {
                    name: faker.company.name(),
                    description: "description",
                    slug: slugify(faker.company.name()),
                  },
                },
              },
            },
          },
        });

        const task = await tx.taskContractRenewal.create({
          include: {
            task_owner: {
              include: {
                user: true,
              },
            },
          },
          data: {
            task_owner: {
              create: {
                role: ManagerAccountRoleType.Owner,
                user: {
                  create: {
                    email: faker.internet.email(),
                    first_name: faker.person.firstName(),
                    last_name: faker.person.lastName(),
                  },
                },
                manager_account: {
                  connect: {
                    id: contract.manager_account_vendor.manager_account.id,
                  },
                },
              },
            },
            start_date: faker.date.past(),
            contract: { connect: { id: contract.id } },
            due_date: faker.date.future(),
            group_chat: {
              create: {},
            },
          },
        });

        const params = {
          contract,
          task,
          formattedCurrentTermEndDate: dayjs
            .utc(contract.current_term_end_date)
            .format("MM/DD/YYYY"),
          formattedDueDate: dayjs.utc(task.due_date).format("MM/DD/YYYY"),
        };

        const renewalReminderRender = pug.renderFile(
          "app/email-templates/renewal-reminder.pug",
          {
            REVYSE_UI_ORIGIN: TEST_REVYSE_UI_ORIGIN,
            ...params,
          }
        );

        const email = renderLayout({
          pre_header_text:
            "Your contract is nearing the end of its current term",
          body: renewalReminderRender,
        });

        const response = templateService.renderRenewalReminderEmail(
          contract,
          task
        );

        expect(response).toBe(email);
      })
    );
  });

  describe("renderManagerAccountUserInvitationEmail", () => {
    it(
      "should render manager account user invitation email",
      withFixtures(async ({ renderLayout }, tx) => {
        const { templateService } = await TestDIContainer(tx);

        const invitation = await tx.userInvitation.create({
          data: {
            email: faker.internet.email(),
            role: {
              role: ManagerAccountRoleType.Editor,
              resource_id: faker.string.uuid(),
            },
          },
        });

        const managerAccount = await tx.managerAccount.create({
          data: {
            name: faker.company.name(),
          },
        });

        const params = {
          invitation,
          managerAccount,
          email: faker.internet.email(),
          token: faker.string.uuid(),
        };

        const managerAccountUserInvitationRender = pug.renderFile(
          "app/email-templates/manager-account-user-invitation.pug",
          {
            REVYSE_UI_ORIGIN: TEST_REVYSE_UI_ORIGIN,
            ...params,
          }
        );

        const email = renderLayout({
          pre_header_text: `You've been invited to manage ${params.managerAccount.name} on Revyse ⚒️`,
          body: managerAccountUserInvitationRender,
        });

        const response =
          templateService.renderManagerAccountUserInvitationEmail(params);

        expect(response).toBe(email);
      })
    );
  });

  describe("renderIntelligenceConsolidatedNotificationsEmail", () => {
    it(
      "should render intelligence consolidated notifications email",
      withFixtures(async ({ renderLayout }, tx) => {
        const { templateService } = await TestDIContainer(tx);

        const notifications = [
          {
            message: faker.lorem.sentence(),
            icon: faker.image.avatar(),
          },
          {
            message: faker.lorem.sentence(),
          },
        ];

        const managerAccount = await tx.managerAccount.create({
          data: {
            name: faker.company.name(),
          },
        });

        const params = {
          notifications,
          manager_account_id: managerAccount.id,
          notifications_count: notifications.length,
        };

        const intelligenceConsolidatedNotificationsRender = pug.renderFile(
          "app/email-templates/intelligence-consolidated-notifications.pug",
          {
            REVYSE_UI_ORIGIN: TEST_REVYSE_UI_ORIGIN,
            defaultNotificationIcon: `${TEST_REVYSE_UI_ORIGIN}/assets/defaultAvatar.png`,
            ...params,
          }
        );

        const email = renderLayout({
          pre_header_text: `You have ${
            params.notifications_count
          } unread notification${params.notifications_count == 1 ? "" : "s"}.`,
          body: intelligenceConsolidatedNotificationsRender,
        });

        const response =
          templateService.renderIntelligenceConsolidatedNotificationsEmail(
            params
          );

        expect(response).toBe(email);
      })
    );
  });
});
