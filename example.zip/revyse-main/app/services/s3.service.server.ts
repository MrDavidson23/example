import { randomUUID } from "crypto";
import {
  unstable_composeUploadHandlers,
  unstable_createMemoryUploadHandler,
  unstable_parseMultipartFormData,
} from "@remix-run/node";
import { isEmpty } from "lodash";
import { getSignedUrl } from "@aws-sdk/s3-request-presigner";
import type {
  PutObjectCommandOutput,
  DeleteObjectCommandOutput,
  GetObjectCommandOutput,
  HeadObjectCommandOutput,
  PutObjectCommandInput,
} from "@aws-sdk/client-s3";
import {
  S3Client,
  DeleteObjectCommand,
  PutObjectCommand,
  HeadObjectCommand,
  GetObjectCommand,
} from "@aws-sdk/client-s3";
import { WebDIContainer } from "../di-containers/web.di-container.server";
import { Readable } from "stream";
import { decodeFilename } from "../utils/file.utils";

const AWS_REGION = process.env.AWS_REGION || "us-west-2";
const AWS_SECRET_ACCESS_KEY =
  process.env.AWS_SECRET_ACCESS_KEY || "PLEASE_SET_AWS_SECRET_ACCESS_KEY";
const AWS_ACCESS_KEY_ID =
  process.env.AWS_ACCESS_KEY_ID || "PLEASE SET_AWS_ACCESS_KEY_ID";
const AWS_S3_BUCKET = process.env.AWS_S3_BUCKET || "PLEASE_SET_AWS_S3_BUCKET";

export type IS3Service = {
  pushObject(
    key: string,
    content: any,
    contentType?: string
  ): Promise<PutObjectCommandOutput>;
  deleteObject(key: string): Promise<DeleteObjectCommandOutput>;
  getFileSignedUrl(key: string, expiresInSeconds: number): Promise<string>;
  getObject(key: string): Promise<GetObjectCommandOutput>;
  getObjectMetadata(key: string): Promise<HeadObjectCommandOutput>;
};

export class MockS3Service implements IS3Service {
  getObjectMetadata(key: string) {
    return {} as any;
  }
  getObject(key: string) {
    return {
      Body: Readable.from(Buffer.from([0x62, 0x75, 0x66, 0x66, 0x65, 0x72])),
    } as any;
  }
  pushObject(key: string, content: any, contentType: string) {
    return {} as any;
  }
  deleteObject(key: string) {
    return {} as any;
  }
  getFileSignedUrl(key: string, expiresInSeconds: number): Promise<string> {
    return {} as any;
  }
}
export class S3Service implements IS3Service {
  private _s3!: S3Client;
  private get s3() {
    if (!this._s3) {
      this._s3 = new S3Client({
        region: AWS_REGION,
        credentials: {
          secretAccessKey: AWS_SECRET_ACCESS_KEY,
          accessKeyId: AWS_ACCESS_KEY_ID,
        },
      });
    }
    return this._s3;
  }

  pushObject(
    key: string,
    content: PutObjectCommandInput["Body"],
    contentType: string
  ) {
    return this.s3.send(
      new PutObjectCommand({
        Bucket: AWS_S3_BUCKET,
        Key: key,
        Body: content,
        ContentType: contentType,
      })
    );
  }

  getObjectMetadata(key: string) {
    return this.s3.send(
      new HeadObjectCommand({
        Bucket: AWS_S3_BUCKET,
        Key: key,
      })
    );
  }

  getObject(key: string) {
    return this.s3.send(
      new GetObjectCommand({
        Bucket: AWS_S3_BUCKET,
        Key: key,
      })
    );
  }

  deleteObject(key: string) {
    return this.s3.send(
      new DeleteObjectCommand({
        Bucket: AWS_S3_BUCKET,
        Key: key,
      })
    );
  }

  async getFileSignedUrl(
    fileKey: string,
    expirationInSeconds: number
  ): Promise<string> {
    const getObjectParams = { Bucket: AWS_S3_BUCKET, Key: fileKey };
    const command = new GetObjectCommand(getObjectParams);
    try {
      return await getSignedUrl(this.s3, command, {
        expiresIn: expirationInSeconds,
      });
    } catch (err) {
      console.error(err);
      throw new Error("Error generating presigned URL");
    }
  }
}

async function convertToBuffer(a: AsyncIterable<Uint8Array>) {
  const result = [];
  for await (const chunk of a) {
    result.push(chunk);
  }
  return Buffer.concat(result);
}

export function parseMultiPartFormDataS3Upload(
  request: Request,
  uploadFields: {
    field: string;
    byteLimit: number;
  }[]
) {
  return unstable_parseMultipartFormData(
    request,
    unstable_composeUploadHandlers(
      async ({ name, contentType, data, filename: encodedFilename }) => {
        const filename = decodeFilename(encodedFilename);
        const field = uploadFields.find(f => f.field === name);
        if (!field) {
          return undefined;
        }
        if (isEmpty(filename)) {
          return "--";
        }

        const fileExt = filename?.split(".").pop() ?? "";

        const { s3Service } = await WebDIContainer();
        const objectId = `${randomUUID()}.${fileExt}`;

        try {
          const { db } = await WebDIContainer();

          console.log("constructing buffer...");
          const buffer = await convertToBuffer(data);
          console.log("uploading to s3", objectId, contentType);
          await s3Service.pushObject(objectId, buffer, contentType);

          console.log("done uploading", objectId);
          const headData = await s3Service.getObjectMetadata(objectId);
          const bytes = headData.ContentLength ?? 0;
          console.log("fetched metadata", objectId, bytes);
          if (bytes > field.byteLimit) {
            console.log("Over max file limit, deleting");
            await s3Service.deleteObject(objectId);
            return "--";
          }

          console.log("creating file");
          const file = await db.file.create({
            data: {
              mime_type: contentType,
              size_kb: Math.round(bytes / 1000.0),
              uri: objectId,
              title: filename!,
            },
          });

          return file.id;
        } catch (e) {
          console.error(e);
        }

        return "--";
      },
      unstable_createMemoryUploadHandler()
    )
  );
}
