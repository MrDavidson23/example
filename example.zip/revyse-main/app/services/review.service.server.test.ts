import {
  Prisma,
  ProductState,
  StripePriceCadence,
  SubscriptionStatus,
  Tier,
  VendorState,
} from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { createTestUser } from "./seeds/createTestUser";
import { slugify } from "../utils/string.utils";

const createNewProductReviewsDefaultParams = {
  title: faker.lorem.sentence(),
  who_uses: ["MY_TEAM"],
  compatibility_score: faker.number.int({ min: 2, max: 5 }),
  customer_service_score: faker.number.int({ min: 2, max: 5 }),
  onboarding_score: faker.number.int({ min: 2, max: 5 }),
  value_score: faker.number.int({ min: 2, max: 5 }),
  compatibility_desc: faker.lorem.sentence(),
  customer_service_desc: faker.lorem.sentence(),
  decision_maker: faker.person.firstName(),
  dislike_most: faker.lorem.sentence(),
  like_most: faker.lorem.sentence(),
  onboarding_desc: faker.lorem.sentence(),
  primary_use_case: faker.lorem.sentence(),
  recommend_to: faker.lorem.sentence(),
  show_company: faker.datatype.boolean(),
  show_job_title: faker.datatype.boolean(),
  show_last_name: faker.datatype.boolean(),
  value_desc: faker.lorem.sentence(),
  custom_question_1: null,
  custom_question_2: null,
  custom_question_3: null,
};

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { authService, db, reviewService } = TestDIContainer(tx);
    const user = await createTestUser(faker.internet.email(), authService);
    const vendorName = faker.company.name();
    const vendor = await db.vendor.create({
      data: {
        slug: slugify(vendorName),
        name: vendorName,
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
        hq_location: faker.location.city(),
        founded_year: faker.date.past().getFullYear().toString(),
        number_employees: faker.number.int({ min: 1, max: 1000 }).toString(),
        linkedin_profile_url: faker.internet.url(),
      },
    });

    const category = await db.productCategory.create({
      data: {
        name: faker.company.name(),
        description: "description",
        slug: "category",
        faq_1: "faq 1",
        faq_2: "faq 2",
        faq_3: "faq 3",
        faq_1_answer: "faq 1 answer",
        faq_2_answer: "faq 2 answer",
        faq_3_answer: "faq 3 answer",
        meta_description: "meta description",
        page_title: "page title",
      },
    });
    const product = await db.product.create({
      data: {
        title: "Test Product",
        description: "description",
        state: ProductState.discovery,
        approved_at: new Date(),
        slug: "test-product",
        page_title: "page title",
        positioning: "positioning",
        meta_description: "meta description",
        primary_category_id: category.id,
        vendor_id: vendor.id,
      },
    });

    const reviews = await Promise.all(
      Array.from({ length: 5 }).map(() =>
        db.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
            approved_at: new Date(),
          },
        })
      )
    );

    return {
      user,
      product,
      reviewService,
      reviews,
    };
  },
});

describe("ProductSlugReviews", () => {
  describe("createNewProductReview, getProductReview", () => {
    test(
      "create and get product review workflow",
      withFixtures(async ({ user, product, reviewService }, tx) => {
        const newReview = await reviewService.createProductReview(
          "new",
          product,
          user.id,
          {
            title: faker.lorem.sentence(),
            who_uses: ["MY_TEAM"],
            compatibility_score: faker.number.int({ min: 2, max: 5 }),
            customer_service_score: faker.number.int({ min: 2, max: 5 }),
            onboarding_score: faker.number.int({ min: 2, max: 5 }),
            value_score: faker.number.int({ min: 2, max: 5 }),
            compatibility_desc: faker.lorem.sentence(),
            customer_service_desc: faker.lorem.sentence(),
            decision_maker: faker.person.firstName(),
            dislike_most: faker.lorem.sentence(),
            like_most: faker.lorem.sentence(),
            onboarding_desc: faker.lorem.sentence(),
            primary_use_case: faker.lorem.sentence(),
            recommend_to: faker.lorem.sentence(),
            show_company: faker.datatype.boolean(),
            show_job_title: faker.datatype.boolean(),
            show_last_name: faker.datatype.boolean(),
            value_desc: faker.lorem.sentence(),
            custom_question_1: null,
            custom_question_2: null,
            custom_question_3: null,
          }
        );
        expect(newReview).not.toBeNull();

        const productReview = await reviewService.getProductReview({
          userId: user.id,
          productId: product.id,
        });
        expect(productReview).not.toBeNull();
      })
    );
  });

  describe("getReviewsByProductIds", () => {
    it(
      "should return reviews for the given product ids",
      withFixtures(async ({ user, product, reviewService, reviews }, tx) => {
        const newProduct = await tx.product.create({
          data: {
            title: "Test Product 2",
            description: "description",
            state: ProductState.discovery,
            approved_at: new Date(),
            slug: "test-product-2",
            page_title: "page title",
            positioning: "positioning",
            meta_description: "meta description",
            primary_category_id: product.primary_category_id,
            vendor_id: product.vendor_id,
          },
        });

        await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
            approved_at: new Date(),
          },
        });

        await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            title: faker.lorem.sentence(),
            product_id: newProduct.id,
            user_id: user.id,
            approved_at: new Date(),
          },
        });

        const reviewsFromService = await reviewService.getReviewsByProductIds([
          product.id,
          newProduct.id,
        ]);
        expect(reviewsFromService).toHaveLength(2 + reviews.length);

        expect(reviewsFromService).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              product_id: product.id,
            }),
            expect.objectContaining({
              product_id: newProduct.id,
            }),
          ])
        );
      })
    );

    it(
      "should return empty array if no reviews found",
      withFixtures(async ({ user, product, reviewService }, tx) => {
        const reviews = await reviewService.getReviewsByProductIds([
          faker.string.uuid(),
        ]);
        expect(reviews).toHaveLength(0);
      })
    );

    it(
      "should return empty array if no product ids provided",
      withFixtures(async ({ reviewService }, tx) => {
        const reviews = await reviewService.getReviewsByProductIds([]);
        expect(reviews).toHaveLength(0);
      })
    );

    it(
      "should return only approved reviews",
      withFixtures(async ({ user, product, reviewService, reviews }, tx) => {
        await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
            approved_at: null,
          },
        });

        const reviewsFromService = await reviewService.getReviewsByProductIds([
          product.id,
        ]);
        expect(reviewsFromService).toHaveLength(reviews.length);
        expect(reviewsFromService).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              product_id: product.id,
            }),
          ])
        );
        expect(reviewsFromService).not.toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              approved_at: null,
            }),
          ])
        );
      })
    );
  });

  describe("updateReviewResponse", () => {
    test(
      "should update review response to an un-responded review",
      withFixtures(async ({ user, product, reviewService }, tx) => {
        const review = await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
            approved_at: new Date(),
          },
        });

        const stripePrice = await tx.stripePrice.create({
          data: {
            id: `price_${faker.string.uuid()}`,
            price: faker.number.int({ min: 1, max: 1000 }),
            cadence: StripePriceCadence.monthly,
            product: {
              create: {
                id: `prod_${faker.string.uuid()}`,
                name: faker.commerce.productName(),
                description: faker.commerce.productDescription(),
                tier: Tier.tier_3,
              },
            },
          },
        });

        await tx.productSubscription.create({
          data: {
            product_id: product.id,
            stripe_id: `sub_${faker.string.uuid()}`,
            status: SubscriptionStatus.active,
            stripe_price_id: stripePrice.id,
          },
        });

        await reviewService.updateReviewResponse(
          review.id,
          "response",
          user.id
        );

        const updatedReview = await tx.productReview.findFirst({
          where: { id: review.id },
          include: {
            product: true,
            user: true,
          },
        });

        expect(updatedReview?.response).toBe("response");
        expect(updatedReview?.responded_by_id).toBe(user.id);
        expect(updatedReview?.responded_at).not.toBeNull();
      })
    );

    test(
      "should update review response to an already responded review",
      withFixtures(async ({ user, product, reviewService }, tx) => {
        const review = await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
            approved_at: new Date(),
            response: "old response",
            responded_at: new Date(),
            responded_by_id: user.id,
          },
        });

        const stripePrice = await tx.stripePrice.create({
          data: {
            id: `price_${faker.string.uuid()}`,
            price: faker.number.int({ min: 1, max: 1000 }),
            cadence: StripePriceCadence.monthly,
            product: {
              create: {
                id: `prod_${faker.string.uuid()}`,
                name: faker.commerce.productName(),
                description: faker.commerce.productDescription(),
                tier: Tier.tier_3,
              },
            },
          },
        });

        await tx.productSubscription.create({
          data: {
            product_id: product.id,
            stripe_id: `sub_${faker.string.uuid()}`,
            status: SubscriptionStatus.active,
            stripe_price_id: stripePrice.id,
          },
        });

        await reviewService.updateReviewResponse(
          review.id,
          "new response",
          user.id
        );

        const updatedReview = await tx.productReview.findFirst({
          where: { id: review.id },
          include: {
            product: true,
            user: true,
          },
        });

        expect(updatedReview?.response).toBe("new response");
        expect(updatedReview?.responded_by_id).toBe(user.id);
        expect(updatedReview?.responded_at).not.toBeNull();
      })
    );

    test(
      "should throw unauthorized error if user does not have permission to respond to reviews",
      withFixtures(async ({ user, product, reviewService }, tx) => {
        const review = await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
            approved_at: new Date(),
          },
        });

        await expect(
          reviewService.updateReviewResponse(review.id, "response", user.id)
        ).rejects.toThrow("Unauthorized");
      })
    );

    test(
      "should throw error if review not found",
      withFixtures(async ({ user, reviewService }, tx) => {
        await expect(
          reviewService.updateReviewResponse(
            faker.string.uuid(),
            "response",
            user.id
          )
        ).rejects.toThrow("No ProductReview found"); // Prisma throws this error
      })
    );
  });

  describe("toggleReviewHelpful", () => {
    test(
      "should mark review as helpful",
      withFixtures(async ({ user, product, reviewService }, tx) => {
        const review = await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
            approved_at: new Date(),
          },
        });

        const { review: updatedReview, helpful } =
          await reviewService.toggleReviewHelpful({
            reviewId: review.id,
            userId: user.id,
          });

        expect(updatedReview.id).toBe(review.id);
        expect(helpful).toBe(true);

        const helpfulRecord = await tx.productReviewHelpful.findFirst({
          where: {
            review_id: review.id,
            user_id: user.id,
          },
        });

        expect(helpfulRecord).not.toBeNull();
      })
    );

    test(
      "should un-mark review as helpful",
      withFixtures(async ({ user, product, reviewService }, tx) => {
        const review = await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
            approved_at: new Date(),
          },
        });

        await tx.productReviewHelpful.create({
          data: {
            user_id: user.id,
            review_id: review.id,
          },
        });

        const { review: updatedReview, helpful } =
          await reviewService.toggleReviewHelpful({
            reviewId: review.id,
            userId: user.id,
          });

        expect(updatedReview.id).toBe(review.id);
        expect(helpful).toBe(false);

        const helpfulRecord = await tx.productReviewHelpful.findFirst({
          where: {
            review_id: review.id,
            user_id: user.id,
          },
        });

        expect(helpfulRecord).toBeNull();
      })
    );

    test(
      "should throw error if review not found",
      withFixtures(async ({ user, reviewService }, tx) => {
        await expect(
          reviewService.toggleReviewHelpful({
            reviewId: faker.string.uuid(),
            userId: user.id,
          })
        ).rejects.toThrow("No ProductReview found"); // Prisma throws this error
      })
    );
  });

  describe("getReviewsCount", () => {
    it(
      "should return count of reviews",
      withFixtures(async ({ user, product, reviewService }, tx) => {
        await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
            approved_at: new Date(),
          },
        });

        const count = await reviewService.getReviewsCount({});
        expect(count).toBeGreaterThan(0);
      })
    );

    it(
      "should return count of reviews by product id",
      withFixtures(async ({ user, product, reviewService, reviews }, tx) => {
        await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
            approved_at: new Date(),
          },
        });

        const count = await reviewService.getReviewsCount({
          where: { product_id: product.id },
        });
        expect(count).toBe(1 + reviews.length);
      })
    );
  });

  describe("getReviews", () => {
    it(
      "should return reviews",
      withFixtures(async ({ product, reviewService, reviews }, tx) => {
        const fetchedReviews = await reviewService.getReviews({
          where: {
            product_id: product.id,
          },
          orderBy: { id: "desc" },
          take: 10,
          skip: 0,
          include: {
            product: true,
            user: true,
            approved_by: true,
            responded_by: true,
          },
        });

        expect(fetchedReviews).toHaveLength(reviews.length);
        expect(fetchedReviews).toEqual(
          expect.arrayContaining(
            reviews.map(review =>
              expect.objectContaining({
                id: review.id,
              })
            )
          )
        );
      })
    );

    it(
      "should return reviews with pagination",
      withFixtures(async ({ product, reviewService, reviews }, tx) => {
        const fetchedReviews = await reviewService.getReviews({
          where: {
            product_id: product.id,
          },
          orderBy: { id: "desc" },
          take: 2,
          skip: 0,
          include: {
            product: true,
            user: true,
            approved_by: true,
            responded_by: true,
          },
        });

        const sortedDBReviews = reviews.sort((a, b) =>
          b.id.localeCompare(a.id)
        );

        expect(fetchedReviews).toHaveLength(2);
        expect(fetchedReviews).toEqual(
          expect.arrayContaining(
            sortedDBReviews.slice(0, 2).map(review =>
              expect.objectContaining({
                id: review.id,
              })
            )
          )
        );
      })
    );
  });

  describe("updateReview", () => {
    test(
      "should update review",
      withFixtures(async ({ user, product, reviewService, reviews }, tx) => {
        const updatedReview = await reviewService.updateReview({
          id: reviews[0].id,
          data: {
            custom_question_1: "New Custom Question 1",
          },
        });

        const reviewFromDb = await tx.productReview.findFirst({
          where: { id: reviews[0].id },
        });

        expect(updatedReview.id).toBe(reviews[0].id);
        expect(reviewFromDb?.custom_question_1).toBe("New Custom Question 1");
      })
    );

    test(
      "should throw error if review not found",
      withFixtures(async ({ user, reviewService }, tx) => {
        await expect(
          reviewService.updateReview({
            id: faker.string.uuid(),
            data: {
              custom_question_1: "New Custom Question 1",
            },
          })
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError); // Prisma throws this error
      })
    );
  });

  describe("updateReviewApproval", () => {
    test(
      "should approve review",
      withFixtures(async ({ user, product, reviewService }, tx) => {
        const review = await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
          },
        });

        const stripePrice = await tx.stripePrice.create({
          data: {
            id: `price_${faker.string.uuid()}`,
            price: faker.number.int({ min: 1, max: 1000 }),
            cadence: StripePriceCadence.monthly,
            product: {
              create: {
                id: `prod_${faker.string.uuid()}`,
                name: faker.commerce.productName(),
                description: faker.commerce.productDescription(),
                tier: Tier.tier_3,
              },
            },
          },
        });

        await tx.productSubscription.create({
          data: {
            product_id: product.id,
            stripe_id: `sub_${faker.string.uuid()}`,
            status: SubscriptionStatus.active,
            stripe_price_id: stripePrice.id,
          },
        });

        await reviewService.updateReviewApproval({
          id: review.id,
          approved: true,
          userId: user.id,
        });

        const reviewFromDb = await tx.productReview.findFirst({
          where: { id: review.id },
        });

        expect(reviewFromDb?.approved_at).not.toBeNull();
        expect(reviewFromDb?.approved_by_id).toBe(user.id);
      })
    );

    test(
      "should un-approve review",
      withFixtures(async ({ user, product, reviewService }, tx) => {
        const review = await tx.productReview.create({
          data: {
            ...createNewProductReviewsDefaultParams,
            product_id: product.id,
            user_id: user.id,
            approved_at: new Date(),
            approved_by_id: user.id,
          },
        });

        await reviewService.updateReviewApproval({
          id: review.id,
          approved: false,
          userId: user.id,
        });

        const reviewFromDb = await tx.productReview.findFirst({
          where: { id: review.id },
        });

        expect(reviewFromDb?.approved_at).toBeNull();
        expect(reviewFromDb?.approved_by_id).toBeNull();
      })
    );
  });

  describe("getReviewById", () => {
    test(
      "should return review by id",
      withFixtures(async ({ reviewService, reviews }, tx) => {
        const fetchedReview = await reviewService.getReviewById({
          id: reviews[0].id,
        });

        expect(fetchedReview).not.toBeNull();
        expect(fetchedReview?.id).toBe(reviews[0].id);
      })
    );
  });

  describe("deleteReview", () => {
    test(
      "should delete review",
      withFixtures(async ({ reviewService, reviews }, tx) => {
        await reviewService.deleteReview({
          id: reviews[0].id,
        });

        const reviewFromDb = await tx.productReview.findFirst({
          where: { id: reviews[0].id },
        });

        expect(reviewFromDb).toBeNull();
      })
    );
  });
});
