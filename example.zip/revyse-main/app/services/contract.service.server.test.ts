import {
  ContractStatus,
  LocationClass,
  LocationStatus,
  Prisma,
  ProductState,
  VendorState,
} from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { createTestUser } from "./seeds/createTestUser";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { authService } = await TestDIContainer(tx);

    const user = await createTestUser(faker.internet.email(), authService);

    const account = await tx.managerAccount.create({
      data: {
        name: faker.company.name(),
        manager_account_vendors: {
          create: {
            vendor: {
              create: {
                name: faker.company.name(),
              },
            },
          },
        },
      },
      include: {
        manager_account_vendors: true,
      },
    });

    const category = await tx.productCategory.create({
      data: {
        name: faker.company.name(),
        description: "description",
        slug: "category",
        faq_1: "faq 1",
        faq_2: "faq 2",
        faq_3: "faq 3",
        faq_1_answer: "faq 1 answer",
        faq_2_answer: "faq 2 answer",
        faq_3_answer: "faq 3 answer",
        meta_description: "meta description",
        page_title: "page title",
      },
    });

    const vendor = await tx.vendor.create({
      data: {
        slug: faker.internet.url(),
        name: faker.company.name(),
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
        products: {
          createMany: {
            data: [
              {
                title: "Contract Service 1",
                description: "description",
                state: ProductState.discovery,
                approved_at: new Date(),
                slug: "contract-service-1",
                page_title: "page title",
                positioning: "positioning",
                meta_description: "meta description",
                primary_category_id: category.id,
              },
              {
                title: "Contract Service 2",
                description: "description",
                state: ProductState.discovery,
                approved_at: new Date(),
                slug: "contract-service-2",
                page_title: "page title",
                positioning: "positioning",
                meta_description: "meta description",
                primary_category_id: category.id,
              },
            ],
          },
        },
      },
      include: {
        products: true,
      },
    });

    const accountVendor = await tx.managerAccountVendor.upsert({
      where: {
        manager_account_id_vendor_id: {
          manager_account_id: account.id,
          vendor_id: vendor.id,
        },
      },
      create: {
        manager_account: { connect: { id: account.id } },
        vendor: { connect: { id: vendor.id } },
      },
      update: {},
    });

    const contracts = await Promise.all(
      Array.from({ length: 3 }).map(() => {
        const isCorporate = !faker.number.int({ min: 0, max: 5 });
        return tx.contract.create({
          data: {
            contract_owner_name: faker.person.fullName(),
            approver: faker.person.fullName(),
            expires_at: faker.date.future(),
            current_term_end_date: faker.date.future(),
            name: faker.commerce.productName(),
            renewal_reminder_lead_time_months: faker.number.int({ max: 12 }),
            status: ContractStatus.Active,
            term_length_months: faker.number.int({ max: 48 }),
            manager_account_vendor: {
              connect: { id: accountVendor.id },
            },
            is_corporate_only: isCorporate,
          },
        });
      })
    );

    const location = await tx.location.create({
      data: {
        name: faker.location.street(),
        pms_id: faker.string.alphanumeric(6),
        owner_name: faker.company.name(),
        street_1: faker.location.streetAddress(),
        street_2: faker.location.secondaryAddress(),
        city: faker.location.city(),
        state: faker.location.state(),
        zip: faker.location.zipCode(),
        region: faker.location.state(),
        unit_count: faker.number.int({ min: 1, max: 1000 }),
        class: faker.helpers.enumValue(LocationClass),
        status: LocationStatus.Active,
        manager_account_id: account.id,
      },
    });

    const productPrices = Array.from(
      "_".repeat(faker.number.int({ min: 1, max: vendor.products.length }))
    ).map(_ => faker.number.int({ min: 100, max: 1000 }));

    const contractWithContractLineItemLocation = await tx.contract.create({
      data: {
        name: faker.commerce.productName(),
        will_auto_renew: true,
        current_term_end_date: null,
        status: ContractStatus.Active,
        is_month_to_month: true,
        manager_account_vendor_id: account.manager_account_vendors[0].id,
        renewal_reminder_lead_time_months: 6,
        auto_renew_term_length: 12,
        contract_owner_name: faker.person.fullName(),
        approver: faker.person.fullName(),
        contract_line_items: {
          create: {
            name: faker.commerce.productName(),
            contract_line_item_locations: {
              create: {
                location: {
                  connect: {
                    id: location.id,
                  },
                },
              },
            },
            contract_line_item_products: {
              createMany: {
                data: productPrices.map(price => ({
                  department: "Support",
                  price: price,
                  product_id:
                    vendor.products[
                      faker.number.int({
                        min: 0,
                        max: vendor.products.length - 1,
                      })
                    ].id,
                })),
              },
            },
          },
        },
      },
      include: {
        manager_account_vendor: {
          include: {
            vendor: true,
          },
        },
        contract_line_items: {
          include: {
            contract_line_item_locations: true,
            contract_line_item_products: {
              include: {
                product: true,
              },
            },
          },
        },
      },
    });

    return {
      user,
      account,
      vendor,
      contract: contractWithContractLineItemLocation,
      location,
      contracts,
    };
  },
});

describe("ContractService", () => {
  describe("createContract", () => {
    test(
      "it should create a contract",
      withFixtures(async ({ user, contract, account, vendor }, tx) => {
        const { contractService } = TestDIContainer(tx);

        const newContract = await contractService.upsertContract(
          "new",
          { id: user.id, email: user.email },
          {
            name: "New Contract Upsert Method",
            status: ContractStatus.Pending,
            will_auto_renew: true,
            is_msa: false,
            is_month_to_month: false,
            document_files: [],
            vendor_id: vendor.id,
            new_vendor: "false",
          },
          account.id
        );

        expect(newContract).toBeDefined();
        expect(newContract).not.toBeNull();
        expect(newContract.status).toEqual(ContractStatus.Pending);
        expect(newContract.name).toEqual("New Contract Upsert Method");

        const updatedContract = await contractService.upsertContract(
          contract.id,
          { id: user.id, email: user.email },
          {
            name: "Updated Contract Upsert Method",
            status: contract.status,
            will_auto_renew: contract.will_auto_renew,
            is_msa: contract.is_msa,
            is_month_to_month: contract.is_month_to_month,
            document_files: [],
            vendor_id: vendor.id,
            new_vendor: "false",
          },
          account.id
        );
        expect(updatedContract.name).toEqual("Updated Contract Upsert Method");
      })
    );
  });

  describe("getContractById", () => {
    test(
      "it should return a contract by id",
      withFixtures(async ({ contract }, tx) => {
        const { contractService } = TestDIContainer(tx);

        const testContract = await contractService.getContractById(contract.id);

        expect(testContract).not.toBeNull();
        expect(testContract.name).toEqual(contract.name);
        expect(testContract.status).toEqual(contract.status);
        expect(testContract.current_term_end_date).toEqual(
          testContract.current_term_end_date
        );
      })
    );
  });

  describe("getContractWithLineItemDetails", () => {
    test(
      "it should return a contract by id including the contract line item details",
      withFixtures(async ({ contract }, tx) => {
        const { contractService } = TestDIContainer(tx);

        const testContract =
          await contractService.getContractWithLineItemDetails(contract.id);

        expect(testContract).not.toBeNull();
        expect(testContract.contract_line_items).toBeDefined();
        expect(
          testContract.contract_line_items[0].contract_line_item_locations
        ).toEqual(contract.contract_line_items[0].contract_line_item_locations);
        expect(
          testContract.contract_line_items[0].contract_line_item_products
        ).toEqual(contract.contract_line_items[0].contract_line_item_products);
      })
    );
  });

  describe("getContractOwnersAndApprovers", () => {
    test(
      "it should unique set of approver and owner names",
      withFixtures(async ({ contract, contracts, account }, tx) => {
        const { contractService } = TestDIContainer(tx);

        const ownersAndApprovers =
          await contractService.getContractOwnersAndApprovers({
            manager_account_vendor: {
              manager_account_id: account.id,
            },
          });

        expect(ownersAndApprovers).not.toBeNull();
        expect(ownersAndApprovers).toContain(contract.contract_owner_name);
        expect(ownersAndApprovers).toContain(contract.approver);

        expect(ownersAndApprovers).toContain(contracts[0].contract_owner_name);
        expect(ownersAndApprovers).toContain(contracts[0].approver);
        expect(ownersAndApprovers).toContain(contracts[1].contract_owner_name);
        expect(ownersAndApprovers).toContain(contracts[1].approver);
      })
    );
  });

  describe("loadContractedLocations", () => {
    test(
      "it should return the contract's assigned locations",
      withFixtures(async ({ contract }, tx) => {
        const { contractService } = TestDIContainer(tx);

        const contractedLocations =
          await contractService.loadContractedLocations(contract.id, {
            contract_line_item: {
              contract_id: contract.id,
            },
          });

        expect(contractedLocations).not.toBeNull();
        expect(
          contractedLocations[0].contract_line_item_locations
        ).not.toBeNull();
      })
    );
  });

  describe("handleContractLocationFile, deleteContractLocationFile", () => {
    test(
      "should create or update a contract location file",
      withFixtures(async ({ contract, location }, tx) => {
        const { contractService } = TestDIContainer(tx);
        const file = await tx.file.create({
          data: {
            title: "image",
            uri: "uri",
            mime_type: "mime_type",
            size_kb: 100,
          },
        });

        const contractLocationFile =
          await contractService.handleContractLocationFile({
            id: "new_file",
            name: "name",
            file: file.id,
            locationId: location.id,
            contractId: contract.id,
          });

        expect(contractLocationFile).not.toBeNull();

        const updatedContractLocationFile =
          await contractService.handleContractLocationFile({
            id: contractLocationFile.id,
            name: "new name",
            file: file.id,
            locationId: location.id,
            contractId: contract.id,
          });

        expect(updatedContractLocationFile.name).toBe("new name");
      })
    );

    test(
      "should delete a contract location file",
      withFixtures(async ({ contract, location }, tx) => {
        const { contractService } = TestDIContainer(tx);
        const file = await tx.file.create({
          data: {
            title: "image",
            uri: "uri",
            mime_type: "mime_type",
            size_kb: 100,
          },
        });

        const contractLocationFile =
          await contractService.handleContractLocationFile({
            id: "new_file",
            name: "name",
            file: file.id,
            locationId: location.id,
            contractId: contract.id,
          });
        await contractService.deleteContractLocationFile(
          contractLocationFile.id
        );

        const doc = await tx.contractLocationFile.findFirst({
          where: {
            id: contractLocationFile.id,
          },
        });

        expect(doc).toBeNull();
      })
    );
  });

  describe("deleteContract", () => {
    test(
      "it should delete a contract",
      withFixtures(async ({ contract }, tx) => {
        const { contractService } = TestDIContainer(tx);

        await contractService.deleteContract(contract.id);

        const deletedContractLineItems = await tx.contractLineItem.findMany({
          where: {
            contract: {
              id: contract.id,
            },
          },
        });

        expect(deletedContractLineItems).toHaveLength(0);

        const deletedContract = await tx.contract.findFirst({
          where: {
            id: contract.id,
          },
        });

        expect(deletedContract).toBeNull();
      })
    );

    test(
      "it should throw an error if the contract does not exist",
      withFixtures(async (_, tx) => {
        const { contractService } = TestDIContainer(tx);

        await expect(
          contractService.deleteContract(faker.string.uuid())
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError);
      })
    );
  });

  describe("archiveContract", () => {
    test(
      "it should archive a contract",
      withFixtures(async ({ contract }, tx) => {
        const { contractService } = TestDIContainer(tx);

        const canceledAt = new Date();

        await contractService.archiveContract(contract.id, canceledAt);

        const archivedContract = await tx.contract.findFirst({
          where: {
            id: contract.id,
          },
        });

        expect(archivedContract?.status).toEqual(ContractStatus.Canceled);
        expect(archivedContract?.canceled_at).toEqual(canceledAt);
      })
    );

    test(
      "it should throw an error if the contract does not exist",
      withFixtures(async (_, tx) => {
        const { contractService } = TestDIContainer(tx);

        await expect(
          contractService.archiveContract(faker.string.uuid(), new Date())
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError);
      })
    );
  });

  describe("getContractDetails", () => {
    test(
      "it should return contract details",
      withFixtures(async ({ contract }, tx) => {
        const { contractService } = TestDIContainer(tx);

        const contractDetails = await contractService.getContractDetails(
          contract.id
        );

        expect(contractDetails).not.toBeNull();
        expect(contractDetails.id).toBe(contract.id);
        expect(contractDetails.contract_line_items).not.toBeNull();
      })
    );

    test(
      "it should throw an error if the contract does not exist",
      withFixtures(async (_, tx) => {
        const { contractService } = TestDIContainer(tx);

        await expect(
          contractService.getContractDetails(faker.string.uuid())
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError);
      })
    );
  });

  describe("handleContractDocument, deleteContractDocument", () => {
    test(
      "should create or update a contract document",
      withFixtures(async ({ contract }, tx) => {
        const { contractService } = TestDIContainer(tx);
        const file = await tx.file.create({
          data: {
            title: "image",
            uri: "uri",
            mime_type: "mime_type",
            size_kb: 100,
          },
        });

        const contractDocument = await contractService.handleContractDocument({
          id: "new_file",
          name: "name",
          file: file.id,
          contractId: contract.id,
        });

        expect(contractDocument).not.toBeNull();

        const updatedVendorDocument =
          await contractService.handleContractDocument({
            id: contractDocument.id,
            name: "new name",
            file: file.id,
            contractId: contract.id,
          });

        expect(updatedVendorDocument.name).toBe("new name");
      })
    );

    test(
      "should delete a contract document",
      withFixtures(async ({ contract }, tx) => {
        const { contractService } = TestDIContainer(tx);
        const file = await tx.file.create({
          data: {
            title: "image",
            uri: "uri",
            mime_type: "mime_type",
            size_kb: 100,
          },
        });

        const contractDocument = await contractService.handleContractDocument({
          id: "new_file",
          name: "name",
          file: file.id,
          contractId: contract.id,
        });
        await contractService.deleteContractDocument(contractDocument.id);

        const doc = await tx.managerAccountVendorDocument.findFirst({
          where: {
            id: contractDocument.id,
          },
        });

        expect(doc).toBeNull();
      })
    );
  });
});
