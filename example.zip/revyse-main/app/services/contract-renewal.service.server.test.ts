import { faker } from "@faker-js/faker";
import { ContractStatus, ManagerAccountRoleType } from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { withFixtureFactory } from "../utils/test.utils.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
dayjs.extend(utc);

const generateGenericContractData = () => ({
  contract_owner_name: faker.person.fullName(),
  approver: faker.person.fullName(),
  expires_at: faker.date.future(),
  current_term_end_date: faker.date.future(),
  renewal_reminder_lead_time_months: faker.number.int({ max: 12 }),
  will_auto_renew: true,
  renewal_reminder_date: faker.date.soon(),
  name: faker.commerce.productName(),
  status: ContractStatus.Active,
  term_length_months: faker.number.int({ max: 48 }),
  renewal_reminder_emails: Array.from({
    length: faker.number.int({ max: 3 }),
  }).map(() => faker.internet.email({ provider: "example.com" })),
});

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const users = await Promise.all(
      Array.from({ length: 3 }).map(async () => {
        return tx.user.create({
          data: {
            email: faker.internet.email(),
            first_name: faker.person.firstName(),
            last_name: faker.person.lastName(),
          },
        });
      })
    );

    const accounts = await Promise.all(
      users.map(async user => {
        return tx.managerAccount.create({
          data: {
            name: faker.company.name(),
            manager_account_roles: {
              createMany: {
                data: Array.from({ length: 3 }).map(() => ({
                  role: faker.helpers.enumValue(ManagerAccountRoleType),
                  user_id: user.id,
                })),
              },
            },
          },
          include: {
            manager_account_roles: {
              where: {
                deleted_at: null,
              },
            },
          },
        });
      })
    );

    const contractsReadyForRenewalReminderWithRenewalReminderDate =
      await Promise.all(
        accounts.map(async account => {
          return tx.contract.create({
            data: {
              ...generateGenericContractData(),
              will_auto_renew: true,
              renewal_reminder_date: dayjs.utc().startOf("day").toDate(),
              status: ContractStatus.Active,
              manager_account_vendor: {
                create: {
                  vendor: {
                    create: {
                      name: faker.company.name(),
                    },
                  },
                  manager_account: {
                    connect: {
                      id: account.id,
                    },
                  },
                },
              },
              task_owner: {
                connect: {
                  id: account.manager_account_roles[0].id,
                },
              },
            },
          });
        })
      );

    const contractsReadyForRenewalReminderWithCurrentTermEndDate =
      await Promise.all(
        accounts.map(async account => {
          const months = faker.number.int({ min: 1, max: 11 });

          const current_term_end_date = dayjs
            .utc()
            .add(months, "month")
            .startOf("day");
          const renewal_reminder_date = dayjs
            .utc(current_term_end_date)
            .subtract(months, "month")
            .startOf("day");

          const will_auto_renew = renewal_reminder_date.isSame(
            dayjs.utc().startOf("day")
          );

          return tx.contract.create({
            data: {
              ...generateGenericContractData(),
              current_term_end_date: current_term_end_date.toDate(),
              renewal_reminder_lead_time_months: months,
              will_auto_renew,
              status: ContractStatus.Active,
              renewal_reminder_date: null,
              manager_account_vendor: {
                create: {
                  vendor: {
                    create: {
                      name: faker.company.name(),
                    },
                  },
                  manager_account: {
                    connect: {
                      id: account.id,
                    },
                  },
                },
              },
              task_owner: {
                connect: {
                  id: account.manager_account_roles[0].id,
                },
              },
            },
          });
        })
      );

    const contractsNotReadyForRenewalReminder = await Promise.all(
      accounts.map(async account => {
        return tx.contract.create({
          data: {
            ...generateGenericContractData(),
            current_term_end_date: faker.date.future({
              refDate: dayjs().add(1, "year").toDate(),
            }), // random future date one year from now
            will_auto_renew: true,
            renewal_reminder_date: null,
            renewal_reminder_lead_time_months: faker.number.int({ max: 12 }),
            manager_account_vendor: {
              create: {
                vendor: {
                  create: {
                    name: faker.company.name(),
                  },
                },
                manager_account: {
                  connect: {
                    id: account.id,
                  },
                },
              },
            },
            task_owner: {
              connect: {
                id: account.manager_account_roles[0].id,
              },
            },
          },
        });
      })
    );

    return {
      users,
      accounts,
      contractsReadyForRenewalReminderWithRenewalReminderDate,
      contractsReadyForRenewalReminderWithCurrentTermEndDate,
      contractsNotReadyForRenewalReminder,
    };
  },
});

describe("ContractRenewalService", () => {
  describe("handleContractRenewal", () => {
    it(
      "sends renewal emails and creates tasks for contracts that are due for renewal",
      withFixtures(
        async (
          {
            contractsReadyForRenewalReminderWithRenewalReminderDate,
            contractsReadyForRenewalReminderWithCurrentTermEndDate,
            contractsNotReadyForRenewalReminder,
          },
          tx
        ) => {
          const { contractRenewalService, mailService, templateService } =
            TestDIContainer(tx);

          const mailServiceSendSpy = jest.spyOn(mailService, "send");

          const templateServiceRenderRenewalReminderEmailSpy = jest.spyOn(
            templateService,
            "renderRenewalReminderEmail"
          );

          await contractRenewalService.handleContractRenewal();

          const contractsReadyForRenewal = [
            ...contractsReadyForRenewalReminderWithRenewalReminderDate,
            ...contractsReadyForRenewalReminderWithCurrentTermEndDate.filter(
              c => c.will_auto_renew
            ),
          ];

          expect(mailServiceSendSpy.mock.calls.length).toBeGreaterThanOrEqual(
            contractsReadyForRenewal.length
          );

          expect(
            templateServiceRenderRenewalReminderEmailSpy.mock.calls.length
          ).toBeGreaterThanOrEqual(contractsReadyForRenewal.length);

          for (const contract of contractsReadyForRenewal) {
            expect(mailServiceSendSpy).toHaveBeenCalledWith(
              {
                to: contract.renewal_reminder_emails,
                subject: `Contract Renewal Reminder | ${contract.name}`,
                body: templateServiceRenderRenewalReminderEmailSpy.mock.results[
                  contractsReadyForRenewal.indexOf(contract)
                ].value,
              }
            );

            const task = await tx.taskContractRenewal.findFirst({
              where: {
                contract_id: contract.id,
              },
            });

            expect(task).not.toBeNull();
          }

          for (const contract of contractsNotReadyForRenewalReminder) {
            expect(mailServiceSendSpy).not.toHaveBeenCalledWith({
              to: contract.renewal_reminder_emails,
              subject: `Contract Renewal Reminder | ${contract.name}`,
              body: expect.any(String),
            });

            expect(
              templateServiceRenderRenewalReminderEmailSpy
            ).not.toHaveBeenCalledWith(contract, expect.any(Object));
          }
        }
      )
    );
  });
});
