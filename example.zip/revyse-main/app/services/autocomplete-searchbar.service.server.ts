import {
  type PrismaClient,
  SubscriptionStatus,
  VendorState,
  ProductState,
  Tier,
} from "@prisma/client";

type ProductQueryResult = {
  id: string;
  title: string;
  description: string;
  logo_file_id: string;
  slug: string;
  tier: string;
};

type VendorQueryResult = {
  id: string;
  name: string;
  logo_file_id: string;
  slug: string;
};

export class AutocompleteSearchBarService {
  constructor(private db: PrismaClient) {}

  private async executeProductOrVendorQuery(
    searchTerm: string,
    isProduct: boolean,
    take: number
  ) {
    const result = await this.db.$queryRawUnsafe<
      ProductQueryResult[] | VendorQueryResult[]
    >(`
    SELECT * FROM 
    (
      SELECT 
        ${
          isProduct
            ? "DISTINCT ON (p.id) p.id, p.title, p.slug, p.logo_file_id, v.name as vendor_name, v.logo_file_id as vendor_logo_file_id"
            : "DISTINCT ON (v.id) v.id, v.name, v.slug, v.logo_file_id"
        },
        pp.tier::text AS tier
      FROM 
        product p
      JOIN 
        vendor v ON p.vendor_id = v.id
      LEFT JOIN 
        "product_subscription" ps ON p.id = ps.product_id AND ps.status::text = '${
          SubscriptionStatus.active
        }'::text
      LEFT JOIN 
        "stripe_price" sp ON ps.stripe_price_id = sp.id
      LEFT JOIN 
        "stripe_product" pp ON sp.product_id = pp.id
      WHERE 
        ${
          isProduct
            ? `p.title ILIKE '%${searchTerm}%'`
            : `v.name ILIKE '%${searchTerm}%'`
        }  
        AND p.state::text = '${ProductState.discovery}'::text
        AND v.state::text = '${VendorState.ApprovedForPublishing}'::text
      GROUP BY 
        ${
          isProduct
            ? `p.id, p.title, p.slug, p.logo_file_id, v.name, v.logo_file_id`
            : `v.id, v.name, v.slug, v.logo_file_id`
        }, pp.tier
    ) AS temp
    ORDER BY 
      CASE temp.tier
        WHEN '${Tier.tier_3}'::text THEN 1
        WHEN '${Tier.tier_2}'::text THEN 2
        WHEN '${Tier.tier_1}'::text THEN 3
        WHEN '${Tier.free}'::text THEN 4
        ELSE 5
      END
    LIMIT ${take};
  `);
    return result;
  }

  async getProductsBySearchTerm(searchTerm: string) {
    return await this.executeProductOrVendorQuery(searchTerm, true, 20);
  }

  async getVendorsBySearchTerm(searchTerm: string) {
    return await this.executeProductOrVendorQuery(searchTerm, false, 5);
  }

  async getCategoriesBySearchTerm(searchTerm: string) {
    return await this.db.productCategory.findMany({
      where: {
        OR: [{ name: { contains: searchTerm, mode: "insensitive" } }],
      },
      select: {
        id: true,
        name: true,
        slug: true,
      },
      take: 5,
      orderBy: {
        name: "asc",
      },
    });
  }
}
