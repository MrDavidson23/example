import {
  ContractStatus,
  IntelligenceNotificationType,
  LocationStatus,
  LocationClass,
  ManagerAccountRoleType,
  TaskCompletionStatus,
  TaskScheduleStatus,
  VendorState,
} from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { createTestUser } from "./seeds/createTestUser";
import { TaskType } from "../utils/tasks.utils";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { authService } = TestDIContainer(tx);

    const user = await createTestUser(faker.internet.email(), authService);

    const account = await tx.managerAccount.create({
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
        },
      },
      data: {
        name: faker.company.name(),
        manager_account_roles: {
          create: {
            role: "Owner",
            user: {
              connect: {
                id: user.id,
              },
            },
          },
        },
      },
    });

    const user2 = await tx.user.create({
      data: {
        email: faker.internet.email({ provider: "test.com" }),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
      },
    });

    const userRole = await tx.managerAccountRole.create({
      data: {
        manager_account: { connect: { id: account.id } },
        user: { connect: { id: user2.id } },
        role: ManagerAccountRoleType.Editor,
      },
    });

    const vendor = await tx.vendor.create({
      data: {
        slug: faker.internet.url(),
        name: faker.company.name(),
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
      },
    });

    const accountVendor = await tx.managerAccountVendor.upsert({
      where: {
        manager_account_id_vendor_id: {
          manager_account_id: account.id,
          vendor_id: vendor.id,
        },
      },
      create: {
        manager_account: { connect: { id: account.id } },
        vendor: { connect: { id: vendor.id } },
      },
      update: {},
    });

    const contracts = await Promise.all(
      Array.from({ length: 20 }).map(() => {
        const isCorporate = !faker.number.int({ min: 0, max: 5 });
        return tx.contract.create({
          data: {
            contract_owner_name: faker.person.fullName(),
            approver: faker.person.fullName(),
            expires_at: faker.date.future(),
            current_term_end_date: faker.date.future(),
            name: faker.commerce.productName(),
            renewal_reminder_lead_time_months: faker.number.int({ max: 12 }),
            status: ContractStatus.Active,
            term_length_months: faker.number.int({ max: 48 }),
            manager_account_vendor: {
              connect: { id: accountVendor.id },
            },
            is_corporate_only: isCorporate,
          },
        });
      })
    );

    const locations = await Promise.all(
      Array.from({ length: 20 }).map(() => {
        return tx.location.create({
          data: {
            name: faker.location.secondaryAddress(),
            pms_id: faker.string.alphanumeric(6),
            street_1: faker.location.streetAddress(),
            city: faker.location.city(),
            state: faker.location.state(),
            zip: faker.location.zipCode(),
            status: faker.helpers.enumValue(LocationStatus),
            manager_account: {
              connect: { id: account.id },
            },
            unit_count: faker.number.int({ min: 1, max: 1000 }),
            class: faker.helpers.enumValue(LocationClass),
          },
        });
      })
    );

    const contractRenewalTasks = await Promise.all(
      contracts.map(contract => {
        const dueDate =
          contract.expires_at ??
          contract.current_term_end_date ??
          faker.date.soon();

        const startDate = faker.helpers.arrayElement([
          faker.date.soon({ days: faker.number.int({ min: 1, max: 30 }) }),
          faker.date.recent({ days: faker.number.int({ min: 1, max: 30 }) }),
        ]);

        return tx.taskContractRenewal.create({
          data: {
            contract: { connect: { id: contract.id } },
            due_date: dueDate,
            task_owner: {
              connect: { id: account.manager_account_roles[0].id },
            },
            start_date: startDate,
            schedule_status:
              new Date() > startDate
                ? new Date() > dueDate
                  ? TaskScheduleStatus.Overdue
                  : TaskScheduleStatus.ReadyToDo
                : TaskScheduleStatus.Upcoming,
            completion_status: faker.helpers.enumValue(TaskCompletionStatus),
            group_chat: {
              create: {},
            },
          },
          include: {
            contract: true,
          },
        });
      })
    );

    const locationDispositionTasks = await Promise.all(
      locations.map(location => {
        const dueDate = faker.date.soon();

        const startDate = faker.helpers.arrayElement([
          faker.date.soon({ days: faker.number.int({ min: 1, max: 30 }) }),
          faker.date.recent({ days: faker.number.int({ min: 1, max: 30 }) }),
        ]);

        return tx.taskLocationDisposition.create({
          data: {
            location: { connect: { id: location.id } },
            due_date: dueDate,
            task_owner: {
              connect: { id: account.manager_account_roles[0].id },
            },
            start_date: startDate,
            schedule_status:
              new Date() > startDate
                ? new Date() > dueDate
                  ? TaskScheduleStatus.Overdue
                  : TaskScheduleStatus.ReadyToDo
                : TaskScheduleStatus.Upcoming,
            completion_status: faker.helpers.enumValue(TaskCompletionStatus),
            group_chat: {
              create: {},
            },
          },
          include: {
            location: true,
          },
        });
      })
    );

    const tasks = [...contractRenewalTasks, ...locationDispositionTasks];

    return {
      user,
      account,
      vendor,
      accountVendor,
      contracts,
      locations,
      tasks,
      locationDispositionTasks,
      contractRenewalTasks,
      userRole,
    };
  },
});

describe("ManagerAccountTask", () => {
  describe("getPendingTaskCount", () => {
    test(
      "get pending tasks count for account user",
      withFixtures(
        async ({ user, account, tasks, locationDispositionTasks }, tx) => {
          const { managerAccountTaskService } = TestDIContainer(tx);

          const pendingTasks = tasks.filter(
            task =>
              (task.schedule_status === TaskScheduleStatus.Overdue ||
                task.schedule_status === TaskScheduleStatus.ReadyToDo) &&
              task.completion_status === TaskCompletionStatus.Incomplete
          );
          const servicePendingTasksCount =
            await managerAccountTaskService.getPendingTasksCount(
              account.id,
              user.id
            );

          expect(servicePendingTasksCount).toBe(pendingTasks.length);
        }
      )
    );
  });

  describe("loadLocationDispositionTask", () => {
    test(
      "should get a task of type `TaskLocationDisposition",
      withFixtures(async ({ locationDispositionTasks }, tx) => {
        const { managerAccountTaskService } = TestDIContainer(tx);

        const task =
          await managerAccountTaskService.loadLocationDispositionTask(
            locationDispositionTasks[0].id
          );

        expect(task?.location_id).toEqual(
          locationDispositionTasks[0].location_id
        );
      })
    );
  });

  describe("loadContractRenewalTask", () => {
    test(
      "should get a task of type `TaskContractRenewal",
      withFixtures(async ({ contractRenewalTasks }, tx) => {
        const { managerAccountTaskService } = TestDIContainer(tx);

        const task = await managerAccountTaskService.loadContractRenewalTask(
          contractRenewalTasks[0].id
        );

        expect(task?.contract_id).toEqual(contractRenewalTasks[0].contract_id);
      })
    );
  });

  describe("archiveLocationDispositionTask", () => {
    test(
      "should archive a task of type `TaskLocationDisposition",
      withFixtures(async ({ locationDispositionTasks }, tx) => {
        const { managerAccountTaskService } = TestDIContainer(tx);
        await managerAccountTaskService.archiveLocationDispositionTask(
          locationDispositionTasks[0].id
        );

        const task = await tx.taskLocationDisposition.findFirst({
          where: {
            id: locationDispositionTasks[0].id,
          },
        });

        expect(task?.completion_status).toEqual(TaskCompletionStatus.Canceled);
        expect(task?.schedule_status).toEqual(TaskScheduleStatus.Archived);
      })
    );
  });

  describe("archiveContractRenewalTask", () => {
    test(
      "should archive a task of type `TaskContractRenewal",
      withFixtures(async ({ contractRenewalTasks }, tx) => {
        const { managerAccountTaskService } = TestDIContainer(tx);
        await managerAccountTaskService.archiveContractRenewalTask(
          contractRenewalTasks[0].id
        );

        const task = await tx.taskContractRenewal.findFirst({
          where: {
            id: contractRenewalTasks[0].id,
          },
        });

        expect(task?.completion_status).toEqual(TaskCompletionStatus.Canceled);
        expect(task?.schedule_status).toEqual(TaskScheduleStatus.Archived);
      })
    );
  });

  describe("activateLocationDispositionTask", () => {
    test(
      "should activate a task of type `TaskLocationDisposition",
      withFixtures(async ({ locationDispositionTasks }, tx) => {
        const { managerAccountTaskService } = TestDIContainer(tx);
        await managerAccountTaskService.activateLocationDispositionTask(
          locationDispositionTasks[0].id
        );

        const task = await tx.taskLocationDisposition.findFirst({
          where: {
            id: locationDispositionTasks[0].id,
          },
        });

        expect(task?.completion_status).toEqual(
          TaskCompletionStatus.Incomplete
        );
        if (task?.due_date && task?.due_date > new Date()) {
          expect(task?.schedule_status).toEqual(TaskScheduleStatus.ReadyToDo);
        } else {
          expect(task?.schedule_status).toEqual(TaskScheduleStatus.Overdue);
        }
      })
    );
  });

  describe("activateContractRenewalTask", () => {
    test(
      "should activate a task of type `TaskContractRenewal",
      withFixtures(async ({ contractRenewalTasks }, tx) => {
        const { managerAccountTaskService } = TestDIContainer(tx);
        await managerAccountTaskService.activateContractRenewalTask(
          contractRenewalTasks[0].id
        );

        const task = await tx.taskContractRenewal.findFirst({
          where: {
            id: contractRenewalTasks[0].id,
          },
        });

        expect(task?.completion_status).toEqual(
          TaskCompletionStatus.Incomplete
        );
        if (task?.due_date && task?.due_date > new Date()) {
          expect(task?.schedule_status).toEqual(TaskScheduleStatus.ReadyToDo);
        } else {
          expect(task?.schedule_status).toEqual(TaskScheduleStatus.Overdue);
        }
      })
    );
  });

  describe("updateLocationDispositionTask", () => {
    test(
      "should update a task of type `TaskLocationDisposition",
      withFixtures(async ({ locationDispositionTasks, userRole }, tx) => {
        const { managerAccountTaskService } = TestDIContainer(tx);

        const soonDate = faker.date.soon();
        const task =
          await managerAccountTaskService.updateLocationDispositionTask(
            locationDispositionTasks[0].id,
            soonDate,
            userRole.id
          );

        expect(task?.due_date).toEqual(soonDate);
        expect(task?.task_owner_id).toEqual(userRole.id);
        locationDispositionTasks[0].schedule_status ===
        TaskScheduleStatus.ReadyToDo
          ? expect(task?.schedule_status).toEqual(TaskScheduleStatus.ReadyToDo)
          : expect(task?.schedule_status).toEqual(
              locationDispositionTasks[0].schedule_status
            );
      })
    );
  });

  describe("updateContractRenewalTask", () => {
    test(
      "should update a task of type `TaskContractRenewal",
      withFixtures(async ({ contractRenewalTasks, userRole }, tx) => {
        const { managerAccountTaskService } = TestDIContainer(tx);

        const soonDate = faker.date.soon();
        const task = await managerAccountTaskService.updateContractRenewalTask(
          contractRenewalTasks[0].id,
          soonDate,
          userRole.id
        );

        expect(task?.due_date).toEqual(soonDate);
        expect(task?.task_owner_id).toEqual(userRole.id);
        contractRenewalTasks[0].schedule_status === TaskScheduleStatus.ReadyToDo
          ? expect(task?.schedule_status).toEqual(TaskScheduleStatus.ReadyToDo)
          : expect(task?.schedule_status).toEqual(
              contractRenewalTasks[0].schedule_status
            );
      })
    );
  });

  describe("handleWizardLocationDispositionTaskDisposed", () => {
    test(
      "should dispose location and task",
      withFixtures(async ({ locationDispositionTasks }, tx) => {
        const { managerAccountTaskService } = TestDIContainer(tx);

        const task = faker.helpers.arrayElement(locationDispositionTasks);

        await managerAccountTaskService.handleWizardLocationDispositionTaskDisposed(
          {
            task,
          }
        );

        const updatedLocation = await tx.location.findUnique({
          where: { id: task.location_id },
        });

        const updatedTask = await tx.taskLocationDisposition.findUnique({
          where: { id: task.id },
        });

        expect(updatedLocation?.status).toBe(LocationStatus.Disposed);

        expect(updatedTask?.completion_status).toBe(
          TaskCompletionStatus.Completed
        );
        expect(updatedTask?.schedule_status).toBe(TaskScheduleStatus.Archived);
      })
    );

    test(
      "should send notification to task owner",
      withFixtures(async ({ locationDispositionTasks }, tx) => {
        const { managerAccountTaskService, intelligenceNotificationService } =
          TestDIContainer(tx);

        const createNotificationSpy = jest.spyOn(
          intelligenceNotificationService,
          "createNotification"
        );

        const task = faker.helpers.arrayElement(locationDispositionTasks);

        await managerAccountTaskService.handleWizardLocationDispositionTaskDisposed(
          {
            task,
          }
        );

        expect(createNotificationSpy).toHaveBeenCalledWith(
          task.task_owner_id,
          IntelligenceNotificationType.TaskCompletionStatusChange,
          {
            task_id: task.id,
            task_type: TaskType.TaskLocationDisposition,
            new_status: TaskCompletionStatus.Completed,
          }
        );
      })
    );
  });

  describe("handleWizardLocationDispositionTaskPending", () => {
    test(
      "should update task due date",
      withFixtures(async ({ locationDispositionTasks }, tx) => {
        const { managerAccountTaskService } = TestDIContainer(tx);

        const task = faker.helpers.arrayElement(locationDispositionTasks);

        const dueDate = faker.date.soon();

        await managerAccountTaskService.handleWizardLocationDispositionTaskPending(
          {
            task,
            fields: { due_date: dueDate },
          }
        );

        const updatedTask = await tx.taskLocationDisposition.findUnique({
          where: { id: task.id },
        });

        expect(updatedTask?.due_date).toEqual(dueDate);
      })
    );

    test(
      "should send notification to task owner",
      withFixtures(async ({ locationDispositionTasks }, tx) => {
        const { managerAccountTaskService, intelligenceNotificationService } =
          TestDIContainer(tx);

        const createNotificationSpy = jest.spyOn(
          intelligenceNotificationService,
          "createNotification"
        );

        const task = faker.helpers.arrayElement(locationDispositionTasks);

        const dueDate = faker.date.soon();

        await managerAccountTaskService.handleWizardLocationDispositionTaskPending(
          {
            task,
            fields: { due_date: dueDate },
          }
        );

        expect(createNotificationSpy).toHaveBeenCalledWith(
          task.task_owner_id,
          IntelligenceNotificationType.TaskDueDateChange,
          {
            task_id: task.id,
            task_type: TaskType.TaskLocationDisposition,
            new_due_date: dueDate.toISOString(),
          }
        );
      })
    );
  });

  describe("handleWizardLocationDispositionTaskKeep", () => {
    test(
      "should complete task",
      withFixtures(async ({ locationDispositionTasks }, tx) => {
        const { managerAccountTaskService } = TestDIContainer(tx);

        const task = faker.helpers.arrayElement(locationDispositionTasks);

        await managerAccountTaskService.handleWizardLocationDispositionTaskKeep(
          {
            task,
          }
        );

        const updatedTask = await tx.taskLocationDisposition.findUnique({
          where: { id: task.id },
        });

        expect(updatedTask?.completion_status).toBe(
          TaskCompletionStatus.Completed
        );
        expect(updatedTask?.schedule_status).toBe(TaskScheduleStatus.Archived);
      })
    );

    test(
      "should send notification to task owner",
      withFixtures(async ({ locationDispositionTasks }, tx) => {
        const { managerAccountTaskService, intelligenceNotificationService } =
          TestDIContainer(tx);

        const createNotificationSpy = jest.spyOn(
          intelligenceNotificationService,
          "createNotification"
        );

        const task = faker.helpers.arrayElement(locationDispositionTasks);

        await managerAccountTaskService.handleWizardLocationDispositionTaskKeep(
          {
            task,
          }
        );

        expect(createNotificationSpy).toHaveBeenCalledWith(
          task.task_owner_id,
          IntelligenceNotificationType.TaskCompletionStatusChange,
          {
            task_id: task.id,
            task_type: TaskType.TaskLocationDisposition,
            new_status: TaskCompletionStatus.Completed,
          }
        );
      })
    );
  });
});
