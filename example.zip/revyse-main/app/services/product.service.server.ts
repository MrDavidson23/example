import type { PrismaClient, Tier } from "@prisma/client";
import {
  Prisma,
  ProductState,
  Role,
  SubscriptionStatus,
  UserRoleType,
  VendorState,
} from "@prisma/client";
import { isNil } from "lodash";
import type { TemplateService } from "./template.service.server";
import type { MailService, MockMailService } from "./mail.service.server";
import { TierPermissionMap } from "../utils/permission.utils";
import { ProductSubscriptionActiveStatuses } from "../utils/product-subscription.utils.server";
export class ProductService {
  constructor(
    private db: PrismaClient,
    private templateService: TemplateService,
    private mailService: MailService | MockMailService
  ) {}

  async getProducts({
    where,
    orderBy,
    take,
    skip,
  }: {
    where?: Prisma.ProductWhereInput;
    orderBy?: Prisma.ProductOrderByWithRelationInput[];
    take?: number;
    skip?: number;
  }) {
    return await this.db.product.findMany({
      where,
      orderBy,
      include: {
        vendor: true,
        primary_category: true,
        subscriptions: {
          where: {
            status: {
              notIn: [
                SubscriptionStatus.incomplete,
                SubscriptionStatus.incomplete_expired,
              ],
            },
          },
          include: {
            stripe_price: {
              include: { product: true },
            },
            user_roles: {
              where: {
                type: UserRoleType.PRODUCT_SUBSCRIPTION,
              },
            },
          },
          orderBy: { created_at: "desc" },
        },
      },
      take,
      skip,
    });
  }

  async getProductBySlug({ slug }: { slug?: string | undefined }) {
    return await this.db.product.findFirst({
      where: {
        slug: slug,
        approved_at: { not: null },
        state: ProductState.discovery,
        vendor: { state: VendorState.ApprovedForPublishing },
      },
      include: {
        primary_category: true,
        secondary_category: true,
        tertiary_category: true,
        vendor: {
          include: {
            vendor_integrations: {
              include: {
                integrated_vendor: true,
                integrated_product: true,
              },
              orderBy: [
                {
                  integrated_vendor: {
                    name: "asc",
                  },
                },
                {
                  integrated_product: {
                    title: "asc",
                  },
                },
              ],
              take: 60,
              distinct: ["integrated_product_id", "integrated_vendor_id"],
            },
          },
        },
        features: {
          orderBy: { order: "asc" },
        },
        industries: {
          orderBy: { name: "asc" },
        },
        good_for_tags: {
          orderBy: { order: "asc" },
        },
        packages: {
          orderBy: { order: "asc" },
        },
        image_files: true,
        brand_video_files: true,
        download_files: true,
        demo_files: true,
        banner_file: true,
        logo_file: true,
      },
    });
  }

  async getProductsMostLoved({
    take = 0,
    categories = [],
  }: {
    take?: number;
    categories?: string[];
  }) {
    type QueryResult = {
      id: string;
      cnt: number;
      title: string;
      description: string;
      logo_file_id: string;
      avg_score: number;
      slug: string;
      primary_category_id: string;
      vendor_name: string;
      industry_ids: string[];
      tier: string;
    };
    const result = await this.db.$queryRaw<QueryResult[]>`
        select * from (select p.id, p.title, p.description, p.slug, p.logo_file_id, 
        p.primary_category_id, v.name as vendor_name, array_agg(itp."A") as industry_ids, 
        count(distinct pr.id)::int as cnt,
        coalesce(avg(pr.value_score + pr.compatibility_score + pr.customer_service_score + pr.onboarding_score) / 4.0, 0)::float as avg_score,
        pp.tier as tier
        from product_review pr 
        right join product p on p.id=pr.product_id and pr.approved_at is not null 
        join vendor v on p.vendor_id=v.id
        left join "_IndustryToProduct" itp on itp."B"=p.id
        left join "product_subscription" ps ON p.id = ps.product_id AND ps.status = 'active'
        left join "stripe_price" sp ON ps.stripe_price_id = sp.id
        left join "stripe_product" pp ON sp.product_id = pp.id
        where
          (pr.id is null OR pr.approved_by_id is not null) -- only approved reviews
          and p.state = 'discovery' -- only products that are approved for discovery
          and v.state = 'ApprovedForPublishing' -- only products from approved for discovery vendors 
          and p.primary_category_id::text = ANY (${categories})
        group by p.id, v.name, pp.tier
        HAVING coalesce(avg(pr.value_score + pr.compatibility_score + pr.customer_service_score + pr.onboarding_score) / 4.0, 0)::float >= 4 -- filter based on the aggregate condition
        order by
          cnt desc
        limit ${take}) temp
        order by
          temp.avg_score desc,
          case temp.tier
            when 'tier_3' then 1
            when 'tier_2' then 2
            when 'tier_1' then 3
            when 'free' then 4
            else 5
          end;`;

    return result;
  }

  async getProductsWithRatings({ ids }: { ids: string[] }) {
    const products = await this.db.product.findMany({
      where: { id: { in: ids } },
      include: {
        industries: true,
        vendor: true,
        good_for_tags: true,
        _count: {
          select: {
            brand_video_files: true,
            demo_files: true,
            packages: true,
          },
        },
        subscriptions: {
          where: {
            status: {
              in: ProductSubscriptionActiveStatuses,
            },
          },
          include: {
            stripe_price: { include: { product: true } },
          },
        },
        primary_category: true,
      },
    });

    const aggregates = await this.db.productReview.groupBy({
      by: ["product_id"],
      _avg: {
        value_score: true,
        compatibility_score: true,
        customer_service_score: true,
        onboarding_score: true,
      },
      _count: {
        id: true,
      },
      where: { product_id: { in: ids }, approved_by_id: { not: null } },
    });

    const claims = await this.db.productSubscription.groupBy({
      by: ["product_id"],
      _count: {
        id: true,
      },
      where: {
        product_id: { in: ids },
        status: {
          in: ProductSubscriptionActiveStatuses,
        },
      },
    });

    return products.map(product => {
      const agg = aggregates.find(agg => agg.product_id === product.id);
      const claim = claims.find(c => c.product_id === product.id);
      const avgReview =
        ((agg?._avg.compatibility_score ?? 0) * 10 +
          (agg?._avg.value_score ?? 0) * 10 +
          (agg?._avg.customer_service_score ?? 0) * 10 +
          (agg?._avg.onboarding_score ?? 0) * 10) /
        4 /
        10;

      return {
        ...product,
        tier: product.subscriptions[0]?.stripe_price?.product?.tier,
        avgReview: +avgReview.toFixed(1),
        totalReviews: agg?._count.id ?? 0,
        subCount: claim?._count?.id ?? 0,
      };
    });
  }

  /**
   * Gets products that have their primary_category_id set to the given categoryId
   */
  async getProductsForPrimaryCategory({
    categoryId,
    take = 0,
  }: {
    categoryId: string;
    take?: number;
  }) {
    return this.getProductsForCategory({
      categoryId,
      take,
      includeSubcategories: false,
    });
  }

  /**
   * Gets all products that have primary, secondary, or tertiary categories that match the given categoryId
   */
  async getProductsForCategory({
    categoryId,
    take = 0,
    includeSubcategories = false,
  }: {
    categoryId: string;
    take?: number;
    includeSubcategories?: boolean;
  }) {
    type QueryResult = {
      id: string;
      cnt: number;
      title: string;
      description: string;
      logo_file_id: string;
      avg_score: number;
      slug: string;
      primary_category_id: string;
      vendor_name: string;
      industry_ids: string[];
      tier: string;
    };
    const catClause = Prisma.sql`(p.primary_category_id::text = ${categoryId} ${
      includeSubcategories
        ? Prisma.sql`OR p.secondary_category_id::text = ${categoryId} OR p.tertiary_category_id::text = ${categoryId}`
        : Prisma.sql`AND true`
    })`;
    const result = await this.db.$queryRaw<QueryResult[]>`
        select p.id, p.title, p.description, p.slug, p.logo_file_id, 
        p.primary_category_id, v.name as vendor_name, array_agg(itp."A") as industry_ids, 
        count(distinct pr.id)::int as cnt, 
        coalesce(avg(pr.value_score + pr.compatibility_score + pr.customer_service_score + pr.onboarding_score) / 4.0, 0)::float as avg_score,
        pp.tier as tier
        from product_review pr 
        right join product p on p.id=pr.product_id and pr.approved_at is not null 
        join vendor v on p.vendor_id=v.id
        left join "_IndustryToProduct" itp on itp."B"=p.id
        left join "product_subscription" ps ON p.id = ps.product_id AND ps.status = 'active'
        left join "stripe_price" sp ON ps.stripe_price_id = sp.id
        left join "stripe_product" pp ON sp.product_id = pp.id
        where ${catClause}
          and (pr.id is null OR pr.approved_by_id is not null) -- only approved reviews
          and p.state = 'discovery' -- only products that are approved for discovery
          and v.state = 'ApprovedForPublishing' -- only products from approved for discovery vendors
        group by p.id, v.name, pp.tier
        order by
          count(pr.id) desc,
          case pp.tier
            when 'tier_3' then 1
            when 'tier_2' then 2
            when 'tier_1' then 3
            when 'free' then 4
            else 5
          end,
          p.title asc
        limit ${take};`;

    return result;
  }

  async upsertProductFromAdmin(
    id: string | undefined,
    user: { id: string },
    formData: {
      title: string;
      description: string;
      vendor_id: string;
      primary_category_id: string;
      slug: string;
      state: ProductState | null;
    }
  ) {
    return await this.db.$transaction(async tx => {
      if (id !== "new") {
        const product = await tx.product.findUnique({
          where: { id },
          include: {
            vendor: true,
            primary_category: true,
            subscriptions: {
              where: {
                status: {
                  notIn: [
                    SubscriptionStatus.incomplete,
                    SubscriptionStatus.incomplete_expired,
                  ],
                },
              },
              orderBy: { created_at: "desc" },
              include: {
                stripe_price: {
                  include: { product: true },
                },
                user_roles: {
                  where: {
                    type: UserRoleType.PRODUCT_SUBSCRIPTION,
                    role: Role.OWNER,
                  },
                  include: {
                    user: true,
                  },
                },
              },
            },
          },
        });
        if (isNil(product)) {
          throw new Error(`Product not found: ${id}`);
        }
        const data = {
          ...formData,
          approved_by_id: formData.state ? user.id : null,
          approved_at: formData.state ? new Date() : null,
          approved: undefined, // need to remove this from the input
        };
        const updatedProduct = await tx.product.update({
          data,
          where: { id },
        });

        // If the product was just approved, send an email to the vendor
        if (
          product.approved_by_id === null &&
          updatedProduct.approved_by_id !== null &&
          product.subscriptions.length > 0
        ) {
          console.log("Sending listing approved email");
          const subscription = product.subscriptions[0];
          const userEmails = subscription.user_roles.map(
            user_role => user_role.user.email
          );

          const body = this.templateService.renderListingApprovedEmail({
            product_id: updatedProduct.id,
            product_name: updatedProduct.title,
          });
          await this.mailService.send({
            to: userEmails,
            subject: "Your product listing has been approved! | Revyse",
            body,
          });
        }
        return updatedProduct;
      } else {
        const data = {
          ...formData,
          positioning: "",
          page_title: `Revyse | Read Reviews for ${formData.title}`,
          meta_description: `Read ${formData.title} reviews from verified users. Compare the best multifamily products and services on Revyse.`,
          approved: undefined,
        };
        const createdProduct = await tx.product.create({
          data,
        });

        return createdProduct;
      }
    });
  }

  async deleteProductFromAdmin(id: string | undefined) {
    const product = await this.db.product.findUniqueOrThrow({
      where: {
        id,
      },
      include: {
        brand_video_files: true,
        demo_files: true,
        download_files: true,
        image_files: true,
        subscriptions: true,
        contract_line_item_products: true,
      },
    });

    const hasActiveSubscription = product.subscriptions.some(
      s => s.status === SubscriptionStatus.active
    );
    if (
      product.approved_at ||
      hasActiveSubscription ||
      product.contract_line_item_products.length > 0
    ) {
      return {
        success: false,
        error:
          "This product is currently published or has an active subscription or is a part of an intelligence contract.",
      };
    }

    await this.db.$transaction(async tx => {
      await tx.productFeature.deleteMany({
        where: {
          product_id: id,
        },
      });
      await tx.buyerContactRequest.deleteMany({
        where: {
          product_id: id,
        },
      });
      await tx.productReview.deleteMany({
        where: {
          product_id: id,
        },
      });
      await tx.productSubscription.deleteMany({
        where: {
          product_id: id,
        },
      });
      await tx.contractLineItemProduct.deleteMany({
        where: {
          product_id: id,
        },
      });

      const fileIds = [
        product.banner_file_id,
        product.logo_file_id,
        ...product.image_files.map(f => f.id),
        ...product.brand_video_files.map(f => f.id),
        ...product.download_files.map(f => f.id),
        ...product.demo_files.map(f => f.id),
      ].filter(id => id) as string[];
      await tx.file.deleteMany({
        where: {
          id: {
            in: fileIds,
          },
        },
      });

      await tx.productPackage.deleteMany({
        where: {
          product_id: id,
        },
      });

      await tx.product.delete({ where: { id } });
    });
    return {
      success: true,
    };
  }
  async getReviewedProductWithSubscriptions(slug: string | undefined) {
    return this.db.product.findFirst({
      where: {
        slug: slug,
        approved_at: { not: null },
        state: ProductState.discovery,
        vendor: { state: VendorState.ApprovedForPublishing },
      },
      include: {
        subscriptions: {
          where: {
            status: {
              in: ProductSubscriptionActiveStatuses,
            },
          },
          include: {
            stripe_price: { include: { product: true } },
          },
          orderBy: { created_at: "desc" },
        },
      },
    });
  }

  async getProductIncludingAllFields(id: string) {
    return await this.db.product.findFirst({
      where: { id },
      include: {
        features: {
          orderBy: { order: "asc" },
        },
        industries: {
          orderBy: { name: "asc" },
        },
        good_for_tags: {
          orderBy: { name: "asc" },
        },
        packages: {
          orderBy: { order: "asc" },
        },
        image_files: true,
        brand_video_files: true,
        download_files: true,
        demo_files: true,
        banner_file: true,
        logo_file: true,
        vendor: true,
        subscriptions: {
          where: {
            status: {
              in: ProductSubscriptionActiveStatuses,
            },
          },
          include: {
            stripe_price: {
              include: { product: true },
            },
            user_roles: {
              where: {
                type: UserRoleType.PRODUCT_SUBSCRIPTION,
              },
              include: {
                user: true,
              },
              orderBy: { role: "asc" },
            },
          },
          orderBy: { created_at: "desc" },
        },
      },
    });
  }

  async updateProduct(
    id: string,
    data: {
      title: string;
      description: string;
      positioning: string;
      primary_category_id: string;
      secondary_category_id?: string | null;
      tertiary_category_id?: string | null;
      lead_prospect_email: string | null;
      demo_scheduling_url: string | null;
      demo_storylane_url: string | null;
      banner_file_id?: string | null;
      logo_file_id?: string | null;
      image_files: string[];
      brand_video_files: string[];
      brand_video_titles: { id: string; title: string }[];
      brand_video_urls: {
        title?: string;
        url: string;
        type: string;
        embedUrl: string;
      }[];
      download_files: string[];
      demo_files: string[];
      features: {
        id?: string;
        name: string;
        description: string;
        order: number;
      }[];
      industries: string[];
      good_for_tags: string[];
      packages: {
        id?: string;
        name: string;
        description: string;
        order: number;
        features: string[];
        price_type?: string | null;
        price: number;
      }[];
      review_questions: string[];
      slug?: string;
      stripeProductId?: string | null;
      stripePriceId?: string | null;
      promo_text: string | null;
    }
  ) {
    const {
      brand_video_titles,
      features,
      industries,
      good_for_tags,
      packages,
      image_files,
      brand_video_files,
      download_files,
      demo_files,
      primary_category_id,
      ...directDBData
    } = data;

    return await this.db.$transaction(async tx => {
      const updatedProduct = await tx.product.update({
        where: { id },
        data: {
          ...directDBData,
          features: {
            deleteMany: { product_id: id },
            createMany: { data: features },
          },
          industries: {
            set: [],
            connect: industries.map(id => ({ id })),
          },
          good_for_tags: {
            set: [],
            connect: good_for_tags.map(id => ({ id })),
          },
          packages: {
            deleteMany: { product_id: id },
            createMany: { data: packages },
          },
          image_files: {
            connect: image_files!.map(id => ({ id })),
          },
          brand_video_files: {
            connect: brand_video_files!.map(id => ({
              id,
            })),
          },
          download_files: {
            connect: download_files!.map(id => ({ id })),
          },
          demo_files: {
            connect: demo_files!.map(id => ({ id })),
          },
        },
      });

      await Promise.all(
        brand_video_files.map(async (item, index) => {
          const correspondingTitle = brand_video_titles.find(
            titleItem => titleItem.id === item
          );
          await tx.file.update({
            where: { id: item },
            data: {
              title:
                correspondingTitle?.title ?? brand_video_titles[index].title,
            },
          });
        })
      );

      return updatedProduct;
    });
  }

  async deleteProduct(id: string) {
    const product = await this.db.product.findUniqueOrThrow({
      where: { id },
      include: { subscriptions: true },
    });

    if (product.subscriptions.length > 0) {
      throw new Error("Cannot delete listing with subscriptions");
    }

    await this.db.productReview.deleteMany({
      where: { product_id: id },
    });

    await this.db.product.delete({ where: { id } });
  }

  getCategoryOptions() {
    return this.db.productCategory.findMany({
      orderBy: { name: "asc" },
    });
  }

  getIndustryOptions() {
    return this.db.industry.findMany({
      orderBy: { name: "asc" },
    });
  }

  getGoodForTagOptions() {
    return this.db.goodForTag.findMany({
      orderBy: { name: "asc" },
    });
  }

  getProductsByCategoryVendorType(categoryVendorType: string, take?: number) {
    return this.db.product.findMany({
      where: {
        primary_category: {
          primary_vendor_type: categoryVendorType,
        },
      },
      take,
    });
  }

  getProductsForSearch(search: string, take?: number) {
    const showGoodForTagsTiers = Object.keys(TierPermissionMap).filter(tier =>
      TierPermissionMap[tier as Tier].includes("show_good_for_tags")
    ) as Tier[];

    return this.db.product.findMany({
      select: { id: true },
      where: {
        OR: [
          { title: { contains: search, mode: "insensitive" } },
          { description: { contains: search, mode: "insensitive" } },
          {
            vendor: { name: { contains: search, mode: "insensitive" } },
          },
          {
            good_for_tags: {
              some: { name: { contains: search, mode: "insensitive" } },
            },
            subscriptions: {
              some: {
                status: {
                  in: ProductSubscriptionActiveStatuses,
                },
                stripe_price: {
                  product: {
                    tier: {
                      in: showGoodForTagsTiers,
                    },
                  },
                },
              },
            },
          },
          { positioning: { contains: search, mode: "insensitive" } },
        ],
        approved_at: { not: null },
        state: ProductState.discovery,
        vendor_id: { not: null },
        vendor: { state: VendorState.ApprovedForPublishing },
      },
      take,
    });
  }

  async getProductsCount({
    where,
  }: {
    where?: Prisma.ProductWhereInput;
  }): Promise<number> {
    return this.db.product.count({ where });
  }
}
