export class RecaptchaService {
  private recaptchaSecretKey = process.env.RECAPTCHA_SECRET_KEY;
  private recaptchaE2EToken = process.env.RECAPTCHA_E2E_TOKEN;

  constructor() {}

  async verifyToken(token: string) {
    if (token === this.recaptchaE2EToken) {
      return true;
    }

    const response = await fetch(
      `https://www.google.com/recaptcha/api/siteverify?secret=${this.recaptchaSecretKey}&response=${token}`,
      {
        method: "POST",
      }
    );
    const data = await response.json();
    return data.success;
  }
}
