import type {
  ContractStatus,
  File,
  LocationClass,
  LocationPropertyStage,
  LocationPropertyType,
  LocationStatus,
  Prisma,
  PrismaClient,
} from "@prisma/client";
import {
  ContractLineItemLocationStatus,
  ContractLineItemStatus,
} from "@prisma/client";
import { isEmpty } from "lodash";
import type { OrderByField } from "~/utils/filtering.utils";
import type { PermissionUser } from "../utils/intelligence-permission.utils";
import {
  canDoOnAccount,
  Permission,
} from "../utils/intelligence-permission.utils";
import { getLocationIdsForUser } from "../utils/location-permission.utils";

export type LocationsFilterType = {
  query?: string;
  unitCount?: string[];
  propertyClass?: LocationClass[];
  region?: string[];
  propertyType?: LocationPropertyType[];
  propertyStage?: LocationPropertyStage[];
  owner?: string[];
  status?: LocationStatus[];
};

export class LocationService {
  constructor(private db: PrismaClient) {}

  private prepareLocationsWhereInput(
    user: PermissionUser,
    account: { id: string },
    locationsFilter: LocationsFilterType
  ) {
    const locationIds = getLocationIdsForUser(user, account, [
      Permission.ViewLocationDetails,
    ]);

    const regionFilters =
      locationsFilter.region?.map(term => ({
        region: {
          contains: term,
          mode: "insensitive",
        },
      })) ?? [];

    const ownerFilters =
      locationsFilter.owner?.map(term => ({
        owner_name: {
          contains: term,
          mode: "insensitive",
        },
      })) ?? [];

    const unitCountFilter =
      locationsFilter.unitCount
        ?.map(singleRange => {
          if (singleRange.includes("-")) {
            const [min, max] = singleRange.split("-").map(Number);
            if (!isNaN(min) && !isNaN(max)) {
              return { unit_count: { gte: min, lte: max } };
            }
          } else if (singleRange === "500") {
            return { unit_count: { gte: 500 } };
          } else {
            const min = Number(singleRange);
            if (!isNaN(min)) {
              return { unit_count: { equals: min } };
            }
          }
          return null;
        })
        .filter(Boolean) ?? [];

    const filters: Prisma.LocationWhereInput = {
      AND: [
        { manager_account_id: account.id },
        ...(locationIds !== "all" ? [{ id: { in: locationIds } }] : []),
        {
          OR: [
            // Query
            {
              name: {
                contains: locationsFilter.query ?? "",
                mode: "insensitive",
              },
            },
            {
              street_1: {
                contains: locationsFilter.query ?? "",
                mode: "insensitive",
              },
            },
            {
              street_2: {
                contains: locationsFilter.query ?? "",
                mode: "insensitive",
              },
            },
            {
              city: {
                contains: locationsFilter.query ?? "",
                mode: "insensitive",
              },
            },
            {
              state: {
                contains: locationsFilter.query ?? "",
                mode: "insensitive",
              },
            },
            {
              region: {
                contains: locationsFilter.query ?? "",
                mode: "insensitive",
              },
            },
            {
              owner_name: {
                contains: locationsFilter.query ?? "",
                mode: "insensitive",
              },
            },
          ],
        },
        { OR: regionFilters as Prisma.LocationWhereInput[] },
        { OR: ownerFilters as Prisma.LocationWhereInput[] },
        { OR: unitCountFilter as Prisma.LocationWhereInput[] },
      ],
    };

    if (!isEmpty(locationsFilter.propertyClass)) {
      filters.class = {
        in: locationsFilter.propertyClass,
      };
    }

    if (!isEmpty(locationsFilter.propertyType)) {
      filters.property_type = {
        in: locationsFilter.propertyType,
      };
    }

    if (!isEmpty(locationsFilter.propertyStage)) {
      filters.property_stage = {
        in: locationsFilter.propertyStage,
      };
    }

    if (!isEmpty(locationsFilter.status)) {
      filters.status = {
        in: locationsFilter.status,
      };
    }

    return filters;
  }

  async getLocation(id: string) {
    return await this.db.location.findUnique({
      where: {
        id,
      },
    });
  }

  async getLocations(
    user: PermissionUser,
    account: { id: string },
    locationsFilter?: LocationsFilterType,
    offset?: number,
    perPage?: number
  ) {
    if (locationsFilter) {
      const filters = this.prepareLocationsWhereInput(
        user,
        account,
        locationsFilter
      );

      return await this.db.location.findMany({
        where: filters,
        skip: offset,
        take: perPage,
        include: {
          _count: {
            select: {
              contract_line_item_locations: true,
            },
          },
        },
        orderBy: {
          name: "asc",
        },
      });
    }

    return await this.db.location.findMany({
      where: {
        manager_account_id: account.id,
      },
      skip: offset,
      take: perPage,
      include: {
        _count: {
          select: {
            contract_line_item_locations: true,
          },
        },
      },
      orderBy: {
        name: "asc",
      },
    });
  }

  async getLocationsCount(
    user: PermissionUser,
    account: { id: string },
    locationsFilter?: LocationsFilterType
  ) {
    if (locationsFilter) {
      const filters = this.prepareLocationsWhereInput(
        user,
        account,
        locationsFilter
      );

      return await this.db.location.count({
        where: filters,
      });
    }

    return await this.db.location.count({
      where: {
        manager_account_id: account.id,
      },
    });
  }

  async getLocationsRegions(
    managerAccountId: string | undefined,
    query?: string
  ) {
    const regions = await this.db.location.findMany({
      where: {
        manager_account_id: managerAccountId,
        region: {
          contains: query ?? "",
          mode: "insensitive",
        },
      },
      select: {
        region: true,
      },
      distinct: ["region"],
      orderBy: {
        name: "asc",
      },
    });

    return regions as { region: string }[];
  }

  async getLocationsOwners(managerAccountId: string | undefined) {
    const owners = await this.db.location.findMany({
      where: {
        manager_account_id: managerAccountId,
        owner_name: {
          not: null,
        },
      },
      select: {
        owner_name: true,
      },
      distinct: ["owner_name"],
      orderBy: {
        name: "asc",
      },
    });

    return owners as { owner_name: string }[];
  }

  async createLocation(data: Prisma.LocationCreateInput) {
    return await this.db.location.create({
      data,
    });
  }

  async createLocations(data: Prisma.LocationCreateManyInput[]) {
    return await this.db.location.createMany({
      data,
    });
  }

  async updateLocation(locationId: string, data: Prisma.LocationUpdateInput) {
    return await this.db.location.update({
      where: {
        id: locationId,
      },
      data,
    });
  }

  async deleteLocation(locationId: string) {
    return await this.db.location.delete({
      where: {
        id: locationId,
      },
    });
  }

  private getLocationContractsWithDocumentsQuery(filters: {
    searchQuery?: string;
    vendors?: string[];
    current_term_end_date?: [string | undefined, string | undefined];
    contract_status?: ContractStatus[];
  }) {
    const and: Prisma.ContractWhereInput[] = [];

    if (filters.searchQuery) {
      and.push({
        OR: [
          {
            name: {
              contains: filters.searchQuery,
              mode: "insensitive",
            },
          },
          {
            manager_account_vendor: {
              vendor: {
                name: {
                  contains: filters.searchQuery,
                  mode: "insensitive",
                },
              },
            },
          },
        ],
      });
    }

    if (filters.vendors) {
      and.push({
        manager_account_vendor: {
          vendor_id: {
            in: filters.vendors,
          },
        },
      });
    }

    if (filters.current_term_end_date) {
      const filter: Prisma.ContractWhereInput["current_term_end_date"] = {};

      if (filters.current_term_end_date[0]) {
        filter["gte"] = new Date(filters.current_term_end_date[0]);
      }

      if (filters.current_term_end_date[1]) {
        filter["lte"] = new Date(filters.current_term_end_date[1]);
      }

      and.push({
        current_term_end_date: filter,
      });
    }

    if (filters.contract_status) {
      and.push({
        status: {
          in: filters.contract_status,
        },
      });
    }

    return and;
  }

  async getLocationContractsWithDocuments(
    user: PermissionUser,
    account: { id: string } | null,
    locationId: string,
    {
      filters,
      pagination,
      orderBy,
      canceledAtEnd,
    }: {
      filters?: {
        searchQuery?: string;
        locations?: string[];
        vendors?: string[];
        current_term_end_date?: [string | undefined, string | undefined];
        contract_status?: ContractStatus[];
      };
      pagination?: {
        page: number;
        perPage: number;
      };
      orderBy?: OrderByField[];
      canceledAtEnd?: boolean;
    }
  ) {
    const and = this.getLocationContractsWithDocumentsQuery(filters ?? {});

    if (!canDoOnAccount(user, account, Permission.ViewSensitiveContracts)) {
      and.push({
        is_sensitive: false,
      });
    }

    const where: Prisma.ContractFindManyArgs["where"] = {
      AND: and,
      OR: [
        {
          contracted_location_files: {
            some: {
              location_id: locationId,
            },
          },
        },
        {
          location_id: locationId,
        },
      ],
    };

    const contracts = await this.db.contract.findMany({
      where,
      include: {
        contracted_location_files: {
          where: {
            location_id: locationId,
          },
          include: {
            file: true,
          },
        },
        document_files: {
          include: {
            file: true,
          },
        },
        manager_account_vendor: {
          select: {
            vendor_id: true,
            vendor: {
              select: {
                name: true,
              },
            },
          },
        },
        // Count if any active contract line item have any active contract line item location
        _count: {
          select: {
            contract_line_items: {
              where: {
                status: ContractLineItemStatus.Active,
                contract_line_item_locations: {
                  some: {
                    location_id: locationId,
                    status: { not: ContractLineItemLocationStatus.Canceled },
                  },
                },
              },
            },
          },
        },
      },
      orderBy: !isEmpty(orderBy) ? orderBy : { manager_account_vendor: { vendor: { name: "asc" } } },
      // if canceledAtEnd is true, we will do pagination later
      skip:
        !canceledAtEnd && pagination
          ? pagination?.perPage * (pagination?.page - 1)
          : undefined,
      take: !canceledAtEnd ? pagination?.perPage : undefined,
    });

    const contractsWithDocumentsKey = contracts.map(contract => {
      const documents: {
        id: string;
        name: string;
        file_id: string;
        file: File;
        created_at: Date;
        updated_at: Date;
      }[] = [...contract.contracted_location_files];

      if (contract.location_id === locationId) {
        documents.push(...contract.document_files);
      }

      return {
        ...contract,
        documents,
      };
    });

    const count = await this.db.contract.count({
      where,
    });

    const data = canceledAtEnd
      ? contractsWithDocumentsKey
          // Sort by status
          .sort((a, b) => {
            const aCanceled = !a._count.contract_line_items;
            const bCanceled = !b._count.contract_line_items;
            return Number(aCanceled) - Number(bCanceled);
          })
          // Handle pagination
          .slice(
            pagination
              ? pagination?.perPage * (pagination?.page - 1)
              : undefined,
            pagination ? pagination?.perPage * pagination?.page : undefined
          )
      : contractsWithDocumentsKey;

    return {
      data,
      count,
    };
  }
}
