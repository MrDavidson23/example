import type {
  ContractLineItemLocationStatus,
  ManagerAccount,
  Prisma,
  PrismaClient,
} from "@prisma/client";
import { Permission, type PermissionUser } from "../utils/intelligence-permission.utils";
import { canDoOnLocation } from "../utils/location-permission.utils";

export type LocationVendorsFilters = {
  page: number;
  perPage: number;
  query?: string;
  status: string[];
  permissionLevel: string[];
};

export class ContractLineItemLocationService {
  constructor(private db: PrismaClient) { }

  async getLocationContractLineItems(
    locationId: string | undefined,
    where: Prisma.ContractLineItemLocationWhereInput | undefined = {
      location_id: locationId,
    },
    offset?: number,
    perPage?: number,
    orderBy?: Prisma.ContractOrderByWithRelationInput | undefined,
    user?: PermissionUser,
    account?: ManagerAccount,
  ) {
    let userCanViewContractLineItemPrice = true

    // If the user, account and location id are provided
    // then check for ViewCompanyLevelContractLineItemPricing permission, 
    // otherwise don't check it and leave it "true"
    if (user && account && locationId) {
      userCanViewContractLineItemPrice = canDoOnLocation(
        user,
        account,
        { id: locationId },
        Permission.ViewCompanyLevelContractLineItemPricing
      );
    }

    const contractLineItems = await this.db.contractLineItemLocation.findMany({
      where: where,
      skip: offset,
      take: perPage,
      include: {
        location: true,
        contract_line_item: {
          include: {
            contract: {
              include: {
                manager_account_vendor: { include: { vendor: true } },
              },
            },
            contract_line_item_locations: true,
            contract_line_item_products: {
              include: {
                product: true,
              },
            },
            contract_line_item_fees: {
              include: {
                fee: true,
              },
            },
          },
        },
      },
      orderBy: [
        { status: "asc" },
        { contract_line_item: { contract: orderBy } },
        { contract_line_item: { contract: { status: "asc" } } },
        {
          contract_line_item: {
            contract: { manager_account_vendor: { vendor: { name: "asc" } } },
          },
        },
      ],
    });

    const modifiedContractLineItems = contractLineItems.map(item => {
      // If the contract line item is managed by the Company Account, 
      // then hide the information in the Price Value column depending on the ViewCompanyLevelContractLineItemPricing Permission
      if (item.contract_line_item.contract.location_id) {
        return item
      } else {
        const newItem = {
          ...item,
          contract_line_item: {
            ...item.contract_line_item,
            price_display: userCanViewContractLineItemPrice ? undefined : "Corporate-Managed Contract",
            price: userCanViewContractLineItemPrice ? item.contract_line_item.price : null,
          }
        };
        return newItem;
      }
    })

    return modifiedContractLineItems;
  }

  async getLocationContractLineItemsCount(
    locationId: string | undefined,
    filters: Prisma.ContractLineItemLocationWhereInput | undefined
  ) {
    return filters
      ? await this.db.contractLineItemLocation.count({
          where: filters,
        })
      : await this.db.contractLineItemLocation.count({
          where: {
            location_id: locationId,
          },
        });
  }

  async copyContractLineItemsToLocations(
    contractLineItemIds: string[],
    locationsIds: string[]
  ) {
    try {
      const contractLineItemLocationToCopy =
        await this.db.contractLineItemLocation.findMany({
          where: { id: { in: contractLineItemIds } },
        });

      await this.db.$transaction(async tx => {
        for (const locationId of locationsIds) {
          for (const contractLineItemLocation of contractLineItemLocationToCopy) {
            const exists = await tx.contractLineItemLocation.count({
              where: {
                location_id: locationId,
                contract_line_item_id:
                  contractLineItemLocation.contract_line_item_id,
              },
            });

            if (!exists) {
              await tx.contractLineItemLocation.create({
                data: {
                  location_id: locationId,
                  contract_line_item_id:
                    contractLineItemLocation.contract_line_item_id,
                  expires_at: contractLineItemLocation.expires_at,
                },
              });
            }
          }
        }
      });
      return true;
    } catch (error) {
      return false;
    }
  }

  async updateContractLineItemLocationStatus({
    contractLineItemId,
    locationId,
    status,
    newExpirationDate,
    newCanceledDate,
  }: {
    contractLineItemId: string;
    locationId: string;
    status: ContractLineItemLocationStatus;
    newExpirationDate?: string;
    newCanceledDate?: string | null;
  }) {
    const updatedContractLineItemLocation =
      await this.db.contractLineItemLocation.updateMany({
        where: {
          location_id: locationId,
          contract_line_item_id: contractLineItemId,
        },
        data: {
          status,
          expires_at: newExpirationDate,
          canceled_at: newCanceledDate,
        },
      });

    return updatedContractLineItemLocation;
  }
}
