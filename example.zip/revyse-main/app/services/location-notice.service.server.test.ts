import { faker } from "@faker-js/faker";
import {
  ContractLineItemLocationStatus,
  ContractLineItemStatus,
  ContractStatus,
  LocationClass,
  LocationNoticeStatus,
  LocationNoticeStep,
  LocationStatus,
  ManagerAccountVendorContactType,
  ManagerAccountVendorStatus,
} from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { Roles } from "../utils/intelligence-permission.utils";
import { withFixtureFactory } from "../utils/test.utils.server";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const account = await tx.managerAccount.create({
      data: {
        name: faker.company.name(),
      },
    });

    const user = await tx.user.create({
      data: {
        email: faker.internet.email(),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
        manager_account_roles: {
          create: {
            manager_account: {
              connect: {
                id: account.id,
              },
            },
            role: Roles.Owner,
          },
        },
      },
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
          include: {
            location_roles: true,
          },
        },
        user_roles: true,
      },
    });

    const vendors = await Promise.all(
      Array.from("_".repeat(faker.number.int({ min: 2, max: 10 }))).map(
        async _ =>
          await tx.vendor.create({
            data: {
              name: faker.company.name(),
            },
          })
      )
    );

    const managerAccountVendors = await Promise.all(
      vendors.map(
        async vendor =>
          await tx.managerAccountVendor.create({
            data: {
              manager_account_id: account.id,
              vendor_id: vendor.id,
              status: ManagerAccountVendorStatus.Active,
              manager_account_vendor_contacts: {
                create: {
                  type: faker.helpers.arrayElement([
                    ManagerAccountVendorContactType.Main,
                    ManagerAccountVendorContactType.Disposition,
                  ]),
                  name: faker.person.fullName(),
                  email: faker.internet.email(),
                },
              },
            },
            include: {
              manager_account_vendor_contacts: true,
            },
          })
      )
    );

    const location = await tx.location.create({
      data: {
        name: faker.company.name(),
        pms_id: faker.string.alphanumeric(6),
        owner_name: faker.company.name(),
        street_1: faker.location.streetAddress(),
        street_2: faker.location.secondaryAddress(),
        city: faker.location.city(),
        state: faker.location.state(),
        zip: faker.location.zipCode(),
        region: faker.location.city(),
        unit_count: faker.number.int({ min: 1, max: 1000 }),
        class: faker.helpers.enumValue(LocationClass),
        status: faker.helpers.enumValue(LocationStatus),
        manager_account_id: account.id,
      },
    });

    const contracts = await Promise.all(
      managerAccountVendors.map(
        async managerAccountVendor =>
          await tx.contract.create({
            data: {
              manager_account_vendor_id: managerAccountVendor.id,
              status: ContractStatus.Active,
              contract_owner_name: faker.person.fullName(),
              approver: faker.person.fullName(),
              expires_at: faker.date.future(),
              current_term_end_date: faker.date.future(),
              name: faker.commerce.productName(),
              renewal_reminder_lead_time_months: faker.number.int({ max: 12 }),
              renewal_reminder_date: faker.date.future(),
              term_length_months: faker.number.int({ max: 48 }),
              is_corporate_only: false,
              contract_line_items: {
                create: {
                  status: ContractLineItemStatus.Active,
                  contract_line_item_locations: {
                    createMany: {
                      data: [
                        {
                          location_id: location.id,
                          status: ContractLineItemLocationStatus.Active,
                        },
                      ],
                    },
                  },
                },
              },
            },
            include: {
              contract_line_items: {
                include: {
                  contract_line_item_locations: true,
                },
              },
            },
          })
      )
    );

    const savedLocationNoticeDisposition =
      await tx.locationNoticeDisposition.create({
        data: {
          location_id: location.id,
          termination_date: new Date(),
          termination_instructions: faker.lorem.sentence(),
          disposition_date: new Date(),
          task_owner_id: user.manager_account_roles[0].id,
          manager_account_role_id: user.manager_account_roles[0].id,
          status: LocationNoticeStatus.Saved,
          status_updated_at: faker.date.past(),
        },
      });

    const sentLocationNoticeDisposition =
      await tx.locationNoticeDisposition.create({
        data: {
          location_id: location.id,
          termination_date: new Date(),
          termination_instructions: faker.lorem.sentence(),
          disposition_date: new Date(),
          task_owner_id: user.manager_account_roles[0].id,
          manager_account_role_id: user.manager_account_roles[0].id,
          status: LocationNoticeStatus.Sent,
          status_updated_at: faker.date.past(),
          location_notice_recipients: {
            createMany: {
              data: managerAccountVendors.map(m => ({
                manager_account_vendor_id: m.id,
                name: faker.person.firstName(),
                email: faker.internet.email(),
              })),
            },
          },
        },
        include: {
          location_notice_recipients: {
            include: {
              manager_account_vendor: {
                include: {
                  vendor: true,
                },
              },
            },
          },
        },
      });

    const sentUpdatedLocationNoticeDisposition =
      await tx.locationNoticeDisposition.create({
        data: {
          location_id: location.id,
          termination_date: new Date(),
          termination_instructions: faker.lorem.sentence(),
          disposition_date: new Date(),
          task_owner_id: user.manager_account_roles[0].id,
          manager_account_role_id: user.manager_account_roles[0].id,
          status: LocationNoticeStatus.Sent,
          status_updated_at: faker.date.past(),
          original_location_notice_id: sentLocationNoticeDisposition.id,
          location_notice_recipients: {
            createMany: {
              data: sentLocationNoticeDisposition.location_notice_recipients.map(
                recipient => ({
                  manager_account_vendor_id:
                    recipient.manager_account_vendor_id,
                  name: recipient.name,
                  email: recipient.email,
                })
              ),
            },
          },
        },
      });

    return {
      user,
      account,
      location,
      vendors,
      managerAccountVendors,
      savedLocationNoticeDisposition,
      sentLocationNoticeDisposition,
      sentUpdatedLocationNoticeDisposition,
      contracts,
    };
  },
});

describe("LocationNoticeService", () => {
  describe("getLocationNotices", () => {
    it(
      "should return location notices",
      withFixtures(
        async (
          {
            user,
            account,
            location,
            savedLocationNoticeDisposition,
            sentLocationNoticeDisposition,
            sentUpdatedLocationNoticeDisposition,
          },
          tx
        ) => {
          const { locationNoticeService } = TestDIContainer(tx);

          const locationNotices =
            await locationNoticeService.getLocationNotices(
              user,
              account,
              location.id,
              {} // No filters
            );

          expect(locationNotices).toHaveLength(3);

          expect(locationNotices).toEqual(
            expect.arrayContaining([
              expect.objectContaining({
                id: savedLocationNoticeDisposition.id,
              }),
              expect.objectContaining({
                id: sentLocationNoticeDisposition.id,
              }),
              expect.objectContaining({
                id: sentUpdatedLocationNoticeDisposition.id,
              }),
            ])
          );
        }
      )
    );

    it(
      "should return location notices with search query",
      withFixtures(
        async (
          { user, account, location, savedLocationNoticeDisposition },
          tx
        ) => {
          const { locationNoticeService } = TestDIContainer(tx);

          const locationNotices =
            await locationNoticeService.getLocationNotices(
              user,
              account,
              location.id,
              {
                searchQuery: "started a new",
              }
            );

          expect(locationNotices).toHaveLength(1);
          expect(locationNotices[0].id).toBe(savedLocationNoticeDisposition.id);
        }
      )
    );
  });

  describe("createLocationNoticeDisposition", () => {
    it(
      "should create location notice disposition",
      withFixtures(async ({ location, user }, tx) => {
        const { locationNoticeService } = TestDIContainer(tx);

        const locationNoticeDisposition =
          await locationNoticeService.createLocationNoticeDisposition(
            location.id,
            {
              termination_date: faker.date.future(),
              termination_instructions: faker.lorem.sentence(),
              disposition_date: faker.date.future(),
              task_owner_id: user.manager_account_roles[0].id,
              manager_account_role_id: user.manager_account_roles[0].id,
            },
            false
          );

        expect(locationNoticeDisposition).toBeDefined();

        const locationNoticeDispositionFromDb =
          await tx.locationNoticeDisposition.findUnique({
            where: {
              id: locationNoticeDisposition.id,
            },
          });

        expect(locationNoticeDispositionFromDb).toBeDefined();

        expect(locationNoticeDispositionFromDb?.status).toBe(
          LocationNoticeStatus.InProgress
        );
        expect(locationNoticeDispositionFromDb?.step).toBe(
          LocationNoticeStep.Details
        );
      })
    );

    it(
      "should create location notice disposition save progress",
      withFixtures(async ({ location, user }, tx) => {
        const { locationNoticeService } = TestDIContainer(tx);

        const locationNoticeDisposition =
          await locationNoticeService.createLocationNoticeDisposition(
            location.id,
            {
              termination_date: faker.date.future(),
              termination_instructions: faker.lorem.sentence(),
              disposition_date: faker.date.future(),
              task_owner_id: user.manager_account_roles[0].id,
              manager_account_role_id: user.manager_account_roles[0].id,
            },
            true
          );

        expect(locationNoticeDisposition).toBeDefined();

        const locationNoticeDispositionFromDb =
          await tx.locationNoticeDisposition.findUnique({
            where: {
              id: locationNoticeDisposition.id,
            },
          });

        expect(locationNoticeDispositionFromDb).toBeDefined();

        expect(locationNoticeDispositionFromDb?.status).toBe(
          LocationNoticeStatus.Saved
        );
        expect(
          locationNoticeDispositionFromDb?.status_updated_at
        ).toBeDefined();
        expect(locationNoticeDispositionFromDb?.step).toBe(
          LocationNoticeStep.Details
        );
      })
    );
  });

  describe("updateLocationNoticeDisposition", () => {
    it(
      "should update location notice disposition",
      withFixtures(async ({ user, savedLocationNoticeDisposition }, tx) => {
        const { locationNoticeService } = TestDIContainer(tx);

        const locationNoticeDisposition =
          await locationNoticeService.updateLocationNoticeDisposition(
            savedLocationNoticeDisposition.id,
            {
              termination_date: faker.date.future(),
              termination_instructions: faker.lorem.sentence(),
              disposition_date: faker.date.future(),
              task_owner_id: user.manager_account_roles[0].id,
              manager_account_role_id: user.manager_account_roles[0].id,
            },
            false
          );

        expect(locationNoticeDisposition).toBeDefined();

        const locationNoticeDispositionFromDb =
          await tx.locationNoticeDisposition.findUnique({
            where: {
              id: locationNoticeDisposition.id,
            },
          });

        expect(locationNoticeDispositionFromDb).toBeDefined();

        expect(locationNoticeDispositionFromDb?.step).toBe(
          LocationNoticeStep.Details
        );
      })
    );

    it(
      "should update location notice disposition save progress",
      withFixtures(async ({ user, savedLocationNoticeDisposition }, tx) => {
        const { locationNoticeService } = TestDIContainer(tx);

        const locationNoticeDisposition =
          await locationNoticeService.updateLocationNoticeDisposition(
            savedLocationNoticeDisposition.id,
            {
              termination_date: faker.date.future(),
              termination_instructions: faker.lorem.sentence(),
              disposition_date: faker.date.future(),
              task_owner_id: user.manager_account_roles[0].id,
              manager_account_role_id: user.manager_account_roles[0].id,
            },
            true
          );

        expect(locationNoticeDisposition).toBeDefined();

        const locationNoticeDispositionFromDb =
          await tx.locationNoticeDisposition.findUnique({
            where: {
              id: locationNoticeDisposition.id,
            },
          });

        expect(locationNoticeDispositionFromDb).toBeDefined();

        expect(locationNoticeDispositionFromDb?.status).toBe(
          LocationNoticeStatus.Saved
        );
        expect(
          locationNoticeDispositionFromDb?.status_updated_at
        ).toBeDefined();
      })
    );
  });

  describe("getVendorRecipientsOptions", () => {
    it(
      "should return vendor recipients options",
      withFixtures(
        async ({ location, managerAccountVendors, user, account }, tx) => {
          const { locationNoticeService } = TestDIContainer(tx);

          const recipientsOptions =
            await locationNoticeService.getVendorRecipientsOptions(
              location.id,
              user,
              account
            );

          expect(recipientsOptions).toHaveLength(managerAccountVendors.length);

          const expectedRecipientsOptions = managerAccountVendors.map(vendor =>
            expect.objectContaining({
              id: vendor.id,
            })
          );

          expect(recipientsOptions).toEqual(
            expect.arrayContaining(expectedRecipientsOptions)
          );
        }
      )
    );
  });

  describe("getLocationNoticeDisposition", () => {
    it(
      "should return location notice disposition",
      withFixtures(
        async (
          { user, account, location, savedLocationNoticeDisposition },
          tx
        ) => {
          const { locationNoticeService } = TestDIContainer(tx);

          const locationNoticeDisposition =
            await locationNoticeService.getLocationNoticeDisposition(
              savedLocationNoticeDisposition.id,
              location.id,
              user,
              account
            );

          expect(locationNoticeDisposition).toBeDefined();

          const locationNoticeDispositionFromDb =
            await tx.locationNoticeDisposition.findUnique({
              where: {
                id: locationNoticeDisposition?.id,
              },
            });

          expect(locationNoticeDispositionFromDb).toBeDefined();
        }
      )
    );
  });

  describe("upsertLocationNoticeDispositionRecipients", () => {
    it(
      "should upsert location notice disposition recipients",
      withFixtures(
        async (
          { savedLocationNoticeDisposition, managerAccountVendors, user },
          tx
        ) => {
          const { locationNoticeService } = TestDIContainer(tx);

          await locationNoticeService.upsertLocationNoticeDispositionRecipients(
            savedLocationNoticeDisposition.id,
            managerAccountVendors.map(vendor => vendor.id),
            user.manager_account_roles[0].id
          );

          const locationNoticeDispositionFromDb =
            await tx.locationNoticeDisposition.findUnique({
              where: {
                id: savedLocationNoticeDisposition.id,
              },
              include: {
                location_notice_recipients: true,
              },
            });

          expect(locationNoticeDispositionFromDb).toBeDefined();

          expect(
            locationNoticeDispositionFromDb?.location_notice_recipients
          ).toHaveLength(managerAccountVendors.length);

          const expectedRecipientsOptions = managerAccountVendors.map(vendor =>
            expect.objectContaining({
              manager_account_vendor_id: vendor.id,
              name: vendor.manager_account_vendor_contacts[0].name,
              email: vendor.manager_account_vendor_contacts[0].email,
            })
          );

          expect(
            locationNoticeDispositionFromDb?.location_notice_recipients
          ).toEqual(expect.arrayContaining(expectedRecipientsOptions));
        }
      )
    );
  });

  describe("saveLocationNoticeDispositionDraftEmail", () => {
    it(
      "should save location notice disposition draft email",
      withFixtures(async ({ savedLocationNoticeDisposition, user }, tx) => {
        const { locationNoticeService } = TestDIContainer(tx);

        await locationNoticeService.saveLocationNoticeDispositionDraftEmail(
          savedLocationNoticeDisposition.id,
          {
            subject: "Test Subject",
            body: "Test Body",
            cc_emails: ["test@test.com"],
            attachments: [],
            uploaded_attachments_to_remove: [],
            manager_account_role_id: user.manager_account_roles[0].id,
          },
          true
        );

        const locationNoticeDispositionFromDb =
          await tx.locationNoticeDisposition.findUnique({
            where: {
              id: savedLocationNoticeDisposition.id,
            },
          });

        expect(locationNoticeDispositionFromDb).toBeDefined();

        expect(locationNoticeDispositionFromDb?.step).toBe(
          LocationNoticeStep.EmailTemplate
        );
        expect(locationNoticeDispositionFromDb?.email_subject).toBe(
          "Test Subject"
        );
        expect(locationNoticeDispositionFromDb?.email_body).toBe("Test Body");
        expect(locationNoticeDispositionFromDb?.email_cc_emails).toEqual([
          "test@test.com",
        ]);
      })
    );
  });

  describe("sendLocationNoticeDispositionEmail", () => {
    it(
      "should send location notice disposition email",
      withFixtures(
        async (
          { savedLocationNoticeDisposition, user, managerAccountVendors },
          tx
        ) => {
          const { locationNoticeService, mailService } = TestDIContainer(tx);

          await locationNoticeService.upsertLocationNoticeDispositionRecipients(
            savedLocationNoticeDisposition.id,
            managerAccountVendors.map(vendor => vendor.id),
            user.manager_account_roles[0].id
          );

          await locationNoticeService.saveLocationNoticeDispositionDraftEmail(
            savedLocationNoticeDisposition.id,
            {
              subject: "Test Subject",
              body: "Test Body",
              cc_emails: ["test@test.com"],
              attachments: [],
              uploaded_attachments_to_remove: [],
              manager_account_role_id: user.manager_account_roles[0].id,
            }
          );

          const mailServiceSendSpy = jest.spyOn(mailService, "send");

          await locationNoticeService.sendLocationNoticeDispositionEmail(
            savedLocationNoticeDisposition.id,
            user.manager_account_roles[0].id
          );

          const locationNoticeDispositionFromDb =
            await tx.locationNoticeDisposition.findUnique({
              where: {
                id: savedLocationNoticeDisposition.id,
              },
              include: {
                location_notice_recipients: true,
                manager_account_role: {
                  include: {
                    user: true,
                  },
                },
              },
            });

          expect(locationNoticeDispositionFromDb).toBeDefined();

          expect(locationNoticeDispositionFromDb?.status).toBe(
            LocationNoticeStatus.Sent
          );

          expect(mailServiceSendSpy).toHaveBeenCalledTimes(
            locationNoticeDispositionFromDb!.location_notice_recipients.length
          );

          for (
            let i = 0;
            i <
            locationNoticeDispositionFromDb!.location_notice_recipients.length;
            i++
          ) {
            const recipient =
              locationNoticeDispositionFromDb!.location_notice_recipients[i]!;
            expect(mailServiceSendSpy).toHaveBeenNthCalledWith(
              i + 1,
              expect.objectContaining({
                to: [recipient.email!],
                cc: [
                  locationNoticeDispositionFromDb?.manager_account_role.user
                    .email,
                  "test@test.com",
                ],
                subject: "Test Subject",
                body: "Test Body",
                attachments: [],
                replyTo:
                  locationNoticeDispositionFromDb?.manager_account_role.user
                    .email,
              })
            );
          }
        }
      )
    );
  });

  describe("deleteLocationNoticeDisposition", () => {
    it(
      "should delete location notice disposition",
      withFixtures(async ({ savedLocationNoticeDisposition }, tx) => {
        const { locationNoticeService } = TestDIContainer(tx);

        await locationNoticeService.deleteLocationNoticeDisposition(
          savedLocationNoticeDisposition.id
        );

        const locationNoticeDispositionFromDb =
          await tx.locationNoticeDisposition.findUnique({
            where: {
              id: savedLocationNoticeDisposition.id,
            },
          });

        expect(locationNoticeDispositionFromDb).toBeNull();
      })
    );
  });
});
