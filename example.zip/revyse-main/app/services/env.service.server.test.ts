import { getEnv } from "./env.service.server";

describe("env.service.server.ts", () => {
  describe("getEnv", () => {
    it('should log "All required environment variables are set."', () => {
      const spy = jest.spyOn(console, "log");
      getEnv();
      expect(spy).toHaveBeenCalledWith(
        "All required environment variables are set."
      );
    });

    it("should return global._env", () => {
      expect(getEnv()).toEqual(global._env);
    });
  });
});
