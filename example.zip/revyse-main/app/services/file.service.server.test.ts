import { PrismaClientKnownRequestError } from "@prisma/client/runtime/library";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { faker } from "@faker-js/faker";
import { withFixtureFactory } from "../utils/test.utils.server";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { fileService } = TestDIContainer(tx);

    const file = await tx.file.create({
      data: {
        title: "title",
        mime_type: "mime_type",
        size_kb: 1,
        uri: "uri",
      },
    });

    return { fileService, file };
  },
});

describe("FileService", () => {
  describe("deleteFile", () => {
    it(
      "should delete a file",
      withFixtures(async ({ fileService, file }, tx) => {
        await fileService.deleteFile(file.id);

        const fileDeleted = await tx.file.findFirst({ where: { id: file.id } });
        expect(fileDeleted).toBeNull();
      })
    );

    it(
      "should fail if empty id",
      withFixtures(async ({ fileService }) => {
        const fileId = "";
        await expect(fileService.deleteFile(fileId)).rejects.toThrow(
          PrismaClientKnownRequestError
        );
      })
    );

    it(
      "should fail if no file with that id",
      withFixtures(async ({ fileService }) => {
        const fileId = faker.string.uuid();
        await expect(fileService.deleteFile(fileId)).rejects.toThrow(
          "No File found"
        );
      })
    );
  });

  describe("getFileAndBuffer", () => {
    it(
      "should return a file and buffer",
      withFixtures(async ({ fileService, file }, tx) => {
        const { buffer, file: fileResult } = await fileService.getFileAndBuffer(
          file.id
        );

        expect(fileResult).toEqual(file);
        expect(buffer).not.toBeNull();
      })
    );

    it(
      "should fail if no file with that id",
      withFixtures(async ({ fileService }) => {
        const fileId = faker.string.uuid();
        const { buffer, file } = await fileService.getFileAndBuffer(fileId);
        expect(file).toBeNull();
        expect(buffer).toBeNull();
      })
    );
  });
});
