import type { Prisma, PrismaClient } from "@prisma/client";
import { ContractStatus } from "@prisma/client";

import {
  calculateNextExpirationDate,
  calculateRenewalReminderDate,
} from "../utils/contracts.utils";
export class SyncCurrentTermEndDateService {
  // eslint-disable-next-line no-useless-constructor
  constructor(private db: PrismaClient) {}

  async syncNewCurrentTermEndDates() {
    try {
      await this.db.$transaction(async tx => {
        const expiredContracts = await tx.contract.findMany({
          where: {
            will_auto_renew: true,
            current_term_end_date: {
              lt: new Date(),
            },
            status: {
              not: ContractStatus.Canceled,
            },
          },
        });

        for (const contract of expiredContracts) {
          const newEndDate = calculateNextExpirationDate(
            contract.will_auto_renew,
            contract.auto_renew_term_length,
            contract.current_term_end_date || new Date()
          );

          const renewalReminderDate =
            newEndDate &&
            contract.auto_renew_term_length &&
            contract.renewal_reminder_lead_time_months
              ? calculateRenewalReminderDate(
                  contract.renewal_reminder_lead_time_months || null,
                  newEndDate
                )
              : contract.renewal_reminder_date
              ? contract.renewal_reminder_date
              : null;

          await tx.contract.update({
            where: {
              id: contract.id,
            },
            data: {
              current_term_end_date: newEndDate,
            },
          });

          if (!contract.is_month_to_month) {
            await tx.contract.update({
              where: {
                id: contract.id,
              },
              data: {
                renewal_reminder_date: renewalReminderDate,
              },
            });
          }
        }

        const expiredLocationContracts =
          await tx.contractLineItemLocation.findMany({
            where: {
              expires_at: {
                lt: new Date(),
              },
              contract_line_item: {
                contract: {
                  will_auto_renew: true,
                  status: {
                    not: ContractStatus.Canceled,
                  },
                },
              },
            },
            include: {
              contract_line_item: {
                include: {
                  contract: true,
                },
              },
            },
          });

        const groupedUpdates = expiredLocationContracts.reduce(
          (acc, locationContract) => {
            const key = `${
              locationContract.contract_line_item.contract.id
            }_${locationContract.expires_at?.toISOString()}`;
            acc[key] = acc[key] || [];
            acc[key].push({
              where: { id: locationContract.id },
              data: {
                expires_at: calculateNextExpirationDate(
                  locationContract.contract_line_item.contract.will_auto_renew,
                  locationContract.contract_line_item.contract
                    .auto_renew_term_length || null,
                  locationContract.expires_at || new Date()
                ),
              },
            });
            return acc;
          },
          {} as Record<string, Prisma.ContractLineItemLocationUpdateManyArgs[]>
        );

        const updatePromises = Object.values(groupedUpdates).map(
          async group => {
            const idsToUpdate = group.map(
              update => update.where?.id
            ) as string[];
            if (idsToUpdate.length > 0) {
              await tx.contractLineItemLocation.updateMany({
                data: group.map(update => update.data)[0],
                where: { id: { in: idsToUpdate } },
              });
            }
          }
        );

        await Promise.all(updatePromises);
      });
    } catch (e: any) {
      console.error(e);
    }
  }
}
