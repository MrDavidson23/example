const CIRCLE_API_HOST =
  process.env.CIRCLE_API_HOST || "Please set up your Circle SO host";
const CIRCLE_API_TOKEN =
  process.env.CIRCLE_API_TOKEN || "Please set up your Circle SO api token";

export type ICircleClientService = {
  getCirclePosts(communityId: number, spaceGroupId: number): Promise<Post[]>;
};

type Post = {
  id: number;
  status: string;
  name: string;
  body: Body;
  slug: string;
  url: string;
  space_name: string;
  space_slug: string;
  space_id: number;
  user_id: number;
  user_email: string;
  user_name: string;
  comments_count: number;
  community_id: number;
  hide_meta_info: boolean;
  user_avatar_url: string;
  published_at: Date;
  created_at: Date;
  updated_at: Date;
  cover_image: null;
  cover_image_url: null;
  cardview_thumbnail: null;
  cardview_thumbnail_url: null;
  is_comments_enabled: boolean;
  is_comments_closed: boolean;
  is_liking_enabled: boolean;
  flagged_for_approval_at: null;
  custom_html: null;
  likes_count: number;
  user_posts_count: number;
  user_topics_count: number;
  user_likes_count: number;
  user_comments_count: number;
};

type Body = {
  id: number;
  name: string;
  body: string;
  record_type: string;
  record_id: number;
  created_at: Date;
  updated_at: Date;
};

export class MockCircleClientService implements ICircleClientService {
  getCirclePosts(communityId: number, spaceGroupId: number): Promise<Post[]> {
    // return mock data
    return Promise.resolve([
      {
        id: 1,
        status: "published",
        name: "Post 1",
        body: {
          id: 1,
          name: "Body 1",
          body: "Body 1",
          record_type: "Post",
          record_id: 1,
          created_at: new Date(),
          updated_at: new Date(),
        },
        slug: "post-1",
        url: "https://example.com/post-1",
        space_name: "Space 1",
        space_slug: "space-1",
        space_id: spaceGroupId,
        user_id: 1,
        user_email: "example1@example.com",
        user_name: "User 1",
        comments_count: 0,
        community_id: communityId,
        hide_meta_info: false,
        user_avatar_url: "https://example.com/user-1",
        published_at: new Date(),
        created_at: new Date(),
        updated_at: new Date(),
        cover_image: null,
        cover_image_url: null,
        cardview_thumbnail: null,
        cardview_thumbnail_url: null,
        is_comments_enabled: true,
        is_comments_closed: false,
        is_liking_enabled: true,
        flagged_for_approval_at: null,
        custom_html: null,
        likes_count: 0,
        user_posts_count: 0,
        user_topics_count: 0,
        user_likes_count: 0,
        user_comments_count: 0,
      },
      {
        id: 2,
        status: "published",
        name: "Post 2",
        body: {
          id: 2,
          name: "Body 2",
          body: "Body 2",
          record_type: "Post",
          record_id: 2,
          created_at: new Date(),
          updated_at: new Date(),
        },
        slug: "post-2",
        url: "https://example.com/post-2",
        space_name: "Space 2",
        space_slug: "space-2",
        space_id: spaceGroupId,
        user_id: 2,
        user_email: "example2@example.com",
        user_name: "User 2",
        comments_count: 0,
        community_id: communityId,
        hide_meta_info: false,
        user_avatar_url: "https://example.com/user-2",
        published_at: new Date(),
        created_at: new Date(),
        updated_at: new Date(),
        cover_image: null,
        cover_image_url: null,
        cardview_thumbnail: null,
        cardview_thumbnail_url: null,
        is_comments_enabled: true,
        is_comments_closed: false,
        is_liking_enabled: true,
        flagged_for_approval_at: null,
        custom_html: null,
        likes_count: 0,
        user_posts_count: 0,
        user_topics_count: 0,
        user_likes_count: 0,
        user_comments_count: 0,
      },
    ]);
  }
}

export class CircleClientService implements ICircleClientService {
  constructor() {}

  async getCirclePosts(communityId: number, spaceGroupId: number) {
    try {
      const res = await fetch(
        `${CIRCLE_API_HOST}/api/v1/posts?community_id=${communityId}&space_group_id=${spaceGroupId}`,
        {
          headers: {
            Authorization: `Bearer ${CIRCLE_API_TOKEN}`,
          },
        }
      );
      const postsData = (await res.json()) as Post[];

      return postsData;
    } catch (error) {
      console.error("CircleClientError: Error in fetching posts", error);
      throw new Error("CircleClientError: Error in fetching posts");
    }
  }
}
