import { withFixtureFactory } from "../utils/test.utils.server";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { slugify } from "../utils/string.utils";
import { VendorState } from "@prisma/client";

const generateVendor = (name: string) => ({
  name,
  website: faker.internet.url(),
  state: VendorState.ApprovedForPublishing,
  hq_location: faker.location.city(),
  founded_year: faker.date.past().getFullYear().toString(),
  number_employees: faker.number.int({ min: 1, max: 1000 }).toString(),
  linkedin_profile_url: faker.internet.url(),
});

const generateVendorIntegrationData = (
  name: string,
  category_name: string,
  integrationNames: string[]
) => ({
  Name: name,
  "PM Software": integrationNames.join(","),
  "# integrations": integrationNames.length,
  URL: faker.internet.url(),
  Founded: faker.date.past().getFullYear().toString(),
  "First seen": faker.date.recent().toLocaleDateString(),
  Categories: category_name,
});

describe("PropexoService", () => {
  const withFixtures = withFixtureFactory({
    setup: async tx => {
      const category = await tx.productCategory.create({
        data: {
          name: faker.company.name(),
          description: "description",
          slug: "category",
          faq_1: "faq 1",
          faq_2: "faq 2",
          faq_3: "faq 3",
          faq_1_answer: "faq 1 answer",
          faq_2_answer: "faq 2 answer",
          faq_3_answer: "faq 3 answer",
          meta_description: "meta description",
          page_title: "page title",
        },
      });

      const VENDORS = [
        generateVendor("Bensontest"),
        generateVendor("Leotest248"),
        generateVendor("FAKEPAGETEST, INC."),
        generateVendor("ABC Software"),
        generateVendor("MACKtest PROPERTY MANAGEMENT"),
      ];
      const vendors = await Promise.all(
        VENDORS.map(v =>
          tx.vendor.create({
            data: { ...v, slug: slugify(v.name) },
          })
        )
      );
      return {
        vendors,
        category,
      };
    },
  });

  describe("syncIntegrationPartners", () => {
    it(
      "should create and delete vendor integrations using csv data",
      withFixtures(async ({ vendors, category }, tx) => {
        const { propexoService, db } = TestDIContainer(tx);

        // create integrations
        const formattedVendors = vendors.map(vendor => {
          const otherVendorNames = vendors
            .filter(v => v.id !== vendor.id)
            .map(v => v.name);
          return generateVendorIntegrationData(
            vendor.name,
            category.name,
            otherVendorNames
          );
        });

        const response = await propexoService.syncIntegrationPartners(
          formattedVendors
        );
        expect(response.success).toBeTruthy();

        const integrations = await db.vendorIntegration.findMany({
          where: {
            vendor_id: {
              in: vendors.map(v => v.id),
            },
          },
        });
        expect(integrations).not.toBeNull();

        // delete integrations
        const deleteResponse = await propexoService.syncIntegrationPartners([
          {
            Name: "",
            "PM Software": "",
            "# integrations": "",
            URL: "",
            Founded: "",
            "First seen": "",
            Categories: "",
          },
        ]);
        expect(deleteResponse.success).toBeTruthy();

        const deletedIntegrations = await db.vendorIntegration.findMany({
          where: {
            vendor_id: {
              in: vendors.map(v => v.id),
            },
          },
        });
        expect(deletedIntegrations).toHaveLength(0);
      })
    );
  });
});
