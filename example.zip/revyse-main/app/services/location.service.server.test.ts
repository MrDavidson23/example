import { faker } from "@faker-js/faker";
import {
  ContractLineItemStatus,
  ContractStatus,
  LocationClass,
  LocationStatus,
  Prisma,
} from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { withFixtureFactory } from "../utils/test.utils.server";
import { Roles } from "../utils/intelligence-permission.utils";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const managerAccount = await tx.managerAccount.create({
      data: {
        name: faker.company.name(),
      },
    });

    const user = await tx.user.create({
      data: {
        email: faker.internet.email(),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
        manager_account_roles: {
          create: {
            manager_account: {
              connect: {
                id: managerAccount.id,
              },
            },
            role: Roles.Owner,
          },
        },
      },
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
          include: {
            location_roles: true,
          },
        },
        user_roles: true,
      },
    });

    const locationNames = [
      "Location 1",
      "Location 2",
      "Location 3",
      "Location 4",
      "Location 5",
    ];

    const locations = await Promise.all(
      locationNames.map(name =>
        tx.location.create({
          data: {
            name,
            pms_id: faker.string.alphanumeric(6),
            owner_name: faker.company.name(),
            street_1: faker.location.streetAddress(),
            street_2: faker.location.secondaryAddress(),
            city: faker.location.city(),
            state: faker.location.state(),
            zip: faker.location.zipCode(),
            region: `${faker.location.city()} ${faker.string.alphanumeric(5)}`,
            unit_count: faker.number.int({ min: 1, max: 1000 }),
            class: faker.helpers.enumValue(LocationClass),
            status: faker.helpers.enumValue(LocationStatus),
            manager_account_id: managerAccount.id,
          },
        })
      )
    );

    return { managerAccount, locations, user };
  },
});

describe("LocationService", () => {
  describe("getLocation", () => {
    it(
      "should return a location by id",
      withFixtures(async ({ locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const locationFromService = await locationService.getLocation(
          locations[0].id
        );

        expect(locationFromService).not.toBeNull();
        expect(locationFromService?.name).toEqual(locations[0].name);
        expect(locationFromService?.pms_id).toEqual(locations[0].pms_id);
        expect(locationFromService?.owner_name).toEqual(
          locations[0].owner_name
        );
      })
    );
  });

  describe("getLocations", () => {
    it(
      "should return all locations",
      withFixtures(async ({ user, managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const locationsFromService = await locationService.getLocations(
          user,
          managerAccount,
        );

        expect(locationsFromService).toHaveLength(5);

        locations.forEach((location, index) => {
          expect(locationsFromService[index].name).toBe(location.name);
        });
      })
    );

    it(
      "should return locations with query",
      withFixtures(async ({ user, managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const locationsFromService = await locationService.getLocations(
          user,
          managerAccount,
          {
            query: locations[0].name,
          }
        );

        expect(locationsFromService).toHaveLength(1);
        expect(locationsFromService[0].id).toBe(locations[0].id);
      })
    );

    it(
      "should return locations with filters",
      withFixtures(async ({ user, managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const locationsFromService = await locationService.getLocations(
          user,
          managerAccount,
          {
            region: [locations[0].region!, locations[4].region!],
          }
        );

        expect(locationsFromService).toHaveLength(2);
        expect(locationsFromService[0].id).toBe(locations[0].id);
        expect(locationsFromService[1].id).toBe(locations[4].id);
      })
    );

    it(
      "should return locations with pagination",
      withFixtures(async ({ user, managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const locationsFromService = await locationService.getLocations(
          user,
          managerAccount,
          undefined,
          0,
          2
        );

        expect(locationsFromService).toHaveLength(2);
        expect(locationsFromService[0].id).toBe(locations[0].id);
        expect(locationsFromService[1].id).toBe(locations[1].id);
      })
    );

    it(
      "should throw error with not found manager account id",
      withFixtures(async ({ user, managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const locationsFromService = await locationService.getLocations(
          user,
          { id: faker.string.uuid() },
        );

        expect(locationsFromService).toHaveLength(0);
      })
    );
  });

  describe("getLocationsCount", () => {
    it(
      "should return all locations count",
      withFixtures(async ({ user, managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const count = await locationService.getLocationsCount(
          user,
          managerAccount,
        );

        expect(count).toBe(5);
      })
    );

    it(
      "should return locations count with query",
      withFixtures(async ({ user, managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const count = await locationService.getLocationsCount(
          user,
          managerAccount,
          {
            query: locations[0].name,
          }
        );

        expect(count).toBe(1);
      })
    );

    it(
      "should return locations count with filters",
      withFixtures(async ({ user, managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const count = await locationService.getLocationsCount(
          user,
          managerAccount,
          {
            region: [locations[0].region!, locations[4].region!],
          }
        );

        expect(count).toBe(2);
      })
    );

    it(
      "should throw error with not found manager account id",
      withFixtures(async ({ user, managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const count = await locationService.getLocationsCount(
          user,
          { id: faker.string.uuid() },
        );

        expect(count).toBe(0);
      })
    );
  });

  describe("getLocationsRegions", () => {
    it(
      "should return all locations regions",
      withFixtures(async ({ managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const regions = await locationService.getLocationsRegions(
          managerAccount.id
        );

        expect(regions).toHaveLength(5);

        const expectedRegions = locations.map(location => location.region!);

        expect(regions.map(region => region.region)).toEqual(
          expect.arrayContaining(expectedRegions)
        );
      })
    );

    it(
      "should return locations regions with query",
      withFixtures(async ({ managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const regions = await locationService.getLocationsRegions(
          managerAccount.id,
          locations[0].region!
        );

        expect(regions).toHaveLength(1);
        expect(regions[0].region).toBe(locations[0].region);
      })
    );

    it(
      "should not return locations regions if not found",
      withFixtures(async ({ managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const regions = await locationService.getLocationsRegions(
          managerAccount.id,
          faker.string.alphanumeric(5)
        );

        expect(regions).toHaveLength(0);
      })
    );
  });

  describe("getLocationsOwners", () => {
    it(
      "should return all locations owners",
      withFixtures(async ({ managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const owners = await locationService.getLocationsOwners(
          managerAccount.id
        );

        expect(owners).toHaveLength(5);

        const expectedOwners = locations.map(location => location.owner_name);

        expect(owners.map(owner => owner.owner_name)).toEqual(
          expect.arrayContaining(expectedOwners)
        );
      })
    );

    it(
      "should throw error with not found manager account id",
      withFixtures(async ({ managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const owners = await locationService.getLocationsOwners(
          faker.string.uuid()
        );

        expect(owners).toHaveLength(0);
      })
    );
  });

  describe("createLocation", () => {
    it(
      "should create location",
      withFixtures(async ({ managerAccount }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const location = await locationService.createLocation({
          name: faker.company.name(),
          pms_id: faker.string.alphanumeric(6),
          owner_name: faker.company.name(),
          street_1: faker.location.streetAddress(),
          street_2: faker.location.secondaryAddress(),
          city: faker.location.city(),
          state: faker.location.state(),
          zip: faker.location.zipCode(),
          region: `${faker.location.city()} ${faker.string.alphanumeric(5)}`,
          unit_count: faker.number.int({ min: 1, max: 1000 }),
          class: faker.helpers.enumValue(LocationClass),
          status: faker.helpers.enumValue(LocationStatus),
          manager_account: {
            connect: {
              id: managerAccount.id,
            },
          },
        });

        expect(location.id).toBeTruthy();

        const locationFromDb = await tx.location.findUnique({
          where: {
            id: location.id,
          },
        });

        expect(locationFromDb).toBeTruthy();
      })
    );
  });

  describe("createLocations", () => {
    it(
      "should create locations",
      withFixtures(async ({ managerAccount }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const locationNames = ["Location 6", "Location 7"];

        await locationService.createLocations(
          locationNames.map(name => ({
            name,
            pms_id: faker.string.alphanumeric(6),
            owner_name: faker.company.name(),
            street_1: faker.location.streetAddress(),
            street_2: faker.location.secondaryAddress(),
            city: faker.location.city(),
            state: faker.location.state(),
            zip: faker.location.zipCode(),
            region: `${faker.location.city()} ${faker.string.alphanumeric(5)}`,
            unit_count: faker.number.int({ min: 1, max: 1000 }),
            class: faker.helpers.enumValue(LocationClass),
            status: faker.helpers.enumValue(LocationStatus),
            manager_account_id: managerAccount.id,
          }))
        );

        const locationsFromDb = await tx.location.findMany({
          where: {
            manager_account_id: managerAccount.id,
          },
        });

        expect(locationsFromDb).toHaveLength(7);

        const expectedLocations = locationsFromDb.filter(location =>
          locationNames.includes(location.name)
        );

        expect(expectedLocations).toHaveLength(2);
      })
    );
  });

  describe("updateLocation", () => {
    it(
      "should update location",
      withFixtures(async ({ managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const location = locations[0];

        const updatedLocation = await locationService.updateLocation(
          location.id,
          {
            name: "Updated Location",
          }
        );

        expect(updatedLocation.id).toBe(location.id);
        expect(updatedLocation.name).toBe("Updated Location");
      })
    );

    it(
      "should throw error with not found location id",
      withFixtures(async ({ managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const updatedLocation = locationService.updateLocation(
          faker.string.uuid(),
          {
            name: "Updated Location",
          }
        );

        expect(updatedLocation).rejects.toThrow(
          Prisma.PrismaClientKnownRequestError
        );
      })
    );
  });

  describe("deleteLocation", () => {
    it(
      "should delete location",
      withFixtures(async ({ managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const location = locations[0];

        await locationService.deleteLocation(location.id);

        const locationFromDb = await tx.location.findUnique({
          where: {
            id: location.id,
          },
        });

        expect(locationFromDb).toBeNull();
      })
    );

    it(
      "should throw error with not found location id",
      withFixtures(async ({ managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const deletedLocation = locationService.deleteLocation(
          faker.string.uuid()
        );

        expect(deletedLocation).rejects.toThrow(
          Prisma.PrismaClientKnownRequestError
        );
      })
    );
  });

  describe("getLocation", () => {
    it(
      "should return location",
      withFixtures(async ({ managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const location = locations[0];

        const locationFromService = await locationService.getLocation(
          location.id
        );

        expect(locationFromService).toBeTruthy();
        expect(locationFromService?.id).toBe(location.id);
      })
    );

    it(
      "should return null with not found location id",
      withFixtures(async ({ managerAccount, locations }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const locationFromService = locationService.getLocation(
          faker.string.uuid()
        );

        await expect(locationFromService).resolves.toBeNull();
      })
    );
  });

  describe("getLocationContractsWithDocuments", () => {
    it(
      "should return location contracts with documents",
      withFixtures(async ({ managerAccount, locations, user }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const filesForTesting = await Promise.all(
          Array.from({ length: 5 }, () =>
            tx.file.create({
              data: {
                title: faker.system.fileName(),
                uri: faker.internet.url(),
                mime_type: faker.system.mimeType(),
                size_kb: faker.number.int({ min: 1, max: 1000 }),
              },
            })
          )
        );

        const contractsWithDocuments = await Promise.all([
          ...Array.from({ length: 5 }, () =>
            tx.contract.create({
              include: {
                contracted_location_files: {
                  where: {
                    location_id: locations[0].id,
                  },
                  include: {
                    file: true,
                  },
                },
                document_files: {
                  include: {
                    file: true,
                  },
                },
                manager_account_vendor: {
                  select: {
                    vendor_id: true,
                    vendor: {
                      select: {
                        name: true,
                      },
                    },
                  },
                },
                _count: {
                  select: {
                    contract_line_items: {
                      where: {
                        status: ContractLineItemStatus.Canceled,
                      },
                    },
                  },
                },
              },
              data: {
                name: faker.company.name(),
                status: faker.helpers.enumValue(ContractStatus),
                contracted_location_files: {
                  createMany: {
                    data: faker.helpers.arrayElements(
                      filesForTesting.map(file => ({
                        name: faker.system.fileName(),
                        file_id: file.id,
                        location_id: locations[0].id,
                      }))
                    ),
                  },
                },
                manager_account_vendor: {
                  create: {
                    vendor: {
                      create: {
                        name: faker.company.name(),
                      },
                    },
                    manager_account: {
                      connect: {
                        id: managerAccount.id,
                      },
                    },
                  },
                },
              },
            })
          ),
          ...Array.from({ length: 5 }, () =>
            tx.contract.create({
              include: {
                contracted_location_files: {
                  where: {
                    location_id: locations[0].id,
                  },
                  include: {
                    file: true,
                  },
                },
                document_files: {
                  include: {
                    file: true,
                  },
                },
                manager_account_vendor: {
                  select: {
                    vendor_id: true,
                    vendor: {
                      select: {
                        name: true,
                      },
                    },
                  },
                },
                _count: {
                  select: {
                    contract_line_items: {
                      where: {
                        status: ContractLineItemStatus.Canceled,
                      },
                    },
                  },
                },
              },
              data: {
                name: faker.company.name(),
                status: faker.helpers.enumValue(ContractStatus),
                location: {
                  connect: {
                    id: locations[0].id,
                  },
                },
                document_files: {
                  createMany: {
                    data: faker.helpers.arrayElements(
                      filesForTesting.map(file => ({
                        name: faker.system.fileName(),
                        file_id: file.id,
                      }))
                    ),
                  },
                },
                manager_account_vendor: {
                  create: {
                    vendor: {
                      create: {
                        name: faker.company.name(),
                      },
                    },
                    manager_account: {
                      connect: {
                        id: managerAccount.id,
                      },
                    },
                  },
                },
              },
            })
          ),
        ]);

        const contractsWithDocumentsFromService =
          await locationService.getLocationContractsWithDocuments(
            user,
            managerAccount,
            locations[0].id,
            {}
          );

        expect(contractsWithDocumentsFromService.data).toHaveLength(10);
        expect(contractsWithDocumentsFromService.count).toBe(10);
        const expectedContractsWithDocuments = [
          ...contractsWithDocuments.slice(0, 5).map(contract => ({
            ...contract,
            documents: contract.contracted_location_files,
          })),
          ...contractsWithDocuments.slice(5).map(contract => ({
            ...contract,
            documents: contract.document_files,
          })),
        ];

        expect(contractsWithDocumentsFromService.data).toEqual(
          expect.arrayContaining(expectedContractsWithDocuments)
        );

        // Filter by search query
        const contractsWithDocumentsFromServiceWithSearchQuery =
          await locationService.getLocationContractsWithDocuments(
            user,
            managerAccount,
            locations[0].id,
            {
              filters: {
                searchQuery: contractsWithDocuments[0].name,
              },
            }
          );

        expect(
          contractsWithDocumentsFromServiceWithSearchQuery.data
        ).toHaveLength(1);
        expect(contractsWithDocumentsFromServiceWithSearchQuery.count).toBe(1);
        expect(
          contractsWithDocumentsFromServiceWithSearchQuery.data[0].id
        ).toBe(contractsWithDocuments[0].id);
      })
    );

    it(
      "should return empty array with not found location id",
      withFixtures(async ({ managerAccount, locations, user }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const contractsWithDocumentsFromService =
          await locationService.getLocationContractsWithDocuments(
            user,
            managerAccount,
            faker.string.uuid(),
            {}
          );

        expect(contractsWithDocumentsFromService.data).toHaveLength(0);
        expect(contractsWithDocumentsFromService.count).toBe(0);
      })
    );

    it(
      "should return empty array with not found location contracts with documents",
      withFixtures(async ({ managerAccount, locations, user }, tx) => {
        const { locationService } = TestDIContainer(tx);

        const contractsWithDocumentsFromService =
          await locationService.getLocationContractsWithDocuments(
            user,
            managerAccount,
            locations[0].id,
            {}
          );

        expect(contractsWithDocumentsFromService.data).toHaveLength(0);
        expect(contractsWithDocumentsFromService.count).toBe(0);
      })
    );
  });
});
