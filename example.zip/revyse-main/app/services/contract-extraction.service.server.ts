import type { BaseNode } from "llamaindex";
import type { RAGService } from "./rag.service.server";
import { GPTModel } from "./rag.service.server";
import { getLogger } from "./logger.factory";
import type { PrismaClient } from "@prisma/client";
import {
  ContractAIExtractFieldStatus,
  ContractAIExtractStatus,
} from "@prisma/client";

export class ContractExtractionService {
  constructor(private db: PrismaClient, private ragService: RAGService) {}

  logger = getLogger("ContractExtractionService");

  async extractInfoFromContract({
    contract_id,
    user_id,
  }: {
    contract_id: string;
    user_id: string;
  }) {
    // Do these in batches so we won't hit Pinecone rate limit
    this.logger.info(`Extracting contract info for contract ${contract_id}`);

    const aiExtract = await this.db.contractAIExtract.create({
      data: {
        contract_id,
        initiated_by_id: user_id,
      },
    });

    // If the extraction doesn't complete in 2 minutes, mark it as failed
    setTimeout(async () => {
      try {
        await this.db.contractAIExtract.update({
          data: {
            status: ContractAIExtractStatus.FAILED,
          },
          where: { id: aiExtract.id },
        });
      } catch (e) {
        this.logger.error("Failed to update contract AI extract status", e);
      }
    }, 120000);

    this.logger.info(`Extracting batch 1...`);
    await Promise.all([
      this.extractVendor(contract_id, aiExtract.id),
      this.extractContractLength(contract_id, aiExtract.id),
      this.extractEffectiveDate(contract_id, aiExtract.id),
      this.extractCustomerSigner(contract_id, aiExtract.id),
    ]);
    this.logger.info(`Extracting batch 2...`);
    await Promise.all([
      this.extractIsMSA(contract_id, aiExtract.id),
      this.extractIsMonthToMonth(contract_id, aiExtract.id),
      this.extractIsAutoRenewing(contract_id, aiExtract.id),
    ]);
    this.logger.info(`Extraction done`);
    const completeAiExtract = await this.db.contractAIExtract.update({
      data: {
        completed_at: new Date(),
        status: ContractAIExtractStatus.COMPLETE,
      },
      where: { id: aiExtract.id },
      include: {
        fields: true,
      },
    });
    return completeAiExtract;
  }

  async extractContractLength(contract_id: string, ai_extract_id: string) {
    const model = GPTModel.GPT_35_TURBO;
    const prompt_version = "0.0.1";
    const prompt = `You are an expert in contract law. 
    Determine the length of time in months that this agreement will be effective initially. 
    This may also be referred to as the "Term" or "Effective Period".`;
    return this.extractField(
      contract_id,
      "contract_length",
      ai_extract_id,
      model,
      prompt_version,
      prompt
    );
  }

  async extractEffectiveDate(contract_id: string, ai_extract_id: string) {
    const model = GPTModel.GPT_35_TURBO;
    const prompt_version = "0.0.1";
    const prompt = `You are an expert in contract law. Find the effective date. 
    Report the effective date in the YYYY-MM-DD format.`;
    return this.extractField(
      contract_id,
      "effective_date",
      ai_extract_id,
      model,
      prompt_version,
      prompt
    );
  }

  async extractCustomerSigner(contract_id: string, ai_extract_id: string) {
    const model = GPTModel.GPT_35_TURBO;
    const prompt_version = "0.0.1";
    const prompt = `You are an expert in contract law. Find the name of the customer (the person, not company) who signed the document.`;
    return this.extractField(
      contract_id,
      "customer_signer",
      ai_extract_id,
      model,
      prompt_version,
      prompt
    );
  }

  async extractIsMSA(contract_id: string, ai_extract_id: string) {
    const model = GPTModel.GPT_35_TURBO;
    const prompt_version = "0.0.1";
    const prompt = `You are an expert in contract law. Is this a master service agreement?
    Respond with "Yes" or "No".`;
    return this.extractField(
      contract_id,
      "is_msa",
      ai_extract_id,
      model,
      prompt_version,
      prompt
    );
  }

  async extractIsMonthToMonth(contract_id: string, ai_extract_id: string) {
    const model = GPTModel.GPT_35_TURBO;
    const prompt_version = "0.0.1";
    const prompt = `You are an expert in contract law. Is this contract month-to-month?
    Respond with "Yes" or "No".`;
    return this.extractField(
      contract_id,
      "is_month_to_month",
      ai_extract_id,
      model,
      prompt_version,
      prompt
    );
  }

  async extractIsAutoRenewing(contract_id: string, ai_extract_id: string) {
    const model = GPTModel.GPT_35_TURBO;
    const prompt_version = "0.0.1";
    const prompt = `You are an expert in contract law. Does this agreement renew automatically? 
    This may be found in the section titled "Term" or "Renewal".
    Respond with "Yes" or "No".`;
    return this.extractField(
      contract_id,
      "is_auto_renewing",
      ai_extract_id,
      model,
      prompt_version,
      prompt
    );
  }

  extractVendor(contract_id: string, ai_extract_id: string) {
    const model = GPTModel.GPT_35_TURBO;
    const prompt_version = "0.0.1";
    const prompt = `You are an expert in contract law. Who is the vendor in this agreement? 
    Some documents may refer to this entity as "The Company".`;
    return this.extractField(
      contract_id,
      "vendor",
      ai_extract_id,
      model,
      prompt_version,
      prompt
    );
  }

  private static instructions = `Given the context information and not prior knowledge, answer the query.
If you cannot find an answer in the given context respond with "No answer found".
Respond with the answer between <answer></answer>. 
Respond with your reasoning between <reasoning></reasoning>.
Respond with your confidence level on a scale from 0 to 1 between <confidence></confidence>.
Respond with the document where you found the information between <document></document>.
Respond with the page number where you found the information between <page_number></page_number>.
Respond with the section where you found the information between <section></section>.`;

  private async extractField(
    contract_id: string,
    field_name: string,
    ai_extract_id: string,
    model: GPTModel,
    prompt_version: string,
    prompt: string
  ) {
    const field = await this.db.contractAIExtractField.create({
      data: {
        field_name,
        model_used: model,
        prompt_version,
        prompt,
        contract_ai_extract_id: ai_extract_id,
      },
    });
    const response = await this.ragService.query({
      query: prompt,
      instructions: ContractExtractionService.instructions,
      filter: { contract_id },
      model,
    });
    const info = this.getInfoFromResponse({
      response: response.response,
      context: response.sourceNodes,
    });
    const completeField = await this.db.contractAIExtractField.update({
      data: info,
      where: { id: field.id },
    });
    return completeField;
  }

  private findTagValueInText(tag: string, text: string) {
    const regex = new RegExp(`<${tag}>(.*?)</${tag}>`);
    const match = regex.exec(text);
    if (match) {
      return match[1];
    }
    return null;
  }

  private getInfoFromResponse({
    response,
    context,
  }: {
    response: string;
    context: BaseNode[] | undefined;
  }) {
    if (context) {
      // Remove the embeddings from the context cuz, we don't want to store them.
      context.forEach(node => {
        delete node.embedding;
      });
    }
    const document = this.findTagValueInText("document", response);
    const page_number = this.findTagValueInText("page_number", response);
    const section = this.findTagValueInText("section", response);
    return {
      response,
      context,
      field_value: this.findTagValueInText("answer", response),
      reasoning: this.findTagValueInText("reasoning", response),
      confidence: this.findTagValueInText("confidence", response),
      reference: `${document}; page ${page_number}; section ${section}`,
      status: ContractAIExtractFieldStatus.COMPLETE,
      completed_at: new Date(),
    };
  }
}
