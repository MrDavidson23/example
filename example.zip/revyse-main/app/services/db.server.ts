import type { Prisma } from "@prisma/client";
import { PrismaClient } from "@prisma/client";
import { getEnv } from "./env.service.server";
declare global {
  // eslint-disable-next-line no-var
  var _db: PrismaClient | undefined;
}

export function getDb() {
  const env = getEnv();
  const DB_USER = env.DB_USER;
  const DB_PASS = env.DB_PASS;
  const DB_HOST = env.DB_HOST;
  const DB_PORT = env.DB_PORT;
  const DB_NAME = env.DB_NAME;

  if (!global._db) {
    // NOTE: we need to use segmented parts of the DB URL because when we create environments in AWS
    // We want terraform to manage the creation of the DB. Thus WE specify the user, pass, dbname but
    // RDS should specify the host.
    const url = `postgresql://${DB_USER}:${DB_PASS}@${DB_HOST}:${DB_PORT}/${DB_NAME}`;

    global._db = makeProxyPrismaClient(
      new PrismaClient({
        log: [
          // { emit: "event", level: "query" },
          "info",
          "warn",
          "error",
        ],
        datasources: {
          db: {
            url,
          },
        },
      })
    );

    // https://github.com/prisma/prisma/issues/5026
    // eslint-disable-next-line @typescript-eslint/ban-ts-comment
    // @ts-ignore
    global._db.$on("query", e => {
      // eslint-disable-next-line @typescript-eslint/ban-ts-comment
      // @ts-ignore
      console.log(`${e.query} ${e.params}`);
    });
  }

  return global._db as ProxyPrismaClient;
}

export type Override<T, K extends Partial<{ [key in keyof T]: any }>> = Omit<
  T,
  keyof K
> &
  K;

export type PrismaTransaction = Omit<
  PrismaClient,
  "$on" | "$connect" | "$disconnect" | "$use" | "$transaction" | "$extends"
>;

export type ProxyPrismaClient = Override<
  PrismaClient,
  {
    $transaction<T>(
      cb: ((tx: ProxyPrismaClient) => Promise<T>) | any[],
      options?: {
        maxWait?: number;
        timeout?: number;
        isolationLevel?: Prisma.TransactionIsolationLevel;
      }
    ): Promise<T>;
  }
>;

function makeProxyPrismaTransaction(
  pTx: PrismaTransaction,
  prisma: PrismaClient
): ProxyPrismaClient {
  const proxyTx = new Proxy(pTx, {
    get(target2, prop2) {
      if (prop2 === "$transaction") {
        return (cb2: ((ttTx2: ProxyPrismaClient) => Promise<any>) | any[]) =>
          Array.isArray(cb2) ? prisma.$transaction(cb2) : cb2(proxyTx);
      }
      if (prop2 === "$disconnect") {
        return () => prisma.$disconnect();
      }
      return target2[prop2 as keyof PrismaTransaction];
    },
  }) as ProxyPrismaClient;
  return proxyTx;
}

function makeProxyPrismaClient(prisma: PrismaClient): ProxyPrismaClient {
  const proxyPrismaClient = new Proxy(prisma, {
    get(target, prop) {
      if (prop === "$transaction") {
        return (
          cb: (ttTx: ProxyPrismaClient) => Promise<any>,
          options: any
        ) => {
          const proxyCallback = (pTx: PrismaTransaction) => {
            const proxyTx = makeProxyPrismaTransaction(pTx, prisma);
            return cb(proxyTx);
          };

          return target.$transaction(proxyCallback, options);
        };
      }

      return target[prop as keyof PrismaClient];
    },
  }) as any;

  return proxyPrismaClient;
}

export function withTx(testFn: (tx: ProxyPrismaClient) => any) {
  return async () => {
    const db = getDb();
    try {
      await db.$transaction(async tx => {
        await testFn(tx);
        throw "rollback";
      });
    } catch (e) {
      if (e !== "rollback") {
        throw e;
      }
    }
  };
}
