import { ContractStatus, type Prisma, VendorState } from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { createTestUser } from "./seeds/createTestUser";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { authService } = await TestDIContainer(tx);

    const user = await createTestUser(faker.internet.email(), authService);
    const category = await tx.productCategory.create({
      data: {
        name: faker.company.name(),
        description: "description",
        slug: "category",
        faq_1: "faq 1",
        faq_2: "faq 2",
        faq_3: "faq 3",
        faq_1_answer: "faq 1 answer",
        faq_2_answer: "faq 2 answer",
        faq_3_answer: "faq 3 answer",
        meta_description: "meta description",
        page_title: "page title",
      },
    });

    const account = await tx.managerAccount.create({
      data: {
        name: faker.company.name(),
        manager_account_vendors: {
          create: {
            vendor: {
              create: {
                name: faker.company.name(),
              },
            },
          },
        },
      },
      include: {
        manager_account_vendors: true,
      },
    });

    const vendor = await tx.vendor.create({
      data: {
        slug: faker.internet.url(),
        name: faker.company.name(),
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
      },
      include: {
        products: true,
      },
    });

    const lineItemPrices = Array.from(
      "_".repeat(faker.number.int({ min: 1, max: 3 }))
    ).map(_ => faker.number.int({ min: 100, max: 1000 }));

    const fees = await Promise.all(
      Array.from({ length: 3 }).map(() => {
        return tx.fee.create({
          data: {
            name: faker.company.name(),
            vendor_id: vendor.id,
            category_id: category.id,
            manager_account_id: account.id,
          },
        });
      })
    );

    const contractWithContractLineItemFees = await tx.contract.create({
      data: {
        name: faker.commerce.productName(),
        will_auto_renew: true,
        current_term_end_date: null,
        status: ContractStatus.Active,
        is_month_to_month: true,
        manager_account_vendor_id: account.manager_account_vendors[0].id,
        renewal_reminder_lead_time_months: 6,
        auto_renew_term_length: 12,
        contract_owner_name: faker.person.fullName(),
        approver: faker.person.fullName(),
        contract_line_items: {
          create: {
            name: faker.commerce.productName(),
            contract_line_item_fees: {
              createMany: {
                data: lineItemPrices.map((price, index) => ({
                  department: "Support",
                  price: price,
                  fee_id: fees[index].id,
                })),
              },
            },
          },
        },
      },
      include: {
        manager_account_vendor: {
          include: {
            vendor: true,
          },
        },
      },
    });

    return {
      user,
      account,
      fees,
      vendor,
      contract: contractWithContractLineItemFees,
      category,
    };
  },
});

describe("FeeService", () => {
  describe("getFees", () => {
    test(
      "it should return fees by filters provided",
      withFixtures(async ({ vendor, account }, tx) => {
        const { feeService } = TestDIContainer(tx);
        const feeFilters: Prisma.FeeWhereInput = {
          vendor_id: vendor.id,
          manager_account_id: account?.id,
        };

        const fees = await feeService.getFees(feeFilters);

        expect(fees).not.toBeNull();
        expect(fees).toHaveLength(3);
      })
    );
  });

  describe("createFee", () => {
    test(
      "it should create a new fee",
      withFixtures(async ({ vendor, account, category }, tx) => {
        const { feeService } = TestDIContainer(tx);

        const fee = await feeService.createFee(
          "New Fee",
          category.id,
          vendor.id,
          account.id
        );
        expect(fee).not.toBeNull();

        const feeFilters: Prisma.FeeWhereInput = {
          vendor_id: vendor.id,
          manager_account_id: account?.id,
        };

        const fees = await feeService.getFees(feeFilters);
        expect(fees).toHaveLength(4);
      })
    );
  });

  describe("updateFee", () => {
    test(
      "it should update a provided fee",
      withFixtures(async ({ category, fees }, tx) => {
        const { feeService } = TestDIContainer(tx);

        const fee = await feeService.updateFee(
          fees[0].id,
          "New Fee Name",
          category.id
        );
        expect(fee).not.toBeNull();
        expect(fee.name).toEqual("New Fee Name");
      })
    );
  });

  describe("deleteFee", () => {
    test(
      "it should delete a fee",
      withFixtures(async ({ fees, vendor, account }, tx) => {
        const { feeService, db } = TestDIContainer(tx);

        await feeService.deleteFee(fees[2].id);

        const feeFilters: Prisma.FeeWhereInput = {
          vendor_id: vendor.id,
          manager_account_id: account?.id,
        };

        const fee = await db.fee.findFirst({
          where: {
            id: fees[2].id,
          },
        });

        const testFees = await feeService.getFees(feeFilters);
        expect(testFees).toHaveLength(2);
        expect(fee).toBeNull();
      })
    );
  });
});
