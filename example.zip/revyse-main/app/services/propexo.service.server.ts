import { IntegrationProvider, type PrismaClient } from "@prisma/client";
import { type TypedResponse } from "@remix-run/node";

export type IPropexoService = {
  syncIntegrationPartners(data: any): Promise<TypedResponse>;
};

export class PropexoService implements IPropexoService {
  constructor(private db: PrismaClient) {}

  async syncIntegrationPartners(data: any): Promise<any> {
    try {
      const recordsToDelete = [];
      const existingRecords = await this.db.vendorIntegration.findMany({
        where: {
          integration_provider: IntegrationProvider.Propexo,
        },
        include: {
          vendor: {
            select: {
              name: true,
            },
          },
          integrated_vendor: {
            select: {
              name: true,
            },
          },
          integrated_product: {
            select: {
              title: true,
            },
          },
        },
      });

      for (const existingRecord of existingRecords) {
        const isIntegratedVendor = existingRecord.integrated_vendor_id !== null;

        const nameToCheck = isIntegratedVendor
          ? existingRecord.integrated_vendor?.name
          : existingRecord.integrated_product?.title;

        const mappedName = mapVendorProductNames(nameToCheck);

        const isPresentInNewData = data.some(
          (row: any) =>
            row["Name"] === mapVendorProductNames(existingRecord.vendor.name) &&
            row["PM Software"].includes(mappedName)
        );

        if (!isPresentInNewData) {
          recordsToDelete.push(existingRecord.id);
        }
      }
      if (recordsToDelete.length > 0) {
        await this.db.vendorIntegration.deleteMany({
          where: {
            id: {
              in: recordsToDelete,
            },
          },
        });
      }
      const clearedRows = data.filter(
        (item: any) =>
          !(item["Name"] === "Text" && item["PM Software"] === "Text")
      );

      if (clearedRows.length === 0) {
        return {
          success: false,
          message:
            "We didn't find any integrations to insert in the file, please update the file and try again",
        };
      }

      for (const row of clearedRows) {
        const vendorNameWithInfo = mapVendorProductNames(row["Name"]);
        const extractedVendorName = extractVendorName(vendorNameWithInfo);
        const vendorName = mapVendorProductNames(extractedVendorName);
        const integrationsList = row["PM Software"].split(",");

        const vendor = await this.db.vendor.findFirst({
          where: { name: vendorName },
        });

        if (!vendor) {
          console.error(`Vendor with name ${vendorName} not found.`);
          continue;
        }

        for (const pmSoftware of integrationsList) {
          const existingVendor = await this.db.vendor.findFirst({
            where: { name: mapVendorProductNames(pmSoftware) },
          });

          const existingProduct = await this.db.product.findFirst({
            where: { title: mapVendorProductNames(pmSoftware) },
          });

          const existingRecord = await this.db.vendorIntegration.findFirst({
            where: {
              vendor_id: vendor.id,
              OR: [
                { integrated_vendor_id: existingVendor?.id },
                { integrated_product_id: existingProduct?.id },
              ],
            },
          });

          if (existingRecord && (existingVendor || existingProduct)) {
            await this.db.vendorIntegration.upsert({
              where: {
                id: existingRecord?.id,
              },
              create: {
                vendor_id: vendor.id,
                integrated_vendor_id: existingVendor?.id
                  ? existingVendor?.id
                  : null,
                integration_provider: IntegrationProvider.Propexo,
                integrated_product_id: existingProduct?.id
                  ? existingProduct?.id
                  : null,
              },
              update: {
                vendor_id: vendor.id,
                integrated_vendor_id: existingVendor?.id
                  ? existingVendor?.id
                  : null,
                integration_provider: IntegrationProvider.Propexo,
                integrated_product_id: existingProduct?.id
                  ? existingProduct?.id
                  : null,
                last_verified_at: new Date(),
              },
            });
          }

          if (!existingRecord && (existingVendor || existingProduct)) {
            const data = existingVendor
              ? {
                  vendor_id: vendor.id,
                  integrated_vendor_id: existingVendor?.id,
                  integration_provider: IntegrationProvider.Propexo,
                }
              : {
                  vendor_id: vendor.id,
                  integrated_product_id: existingProduct?.id,
                  integration_provider: IntegrationProvider.Propexo,
                };
            await this.db.vendorIntegration.create({
              data,
            });
          }
        }
      }
      return {
        success: true,
        message: "Integration partners have been successfully synced",
      };
    } catch (e: any) {
      console.error(e);
      return {
        success: false,
        message: "An error occurred while syncing integration partners",
      };
    }
  }
}

function extractVendorName(nameWithInfo: string): string {
  const regex = /\s*\([^)]*\)\s*|\s+/g;
  const result = nameWithInfo.replace(regex, " ").trim();
  return result;
}

function mapVendorProductNames(name: string | undefined): string {
  if (!name) {
    return "";
  }
  switch (name) {
    case "RealPage AppPartner":
    case "RealPage Registered Vendor":
      return "RealPage";
    case "MRI":
      return "MRI Software";
    default:
      return name;
  }
}
