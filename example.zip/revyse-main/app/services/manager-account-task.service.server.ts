import type { IntelligenceNotificationService } from "./intelligence-notification.service.server";
import type {
  EmojiType,
  TaskContractRenewal,
  Prisma,
  PrismaClient,
  Contract,
  ManagerAccountVendor,
  ManagerAccount,
  ManagerAccountRole,
  TaskLocationDisposition,
} from "@prisma/client";
import {
  ContractStatus,
  TaskCompletionStatus,
  TaskScheduleStatus,
  IntelligenceNotificationType,
  LocationStatus,
} from "@prisma/client";
import type { ManagerAccountRoleService } from "./manager-account-role.service.server";
import { intersection } from "lodash";
import { TaskNamePrefixes, TaskType, orderTasks } from "../utils/tasks.utils";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import type { OrderByField } from "../utils/filtering.utils";
import type { PermissionUser } from "../utils/intelligence-permission.utils";
import {
  canDoOnAccount,
  Permission,
} from "../utils/intelligence-permission.utils";
dayjs.extend(utc);

export type TaskContract = Contract & {
  manager_account_vendor: ManagerAccountVendor & {
    manager_account: ManagerAccount & {
      manager_account_roles: ManagerAccountRole[];
    };
  } & {
    vendor: {
      name: string;
    };
  };
};

export type TasksFilters = {
  searchQuery?: string;
  schedule_status?: TaskScheduleStatus[];
  completion_status?: TaskCompletionStatus[];
  task_owner_id?: string;
  start_date?: [string | undefined, string | undefined];
  due_date?: [string | undefined, string | undefined];
  custom_status?: keyof typeof TaskCustomStatusFilterMapping;
};

const TaskCustomStatusFilterMapping = {
  active: {
    schedule_status: [TaskScheduleStatus.ReadyToDo, TaskScheduleStatus.Overdue],
    completion_status: [TaskCompletionStatus.Incomplete],
  },
  upcoming: {
    schedule_status: [TaskScheduleStatus.Upcoming],
    completion_status: [TaskCompletionStatus.Incomplete],
  },
  archived: {
    completion_status: [
      TaskCompletionStatus.Completed,
      TaskCompletionStatus.Canceled,
    ],
  },
};

export class ManagerAccountTaskService {
  constructor(
    private db: PrismaClient,
    private managerAccountRoleService: ManagerAccountRoleService,
    private intelligenceNotificationService: IntelligenceNotificationService
  ) {}

  /**
   * Create a new task of type `TaskContractRenewal`.
   * This function creates a new task for the contract renewal process.
   * @param contract contract that will be associated to the task
   * @param startDate date that will be used as the task start_date
   * @returns the created task
   */
  async createContractRenewalTask(
    contract: TaskContract,
    startDate: dayjs.Dayjs
  ) {
    // Create a new group_chat, this way the users will be able to send messages in a group_chat that will be associated to the task
    const task = await this.db.$transaction(async db => {
      const groupChat = await db.groupChat.create({});
      const task = await db.taskContractRenewal.create({
        data: {
          contract_id: contract.id,
          start_date: startDate.toDate(),
          due_date: contract.current_term_end_date,
          task_owner_id:
            contract.task_owner_id ??
            contract.manager_account_vendor.manager_account
              .manager_account_roles[0].id,
          group_chat_id: groupChat.id,
        },
        include: {
          task_owner: {
            include: {
              user: true,
            },
          },
        },
      });

      await this.intelligenceNotificationService.createNotification(
        task.task_owner_id,
        IntelligenceNotificationType.TaskScheduleStatusChange,
        {
          task_id: task.id,
          task_type: TaskType.TaskContractRenewal,
          new_status: TaskScheduleStatus.ReadyToDo,
        }
      );

      return task;
    });

    return task;
  }

  /**
   * Get the count of pending tasks for a user in a manager account.
   * Pending tasks are tasks that are incomplete and have a schedule status of ReadyToDo or Overdue.
   * @param managerAccountId manager account id
   * @param userId user id
   * @returns count of pending tasks
   */
  async getPendingTasksCount(managerAccountId: string, userId: string) {
    const managerAccountRole =
      await this.managerAccountRoleService.getManagerAccountRole({
        user_id: userId,
        manager_account_id: managerAccountId,
      });

    if (!managerAccountRole) {
      return 0;
    }

    const where = {
      task_owner_id: managerAccountRole.id,
      schedule_status: {
        in: [TaskScheduleStatus.ReadyToDo, TaskScheduleStatus.Overdue],
      },
      completion_status: TaskCompletionStatus.Incomplete,
    };

    const taskContractRenewalCount = await this.db.taskContractRenewal.count({
      where,
    });
    const taskLocationDispositionCount =
      await this.db.taskLocationDisposition.count({ where });

    return taskContractRenewalCount + taskLocationDispositionCount;
  }

  /**
   * Utility function to get the prisma query for tasks based on the `TasksFilters` and task type.
   * @param argFilters instance of `TasksFilters`
   * @param taskType task type
   * @returns prisma query for tasks depending on the task type
   */
  private getTasksFiltersQuery(argFilters?: TasksFilters, taskType?: TaskType) {
    let generalQueryFilters:
      | Prisma.TaskContractRenewalWhereInput
      | Prisma.TaskLocationDispositionWhereInput = {};

    if (!argFilters) return generalQueryFilters;

    const filters = { ...argFilters };

    if (filters.custom_status) {
      const customStatusFilters =
        TaskCustomStatusFilterMapping[filters.custom_status];
      if ("schedule_status" in customStatusFilters) {
        if (filters.schedule_status) {
          filters.schedule_status = intersection(
            customStatusFilters.schedule_status,
            filters.schedule_status
          );
        } else {
          filters.schedule_status = customStatusFilters.schedule_status;
        }
      }
      if ("completion_status" in customStatusFilters) {
        if (filters.completion_status) {
          filters.completion_status = intersection(
            customStatusFilters.completion_status,
            filters.completion_status
          );
        } else {
          filters.completion_status = customStatusFilters.completion_status;
        }
      }
    }

    if (taskType === TaskType.TaskContractRenewal) {
      const specificQueryFilters: Prisma.TaskContractRenewalWhereInput = {};

      if (filters.searchQuery) {
        specificQueryFilters.OR = [
          {
            contract: {
              name: { contains: filters.searchQuery, mode: "insensitive" },
            },
          },
          {
            contract: {
              manager_account_vendor: {
                vendor: {
                  name: { contains: filters.searchQuery, mode: "insensitive" },
                },
              },
            },
          },
        ];
      }

      generalQueryFilters = specificQueryFilters;
    } else if (taskType === TaskType.TaskLocationDisposition) {
      const specificQueryFilters: Prisma.TaskLocationDispositionWhereInput = {};

      if (filters.searchQuery) {
        specificQueryFilters.OR = [
          {
            location: {
              name: { contains: filters.searchQuery, mode: "insensitive" },
            },
          },
        ];
      }

      generalQueryFilters = specificQueryFilters;
    }

    if (taskType && filters.searchQuery) {
      const taskTypePrefix = TaskNamePrefixes[taskType].toLocaleLowerCase();
      const includesTaskTypePrefix = taskTypePrefix.includes(
        filters.searchQuery.toLocaleLowerCase()
      );

      if (includesTaskTypePrefix) {
        // Removing filters if search query includes task type prefix, so we return all tasks of this type
        generalQueryFilters.OR = undefined;
      }
    }

    if (filters.schedule_status) {
      generalQueryFilters.schedule_status = { in: filters.schedule_status };
    }

    if (filters.completion_status) {
      generalQueryFilters.completion_status = { in: filters.completion_status };
    }

    if (filters.task_owner_id) {
      generalQueryFilters.task_owner_id = filters.task_owner_id;
    }

    if (filters.start_date) {
      generalQueryFilters.start_date = {
        gte: filters.start_date[0]
          ? new Date(filters.start_date[0])
          : undefined,
        lte: filters.start_date[1]
          ? new Date(filters.start_date[1])
          : undefined,
      };
    }

    if (filters.due_date) {
      generalQueryFilters.due_date = {
        gte: filters.due_date[0] ? new Date(filters.due_date[0]) : undefined,
        lte: filters.due_date[1] ? new Date(filters.due_date[1]) : undefined,
      };
    }

    return generalQueryFilters;
  }

  /**
   * Get the tasks for a user in a manager account.
   * This function gets tasks of type `TaskContractRenewal` and `TaskLocationDisposition` and merges them.
   * @param user used to check permissions
   * @param managerAccount manager account used to filter tasks and check permissions
   * @param userId id of the user if the tasks are for a specific user
   * @param filters instance of `TasksFilters`
   * @param pagination Object with the page and perPage keys
   * @param orderBy List of objects with the order by keys and their direction
   * @returns tasks for a user in a manager account
   */
  async getTasks(
    user: PermissionUser,
    managerAccount: ManagerAccount,
    userId?: string,
    filters?: TasksFilters,
    pagination?: { page: number; perPage: number },
    orderBy?: OrderByField[]
  ) {
    const hideSensitiveContracts = !canDoOnAccount(
      user,
      managerAccount,
      Permission.ViewSensitiveContracts
    );

    const taskContractRenewals = await this.db.taskContractRenewal.findMany({
      where: {
        task_owner: {
          user_id: userId,
        },
        contract: {
          manager_account_vendor: {
            manager_account_id: managerAccount.id,
          },
          is_sensitive: hideSensitiveContracts ? false : undefined,
        },
        AND: [
          this.getTasksFiltersQuery(
            filters,
            TaskType.TaskContractRenewal
          ) as Prisma.TaskContractRenewalWhereInput,
        ],
      },
      include: {
        contract: true,
        task_owner: {
          include: {
            user: true,
          },
        },
        group_chat: {
          select: {
            _count: {
              select: {
                messages: true,
              },
            },
          },
        },
      },
    });

    const taskLocationDispositions =
      await this.db.taskLocationDisposition.findMany({
        where: {
          task_owner: {
            user_id: userId,
          },
          location: {
            manager_account_id: managerAccount.id,
          },
          AND: [
            this.getTasksFiltersQuery(
              filters,
              TaskType.TaskLocationDisposition
            ) as Prisma.TaskLocationDispositionWhereInput,
          ],
        },
        include: {
          location: true,
          task_owner: {
            include: {
              user: true,
            },
          },
          group_chat: {
            select: {
              _count: {
                select: {
                  messages: true,
                },
              },
            },
          },
        },
      });

    const mergedTasks = [...taskContractRenewals, ...taskLocationDispositions];

    orderTasks(mergedTasks, orderBy);

    if (pagination) {
      const paginatedResults = mergedTasks.slice(
        (pagination.page - 1) * pagination.perPage,
        pagination.page * pagination.perPage
      );

      return paginatedResults;
    }

    return mergedTasks;
  }

  /**
   * Get the count of tasks for a user in a manager account.
   * This function gets tasks of type `TaskContractRenewal` and `TaskLocationDisposition` and returns the count.
   * @param user user used to check permissions
   * @param managerAccount manager account used to filter tasks and check permissions
   * @param userId id of the user if the tasks are for a specific user
   * @param filters instance of `TasksFilters`
   * @returns count of tasks
   */
  async getTasksCount(
    user: PermissionUser,
    managerAccount: ManagerAccount,
    userId?: string,
    filters?: TasksFilters
  ) {
    const hideSensitiveContracts = !canDoOnAccount(
      user,
      managerAccount,
      Permission.ViewSensitiveContracts
    );

    const taskContractRenewalCount = await this.db.taskContractRenewal.count({
      where: {
        task_owner: {
          user_id: userId,
        },
        contract: {
          is_sensitive: hideSensitiveContracts ? false : undefined,
          manager_account_vendor: {
            manager_account_id: managerAccount.id,
          },
        },
        AND: [
          this.getTasksFiltersQuery(
            filters,
            TaskType.TaskContractRenewal
          ) as Prisma.TaskContractRenewalWhereInput,
        ],
      },
    });

    const taskLocationDispositionCount =
      await this.db.taskLocationDisposition.count({
        where: {
          task_owner: {
            user_id: userId,
          },
          location: {
            manager_account_id: managerAccount.id,
          },
          AND: [
            this.getTasksFiltersQuery(
              filters,
              TaskType.TaskLocationDisposition
            ) as Prisma.TaskLocationDispositionWhereInput,
          ],
        },
      });

    return taskContractRenewalCount + taskLocationDispositionCount;
  }

  /**
   * Get a task of type `TaskContractRenewal`.
   * This function gets a task of type `TaskContractRenewal` and returns it.
   * @param id the task id
   * @returns a task of type `TaskContractRenewal`
   */
  async loadContractRenewalTask(id: string | undefined) {
    const task = await this.db.taskContractRenewal.findFirst({
      where: {
        id: id,
      },
      include: {
        contract: {
          include: {
            task_owner: {
              include: {
                user: true,
              },
            },
            contract_line_items: {
              include: {
                contract_line_item_locations: true,
                contract_line_item_fees: {
                  include: {
                    fee: {
                      include: {
                        category: true,
                      },
                    },
                  },
                },
                contract_line_item_products: {
                  include: {
                    product: {
                      include: {
                        primary_category: true,
                      },
                    },
                  },
                },
              },
            },
            manager_account_vendor: {
              include: {
                vendor: true,
                manager_account_vendor_contacts: true,
              },
            },
          },
        },
        task_owner: {
          include: {
            user: true,
          },
        },
      },
    });
    return task;
  }

  /**
   * Get a task of type `TaskLocationDisposition`.
   * This function gets a task of type `TaskLocationDisposition` and returns it.
   * @param id the task id
   * @returns a task of type `TaskLocationDisposition`
   */
  async loadLocationDispositionTask(id: string | undefined) {
    const task = await this.db.taskLocationDisposition.findFirst({
      where: {
        id: id,
      },
      include: {
        location: true,
        task_owner: {
          include: {
            user: true,
          },
        },
      },
    });
    return task;
  }

  /**
   * Archive a task of type `TaskContractRenewal` in a manager account.
   * This function updates the completion status of a task of type `TaskContractRenewal` and sets it to Canceled.
   * @param taskId the contract renewal task id
   */
  async archiveContractRenewalTask(taskId: string) {
    await this.db.taskContractRenewal.update({
      where: {
        id: taskId,
      },
      data: {
        completion_status: TaskCompletionStatus.Canceled,
        schedule_status: TaskScheduleStatus.Archived,
      },
    });
  }

  /**
   * Archive a task of type `LocationDispositionTask` in a manager account.
   * This function updates the completion status of a task of type `LocationDispositionTask` and sets it to Canceled.
   * @param taskId the contract renewal task id
   */
  async archiveLocationDispositionTask(taskId: string) {
    await this.db.taskLocationDisposition.update({
      where: {
        id: taskId,
      },
      data: {
        completion_status: TaskCompletionStatus.Canceled,
        schedule_status: TaskScheduleStatus.Archived,
      },
    });
  }

  /**
   * Activate a task of type `TaskContractRenewal` in a manager account.
   * This function updates the completion status of a task of type `TaskContractRenewal` and sets it to Incomplete.
   * Also, it changes the task schedule status back to either Ready to Do or Overdue, depending on the Task Due Date.
   * @param taskId the contract renewal task id
   */
  async activateContractRenewalTask(taskId: string) {
    const task = await this.db.taskContractRenewal.findUnique({
      select: {
        due_date: true,
      },
      where: {
        id: taskId,
      },
    });

    // Change the task completion status back to either Ready to Do or Overdue, depending on the Task Due Date.
    const scheduleStatus =
      task?.due_date && task.due_date > new Date()
        ? TaskScheduleStatus.ReadyToDo
        : TaskScheduleStatus.Overdue;

    await this.db.taskContractRenewal.update({
      where: {
        id: taskId,
      },
      data: {
        completion_status: TaskCompletionStatus.Incomplete,
        schedule_status: scheduleStatus,
      },
    });
  }

  /**
   * Activate a task of type `TaskLocationDisposition` in a manager account.
   * This function updates the completion status of a task of type `TaskLocationDisposition` and sets it to Incomplete.
   * Also, it changes the task schedule status back to either Ready to Do or Overdue, depending on the Task Due Date.
   * @param taskId the contract renewal task id
   */
  async activateLocationDispositionTask(taskId: string) {
    const task = await this.db.taskLocationDisposition.findUnique({
      select: {
        due_date: true,
      },
      where: {
        id: taskId,
      },
    });

    // Change the task completion status back to either Ready to Do or Overdue, depending on the Task Due Date.
    const scheduleStatus =
      task?.due_date && task.due_date > new Date()
        ? TaskScheduleStatus.ReadyToDo
        : TaskScheduleStatus.Overdue;

    await this.db.taskLocationDisposition.update({
      where: {
        id: taskId,
      },
      data: {
        completion_status: TaskCompletionStatus.Incomplete,
        schedule_status: scheduleStatus,
      },
    });
  }

  /**
   * Update a task of type `TaskContractRenewal`.
   * This function updates the due_date and task_owner_id of task of type `TaskContractRenewal` and returns it.
   * @param taskId the task id
   * @param newDueDate the new due date
   * @param newTaskOwnerId the id of the new task owner
   */
  async updateContractRenewalTask(
    taskId: string,
    newDueDate: Date | null,
    newTaskOwnerId: string | null
  ) {
    const taskContractRenewal = await this.db.taskContractRenewal.findUnique({
      where: {
        id: taskId,
      },
    });
    const isOverDue =
      taskContractRenewal?.schedule_status === TaskScheduleStatus.Overdue;
    const isNewDueDateInFuture = newDueDate ? newDueDate > new Date() : false;

    const data =
      isOverDue && isNewDueDateInFuture
        ? {
            due_date: newDueDate,
            schedule_status: TaskScheduleStatus.ReadyToDo,
            task_owner: newTaskOwnerId
              ? {
                  connect: {
                    id: newTaskOwnerId,
                  },
                }
              : undefined,
          }
        : {
            due_date: newDueDate,
            task_owner: newTaskOwnerId
              ? {
                  connect: {
                    id: newTaskOwnerId,
                  },
                }
              : undefined,
          };
    return this.db.taskContractRenewal.update({
      where: {
        id: taskId,
      },
      data,
    });
  }

  /**
   * Update a task of type `TaskLocationDisposition`.
   * This function updates the due_date and task_owner_id of task of type `TaskLocationDisposition` and returns it.
   * @param taskId the task id
   * @param newDueDate the new due date
   * @param newTaskOwnerId the id of the new task owner
   */
  async updateLocationDispositionTask(
    taskId: string,
    newDueDate: Date | null,
    newTaskOwnerId: string | null
  ) {
    const taskLocationDisposition =
      await this.db.taskLocationDisposition.findUnique({
        where: {
          id: taskId,
        },
      });
    const isOverDue =
      taskLocationDisposition?.schedule_status === TaskScheduleStatus.Overdue;
    const isNewDueDateInFuture = newDueDate ? newDueDate > new Date() : false;

    const data =
      isOverDue && isNewDueDateInFuture
        ? {
            due_date: newDueDate,
            schedule_status: TaskScheduleStatus.ReadyToDo,
            task_owner: newTaskOwnerId
              ? {
                  connect: {
                    id: newTaskOwnerId,
                  },
                }
              : undefined,
          }
        : {
            due_date: newDueDate,
            task_owner: newTaskOwnerId
              ? {
                  connect: {
                    id: newTaskOwnerId,
                  },
                }
              : undefined,
          };
    return this.db.taskLocationDisposition.update({
      where: {
        id: taskId,
      },
      data,
    });
  }

  async handleWizardContractRenewalTaskRenewed({
    task,
    fields,
  }: {
    task: TaskContractRenewal;
    fields: {
      current_term_end_date?: Date | null;
      contract_file?: string | null;
      contract_file_name?: string | null;
      renewal_reminder_date?: Date | null;
      renewal_reminder_lead_time_months?: number | null;
      task_owner_id?: string | null;
    };
  }) {
    const {
      current_term_end_date,
      contract_file,
      contract_file_name,
      renewal_reminder_date,
      renewal_reminder_lead_time_months,
      task_owner_id,
    } = fields;

    this.db.$transaction(async db => {
      const contract = await db.contract.update({
        where: { id: task.contract_id },
        data: {
          status: ContractStatus.Active,
          current_term_end_date,
          renewal_reminder_date: renewal_reminder_date ?? undefined,
          renewal_reminder_lead_time_months:
            renewal_reminder_lead_time_months ?? undefined,
          task_owner_id: task_owner_id ?? undefined,
        },
      });

      if (contract_file && contract_file !== "--") {
        await db.contractFile.create({
          data: {
            contract_id: contract.id,
            name: contract_file_name || "",
            file_id: contract_file as string,
          },
        });
      }

      await db.taskContractRenewal.update({
        where: { id: task.id },
        data: {
          completion_status: TaskCompletionStatus.Completed,
          schedule_status: TaskScheduleStatus.Archived,
        },
      });

      await this.intelligenceNotificationService.createNotification(
        task.task_owner_id, // who should receive the notification
        IntelligenceNotificationType.TaskCompletionStatusChange, // what type of notification
        {
          // metadata (specific to each notification type)
          task_id: task.id,
          task_type: TaskType.TaskContractRenewal,
          new_status: TaskCompletionStatus.Completed,
        }
      );
    });
  }

  async handleWizardContractRenewalTaskPending({
    task,
    fields,
  }: {
    task: TaskContractRenewal;
    fields: {
      due_date: Date | null;
    };
  }) {
    this.db.$transaction(async db => {
      const { due_date } = fields;

      await db.taskContractRenewal.update({
        where: { id: task.id },
        data: {
          due_date,
        },
      });

      await this.intelligenceNotificationService.createNotification(
        task.task_owner_id,
        IntelligenceNotificationType.TaskDueDateChange,
        {
          task_id: task.id,
          task_type: TaskType.TaskContractRenewal,
          new_due_date: due_date?.toISOString() ?? "",
        }
      );
    });
  }

  async handleWizardContractRenewalTaskCanceled({
    task,
  }: {
    task: TaskContractRenewal;
  }) {
    this.db.$transaction(async db => {
      await db.contract.update({
        where: { id: task.contract_id },
        data: {
          status: ContractStatus.Canceled,
        },
      });

      await db.taskContractRenewal.update({
        where: { id: task.id },
        data: {
          completion_status: TaskCompletionStatus.Completed,
          schedule_status: TaskScheduleStatus.Archived,
        },
      });

      await this.intelligenceNotificationService.createNotification(
        task.task_owner_id,
        IntelligenceNotificationType.TaskCompletionStatusChange,
        {
          task_id: task.id,
          task_type: TaskType.TaskContractRenewal,
          new_status: TaskCompletionStatus.Completed,
        }
      );
    });
  }

  async updateContractRenewalTaskScheduleStatuses() {
    const contractRenewalTasks = await this.db.taskContractRenewal.findMany({
      where: {
        due_date: {
          lte: new Date(),
        },
      },
    });

    for (const task of contractRenewalTasks) {
      if (task.schedule_status !== TaskScheduleStatus.Overdue) {
        await this.db.$transaction(async db => {
          await db.taskContractRenewal.update({
            where: {
              id: task.id,
            },
            data: {
              schedule_status: TaskScheduleStatus.Overdue,
            },
          });

          await this.intelligenceNotificationService.createNotification(
            task.task_owner_id,
            IntelligenceNotificationType.TaskScheduleStatusChange,
            {
              task_id: task.id,
              task_type: TaskType.TaskContractRenewal,
              new_status: TaskScheduleStatus.Overdue,
            }
          );
        });
      }
    }
  }

  async isTaskOwner(userRoleId: string | undefined) {
    return (await this.db.taskContractRenewal.count({
      where: {
        task_owner_id: userRoleId,
        completion_status: TaskCompletionStatus.Incomplete,
      },
    })) +
      (await this.db.taskLocationDisposition.count({
        where: {
          task_owner_id: userRoleId,
          completion_status: TaskCompletionStatus.Incomplete,
        },
      })) >
      0
      ? true
      : false;
  }

  async reassignUserTasks(taskOwnerId: string, newTaskOwnerId: string) {
    await this.db.taskContractRenewal.updateMany({
      where: {
        task_owner_id: taskOwnerId,
      },
      data: {
        task_owner_id: newTaskOwnerId,
      },
    });

    await this.db.taskLocationDisposition.updateMany({
      where: {
        task_owner_id: taskOwnerId,
      },
      data: {
        task_owner_id: newTaskOwnerId,
      },
    });
  }

  async getGroupChatMessages(groupChatId: string) {
    return this.db.message.findMany({
      where: {
        group_chat_id: groupChatId,
      },
      include: {
        sender: {
          include: {
            user: true,
          },
        },
        reactions: {
          include: {
            sender: {
              include: {
                user: true,
              },
            },
          },
        },
        message_files: {
          include: {
            file: true,
          },
        },
      },
    });
  }

  async sendTaskMessage(
    senderId: string,
    content: string,
    groupId: string,
    mentionedUsers?: string[] | undefined,
    messageFiles?: {
      file: string;
    }[]
  ) {
    const data = mentionedUsers
      ? {
          sender_id: senderId,
          content: content,
          group_chat_id: groupId,
          mentioned_users: {
            connect: mentionedUsers.map(id => ({ id })),
          },
        }
      : {
          sender_id: senderId,
          content: content,
          group_chat_id: groupId,
        };

    const message = await this.db.$transaction(async db => {
      const message = await db.message.create({
        data,
        include: {
          group_chat: {
            include: {
              task_contract_renewal: true,
              task_location_disposition: true,
            },
          },
        },
      });

      if (messageFiles) {
        for (const file of messageFiles) {
          await db.messageFile.create({
            data: {
              message_id: message.id,
              file_id: file.file,
            },
          });
        }
      }
      const task =
        message.group_chat.task_contract_renewal.at(0) ??
        message.group_chat.task_location_disposition.at(0) ??
        null;
      const taskType = message.group_chat.task_contract_renewal
        ? TaskType.TaskContractRenewal
        : TaskType.TaskLocationDisposition;

      if (task) {
        // Send notification to mentioned users
        if (mentionedUsers) {
          await Promise.all(
            mentionedUsers.map(async managerAccountRoleId => {
              return this.intelligenceNotificationService.createNotification(
                managerAccountRoleId,
                IntelligenceNotificationType.TaskMessageMention,
                {
                  task_id: task.id,
                  task_type: taskType,
                  message_id: message.id,
                  sender_id: senderId,
                }
              );
            })
          );
        }

        // Send notification to task owner if the sender is not the task owner
        if (senderId !== task.task_owner_id) {
          const todayNotification =
            await this.db.intelligenceNotification.findFirst({
              where: {
                type: IntelligenceNotificationType.TaskMessageOwner,
                created_at: {
                  gte: dayjs().startOf("day").toDate(),
                  lte: dayjs().endOf("day").toDate(),
                },
                metadata: {
                  path: ["task_id"],
                  equals: task.id,
                },
              },
            });

          // If there is no notification for today, create one
          if (!todayNotification) {
            await this.intelligenceNotificationService.createNotification(
              task.task_owner_id,
              IntelligenceNotificationType.TaskMessageOwner,
              {
                task_id: task.id,
                task_type: taskType,
                message_id: message.id,
                sender_id: senderId,
              }
            );
          }
        }
      }

      return message;
    });

    return message;
  }

  async reactTaskMessage(messageId: string, type: EmojiType, senderId: string) {
    const existingReaction = await this.db.reaction.findFirst({
      where: {
        message_id: messageId,
        sender_id: senderId,
        type: type,
      },
    });

    if (!existingReaction) {
      await this.db.reaction.create({
        data: {
          message: {
            connect: {
              id: messageId,
            },
          },
          type: type,
          sender: {
            connect: {
              id: senderId,
            },
          },
        },
      });
    } else {
      await this.db.reaction.delete({
        where: {
          id: existingReaction.id,
        },
      });
    }
  }

  async handleWizardLocationDispositionTaskDisposed({
    task,
  }: {
    task: TaskLocationDisposition;
  }) {
    await this.db.$transaction(async tx => {
      await tx.taskLocationDisposition.update({
        where: { id: task.id },
        data: {
          completion_status: TaskCompletionStatus.Completed,
          schedule_status: TaskScheduleStatus.Archived,
        },
      });

      await this.intelligenceNotificationService.createNotification(
        task.task_owner_id,
        IntelligenceNotificationType.TaskCompletionStatusChange,
        {
          task_id: task.id,
          task_type: TaskType.TaskLocationDisposition,
          new_status: TaskCompletionStatus.Completed,
        }
      );

      await tx.location.update({
        where: { id: task.location_id },
        data: {
          status: LocationStatus.Disposed,
        },
      });
    });
  }

  async handleWizardLocationDispositionTaskPending({
    task,
    fields,
  }: {
    task: TaskLocationDisposition;
    fields: {
      due_date: Date | null;
    };
  }) {
    const { due_date } = fields;

    await this.db.taskLocationDisposition.update({
      where: { id: task.id },
      data: {
        due_date,
      },
    });

    await this.intelligenceNotificationService.createNotification(
      task.task_owner_id,
      IntelligenceNotificationType.TaskDueDateChange,
      {
        task_id: task.id,
        task_type: TaskType.TaskLocationDisposition,
        new_due_date: due_date?.toISOString() ?? "",
      }
    );
  }

  async handleWizardLocationDispositionTaskKeep({
    task,
  }: {
    task: TaskLocationDisposition;
  }) {
    await this.db.$transaction(async tx => {
      await tx.taskLocationDisposition.update({
        where: { id: task.id },
        data: {
          completion_status: TaskCompletionStatus.Completed,
          schedule_status: TaskScheduleStatus.Archived,
        },
      });

      await this.intelligenceNotificationService.createNotification(
        task.task_owner_id,
        IntelligenceNotificationType.TaskCompletionStatusChange,
        {
          task_id: task.id,
          task_type: TaskType.TaskLocationDisposition,
          new_status: TaskCompletionStatus.Completed,
        }
      );
    });
  }
}
