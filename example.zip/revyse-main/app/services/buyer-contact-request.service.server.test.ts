import { ProductState, Role, UserRoleType } from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const category = await tx.productCategory.create({
      data: {
        name: faker.company.name(),
        description: "description",
        slug: "category",
        faq_1: "faq 1",
        faq_2: "faq 2",
        faq_3: "faq 3",
        faq_1_answer: "faq 1 answer",
        faq_2_answer: "faq 2 answer",
        faq_3_answer: "faq 3 answer",
        meta_description: "meta description",
        page_title: "page title",
      },
    });

    const productWithSubscription = await tx.product.create({
      data: {
        title: "Buyer Contact Request Test With Subscription",
        description: "description",
        state: ProductState.discovery,
        approved_at: new Date(),
        slug: "buyer-contact-request-test-with-subscription",
        page_title: "page title",
        positioning: "positioning",
        meta_description: "meta description",
        primary_category: {
          connect: {
            id: category.id,
          },
        },
        subscriptions: {
          create: {
            stripe_id: "sub_123",
            status: "active",
            stripe_price: {
              create: {
                id: "price_123",
                price: 1000,
                cadence: "monthly",
                active: true,
                product: {
                  create: {
                    id: "prod_123",
                    name: "stripe test product",
                    description: "description",
                  },
                },
              },
            },
          },
        },
      },
      include: {
        subscriptions: {
          include: {
            stripe_price: true,
          },
        },
      },
    });

    const product = await tx.product.create({
      data: {
        title: "Buyer Contact Request Test",
        description: "description",
        state: ProductState.discovery,
        approved_at: new Date(),
        slug: "buyer-contact-request-test",
        page_title: "page title",
        positioning: "positioning",
        meta_description: "meta description",
        primary_category: {
          connect: {
            id: category.id,
          },
        },
      },
    });

    const buyerUser = await tx.user.create({
      data: {
        email: faker.internet.email(),
        first_name: "first",
        last_name: "last",
        company_name: "company",
        phone: "phone",
        title: "title",
        user_roles: {
          create: {
            type: UserRoleType.GLOBAL,
            role: Role.BUYER,
          },
        },
      },
    });

    const ownerUser = await tx.user.create({
      data: {
        email: "invalid@email.email",
        first_name: "first",
        last_name: "last",
        company_name: "company",
        phone: "phone",
        title: "title",
        user_roles: {
          create: {
            type: UserRoleType.PRODUCT_SUBSCRIPTION,
            role: Role.OWNER,
            resource_id: productWithSubscription.subscriptions[0].id,
          },
        },
      },
    });

    return {
      category,
      productWithSubscription,
      product,
      buyerUser,
      ownerUser,
    };
  },
});

describe("BuyerContactRequest", () => {
  describe("createRequest", () => {
    test(
      "buyer create request",
      withFixtures(async ({ buyerUser, productWithSubscription }, tx) => {
        const { buyerContactRequestService } = TestDIContainer(tx);
        const request = await buyerContactRequestService.createRequest(
          buyerUser,
          productWithSubscription.id,
          "description"
        );
        expect(request).not.toBeNull();
        expect(request.description).toBe("description");
      })
    );

    test(
      "error if no active subscription",
      withFixtures(async ({ buyerUser, product }, tx) => {
        const { buyerContactRequestService } = TestDIContainer(tx);
        await expect(
          buyerContactRequestService.createRequest(
            buyerUser,
            product.id,
            "description"
          )
        ).rejects.toThrow("No active subscription found for this product");
      })
    );

    test(
      "request with test prefix to owner",
      withFixtures(async ({ productWithSubscription, ownerUser }, tx) => {
        const { buyerContactRequestService } = TestDIContainer(tx);
        const request = await buyerContactRequestService.createRequest(
          ownerUser,
          productWithSubscription.id,
          "description",
          true
        );
        expect(request).not.toBeNull();
        expect(request.description).toBe("[TEST] description");
      })
    );
  });
});
