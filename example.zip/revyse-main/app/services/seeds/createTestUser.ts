import type { User } from "@prisma/client";
import { SignUpIntent } from "@prisma/client";
import type { AuthService } from "../auth.service.server";

export async function createTestUser(email: string, authService: AuthService) {
  let user: User;

  const params = {
    email: email,
    password: "beepboop",
    first_name: "Test",
    last_name: "User",
    company_name: "company",
    phone: "phone",
    title: "title",
    intent: SignUpIntent.ORGANIC,
  };
  const result = await authService.register(params, false);
  if (!result.ok) {
    throw result;
  }
  user = result.value;
  return user;
}
