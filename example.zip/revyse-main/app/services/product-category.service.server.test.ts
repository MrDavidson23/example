import { Prisma, ProductState } from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { slugify } from "../utils/string.utils";
import { withTx } from "./db.server";
import { faker } from "@faker-js/faker";

const generateCategory = (name: string) => ({
  name: `${name} ${faker.lorem.words(1)}`,
  description: "description",
  faq_1: "faq 1",
  faq_2: "faq 2",
  faq_3: "faq 3",
  faq_1_answer: "faq 1 answer",
  faq_2_answer: "faq 2 answer",
  faq_3_answer: "faq 3 answer",
  meta_description: "meta description",
  page_title: "page title",
});

const CATS = [
  generateCategory("Smart Home"),
  generateCategory("Business Consultants"),
  generateCategory("Category 3"),
];

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const categories = await Promise.all(
      CATS.map(c =>
        tx.productCategory.create({
          data: { ...c, highlighted: false, slug: slugify(c.name) },
          include: {
            primary_products: true,
          },
        })
      )
    );

    const products = await tx.product.createMany({
      data: [
        {
          title: "Product for Smart Home",
          description: "description",
          state: ProductState.discovery,
          approved_at: new Date(),
          slug: "product-for-smart-home",
          page_title: "page title",
          positioning: "positioning",
          meta_description: "meta description",
          primary_category_id: categories[0].id,
        },
        {
          title: "Product for Business Consultants",
          description: "description",
          state: ProductState.discovery,
          approved_at: new Date(),
          slug: "product-for-business-consultants",
          page_title: "page title",
          positioning: "positioning",
          meta_description: "meta description",
          primary_category_id: categories[1].id,
        },
      ],
    });

    return {
      categories,
      products,
    };
  },
});

describe("ProductCategory Service", () => {
  describe("getAllCategories", () => {
    test(
      "should return all existing categories",
      withFixtures(async ({ categories }, tx) => {
        const { productCategoryService } = TestDIContainer(tx);
        const testCategories = await productCategoryService.getAllCategories();
        expect(testCategories).not.toBeNull();

        expect(testCategories.map(category => category.name)).toEqual(
          expect.arrayContaining([categories[0].name])
        );
        expect(testCategories.map(category => category.name)).toEqual(
          expect.arrayContaining([categories[1].name])
        );
        expect(testCategories.map(category => category.name)).toEqual(
          expect.arrayContaining([categories[2].name])
        );
      })
    );
  });

  describe("getPopularCategories", () => {
    test(
      "should return 3 popular categories",
      withTx(async tx => {
        const { productCategoryService } = TestDIContainer(tx);
        const popularCategories =
          await productCategoryService.getPopularCategories();

        expect(popularCategories.services).not.toBeNull();
        expect(popularCategories.technology).not.toBeNull();
        expect(popularCategories.suppliers).toHaveLength(0);
      })
    );
  });

  describe("getCategory", () => {
    test(
      "should return single category by slug",
      withFixtures(async ({ categories }, tx) => {
        const { productCategoryService } = TestDIContainer(tx);
        const testCategory = await productCategoryService.getCategory({
          slug: categories[2].slug,
        });

        expect(testCategory).not.toBeNull();
      })
    );
  });

  describe("getCategoryProducts", () => {
    test(
      "should return category products with ratings",
      withFixtures(async ({ categories }, tx) => {
        const { productCategoryService } = TestDIContainer(tx);

        const categoryProducts =
          await productCategoryService.getCategoryProducts(categories[1].id);
        expect(categoryProducts).not.toBeNull();
        expect(categoryProducts).toHaveLength(
          categories[1].primary_products.length
        );
      })
    );
  });

  describe("updateCategory", () => {
    test(
      "should update category",
      withFixtures(async ({ categories }, tx) => {
        const { productCategoryService } = TestDIContainer(tx);
        const newCategoryName = faker.lorem.words(3);
        const testCategory = await productCategoryService.updateCategory(
          categories[0].id,
          { name: newCategoryName }
        );

        expect(testCategory).not.toBeNull();
        expect(testCategory.name).toEqual(newCategoryName);
      })
    );

    test(
      "should throw error if category is not found",
      withFixtures(async ({ categories }, tx) => {
        const { productCategoryService } = TestDIContainer(tx);

        await expect(
          productCategoryService.updateCategory(faker.string.uuid(), {
            name: "New Name",
          })
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError);
      })
    );
  });

  describe("createCategory", () => {
    test(
      "should create a new product category",
      withTx(async tx => {
        const { productCategoryService } = TestDIContainer(tx);
        const newCategoryName = faker.lorem.words(3);

        const testCategory = await productCategoryService.createCategory({
          name: newCategoryName,
          description: faker.lorem.paragraph(),
          highlighted: false,
          slug: slugify(newCategoryName),
          faq_1: faker.lorem.paragraph(),
          faq_1_answer: faker.lorem.paragraph(),
          faq_2: faker.lorem.paragraph(),
          faq_2_answer: faker.lorem.paragraph(),
          faq_3: faker.lorem.paragraph(),
          faq_3_answer: faker.lorem.paragraph(),
          meta_description: faker.lorem.paragraph(),
          page_title: newCategoryName,
        });

        expect(testCategory).not.toBeNull();
        expect(testCategory.name).toEqual(newCategoryName);
      })
    );
  });
  describe("deleteCategory", () => {
    test(
      "should delete category",
      withFixtures(async ({ categories }, tx) => {
        const { productCategoryService } = TestDIContainer(tx);
        await productCategoryService.deleteCategory(categories[2].id);

        await expect(
          productCategoryService.getCategory({ id: categories[2].id })
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError);
      })
    );

    test(
      "should throw error if category has products",
      withFixtures(async ({ categories }, tx) => {
        const { productCategoryService } = TestDIContainer(tx);

        await expect(
          productCategoryService.deleteCategory(categories[1].id)
        ).rejects.toThrowError("Category has products");
      })
    );

    test(
      "should throw error if category is not found",
      withFixtures(async ({ categories }, tx) => {
        const { productCategoryService } = TestDIContainer(tx);

        await expect(
          productCategoryService.deleteCategory(faker.string.uuid())
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError);
      })
    );
  });

  describe("getCategoriesForProducts", () => {
    test(
      "should return categories for products with categories",
      withFixtures(async ({ categories }, tx) => {
        const { productCategoryService } = TestDIContainer(tx);

        const testCategories =
          await productCategoryService.getCategoriesForProducts({
            search: categories[0].name,
            products: [
              {
                primary_category_id: categories[1].id,
                secondary_category_id: null,
                tertiary_category_id: null,
              },
            ],
          });

        expect(testCategories).not.toBeNull();
        expect(testCategories).toHaveLength(2);
        expect(testCategories).toEqual(
          expect.arrayContaining([
            expect.objectContaining({ name: categories[0].name }),
            expect.objectContaining({ name: categories[1].name }),
          ])
        );

        expect(testCategories).not.toEqual(
          expect.arrayContaining([
            expect.objectContaining({ name: categories[2].name }),
          ])
        );
      })
    );
  });
});
