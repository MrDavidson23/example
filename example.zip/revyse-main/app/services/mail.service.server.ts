import type { Transporter } from "nodemailer";
import { createTransport } from "nodemailer";
import { getEnv } from "./env.service.server";
import type SMTPTransport from "nodemailer/lib/smtp-transport";
import type Mail from "nodemailer/lib/mailer";

const env = getEnv();
const SMTP_FROM = env.SMTP_FROM;
const SMTP_HOST = env.SMTP_HOST;
const SMTP_PORT = env.SMTP_PORT;
const SMTP_USER = env.SMTP_USER;
const SMTP_PASS = env.SMTP_PASS;
const SMTP_USE_TLS = env.SMTP_USE_TLS;
const CI = !!process.env.CI;

export type EmailBodyParam = {
  id: string;
  value: string;
};

export type SendEmailParams = {
  subject: string;
  from?: string;
  to: Array<string>;
  cc?: Array<string>;
  bcc?: Array<string>;
  body: string;
  attachments?: Mail.Attachment[];
  replyTo?: string;
};

export interface IMailService {
  send({ subject, from, to, cc, bcc, body }: SendEmailParams): Promise<any>;
}

export class MailService implements IMailService {
  private transport!: Transporter<SMTPTransport.SentMessageInfo>;
  constructor() {
    if (CI) {
      return;
    }
    this.transport = createTransport({
      host: SMTP_HOST,
      port: SMTP_PORT,
      auth: {
        user: SMTP_USER,
        pass: SMTP_PASS,
      },
      secure: SMTP_USE_TLS,
    });
  }

  async send(params: SendEmailParams): Promise<any> {
    const { subject, to, cc, bcc, body } = params;
    return new Promise((res, rej) => {
      if (!to || to.length === 0) {
        rej("Invalid to address(es)");
        return;
      }

      if (CI) {
        res("CI mode, not sending email");
        return;
      }

      this.transport.sendMail(
        {
          from: params.from ?? SMTP_FROM,
          to,
          cc,
          bcc,
          subject,
          html: body,
          replyTo: params.replyTo ?? "support@revyse.com",
          headers: {
            "X-SES-CONFIGURATION-SET": "Default",
            "X-SES-MESSAGE-TAGS": "type=any",
          },
          attachments: params.attachments ?? [],
        },
        (err, info) => {
          if (err) {
            rej(err);
          } else {
            res(info);
          }
        }
      );
    });
  }
}

export class MockMailService implements IMailService {
  async send({
    subject,
    from,
    to,
    cc,
    bcc,
    body,
  }: SendEmailParams): Promise<any> {}
}
