import type { TypedResponse } from "@remix-run/node";
import { json } from "@remix-run/node";
import type { PrismaClient, User } from "@prisma/client";
import * as crypto from "crypto";
interface UserInfo {
  id: number;
  name: string;
  email: string;
}

export type ISSOService = {
  generateAuthCode(
    response_type: string | null,
    client_id: string,
    redirect_uri: string,
    scope: string | null,
    user: User
  ): Promise<TypedResponse>;
  generateAccessToken(
    client_id?: string,
    client_secret?: string,
    grant_type?: string,
    code?: string,
    redirect_uri?: string
  ): Promise<TypedResponse>;
  getUserInfo(access_token: string): Promise<TypedResponse>;
};

export class SSOService implements ISSOService {
  constructor(private db: PrismaClient) {}

  async generateAuthCode(
    response_type: string,
    client_id: string,
    redirect_uri: string,
    scope: string,
    user: User
  ): Promise<TypedResponse> {
    if (response_type !== "code") {
      return json({ error: "Invalid response type" }, { status: 400 });
    }

    const client = await this.db.oAuthClient.findUnique({
      where: { client_id },
    });
    if (!client || client.disabled_at) {
      return json({ error: "Invalid client" }, { status: 400 });
    }

    if (client.redirect_uri !== redirect_uri) {
      return json({ error: "Redirect URI doesn't match" }, { status: 400 });
    }

    if (scope !== "read") {
      return json({ error: "Invalid scope" }, { status: 400 });
    }

    const authCode = crypto
      .randomBytes(16)
      .toString("base64")
      .replace(/\+/g, "_"); // Circle seems not to like + characters in the auth code

    const expires_at = new Date();
    expires_at.setMinutes(expires_at.getMinutes() + 20);

    const oauthCode = await this.db.oAuthCode.create({
      data: {
        code: authCode,
        user_id: user.id,
        redirect_uri,
        client_id,
        expires_at,
      },
    });

    return json({ oauthCode: oauthCode }, { status: 200 });
  }

  async generateAccessToken(
    client_id: string,
    client_secret: string,
    grant_type: string,
    code: string,
    redirect_uri: string
  ): Promise<TypedResponse> {
    if (grant_type !== "authorization_code") {
      return json({ error: "Invalid grant type" }, { status: 400 });
    }

    const client = await this.db.oAuthClient.findUnique({
      where: { client_id },
    });
    if (!client || client.client_secret !== client_secret) {
      return json({ error: "Invalid client credentials" }, { status: 400 });
    }

    const oauthCode = await this.db.oAuthCode.findUnique({ where: { code } });
    if (!oauthCode || oauthCode.used_at) {
      return json({ error: "Invalid authorization code" }, { status: 400 });
    }

    if (oauthCode.redirect_uri !== redirect_uri) {
      return json({ error: "Redirect URI does not match" }, { status: 400 });
    }

    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + 30);

    const accessToken = crypto.randomBytes(32).toString("base64");

    const oauthToken = await this.db.oAuthToken.create({
      data: {
        token: accessToken,
        code: oauthCode.code,
        expires_at: expiresAt,
      },
    });

    await this.db.oAuthCode.update({
      where: { code },
      data: { used_at: new Date() },
    });

    const response = await this.getUserInfo(oauthToken.token);
    const user = (await response.json()) as UserInfo;

    return json(
      {
        access_token: oauthToken.token,
        token_type: "bearer",
        expires_in: oauthToken.expires_at,
        scope: "read",
        uid: user.id,
        info: {
          name: user.name,
          email: user.email,
        },
      },
      { status: 200 }
    );
  }

  async getUserInfo(access_token: string): Promise<TypedResponse> {
    if (!access_token) {
      return json({ error: "Access token missing" }, { status: 401 });
    }

    const oauthToken = await this.db.oAuthToken.findFirst({
      where: {
        token: access_token,
        expires_at: {
          gte: new Date(),
        },
      },
      include: {
        oauth_code: {
          include: {
            user: true,
          },
        },
      },
    });

    if (!oauthToken) {
      return json(
        { error: "Invalid or expired access token" },
        { status: 401 }
      );
    }

    const user = oauthToken.oauth_code.user;

    return json({
      user: {
        id: user.id,
        email: user.email,
        name: `${user.first_name} ${user.last_name}`,
      },
    });
  }
}
