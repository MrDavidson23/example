import type { PrismaClient } from "@prisma/client";
import type { MockS3Service } from "./s3.service.server";
import type { Readable } from "stream";

export class FileService {
  constructor(private db: PrismaClient, private s3Service: MockS3Service) {}

  async deleteFile(fileId: string) {
    return await this.db.$transaction(async tx => {
      const file = await tx.file.findFirstOrThrow({ where: { id: fileId } });
      await this.s3Service.deleteObject(file.uri);
      await tx.file.delete({
        where: { id: fileId },
      });
    });
  }

  async getFileAndBuffer(fileId: string) {
    const file = await this.db.file.findFirst({ where: { id: fileId } });
    if (!file) {
      return {
        buffer: null,
        file: null,
      };
    }

    const response = await this.s3Service.getObject(file.uri);

    // Read the stream and collect it into a buffer
    const chunks: Uint8Array[] = [];
    for await (const chunk of response.Body as Readable) {
      chunks.push(chunk);
    }
    const buffer = Buffer.concat(chunks);

    return {
      buffer,
      file,
    };
  }
}
