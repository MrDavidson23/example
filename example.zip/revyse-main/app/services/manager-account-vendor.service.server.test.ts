import { faker } from "@faker-js/faker";

import {
  ContractStatus,
  IntelligenceVendorIntegrationStatus,
  ManagerAccountVendorBusinessCriticalityRating,
  ManagerAccountVendorContactType,
  ManagerAccountVendorDocumentType,
  ManagerAccountVendorRiskScore,
  Prisma,
  ProductState,
  VendorState,
} from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { createTestUser } from "./seeds/createTestUser";
import { randomUUID } from "crypto";
import { withTx } from "./db.server";
import { slugify } from "../utils/string.utils";
import { map } from "lodash";

const generateVendor = (name: string) => ({
  name,
  website: faker.internet.url(),
  state: VendorState.ApprovedForPublishing,
  hq_location: faker.location.city(),
  founded_year: faker.date.past().getFullYear().toString(),
  number_employees: faker.number.int({ min: 1, max: 1000 }).toString(),
  linkedin_profile_url: faker.internet.url(),
});

const generateProduct = (title: string) => ({
  title,
  description: "description",
  state: ProductState.discovery,
  approved_at: new Date(),
  page_title: "page title",
  positioning: "positioning",
  meta_description: "meta description",
});

const PRODUCTS = [
  generateProduct("ABC"),
  generateProduct("BCD"),
  generateProduct("EFG"),
];

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { authService } = TestDIContainer(tx);

    const user = await createTestUser(faker.internet.email(), authService);

    const category = await tx.productCategory.create({
      data: {
        name: faker.company.name(),
        description: "description",
        slug: "category",
        faq_1: "faq 1",
        faq_2: "faq 2",
        faq_3: "faq 3",
        faq_1_answer: "faq 1 answer",
        faq_2_answer: "faq 2 answer",
        faq_3_answer: "faq 3 answer",
        meta_description: "meta description",
        page_title: "page title",
      },
    });

    const VENDORS = [
      generateVendor("Bensontest"),
      generateVendor("Leotest248"),
      generateVendor("FAKEPAGETEST, INC."),
      generateVendor("ABC Software"),
      generateVendor("MACKtest PROPERTY MANAGEMENT"),
    ];
    const vendors = await Promise.all(
      VENDORS.map(v =>
        tx.vendor.create({
          data: { ...v, slug: slugify(v.name) },
        })
      )
    );

    const vendor = await tx.vendor.create({
      data: {
        slug: faker.internet.url(),
        name: faker.company.name(),
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
      },
    });

    const account = await tx.managerAccount.create({
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
        },
        manager_account_vendors: {
          include: {
            vendor: true,
          },
        },
      },
      data: {
        name: faker.company.name(),
        manager_account_roles: {
          create: {
            role: "Owner",
            user: {
              connect: {
                id: user.id,
              },
            },
          },
        },
        manager_account_vendors: {
          createMany: {
            data: [{ vendor_id: vendors[0].id }, { vendor_id: vendors[1].id }],
          },
        },
      },
    });

    const products = await Promise.all(
      PRODUCTS.map(p =>
        tx.product.create({
          data: {
            ...p,
            slug: slugify(p.title),
            primary_category: {
              connect: {
                id: category.id,
              },
            },
            vendor: {
              connect: {
                id: vendor.id,
              },
            },
          },
        })
      )
    );

    const accountVendor = await tx.managerAccountVendor.upsert({
      where: {
        manager_account_id_vendor_id: {
          manager_account_id: account.id,
          vendor_id: vendor.id,
        },
      },
      create: {
        manager_account: { connect: { id: account.id } },
        vendor: { connect: { id: vendor.id } },
        intelligence_vendor_integrations: {
          createMany: {
            data: [
              {
                integrated_vendor_id: account.manager_account_vendors[0].id,
                status: IntelligenceVendorIntegrationStatus.Active,
                notes: faker.lorem.paragraph(),
              },
              {
                integrated_product_id: products[0].id,
                status: IntelligenceVendorIntegrationStatus.Active,
                notes: faker.lorem.paragraph(),
              },
              {
                integrated_product_id: products[1].id,
                status: IntelligenceVendorIntegrationStatus.Active,
                notes: faker.lorem.paragraph(),
              },
            ],
          },
        },
      },
      update: {},
      include: {
        vendor: true,
        intelligence_vendor_integrations: {
          include: {
            integrated_vendor: {
              include: {
                vendor: true,
              },
            },
            integrated_product: true,
          },
        },
      },
    });

    const contracts = await Promise.all(
      Array.from({ length: 3 }).map(() => {
        const isCorporate = !faker.number.int({ min: 0, max: 5 });
        return tx.contract.create({
          data: {
            contract_owner_name: faker.person.fullName(),
            approver: faker.person.fullName(),
            expires_at: faker.date.future(),
            current_term_end_date: faker.date.future(),
            name: faker.commerce.productName(),
            renewal_reminder_lead_time_months: faker.number.int({ max: 12 }),
            status: ContractStatus.Active,
            term_length_months: faker.number.int({ max: 48 }),
            manager_account_vendor: {
              connect: { id: accountVendor.id },
            },
            is_corporate_only: isCorporate,
          },
        });
      })
    );

    const newVendor = await tx.vendor.create({
      data: {
        name: faker.company.name(),
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
      },
    });

    const newAccountVendor = await tx.managerAccountVendor.create({
      data: {
        manager_account: { connect: { id: account.id } },
        vendor: {
          create: {
            name: faker.company.name(),
            website: faker.internet.url(),
            state: VendorState.ApprovedForPublishing,
          },
        },
      },
    });

    const userWithRoles = await tx.user.findFirstOrThrow({
      where: {
        id: user.id,
      },
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
          include: {
            location_roles: true,
          },
        },
        user_roles: true,
      },
    });

    return {
      user,
      account,
      vendor,
      vendors,
      accountVendor,
      contracts,
      newVendor,
      newAccountVendor,
      userWithRoles,
    };
  },
});

describe("ManagerAccountVendor", () => {
  describe("getManagerAccountVendorIdAndName", () => {
    test(
      "should return manager account vendor id and name",
      withFixtures(async ({ accountVendor, vendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const vendorIdAndName =
          await managerAccountVendorService.getManagerAccountVendorIdAndName(
            accountVendor.id
          );

        expect(vendorIdAndName?.id).toBe(vendor.id);
        expect(vendorIdAndName?.name).toBe(vendor.name);
      })
    );
    test(
      "should return null when id doesn't match database record",
      withTx(async tx => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const vendorIdAndName =
          await managerAccountVendorService.getManagerAccountVendorIdAndName(
            randomUUID()
          );
        expect(vendorIdAndName).toBeUndefined();
      })
    );
  });

  describe("getManagerAccountVendorWithFilters", () => {
    it(
      "should return the manager account vendor with filters without passing an id",
      withFixtures(async ({ contracts }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const retrievedManagerAccountVendor =
          await managerAccountVendorService.getManagerAccountVendorWithFilters(
            {
              contracts: {
                some: {
                  id: contracts[0].id,
                },
              },
            },
            {
              vendor: {
                select: {
                  id: true,
                  name: true,
                  description: true,
                  logo_file_id: true,
                },
              },
            }
          );
        expect(retrievedManagerAccountVendor).not.toBeNull();
        expect(retrievedManagerAccountVendor?.vendor).not.toBeNull();
      })
    );
    it(
      "should return null if the manager account vendor does not exist",
      withFixtures(async (_, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);
        const retrievedManagerAccountVendor =
          await managerAccountVendorService.getManagerAccountVendorWithFilters(
            {
              contracts: {
                some: {
                  id: faker.string.uuid(),
                },
              },
            },
            {
              vendor: {
                select: {
                  id: true,
                },
              },
            }
          );
        expect(retrievedManagerAccountVendor).toBeNull();
      })
    );
  });

  describe("getManagerAccountVendor", () => {
    it(
      "should return the manager account vendor",
      withFixtures(async ({ newAccountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const retrievedManagerAccountVendor =
          await managerAccountVendorService.getManagerAccountVendor(
            newAccountVendor.id
          );

        expect(retrievedManagerAccountVendor).toEqual(newAccountVendor);
      })
    );

    it(
      "should return the manager account vendor with the specified includes",
      withFixtures(async ({ newAccountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const retrievedManagerAccountVendor =
          await managerAccountVendorService.getManagerAccountVendor(
            newAccountVendor.id,
            {
              vendor: true,
            }
          );

        expect(retrievedManagerAccountVendor.vendor).toBeDefined();
      })
    );
  });

  describe("getManagerAccountVendorWithIntegrations", () => {
    it(
      "should return the manager account vendor with the intelligence vendor integrations",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const retrievedManagerAccountVendor =
          await managerAccountVendorService.getManagerAccountVendorWithIntegrations(
            accountVendor.id
          );

        expect(
          retrievedManagerAccountVendor.intelligence_vendor_integrations
        ).toEqual(accountVendor.intelligence_vendor_integrations);
      })
    );
    it(
      "should throw an error if the manager account vendor does not exist",
      withFixtures(async (_, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        await expect(
          managerAccountVendorService.getManagerAccountVendorWithIntegrations(
            faker.string.uuid()
          )
        ).rejects.toThrowError("No ManagerAccountVendor found"); // Prisma error
      })
    );
  });

  describe("getVendorRating", () => {
    test(
      "should return manager account vendor rating",
      withFixtures(async ({ user, vendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const category = await tx.productCategory.create({
          data: {
            name: "review-category-test",
            description: "description",
            slug: "category",
            faq_1: "faq 1",
            faq_2: "faq 2",
            faq_3: "faq 3",
            faq_1_answer: "faq 1 answer",
            faq_2_answer: "faq 2 answer",
            faq_3_answer: "faq 3 answer",
            meta_description: "meta description",
            page_title: "page title",
          },
        });

        const product = await tx.product.create({
          data: {
            title: "Vendor Rating Test Product",
            description: "description",
            state: ProductState.discovery,
            approved_at: new Date(),
            slug: "test-product",
            page_title: "page title",
            positioning: "positioning",
            meta_description: "meta description",
            primary_category_id: category.id,
            vendor_id: vendor.id,
          },
        });

        const review = await tx.productReview.create({
          data: {
            approved_at: faker.date.past(),
            approved_by: {
              connect: {
                id: user.id,
              },
            },
            product: { connect: { id: product.id } },
            compatibility_score: faker.number.int({ min: 2, max: 5 }),
            customer_service_score: faker.number.int({ min: 2, max: 5 }),
            onboarding_score: faker.number.int({ min: 2, max: 5 }),
            value_score: faker.number.int({ min: 2, max: 5 }),
            compatibility_desc: faker.lorem.sentence(),
            customer_service_desc: faker.lorem.sentence(),
            decision_maker: faker.person.firstName(),
            dislike_most: faker.lorem.sentence(),
            like_most: faker.lorem.sentence(),
            onboarding_desc: faker.lorem.sentence(),
            primary_use_case: faker.lorem.sentence(),
            recommend_to: faker.lorem.sentence(),
            show_company: faker.datatype.boolean(),
            show_job_title: faker.datatype.boolean(),
            show_last_name: faker.datatype.boolean(),
            user: { connect: { id: user.id } },
            value_desc: faker.lorem.sentence(),
          },
        });

        const vendorDetails = await managerAccountVendorService.getVendorRating(
          vendor.id
        );

        expect(vendorDetails?.rating).toBeGreaterThan(1);
        expect(vendorDetails?.totalReviews).toBe(1);

        await tx.productReview.delete({
          where: {
            id: review.id,
          },
        });
        await tx.product.delete({
          where: {
            id: product.id,
          },
        });
      })
    );
  });

  describe("getManagerAccountVendorContracts", () => {
    test(
      "should return manager account vendor contracts",
      withFixtures(
        async ({ accountVendor, contracts, userWithRoles, account }, tx) => {
          const { managerAccountVendorService } = TestDIContainer(tx);
          const vendorContracts =
            await managerAccountVendorService.getManagerAccountVendorContracts(
              userWithRoles,
              account,
              accountVendor.id,
              { status: [ContractStatus.Active] }
            );

          expect(vendorContracts).toHaveLength(contracts.length);
          expect(vendorContracts.map(contract => contract.name)).toEqual(
            expect.arrayContaining([contracts[0].name])
          );
          expect(vendorContracts.map(contract => contract.name)).toEqual(
            expect.arrayContaining([contracts[1].name])
          );
          expect(vendorContracts.map(contract => contract.name)).toEqual(
            expect.arrayContaining([contracts[2].name])
          );
        }
      )
    );
  });

  describe("getManagerAccountVendorContractsCount", () => {
    test(
      "should return manager account vendor contracts count",
      withFixtures(async ({ accountVendor, contracts }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);
        const activeVendorContracts =
          await managerAccountVendorService.getManagerAccountVendorContractsCount(
            accountVendor.id,
            { status: [ContractStatus.Active] }
          );
        expect(activeVendorContracts).toBe(contracts.length);

        const canceledVendorContracts =
          await managerAccountVendorService.getManagerAccountVendorContractsCount(
            accountVendor.id,
            { status: [ContractStatus.Canceled] }
          );
        expect(canceledVendorContracts).toBe(0);
      })
    );
  });

  describe("getManagerAccountVendorsTableData", () => {
    test(
      "should return manager account vendor contracts",
      withFixtures(async ({ accountVendor, account, userWithRoles }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);
        const vendors =
          await managerAccountVendorService.getManagerAccountVendorsTableData(
            userWithRoles,
            account,
            {
              query: undefined,
            }
          );

        const vendorNames = vendors.rows.map(vendor => vendor.vendor_name);

        const matchedAccountVendors = account.manager_account_vendors.some(
          vendor => vendorNames.includes(vendor.vendor.name)
        );
        expect(matchedAccountVendors).toBeTruthy();
        expect(vendorNames.includes(accountVendor.vendor.name)).toBeTruthy();
      })
    );
  });

  describe("updateManagerAccountVendorIntegrationMap", () => {
    it(
      "should create a manager account vendor intelligence vendor integration",
      withFixtures(async ({ accountVendor, account }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);
        // Call the update function with combined data
        const retrievedManagerAccountVendor =
          await managerAccountVendorService.updateManagerAccountVendorIntegrationMap(
            accountVendor.id,
            {
              intelligence_vendor_integrations: [
                ...accountVendor.intelligence_vendor_integrations,
                {
                  status: IntelligenceVendorIntegrationStatus.Pending,
                  id: "new_" + new Date().getTime(),
                  integrated_vendor_id: account.manager_account_vendors[1].id,
                  notes: faker.lorem.paragraph(),
                },
              ],
            }
          );

        expect(
          retrievedManagerAccountVendor.intelligence_vendor_integrations
        ).toHaveLength(4);
      })
    );
  });

  describe("getVendorIntegrationVendorOptions", () => {
    it(
      "should return vendor integration vendor options",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const vendorOptions =
          await managerAccountVendorService.getVendorIntegrationVendorOptions({
            id: {
              not: {
                in: [
                  accountVendor.vendor.id,
                  ...(map(
                    accountVendor.intelligence_vendor_integrations,
                    "integrated_vendor_id"
                  ).filter(Boolean) as string[]),
                ],
              },
            },
          });

        expect(vendorOptions).toBeDefined();
        expect(vendorOptions.length).toBeGreaterThan(0);
        expect(vendorOptions[0].id).toBeDefined();
        expect(vendorOptions[0].vendor.name).toBeDefined();
        expect(vendorOptions[0].vendor.logo_file_id).toBeDefined();
      })
    );
  });

  describe("getVendorIntegrationProductOptions", () => {
    it(
      "should return vendor integration product options",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const productOptions =
          await managerAccountVendorService.getVendorIntegrationProductOptions({
            id: {
              not: {
                in: [
                  ...(map(
                    accountVendor.intelligence_vendor_integrations,
                    "integrated_product_id"
                  ).filter(Boolean) as string[]),
                ],
              },
            },
          });

        expect(productOptions).toBeDefined();
        expect(productOptions.length).toBeGreaterThan(0);
        expect(productOptions[0].id).toBeDefined();
        expect(productOptions[0].title).toBeDefined();
        expect(productOptions[0].logo_file_id).toBeDefined();
      })
    );
  });

  describe("updateManagerAccountVendorContacts", () => {
    it(
      "should create contacts",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);
        const contactsData = {
          [ManagerAccountVendorContactType.Disposition]: {
            email: faker.internet.email(),
            notes: faker.lorem.sentence(),
          },
          [ManagerAccountVendorContactType.Billing]: {
            phone: faker.phone.number(),
          },
        };

        await managerAccountVendorService.updateManagerAccountVendorContacts(
          accountVendor.id,
          contactsData
        );

        const contacts = await tx.managerAccountVendorContact.findMany({
          where: { manager_account_vendor_id: accountVendor.id },
        });
        expect(contacts).toHaveLength(2);
        expect(contacts).toEqual(
          expect.arrayContaining(
            Object.entries(contactsData).map(([type, data]) =>
              expect.objectContaining({
                type,
                ...data,
              })
            )
          )
        );
      })
    );

    it(
      "should update contacts",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);
        const contactsData = {
          [ManagerAccountVendorContactType.Disposition]: {
            email: faker.internet.email(),
            notes: faker.lorem.sentence(),
          },
          [ManagerAccountVendorContactType.Billing]: {
            phone: faker.phone.number(),
          },
          [ManagerAccountVendorContactType.Internal]: {
            name: faker.person.fullName(),
            email: faker.internet.email(),
            notes: faker.lorem.sentence(),
          },
          [ManagerAccountVendorContactType.Main]: {
            phone: faker.phone.number(),
          },
        };

        await managerAccountVendorService.updateManagerAccountVendorContacts(
          accountVendor.id,
          contactsData
        );

        const updatedContactsData = {
          [ManagerAccountVendorContactType.Disposition]: {
            email: faker.internet.email(),
            notes: faker.lorem.sentence(),
          },
          [ManagerAccountVendorContactType.Billing]: {
            phone: faker.phone.number(),
          },
        };

        await managerAccountVendorService.updateManagerAccountVendorContacts(
          accountVendor.id,
          updatedContactsData
        );

        const contacts = await tx.managerAccountVendorContact.findMany({
          where: { manager_account_vendor_id: accountVendor.id },
        });
        expect(contacts).toHaveLength(4);
        expect(contacts).toEqual(
          expect.arrayContaining(
            Object.entries(updatedContactsData).map(([type, data]) =>
              expect.objectContaining({
                type,
                ...data,
              })
            )
          )
        );

        // Ensure that the other contacts are not deleted or updated
        expect(contacts).toContainEqual(
          expect.objectContaining({
            type: ManagerAccountVendorContactType.Internal,
            ...contactsData[ManagerAccountVendorContactType.Internal],
          })
        );
        expect(contacts).toContainEqual(
          expect.objectContaining({
            type: ManagerAccountVendorContactType.Main,
            ...contactsData[ManagerAccountVendorContactType.Main],
          })
        );
      })
    );

    it(
      "should delete contacts when data is empty",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);
        const contactsData = {
          [ManagerAccountVendorContactType.Disposition]: {
            email: faker.internet.email(),
            notes: faker.lorem.sentence(),
          },
          [ManagerAccountVendorContactType.Billing]: {
            phone: faker.phone.number(),
          },
          [ManagerAccountVendorContactType.Internal]: {
            name: faker.person.fullName(),
            email: faker.internet.email(),
            notes: faker.lorem.sentence(),
          },
          [ManagerAccountVendorContactType.Main]: {
            phone: faker.phone.number(),
          },
        };

        await managerAccountVendorService.updateManagerAccountVendorContacts(
          accountVendor.id,
          contactsData
        );

        await managerAccountVendorService.updateManagerAccountVendorContacts(
          accountVendor.id,
          {
            [ManagerAccountVendorContactType.Disposition]: {},
            [ManagerAccountVendorContactType.Billing]: {},
          }
        );

        const contacts = await tx.managerAccountVendorContact.findMany({
          where: { manager_account_vendor_id: accountVendor.id },
        });

        expect(contacts).toHaveLength(2);
        expect(contacts).not.toEqual(
          expect.arrayContaining(
            Object.entries({
              [ManagerAccountVendorContactType.Disposition]: {},
              [ManagerAccountVendorContactType.Billing]: {},
            }).map(([type, data]) =>
              expect.objectContaining({
                type,
                ...data,
              })
            )
          )
        );

        // Ensure that the other contacts are not deleted
        expect(contacts).toEqual(
          expect.arrayContaining(
            Object.entries({
              [ManagerAccountVendorContactType.Main]: {},
              [ManagerAccountVendorContactType.Internal]: {},
            }).map(([type, data]) =>
              expect.objectContaining({
                type,
                ...data,
              })
            )
          )
        );
      })
    );
  });

  describe("createManagerAccountVendor", () => {
    it(
      "should create a new manager account vendor",
      withFixtures(async ({ account }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const newVendorName = faker.company.name();

        const newManagerAccountVendor =
          await managerAccountVendorService.createManagerAccountVendor(
            {
              manager_account_id: account.id,
              vendor_id: "new",
              new_vendor_name: newVendorName,
              new_vendor_description: faker.lorem.sentence(),
            },
            { email: faker.internet.email() }
          );

        expect(newManagerAccountVendor).toBeDefined();

        const newVendor = await tx.vendor.findUnique({
          where: { id: newManagerAccountVendor.vendor_id },
        });

        expect(newVendor!.name).toBe(newVendorName);
        expect(newVendor!.state).toBe(VendorState.NotApproved);

        const managerAccountVendor = await tx.managerAccountVendor.findFirst({
          where: {
            manager_account_id: account.id,
            vendor_id: newVendor!.id,
          },
        });

        expect(managerAccountVendor).toBeDefined();
      })
    );

    it(
      "should associate an existing vendor with the manager account",
      withFixtures(async ({ account, newVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const newManagerAccountVendor =
          await managerAccountVendorService.createManagerAccountVendor(
            {
              manager_account_id: account.id,
              vendor_id: newVendor.id,
              new_vendor_name: faker.company.name(),
              new_vendor_description: faker.lorem.sentence(),
            },
            { email: faker.internet.email() }
          );

        expect(newManagerAccountVendor).toBeDefined();

        const managerAccountVendor = await tx.managerAccountVendor.findFirst({
          where: {
            manager_account_id: account.id,
            vendor_id: newVendor.id,
          },
        });

        expect(managerAccountVendor).toBeDefined();
      })
    );

    it(
      "should throw an error if the vendor already exists in the account",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        await expect(
          managerAccountVendorService.createManagerAccountVendor(
            {
              manager_account_id: accountVendor.manager_account_id,
              vendor_id: accountVendor.vendor_id,
              new_vendor_name: faker.company.name(),
              new_vendor_description: faker.lorem.sentence(),
            },
            { email: faker.internet.email() }
          )
        ).rejects.toThrowError("Vendor already exists in account");
      })
    );
  });

  describe("getVendorOptions", () => {
    test(
      "should return all vendors that are approved for publishing or are associated with the manager account",
      withFixtures(async ({ account, vendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const vendorsNames = [faker.company.name(), faker.company.name()];

        await tx.vendor.createMany({
          data: [
            {
              name: vendorsNames[0],
              state: VendorState.ApprovedForPublishing,
            },
            {
              name: vendorsNames[1],
              state: VendorState.RevyseIntelligenceOnly,
            },
          ],
        });

        const notApprovedVendorInAccount = await tx.vendor.create({
          data: {
            name: faker.company.name(),
            state: VendorState.NotApproved,
            manager_account_vendors: {
              create: {
                manager_account_id: account.id,
              },
            },
          },
        });

        const vendorOptions =
          await managerAccountVendorService.getVendorOptions(account.id);

        expect(vendorOptions.length).toBeGreaterThan(0);

        expect(vendorOptions).toEqual(
          expect.arrayContaining([
            expect.objectContaining({ id: vendor.id }),
            expect.objectContaining({ id: notApprovedVendorInAccount.id }),
            expect.objectContaining({ name: vendorsNames[0] }),
            expect.objectContaining({ name: vendorsNames[1] }),
          ])
        );
      })
    );

    test(
      "should not return vendors that are not approved for publishing and are not associated with the manager account",
      withFixtures(async ({ account }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const notApprovedVendor = await tx.vendor.create({
          data: {
            name: faker.company.name(),
            state: VendorState.NotApproved,
          },
        });

        const vendorOptions =
          await managerAccountVendorService.getVendorOptions(account.id);

        expect(vendorOptions).not.toContainEqual(
          expect.objectContaining({ id: notApprovedVendor.id })
        );
      })
    );
  });

  describe("handleVendorDocument, deleteVendorDocument", () => {
    test(
      "should create or update a manager account vendor document",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);
        const file = await tx.file.create({
          data: {
            title: "image",
            uri: "uri",
            mime_type: "mime_type",
            size_kb: 100,
          },
        });

        const vendorDocument =
          await managerAccountVendorService.handleVendorDocument({
            id: "new_file",
            name: "name",
            type: ManagerAccountVendorDocumentType.PrivacyPolicy,
            file: file.id,
            managerAccountVendorId: accountVendor.id,
          });

        expect(vendorDocument).not.toBeNull();

        const updatedVendorDocument =
          await managerAccountVendorService.handleVendorDocument({
            id: vendorDocument.id,
            name: "new name",
            type: ManagerAccountVendorDocumentType.TermsofService,
            file: file.id,
            managerAccountVendorId: accountVendor.id,
          });

        expect(updatedVendorDocument.name).toBe("new name");
        expect(updatedVendorDocument.type).toBe(
          ManagerAccountVendorDocumentType.TermsofService
        );
      })
    );

    test(
      "should delete a manager account vendor document",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);
        const file = await tx.file.create({
          data: {
            title: "image",
            uri: "uri",
            mime_type: "mime_type",
            size_kb: 100,
          },
        });

        const vendorDocument =
          await managerAccountVendorService.handleVendorDocument({
            id: "new_file",
            name: "name",
            type: ManagerAccountVendorDocumentType.PrivacyPolicy,
            file: file.id,
            managerAccountVendorId: accountVendor.id,
          });
        await managerAccountVendorService.deleteVendorDocument(
          vendorDocument.id
        );

        const doc = await tx.managerAccountVendorDocument.findFirst({
          where: {
            id: vendorDocument.id,
          },
        });

        expect(doc).toBeNull();
      })
    );
  });

  describe("updateManagerAccountVendor", () => {
    it(
      "should update the manager account vendor",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const data = {
          business_criticality_rating: faker.helpers.enumValue(
            ManagerAccountVendorBusinessCriticalityRating
          ),
          vendor_risk_score: faker.helpers.enumValue(
            ManagerAccountVendorRiskScore
          ),
        };

        await managerAccountVendorService.updateManagerAccountVendor(
          accountVendor.id,
          data
        );

        const updatedManagerAccountVendor =
          await tx.managerAccountVendor.findUnique({
            where: { id: accountVendor.id },
          });

        expect(updatedManagerAccountVendor).toBeDefined();
        expect(updatedManagerAccountVendor!.business_criticality_rating).toBe(
          data.business_criticality_rating
        );
        expect(updatedManagerAccountVendor!.vendor_risk_score).toBe(
          data.vendor_risk_score
        );
      })
    );

    it(
      "should throw an error if the manager account vendor does not exist",
      withFixtures(async (_, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        await expect(
          managerAccountVendorService.updateManagerAccountVendor(
            faker.string.uuid(),
            {
              business_criticality_rating: faker.helpers.enumValue(
                ManagerAccountVendorBusinessCriticalityRating
              ),
            }
          )
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError); // Prisma error
      })
    );
  });

  describe("deleteManagerAccountVendor", () => {
    it(
      "should delete the manager account vendor",
      withFixtures(async ({ newAccountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        await managerAccountVendorService.deleteManagerAccountVendor(
          newAccountVendor.id
        );

        const deletedManagerAccountVendor =
          await tx.managerAccountVendor.findUnique({
            where: { id: newAccountVendor.id },
          });

        expect(deletedManagerAccountVendor).toBeNull();
      })
    );

    it(
      "should throw an error if the manager account vendor has contracts",
      withFixtures(async ({ newAccountVendor }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        await tx.contract.create({
          data: {
            manager_account_vendor_id: newAccountVendor.id,
            name: faker.company.name(),
            status: faker.helpers.enumValue(ContractStatus),
          },
        });

        await expect(
          managerAccountVendorService.deleteManagerAccountVendor(
            newAccountVendor.id
          )
        ).rejects.toThrowError("Vendor has contracts");
      })
    );

    it(
      "should throw an error if the manager account vendor does not exist",
      withFixtures(async (_, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        await expect(
          managerAccountVendorService.deleteManagerAccountVendor(
            faker.string.uuid()
          )
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError); // Prisma error
      })
    );
  });

  describe("createManagerAccountVendors", () => {
    it(
      "should create multiple manager account vendors",
      withFixtures(async ({ account }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const vendorsData = [
          {
            vendor_id: "new",
            new_vendor_name: faker.company.name(),
            new_vendor_description: faker.lorem.sentence(),
          },
          {
            vendor_id: "new",
            new_vendor_name: faker.company.name(),
            new_vendor_description: faker.lorem.sentence(),
          },
        ];

        const vendors =
          await managerAccountVendorService.createManagerAccountVendors(
            account.id,
            vendorsData,
            { email: faker.internet.email() }
          );

        expect(vendors).toHaveLength(2);

        const managerAccountVendors = await tx.managerAccountVendor.findMany({
          where: {
            manager_account_id: account.id,
            vendor: { name: { in: vendorsData.map(v => v.new_vendor_name) } },
          },
        });

        expect(managerAccountVendors).toHaveLength(2);
        expect(vendors).toEqual(
          expect.arrayContaining(
            managerAccountVendors.map(vendor =>
              expect.objectContaining({
                id: vendor.id,
              })
            )
          )
        );
      })
    );
  });

  describe("searchVendorNameMatches", () => {
    // cspell:ignore Bensontest, Leotest, FAKEPAGETEST, ABCSoftware, MACKtest
    // db vendor names                               search queries
    // Bensontest                                 -> BENSONTEST INTEGRATED MARKETING SOLUTIONS
    // Leotest247                                 -> LEOtest247 INC
    // FAKEPAGETEST, INC.                         -> fakepagetest
    // ABC Software                               -> ABCSoftware Solutions
    // MACKtest PROPERTY MANAGEMENT               -> macktest

    it(
      "should return vendors with short name searching by a long name",
      withFixtures(async ({ accountVendor, vendors }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const vendorsFromService =
          await managerAccountVendorService.searchVendorNameMatches(
            "BENSONTEST INTEGRATED MARKETING SOLUTIONS",
            accountVendor.manager_account_id
          );

        expect(vendorsFromService[0].name).toBe("Bensontest");
      })
    );

    it(
      "should return vendors with long name searching by a short name",
      withFixtures(async ({ accountVendor, vendors }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const vendorsFromService =
          await managerAccountVendorService.searchVendorNameMatches(
            "macktest",
            accountVendor.manager_account_id
          );

        expect(vendorsFromService[0].name).toBe("MACKtest PROPERTY MANAGEMENT");
      })
    );

    it(
      "should return vendors with whitespace in the query but not in the vendor name",
      withFixtures(async ({ accountVendor, vendors }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const vendorsFromService =
          await managerAccountVendorService.searchVendorNameMatches(
            "LEOTEST248 INC",
            accountVendor.manager_account_id
          );

        expect(vendorsFromService[0].name).toBe("Leotest248");
      })
    );

    it(
      "should return vendors with whitespace in the vendor name but not in the query",
      withFixtures(async ({ accountVendor, vendors }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const vendorsFromService =
          await managerAccountVendorService.searchVendorNameMatches(
            "ABCSoftware Solutions",
            accountVendor.manager_account_id
          );

        expect(vendorsFromService[0].name).toBe("ABC Software");
      })
    );

    it(
      "should return vendors with different case",
      withFixtures(async ({ accountVendor, vendors }, tx) => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const vendorsFromService =
          await managerAccountVendorService.searchVendorNameMatches(
            "fakepagetest",
            accountVendor.manager_account_id
          );

        expect(vendorsFromService[0].name).toBe("FAKEPAGETEST, INC.");
      })
    );
  });

  describe("createGeneralLedgerImport", () => {
    const generateGeneralLedgerImportRow = () => ({
      posted_date: faker.date.past(),
      doc_date: faker.date.past(),
      doc: faker.string.numeric(5),
      memo: `${faker.finance.transactionType()} - ${faker.company.name()} - ${faker.commerce.productName()}`,
      department: faker.company.buzzNoun(),
      property: faker.company.name(),
      unit: faker.string.numeric(3),
      journal: faker.company.buzzNoun(),
      // replace parentheses with negative sign
      debit: faker.number.float({ min: 0, max: 1000 }),
      // replace parentheses with negative sign
      credit: faker.number.float({ min: 0, max: 1000 }),
      // replace parentheses with negative sign
      total: faker.number.float({ min: 0, max: 1000 }),
      parsed_vendor_name: faker.company.name(),
      parsed_line_item_name: faker.commerce.productName(),
    });

    it(
      "should create a new general ledger import",
      withTx(async tx => {
        const { managerAccountVendorService } = TestDIContainer(tx);

        const newGeneralLedgerImport =
          await managerAccountVendorService.createGeneralLedgerImport({
            manager_account: {
              create: {
                name: faker.company.name(),
              },
            },
            general_ledger_import_rows: {
              createMany: {
                data: Array.from({ length: 3 }).map(() =>
                  generateGeneralLedgerImportRow()
                ),
              },
            },
          });

        expect(newGeneralLedgerImport).toBeDefined();

        const generalLedgerImport = await tx.generalLedgerImport.findUnique({
          where: { id: newGeneralLedgerImport.id },
          include: { general_ledger_import_rows: true },
        });

        expect(generalLedgerImport).toBeDefined();
        expect(generalLedgerImport!.general_ledger_import_rows).toHaveLength(3);
      })
    );
  });
});
