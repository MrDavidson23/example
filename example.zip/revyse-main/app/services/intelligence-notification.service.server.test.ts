import {
  ContractStatus,
  LocationClass,
  LocationStatus,
  TaskCompletionStatus,
  TaskScheduleStatus,
  VendorState,
} from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { createTestUser } from "./seeds/createTestUser";
import { TaskType } from "../utils/tasks.utils";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { authService } = await TestDIContainer(tx);

    const user = await createTestUser(faker.internet.email(), authService);

    const account = await tx.managerAccount.create({
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
        },
      },
      data: {
        name: faker.company.name(),
        manager_account_roles: {
          create: {
            role: "Owner",
            user: {
              connect: {
                id: user.id,
              },
            },
          },
        },
      },
    });
    const vendor = await tx.vendor.create({
      data: {
        slug: faker.internet.url(),
        name: faker.company.name(),
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
      },
    });

    const accountVendor = await tx.managerAccountVendor.upsert({
      where: {
        manager_account_id_vendor_id: {
          manager_account_id: account.id,
          vendor_id: vendor.id,
        },
      },
      create: {
        manager_account: { connect: { id: account.id } },
        vendor: { connect: { id: vendor.id } },
      },
      update: {},
    });

    const contracts = await Promise.all(
      Array.from({ length: 2 }).map(() => {
        const isCorporate = !faker.number.int({ min: 0, max: 5 });
        return tx.contract.create({
          data: {
            contract_owner_name: faker.person.fullName(),
            approver: faker.person.fullName(),
            expires_at: faker.date.future(),
            current_term_end_date: faker.date.future(),
            name: faker.commerce.productName(),
            renewal_reminder_lead_time_months: faker.number.int({ max: 12 }),
            status: ContractStatus.Active,
            term_length_months: faker.number.int({ max: 48 }),
            manager_account_vendor: {
              connect: { id: accountVendor.id },
            },
            is_corporate_only: isCorporate,
          },
        });
      })
    );

    const renewalTasks = await Promise.all(
      contracts.map(contract => {
        const dueDate =
          contract.expires_at ??
          contract.current_term_end_date ??
          faker.date.soon();

        const startDate = faker.helpers.arrayElement([
          faker.date.soon({ days: faker.number.int({ min: 1, max: 30 }) }),
          faker.date.recent({ days: faker.number.int({ min: 1, max: 30 }) }),
        ]);

        return tx.taskContractRenewal.create({
          data: {
            contract: { connect: { id: contract.id } },
            due_date: contract.expires_at ?? contract.current_term_end_date,
            task_owner: {
              connect: { id: account.manager_account_roles[0].id },
            },
            start_date: startDate,
            schedule_status:
              new Date() > startDate
                ? new Date() > dueDate
                  ? TaskScheduleStatus.Overdue
                  : TaskScheduleStatus.ReadyToDo
                : TaskScheduleStatus.Upcoming,
            completion_status: faker.helpers.enumValue(TaskCompletionStatus),
            group_chat: {
              create: {},
            },
          },
        });
      })
    );

    const locations = await Promise.all(
      Array.from({ length: 2 }).map(() => {
        return tx.location.create({
          data: {
            name: faker.location.street(),
            pms_id: faker.string.alphanumeric(6),
            owner_name: faker.company.name(),
            street_1: faker.location.streetAddress(),
            street_2: faker.location.secondaryAddress(),
            city: faker.location.city(),
            state: faker.location.state(),
            zip: faker.location.zipCode(),
            region: faker.location.state(),
            unit_count: faker.number.int({ min: 1, max: 1000 }),
            class: faker.helpers.enumValue(LocationClass),
            status: LocationStatus.Active,
            manager_account_id: account.id,
          },
        });
      })
    );

    const locationDispositionTasks = await Promise.all(
      locations.map(location => {
        const dueDate = faker.date.soon();
        const startDate = faker.date.recent();

        return tx.taskLocationDisposition.create({
          data: {
            location: { connect: { id: location.id } },
            due_date: dueDate,
            task_owner: {
              connect: { id: account.manager_account_roles[0].id },
            },
            start_date: startDate,
            schedule_status:
              new Date() > startDate
                ? new Date() > dueDate
                  ? TaskScheduleStatus.Overdue
                  : TaskScheduleStatus.ReadyToDo
                : TaskScheduleStatus.Upcoming,
            completion_status: faker.helpers.enumValue(TaskCompletionStatus),
            group_chat: {
              create: {},
            },
          },
        });
      })
    );

    return {
      user,
      account,
      vendor,
      accountVendor,
      contracts,
      renewalTasks,
      locations,
      locationDispositionTasks,
    };
  },
});

describe("IntelligenceNotificationService", () => {
  describe("getTaskWithNeededData", () => {
    test(
      "get contract renewal task",
      withFixtures(async ({ user, account, renewalTasks }, tx) => {
        const { intelligenceNotificationService } = TestDIContainer(tx);

        const task =
          await intelligenceNotificationService.getTaskWithNeededData(
            renewalTasks[0].id,
            TaskType.TaskContractRenewal
          );

        expect(task).not.toBeNull();
        expect(!!task && "contract" in task).toBeTruthy();
      })
    );
    test(
      "get location disposition task",
      withFixtures(async ({ user, account, locationDispositionTasks }, tx) => {
        const { intelligenceNotificationService } = TestDIContainer(tx);

        const task =
          await intelligenceNotificationService.getTaskWithNeededData(
            locationDispositionTasks[0].id,
            TaskType.TaskLocationDisposition
          );

        expect(task).not.toBeNull();
        expect(!!task && "location" in task).toBeTruthy();
      })
    );
    test("get null task", async () => {
      const { intelligenceNotificationService } = TestDIContainer();

      const task = await intelligenceNotificationService.getTaskWithNeededData(
        "123",
        TaskType.TaskContractRenewal
      );

      expect(task).toBeNull();
    });
  });
});
