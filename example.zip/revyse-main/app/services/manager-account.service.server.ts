import type {
  ProductCategory,
  Product,
  Vendor,
  ContractLineItem,
  ContractLineItemLocation,
  Location,
  PrismaClient,
  Prisma,
  ContractLineItemProduct,
  ContractLineItemFee,
  ContractLineItemPriceCadence,
  ContractPricingType,
  Contract,
  User,
  ManagerAccount,
} from "@prisma/client";
import {
  ContractLineItemLocationStatus,
  ContractLineItemStatus,
  ContractStatus,
  LocationStatus,
  ManagerAccountRoleType,
  ManagerAccountVendorStatus,
  ResidentLifecyclePhase,
  Role,
} from "@prisma/client";
import type { ProductService } from "./product.service.server";
import dayjs from "dayjs";
import { generateContractsRawPermissionsQuery } from "../utils/contract-permission.utils";
import {
  canDoOnAccount,
  Permission,
  type PermissionUser,
} from "../utils/intelligence-permission.utils";
import { getLocationIdsForUser } from "../utils/location-permission.utils";
import { ProductSubscriptionActiveStatuses } from "../utils/product-subscription.utils.server";
export const ContractLineItemPriceCadenceMultiplier: Record<
  ContractLineItemPriceCadence | "Default",
  number
> = {
  Monthly: 12,
  Quarterly: 4,
  Annual: 1,
  OneTime: 1,
  Default: 1,
};

/*
  Prices calculated by product or fee: 
    - FlatRate: is one price, no matter how many locations the user assigns
    - PerLocation: the price changes based on the number of locations assigned.
    - PerUnit: the price changes based on the specific locations assigned, and their Unit Count.
    - PerSeat: the price changes based on the number of seats entered
  Prices calculated by contract contractLineItem:
    - UsageBased: the price varies based on how much is used, so we use the estimated cost field
    - PerLease: the price varies based on the lease, so we use the estimated cost field
    - Itemized: the price is calculated by the items the user adds to the contract_line_item_items field (calculation is saved in the line item price already)
*/
export const ContractPricingTypeCalculation: Record<
  ContractPricingType | "Default",
  {
    calc: (
      price: number,
      contractLineItem: ContractLineItemWithIncludes
    ) => number;
    calcOn: "productsAndFees" | "contractLineItem";
  }
> = {
  FlatRate: {
    calc: (price, contractLineItem) => price,
    calcOn: "productsAndFees",
  },
  PerLocation: {
    calc: (price, contractLineItem) =>
      price * contractLineItem.contract_line_item_locations.length,
    calcOn: "productsAndFees",
  },
  PerUnit: {
    calc: (price, contractLineItem) =>
      price *
      contractLineItem.contract_line_item_locations.reduce(
        (acc, l) => acc + l.location.unit_count,
        0
      ),
    calcOn: "productsAndFees",
  },
  PerSeat: {
    calc: (price, contractLineItem) =>
      price * (contractLineItem.seats_number ?? 0),
    calcOn: "productsAndFees",
  },
  UsageBased: {
    calc: (price, contractLineItem) =>
      contractLineItem.estimated_cost as number,
    calcOn: "contractLineItem",
  },
  PerLease: {
    calc: (price, contractLineItem) =>
      (contractLineItem.estimated_cost as number) *
      contractLineItem.contract_line_item_locations.length,
    calcOn: "contractLineItem",
  },
  Itemized: {
    calc: (price, contractLineItem) => price,
    calcOn: "contractLineItem",
  },
  Default: {
    calc: (price, contractLineItem) => price,
    calcOn: "productsAndFees",
  },
};

type ContractLineItemWithIncludes = ContractLineItem & {
  contract_line_item_products: ContractLineItemProduct[];
  contract_line_item_fees: ContractLineItemFee[];
  contract_line_item_locations: (ContractLineItemLocation & {
    location: Location;
  })[];
};

export class ManagerAccountService {
  // eslint-disable-next-line no-useless-constructor
  constructor(
    private db: PrismaClient,
    private productService: ProductService
  ) {}

  async getManagerAccount(id: string) {
    const managerAccount = this.db.managerAccount.findUnique({
      where: { id },
    });

    return managerAccount;
  }

  async getManagerAccountDetails(id: string) {
    const managerAccount = await this.db.managerAccount.findFirstOrThrow({
      where: { id },
      include: {
        avatar: true,
        locations: true,
        _count: {
          select: {
            locations: {
              where: {
                status: {
                  notIn: [LocationStatus.Disposed],
                },
              },
            },
          },
        },
      },
    });

    return {
      ...managerAccount,
      locations_count: managerAccount._count.locations,
      unit_count: managerAccount.locations.reduce(
        (acc, l) =>
          acc + (l.status != LocationStatus.Disposed ? l.unit_count : 0),
        0
      ),
    };
  }

  async getManagerAccountByContractId(contractId: string) {
    const managerAccount = this.db.managerAccount.findFirst({
      where: {
        manager_account_vendors: {
          some: {
            contracts: {
              some: {
                id: contractId,
              },
            },
          },
        },
      },
    });

    return managerAccount;
  }

  async getManagerAccountsForUser({
    id,
    user_roles,
  }: Pick<User, "id"> & { user_roles: { role: Role }[] }) {
    const managerAccounts = this.db.managerAccount.findMany({
      where: user_roles?.some(role => role.role === Role.GOD_MODE)
        ? {}
        : {
            manager_account_roles: { some: { user_id: id, deleted_at: null } },
          },
    });

    return managerAccounts;
  }

  async getTotalsForAccount(user: PermissionUser, account: ManagerAccount) {
    const hideSensitiveContracts = !canDoOnAccount(
      user,
      account,
      Permission.ViewSensitiveContracts
    );

    const contractsWhere: Prisma.ContractWhereInput = {
      manager_account_vendor: { manager_account_id: account.id },
      status: ContractStatus.Active,
      is_sensitive: hideSensitiveContracts ? false : undefined,
    };

    const contracts = await this.db.contract.count({
      where: contractsWhere,
    });
    const products = await this.db.product.count({
      where: {
        contract_line_item_products: {
          some: {
            contract_line_item: {
              status: {
                not: ContractLineItemStatus.Canceled,
              },
              contract: contractsWhere,
            },
          },
        },
      },
    });

    const vendors = await this.db.managerAccountVendor.count({
      where: {
        manager_account_id: account.id,
        status: ManagerAccountVendorStatus.Active,
        OR: hideSensitiveContracts
          ? [
              {
                contracts: {
                  none: {},
                },
              },
              {
                NOT: {
                  contracts: {
                    every: {
                      is_sensitive: true,
                    },
                  },
                },
              },
            ]
          : undefined,
      },
    });

    return {
      contracts,
      products,
      vendors,
    };
  }

  async getContractLineItemAnnualAssignedValue(contractLineItemId: string) {
    const contractLineItem = await this.db.contractLineItem.findFirstOrThrow({
      where: {
        id: contractLineItemId,
      },
      include: {
        contract_line_item_fees: true,
        contract_line_item_products: true,
        contract_line_item_locations: {
          where: {
            status: { not: ContractLineItemLocationStatus.Canceled, },
            location: {
              status: {
                in: [LocationStatus.Active, LocationStatus.Pending],
              },
            },
          },
          include: {
            location: true,
          },
        },
      },
    });

    let total = 0;

    const pricingTypeCalculation =
      ContractPricingTypeCalculation[
        contractLineItem.pricing_type ?? "Default"
      ];
    const cadenceMultiplier =
      ContractLineItemPriceCadenceMultiplier[
        contractLineItem.cadence ?? "Default"
      ];
    if (pricingTypeCalculation.calcOn === "contractLineItem") {
      total +=
        pricingTypeCalculation.calc(contractLineItem.price, contractLineItem) *
        cadenceMultiplier;
      return total; // Return early if the calculation is based on the contract contractLineItem
    }

    // Then iterate on productsAndFess to handle the types that are calculated based on the products and fees assigned to the contract
    [
      ...contractLineItem.contract_line_item_products,
      ...contractLineItem.contract_line_item_fees,
    ]
      // Filter out the items that are not calculated based on the products and fees
      .filter(() => pricingTypeCalculation.calcOn === "productsAndFees")
      .forEach(productOrFee => {
        total +=
          pricingTypeCalculation.calc(productOrFee.price, contractLineItem) *
          cadenceMultiplier;
      });

    return total;
  }

  async getContractAnnualAssignedValue(contractId: string) {
    const contractLineItems = await this.db.contractLineItem.findMany({
      where: {
        status: {
          not: ContractLineItemStatus.Canceled,
        },
        contract: {
          id: contractId,
          status: ContractStatus.Active,
        },
      },
      include: {
        contract_line_item_products: {
          include: { product: { include: { primary_category: true } } },
        },
        contract_line_item_fees: {
          include: { fee: { include: { category: true } } },
        },
        contract_line_item_locations: {
          where: {
            status: { not: ContractLineItemLocationStatus.Canceled, },
            location: {
              status: {
                in: [LocationStatus.Active, LocationStatus.Pending],
              },
            },
          },
          select: {
            location_id: true,
            location: { select: { unit_count: true } },
          },
        },
      },
    });

    const annualValue = this.calculateAnnualValue(contractLineItems as any[]);
    return annualValue.total;
  }

  async getManagerAccountVendorAnnualAssignedValue(
    managerAccountVendorId: string
  ) {
    const managerAccountVendorContracts =
      await this.db.managerAccountVendor.findFirstOrThrow({
        where: {
          id: managerAccountVendorId,
        },
        select: {
          contracts: {
            where: {
              status: {
                notIn: [ContractStatus.Canceled, ContractStatus.Pending],
              },
            },
            include: {
              contract_line_items: {
                where: {
                  status: {
                    not: ContractLineItemStatus.Canceled,
                  },
                },
                include: {
                  contract_line_item_locations: {
                    where: {
                      status: { not: ContractLineItemLocationStatus.Canceled, },
                      location: {
                        status: {
                          in: [LocationStatus.Active, LocationStatus.Pending],
                        },
                      },
                    },
                    include: {
                      location: true,
                    },
                  },
                  contract_line_item_fees: {
                    include: {
                      fee: true,
                    },
                  },
                  contract_line_item_products: {
                    include: {
                      product: true,
                    },
                  },
                },
              },
            },
          },
        },
      });
    const allContractLineItems =
      managerAccountVendorContracts.contracts.flatMap(
        contract => contract.contract_line_items
      );
    const annualValue = this.calculateAnnualValue(allContractLineItems).total;
    return annualValue;
  }

  async getSpend(
    user: PermissionUser,
    managerAccount: ManagerAccount,
    include: {
      byDepartment?: boolean;
      byRLP?: boolean;
      byCategory?: boolean;
    } = { byDepartment: true, byRLP: false, byCategory: false }
  ) {
    type QueryResult = {
      byDepartment: { [key: string]: number };
      byRLP: { [key: string]: number };
      byCategory: { [key: string]: number };
      total: number;
    };

    const statusFiltersRawSql: Record<string, (alias: string) => string> = {
      managerAccountVendor: alias =>
        `${alias}.manager_account_id='${managerAccount.id}' AND ${alias}.status in ('${ManagerAccountVendorStatus.Active}', '${ManagerAccountVendorStatus.Piloting}')`,
      contract: alias =>
        `${alias}.status in ('${ContractStatus.Active}', '${ContractStatus.Pending}')`,
      location: alias =>
        `${alias}.status in ('${LocationStatus.Active}', '${LocationStatus.Pending}')`,
      contractLineItem: alias =>
        `${alias}.status='${ContractLineItemStatus.Active}'`,
      contractLineItemLocation: alias =>
        `${alias}.status in ('${ContractLineItemLocationStatus.Active}', '${ContractLineItemLocationStatus.Pending}')`,
    };

    const result = await this.db.$queryRawUnsafe<QueryResult[]>(`
    with contract_line_items_product_and_fees as (
      select 
        clip.id, 
        clip.contract_line_item_id,
        clip.price
        ${include.byDepartment ? ",clip.department" : ""}
        ${
          include.byCategory || include.byRLP
            ? ",p.primary_category_id as category_id"
            : ""
        }
      from 
        contract_line_item_product clip
        inner join product p on p.id=clip.product_id
        inner join contract_line_item cli on cli.id=clip.contract_line_item_id AND ${statusFiltersRawSql.contractLineItem(
          "cli"
        )}
        inner join contract c on c.id=cli.contract_id AND ${statusFiltersRawSql.contract(
          "c"
        )}
        ${
          managerAccount.id
            ? `inner join manager_account_vendor mav on 
                mav.id=c.manager_account_vendor_id 
                AND ${statusFiltersRawSql.managerAccountVendor("mav")}
                AND mav.manager_account_id='${managerAccount.id}'`
            : ""
        }
      where
        1=1
        ${generateContractsRawPermissionsQuery({
          user,
          managerAccount,
          alias: { contract: "c" },
          queryConfig: { prefix: "AND" },
        })}
      union all
      select 
        clif.id,
        clif.contract_line_item_id,
        clif.price
        ${include.byDepartment ? ",clif.department" : ""}
        ${include.byCategory || include.byRLP ? ",f.category_id" : ""}
      from 
        contract_line_item_fee clif
        inner join fee f on f.id=clif.fee_id
        inner join contract_line_item cli on cli.id=clif.contract_line_item_id AND ${statusFiltersRawSql.contractLineItem(
          "cli"
        )}
        inner join contract c on c.id=cli.contract_id AND ${statusFiltersRawSql.contract(
          "c"
        )}
        ${
          managerAccount.id
            ? `inner join manager_account_vendor mav on 
                mav.id=c.manager_account_vendor_id 
                AND ${statusFiltersRawSql.managerAccountVendor("mav")}
                AND mav.manager_account_id='${managerAccount.id}'`
            : ""
        }
      where
        1=1
        ${generateContractsRawPermissionsQuery({
          user,
          managerAccount,
          alias: { contract: "c" },
          queryConfig: { prefix: "AND" },
        })}
    ),
    contract_line_item_with_location_counts as (
      select 
        cli.id,
        cli.pricing_type,
        cli.cadence,
        cli.seats_number,
        cli.estimated_cost,
        sum(l.unit_count) as unit_count,
        count(l.id) as location_count
      from
        contract_line_item cli
        join contract c on c.id=cli.contract_id AND ${statusFiltersRawSql.contract(
          "c"
        )}
        ${
          managerAccount.id
            ? `inner join manager_account_vendor mav on 
                mav.id=c.manager_account_vendor_id 
                AND ${statusFiltersRawSql.managerAccountVendor("mav")}
                AND mav.manager_account_id='${managerAccount.id}'`
            : ""
        }
        left join contract_line_item_location clil on clil.contract_line_item_id=cli.id AND clil.status 
        in ('${ContractLineItemLocationStatus.Active}', '${ContractLineItemLocationStatus.Pending}')
        left join location l on l.id=clil.location_id AND ${statusFiltersRawSql.location(
          "l"
        )}
      where 
        ${statusFiltersRawSql.contractLineItem("cli")}
        ${generateContractsRawPermissionsQuery({
          user,
          managerAccount,
          alias: { contract: "c" },
          queryConfig: { prefix: "AND" },
        })}
      group by cli.id
    ),
    contract_line_item_products_and_fees_annual_values as (
      select 
        clipf.id
        ${include.byDepartment ? ",clipf.department" : ""}
        ${include.byCategory || include.byRLP ? ",clipf.category_id" : ""}
        ,(
          -- Price
          (CASE 
            WHEN cli.pricing_type = 'FlatRate' THEN clipf.price
            WHEN cli.pricing_type = 'PerSeat' THEN clipf.price * cli.seats_number
            WHEN cli.pricing_type = 'PerUnit' THEN clipf.price * cli.unit_count
            WHEN cli.pricing_type = 'PerLocation' THEN clipf.price * cli.location_count
            WHEN cli.pricing_type = 'UsageBased' THEN cli.estimated_cost
            WHEN cli.pricing_type = 'PerLease' THEN cli.estimated_cost * cli.location_count
            WHEN cli.pricing_type = 'Itemized' THEN clipf.price
            ELSE 0 END) *
          -- Cadence
          (CASE 
            WHEN cli.cadence = 'Monthly' THEN 12
            WHEN cli.cadence = 'Quarterly' THEN 4
            WHEN cli.cadence = 'Annual' THEN 1
            ELSE 1 END)
        ) as annual_value
      from
        contract_line_items_product_and_fees clipf
        left join contract_line_item_with_location_counts cli on cli.id=clipf.contract_line_item_id
    )
    ${
      include.byDepartment
        ? `,departments as (
      select distinct department from (
        select
          department
        from
          contract_line_item_product clip
          inner join contract_line_item cli on cli.id=clip.contract_line_item_id AND ${statusFiltersRawSql.contractLineItem(
            "cli"
          )}
          inner join contract c on c.id=cli.contract_id AND ${statusFiltersRawSql.contract(
            "c"
          )}
          ${
            managerAccount.id
              ? `inner join manager_account_vendor mav on 
                  mav.id=c.manager_account_vendor_id 
                  AND ${statusFiltersRawSql.managerAccountVendor("mav")}
                  AND mav.manager_account_id='${managerAccount.id}'`
              : ""
          }
        where
          1=1
          ${generateContractsRawPermissionsQuery({
            user,
            managerAccount,
            alias: { contract: "c" },
            queryConfig: { prefix: "AND" },
          })}
        union
        select
          department
        from
          contract_line_item_fee clif
          inner join contract_line_item cli on cli.id=clif.contract_line_item_id AND ${statusFiltersRawSql.contractLineItem(
            "cli"
          )}
          inner join contract c on c.id=cli.contract_id AND ${statusFiltersRawSql.contract(
            "c"
          )}
          ${
            managerAccount.id
              ? `inner join manager_account_vendor mav on 
                  mav.id=c.manager_account_vendor_id 
                  AND ${statusFiltersRawSql.managerAccountVendor("mav")}
                  AND mav.manager_account_id='${managerAccount.id}'`
              : ""
          }
        where
          1=1
          ${generateContractsRawPermissionsQuery({
            user,
            managerAccount,
            alias: { contract: "c" },
            queryConfig: { prefix: "AND" },
          })}
      ) as d
    )`
        : ""
    }
    ${
      include.byRLP
        ? `,rlp as (
      select distinct resident_lifecycle_phase from product_category
    )`
        : ""
    }
    ${
      include.byCategory
        ? `,categories as (
      select distinct primary_category_id from product
    )`
        : ""
    }
    ${
      include.byDepartment
        ? `,account_department_spend as (
      select 
        clipfav.department,
        coalesce(sum(clipfav.annual_value), 0) as annual_value
      from 
        contract_line_item_products_and_fees_annual_values clipfav
      group by department
    )`
        : ""
    }
    ${
      include.byRLP
        ? `,account_rlp_spend as (
      select 
        pc.resident_lifecycle_phase,
        coalesce(sum(clipfav.annual_value), 0) as annual_value
      from 
        contract_line_item_products_and_fees_annual_values clipfav
        left join product_category pc on pc.id=clipfav.category_id
      group by resident_lifecycle_phase
    )`
        : ""
    }
    ${
      include.byCategory
        ? `,account_category_spend as (
      select 
        clipfav.category_id,
        coalesce(sum(clipfav.annual_value), 0) as annual_value
      from 
        contract_line_item_products_and_fees_annual_values clipfav
        left join product_category pc on pc.id=clipfav.category_id
      group by category_id
    )`
        : ""
    }
    ,total as (
      select
        coalesce(sum(clipfav.annual_value), 0) as total
      from 
        contract_line_item_products_and_fees_annual_values clipfav
    )
    SELECT
      total.total as total,
      ${
        include.byDepartment
          ? "json_object_agg(ads.department, ads.annual_value) "
          : `json_object('{}')`
      } as "byDepartment",
      ${
        include.byRLP
          ? "json_object_agg(ars.resident_lifecycle_phase, ars.annual_value)"
          : `json_object('{}')`
      } as "byRLP",
      ${
        include.byCategory
          ? "json_object_agg(ac.category_id, ac.annual_value)"
          : `json_object('{}')`
      } as "byCategory"
    from
      total
      ${include.byDepartment ? `cross join account_department_spend ads` : ""}
      ${include.byRLP ? `cross join account_rlp_spend ars` : ""}
      ${include.byCategory ? `cross join account_category_spend ac` : ""}
    group by total.total
    `);

    return (
      result[0] ?? {
        byDepartment: {},
        byRLP: {},
        byCategory: {},
        total: 0,
      }
    );
  }

  calculateAnnualValue(contractLineItems: ContractLineItemWithIncludes[]) {
    const annualValue = contractLineItems.reduce(
      (acc, contractLineItem) => {
        const pricingTypeCalculation =
          ContractPricingTypeCalculation[
            contractLineItem.pricing_type ?? "Default"
          ];
        const cadenceMultiplier =
          ContractLineItemPriceCadenceMultiplier[
            contractLineItem.cadence ?? "Default"
          ];

        // Then iterate on productsAndFess to handle the types that are calculated based on the products and fees assigned to the contract
        [
          ...contractLineItem.contract_line_item_products,
          ...contractLineItem.contract_line_item_fees,
        ]
          // Filter out the items that are not calculated based on the products and fees
          .forEach(productOrFee => {
            let value =
              pricingTypeCalculation.calc(
                productOrFee.price,
                contractLineItem
              ) * cadenceMultiplier;
            acc = this.updateAccumulator(acc, productOrFee, value);
          });
        return acc;
      },
      {
        byCategory: {} as Record<string, number>,
        byRLP: {} as Record<string, number>,
        byDepartment: {} as Record<string, number>,
        total: 0,
      }
    );

    return annualValue;
  }

  private updateAccumulator(
    acc: any,
    contractLineItemItem: any,
    value: number
  ) {
    const categoryKey = contractLineItemItem.product
      ? contractLineItemItem.product.primary_category_id
      : contractLineItemItem.fee.category_id;

    const rlpKey =
      contractLineItemItem.product?.primary_category
        ?.resident_lifecycle_phase ??
      contractLineItemItem.fee?.category?.resident_lifecycle_phase ??
      null;

    if (!acc.byCategory.hasOwnProperty(categoryKey)) {
      acc.byCategory[categoryKey] = 0;
    }
    acc.byCategory[categoryKey] += value;

    if (!acc.byRLP.hasOwnProperty(rlpKey)) {
      acc.byRLP[rlpKey] = 0;
    }
    acc.byRLP[rlpKey] += value;

    if (!acc.byDepartment.hasOwnProperty(contractLineItemItem.department)) {
      acc.byDepartment[contractLineItemItem.department] = 0;
    }
    acc.byDepartment[contractLineItemItem.department] += value;

    acc.total += value;

    return acc;
  }

  async getProductsByResidentLifecyclePhase(
    user: PermissionUser,
    account: ManagerAccount
  ) {
    const hideSensitiveContracts = !canDoOnAccount(
      user,
      account,
      Permission.ViewSensitiveContracts
    );
    const products = await this.db.product.findMany({
      where: {
        contract_line_item_products: {
          some: {
            contract_line_item: {
              contract: {
                manager_account_vendor: { manager_account_id: account.id },
                status: ContractStatus.Active,
                is_sensitive: hideSensitiveContracts ? false : undefined,
              },
            },
          },
        },
      },
      include: {
        primary_category: true,
        vendor: true,
        subscriptions: {
          where: {
            status: {
              in: ProductSubscriptionActiveStatuses,
            },
          },
          include: {
            stripe_price: { include: { product: true } },
          },
        },
      },
      orderBy: { primary_category: { name: "asc" } },
    });

    const ids = products.map(product => product.id);

    const aggregates = await this.db.productReview.groupBy({
      by: ["product_id"],
      _avg: {
        value_score: true,
        compatibility_score: true,
        customer_service_score: true,
        onboarding_score: true,
      },
      _count: {
        id: true,
      },
      where: { product_id: { in: ids }, approved_by_id: { not: null } },
    });

    const productMap = products.reduce((acc, p) => {
      acc[p.id] = p as any;
      return acc;
    }, {} as Record<string, Product & { primary_category: ProductCategory; vendor: Vendor }>);

    const rlpToProductIds = Object.entries(productMap).reduce(
      (acc, [productId, product]) => {
        if (
          !acc.hasOwnProperty(product.primary_category.resident_lifecycle_phase)
        ) {
          acc[product.primary_category.resident_lifecycle_phase] =
            new Set<string>();
        }
        acc[product.primary_category.resident_lifecycle_phase].add(productId);
        return acc;
      },
      {} as Record<ResidentLifecyclePhase, Set<string>>
    );

    const rlpCatCount = Object.keys(ResidentLifecyclePhase).reduce(
      (acc, rlp) => {
        acc[rlp as ResidentLifecyclePhase] = {};
        for (const productId of rlpToProductIds[
          rlp as ResidentLifecyclePhase
        ] || []) {
          const product = productMap[productId];
          if (
            !acc[rlp as ResidentLifecyclePhase].hasOwnProperty(
              product.primary_category_id
            )
          ) {
            acc[rlp as ResidentLifecyclePhase][product.primary_category_id] = 0;
          }
          acc[rlp as ResidentLifecyclePhase][product.primary_category_id] += 1;
        }
        return acc;
      },
      {} as { [key in ResidentLifecyclePhase]: { [key: string]: number } }
    );

    const result = Object.keys(ResidentLifecyclePhase).reduce((acc, rlp) => {
      const products = Array.from(
        rlpToProductIds[rlp as ResidentLifecyclePhase] || []
      ).map(id => {
        const agg = aggregates.find(agg => agg.product_id === id);
        const avgReview =
          ((agg?._avg.compatibility_score ?? 0) +
            (agg?._avg.value_score ?? 0) +
            (agg?._avg.customer_service_score ?? 0) +
            (agg?._avg.onboarding_score ?? 0)) /
          4.0;
        return {
          ...productMap[id],
          hasOverlap:
            rlpCatCount[rlp as ResidentLifecyclePhase][
              productMap[id].primary_category_id
            ] > 1,
          avgReview,
        };
      });
      acc[rlp as ResidentLifecyclePhase] = products;
      return acc;
    }, {} as Record<ResidentLifecyclePhase, Array<Product & { avgReview: number; primary_category: ProductCategory; vendor: Vendor; hasOverlap: boolean }>>);

    return result;
  }

  async getDepartmentContractLineItems(
    name: string,
    user: PermissionUser,
    account: ManagerAccount
  ) {
    const hideSensitiveContracts = !canDoOnAccount(
      user,
      account,
      Permission.ViewSensitiveContracts
    );
    const result = await this.db.contractLineItem.findMany({
      where: {
        AND: [
          {
            status: {
              not: ContractLineItemStatus.Canceled,
            },
            contract: {
              status: {
                in: [ContractStatus.Active, ContractStatus.Pending],
              },
              manager_account_vendor: {
                status: {
                  in: [
                    ManagerAccountVendorStatus.Active,
                    ManagerAccountVendorStatus.Piloting,
                  ],
                },
                manager_account_id: account.id,
              },
              is_sensitive: hideSensitiveContracts ? false : undefined,
            },
          },
          {
            OR: [
              {
                contract_line_item_products: {
                  some: {
                    department: {
                      equals: name,
                    },
                  },
                },
              },
              {
                contract_line_item_fees: {
                  some: {
                    department: {
                      equals: name,
                    },
                  },
                },
              },
            ],
          },
        ],
      },
      include: {
        contract: {
          include: {
            manager_account_vendor: {
              include: {
                vendor: true,
              },
            },
          },
        },
      },
      orderBy: {
        contract: {
          name: "asc",
        },
      },
    });
    return result;
  }

  async getCountsByDepartment(user: PermissionUser, account: ManagerAccount) {
    const hideSensitiveContracts = !canDoOnAccount(
      user,
      account,
      Permission.ViewSensitiveContracts
    );
    const query = {
      where: {
        contract_line_item: {
          contract: {
            manager_account_vendor: {
              manager_account_id: account.id,
              status: {
                in: [
                  ManagerAccountVendorStatus.Active,
                  ManagerAccountVendorStatus.Piloting,
                ],
              },
            },
            status: { in: [ContractStatus.Active, ContractStatus.Pending] },
            is_sensitive: hideSensitiveContracts ? false : undefined,
          },
          status: {
            not: ContractLineItemStatus.Canceled,
          },
        },
      },
      include: {
        contract_line_item: {
          include: {
            contract: {
              include: {
                manager_account_vendor: true,
              },
            },
          },
        },
      },
    };

    const contractLineItemProducts =
      await this.db.contractLineItemProduct.findMany(query);
    const contractLineItemFees = await this.db.contractLineItemFee.findMany(
      query
    );

    const contractLineItemsDepartments: Record<string, Set<string>> = [
      ...contractLineItemProducts,
      ...contractLineItemFees,
    ].reduce((acc, cli) => {
      if (!acc.hasOwnProperty(cli.department)) {
        acc[cli.department] = new Set<string>();
      }
      acc[cli.department].add(cli.contract_line_item_id);
      return acc;
    }, {} as Record<string, Set<string>>);

    const contractsDepartments: Record<string, Set<string>> = [
      ...contractLineItemProducts,
      ...contractLineItemFees,
    ].reduce((acc, cli) => {
      if (!acc.hasOwnProperty(cli.department)) {
        acc[cli.department] = new Set<string>();
      }
      acc[cli.department].add(cli.contract_line_item.contract_id);
      return acc;
    }, {} as Record<string, Set<string>>);

    const vendorsDepartments: Record<string, Set<string>> = [
      ...contractLineItemProducts,
      ...contractLineItemFees,
    ].reduce((acc, cli) => {
      if (!acc.hasOwnProperty(cli.department)) {
        acc[cli.department] = new Set<string>();
      }
      acc[cli.department].add(
        cli.contract_line_item.contract.manager_account_vendor.id
      );
      return acc;
    }, {} as Record<string, Set<string>>);

    const contractLineItems = Object.entries(
      contractLineItemsDepartments
    ).reduce((acc, [dep, set]) => {
      acc[dep] = set.size;
      return acc;
    }, {} as Record<string, number>);

    const contracts = Object.entries(contractsDepartments).reduce(
      (acc, [dep, set]) => {
        acc[dep] = set.size;
        return acc;
      },
      {} as Record<string, number>
    );

    const vendors = Object.entries(vendorsDepartments).reduce(
      (acc, [dep, set]) => {
        acc[dep] = set.size;
        return acc;
      },
      {} as Record<string, number>
    );

    return {
      contractLineItems,
      contracts,
      vendors,
    };
  }

  async getUpcomingContractRenewals(
    user: PermissionUser,
    account: ManagerAccount,
    includeMonthToMonth: boolean,
    quantity: number
  ) {
    const hideSensitiveContracts = !canDoOnAccount(
      user,
      account,
      Permission.ViewSensitiveContracts
    );

    const where: Prisma.ContractWhereInput = {
      manager_account_vendor: { manager_account_id: account.id },
      status: ContractStatus.Active,
      current_term_end_date: {
        gte: dayjs().subtract(1, "month").toDate(),
      },
      is_sensitive: hideSensitiveContracts ? false : undefined,
      is_month_to_month: !includeMonthToMonth ? false : undefined,
    };

    const contracts = await this.db.contract.findMany({
      where,
      include: {
        contract_line_items: {
          include: {
            contract_line_item_products: {
              include: { product: true },
            },
          },
        },
        manager_account_vendor: {
          include: { vendor: true },
        },
      },
      take: quantity,
      orderBy: { current_term_end_date: "asc" },
    });
    const productIds = new Set<string>();
    contracts.forEach(c => {
      c.contract_line_items.forEach(cs => {
        cs.contract_line_item_products.forEach(csp => {
          productIds.add(csp.product_id);
        });
      });
    });

    const productMap = (
      await this.productService.getProductsWithRatings({
        ids: Array.from(productIds),
      })
    ).reduce((acc, p) => {
      acc[p.id] = p;
      return acc;
    }, {} as Record<string, Awaited<ReturnType<typeof this.productService.getProductsWithRatings>>[number]>);

    const result = contracts.map(c => {
      return {
        ...c,
        contract_line_items: c.contract_line_items.map(cs => {
          return {
            ...cs,
            contract_line_item_products: cs.contract_line_item_products.map(
              csp => {
                return {
                  ...csp,
                  product: productMap[csp.product_id],
                };
              }
            ),
          };
        }),
      };
    });

    return result;
  }

  async getContractsTableData(
    user: PermissionUser,
    managerAccount: ManagerAccount,
    filters: {
      searchQuery?: string;
      status?: ContractStatus[];
      location_count_ranges?: [number, number][];
      vendors?: string[];
      locations?: string[];
      owners_or_approvers?: string[];
      current_term_end_date?: [string | undefined, string | undefined];
    },
    limit?: number,
    offset?: number,
    orderBy?: Partial<Record<keyof Contract, "asc" | "desc">>[]
  ) {
    type QueryResult = {
      total_count: number;
      rows: (Contract & {
        vendor_name: string;
        line_items_count: number;
        contracted_locations_count: number;
        annual_value: number;
        contract_line_items: ContractLineItem[];
      })[];
    };

    const query = filters.searchQuery?.replace(/'/g, "''");
    // For archived screen, the total number of Line Items shown in the row should include all of the Line Items on the contract
    const contractLineItemStatus = !filters.status?.includes(ContractStatus.Canceled) ? "where cli.status = 'Active'" : "";
    // The total number of Locations shown in the row should include all Location that have ever had a line item assignment, regardless of when its line item assignment status changed
    const contractLineItemLocationStatus = !filters.status?.includes(ContractStatus.Canceled) ? "where clil.status != 'Canceled'" : "";

    const result = await this.db.$queryRawUnsafe<QueryResult[]>(`
    with contract_line_item_annual_values as (
      select 
        cli.id,
        cli.contract_id,
        (-- Price
          (CASE 
            WHEN cli.pricing_type = 'FlatRate' THEN cli.price
            WHEN cli.pricing_type = 'PerSeat' THEN cli.price * cli.seats_number
            WHEN cli.pricing_type = 'UsageBased' THEN cli.estimated_cost
            WHEN cli.pricing_type = 'PerLease' THEN cli.estimated_cost * count(l.id)
            WHEN cli.pricing_type = 'PerUnit' THEN cli.price * sum(l.unit_count)
            WHEN cli.pricing_type = 'PerLocation' THEN cli.price * count(l.id)
            WHEN cli.pricing_type = 'Itemized' THEN cli.price
            ELSE 1 END) *
        -- Cadence
          (CASE 
            WHEN cli.cadence = 'Monthly' THEN 12
            WHEN cli.cadence = 'Quarterly' THEN 4
            WHEN cli.cadence = 'Annual' THEN 1
            ELSE 1 END)
        ) as annual_value
      from 
        contract_line_item cli 
        join contract c on c.id=cli.contract_id
        left join contract_line_item_location clil on clil.contract_line_item_id=cli.id AND clil.status
        in ('${ContractLineItemLocationStatus.Active}', '${ContractLineItemLocationStatus.Pending}')
        left join location l on l.id=clil.location_id AND l.status in ('Active', 'Pending')
      ${contractLineItemStatus}
      group by cli.id
    ),
    contract_annual_values as (
      select 
        c.*,
        coalesce(sum(cliav.annual_value), 0) as annual_value,
        count(cliav.id)::int as line_items_count
      from 
        contract c 
        left join contract_line_item_annual_values cliav on cliav.contract_id=c.id
      group by c.id
    ),
    contract_locations_count as (
      select 
        c.id, 
        COUNT(distinct l.id)::int as contracted_locations_count 
  		from 
        location l
        inner join contract_line_item_location clil on clil.location_id=l.id
        inner join contract_line_item cli on cli.id=clil.contract_line_item_id
        inner join contract c on c.id=cli.contract_id 
      ${contractLineItemLocationStatus}
      group by c.id
    ),
    contract_line_items as (
      select
        c.id as contract_id,
        json_agg(cli.*) as line_items
      from
        contract c
        left join contract_line_item cli on cli.contract_id=c.id
      group by c.id
    ),
    contracts as (
      select 
        cav.*, 
        (CASE
          WHEN clc.contracted_locations_count IS NULL THEN 0
          ELSE clc.contracted_locations_count
        END) as contracted_locations_count,
        v.name as vendor_name,
        cli.line_items as contract_line_items
      from 
        contract_annual_values cav 
        left join manager_account_vendor mav on cav.manager_account_vendor_id=mav.id
        left join vendor v on v.id=mav.vendor_id
        left join contract_line_items cli on cli.contract_id=cav.id
        left join contract_locations_count clc on clc.id=cav.id
      where 
        mav.manager_account_id='${managerAccount.id}'::uuid
        ${generateContractsRawPermissionsQuery({
          user,
          managerAccount,
          alias: {
            contract: "cav",
          },
          queryConfig: {
            prefix: "AND",
          },
        })}
        ${
          filters.searchQuery
            ? `AND (cav.name ILIKE '%${query}%' OR v.name ILIKE '%${query}%')`
            : ""
        }
        ${
          filters.status
            ? `AND cav.status::text IN ('${filters.status.join("','")}')`
            : ""
        }
        ${
          filters.location_count_ranges
            ? `AND (${filters.location_count_ranges
                .map(
                  range =>
                    `clc.contracted_locations_count >= ${range[0]} AND clc.contracted_locations_count <= ${range[1]}`
                )
                .join(" OR ")})`
            : ""
        }
        ${
          filters.vendors
            ? `AND v.id IN ('${filters.vendors.join("','")}')`
            : ""
        }
        ${
          filters.locations
            ? `AND (
                EXISTS (
                  SELECT * 
                  FROM 
                    contract_line_item cli 
                    INNER JOIN contract_line_item_location clil 
                      ON clil.contract_line_item_id=cli.id
                    WHERE 
                      cli.contract_id=cav.id 
                      AND clil.location_id IN ('${filters.locations.join(
                        "','"
                      )}')
                )
                OR
                cav.location_id IN ('${filters.locations.join("','")}')
              )`
            : ""
        }
        ${
          filters.owners_or_approvers
            ? `AND cav.contract_owner_name::text IN ('${filters.owners_or_approvers.join(
                "','"
              )}') OR cav.approver::text IN ('${filters.owners_or_approvers.join(
                "','"
              )}')`
            : ""
        }
        ${
          filters.current_term_end_date?.[0]
            ? `AND cav.current_term_end_date >= '${filters.current_term_end_date[0]}'`
            : ""
        }
        ${
          filters.current_term_end_date?.[1]
            ? `AND cav.current_term_end_date <= '${filters.current_term_end_date[1]}'`
            : ""
        }
    )
    SELECT 
      (SELECT count(*)::int FROM contracts) as total_count,
      (
        SELECT json_agg(mav.*) FROM (
          SELECT * FROM contracts
					${this.constructOrderByClause(orderBy)}
          ${limit ? `LIMIT ${limit}` : ""}
          ${offset ? `OFFSET ${offset}` : ""}
        ) as mav
      ) as rows
    `);

    return result[0];
  }

  constructOrderByClause(
    orderBy?: Partial<Record<keyof Contract, "asc" | "desc">>[]
  ) {
    if (!orderBy || orderBy.length === 0) {
      return "";
    }

    const orderByString = orderBy
      .map(item => {
        const [key, value] = Object.entries(item)[0];
        return `${key} ${value}`;
      })
      .join(", ");

    return `ORDER BY ${orderByString}`;
  }

  async getAccountDepartmentList(
    accountId: string,
    filters: { query?: string }
  ) {
    type QueryResult = {
      department: string;
    };

    const query = `%${filters.query?.toLocaleLowerCase() ?? ""}%`;

    const result = await this.db.$queryRaw<QueryResult[]>`
      with departments as (
        select
          clip.department
        from 
          contract_line_item_product clip
          inner join product p on p.id=clip.product_id
          inner join contract_line_item cli on cli.id=clip.contract_line_item_id
          inner join contract c on c.id=cli.contract_id
          inner join manager_account_vendor mav on 
            mav.id=c.manager_account_vendor_id
            AND mav.manager_account_id=${accountId}::uuid
        union all
        select 
          clif.department
        from 
          contract_line_item_fee clif
          inner join fee f on f.id=clif.fee_id
          inner join contract_line_item cli on cli.id=clif.contract_line_item_id
          inner join contract c on c.id=cli.contract_id
          inner join manager_account_vendor mav on 
            mav.id=c.manager_account_vendor_id
            AND mav.manager_account_id=${accountId}::uuid
      )
      select distinct department 
      from departments
      where LOWER(department) LIKE LOWER(${query})
    `;

    return result;
  }

  async getSpendByLocationReportData(
    user: PermissionUser,
    account: ManagerAccount,
    filters: {
      searchQuery?: string;
      locations?: string[];
      regions?: string[];
      owners?: string[];
    } = {}
  ) {
    type QueryResult = {
      locations: {
        id: string;
        name: string;
        vendors_count: number;
        contracts_count: number;
        line_items_count: number;
        annual_value: number;
        unit_annual_value: number | null;
      }[];
      totals: {
        vendors_count: number;
        contracts_count: number;
        line_items_count: number;
        annual_value: number;
        unit_annual_value: number | null;
      }[];
    };

    const query = filters.searchQuery?.replace(/'/g, "''");

    // Replace single quotes with double quotes to avoid issues with quotes in the query
    const owners = filters.owners?.map(owner => owner.replace(/'/g, "''"));
    const regions = filters.regions?.map(region => region.replace(/'/g, "''"));

    const result = await this.db.$queryRawUnsafe<QueryResult[]>(`
    with contract_line_item_annual_values as (
      select 
        cli.id,
        cli.contract_id,
        cli.pricing_type,
        count(l.id) as location_count,
        coalesce(sum(l.unit_count), 0) as unit_count,
        mav.vendor_id as vendor_id,
        (-- Price
          (CASE 
            WHEN cli.pricing_type = 'FlatRate' THEN cli.price 
            WHEN cli.pricing_type = 'PerSeat' THEN cli.price * cli.seats_number
            WHEN cli.pricing_type = 'UsageBased' THEN cli.estimated_cost
            WHEN cli.pricing_type = 'PerLease' THEN cli.estimated_cost
            WHEN cli.pricing_type = 'PerUnit' THEN cli.price
            WHEN cli.pricing_type = 'PerLocation' THEN cli.price
            ELSE 1 END) *
        -- Cadence
          (CASE 
            WHEN cli.cadence = 'Monthly' THEN 12
            WHEN cli.cadence = 'Quarterly' THEN 4
            WHEN cli.cadence = 'Annual' THEN 1
            ELSE 1 END)
        ) as annual_value
      from 
        contract_line_item cli 
        join contract c on c.id=cli.contract_id
        left join contract_line_item_location clil on clil.contract_line_item_id=cli.id AND clil.status
        in ('${ContractLineItemLocationStatus.Active}', '${ContractLineItemLocationStatus.Pending}')
        left join location l on l.id=clil.location_id AND l.status in ('Active', 'Pending')
        left join manager_account_vendor mav on c.manager_account_vendor_id=mav.id
        left join manager_account ma on ma.id=mav.manager_account_id AND ma.id='${
          account.id
        }'::uuid
      where
        cli.status = 'Active'
        ${generateContractsRawPermissionsQuery({
          user,
          managerAccount: account,
          alias: {
            contract: "c",
          },
          queryConfig: {
            prefix: "AND",
          },
        })}
      group by cli.id, mav.vendor_id
    ),
    location_annual_values as (
      select 
        l.id,
        l.name,
        count(distinct cliav.vendor_id)::int as vendors_count,
        count(distinct cliav.contract_id)::int as contracts_count,
        count(distinct cliav.id)::int as line_items_count,
        coalesce(sum(
          CASE 
            WHEN cliav.pricing_type = 'PerUnit' THEN cliav.annual_value * l.unit_count
            WHEN cliav.pricing_type IN ('PerLocation', 'PerLease') THEN cliav.annual_value
            WHEN cliav.location_count > 0 THEN cliav.annual_value / cliav.location_count
            ELSE 0
          END
        ), 0) as annual_value,
        coalesce(sum(
          CASE 
            WHEN cliav.pricing_type = 'PerUnit' THEN cliav.annual_value
            WHEN cliav.pricing_type IN ('PerLocation', 'PerLease') AND l.unit_count > 0 THEN cliav.annual_value / l.unit_count
            WHEN cliav.location_count > 0 AND l.unit_count > 0 THEN (cliav.annual_value / cliav.location_count) / l.unit_count
            ELSE 0
          END
        ), 0) as unit_annual_value
      from 
        location l
        left join contract_line_item_location clil on clil.location_id=l.id
        left join contract_line_item_annual_values cliav on cliav.id=clil.contract_line_item_id
      where
        l.manager_account_id='${account.id}'::uuid
        AND l.status in ('Active', 'Pending')
        ${filters.searchQuery ? `AND (l.name ILIKE '%${query}%')` : ""}
        ${
          filters.locations
            ? `AND l.id IN ('${filters.locations.join("','")}')`
            : ""
        }
        ${regions ? `AND l.region IN ('${regions.join("','")}')` : ""}
        ${owners ? `AND l.owner_name IN ('${owners.join("','")}')` : ""}
      group by l.id
      order by l.name
    ),
    total_annual_values as (
      select 
        count(distinct cliav.vendor_id)::int as vendors_count,
        count(distinct cliav.contract_id)::int as contracts_count,
        count(distinct cliav.id)::int as line_items_count,
        coalesce(sum(
          CASE 
            WHEN cliav.pricing_type = 'PerUnit' THEN cliav.annual_value * l.unit_count
            WHEN cliav.pricing_type IN ('PerLocation', 'PerLease') THEN cliav.annual_value
            WHEN cliav.location_count > 0 THEN cliav.annual_value / cliav.location_count
            ELSE 0
          END
        ), 0) as annual_value,
        coalesce(sum(
          CASE 
            WHEN cliav.pricing_type = 'PerUnit' THEN cliav.annual_value
            WHEN cliav.pricing_type IN ('PerLocation', 'PerLease') AND cliav.unit_count > 0 THEN cliav.annual_value / cliav.unit_count
            WHEN cliav.location_count > 0 AND cliav.unit_count > 0 THEN (cliav.annual_value / cliav.location_count) / cliav.unit_count
            ELSE 0
          END
        ), 0) as unit_annual_value
      from
        manager_account ma
        inner join location l on l.manager_account_id=ma.id
        left join contract_line_item_location clil on clil.location_id=l.id
        left join contract_line_item_annual_values cliav on cliav.id=clil.contract_line_item_id
        left join contract c on c.id=cliav.contract_id
      where
        ma.id='${account.id}'::uuid
        AND l.status in ('Active', 'Pending')
        ${filters.searchQuery ? `AND (l.name ILIKE '%${query}%')` : ""}
        ${
          filters.locations
            ? `AND l.id IN ('${filters.locations.join("','")}')`
            : ""
        }
        ${
          regions
            ? `AND l.region IN ('${regions.join("','")}')`
            : ""
        }
        ${
          owners
            ? `AND l.owner_name IN ('${owners.join("','")}')`
            : ""
        }
      group by ma.id
    )
    select 
      (
        select 
          json_agg(lav.*) as locations 
        from location_annual_values lav
      ) as locations,
      (
        select 
          json_agg(tav.*) 
        from total_annual_values tav
      ) as totals
  `);

    return {
      locations: result[0].locations ?? [],
      totals: result[0].totals?.[0] ?? {
        vendors_count: 0,
        contracts_count: 0,
        line_items_count: 0,
        annual_value: 0,
        unit_annual_value: null,
      },
    };
  }

  async updateManagerAccount(
    accountId: string,
    data: Prisma.ManagerAccountUpdateInput
  ) {
    return this.db.managerAccount.update({
      where: { id: accountId },
      data,
    });
  }

  async getTaskOwnerOptions(accountId: string) {
    const managerAccountRoles = await this.db.managerAccountRole.findMany({
      where: {
        manager_account_id: accountId,
        deleted_at: null,
        role: {
          in: [ManagerAccountRoleType.Owner, ManagerAccountRoleType.Editor]
        }
      },
      include: {
        user: true,
      },
    });

    const options = managerAccountRoles.map(mar => ({
      value: mar.id,
      label: `${mar.user.first_name} ${mar.user.last_name} - ${mar.user.email}`,
    }));

    return options;
  }

  async getLocationsForUser(accountId: string, user: PermissionUser) {
    const locationIds = getLocationIdsForUser(user, { id: accountId }, [
      Permission.ViewLocationDetails,
    ]);

    const locations = await this.db.location.findMany({
      where: {
        manager_account_id: accountId,
        id: locationIds === "all" ? undefined : { in: locationIds },
      },
      orderBy: {
        name: "asc",
      },
    });

    return locations;
  }
}
