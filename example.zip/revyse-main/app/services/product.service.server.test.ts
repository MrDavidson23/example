import { faker } from "@faker-js/faker";
import {
  ProductState,
  Role,
  SubscriptionStatus,
  Tier,
  UserRoleType,
  VendorState,
} from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { slugify } from "../utils/string.utils";
import { withFixtureFactory } from "../utils/test.utils.server";
import { sortBy } from "lodash";
import { createTestUser } from "./seeds/createTestUser";
import { ProductSubscriptionActiveStatuses } from "../utils/product-subscription.utils.server";

const generateProduct = (title: string) => ({
  title,
  description: "description",
  state: ProductState.discovery,
  approved_at: new Date(),
  page_title: "page title",
  positioning: "positioning",
  meta_description: "meta description",
});

const PRODUCTS = [
  generateProduct("Product A"),
  generateProduct("Product B"),
  generateProduct("Product C"),
  generateProduct("Product D"),
  generateProduct("Product E"),
  generateProduct("Product F"),
];

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { authService } = TestDIContainer(tx);

    const user = await createTestUser(faker.internet.email(), authService);

    const category = await tx.productCategory.create({
      data: {
        name: faker.company.name(),
        description: "description",
        slug: "category",
        faq_1: "faq 1",
        faq_2: "faq 2",
        faq_3: "faq 3",
        faq_1_answer: "faq 1 answer",
        faq_2_answer: "faq 2 answer",
        faq_3_answer: "faq 3 answer",
        meta_description: "meta description",
        page_title: "page title",
      },
    });

    const vendor = await tx.vendor.create({
      data: {
        slug: faker.internet.url(),
        name: faker.company.name(),
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
      },
    });
    const adminUser = await tx.user.create({
      data: {
        email: faker.internet.email(),
        first_name: "first",
        last_name: "last",
        company_name: "company",
        phone: "phone",
        title: "title",
        user_roles: {
          create: {
            type: UserRoleType.GLOBAL,
            role: Role.GOD_MODE,
          },
        },
      },
      include: {
        user_roles: true,
      },
    });

    const stripeProduct = await tx.stripeProduct.create({
      data: {
        id: `prod_${faker.string.uuid()}`,
        name: "product",
        active: true,
        tier: Tier.tier_3,
        description: "product",
      },
    });

    const stripePrice = await tx.stripePrice.create({
      data: {
        id: `price_${faker.string.uuid()}`,
        product: { connect: { id: stripeProduct.id } },
        active: true,
        cadence: "monthly",
        price: 1000,
      },
    });

    const product = await tx.product.create({
      data: {
        title:
          faker.commerce.productName() + " " + faker.string.alphanumeric(5),
        description: "description",
        state: ProductState.discovery,
        approved_at: new Date(),
        slug: slugify(faker.commerce.productName()),
        page_title: "page title",
        positioning: "positioning",
        meta_description: "meta description",
        vendor: {
          connect: {
            id: vendor.id,
          },
        },
        primary_category: {
          create: {
            name: `${faker.commerce.department()} ${faker.string.alphanumeric(
              5
            )}`,
            description: "description",
            slug: "category",
            faq_1: "faq 1",
            faq_2: "faq 2",
            faq_3: "faq 3",
            faq_1_answer: "faq 1 answer",
            faq_2_answer: "faq 2 answer",
            faq_3_answer: "faq 3 answer",
            meta_description: "meta description",
            page_title: "page title",
            primary_vendor_type: "Test Vendor Type",
          },
        },
        subscriptions: {
          createMany: {
            data: [
              {
                stripe_id: `sub_${faker.string.uuid()}`,
                status: SubscriptionStatus.active,
                stripe_price_id: stripePrice.id,
              },
            ],
          },
        },
        reviews: {
          create: {
            approved_at: faker.date.past(),
            approved_by: {
              connect: {
                id: user.id,
              },
            },
            compatibility_score: 5,
            customer_service_score: 5,
            onboarding_score: 5,
            value_score: 5,
            compatibility_desc: faker.lorem.sentence(),
            customer_service_desc: faker.lorem.sentence(),
            decision_maker: faker.person.firstName(),
            dislike_most: faker.lorem.sentence(),
            like_most: faker.lorem.sentence(),
            onboarding_desc: faker.lorem.sentence(),
            primary_use_case: faker.lorem.sentence(),
            recommend_to: faker.lorem.sentence(),
            show_company: faker.datatype.boolean(),
            show_job_title: faker.datatype.boolean(),
            show_last_name: faker.datatype.boolean(),
            user: { connect: { id: user.id } },
            value_desc: faker.lorem.sentence(),
          },
        },
        features: {
          create: [
            {
              name: "feature 1",
              description: "description",
              order: 1,
            },
            {
              name: "feature 2",
              description: "description",
              order: 2,
            },
          ],
        },
        industries: {
          create: [
            {
              name: `${faker.commerce.department()} ${faker.string.alphanumeric(
                5
              )}`,
              description: "description",
              slug: slugify(
                `${faker.commerce.department()} ${faker.string.alphanumeric(5)}`
              ),
            },
            {
              name: `${faker.commerce.department()} ${faker.string.alphanumeric(
                5
              )}`,
              description: "description",
              slug: slugify(
                `${faker.commerce.department()} ${faker.string.alphanumeric(5)}`
              ),
            },
          ],
        },
        image_files: {
          create: [
            {
              title: "image",
              uri: "uri",
              mime_type: "mime_type",
              size_kb: 100,
            },
            {
              title: "image 2",
              uri: "uri",
              mime_type: "mime_type",
              size_kb: 200,
            },
          ],
        },
      },
      include: {
        features: {
          orderBy: { order: "asc" },
        },
        industries: {
          orderBy: { name: "asc" },
        },
        good_for_tags: {
          orderBy: { name: "asc" },
        },
        packages: {
          orderBy: { order: "asc" },
        },
        image_files: true,
        brand_video_files: true,
        download_files: true,
        demo_files: true,
        banner_file: true,
        logo_file: true,
        vendor: true,
        subscriptions: {
          where: {
            status: {
              in: ProductSubscriptionActiveStatuses,
            },
          },
          include: {
            stripe_price: {
              include: { product: true },
            },
          },
          orderBy: { created_at: "desc" },
        },
      },
    });

    const products = await Promise.all(
      PRODUCTS.map(p =>
        tx.product.create({
          data: {
            ...p,
            slug: slugify(p.title),
            primary_category: {
              connect: {
                id: category.id,
              },
            },
            vendor: {
              connect: {
                id: vendor.id,
              },
            },
            reviews: {
              create: {
                approved_at: faker.date.past(),
                approved_by: {
                  connect: {
                    id: user.id,
                  },
                },
                compatibility_score: faker.number.int({ min: 2, max: 5 }),
                customer_service_score: faker.number.int({ min: 2, max: 5 }),
                onboarding_score: faker.number.int({ min: 2, max: 5 }),
                value_score: faker.number.int({ min: 2, max: 5 }),
                compatibility_desc: faker.lorem.sentence(),
                customer_service_desc: faker.lorem.sentence(),
                decision_maker: faker.person.firstName(),
                dislike_most: faker.lorem.sentence(),
                like_most: faker.lorem.sentence(),
                onboarding_desc: faker.lorem.sentence(),
                primary_use_case: faker.lorem.sentence(),
                recommend_to: faker.lorem.sentence(),
                show_company: faker.datatype.boolean(),
                show_job_title: faker.datatype.boolean(),
                show_last_name: faker.datatype.boolean(),
                user: { connect: { id: user.id } },
                value_desc: faker.lorem.sentence(),
              },
            },
          },
        })
      )
    );

    const notPublishedProduct = await tx.product.create({
      data: {
        title: `${faker.commerce.product()} ${faker.string.alphanumeric(6)}`,
        description: "description",
        slug: slugify(
          `${faker.commerce.product()} ${faker.string.alphanumeric(6)}`
        ),
        page_title: "page title",
        positioning: "positioning",
        meta_description: "meta description",
        primary_category_id: category.id,
        vendor_id: vendor.id,
      },
    });

    const secondaryCategoryProduct = await tx.product.create({
      data: {
        title: `${faker.commerce.product()} ${faker.string.alphanumeric(6)}`,
        description: "description",
        slug: slugify(
          `${faker.commerce.product()} ${faker.string.alphanumeric(6)}`
        ),
        page_title: "page title",
        positioning: "positioning",
        meta_description: "meta description",
        state: ProductState.discovery,
        primary_category: {
          create: {
            name: `${faker.commerce.department()} ${faker.string.alphanumeric(
              5
            )}`,
            description: "description",
            slug: "category",
            faq_1: "faq 1",
            faq_2: "faq 2",
            faq_3: "faq 3",
            faq_1_answer: "faq 1 answer",
            faq_2_answer: "faq 2 answer",
            faq_3_answer: "faq 3 answer",
            meta_description: "meta description",
            page_title: "page title",
          },
        },
        reviews: {
          create: {
            approved_at: faker.date.past(),
            approved_by: {
              connect: {
                id: user.id,
              },
            },
            compatibility_score: faker.number.int({ min: 2, max: 5 }),
            customer_service_score: faker.number.int({ min: 2, max: 5 }),
            onboarding_score: faker.number.int({ min: 2, max: 5 }),
            value_score: faker.number.int({ min: 2, max: 5 }),
            compatibility_desc: faker.lorem.sentence(),
            customer_service_desc: faker.lorem.sentence(),
            decision_maker: faker.person.firstName(),
            dislike_most: faker.lorem.sentence(),
            like_most: faker.lorem.sentence(),
            onboarding_desc: faker.lorem.sentence(),
            primary_use_case: faker.lorem.sentence(),
            recommend_to: faker.lorem.sentence(),
            show_company: faker.datatype.boolean(),
            show_job_title: faker.datatype.boolean(),
            show_last_name: faker.datatype.boolean(),
            user: { connect: { id: user.id } },
            value_desc: faker.lorem.sentence(),
          },
        },
        secondary_category: { connect: { id: category.id } },
        vendor: { connect: { id: vendor.id } },
      },
    });

    return {
      adminUser,
      product,
      products,
      vendor,
      category,
      notPublishedProduct,
      secondaryCategoryProduct,
    };
  },
});

describe("ProductService", () => {
  describe("getReviewedProductWithSubscriptions", () => {
    it(
      "should get reviewed product with subscriptions",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);
        const testProduct =
          await productService.getReviewedProductWithSubscriptions(
            product.slug
          );

        expect(testProduct).not.toBeNull();
        expect(testProduct?.subscriptions).toBeDefined();
        expect(testProduct?.subscriptions).toStrictEqual(product.subscriptions);
      })
    );
  });

  describe("getProductsForPrimaryCategory", () => {
    it(
      "should get products that have their primary_category_id set to the given categoryId",
      withFixtures(
        async ({ products, secondaryCategoryProduct, category }, tx) => {
          const { productService } = TestDIContainer(tx);
          const testProducts =
            await productService.getProductsForPrimaryCategory({
              categoryId: category.id,
              take: 10,
            });

          expect(testProducts).not.toBeNull();

          expect(testProducts.map(product => product.id)).not.toEqual(
            expect.arrayContaining([secondaryCategoryProduct.id])
          );
          expect(testProducts.map(product => product.id)).toEqual(
            expect.arrayContaining(products.map(product => product.id))
          );
        }
      )
    );
  });

  describe("getProductsWithRatings", () => {
    it(
      "should get products with ratings by product ids",
      withFixtures(async (_, tx) => {
        const { productService } = TestDIContainer(tx);

        const productIds = (
          await tx.product.findMany({
            select: { id: true },
            where: {
              state: ProductState.discovery,
            },
          })
        ).map(p => p.id);

        const productWithRatings = await productService.getProductsWithRatings({
          ids: productIds,
        });

        expect(productWithRatings.map(product => product.tier)).toBeDefined();
        expect(
          productWithRatings.map(product => product.totalReviews)
        ).toBeDefined();
        expect(
          productWithRatings.map(product => product.totalReviews).length
        ).toBeGreaterThan(0);
        expect(
          productWithRatings.map(product => product.avgReview)
        ).toBeDefined();
        expect(
          productWithRatings.map(product => product.subCount)
        ).toBeDefined();
      })
    );
  });

  describe("getProductsMostLoved", () => {
    it(
      "should get most loved products",
      withFixtures(
        async ({ product, category, secondaryCategoryProduct }, tx) => {
          const { productService } = TestDIContainer(tx);

          const productWithRatings = await productService.getProductsMostLoved({
            take: 10,
            categories: [
              product.primary_category_id,
              category.id,
              secondaryCategoryProduct.secondary_category_id!,
            ],
          });

          expect(productWithRatings.map(product => product.tier)).toBeDefined();
          expect(
            productWithRatings.map(product => product.industry_ids)
          ).toBeDefined();
          expect(
            productWithRatings.map(product => product.industry_ids).length
          ).toBeGreaterThan(0);

          // Expect product to be the first in the array since has tier 3 and 5 stars review
          expect(productWithRatings[0].id).toEqual(product.id);
        }
      )
    );
  });

  describe("getProductBySlug", () => {
    it(
      "should get a product by slug",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);
        const testProduct = await productService.getProductBySlug({
          slug: product.slug,
        });

        expect(testProduct).not.toBeNull();
        expect(testProduct?.vendor).not.toBeNull();
        expect(testProduct?.primary_category).not.toBeNull();
        expect(testProduct?.industries).not.toBeNull();
        expect(testProduct?.features).not.toBeNull();
      })
    );
  });

  describe("deleteProduct", () => {
    it(
      "should return an error when trying to delete a product with subscriptions",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);

        await expect(productService.deleteProduct(product.id)).rejects.toThrow(
          "Cannot delete listing with subscriptions"
        );
      })
    );

    it(
      "should delete a product",
      withFixtures(async ({ notPublishedProduct }, tx) => {
        const { productService } = TestDIContainer(tx);
        await productService.deleteProduct(notPublishedProduct.id);

        const deletedProduct = await tx.product.findFirst({
          where: {
            id: notPublishedProduct.id,
          },
        });

        expect(deletedProduct).toBeNull();
      })
    );
  });

  describe("getProductIncludingAllFields", () => {
    it(
      "should get all the products with filters",
      withFixtures(async ({ products }, tx) => {
        const { productService } = TestDIContainer(tx);

        const filteredProducts = await productService.getProducts({
          where: {
            title: { contains: "Product", mode: "insensitive" },
          },
          orderBy: [{ title: "asc" }],
          take: 5,
          skip: 2,
        });

        const expected = sortBy(products, "title")
          .slice(2, 7)
          .map(product => expect.objectContaining(product));

        expect(filteredProducts).toEqual(expect.arrayContaining(expected));
      })
    );
  });
  describe("getProductIncludingAllFields", () => {
    it(
      "should get a product with all fields",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);

        const productWithAllFields =
          await productService.getProductIncludingAllFields(product.id);

        expect(productWithAllFields?.title).toBe(product.title);
        expect(productWithAllFields?.description).toBe(product.description);
        expect(productWithAllFields?.positioning).toBe(product.positioning);
        expect(productWithAllFields?.primary_category_id).toBe(
          product.primary_category_id
        );
        expect(productWithAllFields?.lead_prospect_email).toBe(
          product.lead_prospect_email
        );
        expect(productWithAllFields?.demo_scheduling_url).toBe(
          product.demo_scheduling_url
        );
        expect(productWithAllFields?.demo_storylane_url).toBe(
          product.demo_storylane_url
        );
        expect(productWithAllFields?.banner_file_id).toBe(
          product.banner_file_id
        );
        expect(productWithAllFields?.logo_file_id).toBe(product.logo_file_id);
        expect(productWithAllFields?.image_files).toEqual(product.image_files);
        expect(productWithAllFields?.brand_video_files).toEqual(
          product.brand_video_files
        );
        expect(productWithAllFields?.download_files).toEqual(
          product.download_files
        );
        expect(productWithAllFields?.demo_files).toEqual(product.demo_files);
        expect(productWithAllFields?.features).toEqual(product.features);
        expect(productWithAllFields?.industries).toEqual(product.industries);
        expect(productWithAllFields?.good_for_tags).toEqual(
          product.good_for_tags
        );
        expect(productWithAllFields?.packages).toEqual(product.packages);
      })
    );

    it(
      "should return null if product is not found",
      withFixtures(async (_, tx) => {
        const { productService } = TestDIContainer(tx);

        const productWithAllFields =
          await productService.getProductIncludingAllFields(
            faker.string.uuid()
          );

        expect(productWithAllFields).toBeNull();
      })
    );
  });

  describe("updateProduct", () => {
    it(
      "should update a product",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);

        const data = {
          title: faker.commerce.productName(),
          description: faker.commerce.productDescription(),
          positioning: "positioning",
          primary_category_id: product.primary_category_id,
          lead_prospect_email: null,
          demo_scheduling_url: null,
          demo_storylane_url: null,
          image_files: [],
          brand_video_files: [],
          brand_video_titles: [],
          brand_video_urls: [],
          download_files: [],
          demo_files: [],
          features: [
            {
              name: "feature updated 1",
              description: "description updated 1",
              order: 1,
            },
            {
              name: "feature updated 2",
              description: "description updated 2",
              order: 2,
            },
          ],
          industries: [],
          good_for_tags: [],
          packages: [],
          review_questions: [],
          slug: slugify(faker.commerce.productName()),
          promo_text: null,
        };

        await productService.updateProduct(product.id, data);

        const updatedProduct =
          await productService.getProductIncludingAllFields(product.id);

        if (!updatedProduct) {
          throw new Error("Product not found");
        }

        expect(updatedProduct.title).toBe(data.title);
        expect(updatedProduct.description).toBe(data.description);
        expect(updatedProduct.positioning).toBe("positioning");
        expect(updatedProduct.primary_category_id).toBe(
          product.primary_category_id
        );
        expect(updatedProduct.features).toMatchObject(data.features);
        expect(updatedProduct.industries).toEqual([]);
      })
    );

    it(
      "should return null if product is not found",
      withFixtures(async (_, tx) => {
        const { productService } = TestDIContainer(tx);

        const data = {
          title: faker.commerce.productName(),
          description: faker.commerce.productDescription(),
          positioning: "positioning",
          primary_category_id: faker.string.uuid(),
          lead_prospect_email: null,
          demo_scheduling_url: null,
          demo_storylane_url: null,
          image_files: [],
          brand_video_files: [],
          brand_video_titles: [],
          brand_video_urls: [],
          download_files: [],
          demo_files: [],
          features: [],
          industries: [],
          good_for_tags: [],
          packages: [],
          review_questions: [],
          slug: slugify(faker.commerce.productName()),
          promo_text: null,
        };

        await expect(
          productService.updateProduct(faker.string.uuid(), data)
        ).rejects.toThrowError();
      })
    );

    it(
      "should update a product brand_video_files",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);

        const newVideoFiles = [
          await tx.file.create({
            data: {
              title: "video",
              uri: "uri",
              mime_type: "mime_type",
              size_kb: 100,
            },
          }),
          await tx.file.create({
            data: {
              title: "video 2",
              uri: "uri",
              mime_type: "mime_type",
              size_kb: 200,
            },
          }),
        ];

        const newVideoFilesIds = newVideoFiles.map(file => file.id);

        const brandVideoTitles = newVideoFiles.map((file, index) => ({
          id: file.id,
          title: `${faker.lorem.word()} ${index + 1}`,
        }));

        const data = {
          title: faker.commerce.productName(),
          description: faker.commerce.productDescription(),
          positioning: "positioning",
          primary_category_id: product.primary_category_id,
          lead_prospect_email: null,
          demo_scheduling_url: null,
          demo_storylane_url: null,
          image_files: [],
          brand_video_files: newVideoFilesIds,
          brand_video_titles: brandVideoTitles,
          brand_video_urls: [],
          download_files: [],
          demo_files: [],
          features: [],
          industries: [],
          good_for_tags: [],
          packages: [],
          review_questions: [],
          slug: slugify(faker.commerce.productName()),
          promo_text: null,
        };

        await productService.updateProduct(product.id, data);

        const updatedProduct =
          await productService.getProductIncludingAllFields(product.id);

        if (!updatedProduct) {
          throw new Error("Product not found");
        }

        expect(updatedProduct.title).toBe(data.title);
        expect(updatedProduct.brand_video_files).toMatchObject(
          brandVideoTitles
        );
      })
    );
  });

  describe("upsertProductFromAdmin", () => {
    it(
      "should update or create a product thru the admin side",
      withFixtures(async ({ adminUser, product, vendor, category }, tx) => {
        const { productService } = TestDIContainer(tx);
        //Update product
        const productTitle = faker.commerce.productName();
        const productDescription = faker.commerce.productDescription();

        const updatedProduct = await productService.upsertProductFromAdmin(
          product.id,
          { id: adminUser.id },
          {
            title: productTitle,
            description: productDescription,
            vendor_id: vendor.id,
            primary_category_id: category.id,
            slug: slugify(productTitle),
            state: ProductState.discovery,
          }
        );

        expect(updatedProduct.title).toBe(productTitle);
        expect(updatedProduct.description).toBe(productDescription);
        expect(updatedProduct.primary_category_id).toBe(category.id);
        expect(updatedProduct.vendor_id).toBe(vendor.id);
        expect(updatedProduct.state).toBe(ProductState.discovery);

        //Create product
        const newProductTitle = faker.commerce.productName();
        const newProductDescription = faker.commerce.productDescription();

        const createdProduct = await productService.upsertProductFromAdmin(
          "new",
          { id: adminUser.id },
          {
            title: newProductTitle,
            description: newProductDescription,
            vendor_id: vendor.id,
            primary_category_id: category.id,
            slug: slugify(newProductTitle),
            state: ProductState.discovery,
          }
        );

        expect(createdProduct.title).toBe(newProductTitle);
        expect(createdProduct.description).toBe(newProductDescription);
        expect(createdProduct.primary_category_id).toBe(category.id);
        expect(createdProduct.vendor_id).toBe(vendor.id);
        expect(createdProduct.state).toBe(ProductState.discovery);
      })
    );
  });

  describe("getCategoryOptions", () => {
    it(
      "should return all categories",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);

        const categories = await productService.getCategoryOptions();

        expect(categories.length).toBeGreaterThan(0);
        expect(
          categories.some(
            category => category.id === product.primary_category_id
          )
        ).toBeTruthy();
      })
    );
  });

  describe("getIndustryOptions", () => {
    it(
      "should return all industries",
      withFixtures(async (_, tx) => {
        const { productService } = TestDIContainer(tx);

        const industry = await tx.industry.create({
          data: {
            name: `${faker.commerce.department()} ${faker.string.alphanumeric(
              5
            )}`,
            description: "description",
            slug: slugify(
              `${faker.commerce.department()} ${faker.string.alphanumeric(5)}`
            ),
          },
        });

        const industries = await productService.getIndustryOptions();

        expect(industries.length).toBeGreaterThan(0);
        expect(industries.some(i => i.id === industry.id)).toBeTruthy();
      })
    );
  });

  describe("getGoodForTagOptions", () => {
    it(
      "should return all good for tags",
      withFixtures(async (_, tx) => {
        const { productService } = TestDIContainer(tx);

        const goodForTag = await tx.goodForTag.create({
          data: {
            name: `${faker.commerce.department()} ${faker.string.alphanumeric(
              5
            )}`,
            description: "description",
            slug: slugify(
              `${faker.commerce.department()} ${faker.string.alphanumeric(5)}`
            ),
          },
        });

        const goodForTags = await productService.getGoodForTagOptions();

        expect(goodForTags.length).toBeGreaterThan(0);
        expect(goodForTags.some(i => i.id === goodForTag.id)).toBeTruthy();
      })
    );
  });

  describe("getProductsByCategoryVendorType", () => {
    it(
      "should return products by category vendor type",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);

        const products = await productService.getProductsByCategoryVendorType(
          "Test Vendor Type"
        );

        expect(products.length).toBeGreaterThan(0);
        expect(products.some(p => p.id === product.id)).toBeTruthy();
      })
    );

    it(
      "should return products by category vendor type with limit",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);

        const newSupplierProduct = await tx.product.create({
          data: {
            title: faker.commerce.productName(),
            description: "description",
            state: ProductState.discovery,
            approved_at: new Date(),
            slug: slugify(faker.commerce.productName()),
            page_title: "page title",
            positioning: "positioning",
            meta_description: "meta description",
            primary_category: {
              create: {
                name: `${faker.commerce.department()} ${faker.string.alphanumeric(
                  5
                )}`,
                description: "description",
                slug: "category",
                faq_1: "faq 1",
                faq_2: "faq 2",
                faq_3: "faq 3",
                faq_1_answer: "faq 1 answer",
                faq_2_answer: "faq 2 answer",
                faq_3_answer: "faq 3 answer",
                meta_description: "meta description",
                page_title: "page title",
                primary_vendor_type: "Test Vendor Type",
              },
            },
          },
        });

        const products = await productService.getProductsByCategoryVendorType(
          "Test Vendor Type",
          1
        );

        expect(products.length).toBe(1);
        expect([product.id, newSupplierProduct.id]).toContain(products[0].id);
      })
    );
  });

  describe("getProductsForSearch", () => {
    it(
      "should return products for search by title",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);

        const products = await productService.getProductsForSearch(
          product.title
        );

        expect(products.length).toBeGreaterThan(0);
        expect(products.some(p => p.id === product.id)).toBeTruthy();
      })
    );

    it(
      "should return products for search by vendor name",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);

        const products = await productService.getProductsForSearch(
          product.vendor!.name
        );

        expect(products.length).toBeGreaterThan(0);
        expect(products.some(p => p.id === product.id)).toBeTruthy();
      })
    );
  });

  describe("getProductsCount", () => {
    it(
      "should return products count",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);

        const count = await productService.getProductsCount({
          where: {
            approved_at: { not: null },
            state: ProductState.discovery,
            title: { contains: product.title },
          },
        });

        expect(count).toBeGreaterThan(0);
      })
    );
  });

  describe("deleteProductFromAdmin", () => {
    it(
      "should delete a product",
      withFixtures(async ({ notPublishedProduct }, tx) => {
        const { productService } = TestDIContainer(tx);

        const response = await productService.deleteProductFromAdmin(
          notPublishedProduct.id
        );

        expect(response.success).toBeTruthy();
      })
    );
    it(
      "should return false when trying to delete a product that is published",
      withFixtures(async ({ product }, tx) => {
        const { productService } = TestDIContainer(tx);

        const response = await productService.deleteProductFromAdmin(
          product.id
        );

        expect(response.success).toBeFalsy();
      })
    );
  });
});
