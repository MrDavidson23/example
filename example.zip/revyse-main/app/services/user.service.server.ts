import type { Prisma, PrismaClient } from "@prisma/client";
import { Role, UserRoleType } from "@prisma/client";
import { isEmpty, isNil } from "lodash";
import * as crypto from "crypto";
import type { AuthService } from "./auth.service.server";
import type { NotificationService } from "./notification.service.server";

export class UserService {
  constructor(
    private db: PrismaClient,
    private authService: AuthService,
    private notificationService: NotificationService
  ) {}

  async getUsers({
    where,
    orderBy,
    take,
    skip,
  }: {
    where?: Prisma.UserWhereInput;
    orderBy?: Prisma.UserOrderByWithRelationInput;
    take?: number;
    skip?: number;
  }) {
    return this.db.user.findMany({
      where,
      orderBy,
      include: {
        user_roles: true,
        email_verification_tokens: {
          where: {
            verified_at: {
              not: null,
            },
          },
        },
      },
      skip,
      take,
    });
  }

  async getUsersCount({ where }: { where?: Prisma.UserWhereInput }) {
    return this.db.user.count({ where });
  }

  async getUserById({ id }: { id: string }) {
    return this.db.user.findFirst({
      where: { id },
      include: {
        user_roles: true,
        email_verification_tokens: {
          where: {
            verified_at: {
              not: null,
            },
          },
        },
      },
    });
  }

  async updateUser({ id, data }: { id: string; data: Prisma.UserUpdateInput }) {
    return await this.db.user.update({
      data,
      where: { id },
    });
  }

  async deleteUser({ id }: { id: string }) {
    return this.db.user.delete({
      where: { id },
    });
  }

  async getEmailVerificationToken(
    where: Prisma.EmailVerificationTokenWhereInput
  ) {
    return this.db.emailVerificationToken.findFirst({ where });
  }

  async updateUserPassword(userId: string, password: string | undefined) {
    await this.db.$transaction(async tx => {
      let password_hash = undefined;
      let password_salt = undefined;
      if (!isNil(password) && !isEmpty(password)) {
        password_salt = crypto.randomBytes(16).toString("hex");
        password_hash = crypto
          .pbkdf2Sync(password, password_salt, 1000, 64, `sha512`)
          .toString(`hex`);
      }

      await tx.userCredential.update({
        where: { user_id: userId },
        data: { password_hash, password_salt },
      });
    });
  }

  async updateUserProfile({
    id,
    data,
  }: {
    id: string;
    data: Prisma.UserUpdateInput;
  }) {
    return this.db.$transaction(async tx => {
      const user = await this.getUserById({ id });

      if (isNil(user)) {
        throw new Error("User not found");
      }

      await tx.user.update({
        data,
        where: { id },
      });

      if (
        !isEmpty(data.email) && // Check if email is being updated
        user.email !== data.email && // and if the email is different than the one in the database
        isEmpty(
          // and if the user has no verified email verification token for the new email
          user.email_verification_tokens.find(ev => ev.email === data.email)
        )
      ) {
        await this.authService.generateEmailVerificationEmailInTx(user.id, tx);
      }
    });
  }

  updateBuyerVerifiedUserRole({
    userId,
    verified,
  }: {
    userId: string;
    verified: boolean;
  }) {
    return this.db.$transaction(async tx => {
      const user = await tx.user.findFirstOrThrow({ where: { id: userId } });
      if (verified) {
        await tx.userRole.create({
          data: {
            user_id: user.id,
            resource_id: null,
            role: Role.BUYER,
            type: UserRoleType.GLOBAL,
          },
        });
        this.notificationService.sendBuyerVerifiedEmail(user.email);
      } else {
        await tx.userRole.deleteMany({
          where: {
            user_id: user.id,
            resource_id: null,
            role: Role.BUYER,
            type: UserRoleType.GLOBAL,
          },
        });
      }
    });
  }
}
