import { faker } from "@faker-js/faker";
import {
  ContractLineItemStatus,
  ContractStatus,
  LocationClass,
  LocationStatus,
  ManagerAccountRoleType,
  ManagerAccountVendorStatus,
  Prisma,
  ProductState,
  ResidentLifecyclePhase,
  Role,
  UserRoleType,
  VendorState,
} from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { withFixtureFactory } from "../utils/test.utils.server";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const managerAccountNames = [
      faker.company.name(),
      faker.company.name(),
      faker.company.name(),
    ];

    const managerAccounts = await Promise.all(
      managerAccountNames.map(name =>
        tx.managerAccount.create({
          data: {
            name,
          },
        })
      )
    );

    const userWithNoAccounts = await tx.user.create({
      data: {
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
        email: faker.internet.email(),
      },
      include: {
        user_roles: true,
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
          include: {
            location_roles: true,
          },
        },
      },
    });

    const userWith2ManagerAccounts = await tx.user.create({
      data: {
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
        email: faker.internet.email(),
        manager_account_roles: {
          createMany: {
            data: [
              {
                manager_account_id: managerAccounts[0].id,
                role: ManagerAccountRoleType.Owner,
              },
              {
                manager_account_id: managerAccounts[1].id,
                role: ManagerAccountRoleType.Editor,
              },
            ],
          },
        },
      },
      include: {
        user_roles: true,
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
          include: {
            location_roles: true,
          },
        },
      },
    });

    const userWithGodMode = await tx.user.create({
      data: {
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
        email: faker.internet.email(),
        user_roles: {
          create: {
            type: UserRoleType.GLOBAL,
            role: Role.GOD_MODE,
          },
        },
      },
      include: {
        user_roles: true,
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
          include: {
            location_roles: true,
          },
        },
      },
    });

    // Insert locations for manager accounts
    const managerAccountsLocations = await Promise.all(
      managerAccounts.map(async managerAccount => {
        const locationNames = [
          "Location 1",
          "Location 2",
          "Location 3",
          "Location 4",
          "Location 5",
        ];

        const locations = await Promise.all(
          locationNames.map(name =>
            tx.location.create({
              data: {
                name,
                pms_id: faker.string.alphanumeric(6),
                owner_name: faker.company.name(),
                street_1: faker.location.streetAddress(),
                street_2: faker.location.secondaryAddress(),
                city: faker.location.city(),
                state: faker.location.state(),
                zip: faker.location.zipCode(),
                unit_count: faker.number.int({ min: 1, max: 1000 }),
                class: faker.helpers.enumValue(LocationClass),
                status: LocationStatus.Active,
                manager_account_id: managerAccount.id,
                region: faker.location.city(),
              },
            })
          )
        );

        return locations;
      })
    );

    const category = await tx.productCategory.create({
      data: {
        name: faker.company.name(),
        description: "description",
        slug: "category",
        faq_1: "faq 1",
        faq_2: "faq 2",
        faq_3: "faq 3",
        faq_1_answer: "faq 1 answer",
        faq_2_answer: "faq 2 answer",
        faq_3_answer: "faq 3 answer",
        meta_description: "meta description",
        page_title: "page title",
        resident_lifecycle_phase: ResidentLifecyclePhase.Leasing,
      },
    });

    const vendor = await tx.vendor.create({
      data: {
        slug: faker.internet.url(),
        name: faker.company.name(),
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
        products: {
          createMany: {
            data: [
              {
                title: "Manager Account Service 1",
                description: "description",
                state: ProductState.discovery,
                approved_at: new Date(),
                slug: "manager-account-service-1",
                page_title: "page title",
                positioning: "positioning",
                meta_description: "meta description",
                primary_category_id: category.id,
              },
              {
                title: "Manager Account Service 2",
                description: "description",
                state: ProductState.discovery,
                approved_at: new Date(),
                slug: "manager-account-service-2",
                page_title: "page title",
                positioning: "positioning",
                meta_description: "meta description",
                primary_category_id: category.id,
              },
            ],
          },
        },
      },
      include: {
        products: true,
      },
    });

    const accountVendor = await tx.managerAccountVendor.upsert({
      where: {
        manager_account_id_vendor_id: {
          manager_account_id: managerAccounts[0].id,
          vendor_id: vendor.id,
        },
      },
      create: {
        manager_account: { connect: { id: managerAccounts[0].id } },
        vendor: { connect: { id: vendor.id } },
        status: ManagerAccountVendorStatus.Active,
      },
      update: {},
      include: {
        contracts: {
          include: {
            contract_line_items: {
              include: {
                contract_line_item_products: true,
              },
            },
          },
        },
      },
    });

    const productPrices = Array.from("_".repeat(vendor.products.length)).map(
      _ => faker.number.int({ min: 100, max: 1000 })
    );

    const contracts = await Promise.all(
      Array.from({ length: 3 }).map((_, i) => {
        const isCorporate = !faker.number.int({ min: 0, max: 5 });
        return tx.contract.create({
          data: {
            contract_owner_name: faker.person.fullName(),
            approver: faker.person.fullName(),
            expires_at: faker.date.future(),
            current_term_end_date: faker.date.future(),
            name: faker.commerce.productName(),
            renewal_reminder_lead_time_months: faker.number.int({ max: 12 }),
            status: ContractStatus.Active,
            term_length_months: faker.number.int({ max: 48 }),
            manager_account_vendor: {
              connect: { id: accountVendor.id },
            },
            is_corporate_only: isCorporate,
            contract_line_items: {
              create: {
                status: ContractLineItemStatus.Active,
                name: faker.commerce.productName(),
                price: productPrices.reduce((acc, price) => acc + price, 0),
                contract_line_item_products: {
                  createMany: {
                    data: productPrices.map((price, index) => ({
                      department: "Support",
                      price: price,
                      product_id: vendor.products[index].id,
                    })),
                  },
                },
                contract_line_item_locations: {
                  createMany: {
                    data: faker.helpers
                      .arrayElements(managerAccountsLocations[0])
                      .map(location => ({
                        location_id: location.id,
                      })),
                  },
                },
              },
            },
          },
          include: {
            contract_line_items: {
              include: {
                contract_line_item_products: true,
                contract_line_item_locations: true,
              },
            },
          },
        });
      })
    );

    return {
      category,
      accountVendor,
      contracts,
      managerAccounts,
      userWithNoAccounts,
      userWith2ManagerAccounts,
      userWithGodMode,
      managerAccountsLocations,
    };
  },
});

describe("ManagerAccountService", () => {
  describe("getManagerAccount", () => {
    it(
      "should return manager account",
      withFixtures(async ({ managerAccounts }, tx) => {
        const { managerAccountService } = TestDIContainer(tx);

        const result = await managerAccountService.getManagerAccount(
          managerAccounts[0].id
        );

        expect(result).toEqual(
          expect.objectContaining({
            id: managerAccounts[0].id,
            name: managerAccounts[0].name,
          })
        );
      })
    );
  });

  describe("getManagerAccountByContractId", () => {
    it(
      "should return manager account",
      withFixtures(async ({ managerAccounts, contracts }, tx) => {
        const { managerAccountService } = TestDIContainer(tx);

        const result =
          await managerAccountService.getManagerAccountByContractId(
            contracts[0].id
          );

        expect(result).toEqual(
          expect.objectContaining({
            id: managerAccounts[0].id,
            name: managerAccounts[0].name,
          })
        );
      })
    );
  });

  describe("getTotalsForAccount", () => {
    it(
      "should return manager account",
      withFixtures(
        async (
          { managerAccounts, contracts, userWith2ManagerAccounts },
          tx
        ) => {
          const { managerAccountService } = TestDIContainer(tx);

          const totals = await managerAccountService.getTotalsForAccount(
            userWith2ManagerAccounts,
            managerAccounts[0]
          );
          expect(totals.contracts).toBe(3);
          expect(totals.products).toBe(2);
          expect(totals.vendors).toBe(1);
        }
      )
    );
  });

  describe("getContractLineItemAnnualAssignedValue", () => {
    it(
      "should correctly calculate the total annual assigned value of a contract line item",
      withFixtures(async ({ contracts }, tx) => {
        const { managerAccountService } = TestDIContainer(tx);

        const contractLineItemId = contracts[0].contract_line_items[0].id;

        const totalValue =
          await managerAccountService.getContractLineItemAnnualAssignedValue(
            contractLineItemId
          );

        const expectedTotalValue =
          contracts[0].contract_line_items[0].contract_line_item_products.reduce(
            (acc, product) => acc + product.price,
            0
          );

        expect(totalValue).toBe(expectedTotalValue);
      })
    );
  });

  describe("getManagerAccountVendorAnnualAssignedValue", () => {
    it(
      "should correctly calculate the total annual assigned to a manager account vendor",
      withFixtures(async ({ contracts }, tx) => {
        const { managerAccountService } = TestDIContainer(tx);

        const totalValue =
          await managerAccountService.getManagerAccountVendorAnnualAssignedValue(
            contracts[0].manager_account_vendor_id
          );
        const expectedTotalValue = contracts
          .flatMap(contract =>
            contract.contract_line_items.map(line =>
              line.contract_line_item_products.reduce(
                (acc, product) => acc + product.price,
                0
              )
            )
          )
          .reduce((acc, value) => acc + value, 0);
        expect(totalValue).toBe(expectedTotalValue);
      })
    );
  });

  describe("getProductsByResidentLifecyclePhase", () => {
    it(
      "should correctly calculate the # of products by resident lifecycle phase",
      withFixtures(
        async ({ userWith2ManagerAccounts, managerAccounts }, tx) => {
          const { managerAccountService } = TestDIContainer(tx);

          const numProductsByResidentLifecycle =
            await managerAccountService.getProductsByResidentLifecyclePhase(
              userWith2ManagerAccounts,
              managerAccounts[0]
            );

          expect(
            numProductsByResidentLifecycle[ResidentLifecyclePhase.Leasing]
              .length
          ).toEqual(2);
        }
      )
    );
  });

  describe("getDepartmentContractLineItems", () => {
    it(
      "should get the department contract line items",
      withFixtures(
        async (
          { accountVendor, managerAccounts, userWith2ManagerAccounts },
          tx
        ) => {
          const { managerAccountService } = TestDIContainer(tx);

          const contractLineItems =
            await managerAccountService.getDepartmentContractLineItems(
              "Support",
              userWith2ManagerAccounts,
              managerAccounts[0]
            );

          expect(contractLineItems).not.toBeNull();
          expect(contractLineItems).toHaveLength(3);
        }
      )
    );
  });

  describe("getCountsByDepartment", () => {
    it(
      "should correctly calculate the # of products, contracts and line items by department",
      withFixtures(
        async (
          { accountVendor, userWith2ManagerAccounts, managerAccounts },
          tx
        ) => {
          const { managerAccountService } = TestDIContainer(tx);

          const counts = await managerAccountService.getCountsByDepartment(
            userWith2ManagerAccounts,
            managerAccounts[0]
          );

          expect(counts.contractLineItems["Support"]).toEqual(3);
          expect(counts.contracts["Support"]).toEqual(3);
          expect(counts.vendors["Support"]).toEqual(1);
        }
      )
    );
  });

  describe("getUpcomingContractRenewals", () => {
    it(
      "should get upcoming renewal contracts and allow to display or not month to month ones",
      withFixtures(
        async (
          { accountVendor, userWith2ManagerAccounts, managerAccounts },
          tx
        ) => {
          const { managerAccountService } = TestDIContainer(tx);

          const contractsUpForRenewal =
            await managerAccountService.getUpcomingContractRenewals(
              userWith2ManagerAccounts,
              managerAccounts[0],
              true,
              10
            );

          expect(contractsUpForRenewal).not.toBeNull();
          expect(contractsUpForRenewal[0].contract_line_items).not.toBeNull();
        }
      )
    );
  });

  describe("getContractsTableData", () => {
    it(
      "should get contracts for displaying in the manager account dashboard table",
      withFixtures(
        async (
          {
            accountVendor,
            contracts,
            userWith2ManagerAccounts,
            managerAccounts,
          },
          tx
        ) => {
          const { managerAccountService } = TestDIContainer(tx);
          const filters = {
            vendors: [accountVendor.vendor_id],
          };
          const tableData = await managerAccountService.getContractsTableData(
            userWith2ManagerAccounts,
            managerAccounts[0],
            filters,
            3,
            undefined,
            [
              {
                current_term_end_date: "asc",
              },
            ]
          );

          expect(tableData).not.toBeNull();
          expect(tableData.rows.map(c => c.id)).toEqual(
            expect.arrayContaining(contracts.map(c => c.id))
          );
        }
      )
    );
  });

  describe("updateManagerAccount", () => {
    it(
      "should update the manager account name",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountService } = TestDIContainer(tx);
        const updatedManagerAccount =
          await managerAccountService.updateManagerAccount(
            accountVendor.manager_account_id,
            {
              name: "New ManagerAccount Name",
            }
          );

        expect(updatedManagerAccount.name).toEqual("New ManagerAccount Name");
      })
    );
  });
  describe("getManagerAccountDetails", () => {
    it(
      "should return manager account details",
      withFixtures(
        async ({ managerAccounts, managerAccountsLocations }, tx) => {
          const { managerAccountService } = TestDIContainer(tx);

          const result = await managerAccountService.getManagerAccountDetails(
            managerAccounts[0].id
          );

          const expectedLocationsCount = managerAccountsLocations[0].filter(
            l => l.status !== LocationStatus.Disposed
          ).length;

          const expectedUnitCount = managerAccountsLocations[0].reduce(
            (acc, l) =>
              acc + (l.status !== LocationStatus.Disposed ? l.unit_count : 0),
            0
          );

          expect(result).toEqual(
            expect.objectContaining({
              id: managerAccounts[0].id,
              name: managerAccounts[0].name,
              locations_count: expectedLocationsCount,
              unit_count: expectedUnitCount,
            })
          );
        }
      )
    );

    it(
      "should throw error if manager account not found",
      withFixtures(async ({ managerAccounts }, tx) => {
        const { managerAccountService } = TestDIContainer(tx);

        await expect(
          managerAccountService.getManagerAccountDetails(faker.string.uuid())
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError);
      })
    );
  });

  describe("getManagerAccountsForUser", () => {
    it(
      "should return manager accounts for user",
      withFixtures(
        async ({ userWith2ManagerAccounts, managerAccounts }, tx) => {
          const { managerAccountService } = TestDIContainer(tx);

          const result = await managerAccountService.getManagerAccountsForUser(
            userWith2ManagerAccounts
          );

          expect(result).toEqual(
            expect.arrayContaining([
              expect.objectContaining({
                id: managerAccounts[0].id,
                name: managerAccounts[0].name,
              }),
              expect.objectContaining({
                id: managerAccounts[1].id,
                name: managerAccounts[1].name,
              }),
            ])
          );
        }
      )
    );

    it(
      "should return all manager accounts for user with god mode",
      withFixtures(async ({ userWithGodMode, managerAccounts }, tx) => {
        const { managerAccountService } = TestDIContainer(tx);

        const result = await managerAccountService.getManagerAccountsForUser(
          userWithGodMode
        );

        expect(result).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              id: managerAccounts[0].id,
              name: managerAccounts[0].name,
            }),
            expect.objectContaining({
              id: managerAccounts[1].id,
              name: managerAccounts[1].name,
            }),
            expect.objectContaining({
              id: managerAccounts[2].id,
              name: managerAccounts[2].name,
            }),
          ])
        );
      })
    );

    it(
      "should return empty array for user with no manager accounts",
      withFixtures(async ({ userWithNoAccounts }, tx) => {
        const { managerAccountService } = TestDIContainer(tx);

        const result = await managerAccountService.getManagerAccountsForUser(
          userWithNoAccounts
        );

        expect(result).toEqual([]);
      })
    );
  });

  describe("getSpendByLocationReportData", () => {
    it(
      "should return spend by location report data",
      withFixtures(
        async ({ managerAccounts, userWith2ManagerAccounts }, tx) => {
          const { managerAccountService } = TestDIContainer(tx);

          const reportData =
            await managerAccountService.getSpendByLocationReportData(
              userWith2ManagerAccounts,
              managerAccounts[0]
            );

          expect(reportData).not.toBeNull();
          expect(reportData.locations).not.toBeNull();
          expect(reportData.totals).not.toBeNull();
        }
      )
    );

    it(
      "should return spend by location report data with search query",
      withFixtures(
        async (
          {
            managerAccounts,
            managerAccountsLocations,
            userWith2ManagerAccounts,
          },
          tx
        ) => {
          const { managerAccountService } = TestDIContainer(tx);

          const reportData =
            await managerAccountService.getSpendByLocationReportData(
              userWith2ManagerAccounts,
              managerAccounts[0],
              {
                searchQuery: managerAccountsLocations[0][1].name,
              }
            );

          expect(reportData).not.toBeNull();
          expect(reportData.locations).toHaveLength(1);
          expect(reportData.totals).not.toBeNull();

          const location = reportData.locations[0];
          expect(location.id).toEqual(managerAccountsLocations[0][1].id);
        }
      )
    );

    it(
      "should return spend by location report data with locations filter",
      withFixtures(
        async (
          {
            managerAccounts,
            managerAccountsLocations,
            userWith2ManagerAccounts,
          },
          tx
        ) => {
          const { managerAccountService } = TestDIContainer(tx);

          const reportData =
            await managerAccountService.getSpendByLocationReportData(
              userWith2ManagerAccounts,
              managerAccounts[0],
              {
                locations: [managerAccountsLocations[0][0].id],
              }
            );

          expect(reportData).not.toBeNull();
          expect(reportData.locations).toHaveLength(1);
          expect(reportData.totals).not.toBeNull();

          const location = reportData.locations[0];
          expect(location.id).toEqual(managerAccountsLocations[0][0].id);
        }
      )
    );

    it(
      "should return spend by location report data with regions filter",
      withFixtures(
        async (
          {
            managerAccounts,
            managerAccountsLocations,
            userWith2ManagerAccounts,
          },
          tx
        ) => {
          const { managerAccountService } = TestDIContainer(tx);

          const reportData =
            await managerAccountService.getSpendByLocationReportData(
              userWith2ManagerAccounts,
              managerAccounts[0],
              {
                regions: [managerAccountsLocations[0][2].region!],
              }
            );

          expect(reportData).not.toBeNull();
          expect(reportData.locations).not.toBeNull();
          expect(reportData.totals).not.toBeNull();

          const location = reportData.locations[0];
          expect(location.id).toEqual(managerAccountsLocations[0][2].id);
        }
      )
    );

    it(
      "should return spend by location report data with owners filter",
      withFixtures(
        async (
          {
            managerAccounts,
            managerAccountsLocations,
            userWith2ManagerAccounts,
          },
          tx
        ) => {
          const { managerAccountService } = TestDIContainer(tx);

          const reportData =
            await managerAccountService.getSpendByLocationReportData(
              userWith2ManagerAccounts,
              managerAccounts[0],
              {
                owners: [managerAccountsLocations[0][3].owner_name!],
              }
            );

          expect(reportData).not.toBeNull();
          expect(reportData.locations).not.toBeNull();
          expect(reportData.totals).not.toBeNull();

          const location = reportData.locations[0];
          expect(location.id).toEqual(managerAccountsLocations[0][3].id);
        }
      )
    );
  });
});
