import type {
  ProductSubscription,
  User,
  PrismaClient,
  ManagerAccountRoleType,
} from "@prisma/client";
import { Prisma, SubscriptionStatus, UserRoleType, Role } from "@prisma/client";
import type { IMailService } from "./mail.service.server";
import type { TemplateService } from "./template.service.server";
import { isNil } from "lodash";
import Stripe from "stripe";
import { getEnv } from "./env.service.server";
import type { CustomerSupportService } from "./customer-support.service.server";
import { ProductSubscriptionActiveStatuses } from "../utils/product-subscription.utils.server";

export type RoleJson = {
  role: Role | ManagerAccountRoleType;
  resource_id?: string;
  manager_account_id?: string;
};

export class ProductSubscriptionService {
  constructor(
    private db: PrismaClient,
    private mailService: IMailService,
    private templateService: TemplateService,
    private customerSupportService: CustomerSupportService
  ) {}

  async getResourceUserRole({
    filters,
  }: {
    filters: Prisma.UserRoleWhereUniqueInput | Prisma.UserRoleWhereInput;
  }) {
    return this.db.userRole.findFirst({
      where: filters,
      include: {
        product_subscription: { include: { product: true } },
        user: true,
      },
    });
  }

  async getProductActiveSubscription(productId: string) {
    return await this.db.productSubscription.findFirst({
      where: {
        product_id: productId,
        status: {
          notIn: [
            SubscriptionStatus.canceled,
            SubscriptionStatus.incomplete_expired,
          ],
        },
      },
      orderBy: { created_at: "desc" },
      include: { stripe_price: { include: { product: true } } },
    });
  }

  async getSubscriptionsForUser(user: Pick<User, "id">) {
    const subscriptions = await this.db.productSubscription.findMany({
      where: {
        status: {
          in: ProductSubscriptionActiveStatuses,
        },
        OR: [
          {
            user_roles: {
              some: {
                type: UserRoleType.PRODUCT_SUBSCRIPTION,
                user_id: user.id,
              },
            },
          },
          {
            user_roles: {
              some: {
                user_id: user.id,
              },
            },
          },
        ],
      },
      include: {
        product: true,
        stripe_price: { include: { product: true } },
        user_roles: true,
      },
    });

    return subscriptions;
  }

  async getSubscriptionUserCount(
    subscription: Pick<ProductSubscription, "id">,
    role?: Role
  ) {
    const userCount = await this.db.userRole.count({
      where: {
        type: UserRoleType.PRODUCT_SUBSCRIPTION,
        resource_id: subscription.id,
        role: role,
      },
    });

    return userCount;
  }

  async getSubscriptionUsers(id: string | undefined) {
    const userRoles = await this.db.userRole.findMany({
      where: {
        type: UserRoleType.PRODUCT_SUBSCRIPTION,
        resource_id: id,
      },
      include: {
        user: true,
      },
    });

    return userRoles;
  }

  async getSubscriptionOwnerUsers(id: string | undefined) {
    const userRoles = await this.db.userRole.findMany({
      where: {
        type: UserRoleType.PRODUCT_SUBSCRIPTION,
        resource_id: id,
        role: Role.OWNER,
      },
      include: {
        user: true,
      },
    });

    return userRoles;
  }

  async deleteSubscriptionRole(id: string | undefined) {
    return await this.db.userRole.delete({ where: { id } });
  }

  async handleSubscriptionRole(
    id: string | null,
    resourceId: string,
    email: string,
    role: string
  ) {
    if (id) {
      await this.db.userRole.update({
        where: {
          id,
        },
        data: {
          role: role as Role,
        },
      });
      return {
        success: true,
      };
    } else {
      const roleExists = await this.db.userRole.findFirst({
        where: {
          resource_id: resourceId,
          user: {
            email: email,
          },
        },
      });

      if (!roleExists) {
        const invitation = await this.db.userInvitation.create({
          data: {
            email: email,
            role: {
              role: role,
              resource_id: resourceId,
            },
          },
        });
        await this.generateUserInviteEmail(invitation.email, resourceId);
        return { success: true };
      } else {
        return {
          success: false,
        };
      }
    }
  }

  async generateUserInviteEmail(email: string, resourceId: string) {
    const userInvitation = await this.db.userInvitation.findFirstOrThrow({
      where: {
        email: email,
        role: {
          path: ["resource_id"],
          equals: resourceId,
        },
      },
    });
    const role = userInvitation.role as RoleJson;

    const subscription = await this.db.productSubscription.findFirstOrThrow({
      where: {
        id: role.resource_id,
      },
      include: {
        product: true,
      },
    });
    if (!userInvitation) {
      return null;
    } else {
      const token = userInvitation.id;

      const body = this.templateService.renderUserInvitationEmail({
        invitation: userInvitation,
        product: subscription?.product,
        email: email,
        token: token,
      });
      await this.mailService.send({
        to: [userInvitation.email],
        subject: "You've been invited to manage a product listing on Revyse ⚒️",
        body,
      });
      return token;
    }
  }

  async cancelSubscriptionInvite(invitationId: string) {
    return this.db.userInvitation.delete({
      where: {
        id: invitationId,
      },
    });
  }

  async acceptSubscriptionInvite(role: RoleJson, user: User, token: string) {
    return await this.db.$transaction(async tx => {
      await tx.productSubscription.findFirstOrThrow({
        where: {
          id: role.resource_id,
        },
        include: {
          product: true,
        },
      });
      const invite = await tx.userInvitation.update({
        where: {
          id: token,
        },
        data: {
          accepted_at: new Date(),
          accepted_by_id: user.id,
        },
      });

      await tx.emailVerificationToken.update({
        where: {
          email: user.email,
        },
        data: {
          verified_at: new Date(),
        },
      });

      await tx.userRole.create({
        data: {
          user_id: user.id,
          resource_id: role.resource_id,
          type: UserRoleType.PRODUCT_SUBSCRIPTION,
          role: role.role as Role,
        },
      });

      return invite;
    });
  }

  async getUserInvitationByToken(token: string) {
    return await this.db.userInvitation.findFirst({
      where: {
        id: token,
        accepted_by_id: null,
      },
    });
  }

  async createSubscriptionCheckoutSession(
    stripePriceId: string,
    productId: string,
    user: User,
    newProductFields?: {
      title: string;
      description: string;
      slug: string;
      primary_category_id: string;
      vendor_id: string;
    }
  ) {
    if (productId !== "new") {
      const product = await this.db.product.findFirst({
        where: { id: productId },
      });
      if (isNil(product)) {
        console.log("Cannot checkout for unknown product: ", productId);
        throw new Error("Cannot checkout for unknown product");
      }

      const existingActiveSubscription =
        await this.db.productSubscription.findFirst({
          where: {
            product_id: productId,
            status: {
              notIn: [
                SubscriptionStatus.canceled,
                SubscriptionStatus.incomplete_expired,
              ],
            },
          },
        });

      if (!isNil(existingActiveSubscription)) {
        console.log(
          "Cannot checkout for product that already has an active subscription: ",
          productId
        );
        throw new Error(
          "Cannot checkout for product that already has an active subscription"
        );
      }
    }

    const stripe = new Stripe(getEnv().STRIPE_SECRET_KEY, {
      apiVersion: "2022-11-15",
    });

    let extraFields: Record<string, string> = {
      productId,
      stripePriceId,
    };

    if (newProductFields) {
      extraFields = {
        ...extraFields,
        ...newProductFields,
      };
    }

    const extraFieldsSearchParams = new URLSearchParams(extraFields);

    let successRoute = `/checkout_success`;
    let cancelRoute = `/checkout_cancelled`;

    if (productId === "new") {
      cancelRoute = `/vendor/products/new`;
    }

    const successUrl = `${
      getEnv().REVYSE_UI_ORIGIN
    }${successRoute}?session_id={CHECKOUT_SESSION_ID}&${extraFieldsSearchParams.toString()}`;
    const cancelUrl = `${
      getEnv().REVYSE_UI_ORIGIN
    }${cancelRoute}?session_id={CHECKOUT_SESSION_ID}${extraFieldsSearchParams.toString()}`;

    const session = await stripe.checkout.sessions.create({
      billing_address_collection: "auto",
      automatic_tax: { enabled: true },
      customer_email: user.email,
      metadata: {
        product_listing_id: productId,
        user_id: user.id,
        stripe_price_id: stripePriceId,
        ...extraFields,
      },
      line_items: [
        {
          price: stripePriceId,
          // For metered billing, do not pass quantity
          quantity: 1,
        },
      ],
      consent_collection: {
        terms_of_service: "required",
      },
      mode: "subscription",
      success_url: successUrl,
      cancel_url: cancelUrl,
      payment_method_collection: "if_required",
      allow_promotion_codes: true,
    });

    return session;
  }

  async createSubscriptionBillingPortalSession(stripeId: string) {
    const stripe = new Stripe(getEnv().STRIPE_SECRET_KEY, {
      apiVersion: "2022-11-15",
    });

    const sub = await stripe.subscriptions.retrieve(stripeId);
    const session = await stripe.billingPortal.sessions.create({
      customer: sub.customer as string,
      return_url: `${getEnv().REVYSE_UI_ORIGIN}/vendor/products`,
    });
    return session;
  }

  async createProductAndSubscription(
    checkoutData: Stripe.Checkout.Session,
    stripe: Stripe
  ) {
    const { user_id, stripe_price_id } = checkoutData.metadata!;
    let { product_listing_id } = checkoutData.metadata!;
    const subscriptionId = checkoutData.subscription as string;

    if (product_listing_id === "new") {
      await this.db.$transaction(async tx => {
        const newProductFields = {
          title: checkoutData.metadata?.title || "",
          description: checkoutData.metadata?.description || "",
          slug: checkoutData.metadata?.slug || "",
          primary_category_id: checkoutData.metadata?.primary_category_id || "",
          vendor_id: checkoutData.metadata?.vendor_id || null,
        };

        const product = await tx.product.create({
          data: {
            ...newProductFields,
            positioning: "",
            page_title: `Revyse | Read Reviews for ${newProductFields.title}`,
            meta_description: `Read ${newProductFields.title} reviews from verified users. Compare the best multifamily products and services on Revyse.`,
          },
        });

        product_listing_id = product.id;

        const user = await tx.user.findUnique({
          where: { id: user_id },
        });

        const env = getEnv();
        await this.customerSupportService.sendCSEmail(
          `New Product Listing Alert | ${product.title}`,
          `<p>Hey Team Revyse,</p> 
          <p>${user?.email} created a new product listing for ${product.title} on Revyse.</p>
          <p>Now it's your turn to review it. The listing won't be live until you click 'approve', 
          so make haste while the sun shines, my friends.</p> 
          <p>Click here to <a href="${env.REVYSE_UI_ORIGIN}/admin/products/${product.id}">review and approve</a>.</p>`
        );
      });
    }

    await this.db.$transaction(async tx => {
      await tx.productSubscription.create({
        data: {
          stripe_id: subscriptionId,
          product_id: product_listing_id,
          status: SubscriptionStatus.incomplete,
          stripe_price_id,
        },
      });
      const product = await tx.product.findUniqueOrThrow({
        where: { id: product_listing_id },
        include: { vendor: true },
      });
      await stripe.subscriptions.update(subscriptionId, {
        metadata: {
          product_name: product.title,
          product_id: product.id,
          vendor_name: product.vendor?.name ?? null,
          product_listing:
            getEnv().REVYSE_UI_ORIGIN + "/products/" + product.slug,
          user_id,
          user_detail: getEnv().REVYSE_UI_ORIGIN + "/admin/users/" + user_id,
        },
      });
      console.log("Checkout session completed!", {
        product_listing_id: checkoutData.metadata?.product_listing_id,
        subscription: checkoutData.subscription,
        stripe_price_id,
      });
    });
    await this.db.$transaction(async tx => {
      const sub = await tx.productSubscription.findFirst({
        where: {
          product_id: product_listing_id,
        },
      });
      await tx.userRole.create({
        data: {
          user_id: user_id,
          resource_id: sub?.id,
          type: UserRoleType.PRODUCT_SUBSCRIPTION,
          role: Role.OWNER,
        },
      });
    });
  }

  async updateSubscription(
    subscription: Stripe.Subscription & {
      plan?: { id: string };
    },
    updateStripePriceId = false
  ) {
    const productSubscription = await this.db.productSubscription.findFirst({
      where: { stripe_id: subscription.id },
    });
    if (isNil(productSubscription)) {
      console.error(
        "Stripe customer.subscription.created event without matching subscription in db",
        { subscription: subscription.id }
      );
    } else {
      await this.db.productSubscription.update({
        where: { stripe_id: subscription.id },
        data: {
          status: subscription.status as SubscriptionStatus,
          stripe_price_id: updateStripePriceId
            ? subscription.plan?.id
            : undefined,
        },
      });
    }
  }

  async getSubscriptionCountByPlan() {
    return await this.db.$queryRaw<
      {
        name: string;
        cnt: number;
      }[]
    >(
      Prisma.sql`
        select 
          spr.name, 
          count(*)::int as cnt 
        from stripe_product spr 
          join stripe_price sp on sp.product_id=spr.id 
          join product_subscription ps on ps.stripe_price_id=sp.id and ps.status='active'
        group by spr.id
        order by spr.order
      `
    );
  }
}
