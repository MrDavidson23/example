import { faker } from "@faker-js/faker";
import { ContractStatus } from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { withFixtureFactory } from "../utils/test.utils.server";
import dayjs from "dayjs";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const managerAccount = await tx.managerAccount.create({
      data: {
        name: faker.company.name(),
        manager_account_vendors: {
          create: {
            vendor: {
              create: {
                name: faker.company.name(),
              },
            },
          },
        },
      },
      include: {
        manager_account_vendors: true,
      },
    });

    return { managerAccount };
  },
});

describe("SyncCurrentTermEndDateService", () => {
  describe("syncNewCurrentTermEndDates", () => {
    it(
      "month to month contracts auto-renew",
      withFixtures(async ({ managerAccount }, tx) => {
        const { syncCurrentTermEndDateService } = TestDIContainer(tx);

        const dates = Array.from({ length: 5 }).map((_, i) =>
          dayjs()
            .subtract(i + 1, "day")
            .toDate()
        );
        const monthToMonthContracts = await Promise.all(
          dates.map((date, i) =>
            tx.contract.create({
              data: {
                name: faker.commerce.productName(),
                will_auto_renew: true,
                current_term_end_date: date,
                status: ContractStatus.Active,
                is_month_to_month: true,
                manager_account_vendor_id:
                  managerAccount.manager_account_vendors[0].id,
                renewal_reminder_lead_time_months: i + 1,
                auto_renew_term_length: i + 1,
              },
            })
          )
        );

        await syncCurrentTermEndDateService.syncNewCurrentTermEndDates();

        const updatedContracts = await tx.contract.findMany({
          where: {
            id: {
              in: monthToMonthContracts.map(contract => contract.id),
            },
          },
          orderBy: {
            current_term_end_date: "asc",
          },
        });

        for (let i = 0; i < updatedContracts.length; i++) {
          const contract = updatedContracts[i];
          expect(contract.current_term_end_date).toEqual(
            dayjs(dates[i])
              .add(contract.auto_renew_term_length!, "month")
              .toDate()
          );
          // Renewal reminder should be null for month-to-month contracts
          expect(contract.renewal_reminder_date).toBeNull();
        }
      })
    );

    it(
      "not month to month contracts auto-renew",
      withFixtures(async ({ managerAccount }, tx) => {
        const { syncCurrentTermEndDateService } = TestDIContainer(tx);

        const dates = Array.from({ length: 5 }).map((_, i) =>
          dayjs()
            .subtract(i + 1, "day")
            .toDate()
        );

        const yearlyContracts = await Promise.all(
          dates.map((date, i) =>
            tx.contract.create({
              data: {
                name: faker.commerce.productName(),
                will_auto_renew: true,
                current_term_end_date: date,
                status: ContractStatus.Active,
                is_month_to_month: false,
                manager_account_vendor_id:
                  managerAccount.manager_account_vendors[0].id,
                renewal_reminder_lead_time_months: i + 1,
                auto_renew_term_length: i + 1,
              },
            })
          )
        );

        await syncCurrentTermEndDateService.syncNewCurrentTermEndDates();

        const updatedContracts = await tx.contract.findMany({
          where: {
            id: {
              in: yearlyContracts.map(contract => contract.id),
            },
          },
          orderBy: {
            current_term_end_date: "asc",
          },
        });

        for (let i = 0; i < updatedContracts.length; i++) {
          const contract = updatedContracts[i];
          expect(contract.current_term_end_date).toEqual(
            dayjs(dates[i])
              .add(contract.auto_renew_term_length!, "month")
              .toDate()
          );
          expect(contract.renewal_reminder_date).toEqual(
            dayjs(contract.current_term_end_date)
              .subtract(contract.renewal_reminder_lead_time_months!, "month")
              .toDate()
          );
        }
      })
    );

    it(
      "no updates on not auto-renew contracts or canceled contracts",
      withFixtures(async ({ managerAccount }, tx) => {
        const { syncCurrentTermEndDateService } = TestDIContainer(tx);

        const date = dayjs().subtract(1, "day").toDate();

        const contracts = await Promise.all([
          tx.contract.create({
            data: {
              name: faker.commerce.productName(),
              will_auto_renew: false,
              current_term_end_date: date,
              status: ContractStatus.Active,
              is_month_to_month: true,
              manager_account_vendor_id:
                managerAccount.manager_account_vendors[0].id,
            },
          }),
          tx.contract.create({
            data: {
              name: faker.commerce.productName(),
              will_auto_renew: true,
              current_term_end_date: date,
              status: ContractStatus.Canceled,
              is_month_to_month: true,
              manager_account_vendor_id:
                managerAccount.manager_account_vendors[0].id,
            },
          }),
        ]);

        await syncCurrentTermEndDateService.syncNewCurrentTermEndDates();

        const updatedContracts = await tx.contract.findMany({
          where: {
            id: {
              in: contracts.map(contract => contract.id),
            },
          },
        });

        for (const contract of updatedContracts) {
          expect(contract.current_term_end_date).toEqual(date);
        }
      })
    );

    it(
      "no updates on contracts with current_term_end_date in the future",
      withFixtures(async ({ managerAccount }, tx) => {
        const { syncCurrentTermEndDateService } = TestDIContainer(tx);

        const date = dayjs().add(1, "day").toDate();

        const contract = await tx.contract.create({
          data: {
            name: faker.commerce.productName(),
            will_auto_renew: true,
            current_term_end_date: date,
            status: ContractStatus.Active,
            is_month_to_month: true,
            manager_account_vendor_id:
              managerAccount.manager_account_vendors[0].id,
          },
        });

        await syncCurrentTermEndDateService.syncNewCurrentTermEndDates();

        const updatedContract = await tx.contract.findUnique({
          where: {
            id: contract.id,
          },
        });

        expect(updatedContract!.current_term_end_date).toEqual(date);
      })
    );

    it(
      "contract line item location with defined expired_at is updated",
      withFixtures(async ({ managerAccount }, tx) => {
        const { syncCurrentTermEndDateService } = TestDIContainer(tx);

        const dates = Array.from({ length: 5 }).map((_, i) =>
          dayjs()
            .subtract(i + 1, "day")
            .toDate()
        );

        const contractsWithContractLineItemLocation = await Promise.all(
          dates.map((date, i) =>
            tx.contract.create({
              data: {
                name: faker.commerce.productName(),
                will_auto_renew: true,
                current_term_end_date: null,
                status: ContractStatus.Active,
                is_month_to_month: true,
                manager_account_vendor_id:
                  managerAccount.manager_account_vendors[0].id,
                renewal_reminder_lead_time_months: i + 1,
                auto_renew_term_length: i + 1,
                contract_line_items: {
                  create: {
                    name: faker.commerce.productName(),
                    contract_line_item_locations: {
                      create: {
                        expires_at: date, // important one
                        location: {
                          create: {
                            name: faker.company.name(),
                            street_1: faker.location.streetAddress(),
                            city: faker.location.city(),
                            state: faker.location.state(),
                            region: faker.location.country(),
                            zip: faker.location.zipCode(),
                            manager_account: {
                              connect: {
                                id: managerAccount.id,
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            })
          )
        );

        await syncCurrentTermEndDateService.syncNewCurrentTermEndDates();

        const updatedContracts = await tx.contract.findMany({
          where: {
            id: {
              in: contractsWithContractLineItemLocation.map(
                contract => contract.id
              ),
            },
          },
          include: {
            contract_line_items: {
              include: {
                contract_line_item_locations: true,
              },
            },
          },
          orderBy: {
            auto_renew_term_length: "asc",
          },
        });

        for (let i = 0; i < updatedContracts.length; i++) {
          const contract = updatedContracts[i];
          const contractLineItemLocation =
            contract.contract_line_items[0].contract_line_item_locations[0];
          expect(contractLineItemLocation.expires_at).toEqual(
            dayjs(dates[i])
              .add(contract.auto_renew_term_length!, "month")
              .toDate()
          );
          // contract was not updated, so the expires_at date should not be updated
          expect(contract.current_term_end_date).toBeNull();
        }
      })
    );
  });
});
