import { faker } from "@faker-js/faker";
import { slugify } from "../utils/string.utils";
import { withFixtureFactory } from "../utils/test.utils.server";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { sortBy } from "lodash";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    // Create posts
    const testPostsNames = Array.from({ length: 10 }, () =>
      faker.lorem.sentence(5)
    );

    const testPosts = await Promise.all(
      testPostsNames.map((name, i) =>
        tx.post.create({
          data: {
            id: i + 1,
            status: "published",
            name: `TEST POST - ${name}`,
            body: faker.lorem.paragraphs(5),
            slug: slugify(name),
            space_name: "revyse",
            space_slug: "revyse",
            space_id: 123,
            user_id: faker.number.int({ min: 1, max: 100 }),
            user_email: faker.internet.email(),
            user_name: faker.internet.userName(),
            comments_count: faker.number.int({ min: 1, max: 100 }),
            community_id: faker.number.int({ min: 1, max: 100 }),
            hide_meta_info: false,
            url: faker.internet.url(),
            published_at: faker.date.recent(),
            user_avatar_url: faker.image.avatar(),
            created_at: faker.date.recent(),
            updated_at: faker.date.recent(),
            is_comments_enabled: faker.datatype.boolean(),
            is_comments_closed: faker.datatype.boolean(),
            is_liking_enabled: faker.datatype.boolean(),
            likes_count: faker.number.int({ min: 1, max: 100 }),
            user_comments_count: faker.number.int({ min: 1, max: 100 }),
            user_likes_count: faker.number.int({ min: 1, max: 100 }),
            user_posts_count: faker.number.int({ min: 1, max: 100 }),
            user_topics_count: faker.number.int({ min: 1, max: 100 }),
          },
        })
      )
    );

    const hiddenTestPost = await tx.post.create({
      data: {
        id: faker.number.int({ min: 100, max: 1000 }),
        status: "published",
        name: `TEST POST - hidden`,
        body: faker.lorem.paragraphs(5),
        slug: `TEST POST - hidden`,
        space_name: "revyse",
        space_slug: "revyse",
        space_id: 123,
        user_id: faker.number.int({ min: 1, max: 100 }),
        user_email: faker.internet.email(),
        user_name: faker.internet.userName(),
        comments_count: faker.number.int({ min: 1, max: 100 }),
        community_id: faker.number.int({ min: 1, max: 100 }),
        hide_meta_info: true, // Important one
        url: faker.internet.url(),
        published_at: faker.date.recent(),
        user_avatar_url: faker.image.avatar(),
        created_at: faker.date.recent(),
        updated_at: faker.date.recent(),
        is_comments_enabled: faker.datatype.boolean(),
        is_comments_closed: faker.datatype.boolean(),
        is_liking_enabled: faker.datatype.boolean(),
        likes_count: faker.number.int({ min: 1, max: 100 }),
        user_comments_count: faker.number.int({ min: 1, max: 100 }),
        user_likes_count: faker.number.int({ min: 1, max: 100 }),
        user_posts_count: faker.number.int({ min: 1, max: 100 }),
        user_topics_count: faker.number.int({ min: 1, max: 100 }),
      },
    });

    const allPosts = await tx.post.findMany();

    const legalDoc = await tx.legalDoc.create({
      data: {
        id: faker.number.int({ min: 1000, max: 10000 }),
        name: "TEST LEGAL DOC",
        body: faker.lorem.paragraphs(5),
        slug: "test-legal-doc",
        hide_meta_info: false,
        published_at: faker.date.recent(),
        created_at: faker.date.recent(),
        updated_at: faker.date.recent(),
      },
    });

    return { testPosts, allPosts, hiddenTestPost, legalDoc };
  },
});

// path: app/services/circle.service.server.ts
describe("CircleSOService", () => {
  describe("getPosts", () => {
    it(
      "should return all posts",
      withFixtures(async ({ allPosts }, tx) => {
        const { circleService } = TestDIContainer(tx);

        const filteredPosts = allPosts.filter(post => !post.hide_meta_info);
        const sortedPosts = sortBy(filteredPosts, "published_at").reverse();

        const result = await circleService.getPosts();

        expect(result).toEqual(sortedPosts);
      })
    );

    it(
      "should return the number of posts specified",
      withFixtures(async ({ allPosts }, tx) => {
        const { circleService } = TestDIContainer(tx);

        const result = await circleService.getPosts(2);

        const filteredPosts = allPosts.filter(post => !post.hide_meta_info);
        const sortedPosts = sortBy(filteredPosts, "published_at").reverse();

        expect(result).toEqual(sortedPosts.slice(0, 2));
      })
    );
  });

  describe("getPostsByName", () => {
    it(
      "should return posts by name",
      withFixtures(async ({ testPosts }, tx) => {
        const { circleService } = TestDIContainer(tx);

        const searchTerm = "TEST POST - ";
        const result = await circleService.getPostsByName(searchTerm);

        const sortedPosts = sortBy(testPosts, "published_at").reverse();

        expect(result).toEqual(sortedPosts);
      })
    );

    it(
      "should return an empty array if no posts are found",
      withFixtures(async () => {
        const { circleService } = TestDIContainer();

        const searchTerm = "non-existent post";
        const result = await circleService.getPostsByName(searchTerm);

        expect(result).toEqual([]);
      })
    );

    it(
      "should return an empty array if searched post has hide_meta_info=true",
      withFixtures(async () => {
        const { circleService } = TestDIContainer();

        const result = await circleService.getPostsByName("TEST POST - hidden");

        expect(result).toEqual([]);
      })
    );
  });

  describe("getPost", () => {
    it(
      "should return a post by slug",
      withFixtures(async ({ testPosts }, tx) => {
        const { circleService } = TestDIContainer(tx);

        const post = testPosts[0];
        const result = await circleService.getPost(post.slug);

        expect(result).toEqual(post);
      })
    );

    it(
      "should throw an error if post is not found",
      withFixtures(async () => {
        const { circleService } = TestDIContainer();

        const slug = "non-existent-post";
        await expect(circleService.getPost(slug)).rejects.toThrow(
          "No Post found" // Prisma error message
        );
      })
    );
  });

  describe("getLegalDoc", () => {
    it(
      "should return a legal doc by slug",
      withFixtures(async ({ legalDoc }, tx) => {
        const { circleService } = TestDIContainer(tx);

        const result = await circleService.getLegalDoc(legalDoc.slug);

        expect(result).toEqual(legalDoc);
      })
    );

    it(
      "should throw an error if legal doc is not found",
      withFixtures(async (_, tx) => {
        const { circleService } = TestDIContainer(tx);

        const slug = "non-existent-legal-doc";
        await expect(circleService.getLegalDoc(slug)).rejects.toThrow(
          `Doc with the slug: ${slug} doesn't exist`
        );
      })
    );
  });

  describe("createPosts", () => {
    it(
      "should create posts",
      withFixtures(async (_, tx) => {
        const { circleService, circleClientService } = TestDIContainer(tx);

        await circleService.createPosts();

        const postsData = await circleClientService.getCirclePosts(1, 1);

        const posts = await tx.post.findMany({
          where: { id: { in: postsData.map(post => post.id) } },
        });

        expect(posts).toHaveLength(postsData.length);
        // check post data
        posts.forEach((post, i) => {
          const postData = postsData[i];
          expect(post.name).toEqual(postData.name);
          expect(post.body).toEqual(postData.body.body);
          expect(post.slug).toEqual(postData.slug);
        });
      })
    );
  });

  describe("createLegalDocs", () => {
    it(
      "should create legal docs",
      withFixtures(async (_, tx) => {
        const { circleService, circleClientService } = TestDIContainer(tx);

        await circleService.createLegalDocs();

        const docsData = await circleClientService.getCirclePosts(1, 2);

        const docs = await tx.legalDoc.findMany({
          where: { id: { in: docsData.map(doc => doc.id) } },
        });

        expect(docs).toHaveLength(docsData.length);
        // check doc data
        docs.forEach((doc, i) => {
          const docData = docsData[i];
          expect(doc.name).toEqual(docData.name);
          expect(doc.body).toEqual(docData.body.body);
          expect(doc.slug).toEqual(docData.slug);
        });
      })
    );
  });

  describe("deleteInexistentPosts", () => {
    it(
      "should delete posts that don't exist in the fetched posts",
      withFixtures(async ({ allPosts }, tx) => {
        const { circleService, circleClientService } = TestDIContainer(tx);

        const existingPosts = allPosts;
        const existingPostIds = existingPosts.map(post => post.id);

        const postsData = await circleClientService.getCirclePosts(1, 1);
        const fetchedPostIds = postsData.map(postData => postData.id);

        const postsToDelete = existingPostIds.filter(
          postId => !fetchedPostIds.includes(postId)
        );

        await circleService.deleteInexistentPosts();

        const posts = await tx.post.findMany({
          where: { id: { in: postsToDelete } },
        });

        expect(posts).toHaveLength(0);
      })
    );
  });

  describe("deleteInexistentLegalDocs", () => {
    it(
      "should delete legal docs that don't exist in the fetched docs",
      withFixtures(async (_, tx) => {
        const { circleService, circleClientService } = TestDIContainer(tx);

        const existingDocs = await tx.legalDoc.findMany();
        const existingDocsIds = existingDocs.map(doc => doc.id);

        const docsData = await circleClientService.getCirclePosts(1, 2);
        const fetchedDocsIds = docsData.map(docData => docData.id);

        const docsToDelete = existingDocsIds.filter(
          docId => !fetchedDocsIds.includes(docId)
        );

        await circleService.deleteInexistentLegalDocs();

        const docs = await tx.legalDoc.findMany({
          where: { id: { in: docsToDelete } },
        });

        expect(docs).toHaveLength(0);
      })
    );
  });

  describe("syncPosts", () => {
    it(
      "should sync posts and legal docs",
      withFixtures(async (_, tx) => {
        const { circleService, circleClientService } = TestDIContainer(tx);

        await circleService.syncPosts();

        const postsData = await circleClientService.getCirclePosts(1, 1);
        const docsData = await circleClientService.getCirclePosts(1, 2);

        const posts = await tx.post.findMany({
          orderBy: { name: "asc" },
        });

        const docs = await tx.legalDoc.findMany({
          orderBy: { name: "asc" },
        });

        expect(posts).toHaveLength(postsData.length);
        expect(docs).toHaveLength(docsData.length);

        // check post data
        posts.forEach((post, i) => {
          const postData = postsData[i];
          expect(post.name).toEqual(postData.name);
          expect(post.body).toEqual(postData.body.body);
          expect(post.slug).toEqual(postData.slug);
        });

        // check doc data
        docs.forEach((doc, i) => {
          const docData = docsData[i];
          expect(doc.name).toEqual(docData.name);
          expect(doc.body).toEqual(docData.body.body);
          expect(doc.slug).toEqual(docData.slug);
        });
      })
    );
  });
});
