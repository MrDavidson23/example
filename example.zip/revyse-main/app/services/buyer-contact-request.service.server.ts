import { Role, UserRoleType } from "@prisma/client";
import type { User, PrismaClient } from "@prisma/client";
import type { IMailService } from "./mail.service.server";
import type { ITemplateService } from "./template.service.server";
import { ProductSubscriptionActiveStatuses } from "../utils/product-subscription.utils.server";

export class BuyerContactRequestService {
  constructor(
    private db: PrismaClient,
    private mailService: IMailService,
    private templateService: ITemplateService
  ) {}

  async createRequest(
    user: User,
    product_id: string,
    description: string,
    isTestRequest: boolean = false
  ) {
    const testPrefix = isTestRequest ? "[TEST] " : "";

    const request = await this.db.$transaction(async tx => {
      const request = await tx.buyerContactRequest.create({
        data: {
          user_id: user.id,
          product_id: product_id,
          description: `${testPrefix}${description}`,
        },
        include: {
          user: true,
          product: {
            include: {
              subscriptions: {
                where: {
                  status: {
                    in: ProductSubscriptionActiveStatuses,
                  },
                },
                orderBy: { created_at: "desc" },
                include: {
                  user_roles: {
                    where: {
                      type: UserRoleType.PRODUCT_SUBSCRIPTION,
                      role: Role.OWNER,
                    },
                    include: {
                      user: true,
                    },
                  },
                },
              },
            },
          },
        },
      });

      if (!request.product.subscriptions.length) {
        throw new Error("No active subscription found for this product");
      }

      const activeSubscription = request.product.subscriptions[0];

      const recipients = activeSubscription.user_roles
        .filter(user_role => user_role.role === Role.OWNER) // Only send to owners
        .map(filteredUserRole => filteredUserRole.user);

      const emailPromises = recipients.map(async recipient => {
        const emailBody = this.templateService.renderBuyerContactEmail({
          recipient,
          request,
        });

        await this.mailService.send({
          to: [request.product.lead_prospect_email || recipient.email],
          subject: `${testPrefix}You have a new inbound lead! 🔥 | Revyse`,
          body: emailBody,
        });
      });
      await Promise.all(emailPromises);
      return request;
    });

    return request;
  }
}
