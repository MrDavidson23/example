import {
  ContractLineItemLocationStatus,
  type Prisma,
  type PrismaClient,
  type ContractLineItemProduct,
  type ContractLineItemFee,
  type ContractLineItem,
  type ContractLineItemLocation,
  type ContractLineItemStatus,
} from "@prisma/client";
import type { ProductService } from "./product.service.server";
import { isNil } from "lodash";
import type { ContractService } from "./contract.service.server";

export type LocationVendorsFilters = {
  page: number;
  perPage: number;
  query?: string;
  status: string[];
  permissionLevel: string[];
};

export class ContractLineItemService {
  constructor(
    private db: PrismaClient,
    private productService: ProductService,
    private contractService: ContractService
  ) {}

  async loadContractLineItem(id: string | undefined) {
    return this.db.contractLineItem.findUniqueOrThrow({
      where: { id },
      include: {
        _count: {
          select: {
            contract_line_item_locations: true,
          },
        },
        contract_line_item_locations: {
          include: {
            location: true,
          },
          orderBy: {
            location: {
              name: "asc",
            },
          },
        },
        contract: {
          include: {
            manager_account_vendor: { include: { vendor: true } },
          },
        },
        contract_line_item_products: {
          include: {
            product: true,
          },
        },
        contract_line_item_fees: {
          include: {
            fee: true,
          },
        },
      },
    });
  }

  async updateContractLineItem({ id, data }: { id: string; data: any }) {
    const lineItem = await this.db.$transaction(async tx => {
      const {
        contract_line_item_products,
        contract_line_item_fees,
        ...formattedData
      } = data;

      const updatedContractLineItem = await tx.contractLineItem.update({
        where: {
          id,
        },
        data: {
          ...formattedData,
        },
      });

      const contractLineItemProducts = data.contract_line_item_products;
      if (contractLineItemProducts && contractLineItemProducts.length > 0) {
        await Promise.all(
          contractLineItemProducts.map(
            async (contractLineItemProduct: ContractLineItemProduct) => {
              if (contractLineItemProduct.id) {
                await tx.contractLineItemProduct.update({
                  where: {
                    id: contractLineItemProduct.id,
                  },
                  data: {
                    ...contractLineItemProduct,
                  },
                });
              } else {
                await tx.contractLineItemProduct.create({
                  data: {
                    ...contractLineItemProduct,
                    contract_line_item_id: updatedContractLineItem.id,
                  },
                });
              }
            }
          )
        );
      }

      const contractLineItemFees = data.contract_line_item_fees;

      if (contractLineItemFees && contractLineItemFees.length > 0) {
        await Promise.all(
          contractLineItemFees.map(
            async (contractLineItemFee: ContractLineItemFee) => {
              if (contractLineItemFee.id) {
                await tx.contractLineItemFee.update({
                  where: {
                    id: contractLineItemFee.id,
                  },
                  data: {
                    ...contractLineItemFee,
                  },
                });
              }
            }
          )
        );
      }
      return updatedContractLineItem;
    });
    return lineItem;
  }

  async selectContractLineItemProductsAndFees({
    id,
    data,
    contractId,
    productIds,
    feeIds,
  }: {
    id: string;
    data: any;
    contractId: string;
    productIds?: string[];
    feeIds?: string[];
  }) {
    const lineItem = await this.db.$transaction(async tx => {
      const contract = await tx.contract.findUniqueOrThrow({
        where: {
          id: contractId,
        },
      });

      const newContractLineItemData: Prisma.ContractLineItemCreateArgs["data"] =
        {
          contract_id: contractId,
        };

      // If the contract has a location, associate the new contract line item with that location
      if (contract.location_id) {
        newContractLineItemData.contract_line_item_locations = {
          create: [
            {
              location: {
                connect: {
                  id: contract.location_id,
                },
              },
              expires_at: null,
            },
          ],
        };
      }

      const loadedContractLineItem =
        id === "new"
          ? await tx.contractLineItem.create({
              data: newContractLineItemData,
              include: {
                contract_line_item_products: true,
                contract_line_item_fees: true,
              },
            })
          : await this.loadContractLineItem(id);

      if (isNil(loadedContractLineItem)) {
        throw new Response("No contract contractLineItem found", {
          status: 404,
        });
      }

      const contractLineItemsProducts =
        loadedContractLineItem?.contract_line_item_products
          ? loadedContractLineItem.contract_line_item_products.map(
              product => product.product_id
            )
          : [];

      const contractLineItemFees =
        loadedContractLineItem?.contract_line_item_fees
          ? loadedContractLineItem.contract_line_item_fees.map(
              fee => fee.fee_id
            )
          : [];

      for (const product of data.products) {
        const existingEntry = await tx.contractLineItemProduct.findFirst({
          where: {
            contract_line_item_id: loadedContractLineItem.id,
            product_id: product.id,
          },
        });
        if (!existingEntry) {
          await tx.contractLineItemProduct.create({
            data: {
              department: "",
              contract_line_item_id: loadedContractLineItem.id,
              product_id: product.id,
            },
          });
        }
      }

      for (const fee of data.fees) {
        const existingEntry = await tx.contractLineItemFee.findFirst({
          where: {
            contract_line_item_id: loadedContractLineItem.id,
            fee_id: fee.id,
          },
        });
        if (!existingEntry) {
          await tx.contractLineItemFee.create({
            data: {
              department: "",
              contract_line_item_id: loadedContractLineItem.id,
              fee_id: fee.id,
            },
          });
        }
      }
      // Compare previously selected products with currently selected products
      const deselectedProducts = contractLineItemsProducts.filter(
        productId => !productIds?.includes(productId)
      );

      // Delete contractLineItemProduct entries for deselected products
      for (const deselectedProduct of deselectedProducts) {
        await tx.contractLineItemProduct.deleteMany({
          where: {
            contract_line_item_id: loadedContractLineItem.id,
            product_id: deselectedProduct,
          },
        });
      }

      // Compare previously selected fees with currently selected fees
      const deselectedFees = contractLineItemFees.filter(
        feeId => feeId && !feeIds?.includes(feeId)
      );

      // Delete contractLineItemFee entries for deselected fees
      for (const deselectedFee of deselectedFees) {
        await tx.contractLineItemFee.deleteMany({
          where: {
            contract_line_item_id: loadedContractLineItem.id,
            fee_id: deselectedFee,
          },
        });
      }
      return loadedContractLineItem;
    });
    return lineItem;
  }

  async deleteContractLineItem(id: string) {
    try {
      await this.db.contractLineItemLocation.deleteMany({
        where: { contract_line_item_id: id },
      });
      await this.db.contractLineItemProduct.deleteMany({
        where: { contract_line_item_id: id },
      });
      await this.db.contractLineItemFee.deleteMany({
        where: { contract_line_item_id: id },
      });
      await this.db.contractLineItem.delete({ where: { id } });
      return {
        success: true,
      };
    } catch (error) {
      return {
        success: false,
      };
    }
  }

  async getContractLineItemProducts(
    filters: Prisma.ProductWhereInput,
    managerAccountVendorId: string
  ) {
    const productIds = (
      filters
        ? await this.db.product.findMany({
            select: { id: true },
            where: filters,
            orderBy: {
              title: "desc",
            },
          })
        : await this.db.product.findMany({
            select: { id: true },
            where: {
              vendor_id: managerAccountVendorId,
            },
            orderBy: {
              title: "desc",
            },
          })
    ).map(p => p.id);

    return await this.productService.getProductsWithRatings({
      ids: productIds,
    });
  }
  async updateContractLineItemStatus({
    contractLineItemId,
    status,
    newCanceledDate,
  }: {
    contractLineItemId: string;
    status: ContractLineItemStatus;
    newCanceledDate?: Date | null;
  }) {
    await this.db.contractLineItemLocation.updateMany({
      where: {
        contract_line_item_id: contractLineItemId,
        status: {
          not: ContractLineItemLocationStatus.Canceled,
        },
      },
      data: {
        status: status as ContractLineItemLocationStatus,
        canceled_at: newCanceledDate,
      },
    });

    const updatedContractLineItem = await this.db.contractLineItem.update({
      where: {
        id: contractLineItemId,
      },
      data: {
        status,
        canceled_at: newCanceledDate,
      },
    });

    return updatedContractLineItem;
  }

  async assignContractLineItemLocations(
    contractLineItem: ContractLineItem & {
      contract_line_item_locations: ContractLineItemLocation[];
    },
    data: {
      locations: {
        id: string;
        expires_at: Date;
      }[];
    }
  ) {
    const existingContractLineItemLocations =
      contractLineItem.contract_line_item_locations;
    const existingLocationIds = new Set(
      existingContractLineItemLocations.map(item => item.location_id)
    );

    const locationsToAdd = data.locations.filter(
      location => !existingLocationIds.has(location.id)
    );
    const locationsToUpdate = data.locations.filter(location =>
      existingLocationIds.has(location.id)
    );
    const extractedIds = data.locations.map(location => location.id);

    const contractLineItemLocationIdsToDelete =
      existingContractLineItemLocations
        .filter(item => !extractedIds.includes(item.location_id))
        .map(item => item.id);

    await this.db.$transaction(async tx => {
      if (contractLineItem.is_corporate_only) {
        await tx.contractLineItem.update({
          where: {
            id: contractLineItem.id,
          },
          data: {
            is_corporate_only: false,
          },
        });
      }

      // Add new location contract contractLineItem tier records
      for (const location of locationsToAdd) {
        await tx.contractLineItemLocation.create({
          data: {
            contract_line_item: { connect: { id: contractLineItem.id } },
            location: { connect: { id: location.id } },
            expires_at: location.expires_at,
          },
        });
      }

      for (const location of locationsToUpdate) {
        const existingContractLineItemLocation =
          await tx.contractLineItemLocation.findFirst({
            where: {
              location_id: location.id,
              contract_line_item_id: contractLineItem.id,
            },
          });
        if (existingContractLineItemLocation) {
          await tx.contractLineItemLocation.update({
            where: {
              id: existingContractLineItemLocation.id,
            },
            data: {
              expires_at: location.expires_at,
            },
          });
        }
      }
      // Delete old location contract contractLineItem tier records
      await this.db.contractLineItemLocation.deleteMany({
        where: {
          id: {
            in: contractLineItemLocationIdsToDelete,
          },
        },
      });
    });
  }
}
