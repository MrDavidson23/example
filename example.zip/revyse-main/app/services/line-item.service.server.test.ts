import {
  ContractPricingType,
  ContractStatus,
  LocationClass,
  LocationStatus,
  ProductState,
  VendorState,
} from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { createTestUser } from "./seeds/createTestUser";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { authService } = await TestDIContainer(tx);

    const user = await createTestUser(faker.internet.email(), authService);

    const account = await tx.managerAccount.create({
      data: {
        name: faker.company.name(),
        manager_account_vendors: {
          create: {
            vendor: {
              create: {
                name: faker.company.name(),
              },
            },
          },
        },
      },
      include: {
        manager_account_vendors: true,
      },
    });

    const category = await tx.productCategory.create({
      data: {
        name: faker.company.name(),
        description: "description",
        slug: "category",
        faq_1: "faq 1",
        faq_2: "faq 2",
        faq_3: "faq 3",
        faq_1_answer: "faq 1 answer",
        faq_2_answer: "faq 2 answer",
        faq_3_answer: "faq 3 answer",
        meta_description: "meta description",
        page_title: "page title",
      },
    });

    const vendor = await tx.vendor.create({
      data: {
        slug: faker.internet.url(),
        name: faker.company.name(),
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
        products: {
          createMany: {
            data: [
              {
                title: "Line Item Product 1",
                description: "description",
                state: ProductState.discovery,
                approved_at: new Date(),
                slug: "line-item-product-1",
                page_title: "page title",
                positioning: "positioning",
                meta_description: "meta description",
                primary_category_id: category.id,
              },
              {
                title: "Line Item Product 2",
                description: "description",
                state: ProductState.discovery,
                approved_at: new Date(),
                slug: "line-item-product-2",
                page_title: "page title",
                positioning: "positioning",
                meta_description: "meta description",
                primary_category_id: category.id,
              },
            ],
          },
        },
      },
      include: {
        products: true,
      },
    });

    const accountVendor = await tx.managerAccountVendor.upsert({
      where: {
        manager_account_id_vendor_id: {
          manager_account_id: account.id,
          vendor_id: vendor.id,
        },
      },
      create: {
        manager_account: { connect: { id: account.id } },
        vendor: { connect: { id: vendor.id } },
      },
      update: {},
    });

    const contracts = await Promise.all(
      Array.from({ length: 3 }).map(() => {
        const isCorporate = !faker.number.int({ min: 0, max: 5 });
        return tx.contract.create({
          data: {
            contract_owner_name: faker.person.fullName(),
            approver: faker.person.fullName(),
            expires_at: faker.date.future(),
            current_term_end_date: faker.date.future(),
            name: faker.commerce.productName(),
            renewal_reminder_lead_time_months: faker.number.int({ max: 12 }),
            status: ContractStatus.Active,
            term_length_months: faker.number.int({ max: 48 }),
            manager_account_vendor: {
              connect: { id: accountVendor.id },
            },
            is_corporate_only: isCorporate,
          },
        });
      })
    );

    const locationNames = [
      "Location 1",
      "Location 2",
      "Location 3",
      "Location 4",
      "Location 5",
    ];

    const locations = await Promise.all(
      locationNames.map(name =>
        tx.location.create({
          data: {
            name,
            pms_id: faker.string.alphanumeric(6),
            owner_name: faker.company.name(),
            street_1: faker.location.streetAddress(),
            street_2: faker.location.secondaryAddress(),
            city: faker.location.city(),
            state: faker.location.state(),
            zip: faker.location.zipCode(),
            region: `${faker.location.city()} ${faker.string.alphanumeric(5)}`,
            unit_count: faker.number.int({ min: 1, max: 1000 }),
            class: faker.helpers.enumValue(LocationClass),
            status: faker.helpers.enumValue(LocationStatus),
            manager_account_id: account.id,
          },
        })
      )
    );

    const productPrices = Array.from(
      "_".repeat(faker.number.int({ min: 1, max: vendor.products.length }))
    ).map(_ => faker.number.int({ min: 100, max: 1000 }));

    const contractWithContractLineItem = await tx.contract.create({
      data: {
        name: faker.commerce.productName(),
        will_auto_renew: true,
        current_term_end_date: null,
        status: ContractStatus.Active,
        is_month_to_month: true,
        manager_account_vendor_id: account.manager_account_vendors[0].id,
        renewal_reminder_lead_time_months: 6,
        auto_renew_term_length: 12,
        contract_owner_name: faker.person.fullName(),
        approver: faker.person.fullName(),
        contract_line_items: {
          create: {
            name: faker.commerce.productName(),
            contract_line_item_products: {
              createMany: {
                data: productPrices.map(price => ({
                  department: "Support",
                  price: price,
                  product_id:
                    vendor.products[
                      faker.number.int({
                        min: 0,
                        max: vendor.products.length - 1,
                      })
                    ].id,
                })),
              },
            },
          },
        },
      },
      include: {
        manager_account_vendor: {
          include: {
            vendor: true,
          },
        },
        contract_line_items: {
          include: {
            contract_line_item_products: {
              include: {
                product: true,
              },
            },
          },
        },
      },
    });

    return {
      user,
      account,
      vendor,
      locations,
      contract: contractWithContractLineItem,
      contracts,
      products: vendor.products,
      category,
    };
  },
});

describe("ContractLineItemService", () => {
  describe("loadContractLineItem", () => {
    test(
      "it should return a contract line item by id",
      withFixtures(async ({ contract }, tx) => {
        const { contractLineItemService } = TestDIContainer(tx);

        const lineItem = await contractLineItemService.loadContractLineItem(
          contract.contract_line_items[0].id
        );

        expect(lineItem).not.toBeNull();
        expect(lineItem.contract_line_item_products).not.toBeNull();
        expect(lineItem.contract_line_item_products).toEqual(
          contract.contract_line_items[0].contract_line_item_products
        );
        expect(lineItem.name).toEqual(contract.contract_line_items[0].name);
      })
    );
  });

  describe("deleteContractLineItem", () => {
    test(
      "it should delete a contract line item",
      withFixtures(async ({ contract }, tx) => {
        const { contractLineItemService, db } = TestDIContainer(tx);

        const response = await contractLineItemService.deleteContractLineItem(
          contract.contract_line_items[0].id
        );
        const lineItem = await db.contractLineItem.findFirst({
          where: {
            id: contract.contract_line_items[0].id,
          },
        });
        expect(response.success).toBeTruthy();
        expect(lineItem).toBeNull();
      })
    );
  });

  describe("selectContractLineItemProductsAndFees, updateContractLineItem", () => {
    test(
      "it should create a new contract line item and then set the price",
      withFixtures(
        async ({ contract, products, vendor, category, account }, tx) => {
          const { contractLineItemService, feeService } = TestDIContainer(tx);

          const fee = await feeService.createFee(
            "New Fee",
            category.id,
            vendor.id,
            account.id
          );

          const newLineItem =
            await contractLineItemService.selectContractLineItemProductsAndFees(
              {
                id: "new",
                data: { products, fees: [{ ...fee }] },
                contractId: contract.id,
              }
            );

          const lineItem = await contractLineItemService.loadContractLineItem(
            newLineItem.id
          );

          expect(lineItem).not.toBeNull();
          expect(lineItem.contract_line_item_products).not.toBeNull();
          expect(lineItem.contract_line_item_products).toHaveLength(2);
          expect(lineItem.contract_line_item_fees).not.toBeNull();
          expect(lineItem.contract_line_item_fees).toHaveLength(1);

          const updatedLineItem =
            await contractLineItemService.updateContractLineItem({
              id: lineItem.id,
              data: {
                name: "New Line Item Name",
                is_corporate_only: false,
                pricing_type: ContractPricingType.FlatRate,
                price: parseFloat(faker.commerce.price()),
                setup_fee: parseFloat(faker.commerce.price()),
                contract_line_item_products:
                  lineItem.contract_line_item_products.map(product => ({
                    price: parseFloat(faker.commerce.price()),
                    department: "Support",
                    product_id: product.product_id,
                    id: product.id,
                  })),
                contract_line_item_fees: lineItem.contract_line_item_fees.map(
                  fee => ({
                    price: parseFloat(faker.commerce.price()),
                    department: "Support",
                    fee_id: fee.fee_id,
                    id: fee.id,
                  })
                ),
              },
            });

          expect(updatedLineItem).not.toBeNull();
          expect(updatedLineItem.name).toEqual("New Line Item Name");
        }
      )
    );
  });

  describe("assignContractLineItemLocations", () => {
    test(
      "it should assign contract line item locations",
      withFixtures(async ({ contract, locations }, tx) => {
        const { db, contractLineItemService } = TestDIContainer(tx);
        const lineItem = await contractLineItemService.loadContractLineItem(
          contract.contract_line_items[0].id
        );

        const locationsData = locations.map(location => {
          return {
            id: location.id,
            expires_at: contract.current_term_end_date ?? new Date(),
          };
        });
        await contractLineItemService.assignContractLineItemLocations(
          lineItem,
          { locations: locationsData }
        );

        const contractLineItemLocations =
          await db.contractLineItemLocation.findMany({
            where: {
              contract_line_item_id: lineItem.id,
            },
          });
        expect(contractLineItemLocations).not.toBeNull();
        expect(contractLineItemLocations).toHaveLength(5);
      })
    );
  });
});
