import type { PrismaClient } from "@prisma/client";
import { ContractStatus } from "@prisma/client";
import type { MailService, MockMailService } from "./mail.service.server";
import type { TemplateService } from "./template.service.server";
import type {
  ManagerAccountTaskService,
  TaskContract,
} from "./manager-account-task.service.server";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
dayjs.extend(utc);

export class ContractRenewalService {
  // eslint-disable-next-line no-useless-constructor
  constructor(
    private db: PrismaClient,
    private mailService: MailService | MockMailService,
    private templateService: TemplateService,
    private managerAccountTaskService: ManagerAccountTaskService
  ) {}

  async handleContractRenewal() {
    console.log("Cronjob sendContractRenewalReminders started at", new Date());

    try {
      const currentDate = new Date();
      const startOfDay = dayjs.utc(currentDate).startOf("day").toDate();

      const reminderContracts = await this.getReminderContracts();

      console.log("Contracts to process:", reminderContracts);

      for (const contract of reminderContracts) {
        await this.sendRenewalEmailAndCreateTask(contract, startOfDay);
      }
    } catch (e: any) {
      console.error(e);
      console.error("Error in sendContractRenewalReminders cron job:", e);
    } finally {
      console.log(
        "Cronjob sendContractRenewalReminders execution completed at",
        new Date()
      );
    }
  }

  private async getReminderContracts() {
    return await this.db.contract.findMany({
      where: {
        will_auto_renew: true,
        status: {
          not: ContractStatus.Canceled,
        },
        task_owner_id: {
          not: null,
        },
      },
      include: {
        manager_account_vendor: {
          include: {
            vendor: {
              select: {
                name: true,
              },
            },
            manager_account: {
              include: {
                manager_account_roles: {
                  where: {
                    deleted_at: null,
                  },
                },
              },
            },
          },
        },
      },
    });
  }

  private async sendRenewalEmailAndCreateTask(
    contract: TaskContract,
    startOfDay: Date
  ) {
    let renewalReminderDate = null;

    if (contract.renewal_reminder_date) {
      renewalReminderDate = dayjs.utc(contract.renewal_reminder_date);
    } else if (contract.renewal_reminder_lead_time_months) {
      const currentTermEndDate = dayjs.utc(contract.current_term_end_date);
      const renewalReminderLeadTime =
        contract.renewal_reminder_lead_time_months;
      renewalReminderDate = currentTermEndDate.subtract(
        renewalReminderLeadTime,
        "month"
      );
    }

    const existingTask = await this.db.taskContractRenewal.findFirst({
      where: {
        contract_id: contract.id,
      },
    });

    if (
      !existingTask &&
      renewalReminderDate &&
      renewalReminderDate.startOf("day").isSame(startOfDay)
    ) {
      const task =
        await this.managerAccountTaskService.createContractRenewalTask(
          contract,
          renewalReminderDate
        );

      const emailBody = this.templateService.renderRenewalReminderEmail(
        contract,
        task
      );

      await this.mailService.send({
        to: contract.renewal_reminder_emails,
        subject: `Contract Renewal Reminder | ${contract.name}`,
        body: emailBody,
      });
    }
  }
}
