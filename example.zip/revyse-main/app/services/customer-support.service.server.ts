import { getEnv } from "./env.service.server";
import type { IMailService, MockMailService } from "./mail.service.server";

export type ICustomerSupportService = {
  sendCSEmail(subject: string, body: string): Promise<void>;
};

export class CustomerSupportService implements ICustomerSupportService {
  constructor(private mailService: IMailService | MockMailService) {}

  async sendCSEmail(subject: string, body: string): Promise<void> {
    const to = getEnv().CUSTOMER_SUPPORT_EMAIL_LIST;
    await this.mailService.send({ to, subject, body });
  }
}
