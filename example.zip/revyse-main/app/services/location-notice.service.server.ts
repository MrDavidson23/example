import type { ManagerAccount, Prisma, PrismaClient } from "@prisma/client";
import {
  ContractLineItemLocationStatus,
  ContractLineItemStatus,
  ContractStatus,
  LocationNoticeStatus,
  LocationNoticeStep,
  ManagerAccountVendorContactType,
} from "@prisma/client";
import type { IMailService } from "./mail.service.server";
import type { MockS3Service } from "./s3.service.server";
import type { Readable } from "stream";
import type Mail from "nodemailer/lib/mailer";
import { getEnv } from "./env.service.server";
import {
  getLocationNoticeName,
  type LocationNotice,
  LocationNoticeType,
} from "../utils/location-notice.utils";
import {
  Permission,
  type PermissionUser,
  canDoOnAccount,
} from "../utils/intelligence-permission.utils";

export type LocationNoticesFilters = {
  searchQuery?: string;
  status?: ("sent" | "incomplete")[];
  vendors?: string[];
  type?: LocationNoticeType[];
  sent_date?: [string | undefined, string | undefined];
};

export type LocationTerminationServiceFilters = {
  searchQuery?: string;
  status?: ("sent" | "incomplete")[];
  sent_date?: [string | undefined, string | undefined];
};

export class LocationNoticeService {
  constructor(
    private db: PrismaClient,
    private mailService: IMailService,
    private s3Service: MockS3Service
  ) {}

  private getLocationNoticeDispositionQuery(
    locationId: string,
    filters: LocationNoticesFilters
  ) {
    const where = {
      location_id: locationId,
      status: {
        not: LocationNoticeStatus.InProgress,
      },
      AND: [
        ...(filters.status
          ? [
              {
                status: {
                  in: filters.status.flatMap(status => {
                    if (status === "sent") {
                      return [LocationNoticeStatus.Sent];
                    } else if (status === "incomplete") {
                      return [LocationNoticeStatus.Saved];
                    }
                    return [];
                  }),
                },
              },
            ]
          : []),
        ...(filters.vendors
          ? [
              {
                location_notice_recipients: {
                  some: {
                    manager_account_vendor: {
                      vendor_id: {
                        in: filters.vendors,
                      },
                    },
                  },
                },
              },
            ]
          : []),
        ...(filters.sent_date
          ? [
              {
                status: LocationNoticeStatus.Sent,
                status_updated_at: {
                  gte: filters.sent_date[0]
                    ? new Date(filters.sent_date[0]).toISOString()
                    : undefined,
                  lte: filters.sent_date[1]
                    ? new Date(filters.sent_date[1]).toISOString()
                    : undefined,
                },
              },
            ]
          : []),
      ],
    } satisfies Prisma.LocationNoticeDispositionFindManyArgs["where"];

    return where;
  }

  private getLocationServiceTerminationQuery(
    locationId: string,
    filters: LocationTerminationServiceFilters
  ) {
    const where = {
      location_id: locationId,
      status: {
        not: LocationNoticeStatus.InProgress,
      },
      AND: [
        ...(filters.status
          ? [
              {
                status: {
                  in: filters.status.flatMap(status => {
                    if (status === "sent") {
                      return [LocationNoticeStatus.Sent];
                    } else if (status === "incomplete") {
                      return [LocationNoticeStatus.Saved];
                    }
                    return [];
                  }),
                },
              },
            ]
          : []),
        ...(filters.sent_date
          ? [
              {
                status: LocationNoticeStatus.Sent,
                status_updated_at: {
                  gte: filters.sent_date[0]
                    ? new Date(filters.sent_date[0]).toISOString()
                    : undefined,
                  lte: filters.sent_date[1]
                    ? new Date(filters.sent_date[1]).toISOString()
                    : undefined,
                },
              },
            ]
          : []),
      ],
    } satisfies Prisma.LocationServiceTerminationNoticeFindManyArgs["where"];

    return where;
  }

  async getLastLocationDispositionNotice(locationId: string) {
    const locationNoticeDisposition =
      await this.db.locationNoticeDisposition.findFirst({
        where: {
          location_id: locationId,
          status: LocationNoticeStatus.Sent,
        },
        orderBy: {
          status_updated_at: "desc",
        },
        include: {
          manager_account_role: {
            include: {
              user: true,
            },
          },
          location_notice_recipients: {
            include: {
              manager_account_vendor: {
                include: {
                  vendor: true,
                },
              },
            },
          },
        },
      });

    return locationNoticeDisposition;
  }

  async getLocationNotices(
    user: PermissionUser,
    account: { id: string },
    locationId: string,
    filters: LocationNoticesFilters
  ) {
    const whereLocationNoticeDisposition =
      this.getLocationNoticeDispositionQuery(locationId, filters);

    const locationNoticeDispositions =
      !filters.type ||
      filters.type.includes(LocationNoticeType.LocationNoticeDisposition)
        ? await this.db.locationNoticeDisposition.findMany({
            where: whereLocationNoticeDisposition,
            orderBy: { created_at: "desc" },
            include: {
              manager_account_role: { include: { user: true } },
              location_notice_recipients: {
                include: {
                  manager_account_vendor: { include: { vendor: true } },
                },
              },
            },
          })
        : [];

    const whereLocationServiceTermination =
      this.getLocationServiceTerminationQuery(locationId, filters);

    const locationServiceTerminations =
      !filters.type ||
      filters.type.includes(LocationNoticeType.LocationServiceTermination)
        ? await this.db.locationServiceTerminationNotice.findMany({
            where: whereLocationServiceTermination,
            orderBy: { created_at: "desc" },
            include: {
              manager_account_role: { include: { user: true } },
              manager_account_vendor: { include: { vendor: true } },
            },
          })
        : [];

    const locationNotices = [
      ...locationNoticeDispositions.map(l => ({
        ...l,
        type: LocationNoticeType.LocationNoticeDisposition,
      })),
      ...locationServiceTerminations.map(lst => ({
        ...lst,
        type: LocationNoticeType.LocationServiceTermination,
      })),
    ];

    // Sort by status_updated_at desc
    locationNotices.sort((a, b) => {
      const aDate = a.status_updated_at ?? a.updated_at;
      const bDate = b.status_updated_at ?? b.updated_at;
      return bDate.getTime() - aDate.getTime();
    });

    // Get names
    const locationNoticesWithName = locationNotices.map(locationNotice => ({
      ...locationNotice,
      name: getLocationNoticeName(locationNotice as LocationNotice),
    }));

    // Filter by name or vendor name with search query
    const filteredResult = locationNoticesWithName.filter(locationNotice => {
      if (!filters.searchQuery) return true;

      const searchQueryLower = filters.searchQuery.toLowerCase();

      return (
        locationNotice.name.toLowerCase().includes(searchQueryLower) ||
        ("location_notice_recipients" in locationNotice &&
          locationNotice.location_notice_recipients.some(r =>
            r.manager_account_vendor.vendor.name
              .toLowerCase()
              .includes(searchQueryLower)
          )) ||
        ("manager_account_vendor" in locationNotice &&
          locationNotice.manager_account_vendor.vendor.name
            .toLowerCase()
            .includes(searchQueryLower))
      );
    });

    const userCanViewCompanyLevelContractDetails = canDoOnAccount(
      user,
      account,
      Permission.ViewCompanyLevelContractDetails
    );

    // Add can_view_details field based on user permissions
    let data;
    if (userCanViewCompanyLevelContractDetails) {
      data = filteredResult.map(locationNotice => ({
        ...locationNotice,
        can_view_details: true,
      }));
    } else {
      const accountVendorIds = filteredResult.flatMap(locationNotice =>
        "location_notice_recipients" in locationNotice
          ? locationNotice.location_notice_recipients.map(
              r => r.manager_account_vendor.id
            )
          : [locationNotice.manager_account_vendor.id]
      );

      const companyLevelContractsRelatedToVendorsLocation =
        await this.db.contract.findMany({
          where: {
            location_id: null,
            status: {
              in: [ContractStatus.Active, ContractStatus.Pending],
            },
            contract_line_items: {
              some: {
                status: {
                  not: ContractLineItemStatus.Canceled,
                },
                contract_line_item_locations: {
                  some: {
                    status: { not: ContractLineItemLocationStatus.Canceled },
                    location_id: locationId,
                  },
                },
              },
            },
            manager_account_vendor: {
              id: {
                in: accountVendorIds,
              },
            },
          },
          select: {
            id: true,
            manager_account_vendor_id: true,
            location_id: true,
          },
        });

      data = filteredResult.map(locationNotice => {
        // If any company level contract is related to a vendor in the notice, can't view details
        const canViewDetails =
          !companyLevelContractsRelatedToVendorsLocation.some(c =>
            "location_notice_recipients" in locationNotice
              ? locationNotice.location_notice_recipients.some(
                  r =>
                    r.manager_account_vendor.id === c.manager_account_vendor_id
                )
              : c.manager_account_vendor_id ===
                locationNotice.manager_account_vendor.id
          );
        return {
          ...locationNotice,
          can_view_details: canViewDetails,
        };
      });
    }

    return data;
  }

  async createLocationNoticeDisposition(
    locationId: string,
    data: {
      termination_date: Date;
      termination_instructions?: string | null | undefined;
      disposition_date: Date;
      task_owner_id: string;
      original_location_notice_id?: string | null;
      manager_account_role_id: string;
    },
    saveProgress?: boolean
  ) {
    const originalLocationNotice = data.original_location_notice_id
      ? await this.db.locationNoticeDisposition.findUnique({
          where: {
            id: data.original_location_notice_id,
          },
          include: {
            location_notice_recipients: true,
          },
        })
      : null;

    // Create location notice
    const locationNotice = await this.db.locationNoticeDisposition.create({
      data: {
        location_id: locationId,
        termination_date: data.termination_date,
        termination_instructions: data.termination_instructions,
        disposition_date: data.disposition_date,
        task_owner_id: data.task_owner_id,
        original_location_notice_id: data.original_location_notice_id,
        manager_account_role_id: data.manager_account_role_id,
        status: saveProgress
          ? LocationNoticeStatus.Saved
          : LocationNoticeStatus.InProgress,
        status_updated_at: saveProgress ? new Date() : undefined,
        step: LocationNoticeStep.Details,
        location_notice_recipients: originalLocationNotice
          ? {
              createMany: {
                data: originalLocationNotice.location_notice_recipients.map(
                  recipient => ({
                    manager_account_vendor_id:
                      recipient.manager_account_vendor_id,
                    name: recipient.name,
                    email: recipient.email,
                  })
                ),
              },
            }
          : undefined,
      },
    });

    return locationNotice;
  }

  async updateLocationNoticeDisposition(
    locationNoticeId: string,
    data: {
      termination_date: Date;
      termination_instructions?: string | null | undefined;
      disposition_date: Date;
      task_owner_id: string;
      manager_account_role_id: string;
    },
    saveProgress?: boolean
  ) {
    const locationNotice = await this.db.locationNoticeDisposition.findUnique({
      where: {
        id: locationNoticeId,
      },
    });

    if (!locationNotice) {
      throw new Error(`Location notice with id ${locationNoticeId} not found`);
    }

    const resetEmailBody =
      locationNotice.disposition_date?.getTime() !==
        data.disposition_date.getTime() ||
      locationNotice.termination_date?.getTime() !==
        data.termination_date.getTime() ||
      locationNotice.termination_instructions !==
        data.termination_instructions ||
      locationNotice.task_owner_id !== data.task_owner_id;

    return await this.db.locationNoticeDisposition.update({
      where: {
        id: locationNoticeId,
      },
      data: {
        termination_date: data.termination_date,
        termination_instructions: data.termination_instructions,
        disposition_date: data.disposition_date,
        task_owner_id: data.task_owner_id,
        status: saveProgress ? LocationNoticeStatus.Saved : undefined,
        status_updated_at: saveProgress ? new Date() : undefined,
        step: saveProgress ? LocationNoticeStep.Details : undefined,
        manager_account_role_id: data.manager_account_role_id,
        email_body: resetEmailBody ? null : undefined,
      },
    });
  }

  async getVendorRecipientsOptions(
    locationId: string,
    user: PermissionUser,
    account: ManagerAccount
  ) {
    const canViewAndManageSensitiveContracts = canDoOnAccount(user, account, [
      Permission.ViewSensitiveContracts,
      Permission.ManageSensitiveContracts,
    ]);

    const vendors = await this.db.managerAccountVendor.findMany({
      where: {
        contracts: {
          some: {
            status: {
              in: [ContractStatus.Active, ContractStatus.Pending],
            },
            is_sensitive: !canViewAndManageSensitiveContracts
              ? false
              : undefined,
            contract_line_items: {
              some: {
                status: {
                  not: ContractLineItemStatus.Canceled,
                },
                contract_line_item_locations: {
                  some: {
                    status: { not: ContractLineItemLocationStatus.Canceled },
                    location_id: locationId,
                  },
                },
              },
            },
          },
        },
      },
      include: {
        vendor: true,
        manager_account_vendor_contacts: {
          where: {
            type: {
              in: [
                ManagerAccountVendorContactType.Disposition,
                ManagerAccountVendorContactType.Main,
              ],
            },
          },
        },
      },
    });

    return vendors.map(vendor => {
      const cancellation_contact = vendor.manager_account_vendor_contacts.find(
        contact => contact.type === ManagerAccountVendorContactType.Disposition
      );

      const main_contact = vendor.manager_account_vendor_contacts.find(
        contact => contact.type === ManagerAccountVendorContactType.Main
      );

      return {
        ...vendor,
        contact: cancellation_contact || main_contact,
      };
    });
  }

  async getLocationNoticeDisposition(
    locationNoticeId: string,
    locationId: string,
    user: PermissionUser,
    account: { id: string }
  ) {
    const userCanViewCompanyLevelContractDetails = canDoOnAccount(
      user,
      account,
      Permission.ViewCompanyLevelContractDetails
    );

    return this.db.locationNoticeDisposition.findUnique({
      where: {
        id: locationNoticeId,
        location_notice_recipients: userCanViewCompanyLevelContractDetails
          ? undefined
          : // If user can't view company level contracts,
            // we make sure none of the recipients are related to company level contracts
            {
              none: {
                manager_account_vendor: {
                  contracts: {
                    some: {
                      location_id: null,
                      status: {
                        in: [ContractStatus.Active, ContractStatus.Pending],
                      },
                      contract_line_items: {
                        some: {
                          status: {
                            not: ContractLineItemStatus.Canceled,
                          },
                          contract_line_item_locations: {
                            some: {
                              status: {
                                not: ContractLineItemLocationStatus.Canceled,
                              },
                              location_id: locationId,
                            },
                          },
                        },
                      },
                    },
                  },
                },
              },
            },
      },
      include: {
        location_notice_recipients: {
          include: {
            manager_account_vendor: {
              include: {
                vendor: true,
              },
            },
          },
        },
        task_owner: {
          include: {
            user: true,
          },
        },
        manager_account_role: {
          include: {
            user: true,
          },
        },
        email_attachments: true,
      },
    });
  }

  async upsertLocationNoticeDispositionRecipients(
    locationNoticeId: string,
    vendorIds: string[],
    managerAccountRoleId: string,
    saveProgress?: boolean
  ) {
    const contacts = await this.db.managerAccountVendorContact.findMany({
      where: {
        manager_account_vendor_id: {
          in: vendorIds,
        },
        type: {
          in: [
            ManagerAccountVendorContactType.Disposition,
            ManagerAccountVendorContactType.Main,
          ],
        },
      },
    });

    await this.db.locationNoticeDisposition.update({
      where: {
        id: locationNoticeId,
      },
      data: {
        step: LocationNoticeStep.Recipients,
        status: saveProgress ? LocationNoticeStatus.Saved : undefined,
        status_updated_at: saveProgress ? new Date() : undefined,
        manager_account_role_id: managerAccountRoleId,
        location_notice_recipients: {
          deleteMany: {},
          createMany: {
            data: vendorIds.map(vendorId => {
              const dispositionContact = contacts.find(
                contact =>
                  contact.manager_account_vendor_id === vendorId &&
                  contact.type === ManagerAccountVendorContactType.Disposition
              );

              const mainContact = contacts.find(
                contact =>
                  contact.manager_account_vendor_id === vendorId &&
                  contact.type === ManagerAccountVendorContactType.Main
              );

              return {
                manager_account_vendor_id: vendorId,
                name: (dispositionContact ?? mainContact)?.name,
                email: (dispositionContact ?? mainContact)?.email,
              };
            }),
          },
        },
      },
    });
  }

  async saveLocationNoticeDispositionDraftEmail(
    locationNoticeId: string,
    fields: {
      subject: string;
      body: string;
      cc_emails: string[];
      attachments: string[];
      uploaded_attachments_to_remove: string[];
      manager_account_role_id: string;
    },
    saveProgress?: boolean
  ) {
    await this.db.locationNoticeDisposition.update({
      where: {
        id: locationNoticeId,
      },
      data: {
        step: LocationNoticeStep.EmailTemplate,
        status: saveProgress ? LocationNoticeStatus.Saved : undefined,
        status_updated_at: saveProgress ? new Date() : undefined,
        manager_account_role_id: fields.manager_account_role_id,
        email_subject: fields.subject,
        email_body: fields.body,
        email_cc_emails: fields.cc_emails,
        email_attachments: {
          deleteMany: {
            id: {
              in: fields.uploaded_attachments_to_remove,
            },
          },
          connect: fields.attachments.map(attachmentId => ({
            id: attachmentId,
          })),
        },
      },
    });
  }

  async sendLocationNoticeDispositionEmail(
    locationNoticeId: string,
    managerAccountRoleId: string
  ) {
    const locationNotice = await this.db.locationNoticeDisposition.findUnique({
      where: {
        id: locationNoticeId,
      },
      include: {
        location_notice_recipients: {
          where: {
            email: {
              not: null,
            },
          },
          include: {
            manager_account_vendor: {
              include: {
                vendor: true,
              },
            },
          },
        },
        email_attachments: true,
        task_owner: {
          include: {
            user: true,
          },
        },
        manager_account_role: {
          include: {
            user: true,
          },
        },
      },
    });

    if (!locationNotice) {
      throw new Error("Location notice not found");
    }

    const attachments: Mail.Attachment[] = await Promise.all(
      locationNotice.email_attachments.map(async attachment => {
        const response = await this.s3Service.getObject(attachment.uri);

        // Read the stream and collect it into a buffer
        const chunks: Uint8Array[] = [];
        for await (const chunk of response.Body as Readable) {
          chunks.push(chunk);
        }
        const buffer = Buffer.concat(chunks);

        return {
          filename: attachment.title,
          content: buffer,
          contentType: attachment.mime_type,
        };
      })
    );

    // get email value from SMTP_FROM env variable
    const env = getEnv();
    const email = env.SMTP_FROM!.split("<")[1].slice(0, -1);

    const from = `${locationNotice.task_owner.user.first_name} ${locationNotice.task_owner.user.last_name}<${email}>`;

    for (const recipient of locationNotice.location_notice_recipients) {
      await this.mailService.send({
        from,
        to: [recipient.email!],
        cc: [
          locationNotice.manager_account_role.user.email,
          ...locationNotice.email_cc_emails,
        ],
        subject: locationNotice.email_subject!,
        body: locationNotice.email_body!,
        attachments,
        replyTo: locationNotice.task_owner.user.email,
      });
    }

    await this.db.locationNoticeDisposition.update({
      where: {
        id: locationNoticeId,
      },
      data: {
        status: LocationNoticeStatus.Sent,
        status_updated_at: new Date(),
        manager_account_role_id: managerAccountRoleId,
      },
    });
  }

  async deleteLocationNoticeDisposition(locationNoticeId: string) {
    await this.db.$transaction(async tx => {
      await tx.locationNoticeDisposition.update({
        where: {
          id: locationNoticeId,
        },
        data: {
          location_notice_recipients: {
            deleteMany: {},
          },
          email_attachments: {
            deleteMany: {},
          },
        },
      });

      await tx.locationNoticeDisposition.delete({
        where: {
          id: locationNoticeId,
        },
      });
    });
  }
}
