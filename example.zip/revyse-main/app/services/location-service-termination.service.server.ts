import type { PrismaClient } from "@prisma/client";
import {
  ContractLineItemLocationStatus,
  ContractLineItemStatus,
  ContractStatus,
  LocationNoticeStatus,
  LocationServiceTerminationStep,
  ManagerAccountVendorContactType,
} from "@prisma/client";
import type { IMailService } from "./mail.service.server";
import type { MockS3Service } from "./s3.service.server";
import type Mail from "nodemailer/lib/mailer";
import type { Readable } from "stream";
import { getEnv } from "./env.service.server";
import { isEmpty } from "lodash";
import type { PermissionUser } from "../utils/intelligence-permission.utils";
import { canDoOnAccount, Permission } from "../utils/intelligence-permission.utils";

export type LocationNoticesFilters = {
  searchQuery?: string;
  status?: ("sent" | "incomplete")[];
  vendors?: string[];
  sent_date?: [string | undefined, string | undefined];
};

export class LocationServiceTerminationService {
  constructor(
    private db: PrismaClient,
    private mailService: IMailService,
    private s3Service: MockS3Service
  ) {}

  async createLocationServiceTermination(
    locationId: string,
    data: {
      termination_date: Date;
      termination_instructions?: string | null | undefined;
      task_owner_id: string;
      manager_account_role_id: string;
      manager_account_vendor_id: string;
      contact_name: string;
      contact_email: string;
      original_location_notice_id?: string | null;
    },
    saveProgress?: boolean
  ) {
    const originalLocationNotice = data.original_location_notice_id
      ? await this.db.locationServiceTerminationNotice.findUnique({
          where: {
            id: data.original_location_notice_id,
          },
          include: {
            services_to_terminate: true,
          },
        })
      : null;

    let servicesToTerminate: string[] = [];
    if (originalLocationNotice) {
      servicesToTerminate = originalLocationNotice.services_to_terminate.map(
        service => service.id
      );
    }
    const serviceTermination =
      await this.db.locationServiceTerminationNotice.create({
        data: {
          location_id: locationId,
          termination_date: data.termination_date,
          termination_instructions: data.termination_instructions,
          contact_email: data.contact_email,
          contact_name: data.contact_name,
          manager_account_vendor_id: data.manager_account_vendor_id,
          task_owner_id: data.task_owner_id,
          original_location_notice_id: data.original_location_notice_id,
          manager_account_role_id: data.manager_account_role_id,
          status: saveProgress
            ? LocationNoticeStatus.Saved
            : LocationNoticeStatus.InProgress,
          status_updated_at: saveProgress ? new Date() : undefined,
          step: LocationServiceTerminationStep.Details,
          services_to_terminate: !isEmpty(servicesToTerminate)
            ? {
                connect: servicesToTerminate.map(id => ({ id })),
              }
            : undefined,
        },
      });

    return serviceTermination;
  }

  async updateLocationServiceTermination(
    serviceTerminationId: string,
    data: {
      termination_date: Date;
      termination_instructions?: string | null | undefined;
      task_owner_id: string;
      manager_account_role_id: string;
      manager_account_vendor_id: string;
      contact_name: string;
      contact_email: string;
    },
    saveProgress?: boolean
  ) {
    const locationNotice =
      await this.db.locationServiceTerminationNotice.findUnique({
        where: {
          id: serviceTerminationId,
        },
      });

    if (!locationNotice) {
      throw new Error(
        `Location notice with id ${serviceTerminationId} not found`
      );
    }

    const resetEmailBody =
      locationNotice.termination_date?.getTime() !==
        data.termination_date.getTime() ||
      locationNotice.termination_instructions !==
        data.termination_instructions ||
      locationNotice.task_owner_id !== data.task_owner_id;

    return await this.db.locationServiceTerminationNotice.update({
      where: {
        id: locationNotice.id,
      },
      data: {
        termination_date: data.termination_date,
        termination_instructions: data.termination_instructions,
        contact_email: data.contact_email,
        contact_name: data.contact_name,
        manager_account_vendor_id: data.manager_account_vendor_id,
        task_owner_id: data.task_owner_id,
        status: saveProgress ? LocationNoticeStatus.Saved : undefined,
        status_updated_at: saveProgress ? new Date() : undefined,
        step: saveProgress ? LocationServiceTerminationStep.Details : undefined,
        manager_account_role_id: data.manager_account_role_id,
        email_body: resetEmailBody ? null : undefined,
      },
    });
  }

  async getVendorOptions(locationId: string) {
    const vendors = await this.db.managerAccountVendor.findMany({
      where: {
        contracts: {
          some: {
            status: {
              in: [ContractStatus.Active, ContractStatus.Pending],
            },
            contract_line_items: {
              some: {
                status: {
                  not: ContractLineItemStatus.Canceled,
                },
                contract_line_item_locations: {
                  some: {
                    status: { not: ContractLineItemLocationStatus.Canceled },
                    location_id: locationId,
                  },
                },
              },
            },
          },
        },
      },
      include: {
        vendor: true,
        manager_account_vendor_contacts: {
          where: {
            type: {
              in: [
                ManagerAccountVendorContactType.Disposition,
                ManagerAccountVendorContactType.Main,
              ],
            },
          },
        },
      },
    });

    return vendors.map(vendor => {
      const cancellation_contact = vendor.manager_account_vendor_contacts.find(
        contact => contact.type === ManagerAccountVendorContactType.Disposition
      );

      const main_contact = vendor.manager_account_vendor_contacts.find(
        contact => contact.type === ManagerAccountVendorContactType.Main
      );

      return {
        ...vendor,
        contact: {
          name: cancellation_contact?.name || main_contact?.name,
          email: cancellation_contact?.email || main_contact?.email,
        },
      };
    });
  }

  async getLocationServiceTermination(
    serviceTerminationId: string,
    locationId: string,
    user: PermissionUser,
    account: { id: string }
  ) {
    const userCanViewCompanyLevelContractDetails = canDoOnAccount(
      user,
      account,
      Permission.ViewCompanyLevelContractDetails
    );

    return this.db.locationServiceTerminationNotice.findUnique({
      where: {
        id: serviceTerminationId,
        manager_account_vendor: userCanViewCompanyLevelContractDetails
        ? undefined
        // If user can't view company level contracts, 
        // we make sure the manager account vendor hasn't any company level contract
        : {
          NOT: {
            contracts: {
              some: {
                location_id: null,
                status: {
                  in: [ContractStatus.Active, ContractStatus.Pending],
                },
                contract_line_items: {
                  some: {
                    status: {
                      not: ContractLineItemStatus.Canceled,
                    },
                    contract_line_item_locations: {
                      some: {
                        status: {
                          not: ContractLineItemLocationStatus.Canceled,
                        },
                        location_id: locationId,
                      },
                    },
                  }
                }
              } 
            }
          }
        }
      },
      include: {
        task_owner: {
          include: {
            user: true,
          },
        },
        manager_account_role: {
          include: {
            user: true,
          },
        },
        services_to_terminate: {
          include: {
            contract: true,
            contract_line_item_products: {
              include: { product: { include: { primary_category: true } } },
            },
            contract_line_item_fees: {
              include: { fee: { include: { category: true } } },
            },
            contract_line_item_locations: {
              select: {
                expires_at: true,
              },
            },
          },
        },
        manager_account_vendor: {
          include: {
            vendor: true,
            manager_account_vendor_contacts: {
              where: {
                type: {
                  in: [
                    ManagerAccountVendorContactType.Disposition,
                    ManagerAccountVendorContactType.Main,
                  ],
                },
              },
            },
          },
        },
        email_attachments: true,
      },
    });
  }

  async getServices(locationId: string, managerAccountVendorId: string) {
    return this.db.contractLineItem.findMany({
      where: {
        status: ContractLineItemStatus.Active,
        contract_line_item_locations: {
          some: {
            status: { not: ContractLineItemLocationStatus.Canceled },
            location_id: locationId,
          },
        },
        contract: {
          manager_account_vendor_id: managerAccountVendorId,
        },
      },
      include: {
        contract: true,
        contract_line_item_products: {
          include: { product: { include: { primary_category: true } } },
        },
        contract_line_item_fees: {
          include: { fee: { include: { category: true } } },
        },
        contract_line_item_locations: {
          where: {
            location_id: locationId,
          },
          select: {
            expires_at: true,
          },
        },
      },
    });
  }

  async getServicesCount(locationId: string, managerAccountVendorId: string) {
    return this.db.contractLineItem.count({
      where: {
        status: ContractLineItemStatus.Active,
        contract_line_item_locations: {
          some: {
            status: { not: ContractLineItemLocationStatus.Canceled },
            location_id: locationId,
          },
        },
        contract: {
          manager_account_vendor_id: managerAccountVendorId,
        },
      },
    });
  }

  async upsertLocationServiceTerminationServices(
    locationNoticeId: string,
    servicesIds: string[],
    managerAccountRoleId: string,
    saveProgress?: boolean
  ) {
    const existingNotice =
      await this.db.locationServiceTerminationNotice.findUnique({
        where: { id: locationNoticeId },
        select: {
          services_to_terminate: {
            select: { id: true },
          },
        },
      });

    if (!existingNotice) {
      throw new Error(`Location notice with id ${locationNoticeId} not found`);
    }

    const existingServiceIds = existingNotice.services_to_terminate.map(
      service => service.id
    );
    const servicesToDisconnect = existingServiceIds.filter(
      id => !servicesIds.includes(id)
    );

    await this.db.locationServiceTerminationNotice.update({
      where: {
        id: locationNoticeId,
      },
      data: {
        step: LocationServiceTerminationStep.SelectServices,
        status: saveProgress ? LocationNoticeStatus.Saved : undefined,
        status_updated_at: saveProgress ? new Date() : undefined,
        manager_account_role_id: managerAccountRoleId,
        services_to_terminate: {
          disconnect: servicesToDisconnect.map(id => ({ id })),
          connect: servicesIds.map(id => ({ id })),
        },
      },
    });
  }

  async saveLocationServiceTerminationDraftEmail(
    locationNoticeId: string,
    fields: {
      subject: string;
      body: string;
      cc_emails: string[];
      attachments: string[];
      uploaded_attachments_to_remove: string[];
      manager_account_role_id: string;
    },
    saveProgress?: boolean
  ) {
    await this.db.locationServiceTerminationNotice.update({
      where: {
        id: locationNoticeId,
      },
      data: {
        step: LocationServiceTerminationStep.EmailTemplate,
        status: saveProgress ? LocationNoticeStatus.Saved : undefined,
        status_updated_at: saveProgress ? new Date() : undefined,
        manager_account_role_id: fields.manager_account_role_id,
        email_subject: fields.subject,
        email_body: fields.body,
        email_cc_emails: fields.cc_emails,
        email_attachments: {
          deleteMany: {
            id: {
              in: fields.uploaded_attachments_to_remove,
            },
          },
          connect: fields.attachments.map(attachmentId => ({
            id: attachmentId,
          })),
        },
      },
    });
  }

  async sendLocationServiceTerminationEmail(
    locationNoticeId: string,
    managerAccountRoleId: string
  ) {
    const locationNotice =
      await this.db.locationServiceTerminationNotice.findUnique({
        where: {
          id: locationNoticeId,
        },
        include: {
          email_attachments: true,
          task_owner: {
            include: {
              user: true,
            },
          },
          manager_account_role: {
            include: {
              user: true,
            },
          },
        },
      });

    if (!locationNotice) {
      throw new Error("Location notice not found");
    }

    const attachments: Mail.Attachment[] = await Promise.all(
      locationNotice.email_attachments.map(async attachment => {
        const response = await this.s3Service.getObject(attachment.uri);

        const chunks: Uint8Array[] = [];
        for await (const chunk of response.Body as Readable) {
          chunks.push(chunk);
        }
        const buffer = Buffer.concat(chunks);

        return {
          filename: attachment.title,
          content: buffer,
          contentType: attachment.mime_type,
        };
      })
    );

    const env = getEnv();
    const email = env.SMTP_FROM!.split("<")[1].slice(0, -1);

    const from = `${locationNotice.task_owner.user.first_name} ${locationNotice.task_owner.user.last_name}<${email}>`;

    await this.mailService.send({
      from,
      to: [locationNotice.contact_email],
      cc: [
        locationNotice.manager_account_role.user.email,
        locationNotice.task_owner.user.email,
        ...locationNotice.email_cc_emails,
      ],
      subject: locationNotice.email_subject!,
      body: locationNotice.email_body!,
      attachments,
      replyTo: locationNotice.task_owner.user.email,
    });

    await this.db.locationServiceTerminationNotice.update({
      where: {
        id: locationNoticeId,
      },
      data: {
        status: LocationNoticeStatus.Sent,
        status_updated_at: new Date(),
        manager_account_role_id: managerAccountRoleId,
      },
    });
  }

  async updateServicesToPendingStatus(locationNoticeId: string) {
    const locationNotice =
      await this.db.locationServiceTerminationNotice.findUnique({
        where: {
          id: locationNoticeId,
        },
        select: {
          services_to_terminate: true,
          location_id: true,
        },
      });

    if (!locationNotice) {
      throw new Error("Location notice not found");
    }

    const servicesIds = locationNotice.services_to_terminate.map(s => s.id);
    return await this.db.contractLineItemLocation.updateMany({
      where: {
        contract_line_item_id: {
          in: servicesIds,
        },
        location_id: locationNotice.location_id,
      },
      data: {
        status: ContractLineItemLocationStatus.Pending,
      },
    });
  }

  async deleteLocationNoticeServiceTermination(serviceTerminationId: string) {
    return await this.db.$transaction(async tx => {
      await tx.locationServiceTerminationNotice.update({
        where: {
          id: serviceTerminationId,
        },
        data: {
          email_attachments: {
            deleteMany: {},
          },
        },
      });

      return await tx.locationServiceTerminationNotice.delete({
        where: {
          id: serviceTerminationId,
        },
      });
    });
  }
}
