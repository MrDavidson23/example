import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { slugify } from "../utils/string.utils";
import { withFixtureFactory } from "../utils/test.utils.server";
import { ProductState, VendorState } from "@prisma/client";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const vendorName = `${faker.company.name()} ${faker.string.alphanumeric(
      5
    )}`;

    const vendor = await tx.vendor.create({
      data: {
        name: vendorName,
        slug: slugify(vendorName),
        state: VendorState.ApprovedForPublishing,
      },
    });

    const product = await tx.product.create({
      data: {
        title: faker.commerce.productName(),
        description: "description",
        state: ProductState.discovery,
        approved_at: new Date(),
        slug: slugify(faker.commerce.productName()),
        page_title: "page title",
        positioning: "positioning",
        meta_description: "meta description",
        vendor: { connect: { id: vendor.id } },
        primary_category: {
          create: {
            name: `${faker.commerce.department()} ${faker.string.alphanumeric(
              5
            )}`,
            description: "description",
            slug: "category",
            faq_1: "faq 1",
            faq_2: "faq 2",
            faq_3: "faq 3",
            faq_1_answer: "faq 1 answer",
            faq_2_answer: "faq 2 answer",
            faq_3_answer: "faq 3 answer",
            meta_description: "meta description",
            page_title: "page title",
            primary_vendor_type: "Test Vendor Type",
          },
        },
      },
    });

    return { vendor, product };
  },
});

describe("VendorService", () => {
  describe("getVendorForDiscovery", () => {
    it(
      "should return vendor with products and integrations",
      withFixtures(async ({ vendor }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        const vendorFromService = await vendorService.getVendorForDiscovery({
          slug: vendor.slug!,
        });

        expect(vendorFromService).toBeDefined();
        expect(vendorFromService.products).toBeDefined();
        expect(vendorFromService.vendor_integrations).toBeDefined();
      })
    );
  });

  describe("getVendor", () => {
    it(
      "should return vendor with products and manager account vendors",
      withFixtures(async ({ vendor }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        const vendorFromService = await vendorService.getVendor(vendor.id);

        expect(vendorFromService).toBeDefined();
        expect(vendorFromService.products).toBeDefined();
        expect(vendorFromService.manager_account_vendors).toBeDefined();
      })
    );
  });

  describe("getVendorWithIntegrations", () => {
    it(
      "should return vendor with vendor integrations and logo file",
      withFixtures(async ({ vendor }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        const vendorFromService = await vendorService.getVendorWithIntegrations(
          vendor.id
        );

        expect(vendorFromService).toBeDefined();
        expect(vendorFromService.vendor_integrations).toBeDefined();
        expect(vendorFromService.logo_file).toBeDefined();
      })
    );
  });

  describe("getVendors", () => {
    it(
      "should return vendors with products",
      withFixtures(async ({ vendor }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        const vendors = await vendorService.getVendors({
          filters: {
            slug: vendor.slug!,
          },
        });

        expect(vendors).toBeDefined();
        expect(vendors.length).toBeGreaterThan(0);
        expect(vendors[0].products).toBeDefined();
      })
    );
  });

  describe("getVendorsCount", () => {
    it(
      "should return count of vendors",
      withFixtures(async ({ vendor }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        const count = await vendorService.getVendorsCount({
          filters: {
            slug: vendor.slug!,
          },
        });

        expect(count).toBeDefined();
        expect(count).toEqual(1);
      })
    );
  });

  describe("getVendorsIdAndName", () => {
    it(
      "should return vendors with id and name",
      withFixtures(async ({ vendor }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        const vendors = await vendorService.getVendorsIdAndName({
          filters: {
            slug: vendor.slug!,
          },
        });

        expect(vendors).toBeDefined();
        expect(vendors.length).toBeGreaterThan(0);
        expect(vendors[0].id).toBeDefined();
        expect(vendors[0].name).toBeDefined();
      })
    );
  });

  describe("getVendorsForAllVendorsPage", () => {
    it(
      "should return vendors with products for all vendors page",
      withFixtures(async ({ vendor }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        const vendors = await vendorService.getVendorsForAllVendorsPage({});

        expect(vendors).toBeDefined();
        expect(vendors.length).toBeGreaterThan(0);
        expect(vendors[0].id).toBeDefined();
        expect(vendors[0].name).toBeDefined();
        expect(vendors[0].slug).toBeDefined();
      })
    );
  });

  describe("createVendor", () => {
    it(
      "should create a vendor",
      withFixtures(async ({ vendor }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        const vendorName = `${faker.company.name()} ${faker.string.alphanumeric(
          5
        )}`;

        const newVendor = await vendorService.createVendor({
          name: vendorName,
          slug: slugify(vendorName),
        });

        const vendorFromDb = await tx.vendor.findFirst({
          where: {
            name: vendorName,
          },
        });

        expect(newVendor).toBeDefined();
        expect(vendorFromDb).toBeDefined();
        expect(vendorFromDb?.name).toEqual(vendorName);
      })
    );
  });

  describe("updateVendor", () => {
    it(
      "should update a vendor",
      withFixtures(async ({ vendor }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        const vendorName = `${faker.company.name()} ${faker.string.alphanumeric(
          5
        )}`;

        const updatedVendor = await vendorService.updateVendor(vendor.id, {
          name: vendorName,
          slug: slugify(vendorName),
        });

        const vendorFromDb = await tx.vendor.findFirst({
          where: {
            id: vendor.id,
          },
        });

        expect(updatedVendor).toBeDefined();
        expect(vendorFromDb).toBeDefined();
        expect(vendorFromDb?.name).toEqual(vendorName);
      })
    );
  });

  describe("deleteVendor", () => {
    it(
      "should delete a vendor",
      withFixtures(async ({ vendor }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        await vendorService.deleteVendor(vendor.id);

        const vendorFromDb = await tx.vendor.findFirst({
          where: {
            id: vendor.id,
          },
        });

        expect(vendorFromDb).toBeNull();
      })
    );
  });

  describe("getVendorIntegrationVendorOptions", () => {
    it(
      "should return vendor integration vendor options",
      withFixtures(async ({ vendor }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        const vendorOptions =
          await vendorService.getVendorIntegrationVendorOptions({
            id: vendor.id,
          });

        expect(vendorOptions).toBeDefined();
        expect(vendorOptions.length).toBeGreaterThan(0);
        expect(vendorOptions[0].id).toBeDefined();
        expect(vendorOptions[0].name).toBeDefined();
        expect(vendorOptions[0].logo_file_id).toBeDefined();
      })
    );
  });

  describe("getVendorIntegrationProductOptions", () => {
    it(
      "should return vendor integration product options",
      withFixtures(async ({ vendor, product }, tx) => {
        const { vendorService } = TestDIContainer(tx);

        const productOptions =
          await vendorService.getVendorIntegrationProductOptions({
            vendor_id: vendor.id,
          });

        expect(productOptions).toBeDefined();
        expect(productOptions.length).toBeGreaterThan(0);
        expect(productOptions[0].id).toBeDefined();
        expect(productOptions[0].title).toBeDefined();
        expect(productOptions[0].logo_file_id).toBeDefined();
      })
    );
  });
});
