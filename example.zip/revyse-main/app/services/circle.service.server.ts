import type { LegalDoc, Post, PrismaClient } from "@prisma/client";
import type { ICircleClientService } from "./circle-client.service.server";

const COMMUNITY_ID = 239731;
const POSTS_ID = COMMUNITY_ID;
const LEGAL_DOCS_ID = 250062;

export type ICircleSOService = {
  getPosts(quantity?: number): Promise<Post[]>;
  getPostsByName(searchTerm: string): Promise<Post[]>;
  getPost(slug: string): Promise<Post>;
  getLegalDoc(slug: string): Promise<LegalDoc>;
  createPosts(): Promise<void>;
  createLegalDocs(): Promise<void>;
  deleteInexistentPosts(): Promise<void>;
  deleteInexistentLegalDocs(): Promise<void>;
  syncPosts(): Promise<void>;
};

export class CircleSOService implements ICircleSOService {
  constructor(
    private db: PrismaClient,
    private circleClientService: ICircleClientService
  ) {}

  async getPosts(quantity?: number) {
    const posts = quantity
      ? await this.db.post.findMany({
          where: { hide_meta_info: false },
          orderBy: { published_at: "desc" },
          take: quantity,
        })
      : await this.db.post.findMany({
          where: { hide_meta_info: false },
          orderBy: { published_at: "desc" },
        });
    return posts;
  }

  async getPostsByName(searchTerm: string) {
    const post = await this.db.post.findMany({
      where: {
        name: { contains: searchTerm, mode: "insensitive" },
        hide_meta_info: false,
      },
      orderBy: { published_at: "desc" },
    });
    return post;
  }

  async getPost(slug: string) {
    const post = await this.db.post.findFirstOrThrow({
      where: { slug: slug },
    });
    return post;
  }

  async getLegalDoc(slug: string): Promise<LegalDoc> {
    const legalDoc = await this.db.legalDoc.findFirst({
      where: { slug: slug },
    });
    if (legalDoc) return legalDoc;
    else throw new Error(`Doc with the slug: ${slug} doesn't exist`);
  }

  // Create posts function used in the circle-blog.cron.server.ts file
  async createPosts(): Promise<void> {
    try {
      const postsData = await this.circleClientService.getCirclePosts(
        COMMUNITY_ID,
        POSTS_ID
      );
      for (const postData of postsData) {
        const { body, ...postDataWithoutBody } = postData;
        await this.db.post.upsert({
          where: { id: postData.id },
          update: { ...postDataWithoutBody, body: postData.body.body },
          create: { ...postDataWithoutBody, body: postData.body.body },
        });
      }
    } catch (error) {
      console.error("Error in cron job:", error);
    }
  }

  async deleteInexistentPosts() {
    try {
      const existingPosts = await this.db.post.findMany();
      const existingPostIds = existingPosts.map(post => post.id);
      const postsData = await this.circleClientService.getCirclePosts(
        COMMUNITY_ID,
        POSTS_ID
      );
      const fetchedPostIds = postsData.map(postData => postData.id);
      const postsToDelete = existingPostIds.filter(
        postId => !fetchedPostIds.includes(postId)
      );
      for (const postIdToDelete of postsToDelete) {
        await this.db.post.delete({
          where: { id: postIdToDelete },
        });
      }
    } catch (error) {
      console.error("Error in cron job:", error);
    }
  }

  async createLegalDocs(): Promise<void> {
    try {
      const docsData = await this.circleClientService.getCirclePosts(
        COMMUNITY_ID,
        LEGAL_DOCS_ID
      );
      for (const docData of docsData) {
        await this.db.legalDoc.upsert({
          where: { id: docData.id },
          update: {
            id: docData.id,
            name: docData.name,
            body: docData.body.body,
            slug: docData.slug,
            hide_meta_info: docData.hide_meta_info,
            published_at: docData.published_at,
            created_at: docData.created_at,
            updated_at: docData.updated_at,
          },
          create: {
            id: docData.id,
            name: docData.name,
            body: docData.body.body,
            slug: docData.slug,
            hide_meta_info: docData.hide_meta_info,
            published_at: docData.published_at,
            created_at: docData.created_at,
            updated_at: docData.updated_at,
          },
        });
      }
    } catch (error) {
      console.error("Error in cron job:", error);
    }
  }

  async deleteInexistentLegalDocs() {
    try {
      const existingDocs = await this.db.legalDoc.findMany();
      const existingDocsIds = existingDocs.map(doc => doc.id);
      const docsData = await this.circleClientService.getCirclePosts(
        COMMUNITY_ID,
        LEGAL_DOCS_ID
      );
      const fetchedDocsIds = docsData.map((docData: any) => docData.id);
      const docsToDelete = existingDocsIds.filter(
        docId => !fetchedDocsIds.includes(docId)
      );
      for (const docIdToDelete of docsToDelete) {
        await this.db.legalDoc.delete({
          where: { id: docIdToDelete },
        });
      }
    } catch (error) {
      console.error("Error in cron job:", error);
    }
  }

  async syncPosts() {
    await this.deleteInexistentPosts();
    await this.createPosts();
    await this.deleteInexistentLegalDocs();
    await this.createLegalDocs();
  }
}
