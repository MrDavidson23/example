import dayjs from "dayjs";
import type {
  BuyerContactRequest,
  Contract,
  ManagerAccount,
  ManagerAccountRole,
  ManagerAccountVendor,
  Product,
  ProductReview,
  TaskContractRenewal,
  User,
  UserInvitation,
  Vendor,
} from "@prisma/client";
import pug from "pug";
import utc from "dayjs/plugin/utc";
dayjs.extend(utc);

const RELOAD = true;

export type ITemplateService = {
  renderForgotPasswordEmail(params: { token: string }): string;
  renderEmailVerificationEmail(params: {
    email: string;
    token: string;
  }): string;
  renderListingApprovedEmail(params: {
    product_id: string;
    product_name: string;
  }): string;
  renderBuyerContactEmail(params: {
    recipient: User;
    request: BuyerContactRequest & { user: User; product: Product };
  }): string;
  renderBuyerVerifiedEmail(params: {}): string;
  renderReviewApprovedEmail(params: {
    review: ProductReview & { product: Product & { vendor: Vendor | null } };
  }): string;
  renderReviewRespondedEmail(params: {
    review: ProductReview & { product: Product & { vendor: Vendor | null } };
  }): string;
  renderUserInvitationEmail(params: {
    invitation: UserInvitation;
    product: Product;
    email: string;
    token: string;
  }): string;
  renderRenewalReminderEmail(
    contract: Contract & {
      manager_account_vendor: ManagerAccountVendor & {
        vendor: {
          name: string;
        };
      };
    },
    task: TaskContractRenewal & {
      task_owner: ManagerAccountRole & { user: User };
    }
  ): string;
  renderManagerAccountUserInvitationEmail(params: {
    invitation: UserInvitation;
    managerAccount: ManagerAccount;
    email: string;
    token: string;
  }): string;
  renderIntelligenceConsolidatedNotificationsEmail(params: {
    notifications: {
      message: string;
      icon?: string;
    }[];
    manager_account_id: string;
    manager_account_avatar_id?: string;
  }): string;
};

export class TemplateService implements ITemplateService {
  private layoutTemplate!: pug.compileTemplate;
  private forgotPassword!: pug.compileTemplate;
  private emailVerification!: pug.compileTemplate;
  private listingApproved!: pug.compileTemplate;
  private buyerContact!: pug.compileTemplate;
  private verifiedBuyer!: pug.compileTemplate;
  private reviewApproved!: pug.compileTemplate;
  private reviewResponded!: pug.compileTemplate;
  private userInvitation!: pug.compileTemplate;
  private renewalReminder!: pug.compileTemplate;
  private managerAccountUserInvitation!: pug.compileTemplate;
  private intelligenceConsolidatedNotifications!: pug.compileTemplate;

  private REVYSE_UI_ORIGIN =
    process.env.REVYSE_UI_ORIGIN || "http://localhost:3000";

  private renderLayout(params: { pre_header_text: string; body: string }) {
    if (!this.layoutTemplate || RELOAD) {
      this.layoutTemplate = pug.compileFile("app/email-templates/layout.pug");
    }
    return this.layoutTemplate({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
    });
  }

  private renderForgotPassword(params: { token: string }) {
    if (!this.forgotPassword || RELOAD) {
      this.forgotPassword = pug.compileFile(
        "app/email-templates/forgot-password.pug"
      );
    }
    return this.forgotPassword({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
    });
  }

  renderForgotPasswordEmail(params: { token: string }) {
    return this.renderLayout({
      pre_header_text: `Reset your password`,
      body: this.renderForgotPassword(params),
    });
  }

  private renderEmailVerification(params: { email: string; token: string }) {
    if (!this.emailVerification || RELOAD) {
      this.emailVerification = pug.compileFile(
        "app/email-templates/email-verification.pug"
      );
    }
    return this.emailVerification({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
    });
  }

  renderEmailVerificationEmail(params: { email: string; token: string }) {
    return this.renderLayout({
      pre_header_text: `One more step is required to verify your Revyse account.`,
      body: this.renderEmailVerification(params),
    });
  }

  private renderListingApproved(params: {
    product_id: string;
    product_name: string;
  }) {
    if (!this.listingApproved || RELOAD) {
      this.listingApproved = pug.compileFile(
        "app/email-templates/listing-approved.pug"
      );
    }
    return this.listingApproved({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
    });
  }

  renderListingApprovedEmail(params: {
    product_id: string;
    product_name: string;
  }) {
    return this.renderLayout({
      pre_header_text: `Product listing approved`,
      body: this.renderListingApproved(params),
    });
  }

  private renderBuyerContact(params: {
    request: BuyerContactRequest & { user: User; product: Product };
  }) {
    if (!this.buyerContact || RELOAD) {
      this.buyerContact = pug.compileFile(
        "app/email-templates/buyer-contact.pug"
      );
    }
    return this.buyerContact({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
    });
  }

  renderBuyerContactEmail(params: {
    request: BuyerContactRequest & { user: User; product: Product };
    recipient: User;
  }) {
    return this.renderLayout({
      pre_header_text: `A buyer wants more information about your product`,
      body: this.renderBuyerContact(params),
    });
  }

  private renderVerifiedBuyer(params: {}) {
    if (!this.verifiedBuyer || RELOAD) {
      this.verifiedBuyer = pug.compileFile(
        "app/email-templates/buyer-verified.pug"
      );
    }
    return this.verifiedBuyer({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
    });
  }

  renderBuyerVerifiedEmail(params: {}) {
    return this.renderLayout({
      pre_header_text: `You're a verified buyer!`,
      body: this.renderVerifiedBuyer(params),
    });
  }

  private renderReviewApproved(params: {
    review: ProductReview & { product: Product & { vendor: Vendor | null } };
  }) {
    if (!this.reviewApproved || RELOAD) {
      this.reviewApproved = pug.compileFile(
        "app/email-templates/review-approved.pug"
      );
    }
    return this.reviewApproved({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
    });
  }

  renderReviewApprovedEmail(params: {
    review: ProductReview & { product: Product & { vendor: Vendor | null } };
  }) {
    return this.renderLayout({
      pre_header_text: `You've got a new Review`,
      body: this.renderReviewApproved(params),
    });
  }

  private renderReviewResponded(params: {
    review: ProductReview & { product: Product & { vendor: Vendor | null } };
  }) {
    if (!this.reviewResponded || RELOAD) {
      this.reviewResponded = pug.compileFile(
        "app/email-templates/review-responded.pug"
      );
    }
    return this.reviewResponded({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
    });
  }

  renderReviewRespondedEmail(params: {
    review: ProductReview & { product: Product & { vendor: Vendor | null } };
  }) {
    return this.renderLayout({
      pre_header_text: `You've got a response to your review`,
      body: this.renderReviewResponded(params),
    });
  }

  private renderUserInvitation(params: {
    invitation: UserInvitation;
    product: Product;
    email: string;
    token: string;
  }) {
    if (!this.userInvitation || RELOAD) {
      this.userInvitation = pug.compileFile(
        "app/email-templates/user-invitation.pug"
      );
    }
    return this.userInvitation({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
    });
  }

  renderUserInvitationEmail(params: {
    invitation: UserInvitation;
    product: Product;
    email: string;
    token: string;
  }) {
    return this.renderLayout({
      pre_header_text: `You've been invited to manage a product listing on Revyse ⚒️`,
      body: this.renderUserInvitation(params),
    });
  }

  private renderRenewalReminder(params: {
    contract: Contract;
    task: TaskContractRenewal;
    formattedCurrentTermEndDate: string;
    formattedDueDate: string;
  }) {
    if (!this.renewalReminder || RELOAD) {
      this.renewalReminder = pug.compileFile(
        "app/email-templates/renewal-reminder.pug"
      );
    }
    return this.renewalReminder({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
    });
  }

  renderRenewalReminderEmail(
    contract: Contract & {
      manager_account_vendor: ManagerAccountVendor & {
        vendor: {
          name: string;
        };
      };
    },
    task: TaskContractRenewal & {
      task_owner: ManagerAccountRole & { user: User };
    }
  ) {
    return this.renderLayout({
      pre_header_text: `Your contract is nearing the end of its current term`,
      body: this.renderRenewalReminder({
        contract,
        task,
        formattedCurrentTermEndDate: dayjs
          .utc(contract.current_term_end_date)
          .format("MM/DD/YYYY"),
        formattedDueDate: dayjs.utc(task.due_date).format("MM/DD/YYYY"),
      }),
    });
  }

  private renderManagerAccountUserInvitation(params: {
    invitation: UserInvitation;
    managerAccount: ManagerAccount;
    email: string;
    token: string;
  }) {
    if (!this.managerAccountUserInvitation || RELOAD) {
      this.managerAccountUserInvitation = pug.compileFile(
        "app/email-templates/manager-account-user-invitation.pug"
      );
    }
    return this.managerAccountUserInvitation({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
    });
  }

  renderManagerAccountUserInvitationEmail(params: {
    invitation: UserInvitation;
    managerAccount: ManagerAccount;
    email: string;
    token: string;
  }) {
    return this.renderLayout({
      pre_header_text: `You've been invited to manage ${params.managerAccount.name} on Revyse ⚒️`,
      body: this.renderManagerAccountUserInvitation(params),
    });
  }

  private renderIntelligenceConsolidatedNotifications(params: {
    notifications: {
      message: string;
      icon?: string;
    }[];
    manager_account_id: string;
    manager_account_avatar_id?: string;
    notifications_count: number;
  }) {
    const defaultNotificationIcon = params.manager_account_avatar_id
      ? `${this.REVYSE_UI_ORIGIN}/images/${params.manager_account_avatar_id}`
      : `${this.REVYSE_UI_ORIGIN}/assets/defaultAvatar.png`;

    if (!this.intelligenceConsolidatedNotifications || RELOAD) {
      this.intelligenceConsolidatedNotifications = pug.compileFile(
        "app/email-templates/intelligence-consolidated-notifications.pug"
      );
    }
    return this.intelligenceConsolidatedNotifications({
      REVYSE_UI_ORIGIN: this.REVYSE_UI_ORIGIN,
      ...params,
      defaultNotificationIcon,
    });
  }

  renderIntelligenceConsolidatedNotificationsEmail(params: {
    notifications: {
      message: string;
      icon?: string;
    }[];
    manager_account_id: string;
    manager_account_avatar_id?: string;
    notifications_count: number;
  }) {
    return this.renderLayout({
      pre_header_text: `You have ${
        params.notifications_count
      } unread notification${params.notifications_count == 1 ? "" : "s"}.`,
      body: this.renderIntelligenceConsolidatedNotifications(params),
    });
  }
}
