import { faker } from "@faker-js/faker";
import {
	ContractLineItemLocationStatus,
	ContractLineItemPriceCadence,
	ContractPricingType,
	ContractStatus,
	LocationClass,
	LocationNoticeStatus,
	LocationNoticeStep,
	LocationStatus,
	ManagerAccountVendorContactType,
	ManagerAccountVendorStatus,
} from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { Roles } from "../utils/intelligence-permission.utils";
import { withFixtureFactory } from "../utils/test.utils.server";

const withFixtures = withFixtureFactory({
	setup: async tx => {
		const account = await tx.managerAccount.create({
			data: {
				name: faker.company.name(),
			},
		});

		const user = await tx.user.create({
			data: {
				email: faker.internet.email(),
				first_name: faker.person.firstName(),
				last_name: faker.person.lastName(),
				manager_account_roles: {
					create: {
						manager_account: {
							connect: {
								id: account.id,
							},
						},
						role: Roles.Owner,
					},
				},
			},
			include: {
				manager_account_roles: {
					include: {
						location_roles: true
					}
				},
				user_roles: true
			},
		});

		const vendor =
			await tx.vendor.create({
				data: {
					name: faker.company.name(),
				},
			})
		const managerAccountVendors =
			await tx.managerAccountVendor.create({
				data: {
					manager_account_id: account.id,
					vendor_id: vendor.id,
					status: ManagerAccountVendorStatus.Active,
					manager_account_vendor_contacts: {
						create: {
							type: faker.helpers.arrayElement([
								ManagerAccountVendorContactType.Main,
								ManagerAccountVendorContactType.Disposition,
							]),
							name: faker.person.fullName(),
							email: faker.internet.email(),
						},
					},
				},
				include: {
					manager_account_vendor_contacts: true,
				},
			})

		const location = await tx.location.create({
			data: {
				name: faker.company.name(),
				pms_id: faker.string.alphanumeric(6),
				owner_name: faker.company.name(),
				street_1: faker.location.streetAddress(),
				street_2: faker.location.secondaryAddress(),
				city: faker.location.city(),
				state: faker.location.state(),
				zip: faker.location.zipCode(),
				region: faker.location.city(),
				unit_count: faker.number.int({ min: 1, max: 1000 }),
				class: faker.helpers.enumValue(LocationClass),
				status: faker.helpers.enumValue(LocationStatus),
				manager_account_id: account.id,
			},
		});

		const contract = await tx.contract.create({
			data: {
				manager_account_vendor_id: managerAccountVendors.id,
				status: ContractStatus.Active,
				contract_owner_name: faker.person.fullName(),
				approver: faker.person.fullName(),
				expires_at: faker.date.future(),
				current_term_end_date: faker.date.future(),
				name: faker.commerce.productName(),
				renewal_reminder_lead_time_months: faker.number.int({ max: 12 }),
				renewal_reminder_date: faker.date.future(),
				term_length_months: faker.number.int({ max: 48 }),
				is_corporate_only: false,
			},
		});

		const savedLocationServiceTermination =
			await tx.locationServiceTerminationNotice.create({
				data: {
					location_id: location.id,
					termination_date: new Date(),
					termination_instructions: faker.lorem.sentence(),
					task_owner_id: user.manager_account_roles[0].id,
					manager_account_role_id: user.manager_account_roles[0].id,
					status: LocationNoticeStatus.Saved,
					status_updated_at: faker.date.past(),
					contact_email: faker.internet.email(),
					contact_name: faker.person.fullName(),
					manager_account_vendor_id: managerAccountVendors.id,
				},
			});

		const contractLineItems = await Promise.all(Array.from(
			"_".repeat(faker.number.int({ min: 2, max: 10 }))
		).map(
			async _ =>
				await tx.contractLineItem.create({
					data: {
						name: faker.commerce.productName(),
						contract_id: contract.id,
						price: faker.number.int({ min: 1, max: 1000 }),
						cadence: ContractLineItemPriceCadence.Monthly,
						pricing_type: ContractPricingType.PerLocation,
						estimated_cost: faker.number.int({ min: 100, max: 1000 }),
						contract_line_item_locations: {
							create: {
								location_id: location.id,
								status: ContractLineItemLocationStatus.Active,
							},
						},
					},
					include: {
						contract_line_item_locations: true,
					},
				})
		));

		const servicesIds = contractLineItems.map(v => v.id);
		const sentLocationServiceTermination =
			await tx.locationServiceTerminationNotice.create({
				data: {
					location_id: location.id,
					termination_date: new Date(),
					termination_instructions: faker.lorem.sentence(),
					task_owner_id: user.manager_account_roles[0].id,
					manager_account_role_id: user.manager_account_roles[0].id,
					status: LocationNoticeStatus.Sent,
					status_updated_at: faker.date.past(),
					contact_email: faker.internet.email(),
					contact_name: faker.person.fullName(),
					manager_account_vendor_id: managerAccountVendors.id,
					services_to_terminate: {
						connect: servicesIds.map(id => ({ id })),
					},
				},
				include: {
					services_to_terminate: true,
				},
			});
		const servicesToTerminate =
			sentLocationServiceTermination.services_to_terminate.map(
				service => service.id
			);

		const sentUpdatedLocationServiceTermination =
			await tx.locationServiceTerminationNotice.create({
				data: {
					location_id: location.id,
					termination_date: new Date(),
					termination_instructions: faker.lorem.sentence(),
					task_owner_id: user.manager_account_roles[0].id,
					manager_account_role_id: user.manager_account_roles[0].id,
					status: LocationNoticeStatus.Sent,
					status_updated_at: faker.date.past(),
					contact_email: faker.internet.email(),
					contact_name: faker.person.fullName(),
					original_location_notice_id: sentLocationServiceTermination.id,
					manager_account_vendor_id: managerAccountVendors.id,
					services_to_terminate: {
						connect: servicesToTerminate.map(id => ({ id })),
					},
				},
			});

		return {
			user,
			account,
			location,
			vendor,
			managerAccountVendors,
			savedLocationServiceTermination,
			sentLocationServiceTermination,
			sentUpdatedLocationServiceTermination,
			contract,
			contractLineItems,
		};
	},
});

describe("LocationServiceTerminationNoticeService", () => {
	describe("createLocationServiceTermination", () => {
		it(
			"should create location service termination notice",
			withFixtures(async ({ location, user, managerAccountVendors }, tx) => {
				const { locationServiceTerminationService } = TestDIContainer(tx);

				const locationServiceTerminationNotice =
					await locationServiceTerminationService.createLocationServiceTermination(
						location.id,
						{
							termination_date: faker.date.future(),
							termination_instructions: faker.lorem.sentence(),
							task_owner_id: user.manager_account_roles[0].id,
							manager_account_role_id: user.manager_account_roles[0].id,
							contact_email: faker.internet.email(),
							contact_name: faker.person.fullName(),
							manager_account_vendor_id: managerAccountVendors.id,
						},
						false
					);

				expect(locationServiceTerminationNotice).toBeDefined();

				const locationServiceTerminationNoticeFromDb =
					await tx.locationServiceTerminationNotice.findUnique({
						where: {
							id: locationServiceTerminationNotice.id,
						},
					});

				expect(locationServiceTerminationNoticeFromDb).toBeDefined();

				expect(locationServiceTerminationNoticeFromDb?.status).toBe(
					LocationNoticeStatus.InProgress
				);
				expect(locationServiceTerminationNoticeFromDb?.step).toBe(
					LocationNoticeStep.Details
				);
			})
		);

		it(
			"should create location service termination notice save progress",
			withFixtures(async ({ location, user, managerAccountVendors }, tx) => {
				const { locationServiceTerminationService } = TestDIContainer(tx);

				const locationServiceTerminationNotice =
					await locationServiceTerminationService.createLocationServiceTermination(
						location.id,
						{
							termination_date: faker.date.future(),
							termination_instructions: faker.lorem.sentence(),
							task_owner_id: user.manager_account_roles[0].id,
							manager_account_role_id: user.manager_account_roles[0].id,
							contact_email: faker.internet.email(),
							contact_name: faker.person.fullName(),
							manager_account_vendor_id: managerAccountVendors.id,
						},
						true
					);

				expect(locationServiceTerminationNotice).toBeDefined();

				const locationServiceTerminationNoticeFromDb =
					await tx.locationServiceTerminationNotice.findUnique({
						where: {
							id: locationServiceTerminationNotice.id,
						},
					});

				expect(locationServiceTerminationNoticeFromDb).toBeDefined();

				expect(locationServiceTerminationNoticeFromDb?.status).toBe(
					LocationNoticeStatus.Saved
				);
				expect(
					locationServiceTerminationNoticeFromDb?.status_updated_at
				).toBeDefined();
				expect(locationServiceTerminationNoticeFromDb?.step).toBe(
					LocationNoticeStep.Details
				);
			})
		);
	});

	describe("updateLocationServiceTermination", () => {
		it(
			"should update location service termination notice",
			withFixtures(
				async (
					{ user, savedLocationServiceTermination, managerAccountVendors },
					tx
				) => {
					const { locationServiceTerminationService } = TestDIContainer(tx);

					const locationServiceTerminationNotice =
						await locationServiceTerminationService.updateLocationServiceTermination(
							savedLocationServiceTermination.id,
							{
								termination_date: faker.date.future(),
								task_owner_id: user.manager_account_roles[0].id,
								manager_account_role_id: user.manager_account_roles[0].id,
								contact_email: faker.internet.email(),
								contact_name: faker.person.fullName(),
								manager_account_vendor_id: managerAccountVendors.id,
							},
							false
						);

					expect(locationServiceTerminationNotice).toBeDefined();

					const locationServiceTerminationNoticeFromDb =
						await tx.locationServiceTerminationNotice.findUnique({
							where: {
								id: locationServiceTerminationNotice.id,
							},
						});

					expect(locationServiceTerminationNoticeFromDb).toBeDefined();

					expect(locationServiceTerminationNoticeFromDb?.step).toBe(
						LocationNoticeStep.Details
					);
				}
			)
		);

		it(
			"should update location service termination notice save progress",
			withFixtures(
				async (
					{ user, savedLocationServiceTermination, managerAccountVendors },
					tx
				) => {
					const { locationServiceTerminationService } = TestDIContainer(tx);

					const locationServiceTerminationNotice =
						await locationServiceTerminationService.updateLocationServiceTermination(
							savedLocationServiceTermination.id,
							{
								termination_date: faker.date.future(),
								task_owner_id: user.manager_account_roles[0].id,
								manager_account_role_id: user.manager_account_roles[0].id,
								contact_email: faker.internet.email(),
								contact_name: faker.person.fullName(),
								manager_account_vendor_id: managerAccountVendors.id,
							},
							true
						);

					expect(locationServiceTerminationNotice).toBeDefined();

					const locationServiceTerminationNoticeFromDb =
						await tx.locationServiceTerminationNotice.findUnique({
							where: {
								id: locationServiceTerminationNotice.id,
							},
						});

					expect(locationServiceTerminationNoticeFromDb).toBeDefined();

					expect(locationServiceTerminationNoticeFromDb?.status).toBe(
						LocationNoticeStatus.Saved
					);
					expect(
						locationServiceTerminationNoticeFromDb?.status_updated_at
					).toBeDefined();
				}
			)
		);
	});

	describe("getVendorOptions", () => {
		it(
			"should return vendor options",
			withFixtures(async ({ location, managerAccountVendors }, tx) => {
				const { locationServiceTerminationService } = TestDIContainer(tx);

				const vendorOptions =
					await locationServiceTerminationService.getVendorOptions(location.id);

				expect(vendorOptions.map(vendor => vendor.id)).toEqual(
					expect.arrayContaining([managerAccountVendors.id])
				);
			})
		);
	});

	describe("getLocationServiceTermination", () => {
		it(
			"should return location service termination notice",
			withFixtures(async ({ user, account, location,savedLocationServiceTermination }, tx) => {
				const { locationServiceTerminationService } = TestDIContainer(tx);

				const locationServiceTerminationNotice =
					await locationServiceTerminationService.getLocationServiceTermination(
						savedLocationServiceTermination.id,
						location.id,
						user,
						account
					);

				expect(locationServiceTerminationNotice).toBeDefined();

				const locationServiceTerminationNoticeFromDb =
					await tx.locationServiceTerminationNotice.findUnique({
						where: {
							id: locationServiceTerminationNotice?.id,
						},
					});

				expect(locationServiceTerminationNoticeFromDb).toBeDefined();
			})
		);
	});

	describe("upsertLocationServiceTerminationServices", () => {
		it(
			"should upsert location service termination notice services to terminate",
			withFixtures(
				async (
					{ savedLocationServiceTermination, contractLineItems, user },
					tx
				) => {
					const { locationServiceTerminationService } = TestDIContainer(tx);

					await locationServiceTerminationService.upsertLocationServiceTerminationServices(
						savedLocationServiceTermination.id,
						contractLineItems.map(service => service.id),
						user.manager_account_roles[0].id
					);

					const locationServiceTerminationNoticeFromDb =
						await tx.locationServiceTerminationNotice.findUnique({
							where: {
								id: savedLocationServiceTermination.id,
							},
							include: {
								services_to_terminate: true,
							},
						});

					expect(locationServiceTerminationNoticeFromDb).toBeDefined();

					expect(
						locationServiceTerminationNoticeFromDb?.services_to_terminate
					).toHaveLength(contractLineItems.length);

					const expectedServicesOptions = contractLineItems.map(service =>
						expect.objectContaining({
							id: service.id,
							name: service.name,
						})
					);

					expect(
						locationServiceTerminationNoticeFromDb?.services_to_terminate
					).toEqual(expect.arrayContaining(expectedServicesOptions));
				}
			)
		);
	});

	describe("saveLocationServiceTerminationDraftEmail", () => {
		it(
			"should save location service termination notice draft email",
			withFixtures(async ({ savedLocationServiceTermination, user }, tx) => {
				const { locationServiceTerminationService } = TestDIContainer(tx);

				await locationServiceTerminationService.saveLocationServiceTerminationDraftEmail(
					savedLocationServiceTermination.id,
					{
						subject: "Test Subject",
						body: "Test Body",
						cc_emails: ["test@test.com"],
						attachments: [],
						uploaded_attachments_to_remove: [],
						manager_account_role_id: user.manager_account_roles[0].id,
					},
					true
				);

				const locationServiceTerminationNoticeFromDb =
					await tx.locationServiceTerminationNotice.findUnique({
						where: {
							id: savedLocationServiceTermination.id,
						},
					});

				expect(locationServiceTerminationNoticeFromDb).toBeDefined();

				expect(locationServiceTerminationNoticeFromDb?.step).toBe(
					LocationNoticeStep.EmailTemplate
				);
				expect(locationServiceTerminationNoticeFromDb?.email_subject).toBe(
					"Test Subject"
				);
				expect(locationServiceTerminationNoticeFromDb?.email_body).toBe(
					"Test Body"
				);
				expect(locationServiceTerminationNoticeFromDb?.email_cc_emails).toEqual(
					["test@test.com"]
				);
			})
		);
	});

	describe("sendLocationServiceTerminationEmail", () => {
		it(
			"should send location service termination notice email",
			withFixtures(
				async (
					{
						savedLocationServiceTermination,
						contractLineItems,
						user,
						managerAccountVendors,
					},
					tx
				) => {
					const { locationServiceTerminationService, mailService } =
						TestDIContainer(tx);

					await locationServiceTerminationService.upsertLocationServiceTerminationServices(
						savedLocationServiceTermination.id,
						contractLineItems.map(service => service.id),
						user.manager_account_roles[0].id
					);

					await locationServiceTerminationService.saveLocationServiceTerminationDraftEmail(
						savedLocationServiceTermination.id,
						{
							subject: "Test Subject",
							body: "Test Body",
							cc_emails: ["test@test.com"],
							attachments: [],
							uploaded_attachments_to_remove: [],
							manager_account_role_id: user.manager_account_roles[0].id,
						}
					);

					const mailServiceSendSpy = jest.spyOn(mailService, "send");

					await locationServiceTerminationService.sendLocationServiceTerminationEmail(
						savedLocationServiceTermination.id,
						user.manager_account_roles[0].id
					);

					const locationServiceTerminationNoticeFromDb =
						await tx.locationServiceTerminationNotice.findUnique({
							where: {
								id: savedLocationServiceTermination.id,
							},
							include: {
								services_to_terminate: true,
								manager_account_role: {
									include: {
										user: true,
									},
								},
								task_owner: {
									include: {
										user: true
									}
								}
							},
						});

					expect(locationServiceTerminationNoticeFromDb).toBeDefined();

					expect(locationServiceTerminationNoticeFromDb?.status).toBe(
						LocationNoticeStatus.Sent
					);

					expect(mailServiceSendSpy).toHaveBeenCalledTimes(1);

					const recipient =
						locationServiceTerminationNoticeFromDb!.contact_email;
					expect(mailServiceSendSpy).toHaveBeenCalledWith(
						expect.objectContaining({
							to: [recipient!],
							cc: [
								locationServiceTerminationNoticeFromDb?.manager_account_role
									.user.email,
								locationServiceTerminationNoticeFromDb?.task_owner
									.user.email,
								"test@test.com",
							],
							subject: "Test Subject",
							body: "Test Body",
							attachments: [],
							replyTo:
								locationServiceTerminationNoticeFromDb?.manager_account_role
									.user.email,
						})
					);
				}
			)
		);
	});

	describe("deleteLocationServiceTermination", () => {
		it(
			"should delete location service termination notice",
			withFixtures(async ({ savedLocationServiceTermination }, tx) => {
				const { locationServiceTerminationService } = TestDIContainer(tx);

				await locationServiceTerminationService.deleteLocationNoticeServiceTermination(
					savedLocationServiceTermination.id
				);

				const locationServiceTerminationNoticeFromDb =
					await tx.locationServiceTerminationNotice.findUnique({
						where: {
							id: savedLocationServiceTermination.id,
						},
					});

				expect(locationServiceTerminationNoticeFromDb).toBeNull();
			})
		);
	});

	describe("updateServicesToPendingStatus", () => {
		it(
			"update contract line items status to pending",
			withFixtures(async ({ sentLocationServiceTermination }, tx) => {
				const { locationServiceTerminationService } = TestDIContainer(tx);

				await locationServiceTerminationService.updateServicesToPendingStatus(
					sentLocationServiceTermination.id
				);

				const contractLineItemsFromDb = await tx.contractLineItem.findMany({
					where: {
						id: {
							in: sentLocationServiceTermination.services_to_terminate.map(
								service => service.id
							),
						},
					},
				});

				contractLineItemsFromDb.map(service =>
					expect.objectContaining({
						status: ContractLineItemLocationStatus.Pending,
					})
				);
			})
		);
	});

	describe("getServices", () => {
		it(
			"get available services for current location and manager account vendor",
			withFixtures(
				async ({ location, managerAccountVendors, contractLineItems }, tx) => {
					const { locationServiceTerminationService } = TestDIContainer(tx);

					const services = await locationServiceTerminationService.getServices(
						location.id,
						managerAccountVendors.id
					);
					expect(services).toHaveLength(contractLineItems.length);

					const expectedServicesOptions = contractLineItems.map(service =>
						expect.objectContaining({
							id: service.id,
						})
					);

					expect(services).toEqual(
						expect.arrayContaining(expectedServicesOptions)
					);
				}
			)
		);
	});
});
