import { SignUpIntent } from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { withTx } from "../services/db.server";
import { faker } from "@faker-js/faker";

const defaultRegisterParams = {
  email: faker.internet.email(),
  password: "heyoh",
  first_name: "first",
  last_name: "last",
  company_name: "company",
  phone: "phone",
  title: "title",
};

describe("AuthService", () => {
  describe("findUserByEmailPassword", () => {
    test(
      "returns null when user not found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);
        const user = await authService.findUserByEmailPassword({
          email: "nope",
          password: "no way",
        });
        expect(user).toBeNull();
      })
    );

    test(
      "returns user when user found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);

        const params = {
          ...defaultRegisterParams,
          intent: SignUpIntent.ORGANIC,
        };
        const result = await authService.registerInTx(params, tx, false);
        if (!result.ok) {
          throw "error";
        }
        const user = await authService.findUserByEmailPasswordInTx(params, tx);
        expect(user).not.toBeNull();
        expect(user?.id).toEqual(result.value.id);
      })
    );
  });

  describe("register", () => {
    test(
      "returns error when user exists",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);

        const params = {
          ...defaultRegisterParams,
          intent: SignUpIntent.ORGANIC,
        };
        const result = await authService.register(params, false);
        expect(result.ok).toBeTruthy();

        const result2 = await authService.register(params, false);
        expect(result2.ok).toBeFalsy();
        if (result2.ok) throw "error";
        expect(result2.error).toEqual(
          `User with email ${params.email} already exists`
        );
      })
    );

    test(
      "returns user when user created",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);

        const params = {
          ...defaultRegisterParams,
          intent: SignUpIntent.ORGANIC,
        };
        const result = await authService.register(params, false);
        expect(result.ok).toBeTruthy();
        if (!result.ok) throw "error";
        expect(result.value.email).toEqual(params.email.toLocaleLowerCase());

        const user = await authService.findUserByEmailPassword(params);
        expect(user).not.toBeNull();
        expect(user?.id).toEqual(result.value.id);
      })
    );
  });

  describe("generateEmailVerificationEmail", () => {
    test(
      "returns null when user not found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);
        const token = await authService.generateEmailVerificationEmail(
          faker.string.uuid(),
          false
        );
        expect(token).toBeNull();
      })
    );

    test(
      "returns token when user found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);

        const params = {
          ...defaultRegisterParams,
          intent: SignUpIntent.ORGANIC,
        };
        const result = await authService.register(params, false);
        if (!result.ok) {
          throw "error";
        }
        const token = await authService.generateEmailVerificationEmail(
          result.value.id,
          false
        );
        expect(token).not.toBeNull();
      })
    );

    test(
      "returns token when user found and token already exists",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);

        const params = {
          ...defaultRegisterParams,
          intent: SignUpIntent.ORGANIC,
        };
        const result = await authService.register(params, false);
        if (!result.ok) {
          throw "error";
        }
        const token = await authService.generateEmailVerificationEmail(
          result.value.id,
          false
        );
        expect(token).not.toBeNull();
        const token2 = await authService.generateEmailVerificationEmail(
          result.value.id,
          false
        );
        expect(token2).not.toBeNull();
        expect(token2?.id).toEqual(token?.id);
      })
    );
  });

  describe("generateForgotPasswordEmail", () => {
    test(
      "returns null when user not found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);
        const token = await authService.generateForgotPasswordEmail("nope");
        expect(token).toBeNull();
      })
    );

    test(
      "returns token when user found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);

        const params = {
          ...defaultRegisterParams,
          intent: SignUpIntent.ORGANIC,
        };
        const result = await authService.register(params, false);
        if (!result.ok) {
          throw "error";
        }
        const token = await authService.generateForgotPasswordEmail(
          result.value.email
        );
        expect(token).not.toBeNull();
      })
    );
  });

  describe("resetPassword", () => {
    test(
      "returns null when token not found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);
        const user = await authService.resetPassword(
          faker.string.uuid(),
          "no way"
        );
        expect(user).toBeNull();
      })
    );

    test(
      "returns user when token found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);

        const params = {
          ...defaultRegisterParams,
          intent: SignUpIntent.ORGANIC,
        };
        const result = await authService.register(params, false);
        if (!result.ok) {
          throw "error";
        }
        const token = await authService.generateForgotPasswordEmail(
          result.value.email
        );
        expect(token).not.toBeNull();

        const user = await authService.resetPassword(
          token?.id ?? "",
          "new password"
        );
        expect(user).not.toBeNull();
        expect(user?.id).toEqual(result.value.id);
      })
    );
  });

  describe("findUserByForgotPasswordToken", () => {
    test(
      "returns null when token not found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);
        const user = await authService.findUserByForgotPasswordToken(
          faker.string.uuid()
        );
        expect(user).toBeUndefined();
      })
    );

    test(
      "returns user when token found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);

        const params = {
          ...defaultRegisterParams,
          intent: SignUpIntent.ORGANIC,
        };
        const result = await authService.register(params, false);
        if (!result.ok) {
          throw "error";
        }
        const token = await authService.generateForgotPasswordEmail(
          result.value.email
        );
        expect(token).not.toBeNull();

        const user = await authService.findUserByForgotPasswordToken(
          token?.id ?? ""
        );
        expect(user).not.toBeNull();
        expect(user?.id).toEqual(result.value.id);
      })
    );
  });

  describe("verifyEmailVerification", () => {
    test(
      "returns null when token not found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);
        const user = await authService.verifyEmailVerification(
          faker.string.uuid()
        );
        expect(user).toBeUndefined();
      })
    );

    test(
      "returns user when token found",
      withTx(async tx => {
        const { authService } = TestDIContainer(tx);

        await tx.buyerDomain.create({
          data: {
            domain: "example.com",
          },
        });

        const params = {
          ...defaultRegisterParams,
          email: faker.internet.email({ provider: "example.com" }),
          intent: SignUpIntent.ORGANIC,
        };
        const result = await authService.register(params, false);
        if (!result.ok) {
          throw "error";
        }
        const token = await authService.generateEmailVerificationEmail(
          result.value.id,
          false
        );
        expect(token).not.toBeNull();

        const user = await authService.verifyEmailVerification(token?.id ?? "");

        expect(user).not.toBeNull();
        expect(user?.id).toEqual(result.value.id);
      })
    );
  });
});
