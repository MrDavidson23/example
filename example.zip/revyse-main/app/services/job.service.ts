import { JobRegistry, CronList } from "../worker/jobs";
import { Queue } from "bullmq";
import { getLogger } from "./logger.factory";
import { getEnv } from "./env.service.server";
const logger = getLogger("JobService");

const env = getEnv();

export class JobService {
  private default_queue = new Queue("default", {
    connection: {
      host: env.REDIS_CLUSTER_ENDPOINT,
      port: 6379,
    },
  });

  public readonly queues = [this.default_queue];

  runJob<
    JobName extends keyof typeof JobRegistry,
    // Gets the second parameter type of the job function
    DataType extends Parameters<(typeof JobRegistry)[JobName]["job"]>[1]
  >(job: JobName, data: DataType, delay = 0) {
    const spec = JobRegistry[job];
    this.default_queue.add(job, data, {
      ...spec.options,
      delay,
    });
  }

  async initCrons() {
    // Remove all crons before re-initializing them
    let repeatableJobs = await this.default_queue.getRepeatableJobs();
    logger.debug(
      "Removing all repeatable jobs",
      repeatableJobs.map(job => job.key)
    );
    await Promise.all(
      repeatableJobs.map(job => {
        return this.default_queue.removeRepeatableByKey(job.key);
      })
    );

    repeatableJobs = await this.default_queue.getRepeatableJobs();
    logger.debug(
      "Repeatable jobs post remove",
      repeatableJobs.map(job => job.key)
    );

    await Promise.all(
      CronList.map(jobSpec =>
        this.default_queue.add(jobSpec.name, null, {
          ...jobSpec.options,
        })
      )
    );

    repeatableJobs = await this.default_queue.getRepeatableJobs();
    logger.info(
      "Initialized repeating jobs:",
      repeatableJobs.map(job => job.key)
    );
  }
}
