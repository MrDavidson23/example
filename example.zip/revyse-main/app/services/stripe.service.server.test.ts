import { faker } from "@faker-js/faker";
import { StripePriceCadence, Tier } from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { withFixtureFactory } from "../utils/test.utils.server";
import type Stripe from "stripe";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const stripeProduct = await tx.stripeProduct.create({
      data: {
        id: `prod_${faker.string.uuid()}`,
        name: faker.commerce.productName(),
        active: true,
        tier: Tier.tier_3,
        description: faker.commerce.productDescription(),
      },
    });

    const stripePrice = await tx.stripePrice.create({
      data: {
        id: `price_${faker.string.uuid()}`,
        product: { connect: { id: stripeProduct.id } },
        active: faker.datatype.boolean(),
        cadence: faker.helpers.enumValue(StripePriceCadence),
        price: faker.number.int({ min: 1000, max: 5000 }),
      },
    });

    const freeStripePrice = await tx.stripePrice.create({
      data: {
        id: `price_${faker.string.uuid()}`,
        product: {
          create: {
            id: `prod_${faker.string.uuid()}`,
            name: faker.commerce.productName(),
            active: true,
            tier: Tier.free,
            description: faker.commerce.productDescription(),
          },
        },
        active: true,
        cadence: StripePriceCadence.monthly,
        price: 0,
      },
    });

    return { stripeProduct, stripePrice, freeStripePrice };
  },
});

describe("StripeService", () => {
  describe("updateStripeProduct", () => {
    it(
      "should update an existing stripeProduct",
      withFixtures(async ({ stripeProduct }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const updateDataStripeProduct = {
          id: stripeProduct.id,
          name: "product",
          description: "product",
        } as Stripe.Product;

        await stripeService.upsertStripeProduct(updateDataStripeProduct);

        const updatedStripeProduct = await tx.stripeProduct.findUnique({
          where: { id: stripeProduct.id },
        });

        expect(updatedStripeProduct?.name).toBe(updateDataStripeProduct.name);
        expect(updatedStripeProduct?.description).toBe(
          updateDataStripeProduct.description
        );
      })
    );

    it(
      "should create a new stripeProduct",
      withFixtures(async ({ stripeProduct }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const newDataStripeProduct = {
          id: `prod_${faker.string.uuid()}`,
          name: "new product",
          description: "new product",
        } as Stripe.Product;

        await stripeService.upsertStripeProduct(newDataStripeProduct);

        const newStripeProduct = await tx.stripeProduct.findFirst({
          where: { name: newDataStripeProduct.name },
        });

        expect(newStripeProduct?.name).toBe(newDataStripeProduct.name);
        expect(newStripeProduct?.description).toBe(
          newDataStripeProduct.description
        );
      })
    );
  });

  describe("getPlanChooserStripeProducts", () => {
    test(
      "should return the existent stripe products",
      withFixtures(async ({ stripePrice }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const stripeProducts =
          await stripeService.getPlanChooserStripeProducts();
        expect(stripeProducts).not.toBeNull();
        expect(stripeProducts.map(p => p.id)).toEqual(
          expect.arrayContaining([stripePrice.product_id])
        );
      })
    );
  });

  describe("updateStripePrice", () => {
    it(
      "should update an existing stripePrice",
      withFixtures(async ({ stripePrice }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const updateDataStripePrice = {
          id: stripePrice.id,
          product: stripePrice.product_id,
          unit_amount: faker.number.int({ min: 1000, max: 5000 }),
          recurring: {
            interval: "year",
            interval_count: 1,
          },
        } as Stripe.Price;

        await stripeService.upsertStripePrice(updateDataStripePrice);

        const updatedStripePrice = await tx.stripePrice.findUnique({
          where: { id: stripePrice.id },
        });

        expect(updatedStripePrice?.price).toBe(
          updateDataStripePrice.unit_amount
        );
        expect(updatedStripePrice?.cadence).toBe(StripePriceCadence.yearly);
        expect(updatedStripePrice?.product_id).toBe(stripePrice.product_id);
      })
    );

    it(
      "should create a new stripePrice",
      withFixtures(async ({ stripeProduct }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const newDataStripePrice = {
          id: `price_${faker.string.uuid()}`,
          product: stripeProduct.id,
          unit_amount: faker.number.int({ min: 1000, max: 5000 }),
          recurring: {
            interval: "month",
            interval_count: 1,
          },
        } as Stripe.Price;

        await stripeService.upsertStripePrice(newDataStripePrice);

        const newStripePrice = await tx.stripePrice.findFirst({
          where: {
            product_id: stripeProduct.id,
            price: newDataStripePrice.unit_amount ?? 0,
            cadence: StripePriceCadence.monthly,
          },
        });

        expect(newStripePrice?.price).toBe(newDataStripePrice.unit_amount);
        expect(newStripePrice?.cadence).toBe(StripePriceCadence.monthly);
      })
    );
  });

  describe("getStripeProduct", () => {
    it(
      "should return a stripeProduct",
      withFixtures(async ({ stripeProduct }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripeProduct = await stripeService.getStripeProduct(
          stripeProduct.id
        );

        expect(foundStripeProduct?.id).toBe(stripeProduct.id);
      })
    );

    it(
      "should return null if stripeProduct is not found",
      withFixtures(async ({ stripeProduct }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripeProduct = await stripeService.getStripeProduct(
          `prod_${faker.string.uuid()}`
        );

        expect(foundStripeProduct).toBeNull();
      })
    );

    it(
      "should return a stripeProduct with filters",
      withFixtures(async ({ stripeProduct }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripeProduct = await stripeService.getStripeProduct(
          stripeProduct.id,
          { name: stripeProduct.name }
        );

        expect(foundStripeProduct?.id).toBe(stripeProduct.id);
      })
    );

    it(
      "should return null if stripeProduct is not found with filters",
      withFixtures(async ({ stripeProduct }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripeProduct = await stripeService.getStripeProduct(
          stripeProduct.id,
          { name: "not found" }
        );

        expect(foundStripeProduct).toBeNull();
      })
    );
  });

  describe("getStripeProducts", () => {
    it(
      "should return all stripeProducts",
      withFixtures(async ({ stripeProduct }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripeProducts = await stripeService.getStripeProducts();

        expect(foundStripeProducts.length).toBeGreaterThan(0);
        expect(
          foundStripeProducts.some(p => p.id === stripeProduct.id)
        ).toBeTruthy();
      })
    );

    it(
      "should return stripeProducts with filters",
      withFixtures(async ({ stripeProduct }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripeProducts = await stripeService.getStripeProducts({
          name: stripeProduct.name,
        });

        expect(foundStripeProducts.length).toBeGreaterThan(0);
        expect(
          foundStripeProducts.some(p => p.id === stripeProduct.id)
        ).toBeTruthy();
      })
    );

    it(
      "should return empty array if stripeProducts are not found with filters",
      withFixtures(async ({ stripeProduct }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripeProducts = await stripeService.getStripeProducts({
          name: "not found",
        });

        expect(foundStripeProducts.length).toBe(0);
      })
    );
  });

  describe("getStripePrice", () => {
    it(
      "should return a stripePrice",
      withFixtures(async ({ stripePrice }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripePrice = await stripeService.getStripePrice(
          stripePrice.id
        );

        expect(foundStripePrice?.id).toBe(stripePrice.id);
      })
    );

    it(
      "should return null if stripePrice is not found",
      withFixtures(async ({ stripePrice }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripePrice = await stripeService.getStripePrice(
          `price_${faker.string.uuid()}`
        );

        expect(foundStripePrice).toBeNull();
      })
    );

    it(
      "should return a stripePrice with filters",
      withFixtures(async ({ stripePrice }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripePrice = await stripeService.getStripePrice(
          stripePrice.id,
          { price: stripePrice.price }
        );

        expect(foundStripePrice?.id).toBe(stripePrice.id);
      })
    );

    it(
      "should return null if stripePrice is not found with filters",
      withFixtures(async ({ stripePrice }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripePrice = await stripeService.getStripePrice(
          stripePrice.id,
          { price: 0 }
        );

        expect(foundStripePrice).toBeNull();
      })
    );
  });

  describe("getFreeStripePriceId", () => {
    it(
      "should return a monthly free stripePrice id",
      withFixtures(async ({ freeStripePrice }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const freeStripePriceId = await stripeService.getFreeStripePriceId();

        expect(freeStripePriceId).not.toBeNull();
        expect(freeStripePriceId?.id).toEqual(freeStripePrice?.id);
      })
    );
  });

  describe("getStripePrices", () => {
    it(
      "should return all stripePrices",
      withFixtures(async ({ stripePrice }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripePrices = await stripeService.getStripePrices();

        expect(foundStripePrices.length).toBeGreaterThan(0);
        expect(
          foundStripePrices.some(p => p.id === stripePrice.id)
        ).toBeTruthy();
      })
    );

    it(
      "should return stripePrices with filters",
      withFixtures(async ({ stripePrice }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripePrices = await stripeService.getStripePrices({
          price: stripePrice.price,
        });

        expect(foundStripePrices.length).toBeGreaterThan(0);
        expect(
          foundStripePrices.some(p => p.id === stripePrice.id)
        ).toBeTruthy();
      })
    );

    it(
      "should return empty array if stripePrices are not found with filters",
      withFixtures(async ({ stripePrice }, tx) => {
        const { stripeService } = TestDIContainer(tx);

        const foundStripePrices = await stripeService.getStripePrices({
          product_id: faker.string.uuid(),
        });

        expect(foundStripePrices.length).toBe(0);
      })
    );
  });

  describe.skip("getProductFromSession", () => {
    // Not testing because it's using Stripe API in the function
  });
});
