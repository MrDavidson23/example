import type { Prisma, Product, PrismaClient } from "@prisma/client";
import { getEnv } from "./env.service.server";
import type { CustomerSupportService } from "./customer-support.service.server";
import type { NotificationService } from "./notification.service.server";
import { tierHasPermission } from "../utils/permission.utils";
import { isNil, isEmpty } from "lodash";
import { ProductSubscriptionActiveStatuses } from "../utils/product-subscription.utils.server";

interface ReviewFormData {
  title: string;
  decision_maker: string | null;
  who_uses: string[];
  primary_use_case: string;
  like_most: string;
  dislike_most: string;
  recommend_to: string | null;
  custom_question_1: string | null;
  custom_question_2: string | null;
  custom_question_3: string | null;
  customer_service_score: number;
  customer_service_desc: string;
  value_score: number;
  value_desc: string;
  onboarding_score: number;
  onboarding_desc: string;
  compatibility_score: number;
  compatibility_desc: string;
  show_last_name: boolean;
  show_job_title: boolean;
  show_company: boolean;
}
export class ReviewService {
  constructor(
    private db: PrismaClient,
    private customerSupportService: CustomerSupportService,
    private notificationService: NotificationService
  ) {}

  async getProductReview({
    userId,
    productId,
  }: {
    userId?: string;
    productId?: string;
  }) {
    return await this.db.productReview.findFirst({
      where: {
        user_id: userId,
        product_id: productId,
      },
    });
  }

  async createProductReview(
    id: string | undefined,
    product: Product,
    userId: string,
    form: ReviewFormData
  ) {
    if (id === "new") {
      const review = await this.db.productReview.create({
        data: {
          ...form,
          product_id: product.id,
          user_id: userId,
        },
      });
      const env = getEnv();
      await this.customerSupportService.sendCSEmail(
        `New Review for ${product.title}`,
        `A new review has been submitted for ${product.title}. Please <a href="${env.REVYSE_UI_ORIGIN}/admin/reviews/${review.id}">review and approve</a>.`
      );
    }
  }
  async getReviewsWithRatings({
    productId,
    take,
  }: {
    productId: string;
    take?: number;
  }) {
    const reviews = await this.db.productReview.findMany({
      take,
      orderBy: { created_at: "desc" },
      where: { product_id: productId, approved_by_id: { not: null } },
      include: {
        user: {
          select: {
            first_name: true,
            last_name: true,
            title: true,
            company_name: true,
          },
        },
        responded_by: {
          select: {
            first_name: true,
            last_name: true,
            title: true,
          },
        },
        _count: {
          select: { helpfuls: true },
        },
      },
    });
    const aggregates = await this.db.productReview.aggregate({
      _avg: {
        value_score: true,
        compatibility_score: true,
        customer_service_score: true,
        onboarding_score: true,
      },
      _count: {
        id: true,
      },
      where: { product_id: productId, approved_by_id: { not: null } },
    });

    return {
      reviews,
      averages: aggregates._avg,
      total_count: aggregates._count.id,
    };
  }

  async getReviewWithHelpfuls({ reviewId }: { reviewId: string | undefined }) {
    const review = await this.db.productReview.findFirstOrThrow({
      where: { id: reviewId },
      include: {
        approved_by: true,
        user: true,
        responded_by: true,
        product: {
          include: {
            vendor: true,
            primary_category: true,
            subscriptions: {
              include: {
                stripe_price: {
                  include: { product: true },
                },
              },
              where: {
                status: {
                  in: ProductSubscriptionActiveStatuses,
                },
              },
              orderBy: { created_at: "desc" },
            },
          },
        },
        _count: {
          select: { helpfuls: true },
        },
      },
    });

    return review;
  }

  getReviewsByProductIds(productIds: string[]) {
    return this.db.productReview.findMany({
      where: {
        product_id: { in: productIds },
        approved_at: { not: null },
      },
      include: {
        user: {
          select: {
            first_name: true,
            last_name: true,
          },
        },
        product: true,
        responded_by: {
          select: {
            first_name: true,
            last_name: true,
          },
        },
      },
      orderBy: {
        created_at: "desc",
      },
    });
  }

  async updateReviewResponse(id: string, response: string, userId: string) {
    await this.db.$transaction(async tx => {
      const review = await tx.productReview.findFirstOrThrow({
        where: { id },
        include: {
          product: {
            include: {
              subscriptions: {
                include: { stripe_price: { include: { product: true } } },
              },
              vendor: true,
            },
          },
          user: true,
        },
      });
      const tier = review.product.subscriptions[0]?.stripe_price.product.tier;
      if (!tierHasPermission(tier, "respond_to_reviews")) {
        throw new Error("Unauthorized");
      }
      if (review.response !== response) {
        const updatedReview = await tx.productReview.update({
          data: {
            response,
            responded_at: new Date(),
            responded_by_id: userId,
          },
          where: { id },
          include: {
            product: {
              include: {
                subscriptions: {
                  include: { stripe_price: { include: { product: true } } },
                },
                vendor: true,
              },
            },
            user: true,
          },
        });

        // If this is the first time the response has been set, send an email
        if (isNil(review.responded_at)) {
          this.customerSupportService
            .sendCSEmail(
              `Review was Responded to on ${updatedReview.product.title}`,
              `<pre>Response:\n\n${updatedReview.response}\n\n<a href="${
                getEnv().REVYSE_UI_ORIGIN
              }/admin/reviews/${updatedReview.id}">View Review</a></pre>`
            )
            .catch(err => console.error(err));
          this.notificationService
            .sendReviewRespondedEmail(updatedReview.user.email, updatedReview)
            .catch(err => console.error(err));
        }
      }
    });
  }

  async toggleReviewHelpful({
    reviewId,
    userId,
  }: {
    reviewId: string;
    userId: string;
  }) {
    const review = await this.db.productReview.findFirstOrThrow({
      where: { id: reviewId },
      include: { product: true, helpfuls: { where: { user_id: userId } } },
    });

    if (isEmpty(review.helpfuls)) {
      await this.db.productReviewHelpful.create({
        data: { user_id: userId, review_id: review.id },
      });
    } else {
      await this.db.productReviewHelpful.delete({
        where: { id: review.helpfuls[0].id },
      });
    }

    return { review, helpful: isEmpty(review.helpfuls) };
  }

  async getReviewsCount({ where }: { where?: Prisma.ProductReviewWhereInput }) {
    return this.db.productReview.count({ where });
  }

  async getReviews({
    where,
    orderBy,
    take,
    skip,
    include,
  }: {
    where: Prisma.ProductReviewWhereInput;
    orderBy: Prisma.ProductReviewFindManyArgs["orderBy"];
    take: number;
    skip: number;
    include: Prisma.ProductReviewInclude;
  }) {
    return this.db.productReview.findMany({
      where,
      orderBy,
      take,
      skip,
      include,
    });
  }

  async updateReview({
    id,
    data,
  }: {
    id: string;
    data: Prisma.ProductReviewUpdateInput;
  }) {
    return this.db.productReview.update({
      data,
      where: { id },
    });
  }

  async updateReviewApproval({
    id,
    approved,
    userId,
  }: {
    id: string;
    approved: boolean;
    userId: string;
  }) {
    await this.db.$transaction(async tx => {
      const review = await tx.productReview.update({
        data: {
          approved_by_id: approved ? userId : null,
          approved_at: approved ? new Date() : null,
        },
        where: { id },
        include: {
          product: {
            include: {
              vendor: true,
              subscriptions: {
                where: {
                  status: {
                    in: ProductSubscriptionActiveStatuses,
                  },
                },
                include: {
                  user_roles: {
                    include: {
                      user: true,
                    },
                  },
                },
              },
            },
          },
        },
      });

      if (approved) {
        const activeSubscription = review.product.subscriptions[0];

        if (activeSubscription) {
          const userEmails = activeSubscription.user_roles.map(
            userRole => userRole.user.email
          );
          this.notificationService.sendReviewApprovedEmail(userEmails, review);
        }
      }
      return review;
    });
  }

  async getReviewById({ id }: { id: string }) {
    const review = await this.db.productReview.findFirst({
      where: { id },
      include: {
        approved_by: true,
        user: {
          include: {
            user_roles: true,
          },
        },
        responded_by: true,
        product: true,
      },
    });

    return review;
  }

  async deleteReview({ id }: { id: string }) {
    return this.db.productReview.delete({
      where: { id },
    });
  }
}
