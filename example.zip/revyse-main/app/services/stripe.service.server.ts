import type { Prisma, PrismaClient } from "@prisma/client";
import { StripePriceCadence, Tier } from "@prisma/client";
import Stripe from "stripe";
import { getEnv } from "./env.service.server";

export class StripeService {
  constructor(private db: PrismaClient) {}

  async getPlanChooserStripeProducts() {
    return this.db.stripeProduct.findMany({
      where: { active: true },
      include: {
        prices: {
          where: { active: true },
        },
      },
      orderBy: { order: "asc" },
    });
  }

  async upsertStripeProduct(product: Stripe.Product) {
    const data = {
      name: product.name,
      description: product.description || "",
    };
    await this.db.stripeProduct.upsert({
      where: { id: product.id },
      create: {
        id: product.id,
        ...data,
      },
      update: data,
    });
  }

  async upsertStripePrice(price: Stripe.Price) {
    const data = {
      price: price.unit_amount || 0,
      product_id: price.product as string,
      cadence:
        price.recurring?.interval === "month" &&
        price.recurring.interval_count === 1
          ? StripePriceCadence.monthly
          : StripePriceCadence.yearly,
    };
    await this.db.stripePrice.upsert({
      where: { id: price.id },
      create: {
        id: price.id,
        ...data,
      },
      update: data,
    });
  }

  async getStripeProduct(
    productId: string,
    filters: Prisma.StripeProductWhereInput = {}
  ) {
    return this.db.stripeProduct.findFirst({
      where: {
        id: productId,
        ...filters,
      },
    });
  }

  async getStripeProducts(filters: Prisma.StripeProductWhereInput = {}) {
    return this.db.stripeProduct.findMany({
      where: filters,
    });
  }

  async getStripePrice(
    priceId: string,
    filters: Prisma.StripePriceWhereInput = {}
  ) {
    return this.db.stripePrice.findFirst({
      where: {
        id: priceId,
        ...filters,
      },
    });
  }

  async getFreeStripePriceId() {
    return await this.db.stripePrice.findFirst({
      where: {
        product: {
          tier: Tier.free,
          active: true,
        },
        active: true,
        cadence: StripePriceCadence.monthly,
      },
      select: {
        id: true,
      },
    });
  }

  async getStripePrices(filters: Prisma.StripePriceWhereInput = {}) {
    return this.db.stripePrice.findMany({
      where: filters,
    });
  }

  async getProductFromSession(sessionId: string) {
    const stripe = new Stripe(getEnv().STRIPE_SECRET_KEY, {
      apiVersion: "2022-11-15",
    });
    const session = await stripe.checkout.sessions.retrieve(sessionId);

    if (!session) throw new Error("No session found");

    if (!session.metadata?.product_listing_id) {
      throw new Error("No product_listing_id found");
    }

    const productId = session.metadata!.product_listing_id;

    if (productId === "new") {
      return null;
    }

    const product = await this.db.product.findUniqueOrThrow({
      where: { id: productId },
    });

    return product;
  }
}
