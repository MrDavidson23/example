import type { Prisma, PrismaClient } from "@prisma/client";
import { ProductState, VendorState } from "@prisma/client";
import type { ProductService } from "./product.service.server";

export class ProductCategoryService {
  constructor(
    private db: PrismaClient,
    private productService: ProductService
  ) {}

  async getAllCategories() {
    return await this.db.productCategory.findMany({
      orderBy: { name: "asc" },
    });
  }

  async getPopularCategories() {
    return {
      technology: await this.db.productCategory.findMany({
        where: {
          name: {
            in: ["Smart Home", "Resident App", "Virtual Leasing Agents"],
          },
        },
      }),
      services: await this.db.productCategory.findMany({
        where: {
          name: { in: ["Branding & Design", "Business Consultants"] },
        },
      }),
      suppliers: await this.db.productCategory.findMany({
        where: {
          name: { in: ["Facilities & Maintenance Supplies", "WiFi & Telecom"] },
        },
      }),
    };
  }

  async getCategory({ slug, id }: { slug?: string; id?: string }) {
    return await this.db.productCategory.findFirstOrThrow({
      where: { slug: slug, id: id },
    });
  }

  async getCategoryProducts(categoryId: string | undefined) {
    const productIds = (
      await this.db.product.findMany({
        select: { id: true },
        where: {
          OR: [
            { primary_category_id: categoryId },
            { secondary_category_id: categoryId },
            { tertiary_category_id: categoryId },
          ],
          approved_at: { not: null },
          state: ProductState.discovery,
          vendor: { state: VendorState.ApprovedForPublishing },
        },
        take: 100,
      })
    ).map(p => p.id);
    return await this.productService.getProductsWithRatings({
      ids: productIds,
    });
  }

  async updateCategory(id: string, data: Prisma.ProductCategoryUpdateInput) {
    return await this.db.productCategory.update({
      where: { id: id },
      data,
    });
  }

  async createCategory(data: Prisma.ProductCategoryCreateInput) {
    return await this.db.$transaction(async tx => {
      return tx.productCategory.create({
        data,
      });
    });
  }

  async deleteCategory(id: string) {
    const categoryProducts = await this.db.product.findMany({
      where: {
        OR: [
          { primary_category_id: id },
          { secondary_category_id: id },
          { tertiary_category_id: id },
        ],
      },
    });

    if (categoryProducts.length) {
      throw new Error("Category has products");
    }

    return await this.db.productCategory.delete({ where: { id: id } });
  }

  getCategoriesForProducts(
    {
      search,
      products,
    }: {
      search: string;
      products: {
        primary_category_id: string;
        secondary_category_id: string | null;
        tertiary_category_id: string | null;
      }[];
    },
    take?: number
  ) {
    return this.db.productCategory.findMany({
      where: {
        OR: [
          { name: { contains: search, mode: "insensitive" } },
          { description: { contains: search, mode: "insensitive" } },
          {
            id: {
              in: products.flatMap(
                p =>
                  [
                    p.primary_category_id,
                    p.secondary_category_id,
                    p.tertiary_category_id,
                  ].filter(Boolean) as string[]
              ),
            },
          },
        ],
      },
      take,
    });
  }
}
