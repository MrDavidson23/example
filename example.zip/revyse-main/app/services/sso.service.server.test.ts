import { withFixtureFactory } from "../utils/test.utils.server";
import { createTestUser } from "./seeds/createTestUser";
import { faker } from "@faker-js/faker";
import { randomUUID } from "crypto";
import { TestDIContainer } from "../di-containers/test.di-container.server";

describe("SSOService", () => {
  const withFixtures = withFixtureFactory({
    setup: async tx => {
      const { db, authService, ssoService } = await TestDIContainer(tx);
      const client = await db.oAuthClient.create({
        data: {
          redirect_uri: "https://test.com/sso/callback",
          name: "Circle",
        },
      });
      const user = await createTestUser(faker.internet.email(), authService);

      return {
        client,
        user,
        ssoService,
      };
    },
  });

  describe("generateAuthCode", () => {
    it(
      "should generate an auth code with valid parameters",
      withFixtures(async ({ ssoService, user, client }, tx) => {
        const response = await ssoService.generateAuthCode(
          "code",
          client.client_id,
          "https://test.com/sso/callback",
          "read",
          user
        );

        expect(response.status).toBe(200);
      })
    );

    it(
      "should return an error with an invalid response type",
      withFixtures(async ({ ssoService, user, client }, tx) => {
        const response = await ssoService.generateAuthCode(
          "invalid_response_type",
          client.client_id,
          "https://test.com/sso/callback",
          "read",
          user
        );

        expect(response.status).toBe(400);
      })
    );

    it(
      "should return an error with an invalid scope",
      withFixtures(async ({ ssoService, user, client }, tx) => {
        const response = await ssoService.generateAuthCode(
          "code",
          client.client_id,
          "https://test.com/sso/callback",
          "invalid_scope",
          user
        );

        expect(response.status).toBe(400);
      })
    );

    it(
      "should return an error with an invalid redirect URI",
      withFixtures(async ({ ssoService, user, client }, tx) => {
        const response = await ssoService.generateAuthCode(
          "code",
          client.client_id,
          "invalid_redirect_uri",
          "read",
          user
        );

        expect(response.status).toBe(400);
      })
    );

    it(
      "should return an error with an invalid client ID",
      withFixtures(async ({ ssoService, user }, tx) => {
        const response = await ssoService.generateAuthCode(
          "code",
          randomUUID(),
          "https://test.com/sso/callback",
          "read",
          user
        );

        expect(response.status).toBe(400);
      })
    );
  });

  describe("generateAccessToken", () => {
    it(
      "should return a valid access token response",
      withFixtures(async ({ ssoService, client, user }, tx) => {
        const oauthCodeResponse = await ssoService.generateAuthCode(
          "code",
          client.client_id,
          "https://test.com/sso/callback",
          "read",
          user
        );

        const oauthCodeBody = await oauthCodeResponse.text();
        const oauthCodeBodyJson = JSON.parse(oauthCodeBody);
        const oauthCode = oauthCodeBodyJson.oauthCode.code;

        const response = await ssoService.generateAccessToken(
          client.client_id,
          client.client_secret,
          "authorization_code",
          oauthCode,
          "https://test.com/sso/callback"
        );
        expect(response.status).toBe(200);
      })
    );

    it(
      "should return an invalid grant type error response",
      withFixtures(async ({ ssoService, client, user }, tx) => {
        const oauthCodeResponse = await ssoService.generateAuthCode(
          "code",
          client.client_id,
          "https://test.com/sso/callback",
          "read",
          user
        );

        const oauthCodeBody = await oauthCodeResponse.text();
        const oauthCodeBodyJson = JSON.parse(oauthCodeBody);
        const oauthCode = oauthCodeBodyJson.oauthCode.code;

        const response = await ssoService.generateAccessToken(
          client.client_id,
          client.client_secret,
          "password",
          oauthCode,
          "https://test.com/sso/callback"
        );

        expect(response.status).toBe(400);
      })
    );

    it(
      "should return an invalid authorization code error response",
      withFixtures(async ({ ssoService, client }, tx) => {
        const response = await ssoService.generateAccessToken(
          client.client_id,
          client.client_secret,
          "authorization_code",
          "invalid_authorization_code",
          "https://test.com/sso/callback"
        );

        expect(response.status).toBe(400);
      })
    );

    it(
      "should return an invalid client credentials error response",
      withFixtures(async ({ ssoService, user, client }, tx) => {
        const oauthCodeResponse = await ssoService.generateAuthCode(
          "code",
          client.client_id,
          "https://test.com/sso/callback",
          "read",
          user
        );

        const oauthCodeBody = await oauthCodeResponse.text();
        const oauthCodeBodyJson = JSON.parse(oauthCodeBody);
        const oauthCode = oauthCodeBodyJson.oauthCode.code;

        const response = await ssoService.generateAccessToken(
          randomUUID(),
          "clientSecret",
          "authorization_code",
          oauthCode,
          "https://test.com/sso/callback"
        );

        expect(response.status).toBe(400);
      })
    );

    it(
      "should return an invalid client credentials error response when client secret doesn't march",
      withFixtures(async ({ ssoService, client, user }, tx) => {
        const oauthCodeResponse = await ssoService.generateAuthCode(
          "code",
          client.client_id,
          "https://test.com/sso/callback",
          "read",
          user
        );

        const oauthCodeBody = await oauthCodeResponse.text();
        const oauthCodeBodyJson = JSON.parse(oauthCodeBody);
        const oauthCode = oauthCodeBodyJson.oauthCode.code;

        const response = await ssoService.generateAccessToken(
          client.client_id,
          randomUUID(),
          "authorization_code",
          oauthCode,
          "https://test.com/sso/callback"
        );

        expect(response.status).toBe(400);
      })
    );
  });

  describe("getUserInfo", () => {
    it(
      "should return user info with a valid access token",
      withFixtures(async ({ ssoService, client, user }, tx) => {
        const oauthCodeResponse = await ssoService.generateAuthCode(
          "code",
          client.client_id,
          "https://test.com/sso/callback",
          "read",
          user
        );
        const oauthCodeBody = await oauthCodeResponse.text();
        const oauthCodeBodyJson = JSON.parse(oauthCodeBody);
        const oauthCode = oauthCodeBodyJson.oauthCode.code;

        const tokenResponse = await ssoService.generateAccessToken(
          client.client_id,
          client.client_secret,
          "authorization_code",
          oauthCode,
          "https://test.com/sso/callback"
        );
        const tokenResponseBody = await tokenResponse.text();
        const tokenBodyJson = JSON.parse(tokenResponseBody);
        const accessToken = tokenBodyJson.access_token;

        const response = await ssoService.getUserInfo(accessToken);

        const expectedUserInfo = {
          user: {
            id: user.id,
            email: user.email,
            name: `${user.first_name} ${user.last_name}`,
          },
        };

        const responseBody = await response.text();
        const bodyJson = JSON.parse(responseBody);

        expect(response.status).toBe(200);
        expect(bodyJson).toEqual(expectedUserInfo);
      })
    );

    it(
      "should return an error with a missing access token",
      withFixtures(async ({ ssoService }, tx) => {
        const accessToken = "";

        const response = await ssoService.getUserInfo(accessToken);

        expect(response.status).toBe(401);
      })
    );

    it(
      "should return an error with an invalid or expired access token",
      withFixtures(async ({ ssoService }, tx) => {
        const accessToken = "invalidAccessToken";

        const response = await ssoService.getUserInfo(accessToken);

        expect(response.status).toBe(401);
      })
    );
  });
});
