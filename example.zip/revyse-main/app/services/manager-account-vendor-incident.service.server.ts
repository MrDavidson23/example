import type {
  ContractStatus,
  ManagerAccountVendorBusinessCriticalityRating,
  ManagerAccountVendorIncidentImpact,
  ManagerAccountVendorIncidentStatus,
  ManagerAccountVendorStatus,
  PrismaClient,
} from "@prisma/client";
import { isNil } from "lodash";

export type ManagerAccountVendorContractFilters = {
  query?: string;
  status?: ContractStatus[];
  annual_value_start?: number;
  annual_value_end?: number;
  current_term_end_date_start?: Date;
  current_term_end_date_end?: Date;
};

export type ManagerAccountVendorTableFilters = {
  query?: string;
  status?: ManagerAccountVendorStatus[];
  is_preferred?: boolean;
  business_criticality_rating?: ManagerAccountVendorBusinessCriticalityRating | null;
  location_count_ranges?: [number, number][]; // [start, end]
  annual_value_start?: number;
  annual_value_end?: number;
};

export class ManagerAccountVendorIncidentService {
  constructor(private db: PrismaClient) {}

  async loadIncident(id: string | undefined) {
    return await this.db.managerAccountVendorIncident.findFirst({
      where: { id },
      include: {
        manager_account_vendor: true,
      },
    });
  }

  async handleIncident(
    id: string,
    accountVendorId: string,
    data: {
      name: string;
      status: ManagerAccountVendorIncidentStatus;
      created_date: Date;
      resolved_date?: Date | null;
      nature_scope_timing?: string | undefined;
      impact?: ManagerAccountVendorIncidentImpact;
      description?: string | undefined;
      next_steps?: string | undefined;
      response_team?: string | undefined;
    }
  ) {
    const incident = await this.db.$transaction(async tx => {
      const loadedIncident =
        id === "new"
          ? await tx.managerAccountVendorIncident.create({
              data: {
                ...data,
                manager_account_vendor_id: accountVendorId,
              },
            })
          : await this.loadIncident(id);

      if (isNil(loadedIncident)) {
        throw new Response("Not found", { status: 404 });
      }
      if (id !== "new") {
        return await tx.managerAccountVendorIncident.update({
          where: { id },
          data: {
            ...data,
          },
        });
      }
      return loadedIncident;
    });
    return incident;
  }

  async deleteIncident(id: string | undefined) {
    return await this.db.managerAccountVendorIncident.delete({ where: { id } });
  }
}
