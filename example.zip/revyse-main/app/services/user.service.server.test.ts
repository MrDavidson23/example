import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { withFixtureFactory } from "../utils/test.utils.server";
import { sortBy } from "lodash";
import { Prisma, Role, UserRoleType } from "@prisma/client";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const users = await Promise.all(
      Array.from({ length: 10 }, () =>
        tx.user.create({
          data: {
            email: faker.internet.email(),
            first_name: faker.person.firstName(),
            last_name: faker.person.lastName(),
          },
        })
      )
    );

    const emailVerificationToken = await tx.emailVerificationToken.create({
      data: {
        user: { connect: { id: users[0].id } },
        email: users[0].email,
        verified_at: new Date(),
      },
    });

    return { users, emailVerificationToken };
  },
});

describe("UserService", () => {
  describe("getUsers", () => {
    it(
      "should return users",
      withFixtures(async ({ users }, tx) => {
        const { userService } = TestDIContainer(tx);

        const result = await userService.getUsers({});

        expect(result).toEqual(
          expect.arrayContaining(
            users.map(user => expect.objectContaining(user))
          )
        );
      })
    );

    it(
      "should return filtered users with email verification tokens",
      withFixtures(async ({ users, emailVerificationToken }, tx) => {
        const { userService } = TestDIContainer(tx);

        const result = await userService.getUsers({
          where: {
            id: users[0].id,
          },
        });

        expect(result).toEqual([
          expect.objectContaining({
            ...users[0],
            email_verification_tokens: [emailVerificationToken],
          }),
        ]);
      })
    );

    it(
      "should return paginated users",
      withFixtures(async ({ users }, tx) => {
        const { userService } = TestDIContainer(tx);

        const result = await userService.getUsers({
          where: {
            id: {
              in: users.map(user => user.id),
            },
          },
          take: 5,
          skip: 2,
          orderBy: {
            email: "asc",
          },
        });

        const expected = sortBy(users, "email")
          .slice(2, 7)
          .map(user => expect.objectContaining(user));

        expect(result).toEqual(expect.arrayContaining(expected));
      })
    );
  });

  describe("getUsersCount", () => {
    it(
      "should return total users",
      withFixtures(async ({ users }, tx) => {
        const { userService } = TestDIContainer(tx);

        const result = await userService.getUsersCount({
          where: {
            id: {
              in: users.map(user => user.id),
            },
          },
        });

        expect(result).toEqual(users.length);
      })
    );

    it(
      "should return filtered total users",
      withFixtures(async ({ users }, tx) => {
        const { userService } = TestDIContainer(tx);

        const result = await userService.getUsersCount({
          where: {
            id: users[0].id,
          },
        });

        expect(result).toEqual(1);
      })
    );
  });

  describe("getUserById", () => {
    it(
      "should return user",
      withFixtures(async ({ users, emailVerificationToken }, tx) => {
        const { userService } = TestDIContainer(tx);

        const result = await userService.getUserById({
          id: users[0].id,
        });

        expect(result).toEqual(
          expect.objectContaining({
            ...users[0],
            email_verification_tokens: [emailVerificationToken],
          })
        );
      })
    );
  });

  describe("updateUser", () => {
    it(
      "should update user",
      withFixtures(async ({ users }, tx) => {
        const { userService } = TestDIContainer(tx);

        const result = await userService.updateUser({
          id: users[0].id,
          data: {
            first_name: "Updated",
          },
        });

        const userFromDb = await tx.user.findFirst({
          where: { id: users[0].id },
        });

        expect(result).toEqual(userFromDb);
        expect(result).toEqual(
          expect.objectContaining({
            ...users[0],
            first_name: "Updated",
          })
        );
      })
    );

    it(
      "should throw error if user not found",
      withFixtures(async ({ users }, tx) => {
        const { userService } = TestDIContainer(tx);

        await expect(
          userService.updateUser({
            id: "non-existing-id",
            data: {
              first_name: "Updated",
            },
          })
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError);
      })
    );
  });

  describe("deleteUser", () => {
    it(
      "should delete user",
      withFixtures(async ({ users }, tx) => {
        const { userService } = TestDIContainer(tx);

        await userService.deleteUser({
          id: users[0].id,
        });

        const userFromDb = await tx.user.findFirst({
          where: { id: users[0].id },
        });

        expect(userFromDb).toBeNull();
      })
    );

    it(
      "should throw error if user not found",
      withFixtures(async ({ users }, tx) => {
        const { userService } = TestDIContainer(tx);

        await expect(
          userService.deleteUser({
            id: faker.string.uuid(),
          })
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError);
      })
    );
  });

  describe("updateBuyerVerifiedUserRole", () => {
    it(
      "should update user role to buyer",
      withFixtures(async ({ users }, tx) => {
        const { userService } = TestDIContainer(tx);

        await userService.updateBuyerVerifiedUserRole({
          userId: users[0].id,
          verified: true,
        });

        const userRoleFromDb = await tx.userRole.findFirst({
          where: {
            user_id: users[0].id,
            role: "BUYER",
            type: "GLOBAL",
          },
        });

        expect(userRoleFromDb).not.toBeNull();
      })
    );

    it(
      "should send buyer verified email",
      withFixtures(async ({ users }, tx) => {
        const { userService, notificationService } = TestDIContainer(tx);
        const sendBuyerVerifiedEmailSpy = jest.spyOn(
          notificationService,
          "sendBuyerVerifiedEmail"
        );

        await userService.updateBuyerVerifiedUserRole({
          userId: users[0].id,
          verified: true,
        });

        expect(sendBuyerVerifiedEmailSpy).toHaveBeenCalledWith(users[0].email);
      })
    );

    it(
      "should revoke buyer role",
      withFixtures(async ({ users }, tx) => {
        const { userService } = TestDIContainer(tx);

        await userService.updateBuyerVerifiedUserRole({
          userId: users[0].id,
          verified: true,
        });

        await userService.updateBuyerVerifiedUserRole({
          userId: users[0].id,
          verified: false,
        });

        const userRoleFromDb = await tx.userRole.findFirst({
          where: {
            user_id: users[0].id,
            role: Role.BUYER,
            type: UserRoleType.GLOBAL,
          },
        });

        expect(userRoleFromDb).toBeNull();
      })
    );
  });
});
