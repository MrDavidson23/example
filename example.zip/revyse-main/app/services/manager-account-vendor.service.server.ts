import {
  ContractLineItemLocationStatus,
  ContractLineItemStatus,
  LocationStatus,
  VendorState,
} from "@prisma/client";
import type {
  Contract,
  ContractStatus,
  ManagerAccountVendor,
  ManagerAccountVendorBusinessCriticalityRating,
  ManagerAccountVendorDocumentType,
  ManagerAccountVendorStatus,
  Prisma,
  PrismaClient,
  ManagerAccountVendorContactType,
  Vendor,
  IntelligenceVendorIntegrationStatus,
  ManagerAccount,
} from "@prisma/client";
import { isEmpty, map } from "lodash";
import { type ManagerAccountService } from "./manager-account.service.server";
import type { MockS3Service } from "./s3.service.server";
import type { CustomerSupportService } from "./customer-support.service.server";
import { getEnv } from "./env.service.server";
import {
  generateContractsRawPermissionsQuery,
  generateManagerAccountVendorRawPermissionQuery,
} from "../utils/contract-permission.utils";
import {
  canDoOnAccount,
  Permission,
  type PermissionUser,
} from "../utils/intelligence-permission.utils";

export type ManagerAccountVendorContractFilters = {
  query?: string;
  status?: ContractStatus[];
  annual_value_start?: number;
  annual_value_end?: number;
  current_term_end_date_start?: Date;
  current_term_end_date_end?: Date;
};

export type ManagerAccountVendorTableFilters = {
  query?: string;
  status?: ManagerAccountVendorStatus[];
  is_preferred?: boolean;
  business_criticality_rating?: ManagerAccountVendorBusinessCriticalityRating | null;
  location_count_ranges?: [number, number][]; // [start, end]
  annual_value_start?: number;
  annual_value_end?: number;
};

export class ManagerAccountVendorService {
  constructor(
    private db: PrismaClient,
    private managerAccountService: ManagerAccountService,
    private s3Service: MockS3Service,
    private customerSupportService: CustomerSupportService
  ) {}

  async getManagerAccountVendorIdAndName(id: string) {
    const managerAccountVendor = await this.db.managerAccountVendor.findUnique({
      where: { id },
      select: {
        vendor: {
          select: {
            id: true,
            name: true,
          },
        },
      },
    });

    return managerAccountVendor?.vendor;
  }

  async getManagerAccountVendorWithFilters(
    where: Prisma.ManagerAccountVendorWhereInput,
    select: Prisma.ManagerAccountVendorSelect
  ) {
    return await this.db.managerAccountVendor.findFirst({
      where,
      select,
    });
  }

  async getManagerAccountVendor(
    id: string,
    include: Prisma.ManagerAccountVendorInclude = {}
  ) {
    const managerAccountVendor =
      await this.db.managerAccountVendor.findUniqueOrThrow({
        where: { id },
        include,
      });

    return managerAccountVendor;
  }

  async getManagerAccountVendorWithIntegrations(id: string) {
    const managerAccountVendor =
      await this.db.managerAccountVendor.findUniqueOrThrow({
        where: { id },
        include: {
          vendor: true,
          manager_account_vendor_contacts: true,
          manager_account_vendor_incidents: true,
          _count: {
            select: {
              manager_account_vendor_documents: true,
            },
          },
          intelligence_vendor_integrations: {
            include: {
              integrated_vendor: {
                include: {
                  vendor: true,
                },
              },
              integrated_product: true,
            },
          },
        },
      });

    return managerAccountVendor;
  }

  async getVendorRating(id: string) {
    const products = await this.db.product.findMany({
      where: { vendor_id: id },
      select: { id: true },
    });

    const productIds = map(products, "id");

    const aggregates = await this.db.productReview.aggregate({
      _avg: {
        value_score: true,
        compatibility_score: true,
        customer_service_score: true,
        onboarding_score: true,
      },
      _count: {
        id: true,
      },
      where: { product_id: { in: productIds }, approved_by_id: { not: null } },
    });

    const rating =
      ((aggregates._avg.value_score ?? 0) * 10 +
        (aggregates._avg.compatibility_score ?? 0) * 10 +
        (aggregates._avg.customer_service_score ?? 0) * 10 +
        (aggregates._avg.onboarding_score ?? 0) * 10) /
      4 /
      10;

    const totalReviews = aggregates._count.id;

    return {
      rating: +rating.toFixed(1),
      totalReviews,
    };
  }

  async getManagerAccountVendorContracts(
    user: PermissionUser,
    managerAccount: ManagerAccount,
    managerAccountVendorId: string,
    filters: ManagerAccountVendorContractFilters,
    take?: number,
    skip?: number,
    orderBy?: Partial<Record<keyof Contract, "asc" | "desc">>[]
  ) {
    const where: Prisma.ContractWhereInput = {
      manager_account_vendor_id: managerAccountVendorId,
    };

    if (
      !canDoOnAccount(user, managerAccount, Permission.ViewSensitiveContracts)
    ) {
      where.is_sensitive = false;
    }

    if (filters.query) {
      where.name = { contains: filters.query, mode: "insensitive" };
    }

    if (!isEmpty(filters.status)) {
      where.status = { in: filters.status };
    }

    if (
      filters.current_term_end_date_start &&
      filters.current_term_end_date_end
    ) {
      where.current_term_end_date = {
        gte: filters.current_term_end_date_start,
        lte: filters.current_term_end_date_end,
      };
    }

    // Defines if the pagination should be done in the query or in the code
    const paginateInQuery =
      !filters.annual_value_start && !filters.annual_value_end;

    const contracts = await this.db.contract.findMany({
      where,
      include: {
        _count: {
          select: {
            contract_line_items: {
              where: {
                status: {
                  not: ContractLineItemStatus.Canceled,
                },
              },
            },
          },
        },
        contract_line_items: {
          where: {
            status: {
              not: ContractLineItemStatus.Canceled,
            },
          },
          include: {
            contract_line_item_locations: {
              where: {
                status: { not: ContractLineItemLocationStatus.Canceled, },
                location: {
                  status: {
                    in: [LocationStatus.Active, LocationStatus.Pending],
                  },
                },
              },
              include: {
                location: true,
              },
            },
            contract_line_item_products: {
              include: { product: { include: { primary_category: true } } },
            },
            contract_line_item_fees: {
              include: { fee: true },
            },
          },
        },
        manager_account_vendor: true,
      },
      take: paginateInQuery ? take : undefined,
      skip: paginateInQuery ? skip : undefined,
      orderBy: orderBy,
    });

    //  Adds the locations count and the annual value to the contracts
    const contractsFormatted = contracts.map(contract => {
      let contractLocationsCount;

      // When all line items in a contract are marked as corporate-only, show “Corporate” in the Locations Assigned column
      const allCorporateOnly =
        contract.contract_line_items.length > 0 &&
        contract.contract_line_items.every(
          contractLineItem => contractLineItem.is_corporate_only
        );
      if (allCorporateOnly) {
        contractLocationsCount = "Corporate";
      } else {
        const contractLineItemLocationIds = contract.contract_line_items
          .flatMap(
            contractLineItem => contractLineItem?.contract_line_item_locations
          )
          .filter(
            location => location.status !== ContractLineItemLocationStatus.Canceled
          )
          .map(location => location.location_id);

        contractLocationsCount = String(
          new Set(contractLineItemLocationIds).size
        );
      }

      const contractAnnualSpend =
        this.managerAccountService.calculateAnnualValue(
          contract.contract_line_items
        );

      return {
        ...contract,
        locations_count: contractLocationsCount,
        annual_value: contractAnnualSpend.total,
      };
    });

    let filteredAndPaginatedContracts = contractsFormatted;

    // Filters the contracts by annual value
    if (filters.annual_value_start || filters.annual_value_end) {
      filteredAndPaginatedContracts = contractsFormatted.filter(contract => {
        if (filters.annual_value_start && filters.annual_value_end) {
          return (
            contract.annual_value >= filters.annual_value_start &&
            contract.annual_value <= filters.annual_value_end
          );
        } else if (filters.annual_value_start) {
          return contract.annual_value >= filters.annual_value_start;
        } else if (filters.annual_value_end) {
          return contract.annual_value <= filters.annual_value_end;
        }
        return true;
      });
    }

    // Paginates the contracts if the pagination was not done in the query
    if (!paginateInQuery && skip != undefined && take != undefined) {
      filteredAndPaginatedContracts = filteredAndPaginatedContracts.slice(
        skip,
        skip + take
      );
    }

    return filteredAndPaginatedContracts;
  }

  async getManagerAccountVendorContractsCount(
    managerAccountVendorId: string,
    filters: ManagerAccountVendorContractFilters
  ) {
    const where: Prisma.ContractWhereInput = {
      manager_account_vendor_id: managerAccountVendorId,
    };

    if (filters.query) {
      where.name = { contains: filters.query, mode: "insensitive" };
    }

    if (!isEmpty(filters.status)) {
      where.status = { in: filters.status };
    }

    if (
      filters.current_term_end_date_start &&
      filters.current_term_end_date_end
    ) {
      where.current_term_end_date = {
        gte: filters.current_term_end_date_start,
        lte: filters.current_term_end_date_end,
      };
    }

    if (!filters.annual_value_start && !filters.annual_value_end) {
      return await this.db.contract.count({
        where: where,
      });
    }

    const contracts = await this.db.contract.findMany({
      where,
      include: {
        contract_line_items: {
          include: {
            contract_line_item_locations: {
              where: {
                status: { not: ContractLineItemLocationStatus.Canceled, },
              },
              include: {
                location: true,
              },
            },
            contract_line_item_products: {
              include: { product: { include: { primary_category: true } } },
            },
            contract_line_item_fees: {
              include: { fee: true },
            },
          },
        },
      },
    });

    const contractsFormatted = contracts.map(contract => {
      const contractAnnualSpend =
        this.managerAccountService.calculateAnnualValue(
          contract.contract_line_items
        );

      const { contract_line_items, ...contractWithoutContractLineItems } =
        contract;

      return {
        ...contractWithoutContractLineItems,
        annual_value: contractAnnualSpend.total,
      };
    });

    const contractsFiltered = contractsFormatted.filter(contract => {
      if (filters.annual_value_start && filters.annual_value_end) {
        return (
          contract.annual_value >= filters.annual_value_start &&
          contract.annual_value <= filters.annual_value_end
        );
      } else if (filters.annual_value_start) {
        return contract.annual_value >= filters.annual_value_start;
      } else if (filters.annual_value_end) {
        return contract.annual_value <= filters.annual_value_end;
      }
      return true;
    });

    const contractsCount = contractsFiltered.length;

    return contractsCount;
  }

  async getManagerAccountVendorsTableData(
    user: PermissionUser,
    managerAccount: ManagerAccount,
    filters: ManagerAccountVendorTableFilters,
    limit?: number,
    offset?: number,
    orderBy?: {
      [K in string]: Prisma.SortOrder;
    }
  ) {
    type QueryResult = {
      total_count: number;
      rows: (ManagerAccountVendor & {
        vendor_logo_file_id: string;
        vendor_name: string;
        active_contracts_count: number;
        contracted_locations_count: number;
        annual_value: number;
        is_corporate_only: boolean;
      })[];
    };

    const query = filters.query?.replace(/'/g, "''");

    const result = await this.db.$queryRawUnsafe<QueryResult[]>(`
    with contract_line_item_annual_values as (
      select 
        cli.id, 
        cli.contract_id, 
        array_agg(l.id) as location_ids,
        cli.is_corporate_only,
        (-- Price
          (CASE 
            WHEN cli.pricing_type = 'FlatRate' THEN cli.price
            WHEN cli.pricing_type = 'PerSeat' THEN cli.price * cli.seats_number
            WHEN cli.pricing_type = 'UsageBased' THEN cli.estimated_cost
            WHEN cli.pricing_type = 'PerLease' THEN cli.estimated_cost * count(l.id)
            WHEN cli.pricing_type = 'PerUnit' THEN cli.price * sum(l.unit_count)
            WHEN cli.pricing_type = 'PerLocation' THEN cli.price * count(l.id)
            WHEN cli.pricing_type = 'Itemized' THEN cli.price
            ELSE 1 END) *
        -- Cadence
          (CASE 
            WHEN cli.cadence = 'Monthly' THEN 12
            WHEN cli.cadence = 'Quarterly' THEN 4
            WHEN cli.cadence = 'Annual' THEN 1
            ELSE 1 END)
        ) as annual_value
      from 
        contract_line_item cli 
        join contract c on c.id=cli.contract_id
        left join contract_line_item_location clil on clil.contract_line_item_id=cli.id AND clil.status
        in ('${ContractLineItemLocationStatus.Active}', '${ContractLineItemLocationStatus.Pending}')
        left join location l on l.id=clil.location_id AND l.status in ('Active', 'Pending')
      where
        cli.status = 'Active'
      group by cli.id
    ),
    contract_annual_values as (
      select 
        c.id, 
        c.manager_account_vendor_id,
        coalesce(sum(cliav.annual_value), 0) as annual_value
      from 
        contract c 
        left join contract_line_item_annual_values cliav on cliav.contract_id=c.id
      where c.status='Active'
      ${generateContractsRawPermissionsQuery({
        user,
        managerAccount,
        alias: {
          contract: "c",
        },
        queryConfig: {
          prefix: "AND",
        },
      })}
      group by c.id
    ),
    vendor_locations_count as (
      select 
        vlc.id, 
        COUNT(distinct vlc.location_ids)::int as contracted_locations_count,
        (CASE 
          WHEN COUNT(vlc.is_corporate_only) = SUM(vlc.is_corporate_only::int) THEN true 
          ELSE false 
        END) 
        as is_corporate_only
      from (
        select 
          v.id, 
          unnest(cliav.location_ids) as location_ids,
          cliav.is_corporate_only
  			from manager_account_vendor v 
      	left join contract_annual_values cav on cav.manager_account_vendor_id=v.id
      	left join contract_line_item_annual_values cliav on cliav.contract_id=cav.id
      ) as vlc
      group by vlc.id
    ),
    vendor_annual_values as (
      select 
        v.*, 
        count(distinct cav.id)::int as active_contracts_count,
        coalesce(sum(cav.annual_value), 0) as annual_value
      from 
        manager_account_vendor v 
        left join contract_annual_values cav on cav.manager_account_vendor_id=v.id
      group by v.id
    ),
    manager_account_vendors as (
      select 
        vav.*, 
        vlc.contracted_locations_count, 
        vlc.is_corporate_only,
        v.name as vendor_name, 
        v.logo_file_id as vendor_logo_file_id
      from 
        vendor_annual_values vav 
        left join vendor v on v.id=vav.vendor_id 
        left join vendor_locations_count vlc on vlc.id=vav.id
      where 
        vav.manager_account_id='${managerAccount.id}'::uuid
        ${generateManagerAccountVendorRawPermissionQuery({
          user,
          managerAccount,
          alias: {
            managerAccountVendor: "vav",
          },
          queryConfig: {
            prefix: "AND",
          },
        })}
        ${filters.query ? `AND v.name ILIKE '%${query}%'` : ""}
        ${
          filters.status
            ? `AND vav.status::text IN ('${filters.status.join("','")}')`
            : ""
        }
        ${
          filters.is_preferred
            ? `AND vav.is_preferred=${filters.is_preferred}`
            : ""
        }
        ${
          filters.business_criticality_rating
            ? `AND vav.business_criticality_rating::text LIKE '${filters.business_criticality_rating}'`
            : ""
        }
        ${
          filters.location_count_ranges
            ? `AND (${filters.location_count_ranges
                .map(
                  range =>
                    `vlc.contracted_locations_count >= ${range[0]} AND vlc.contracted_locations_count <= ${range[1]}`
                )
                .join(" OR ")})`
            : ""
        }
        ${
          filters.annual_value_start
            ? `AND vav.annual_value >= ${filters.annual_value_start}`
            : ""
        }
        ${
          filters.annual_value_end
            ? `AND vav.annual_value <= ${filters.annual_value_end}`
            : ""
        }
    )
    SELECT 
      (SELECT count(*)::int FROM manager_account_vendors) as total_count,
      (
        SELECT json_agg(mav.*) FROM (
          SELECT * FROM manager_account_vendors
          ${
            orderBy
              ? `ORDER BY ${Object.entries(orderBy)
                  .map(([key, value]) => `${key} ${value}`)
                  .join(", ")}`
              : ""
          }
          ${limit ? `LIMIT ${limit}` : ""}
          ${offset ? `OFFSET ${offset}` : ""}
        ) as mav
      ) as rows
    `);

    return result[0];
  }

  async updateManagerAccountVendorIntegrationMap(
    id: string,
    data: {
      intelligence_vendor_integrations: {
        status: IntelligenceVendorIntegrationStatus;
        id: string;
        integrated_vendor_id?: string | null;
        integrated_product_id?: string | null;
        notes?: string | null | undefined;
      }[];
    }
  ) {
    const integrationData = {
      intelligence_vendor_integrations: {
        deleteMany: {
          id: {
            notIn: map(data.intelligence_vendor_integrations, "id").filter(
              v => !v.includes("new_")
            ),
          },
        },
        updateMany: data.intelligence_vendor_integrations
          .filter(v => !v.id.includes("new_"))
          .map(vendorIntegration => ({
            data: {
              integrated_vendor_id: vendorIntegration.integrated_vendor_id,
              integrated_product_id: vendorIntegration.integrated_product_id,
              status: vendorIntegration.status,
              notes: vendorIntegration.notes,
            },
            where: { id: vendorIntegration.id },
          })),
        createMany: {
          data: data.intelligence_vendor_integrations
            .filter(v => v.id.includes("new_"))
            .map(vendorIntegration => ({
              integrated_vendor_id: vendorIntegration.integrated_vendor_id,
              integrated_product_id: vendorIntegration.integrated_product_id,
              status: vendorIntegration.status,
              notes: vendorIntegration.notes,
            })),
        },
      },
    };

    return await this.db.$transaction(async tx => {
      return tx.managerAccountVendor.update({
        data: integrationData,
        where: { id },
        include: {
          intelligence_vendor_integrations: true,
        },
      });
    });
  }

  async getVendorIntegrationVendorOptions(
    where: Prisma.ManagerAccountVendorWhereInput
  ) {
    return await this.db.managerAccountVendor.findMany({
      where,
      include: { vendor: true },
      distinct: ["vendor_id"],
      orderBy: { vendor: { name: "asc" } },
    });
  }

  getVendorIntegrationProductOptions(where: Prisma.ProductWhereInput) {
    return this.db.product.findMany({
      where,
      select: {
        id: true,
        title: true,
        logo_file_id: true,
      },
      orderBy: {
        title: "asc",
      },
    });
  }

  async updateManagerAccountVendorContacts(
    managerAccountVendorId: string,
    contacts: Partial<
      Record<
        ManagerAccountVendorContactType,
        Omit<
          Prisma.ManagerAccountVendorContactCreateInput,
          "type" | "manager_account_vendor"
        >
      >
    >
  ) {
    for (const key of Object.keys(contacts)) {
      const type = key as ManagerAccountVendorContactType;
      const contactData = contacts[type];

      if (!contactData || Object.values(contactData).every(isEmpty)) {
        await this.db.managerAccountVendorContact.deleteMany({
          where: {
            manager_account_vendor_id: managerAccountVendorId,
            type,
          },
        });

        continue;
      }

      await this.db.managerAccountVendorContact.upsert({
        where: {
          manager_account_vendor_id_type: {
            manager_account_vendor_id: managerAccountVendorId,
            type,
          },
        },
        create: {
          ...contactData,
          manager_account_vendor: { connect: { id: managerAccountVendorId } },
          type,
        },
        update: {
          ...contactData,
        },
      });
    }
  }

  async createManagerAccountVendor(
    data: {
      manager_account_id: string;
      vendor_id: string;
      new_vendor_name: string | null;
      new_vendor_description?: string | null;
    },
    user: { email: string }
  ) {
    return this.db.$transaction(async tx => {
      let vendorId = data.vendor_id;

      if (vendorId === "new") {
        const env = getEnv();
        const vendor = await tx.vendor.create({
          data: {
            name: data.new_vendor_name as string,
            description: data.new_vendor_description,
            slug: "",
          },
        });

        this.customerSupportService.sendCSEmail(
          `New Vendor Alert | ${vendor.name}`,
          `<p>Hey Team Revyse,</p> 
          <p>${user.email} created a new vendor for ${vendor.name} on Revyse via Vendor Intelligence.</p>
          <p>Now it's your turn to review it.</p> 
          <p>Click here to <a href="${env.REVYSE_UI_ORIGIN}/admin/vendors/${vendor.id}">review and approve</a>.</p>`
        );

        vendorId = vendor.id;
      } else {
        // If vendor already exists in account, return error
        const existingVendor = await tx.managerAccountVendor.findFirst({
          where: {
            vendor_id: vendorId,
            manager_account_id: data.manager_account_id,
          },
        });

        if (existingVendor) {
          throw new Error("Vendor already exists in account");
        }
      }

      // Associate the vendor with the account
      return await tx.managerAccountVendor.create({
        data: {
          manager_account_id: data.manager_account_id,
          vendor_id: vendorId,
        },
      });
    });
  }

  getVendorOptions(
    managerAccountId: string,
    user?: PermissionUser,
    options: { locationId?: string } = {}
  ) {
    const whereAnd: Prisma.VendorWhereInput[] = [
      {
        manager_account_vendors: {
          some: {
            manager_account_id: managerAccountId,
          },
        },
      },
    ];

    if (
      user &&
      !canDoOnAccount(
        user,
        { id: managerAccountId },
        Permission.ViewSensitiveContracts
      )
    ) {
      whereAnd.push({
        manager_account_vendors: {
          some: {
            manager_account_id: managerAccountId,
            OR: [
              {
                contracts: {
                  none: {},
                },
              },
              {
                NOT: {
                  contracts: {
                    every: {
                      is_sensitive: true,
                    },
                  },
                },
              },
            ],
          },
        },
      });
    }

    return this.db.vendor.findMany({
      select: {
        id: true,
        name: true,
        description: true,
        logo_file_id: true,
      },
      where: {
        OR: [
          {
            state: {
              in: [
                VendorState.ApprovedForPublishing,
                VendorState.RevyseIntelligenceOnly,
              ],
            },
          },
          {
            AND: whereAnd,
          },
        ],
        AND: [
          ...(options.locationId
            ? [
                {
                  manager_account_vendors: {
                    some: {
                      manager_account_id: managerAccountId,
                      contracts: {
                        some: {
                          contract_line_items: {
                            some: {
                              contract_line_item_locations: {
                                some: {
                                  location_id: options.locationId,
                                },
                              },
                            },
                          },
                        },
                      },
                    },
                  },
                },
              ]
            : []),
        ],
      },
    });
  }

  async deleteVendorDocument(id: string) {
    try {
      await this.db.$transaction(async tx => {
        const document = await tx.managerAccountVendorDocument.findFirstOrThrow(
          {
            where: {
              id,
            },
            include: {
              file: true,
            },
          }
        );

        const file = document.file;

        if (file) {
          await this.s3Service.deleteObject(file.uri);
        }

        await tx.managerAccountVendorDocument.delete({
          where: {
            id,
          },
        });

        await tx.file.delete({
          where: {
            id: file?.id,
          },
        });
      });
      return {
        success: true,
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message,
      };
    }
  }

  async handleVendorDocument({
    id,
    name,
    type,
    file,
    managerAccountVendorId,
  }: {
    id: string;
    name: string | null;
    type: string | null;
    file: string | null;
    managerAccountVendorId: string;
  }) {
    let vendorDocument = null;
    if (id.includes("new_")) {
      vendorDocument = await this.db.managerAccountVendorDocument.create({
        data: {
          manager_account_vendor_id: managerAccountVendorId,
          name: !isEmpty(name) ? name : undefined,
          type: !isEmpty(type)
            ? (type as ManagerAccountVendorDocumentType)
            : undefined,
          file_id: !isEmpty(file) ? file : undefined,
        },
      });
    } else {
      vendorDocument = await this.db.managerAccountVendorDocument.update({
        where: {
          id,
        },
        data: {
          name: !isEmpty(name) ? name : undefined,
          type: !isEmpty(type)
            ? (type as ManagerAccountVendorDocumentType)
            : undefined,
          file_id: !isEmpty(file) ? file : undefined,
        },
      });
    }
    return vendorDocument;
  }
  async updateManagerAccountVendor(
    id: string,
    data: Prisma.ManagerAccountVendorUpdateInput
  ) {
    return this.db.managerAccountVendor.update({
      where: { id },
      data,
    });
  }

  async deleteManagerAccountVendor(id: string) {
    const managerAccountVendor = await this.getManagerAccountVendor(id, {
      _count: {
        select: {
          contracts: true,
        },
      },
    });

    if (managerAccountVendor._count.contracts > 0) {
      throw new Error("Vendor has contracts");
    }

    return await this.db.managerAccountVendor.delete({
      where: {
        id,
      },
    });
  }

  async createManagerAccountVendors(
    managerAccountId: string,
    data: {
      vendor_id: string;
      new_vendor_name: string | null;
      new_vendor_description?: string | null;
    }[],
    user: { email: string }
  ) {
    const vendors = await Promise.all(
      data.map(async d => {
        try {
          return await this.createManagerAccountVendor(
            {
              manager_account_id: managerAccountId,
              ...d,
            },
            user
          );
        } catch (error) {
          if (error instanceof Error) {
            console.error(error.message);
          }
          return null;
        }
      })
    );

    return vendors.filter(Boolean);
  }

  async searchVendorNameMatches(vendorName: string, managerAccountId: string) {
    type QueryResult = (Vendor & { vendor_associated: boolean })[];

    const vendors = await this.db.$queryRaw<QueryResult>`
      SELECT 
        vendor.*,
        CASE WHEN manager_account_vendor.id IS NOT NULL THEN TRUE ELSE FALSE END AS vendor_associated 
      FROM 
        vendor
        LEFT JOIN manager_account_vendor 
          ON vendor.id = manager_account_vendor.vendor_id 
          AND manager_account_vendor.manager_account_id = ${managerAccountId}::uuid
      WHERE 
        (
          plainto_tsquery(${vendorName}::text) @@ to_tsvector(vendor.name)
          OR
          plainto_tsquery(vendor.name) @@ to_tsvector(${vendorName}::text)
          OR
          plainto_tsquery(REPLACE(${vendorName}::text, ' ', '')) @@ to_tsvector(vendor.name)
          OR
          plainto_tsquery(REPLACE(vendor.name, ' ', '')) @@ to_tsvector(${vendorName}::text)
        )
      AND
        (
          vendor.state IN (${VendorState.ApprovedForPublishing}::vendor_state, ${VendorState.RevyseIntelligenceOnly}::vendor_state)
          OR
          manager_account_vendor.id IS NOT NULL
        )
    `;

    return vendors;
  }

  async createGeneralLedgerImport(data: Prisma.GeneralLedgerImportCreateInput) {
    return this.db.generalLedgerImport.create({ data });
  }
}
