import { ProductState, VendorState } from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { slugify } from "../utils/string.utils";
import { faker } from "@faker-js/faker";
import { withTx } from "./db.server";

const generateCategory = (name: string) => ({
  name,
  description: "description",
  faq_1: "faq 1",
  faq_2: "faq 2",
  faq_3: "faq 3",
  faq_1_answer: "faq 1 answer",
  faq_2_answer: "faq 2 answer",
  faq_3_answer: "faq 3 answer",
  meta_description: "meta description",
  page_title: "page title",
});

const CATS = [
  generateCategory("ABC"),
  generateCategory("BCD"),
  generateCategory("EFG"),
];

const generateProduct = (title: string) => ({
  title,
  description: "description",
  state: ProductState.discovery,
  approved_at: new Date(),
  page_title: "page title",
  positioning: "positioning",
  meta_description: "meta description",
});

const PRODUCTS = [
  generateProduct("ABC"),
  generateProduct("BCD"),
  generateProduct("EFG"),
];

const generateVendor = (name: string) => ({
  name,
  website: faker.internet.url(),
  state: VendorState.ApprovedForPublishing,
  hq_location: faker.location.city(),
  founded_year: faker.date.past().getFullYear().toString(),
  number_employees: faker.number.int({ min: 1, max: 1000 }).toString(),
  linkedin_profile_url: faker.internet.url(),
});

const VENDORS = [generateVendor("ABC"), generateVendor("XYZ")];

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { db } = TestDIContainer(tx);

    const vendors = await Promise.all(
      VENDORS.map(v =>
        db.vendor.create({
          data: { ...v, slug: slugify(v.name) },
        })
      )
    );
    const categories = await Promise.all(
      CATS.map(c =>
        db.productCategory.create({
          data: { ...c, highlighted: false, slug: slugify(c.name) },
          include: {
            primary_products: true,
          },
        })
      )
    );
    const products = await Promise.all(
      PRODUCTS.map(p =>
        db.product.create({
          data: {
            ...p,
            slug: slugify(p.title),
            primary_category: {
              connect: {
                id: categories[0].id,
              },
            },
            vendor: {
              connect: {
                id: vendors[0].id,
              },
            },
          },
        })
      )
    );

    return {
      vendors,
      categories,
      products,
    };
  },
});

describe("AutocompleteSearchBar Service", () => {
  describe("getProductsBySearchTerm", () => {
    test(
      "should return products that title contains the search term",
      withFixtures(async ({ products }, tx) => {
        const { autocompleteSearchBarService } = TestDIContainer(tx);
        const testProducts =
          await autocompleteSearchBarService.getProductsBySearchTerm("B");
        expect(testProducts).not.toBeNull();
        expect(testProducts).toHaveLength(2);
        expect(testProducts.map(product => product.id)).toEqual(
          expect.arrayContaining([products[0].id])
        );
        expect(testProducts.map(product => product.id)).toEqual(
          expect.arrayContaining([products[1].id])
        );
      })
    );
    test(
      "should return null when provided search term isn't contained in any product title",
      withTx(async tx => {
        const { autocompleteSearchBarService } = TestDIContainer(tx);
        const testProducts =
          await autocompleteSearchBarService.getProductsBySearchTerm("XYZ");
        expect(testProducts).toHaveLength(0);
      })
    );
  });

  describe("getVendorsBySearchTerm", () => {
    test(
      "should return vendors that name contains the search term",
      withFixtures(async ({ vendors }, tx) => {
        const { autocompleteSearchBarService } = TestDIContainer(tx);
        const testVendors =
          await autocompleteSearchBarService.getVendorsBySearchTerm("ABC");
        expect(testVendors).not.toBeNull();
        expect(testVendors).toHaveLength(1);
        expect(testVendors.map(vendor => vendor.id)).toEqual(
          expect.arrayContaining([vendors[0].id])
        );
      })
    );
    test(
      "should return null when provided search term isn't contained in any vendor name",
      withTx(async tx => {
        const { autocompleteSearchBarService } = TestDIContainer(tx);
        const testProducts =
          await autocompleteSearchBarService.getProductsBySearchTerm("EFG");
        expect(testProducts).toHaveLength(0);
      })
    );
  });

  describe("getCategoriesBySearchTerm", () => {
    test(
      "should return categories that name contains the search term",
      withFixtures(async ({ categories }, tx) => {
        const { autocompleteSearchBarService } = TestDIContainer(tx);
        const testCategories =
          await autocompleteSearchBarService.getCategoriesBySearchTerm("ABC");
        expect(testCategories).not.toBeNull();
        expect(testCategories).toHaveLength(1);
        expect(testCategories.map(category => category.id)).toEqual(
          expect.arrayContaining([categories[0].id])
        );
      })
    );
    test(
      "should return null when provided search term isn't contained in any category name",
      withTx(async tx => {
        const { autocompleteSearchBarService } = TestDIContainer(tx);
        const testCategories =
          await autocompleteSearchBarService.getCategoriesBySearchTerm("XYZ");
        expect(testCategories).toHaveLength(0);
      })
    );
  });
});
