import type { Product, ProductReview, Vendor } from "@prisma/client";
import type { IMailService } from "./mail.service.server";
import type { ITemplateService } from "./template.service.server";

export type INotificationService = {
  sendBuyerVerifiedEmail(toEmail: string): Promise<void>;
  sendReviewApprovedEmail(
    toEmail: string[],
    review: ProductReview & {
      product: Product & { vendor: Vendor | null };
    }
  ): Promise<void>;
  sendReviewRespondedEmail(
    toEmail: string,
    review: ProductReview
  ): Promise<void>;
};

export class NotificationService implements INotificationService {
  constructor(
    private mailService: IMailService,
    private templateService: ITemplateService
  ) {}
  sendBuyerVerifiedEmail(toEmail: string): Promise<void> {
    console.log("Sending buyer verified email to", toEmail);
    return this.mailService.send({
      to: [toEmail],
      subject: "Get ready to evaluate proptech products like a pro! | Revyse",
      body: this.templateService.renderBuyerVerifiedEmail({}),
    });
  }

  sendReviewApprovedEmail(
    toEmail: string[],
    review: ProductReview & {
      product: Product & { vendor: Vendor | null };
    }
  ) {
    console.log("Sending review approved email to ", toEmail);
    return this.mailService.send({
      to: toEmail,
      subject: `New review for ${review.product.title} ⭐️ | Revyse`,
      body: this.templateService.renderReviewApprovedEmail({ review }),
    });
  }

  sendReviewRespondedEmail(
    toEmail: string,
    review: ProductReview & { product: Product & { vendor: Vendor | null } }
  ) {
    console.log("Sending review responded email to ", toEmail);
    return this.mailService.send({
      to: [toEmail],
      subject: `${
        review.product.vendor!.name
      } has responded to your review ⭐️ | Revyse`,
      body: this.templateService.renderReviewRespondedEmail({ review }),
    });
  }
}
