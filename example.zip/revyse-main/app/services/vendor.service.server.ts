import type { PrismaClient, VendorValueTags } from "@prisma/client";
import {
  Prisma,
  ProductState,
  SubscriptionStatus,
  VendorState,
} from "@prisma/client";
import { isEmpty } from "lodash";
import type { PRODUCT_PERKS_KEYS } from "~/utils/constants.utils";
import type { PermissionUser } from "../utils/intelligence-permission.utils";
import {
  canDoOnAccount,
  Permission,
} from "../utils/intelligence-permission.utils";
import { ProductSubscriptionActiveStatuses } from "../utils/product-subscription.utils.server";

export class VendorService {
  constructor(private db: PrismaClient) {}

  async getVendorForDiscovery({ slug }: { slug: string }) {
    const vendor = await this.db.vendor.findFirstOrThrow({
      where: { slug: slug, state: VendorState.ApprovedForPublishing },
      include: {
        products: {
          include: {
            subscriptions: {
              include: {
                stripe_price: {
                  include: {
                    product: true,
                  },
                },
              },
            },
          },
        },
        vendor_integrations: {
          include: {
            integrated_vendor: true,
            integrated_product: true,
          },
          orderBy: [
            {
              integrated_vendor: {
                name: "asc",
              },
            },
            {
              integrated_product: {
                title: "asc",
              },
            },
          ],
          take: 60,
          distinct: ["integrated_product_id", "integrated_vendor_id"],
        },
      },
    });

    return vendor;
  }

  async getVendor(id: string) {
    const vendor = await this.db.vendor.findFirstOrThrow({
      where: { id },
      include: {
        products: {
          where: {
            state: ProductState.discovery,
          },
        },
        manager_account_vendors: true,
      },
    });

    return vendor;
  }

  async getVendorWithIntegrations(id: string) {
    const vendor = await this.db.vendor.findFirstOrThrow({
      where: { id },
      include: {
        vendor_integrations: {
          include: {
            integrated_vendor: true,
            integrated_product: true,
          },
        },
        logo_file: true,
      },
    });

    return vendor;
  }

  async getVendors({
    filters,
    orderBy,
    take,
    skip,
  }: {
    filters: Prisma.VendorWhereInput;
    orderBy?: Prisma.VendorFindManyArgs["orderBy"];
    take?: number;
    skip?: number;
  }) {
    const vendors = await this.db.vendor.findMany({
      where: filters,
      include: {
        products: {
          include: {
            _count: {
              select: {
                brand_video_files: true,
                demo_files: true,
                packages: true,
              },
            },
          },
        },
      },
      orderBy: orderBy ?? {
        name: "asc",
      },
      take,
      skip,
    });

    return vendors;
  }

  async getVendorsCount({ filters }: { filters: Prisma.VendorWhereInput }) {
    const count = await this.db.vendor.count({
      where: filters,
    });

    return count;
  }

  async getVendorsIdAndName({
    filters,
    user,
    account,
  }: {
    filters?: Prisma.VendorWhereInput;
    user?: PermissionUser;
    account?: { id: string } | null;
  } = {}) {
    const where = filters ?? {};

    if (
      user &&
      account &&
      !canDoOnAccount(user, account, Permission.ViewSensitiveContracts)
    ) {
      where.AND = {
        manager_account_vendors: {
          some: {
            manager_account_id: account.id,
            OR: [
              {
                contracts: {
                  none: {},
                },
              },
              {
                NOT: {
                  contracts: {
                    every: {
                      is_sensitive: true,
                    },
                  },
                },
              },
            ],
          },
        },
      };
    }

    const vendors = await this.db.vendor.findMany({
      where,
      select: {
        id: true,
        name: true,
      },
      orderBy: {
        name: "asc",
      },
    });

    return vendors;
  }

  async getVendorsForAllVendorsPage({
    valueTags,
    productPerks,
  }: {
    valueTags?: VendorValueTags[];
    productPerks?: (keyof typeof PRODUCT_PERKS_KEYS)[];
  }) {
    const where: Prisma.VendorWhereInput = {
      state: VendorState.ApprovedForPublishing,
    };

    if (!isEmpty(valueTags)) {
      where.value_tags = {
        hasEvery: valueTags,
      };
    }

    if (productPerks && !isEmpty(productPerks)) {
      where.products = {
        some: {
          AND: [
            {
              state: ProductState.discovery,
            },
          ],
        },
      };

      const subscriptionActiveWhere: Prisma.ProductSubscriptionListRelationFilter =
        {
          some: {
            status: {
              in: ProductSubscriptionActiveStatuses,
            },
          },
        };

      if (productPerks.includes("promos")) {
        (where.products.some?.AND as Prisma.ProductWhereInput[]).push({
          AND: [
            {
              promo_text: {
                not: null,
              },
            },
            {
              promo_text: {
                not: "",
              },
            },
            {
              subscriptions: subscriptionActiveWhere,
            },
          ],
        });
      }

      if (productPerks.includes("demos")) {
        (where.products.some?.AND as Prisma.ProductWhereInput[]).push({
          AND: [
            {
              demo_storylane_url: {
                not: null,
              },
            },
            {
              demo_storylane_url: {
                not: "",
              },
            },
            {
              subscriptions: subscriptionActiveWhere,
            },
          ],
        });
      }

      if (productPerks.includes("pricing")) {
        (where.products.some?.AND as Prisma.ProductWhereInput[]).push({
          packages: {
            some: {},
          },
          subscriptions: subscriptionActiveWhere,
        });
      }

      if (productPerks.includes("videos")) {
        (where.products.some?.AND as Prisma.ProductWhereInput[]).push({
          OR: [
            {
              brand_video_files: {
                some: {},
              },
              subscriptions: subscriptionActiveWhere,
            },
            {
              AND: [
                {
                  brand_video_urls: {
                    not: Prisma.AnyNull,
                  },
                },
                {
                  brand_video_urls: {
                    not: [],
                  },
                },
                {
                  subscriptions: subscriptionActiveWhere,
                },
              ],
            },
          ],
        });
      }
    }

    const vendors = await this.db.vendor.findMany({
      where,
      select: {
        id: true,
        name: true,
        slug: true,
      },
      orderBy: {
        name: "asc",
      },
    });
    return vendors;
  }

  async getVendorProductWithSpecialOffer({ vendorId }: { vendorId: string }) {
    const productsWithSpecialOffer = await this.db.product.findMany({
      where: {
        AND: [
          {
            promo_text: {
              not: null,
            },
          },
          {
            promo_text: {
              not: "",
            },
          },
        ],
        vendor_id: vendorId,
        approved_at: { not: null },
        state: ProductState.discovery,
        vendor: { state: VendorState.ApprovedForPublishing },
      },
      include: {
        vendor: true,
        banner_file: true,
        _count: {
          select: {
            reviews: true,
          },
        },
      },
    });

    const product = productsWithSpecialOffer.reduce(
      (prev: any, current) =>
        prev._count.reviews > current._count.reviews ? prev : current,
      productsWithSpecialOffer[0]
    );
    const activeSubscription = product
      ? await this.db.productSubscription.findFirst({
          where: {
            product_id: product?.id,
            status: {
              notIn: [
                SubscriptionStatus.canceled,
                SubscriptionStatus.incomplete_expired,
              ],
            },
          },
          orderBy: { created_at: "desc" },
          include: { stripe_price: { include: { product: true } } },
        })
      : null;

    return {
      product,
      activeSubscription,
    };
  }

  async createVendor(data: Prisma.VendorCreateInput) {
    const vendor = await this.db.vendor.create({
      data,
    });

    return vendor;
  }

  async updateVendor(id: string, data: Prisma.VendorUpdateInput) {
    const vendor = await this.db.vendor.update({
      where: { id },
      data,
    });

    return vendor;
  }

  async deleteVendor(id: string) {
    await this.db.vendor.delete({
      where: { id },
    });
  }

  getVendorIntegrationVendorOptions(where: Prisma.VendorWhereInput) {
    return this.db.vendor.findMany({
      where,
      select: {
        id: true,
        name: true,
        logo_file_id: true,
      },
      orderBy: {
        name: "asc",
      },
    });
  }

  getVendorIntegrationProductOptions(where: Prisma.ProductWhereInput) {
    return this.db.product.findMany({
      where,
      select: {
        id: true,
        title: true,
        logo_file_id: true,
      },
      orderBy: {
        title: "asc",
      },
    });
  }
}
