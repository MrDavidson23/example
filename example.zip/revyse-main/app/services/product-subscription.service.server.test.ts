import { faker } from "@faker-js/faker";
import {
  Prisma,
  ProductState,
  Role,
  StripePriceCadence,
  SubscriptionStatus,
  Tier,
  UserRoleType,
  VendorState,
} from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { slugify } from "../utils/string.utils";
import { withFixtureFactory } from "../utils/test.utils.server";
import type Stripe from "stripe";
import { createTestUser } from "./seeds/createTestUser";
import type { RoleJson } from "./product-subscription.service.server";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const categoryName =
      faker.commerce.department() +
      " " +
      faker.number.int({ min: 1, max: 1000 });
    const category = await tx.productCategory.create({
      data: {
        name: categoryName,
        description: faker.commerce.productDescription(),
        slug: slugify(categoryName),
        faq_1: "faq 1",
        faq_2: "faq 2",
        faq_3: "faq 3",
        faq_1_answer: "faq 1",
        faq_2_answer: "faq 2",
        faq_3_answer: "faq 3",
        page_title: categoryName,
        meta_description: categoryName,
      },
    });
    const vendorName = faker.company.name();
    const vendor = await tx.vendor.create({
      data: {
        slug: slugify(vendorName),
        name: vendorName,
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
        hq_location: faker.location.city(),
        founded_year: faker.date.past().getFullYear().toString(),
        number_employees: faker.number.int({ min: 1, max: 1000 }).toString(),
        linkedin_profile_url: faker.internet.url(),
      },
    });

    const productName = `${faker.commerce.productName()} ${faker.string.uuid()}`;
    const product = await tx.product.create({
      data: {
        title: productName,
        slug: slugify(productName),
        description: faker.commerce.productDescription(),
        positioning: "",
        approved_at: new Date(),
        primary_category: { connect: { id: category.id } },
        vendor: { connect: { id: vendor.id } },
        page_title: productName,
        meta_description: productName,
        state: ProductState.discovery,
      },
      include: {
        features: true,
        packages: true,
      },
    });

    const stripeProduct = await tx.stripeProduct.create({
      data: {
        id: `prod_${faker.string.uuid()}`,
        name: "product",
        active: true,
        tier: Tier.tier_3,
        description: "product",
      },
    });

    const stripePrice = await tx.stripePrice.create({
      data: {
        id: `price_${faker.string.uuid()}`,
        product: { connect: { id: stripeProduct.id } },
        active: true,
        cadence: "monthly",
        price: 1000,
      },
    });

    const productSubscription = await tx.productSubscription.create({
      data: {
        stripe_id: `sub_${faker.string.uuid()}`,
        status: SubscriptionStatus.active,
        product: { connect: { id: product.id } },
        stripe_price: { connect: { id: stripePrice.id } },
      },
    });

    const invitedEmail = faker.internet.email();
    const invitation = await tx.userInvitation.create({
      data: {
        email: invitedEmail,
        role: {
          role: Role.ADMIN,
          resource_id: productSubscription.id,
        },
      },
    });

    const ownerUser = await tx.user.create({
      data: {
        email: faker.internet.email(),
        first_name: "first",
        last_name: "last",
        company_name: "company",
        phone: "phone",
        title: "title",
        user_roles: {
          create: {
            type: UserRoleType.PRODUCT_SUBSCRIPTION,
            role: Role.OWNER,
            resource_id: productSubscription.id,
          },
        },
      },
    });

    const adminUser = await tx.user.create({
      data: {
        email: faker.internet.email(),
        first_name: "first",
        last_name: "last",
        company_name: "company",
        phone: "phone",
        title: "title",
        user_roles: {
          create: {
            type: UserRoleType.PRODUCT_SUBSCRIPTION,
            role: Role.ADMIN,
            resource_id: productSubscription.id,
          },
        },
      },
      include: {
        user_roles: true,
      },
    });
    return {
      product,
      productSubscription,
      ownerUser,
      adminUser,
      invitation,
      invitedEmail,
      stripeProduct,
    };
  },
});

describe("ProductSubscriptionService", () => {
  it.skip("createProductAndSubscription", async () => {}); // This test is skipped because it uses stripe and mails (third party services)

  describe("getProductActiveSubscription", () => {
    test(
      "should return product active subscription by product id",
      withFixtures(async ({ product, productSubscription }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        const activeSubscription =
          await productSubscriptionService.getProductActiveSubscription(
            product.id
          );
        expect(activeSubscription).not.toBeNull();
        expect(activeSubscription?.id).toBe(productSubscription.id);
      })
    );
  });

  describe("getResourceUserRole", () => {
    test(
      "should return the user role by user id and resource id",
      withFixtures(async ({ productSubscription, ownerUser }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        const userRole = await productSubscriptionService.getResourceUserRole({
          filters: {
            user_id: ownerUser.id,
            resource_id: productSubscription.id,
          },
        });
        expect(userRole).not.toBeNull();
        expect(userRole?.product_subscription?.id).toBe(productSubscription.id);
      })
    );
  });

  describe("getSubscriptionsForUser", () => {
    test(
      "should return the product subscriptions that an user have",
      withFixtures(async ({ ownerUser }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        const userSubscriptions =
          await productSubscriptionService.getSubscriptionsForUser({
            id: ownerUser.id,
          });

        expect(userSubscriptions).not.toBeNull();
        expect(userSubscriptions).toHaveLength(1);
      })
    );
  });

  describe("getSubscriptionUserCount", () => {
    test(
      "should return the count of users assigned to a product subscription",
      withFixtures(async ({ productSubscription }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        const count = await productSubscriptionService.getSubscriptionUserCount(
          productSubscription
        );

        expect(count).toEqual(2);
      })
    );
  });

  describe("getSubscriptionUsers", () => {
    test(
      "should return the user roles by user id and resource id",
      withFixtures(async ({ productSubscription, ownerUser }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        const users = await productSubscriptionService.getSubscriptionUsers(
          productSubscription.id
        );

        expect(users).not.toBeNull();
        expect(users.map(user => user.user)).toEqual(
          expect.arrayContaining([ownerUser])
        );
      })
    );
  });

  describe("generateUserInviteEmail", () => {
    test(
      "should resend a user invite email if invitation exist",
      withFixtures(async ({ productSubscription, invitedEmail }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        const token = await productSubscriptionService.generateUserInviteEmail(
          invitedEmail,
          productSubscription.id
        );

        expect(token).not.toBeNull();
      })
    );

    test(
      "should return null if first invitation doesn't exist",
      withFixtures(async ({ productSubscription }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);
        await expect(
          productSubscriptionService.generateUserInviteEmail(
            faker.internet.email(),
            productSubscription.id
          )
        ).rejects.toThrow(Prisma.PrismaClientKnownRequestError);
      })
    );
  });

  describe.skip("createSubscriptionCheckoutSession", () => {
    // Not testing because it's using Stripe API in the function
  });

  describe.skip("createSubscriptionBillingPortalSession", () => {
    // Not testing because it's using Stripe API in the function
  });

  describe("getSubscriptionOwnerUsers", () => {
    test(
      "should return the subscription owner users",
      withFixtures(async ({ productSubscription, ownerUser }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        const userRoles =
          await productSubscriptionService.getSubscriptionOwnerUsers(
            productSubscription.id
          );
        expect(userRoles).not.toBeNull();
        expect(userRoles).toHaveLength(1);
        expect(userRoles[0].user_id).toBe(ownerUser.id);
      })
    );
  });

  describe("handleSubscriptionRole, deleteSubscriptionRole", () => {
    test(
      "should create a subscription user role",
      withFixtures(async ({ productSubscription }, tx) => {
        const { db, productSubscriptionService } = TestDIContainer(tx);
        const fakeUserEmail = faker.internet.email();
        const response =
          await productSubscriptionService.handleSubscriptionRole(
            null,
            productSubscription.id,
            fakeUserEmail,
            Role.OWNER
          );

        const invite = await db.userInvitation.findFirst({
          where: {
            email: fakeUserEmail,
          },
        });
        expect(response.success).toBe(true);
        expect(invite).not.toBeNull();
      })
    );

    test(
      "should update the subscription user role",
      withFixtures(async ({ productSubscription, adminUser }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        await productSubscriptionService.handleSubscriptionRole(
          adminUser.user_roles[0].id,
          productSubscription.id,
          adminUser.email,
          Role.OWNER
        );

        const userRole = await productSubscriptionService.getResourceUserRole({
          filters: {
            resource_id: productSubscription.id,
            user_id: adminUser.id,
          },
        });
        expect(userRole).not.toBeNull();
        expect(userRole?.role).toBe(Role.OWNER);
      })
    );

    test(
      "should delete the subscription user role",
      withFixtures(async ({ adminUser, productSubscription }, tx) => {
        const { db, productSubscriptionService } = TestDIContainer(tx);

        await productSubscriptionService.deleteSubscriptionRole(
          adminUser.user_roles[0].id
        );

        const userRole = await db.userRole.findFirst({
          where: {
            user_id: adminUser.id,
            resource_id: productSubscription.id,
          },
        });
        expect(userRole).toBeNull();
      })
    );
  });

  describe("updateSubscription", () => {
    it(
      "update subscription status to canceled",
      withFixtures(async ({ productSubscription }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        const subscription = {
          id: productSubscription.stripe_id,
          status: SubscriptionStatus.canceled,
        } as Stripe.Subscription;

        // Update status to canceled
        await productSubscriptionService.updateSubscription(subscription, true);

        const updatedProductSubscription =
          await tx.productSubscription.findUnique({
            where: { id: productSubscription.id },
          });

        expect(updatedProductSubscription?.status).toBe(
          SubscriptionStatus.canceled
        );
      })
    );

    it(
      "updateSubscription status to active and new stripe price",
      withFixtures(async ({ productSubscription }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        const stripeProduct = await tx.stripeProduct.create({
          data: {
            id: `prod_${faker.string.uuid()}`,
            name: "product",
            active: true,
            tier: Tier.tier_3,
            description: "product",
          },
        });

        const stripePrice = await tx.stripePrice.create({
          data: {
            id: `price_${faker.string.uuid()}`,
            product: { connect: { id: stripeProduct.id } },
            active: true,
            cadence: StripePriceCadence.yearly,
            price: 2000,
          },
        });

        const subscription = {
          id: productSubscription.stripe_id,
          status: SubscriptionStatus.active,
          plan: { id: stripePrice.id },
        } as Stripe.Subscription & { plan: { id: string } };

        await productSubscriptionService.updateSubscription(subscription, true);

        const updatedProductSubscription =
          await tx.productSubscription.findUnique({
            where: { id: productSubscription.id },
          });

        expect(updatedProductSubscription?.status).toBe(
          SubscriptionStatus.active
        );
        expect(updatedProductSubscription?.stripe_price_id).toBe(
          stripePrice.id
        );
      })
    );
  });

  describe("acceptSubscriptionInvite", () => {
    test(
      "should accept a user invitation",
      withFixtures(async ({ invitation, invitedEmail }, tx) => {
        const { productSubscriptionService, authService } = TestDIContainer(tx);
        const user = await createTestUser(invitedEmail, authService);

        const invite =
          await productSubscriptionService.acceptSubscriptionInvite(
            invitation.role as RoleJson,
            user,
            invitation.id
          );

        expect(invite.accepted_at).not.toBeNull();
        expect(invite.accepted_by_id).toEqual(user.id);
      })
    );
  });

  describe("getUserInvitationByToken", () => {
    test(
      "should get user invitation by id",
      withFixtures(async ({ invitation }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        const invite =
          await productSubscriptionService.getUserInvitationByToken(
            invitation.id
          );
        expect(invite).not.toBeNull();
      })
    );
  });

  describe("cancelSubscriptionInvite", () => {
    test(
      "should cancel product subscription user invitation",
      withFixtures(async ({ invitation }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        await productSubscriptionService.cancelSubscriptionInvite(
          invitation.id
        );
        const invite = await tx.userInvitation.findFirst({
          where: {
            id: invitation.id,
          },
        });

        expect(invite).toBeNull();
      })
    );
  });

  describe("getSubscriptionCountByPlan", () => {
    test(
      "should return subscription count by plan",
      withFixtures(async ({ stripeProduct }, tx) => {
        const { productSubscriptionService } = TestDIContainer(tx);

        const subscriptionCountByPlan =
          await productSubscriptionService.getSubscriptionCountByPlan();

        expect(subscriptionCountByPlan).not.toBeNull();
        expect(subscriptionCountByPlan.length).toBeGreaterThan(0);
        expect(subscriptionCountByPlan).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              name: stripeProduct.name,
              cnt: 1,
            }),
          ])
        );
      })
    );
  });
});
