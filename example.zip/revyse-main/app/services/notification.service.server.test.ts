import { faker } from "@faker-js/faker";
import { ProductState, VendorState } from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { slugify } from "../utils/string.utils";
import { withFixtureFactory } from "../utils/test.utils.server";
import { createTestUser } from "./seeds/createTestUser";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { authService } = TestDIContainer();

    const user = await createTestUser(faker.internet.email(), authService);

    const vendorName = faker.company.name();
    const vendor = await tx.vendor.create({
      data: {
        slug: slugify(vendorName),
        name: vendorName,
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
        hq_location: faker.location.city(),
        founded_year: faker.date.past().getFullYear().toString(),
        number_employees: faker.number.int({ min: 1, max: 1000 }).toString(),
        linkedin_profile_url: faker.internet.url(),
      },
    });

    const category = await tx.productCategory.create({
      data: {
        name: faker.company.name(),
        description: "description",
        slug: "category",
        faq_1: "faq 1",
        faq_2: "faq 2",
        faq_3: "faq 3",
        faq_1_answer: "faq 1 answer",
        faq_2_answer: "faq 2 answer",
        faq_3_answer: "faq 3 answer",
        meta_description: "meta description",
        page_title: "page title",
      },
    });
    const product = await tx.product.create({
      data: {
        title: "Test Product",
        description: "description",
        state: ProductState.discovery,
        approved_at: new Date(),
        slug: "test-product",
        page_title: "page title",
        positioning: "positioning",
        meta_description: "meta description",
        primary_category_id: category.id,
        vendor_id: vendor.id,
      },
    });

    const review = await tx.productReview.create({
      include: { product: { include: { vendor: true } } },
      data: {
        product: { connect: { id: product.id } },
        compatibility_score: faker.number.int({ min: 2, max: 5 }),
        customer_service_score: faker.number.int({ min: 2, max: 5 }),
        onboarding_score: faker.number.int({ min: 2, max: 5 }),
        value_score: faker.number.int({ min: 2, max: 5 }),
        compatibility_desc: faker.lorem.sentence(),
        customer_service_desc: faker.lorem.sentence(),
        decision_maker: faker.person.firstName(),
        dislike_most: faker.lorem.sentence(),
        like_most: faker.lorem.sentence(),
        onboarding_desc: faker.lorem.sentence(),
        primary_use_case: faker.lorem.sentence(),
        recommend_to: faker.lorem.sentence(),
        show_company: faker.datatype.boolean(),
        show_job_title: faker.datatype.boolean(),
        show_last_name: faker.datatype.boolean(),
        user: { connect: { id: user.id } },
        value_desc: faker.lorem.sentence(),
      },
    });

    return { review };
  },
});

describe("NotificationService", () => {
  describe("sendBuyerVerifiedEmail", () => {
    it("should send an email to the buyer", async () => {
      const { mailService, templateService, notificationService } =
        TestDIContainer();
      const toEmail = faker.internet.email();
      const sendSpy = jest.spyOn(mailService, "send");
      const renderSpy = jest.spyOn(templateService, "renderBuyerVerifiedEmail");

      await notificationService.sendBuyerVerifiedEmail(toEmail);

      expect(sendSpy).toHaveBeenCalledWith({
        to: [toEmail],
        subject: "Get ready to evaluate proptech products like a pro! | Revyse",
        body: renderSpy.mock.results[0].value,
      });

      sendSpy.mockRestore();
      renderSpy.mockRestore();
    });
  });

  describe("sendReviewApprovedEmail", () => {
    it(
      "should send an email to the reviewer",
      withFixtures(async ({ review }, tx) => {
        const { mailService, templateService, notificationService } =
          TestDIContainer();
        const toEmail = faker.internet.email();
        const sendSpy = jest.spyOn(mailService, "send");
        const renderSpy = jest.spyOn(
          templateService,
          "renderReviewApprovedEmail"
        );

        await notificationService.sendReviewApprovedEmail([toEmail], review);

        expect(sendSpy).toHaveBeenCalledWith({
          to: [toEmail],
          subject: `New review for ${review.product.title} ⭐️ | Revyse`,
          body: renderSpy.mock.results[0].value,
        });

        sendSpy.mockRestore();
        renderSpy.mockRestore();
      })
    );
  });

  describe("sendReviewRespondedEmail", () => {
    it(
      "should send an email to the reviewer",
      withFixtures(async ({ review }, tx) => {
        const { mailService, templateService, notificationService } =
          TestDIContainer();
        const toEmail = faker.internet.email();
        const sendSpy = jest.spyOn(mailService, "send");
        const renderSpy = jest.spyOn(
          templateService,
          "renderReviewRespondedEmail"
        );

        await notificationService.sendReviewRespondedEmail(toEmail, review);

        expect(sendSpy).toHaveBeenCalledWith({
          to: [toEmail],
          subject: `${
            review.product.vendor!.name
          } has responded to your review ⭐️ | Revyse`,
          body: renderSpy.mock.results[0].value,
        });

        sendSpy.mockRestore();
        renderSpy.mockRestore();
      })
    );
  });
});
