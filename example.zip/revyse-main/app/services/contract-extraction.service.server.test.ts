import { ContractStatus } from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { TestDIContainer } from "../di-containers/test.di-container.server";

/**
 * Don't have a good pattern for running these tests in CI yet. So leave them
 * as pending unless you are actively using them.
 */
xdescribe("ContractExtractionService", () => {
  const withFixtures = withFixtureFactory({
    setup: async tx => {
      const { db, contractExtractionService } = TestDIContainer(tx);
      const user = await db.user.create({
        data: {
          email: "",
          first_name: "",
          last_name: "",
        },
      });
      const ai_extract = await db.contractAIExtract.create({
        data: {
          contract: {
            create: {
              id: "e85cf362-0c18-4643-823a-4315f760c4bb",
              contract_owner_name: "John Doe",
              expires_at: new Date(),
              name: "Mark Taylor MSA",
              status: ContractStatus.Active,
              term_length_months: 12,
              manager_account_vendor: {
                create: {
                  vendor: {
                    create: {
                      name: "ResMan, LLC",
                    },
                  },
                  manager_account: {
                    create: {
                      name: "Mark Taylor",
                    },
                  },
                },
              },
            },
          },
          initiated_by: {
            connect: {
              id: user.id,
            },
          },
        },
      });
      return {
        contractExtractionService,
        ai_extract,
      };
    },
  });

  describe("extractContractLength", () => {
    it(
      "should find the contract length in months",
      withFixtures(async ({ contractExtractionService, ai_extract }, tx) => {
        const field = await contractExtractionService.extractContractLength(
          // This contract_id is actually in pinecone - Mark Taylor MSA
          ai_extract.contract_id,
          ai_extract.id
        );
        console.log(field);
        expect(field.field_value).toBe("12 months");
      }),
      10000
    );
  });

  describe("extractEffectiveDate", () => {
    it(
      "should find the effective date",
      withFixtures(async ({ contractExtractionService, ai_extract }, tx) => {
        const field = await contractExtractionService.extractEffectiveDate(
          // This contract_id is actually in pinecone - Mark Taylor MSA
          ai_extract.contract_id,
          ai_extract.id
        );
        console.log(field);
        expect(field.field_value).toBe("2016-07-26");
      }),
      10000
    );
  });

  describe("extractCustomerSigner", () => {
    it(
      "should find the customer who signed the document",
      withFixtures(async ({ contractExtractionService, ai_extract }, tx) => {
        const field = await contractExtractionService.extractCustomerSigner(
          ai_extract.contract_id,
          ai_extract.id
        );
        console.log(field);
        expect(field.field_value).toBe("John Carlson");
      }),
      10000
    );
  });

  describe("extractIsMSA", () => {
    it(
      "be able to tell if the contract is an MSA",
      withFixtures(async ({ contractExtractionService, ai_extract }, tx) => {
        const field = await contractExtractionService.extractIsMSA(
          ai_extract.contract_id,
          ai_extract.id
        );
        console.log(field);
        expect(field.field_value).toBe("Yes");
      }),
      10000
    );
  });

  describe("extractIsMonthToMonth", () => {
    it(
      "be able to tell if the is month-to-month",
      withFixtures(async ({ contractExtractionService, ai_extract }, tx) => {
        const field = await contractExtractionService.extractIsMonthToMonth(
          ai_extract.contract_id,
          ai_extract.id
        );
        console.log(field);
        expect(field.field_value).toBe("No");
      }),
      10000
    );
  });

  describe("extractIsAutoRenewing", () => {
    it(
      "be able to tell if the auto renews",
      withFixtures(async ({ contractExtractionService, ai_extract }, tx) => {
        const field = await contractExtractionService.extractIsAutoRenewing(
          ai_extract.contract_id,
          ai_extract.id
        );
        console.log(field);
        expect(field.field_value).toBe("Yes");
      }),
      10000
    );
  });

  describe("extractVendor", () => {
    it(
      "be able to tell who the vendor is",
      withFixtures(async ({ contractExtractionService, ai_extract }, tx) => {
        const field = await contractExtractionService.extractVendor(
          ai_extract.contract_id,
          ai_extract.id
        );
        console.log(field);
        expect(field.field_value).toBe("ResMan, LLC");
      }),
      10000
    );
  });
});
