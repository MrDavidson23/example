import { type Prisma, type PrismaClient } from "@prisma/client";

export class FeeService {
  constructor(private db: PrismaClient) {}

  async getFees(filters: Prisma.FeeWhereInput) {
    return await this.db.fee.findMany({
      where: filters,
      orderBy: {
        name: "desc",
      },
      include: {
        vendor: true,
        category: true,
      },
    });
  }

  async createFee(
    name: string,
    categoryId: string,
    vendorId: string,
    managerAccountId: string
  ) {
    return await this.db.fee.create({
      data: {
        name,
        category_id: categoryId,
        vendor_id: vendorId,
        manager_account_id: managerAccountId,
      },
    });
  }

  async updateFee(id: string, name: string, categoryId: string) {
    return await this.db.fee.update({
      where: {
        id,
      },
      data: {
        name,
        category_id: categoryId,
      },
    });
  }

  async deleteFee(id: string) {
    const fee = await this.db.fee.findFirst({
      where: {
        id,
      },
    });
    const isRelatedToContractLineItemFee =
      await this.db.contractLineItemFee.findFirst({
        where: {
          id,
        },
      });
    if (isRelatedToContractLineItemFee) {
      return {
        success: false,
        error:
          "Cannot delete fee. To delete this fee, first remove it from all active line items.",
        fee: fee,
      };
    }
    await this.db.fee.delete({
      where: {
        id,
      },
    });

    return {
      success: true,
      fee: fee,
      error: undefined,
    };
  }
}
