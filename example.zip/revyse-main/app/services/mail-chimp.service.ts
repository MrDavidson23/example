import { getLogger } from "./logger.factory";
import { getEnv } from "./env.service.server";
import MailChimp from "@mailchimp/mailchimp_marketing";
import crypto from "crypto";
import { capitalize } from "../utils/string.utils";
import type { SignUpIntent } from "@prisma/client";

const logger = getLogger("MailChimp");

const API_KEY = getEnv().MAIL_CHIMP_API_KEY;
if (!API_KEY) {
  logger.warn("MailChimp API_KEY not configured");
}
const SERVER_PREFIX = "us14";
const LIST_ID = "b97f1bab18";

export type IMailChimpService = {
  addOrUpdateContact(userInfo: {
    first_name: string;
    last_name: string;
    email: string;
    sign_up_intent: SignUpIntent;
  }): Promise<void>;
};

export class MockMailChimpService implements IMailChimpService {
  async addOrUpdateContact({
    first_name,
    last_name,
    email,
    sign_up_intent,
  }: {
    first_name: string;
    last_name: string;
    email: string;
    sign_up_intent: SignUpIntent;
  }) {}
}

export class MailChimpService implements IMailChimpService {
  constructor() {
    MailChimp.setConfig({
      apiKey: API_KEY,
      server: SERVER_PREFIX,
    });
  }

  // ping(): Promise<{ health_status: string }> {
  //   return MailChimp.ping.get();
  // }

  async getLists() {
    const response = await MailChimp.lists.getAllLists();
    logger.debug("getLists response: ", response);
  }

  async addOrUpdateContact({
    first_name,
    last_name,
    email,
    sign_up_intent,
  }: {
    first_name: string;
    last_name: string;
    email: string;
    sign_up_intent: SignUpIntent;
  }) {
    if (API_KEY) {
      try {
        const subscriber_id = crypto
          .createHash("md5")
          .update(email)
          .digest("hex");

        const setListMemberResponse = await MailChimp.lists.setListMember(
          LIST_ID,
          subscriber_id,
          {
            email_address: email,
            status_if_new: "subscribed",
            merge_fields: {
              FNAME: first_name,
              LNAME: last_name,
            },
          }
        );
        logger.trace("addContact response: ", setListMemberResponse);

        if (sign_up_intent !== "ORGANIC") {
          const tags = [{ name: capitalize(sign_up_intent), status: "active" }];
          logger.info("adding tags: ", tags);
          const addTagResponse = await MailChimp.lists.updateListMemberTags(
            LIST_ID,
            subscriber_id,
            {
              tags,
            }
          );
          logger.trace("addTagResponse: ", addTagResponse);
        }
      } catch (e) {
        logger.error("addContact error", e);
      }
    }
  }
}
