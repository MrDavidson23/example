import {
  UserRoleType,
  type ManagerAccountRoleType,
  type Prisma,
  type PrismaClient,
  type User,
  type UserInvitation,
  Role,
} from "@prisma/client";
import { assertUserInput } from "../utils/assert.utils.server";
import type { TemplateService } from "./template.service.server";
import type { MailService, MockMailService } from "./mail.service.server";
import { isEmpty, sortBy } from "lodash";

export type ManagerAccountUsersFilters = {
  page: number;
  perPage: number;
  query?: string;
  status: string[];
  permissionLevel: string[];
};

type UserInvitationRoleJson = {
  role: ManagerAccountRoleType;
  manager_account_id: string;
};

export class ManagerAccountRoleService {
  constructor(
    private db: PrismaClient,
    private mailService: MailService | MockMailService,
    private templateService: TemplateService
  ) {}

  async getManagerAccount(id: string) {
    const managerAccount = this.db.managerAccount.findUnique({
      where: { id },
    });

    return managerAccount;
  }

  private getManagerAccountRolesQuery(
    manager_account_id: string,
    filters: ManagerAccountUsersFilters
  ): Prisma.ManagerAccountRoleWhereInput {
    return {
      manager_account_id: manager_account_id,
      deleted_at: null,
      OR: [
        {
          user: {
            email: {
              contains: filters.query,
              mode: "insensitive",
            },
          },
        },
        {
          user: {
            first_name: {
              contains: filters.query,
              mode: "insensitive",
            },
          },
        },
        {
          user: {
            last_name: {
              contains: filters.query,
              mode: "insensitive",
            },
          },
        },
      ],
      role: !isEmpty(filters.permissionLevel)
        ? {
            in: filters.permissionLevel as ManagerAccountRoleType[],
          }
        : {},
    };
  }

  async getManagerAccountRoles(
    manager_account_id: string,
    filters: ManagerAccountUsersFilters
  ) {
    const managerAccountRoles = this.db.managerAccountRole.findMany({
      where: this.getManagerAccountRolesQuery(manager_account_id, filters),
      include: {
        user: {
          select: {
            id: true,
            first_name: true,
            last_name: true,
            email: true,
            last_accessed_at: true,
          },
        },
      },
      orderBy: {
        user: {
          email: "asc",
        },
      },
      take: filters.perPage * filters.page,
    });

    return managerAccountRoles;
  }

  async getManagerAccountRolesCount(
    manager_account_id: string,
    filters: ManagerAccountUsersFilters
  ) {
    return this.db.managerAccountRole.count({
      where: this.getManagerAccountRolesQuery(manager_account_id, filters),
    });
  }

  private getManagerAccountRoleUserInvitationsQuery(
    manager_account_id: string,
    filters: ManagerAccountUsersFilters
  ): Prisma.UserInvitationWhereInput {
    return {
      accepted_at: null, // Not Accepted
      email: {
        contains: filters.query,
        mode: "insensitive",
      },
      AND: [
        {
          role: {
            path: ["manager_account_id"],
            equals: manager_account_id,
          },
        },
        {
          OR: filters.permissionLevel.map(role => ({
            role: {
              path: ["role"],
              equals: role,
            },
          })),
        },
      ],
    };
  }

  async getManagerAccountRoleUserInvitations(
    manager_account_id: string,
    filters: ManagerAccountUsersFilters
  ) {
    return this.db.userInvitation.findMany({
      select: {
        id: true,
        email: true,
        role: true,
      },
      where: this.getManagerAccountRoleUserInvitationsQuery(
        manager_account_id,
        filters
      ),
      orderBy: {
        email: "asc",
      },
      take: filters.perPage * filters.page,
    });
  }

  async getManagerAccountRoleUserInvitationsCount(
    manager_account_id: string,
    filters: ManagerAccountUsersFilters
  ) {
    return this.db.userInvitation.count({
      where: this.getManagerAccountRoleUserInvitationsQuery(
        manager_account_id,
        filters
      ),
    });
  }

  async getManagerAccountRolesTableData(
    manager_account_id: string,
    filters: ManagerAccountUsersFilters
  ) {
    const includeActive =
      isEmpty(filters.status) || filters.status.includes("active");
    const includePending =
      isEmpty(filters.status) || filters.status.includes("pending");

    const managerAccountRoles = includeActive
      ? await this.getManagerAccountRoles(manager_account_id, filters)
      : [];
    const pendingInvitations = includePending
      ? await this.getManagerAccountRoleUserInvitations(
          manager_account_id,
          filters
        )
      : [];

    const managerAccountRolesFormatted = managerAccountRoles.map(
      managerAccountRole => ({
        id: managerAccountRole.user_id,
        name: `${managerAccountRole.user.first_name} ${managerAccountRole.user.last_name}`,
        email: managerAccountRole.user.email,
        permissionLevel: managerAccountRole.role,
        lastAccessed: managerAccountRole.user.last_accessed_at,
        isInvitation: false,
      })
    );

    const invitationsFormatted = pendingInvitations.map(pendingInvitation => ({
      id: pendingInvitation.id,
      name: "",
      email: pendingInvitation.email,
      permissionLevel: (pendingInvitation.role as UserInvitationRoleJson).role,
      lastAccessed: null,
      isInvitation: true,
    }));

    const resultData = sortBy(
      [...managerAccountRolesFormatted, ...invitationsFormatted],
      "email"
    );

    return resultData.slice(
      filters.perPage * (filters.page - 1),
      filters.perPage * filters.page
    );
  }

  async getManagerAccountRolesTableDataCount(
    manager_account_id: string,
    filters: ManagerAccountUsersFilters
  ) {
    let count = 0;
    const includeActive =
      isEmpty(filters.status) || filters.status.includes("active");
    const includePending =
      isEmpty(filters.status) || filters.status.includes("pending");

    if (includeActive) {
      count += await this.getManagerAccountRolesCount(
        manager_account_id,
        filters
      );
    }

    if (includePending) {
      count += await this.getManagerAccountRoleUserInvitationsCount(
        manager_account_id,
        filters
      );
    }

    return count;
  }

  async getManagerAccountRole(
    params: { id: string } | { manager_account_id: string; user_id: string }
  ) {
    return this.db.managerAccountRole.findFirst({
      where: params,
      include: {
        user: {
          select: {
            first_name: true,
            last_name: true,
            email: true,
          },
        },
      },
    });
  }

  async getManagerAccountRoleUserInvitation(
    params: { id: string } | { manager_account_id: string; email: string }
  ) {
    if ("id" in params) {
      return await this.db.userInvitation.findUnique({ where: params });
    }

    return this.db.userInvitation.findFirst({
      where: {
        email: params.email,
        role: {
          path: ["manager_account_id"],
          equals: params.manager_account_id,
        },
      },
    });
  }

  async createManagerAccountRoleUserInvitation(
    {
      manager_account_id,
      email,
      role,
    }: {
      manager_account_id: string;
      email: string;
      role: ManagerAccountRoleType;
    },
    sendInvitationEmail: boolean = false
  ) {
    const invitation = await this.db.userInvitation.create({
      data: {
        email: email,
        role: {
          role,
          manager_account_id,
        },
      },
    });

    if (sendInvitationEmail) {
      await this.sendManagerAccountUserInvitationEmail(invitation);
    }

    return invitation;
  }

  async updateManagerAccountRoleRole(
    id: string,
    newRole: ManagerAccountRoleType
  ) {
    return await this.db.managerAccountRole.update({
      where: {
        id,
      },
      data: {
        role: newRole,
      },
    });
  }

  async updateUserInvitationRole(
    id: string,
    newRole: { manager_account_id: string; role: ManagerAccountRoleType }
  ) {
    return await this.db.userInvitation.update({
      where: {
        id,
      },
      data: {
        role: newRole,
      },
    });
  }

  async deleteUserInvitation(id: string) {
    const invitation = await this.db.userInvitation.delete({
      where: {
        id,
      },
    });

    return invitation;
  }

  async deleteManagerAccountRole(id: string) {
    const managerAccountRole = await this.db.managerAccountRole.update({
      where: {
        id,
      },
      data: {
        deleted_at: new Date(),
      },
    });

    return managerAccountRole;
  }

  async acceptManagerAccountUserInvitation(
    user: User,
    invitationId: string,
    role: { manager_account_id: string; role: ManagerAccountRoleType }
  ) {
    // Check if this user is already associated with this Intelligence Manager Account
    const userManagerAccountRole = await this.db.managerAccountRole.findFirst({
      where: {
        user_id: user.id,
        manager_account_id: role.manager_account_id,
      },
    });
    if (userManagerAccountRole) {
      return false;
    }

    await this.db.$transaction(async tx => {
      await tx.managerAccount.findFirstOrThrow({
        where: {
          id: role.manager_account_id,
        },
      });
      await tx.userInvitation.update({
        where: {
          id: invitationId,
        },
        data: {
          accepted_at: new Date(),
          accepted_by_id: user.id,
        },
      });

      await tx.emailVerificationToken.update({
        where: {
          email: user.email,
        },
        data: {
          verified_at: new Date(),
        },
      });

      await tx.managerAccountRole.create({
        data: {
          user_id: user.id,
          ...role,
        },
      });

      const existingBuyerRole = await tx.userRole.findFirst({
        where: {
          user_id: user.id,
          type: UserRoleType.GLOBAL,
          role: Role.BUYER,
        },
      });
      if (!existingBuyerRole) {
        await tx.userRole.create({
          data: {
            user_id: user.id,
            type: UserRoleType.GLOBAL,
            role: Role.BUYER,
          },
        });
      }
    });

    return true;
  }

  async sendManagerAccountUserInvitationEmail(userInvitation: UserInvitation) {
    const role = userInvitation.role as UserInvitationRoleJson;

    const managerAccount = await this.db.managerAccount.findFirstOrThrow({
      where: {
        id: role.manager_account_id,
      },
    });

    assertUserInput(
      managerAccount != null,
      "Error finding your account, please check if your account still exists"
    );

    const body = this.templateService.renderManagerAccountUserInvitationEmail({
      invitation: userInvitation,
      managerAccount,
      email: userInvitation.email,
      token: userInvitation.id,
    });
    await this.mailService.send({
      to: [userInvitation.email],
      subject: `You've been invited to manage ${managerAccount.name} on Revyse ⚒️`,
      body,
    });
  }

  updateAlertsAndNotifications(
    id: string,
    fields: {
      daily_notification_email?: boolean;
    }
  ) {
    return this.db.managerAccountRole.update({
      where: {
        id: id,
      },
      data: fields,
    });
  }
}
