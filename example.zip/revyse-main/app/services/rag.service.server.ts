import {
  OpenAI,
  PDFReader,
  PineconeVectorStore,
  ResponseSynthesizer,
  SimpleResponseBuilder,
  VectorIndexRetriever,
  VectorStoreIndex,
  serviceContextFromDefaults,
} from "llamaindex";
import fs from "fs";
import os from "os";
import path from "path";
import type { Readable } from "stream";
import { getLogger } from "./logger.factory";
import type { PrismaClient } from "@prisma/client";
import type { MockS3Service } from "./s3.service.server";

export const GPTModel = {
  GPT_4_TURBO: "gpt-4-0125-preview",
  GPT_35_TURBO: "gpt-3.5-turbo-0125",
  GPT_4: "gpt-4",
} as const;
export type GPTModel = (typeof GPTModel)[keyof typeof GPTModel];

export class RAGService {
  constructor(private db: PrismaClient, private s3Service: MockS3Service) {}

  logger = getLogger("RAGService");
  async addFileToIndex({
    file_id,
    contract_id,
    account_id,
  }: {
    file_id: string;
    contract_id: string;
    account_id: string;
  }) {
    const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), file_id));
    const file = await this.db.file.update({
      where: { id: file_id },
      data: {
        index_started_at: new Date(),
      },
    });

    try {
      this.logger.debug("Downloading file from S3...");
      const response = await this.s3Service.getObject(file.uri);
      const chunks: Uint8Array[] = [];

      for await (const chunk of response.Body as Readable) {
        chunks.push(chunk);
      }

      const buffer = Buffer.concat(chunks);
      const tempFilePath = path.join(tempDir, file_id);
      fs.writeFileSync(tempFilePath, buffer);
      this.logger.debug(`Wrote file to ${tempFilePath}`);

      this.logger.info("Extracting text from PDF...");
      const pdfReader = new PDFReader();
      const documents = await pdfReader.loadData(tempFilePath);
      const doc_ref_id = documents.length > 0 ? documents[0].id_ : null;
      documents.forEach(document => {
        document.metadata.file_id = file_id;
        document.metadata.contract_id = contract_id;
        document.metadata.account_id = account_id;
        document.metadata.file_name = file.title;
      });

      this.logger.debug(documents);
      this.logger.info("Getting index");
      const index = await this.getIndex();

      if (file.doc_ref_id) {
        this.logger.info("Deleting old docs from the index");
        await index.deleteRefDoc(file.doc_ref_id, true);
      }

      this.logger.info("Indexing document");
      await Promise.all(documents.map(d => index.insert(d)));
      await this.db.file.update({
        where: { id: file_id },
        data: { doc_ref_id, indexed_at: new Date() },
      });
    } catch (e) {
      this.logger.error(e);
    } finally {
      // Clean up temp directory
      this.logger.info("Removing temp directory");
      fs.rmSync(tempDir, { recursive: true });
    }
  }

  async query({
    query,
    instructions,
    filter,
    model,
  }: {
    query: string;
    instructions: string;
    filter?: { account_id?: string; contract_id?: string; file_id?: string };
    model: GPTModel;
  }) {
    const index = await this.getIndex(model);
    const queryEngine = index.asQueryEngine({
      responseSynthesizer: new ResponseSynthesizer({
        responseBuilder: new SimpleResponseBuilder(
          this.getServiceContext(model),
          ({ context, query }) => {
            console.log({ queryInResponseBuilder: query });
            return `Context information is below.
---------------------
${context}
---------------------
${instructions}
Query: ${query}
Answer:`;
          }
        ),
      }),
      retriever: new VectorIndexRetriever({ index, similarityTopK: 5 }),
      preFilters: {
        filters: filter
          ? Object.entries(filter).map(([key, value]) => {
              return { key, value, filterType: "ExactMatch" };
            })
          : [],
      },
    });
    this.logger.debug("making query to index...");
    const result = await queryEngine.query({ query });
    return result;
  }

  async removeFileFromIndex({ file_id }: { file_id: string }) {
    throw "Not implemented";
  }

  async removeContractFromIndex({ contract_id }: { contract_id: string }) {
    throw "Not implemented";
  }

  async removeAccountFromIndex({ account_id }: { account_id: string }) {
    throw "Not implemented";
  }

  private async getIndex(model: GPTModel = "gpt-3.5-turbo-0125") {
    const vectorStore = new PineconeVectorStore({
      indexName: "dev",
    });
    const index = await VectorStoreIndex.fromVectorStore(
      vectorStore,
      this.getServiceContext(model)
    );
    return index;
  }

  private getServiceContext(model: GPTModel) {
    return serviceContextFromDefaults({
      llm: new OpenAI({
        model,
      }),
    });
  }
}
