import { faker } from "@faker-js/faker";
import { ManagerAccountRoleType } from "@prisma/client";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { withFixtureFactory } from "../utils/test.utils.server";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const managerAccount = await tx.managerAccount.create({
      data: {
        name: faker.company.name(),
      },
    });

    const managerAccountRoles = await Promise.all(
      Array.from({ length: 10 }).map(() => {
        const email = faker.internet.email({ provider: "example.com" });

        return tx.managerAccountRole.create({
          data: {
            manager_account: { connect: { id: managerAccount.id } },
            role: faker.helpers.enumValue(ManagerAccountRoleType),
            user: {
              create: {
                first_name: faker.person.firstName(),
                last_name: faker.person.lastName(),
                email,
                email_verification_tokens: {
                  create: {
                    verified_at: null,
                    email,
                  },
                },
              },
            },
          },
          include: { user: true },
        });
      })
    );

    const userInvitations = await Promise.all(
      Array.from({ length: 10 }).map(() => {
        return tx.userInvitation.create({
          data: {
            email: faker.internet.email({ provider: "example.com" }),
            role: {
              role: faker.helpers.enumValue(ManagerAccountRoleType),
              manager_account_id: managerAccount.id,
            },
          },
        });
      })
    );

    return { managerAccount, managerAccountRoles, userInvitations };
  },
});

describe("ManagerAccountRoleService", () => {
  describe("getManagerAccount", () => {
    it(
      "should return a manager account",
      withFixtures(async ({ managerAccount }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result = await managerAccountRoleService.getManagerAccount(
          managerAccount.id
        );

        expect(result).toEqual(managerAccount);
      })
    );
  });

  describe("getManagerAccountRoles", () => {
    it(
      "should return manager account roles",
      withFixtures(async ({ managerAccount }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result = await managerAccountRoleService.getManagerAccountRoles(
          managerAccount.id,
          {
            page: 1,
            perPage: 5,
            query: "",
            status: [],
            permissionLevel: [],
          }
        );

        expect(result).toHaveLength(5);
        expect(result).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              manager_account_id: managerAccount.id,
            }),
          ])
        );
      })
    );

    it(
      "should return manager account roles with query",
      withFixtures(async ({ managerAccount, managerAccountRoles }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result = await managerAccountRoleService.getManagerAccountRoles(
          managerAccount.id,
          {
            page: 1,
            perPage: 10,
            query: managerAccountRoles[0].user.email,
            status: [],
            permissionLevel: [],
          }
        );

        expect(result).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              user: expect.objectContaining({
                email: managerAccountRoles[0].user.email,
              }),
            }),
          ])
        );
      })
    );
  });

  describe("getManagerAccountRolesCount", () => {
    it(
      "should return manager account roles count",
      withFixtures(async ({ managerAccount }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result =
          await managerAccountRoleService.getManagerAccountRolesCount(
            managerAccount.id,
            {
              page: 1,
              perPage: 5,
              query: "",
              status: [],
              permissionLevel: [],
            }
          );

        expect(result).toBe(10);
      })
    );
  });

  describe("getManagerAccountRoleUserInvitations", () => {
    it(
      "should return manager account role user invitations",
      withFixtures(async ({ managerAccount }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result =
          await managerAccountRoleService.getManagerAccountRoleUserInvitations(
            managerAccount.id,
            {
              page: 1,
              perPage: 5,
              query: "",
              status: [],
              permissionLevel: [],
            }
          );

        expect(result).toHaveLength(5);
        expect(result).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              role: expect.objectContaining({
                manager_account_id: managerAccount.id,
              }),
            }),
          ])
        );
      })
    );

    it(
      "should return manager account role user invitations with query",
      withFixtures(async ({ managerAccount, userInvitations }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result =
          await managerAccountRoleService.getManagerAccountRoleUserInvitations(
            managerAccount.id,
            {
              page: 1,
              perPage: 10,
              query: userInvitations[0].email,
              status: [],
              permissionLevel: [],
            }
          );

        expect(result).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              email: userInvitations[0].email,
            }),
          ])
        );
      })
    );
  });

  describe("getManagerAccountRoleUserInvitationsCount", () => {
    it(
      "should return manager account role user invitations count",
      withFixtures(async ({ managerAccount }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result =
          await managerAccountRoleService.getManagerAccountRoleUserInvitationsCount(
            managerAccount.id,
            {
              page: 1,
              perPage: 5,
              query: "",
              status: [],
              permissionLevel: [],
            }
          );

        expect(result).toBe(10);
      })
    );
  });

  describe("getManagerAccountRolesTableData", () => {
    it(
      "should return manager account roles table data",
      withFixtures(async ({ managerAccount }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result =
          await managerAccountRoleService.getManagerAccountRolesTableData(
            managerAccount.id,
            {
              page: 1,
              perPage: 5,
              query: "",
              status: [],
              permissionLevel: [],
            }
          );

        expect(result).toHaveLength(5);
      })
    );

    it(
      "should return manager account roles table data with query",
      withFixtures(async ({ managerAccount, managerAccountRoles }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result =
          await managerAccountRoleService.getManagerAccountRolesTableData(
            managerAccount.id,
            {
              page: 1,
              perPage: 20,
              query: managerAccountRoles[0].user.email,
              status: [],
              permissionLevel: [],
            }
          );

        expect(result).toEqual(
          expect.arrayContaining([
            expect.objectContaining({
              email: managerAccountRoles[0].user.email,
            }),
          ])
        );
      })
    );
  });

  describe("getManagerAccountRolesTableDataCount", () => {
    it(
      "should return manager account roles table data count",
      withFixtures(async ({ managerAccount }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result =
          await managerAccountRoleService.getManagerAccountRolesTableDataCount(
            managerAccount.id,
            {
              page: 1,
              perPage: 5,
              query: "",
              status: [],
              permissionLevel: [],
            }
          );

        expect(result).toBe(20);
      })
    );
  });

  describe("getManagerAccountRole", () => {
    it(
      "should return a manager account role",
      withFixtures(async ({ managerAccountRoles }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result = await managerAccountRoleService.getManagerAccountRole({
          id: managerAccountRoles[0].id,
        });

        expect(result?.id).toEqual(managerAccountRoles[0].id);
      })
    );

    it(
      "should return a manager account role by manager_account_id and user_id",
      withFixtures(async ({ managerAccountRoles }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result = await managerAccountRoleService.getManagerAccountRole({
          manager_account_id: managerAccountRoles[0].manager_account_id,
          user_id: managerAccountRoles[0].user_id,
        });

        expect(result?.id).toEqual(managerAccountRoles[0].id);
      })
    );
  });

  describe("getManagerAccountRoleUserInvitation", () => {
    it(
      "should return a manager account role user invitation",
      withFixtures(async ({ userInvitations }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result =
          await managerAccountRoleService.getManagerAccountRoleUserInvitation({
            id: userInvitations[0].id,
          });

        expect(result?.id).toEqual(userInvitations[0].id);
      })
    );

    it(
      "should return a manager account role user invitation by manager_account_id and email",
      withFixtures(async ({ managerAccount, userInvitations }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result =
          await managerAccountRoleService.getManagerAccountRoleUserInvitation({
            manager_account_id: managerAccount.id,
            email: userInvitations[0].email,
          });

        expect(result?.id).toEqual(userInvitations[0].id);
      })
    );
  });

  describe("createManagerAccountRoleUserInvitation", () => {
    it(
      "should create a manager account role user invitation",
      withFixtures(async ({ managerAccount }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result =
          await managerAccountRoleService.createManagerAccountRoleUserInvitation(
            {
              manager_account_id: managerAccount.id,
              email: faker.internet.email({ provider: "example.com" }),
              role: faker.helpers.enumValue(ManagerAccountRoleType),
            }
          );

        const userInvitation = await tx.userInvitation.findUnique({
          where: { id: result.id },
        });

        expect(result).not.toBeNull();
        expect(userInvitation).not.toBeNull();
      })
    );

    it(
      "should create a manager account role user invitation and send email",
      withFixtures(async ({ managerAccount }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);

        const sendManagerAccountUserInvitationEmail = jest.spyOn(
          managerAccountRoleService,
          "sendManagerAccountUserInvitationEmail"
        );

        const result =
          await managerAccountRoleService.createManagerAccountRoleUserInvitation(
            {
              manager_account_id: managerAccount.id,
              email: faker.internet.email({ provider: "example.com" }),
              role: faker.helpers.enumValue(ManagerAccountRoleType),
            },
            true
          );

        expect(result).not.toBeNull();
        expect(sendManagerAccountUserInvitationEmail).toHaveBeenCalled();
      })
    );
  });

  describe("updateManagerAccountRoleRole", () => {
    it(
      "should update a manager account role role",
      withFixtures(async ({ managerAccountRoles }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const newRole = faker.helpers.enumValue(ManagerAccountRoleType);
        const result =
          await managerAccountRoleService.updateManagerAccountRoleRole(
            managerAccountRoles[0].id,
            newRole
          );

        const updatedManagerAccountRole =
          await tx.managerAccountRole.findUnique({
            where: { id: managerAccountRoles[0].id },
          });

        expect(result).not.toBeNull();
        expect(result.role).toEqual(newRole);
        expect(updatedManagerAccountRole?.role).toEqual(newRole);
      })
    );
  });

  describe("updateUserInvitationRole", () => {
    it(
      "should update a user invitation role",
      withFixtures(async ({ managerAccount, userInvitations }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const newRole = faker.helpers.enumValue(ManagerAccountRoleType);
        const newRoleJson = {
          manager_account_id: managerAccount.id,
          role: newRole,
        };
        const result = await managerAccountRoleService.updateUserInvitationRole(
          userInvitations[0].id,
          newRoleJson
        );

        const updatedUserInvitation = await tx.userInvitation.findUnique({
          where: { id: userInvitations[0].id },
        });

        expect(result).not.toBeNull();
        expect(result.role!).toEqual(newRoleJson);
        expect(updatedUserInvitation?.role).toEqual(newRoleJson);
      })
    );
  });

  describe("deleteUserInvitation", () => {
    it(
      "should delete a user invitation",
      withFixtures(async ({ userInvitations }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result = await managerAccountRoleService.deleteUserInvitation(
          userInvitations[0].id
        );

        const deletedUserInvitation = await tx.userInvitation.findUnique({
          where: { id: userInvitations[0].id },
        });

        expect(result).not.toBeNull();
        expect(deletedUserInvitation).toBeNull();
      })
    );
  });

  describe("deleteManagerAccountRole", () => {
    it(
      "should delete a manager account role",
      withFixtures(async ({ managerAccountRoles }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result = await managerAccountRoleService.deleteManagerAccountRole(
          managerAccountRoles[0].id
        );

        const deletedManagerAccountRole =
          await tx.managerAccountRole.findUnique({
            where: { id: managerAccountRoles[0].id },
          });

        expect(result).not.toBeNull();
        expect(deletedManagerAccountRole?.deleted_at).not.toBeNull();
      })
    );
  });

  describe("acceptManagerAccountUserInvitation", () => {
    it(
      "should accept a manager account user invitation",
      withFixtures(
        async (
          { managerAccount, userInvitations, managerAccountRoles },
          tx
        ) => {
          const { managerAccountRoleService } = TestDIContainer(tx);

          const user = await tx.user.create({
            data: {
              email: userInvitations[0].email,
              first_name: faker.person.firstName(),
              last_name: faker.person.lastName(),
              email_verification_tokens: {
                create: {
                  verified_at: null,
                  email: userInvitations[0].email,
                },
              },
            },
          });

          const result =
            await managerAccountRoleService.acceptManagerAccountUserInvitation(
              user,
              userInvitations[0].id,
              userInvitations[0].role! as {
                manager_account_id: string;
                role: ManagerAccountRoleType;
              }
            );

          const acceptedUserInvitation = await tx.userInvitation.findUnique({
            where: { id: userInvitations[0].id },
          });

          const acceptedManagerAccountRole =
            await tx.managerAccountRole.findFirst({
              where: {
                user_id: user.id,
                manager_account_id: managerAccount.id,
              },
            });

          expect(result).toBe(true);
          expect(acceptedUserInvitation?.accepted_at).not.toBeNull();
          expect(acceptedUserInvitation?.accepted_by_id).toEqual(user.id);
          expect(acceptedManagerAccountRole).not.toBeNull();
        }
      )
    );

    it(
      "should not accept a manager account user invitation if user is already associated with this Intelligence Manager Account",
      withFixtures(async ({ userInvitations, managerAccountRoles }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);

        const result =
          await managerAccountRoleService.acceptManagerAccountUserInvitation(
            managerAccountRoles[0].user,
            userInvitations[0].id,
            userInvitations[0].role as {
              manager_account_id: string;
              role: ManagerAccountRoleType;
            }
          );

        expect(result).toBe(false);
      })
    );
  });

  describe("sendManagerAccountUserInvitationEmail", () => {
    it(
      "should send a manager account user invitation email",
      withFixtures(async ({ userInvitations, managerAccount }, tx) => {
        const { managerAccountRoleService, mailService, templateService } =
          TestDIContainer(tx);

        const send = jest.spyOn(mailService, "send");
        const renderManagerAccountUserInvitationEmail = jest.spyOn(
          templateService,
          "renderManagerAccountUserInvitationEmail"
        );

        await managerAccountRoleService.sendManagerAccountUserInvitationEmail(
          userInvitations[0]
        );

        expect(send).toHaveBeenCalledWith({
          to: [userInvitations[0].email],
          subject: `You've been invited to manage ${managerAccount.name} on Revyse ⚒️`,
          body: renderManagerAccountUserInvitationEmail.mock.results[0].value,
        });
      })
    );
  });

  describe("updateAlertsAndNotifications", () => {
    it(
      "should update alerts and notifications",
      withFixtures(async ({ managerAccountRoles }, tx) => {
        const { managerAccountRoleService } = TestDIContainer(tx);
        const result =
          await managerAccountRoleService.updateAlertsAndNotifications(
            managerAccountRoles[0].id,
            {
              daily_notification_email: true,
            }
          );

        const updatedManagerAccountRole =
          await tx.managerAccountRole.findUnique({
            where: { id: managerAccountRoles[0].id },
          });

        expect(result).not.toBeNull();
        expect(updatedManagerAccountRole?.daily_notification_email).toBe(true);
      })
    );
  });
});
