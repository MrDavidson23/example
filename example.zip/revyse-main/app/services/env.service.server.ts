declare global {
  var _env: typeof env;
}

const env = {
  REVYSE_UI_ORIGIN: process.env.REVYSE_UI_ORIGIN || "http://localhost:3000",
  DB_HOST: process.env.DB_HOST!,
  DB_USER: process.env.DB_USER!,
  DB_PASS: process.env.DB_PASS!,
  DB_NAME: process.env.DB_NAME!,
  DB_PORT: process.env.DB_PORT!,
  SESSION_SECRET: process.env.SESSION_SECRET!,
  LIVE_RELOAD: process.env.LIVE_RELOAD === "true",
  SMTP_USER: process.env.SMTP_USER!,
  SMTP_PASS: process.env.SMTP_PASS!,
  SMTP_FROM: process.env.SMTP_FROM!,
  SMTP_HOST: process.env.SMTP_HOST!,
  SMTP_PORT: parseInt(process.env.SMTP_PORT || "465"),
  SMTP_USE_TLS: process.env.SMTP_USE_TLS === "true",
  AWS_SECRET_ACCESS_KEY: process.env.AWS_SECRET_ACCESS_KEY!,
  AWS_ACCESS_KEY_ID: process.env.AWS_ACCESS_KEY_ID!,
  AWS_S3_BUCKET: process.env.AWS_S3_BUCKET!,
  LOG_LEVEL: process.env.LOG_LEVEL || "debug",
  CUSTOMER_SUPPORT_EMAIL_LIST: process.env.CUSTOMER_SUPPORT_EMAIL_LIST
    ? process.env.CUSTOMER_SUPPORT_EMAIL_LIST.split(",")
    : ["jonathan@revyse.com"],
  SEED_TEST_DATA: process.env.SEED_TEST_DATA === "true",
  STRIPE_SECRET_KEY: process.env.STRIPE_SECRET_KEY!,
  STRIPE_WEBHOOK_SECRET: process.env.STRIPE_WEBHOOK_SECRET!,
  MAIL_CHIMP_API_KEY: process.env.MAIL_CHIMP_API_KEY || "",
  GTM_ID: process.env.GTM_ID || "",
  HOT_JAR_ID: process.env.HOT_JAR_ID || "",
  RECAPTCHA_SECRET_KEY: process.env.RECAPTCHA_SECRET_KEY || "",
  REDIS_CLUSTER_ENDPOINT: process.env.REDIS_CLUSTER_ENDPOINT!,
};

export function getEnv() {
  if (!global._env) {
    const missing: string[] = [];
    Object.entries(env).forEach(([key, value]) => {
      if (value === undefined) {
        missing.push(key);
      }
    });
    if (missing.length > 0) {
      console.error(
        "Missing required environment variables: " + missing.join(", ")
      );
      process.exit(1);
    } else {
      console.log("All required environment variables are set.");
    }
    global._env = env;
  }

  return global._env;
}
