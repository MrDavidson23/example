import {
  ManagerAccountVendorIncidentStatus,
  VendorState,
} from "@prisma/client";
import { withFixtureFactory } from "../utils/test.utils.server";
import { faker } from "@faker-js/faker";
import { TestDIContainer } from "../di-containers/test.di-container.server";
import { createTestUser } from "./seeds/createTestUser";
import { randomUUID } from "crypto";
import { withTx } from "./db.server";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const { authService } = TestDIContainer(tx);

    const user = await createTestUser(faker.internet.email(), authService);

    const vendor = await tx.vendor.create({
      data: {
        slug: faker.internet.url(),
        name: faker.company.name(),
        website: faker.internet.url(),
        state: VendorState.ApprovedForPublishing,
      },
    });

    const account = await tx.managerAccount.create({
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
        },
        manager_account_vendors: {
          include: {
            vendor: true,
          },
        },
      },
      data: {
        name: faker.company.name(),
        manager_account_roles: {
          create: {
            role: "Owner",
            user: {
              connect: {
                id: user.id,
              },
            },
          },
        },
      },
    });

    const accountVendor = await tx.managerAccountVendor.upsert({
      where: {
        manager_account_id_vendor_id: {
          manager_account_id: account.id,
          vendor_id: vendor.id,
        },
      },
      create: {
        manager_account: { connect: { id: account.id } },
        vendor: { connect: { id: vendor.id } },
        manager_account_vendor_incidents: {
          createMany: {
            data: [
              {
                name: faker.company.name(),
                status: ManagerAccountVendorIncidentStatus.New,
                created_date: new Date(),
                resolved_date: faker.date.soon(),
              },
              {
                name: faker.company.name(),
                status: ManagerAccountVendorIncidentStatus.InProgress,
                created_date: new Date(),
                resolved_date: faker.date.soon(),
              },
            ],
          },
        },
      },
      update: {},
      include: {
        manager_account_vendor_incidents: true,
      },
    });
    return { user, account, vendor, accountVendor };
  },
});

describe("ManagerAccountVendorIncident", () => {
  describe("loadIncident", () => {
    test(
      "should return manager account vendor incident",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorIncidentService } = TestDIContainer(tx);

        const incident = await managerAccountVendorIncidentService.loadIncident(
          accountVendor.manager_account_vendor_incidents[0].id
        );

        expect(incident?.manager_account_vendor_id).toBe(accountVendor.id);
      })
    );
    test(
      "should return null when id doesn't match database record",
      withTx(async tx => {
        const { managerAccountVendorIncidentService } = TestDIContainer(tx);

        const incident = await managerAccountVendorIncidentService.loadIncident(
          randomUUID()
        );
        expect(incident).toBeNull();
      })
    );
  });

  describe("handleIncident", () => {
    test(
      "should create a manager account vendor incident",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorIncidentService } = TestDIContainer(tx);
        const incident =
          await managerAccountVendorIncidentService.handleIncident(
            "new",
            accountVendor.id,
            {
              name: faker.company.name(),
              status: ManagerAccountVendorIncidentStatus.InProgress,
              created_date: new Date(),
            }
          );

        expect(incident).not.toBeNull();

        const resolved = new Date();
        const updatedIncident =
          await managerAccountVendorIncidentService.handleIncident(
            incident.id,
            accountVendor.id,
            {
              name: "New name",
              status: ManagerAccountVendorIncidentStatus.Resolved,
              created_date: new Date(),
              resolved_date: resolved,
            }
          );

        expect(updatedIncident.name).toEqual("New name");
        expect(updatedIncident.resolved_date).toBeDefined();
        expect(updatedIncident.resolved_date).toEqual(resolved);
        expect(updatedIncident.status).toEqual(
          ManagerAccountVendorIncidentStatus.Resolved
        );
      })
    );
  });

  describe("deleteIncident", () => {
    test(
      "should delete a manager account vendor incident",
      withFixtures(async ({ accountVendor }, tx) => {
        const { managerAccountVendorIncidentService } = TestDIContainer(tx);
        const loadedIncident =
          await managerAccountVendorIncidentService.loadIncident(
            accountVendor.manager_account_vendor_incidents[0].id
          );

        await managerAccountVendorIncidentService.deleteIncident(
          loadedIncident?.id
        );

        const incident = await tx.managerAccountVendorIncident.findFirst({
          where: {
            id: loadedIncident?.id,
          },
        });

        expect(incident).toBeNull();
        expect(accountVendor.manager_account_vendor_incidents).toHaveLength(2);
      })
    );
  });
});
