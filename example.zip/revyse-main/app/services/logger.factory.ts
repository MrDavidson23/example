import * as log4js from "log4js";
import { getEnv } from "./env.service.server";
export function getLogger(cat: string) {
  const logger = log4js.getLogger(cat);
  logger.level = getEnv().LOG_LEVEL;
  return logger;
}
