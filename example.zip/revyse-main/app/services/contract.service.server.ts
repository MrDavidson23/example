import {
  ContractLineItemLocationStatus,
  ContractLineItemStatus,
  ContractStatus,
  LocationStatus,
  ManagerAccountVendorStatus,
  type Prisma,
  type PrismaClient,
} from "@prisma/client";
import type { MockS3Service } from "./s3.service.server";
import { getEnv } from "./env.service.server";
import type { CustomerSupportService } from "./customer-support.service.server";
import { isNil } from "lodash";
import {
  FeatureFlag,
  type FeatureFlagService,
} from "./feature-flag.service.server";
import type { RAGService } from "./rag.service.server";
import { getLogger } from "./logger.factory";

type ContractFields = {
  name: string;
  term_length_months?: number | null;
  auto_renew_term_length?: number | null;
  status: ContractStatus;
  canceled_at?: Date | null;
  expires_at?: Date | null;
  current_term_end_date?: Date | null;
  effective_date?: Date | null;
  termination_notice_period?: number | null;
  termination_notice_details?: string | null;
  task_owner_id?: string | null;
  contract_owner_name?: string | null;
  approver?: string | null;
  department?: string;
  is_msa: boolean;
  will_auto_renew: boolean;
  is_month_to_month: boolean;
  notes?: string | null;
  renewal_reminder_lead_time_months?: number | null;
  renewal_reminder_date?: Date | null;
  renewal_reminder_emails?: string[];
  document_files: {
    id: string;
    name: string;
    file: string;
  }[];
  vendor_id: string | null;
  vendor_name?: string;
  description?: string;
  new_vendor: string;
  location_id?: string | null;
  is_sensitive?: boolean;
};
export class ContractService {
  constructor(
    private db: PrismaClient,
    private s3Service: MockS3Service,
    private customerSupportService: CustomerSupportService,
    private featureFlagService: FeatureFlagService,
    private ragService: RAGService
  ) {}

  async getContractById(id: string) {
    return await this.db.contract.findFirstOrThrow({
      where: { id },
      include: {
        manager_account_vendor: {
          include: {
            vendor: true,
          },
        },
      },
    });
  }

  async handleContractDocument({
    id,
    name,
    file,
    contractId,
  }: {
    id: string;
    name: string;
    file: string | null;
    contractId: string;
  }) {
    let contractFile = null;
    if (id?.includes("new_")) {
      contractFile = await this.db.contractFile.create({
        data: {
          contract_id: contractId,
          name: name,
          file_id: file ?? "",
        },
      });
    } else {
      const data = file
        ? {
            contract_id: contractId,
            name: name,
            file_id: file,
          }
        : {
            contract_id: contractId,
            name: name,
          };
      contractFile = await this.db.contractFile.update({
        where: {
          id: id,
        },
        data,
      });
    }
    return contractFile;
  }

  async deleteContractDocument(id: string) {
    try {
      await this.db.$transaction(async tx => {
        const document = await tx.contractFile.findFirstOrThrow({
          where: {
            id,
          },
          include: {
            file: true,
          },
        });

        const file = document.file;

        if (file) {
          await this.s3Service.deleteObject(file.uri);
        }

        await tx.contractFile.delete({
          where: {
            id,
          },
        });

        await tx.file.delete({
          where: {
            id: file?.id,
          },
        });
      });
      return {
        success: true,
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message,
      };
    }
  }

  async getContractWithLineItemDetails(id: string) {
    return await this.db.contract.findFirstOrThrow({
      where: { id },
      include: {
        document_files: true,
        contract_line_items: {
          include: {
            contract_line_item_products: {
              include: {
                product: true,
              },
            },
            contract_line_item_fees: {
              include: {
                fee: true,
              },
            },
            _count: {
              select: {
                contract_line_item_locations: {
                  where: {
                    status: { not: ContractLineItemLocationStatus.Canceled, },
                    location: {
                      status: {
                        in: [LocationStatus.Active, LocationStatus.Pending],
                      },
                    },
                  },
                },
              },
            },
            contract_line_item_locations: true,
          },
          orderBy: {
            name: "asc",
          },
        },
        manager_account_vendor: { include: { vendor: true } },
      },
    });
  }

  async loadContractedLocations(
    id: string | undefined,
    filters: Prisma.ContractLineItemLocationWhereInput,
    offset?: number,
    perPage?: number
  ) {
    return await this.db.location.findMany({
      where: {
        contract_line_item_locations: {
          some: filters,
        },
      },
      skip: offset,
      take: perPage,
      include: {
        contracted_location_files: {
          orderBy: {
            created_at: "desc",
          },
          where: {
            contract_id: id,
          },
          include: {
            file: true,
          },
        },
        contract_line_item_locations: {
          where: {
            contract_line_item: {
              contract_id: id,
            },
          },
          include: {
            contract_line_item: true,
            location: true,
          },
        },
      },
      orderBy: {
        name: "asc",
      },
    });
  }

  async deleteContractLocationFile(id: string) {
    try {
      await this.db.$transaction(async tx => {
        const document = await tx.contractLocationFile.findFirstOrThrow({
          where: {
            id,
          },
          include: {
            file: true,
          },
        });

        const file = document.file;

        if (file) {
          await this.s3Service.deleteObject(file.uri);
        }

        await tx.contractLocationFile.delete({
          where: {
            id,
          },
        });

        await tx.file.delete({
          where: {
            id: file?.id,
          },
        });
      });
      return {
        success: true,
      };
    } catch (error: any) {
      return {
        success: false,
        error: error.message,
      };
    }
  }

  async handleContractLocationFile({
    id,
    name,
    file,
    locationId,
    contractId,
  }: {
    id: string;
    name: string;
    file: string | null;
    locationId: string;
    contractId: string;
  }) {
    let vendorDocument = null;
    if (id.includes("new_")) {
      vendorDocument = await this.db.contractLocationFile.create({
        data: {
          location_id: locationId,
          contract_id: contractId,
          name: name,
          file_id: file ?? "",
        },
      });
    } else {
      const data = file
        ? {
            name,
            file_id: file,
          }
        : {
            name,
          };
      vendorDocument = await this.db.contractLocationFile.update({
        where: {
          id,
        },
        data,
      });
    }
    return vendorDocument;
  }

  async getContractOwnersAndApprovers(filters: Prisma.ContractWhereInput) {
    const contracts = await this.db.contract.findMany({
      where: filters,
      select: {
        contract_owner_name: true,
        approver: true,
      },
    });

    return [
      ...new Set(
        contracts.flatMap(
          ({ contract_owner_name, approver }) =>
            [contract_owner_name, approver]?.filter(Boolean) as string[]
        )
      ),
    ];
  }

  async deleteContract(id: string) {
    return await this.db.$transaction(async tx => {
      await tx.contractLineItemLocation.deleteMany({
        where: {
          contract_line_item: {
            contract: { id },
          },
        },
      });
      await tx.contractLineItemProduct.deleteMany({
        where: {
          contract_line_item: {
            contract: { id },
          },
        },
      });
      await tx.contractLineItem.deleteMany({
        where: {
          contract: { id },
        },
      });
      return await tx.contract.delete({
        where: {
          id,
        },
      });
    });
  }

  async archiveContract(id: string, canceled_at: Date | null) {
    await this.db.contract.update({
      where: {
        id,
      },
      data: {
        status: ContractStatus.Canceled,
        canceled_at: canceled_at,
      },
    });
  }

  async getContractDetails(id: string) {
    return this.db.contract.findUniqueOrThrow({
      where: { id },
      include: {
        document_files: {
          orderBy: {
            updated_at: "desc",
          },
        },
        task_owner: {
          include: {
            user: true,
          },
        },
        manager_account_vendor: { include: { vendor: true } },
        contract_line_items: {
          where: {
            status: {
              not: ContractLineItemStatus.Canceled,
            },
          },
          select: {
            id: true,
            name: true,
            price_increase_percent: true,
            price_increase_cadence: true,
            contract_line_item_locations: {
              where: {
                location: {
                  status: {
                    in: [LocationStatus.Active, LocationStatus.Pending],
                  },
                },
                status: { not: ContractLineItemLocationStatus.Canceled, },
              },
            },
            is_corporate_only: true,
          },
        },
        location: true,
      },
    });
  }

  async upsertContract(
    id: string,
    user: { id: string; email: string },
    data: ContractFields,
    managerAccountId: string
  ) {
    const logger = getLogger("upsertContract");

    const vendorId =
      data.new_vendor === "false" && data.vendor_id
        ? data.vendor_id
        : await this.db.$transaction(async tx => {
            const vendor = await tx.vendor.create({
              data: {
                name: data.vendor_name ?? "",
                description: data.description,
                approved_by_id: null,
                approved_at: null,
              },
            });
            // Create manager account vendor
            await tx.managerAccountVendor.create({
              data: {
                manager_account_id: managerAccountId,
                vendor_id: vendor.id,
              },
            });
            const env = getEnv();
            await this.customerSupportService.sendCSEmail(
              `New Vendor Alert | ${vendor.name}`,
              `<p>Hey Team Revyse,</p> 
<p>${user.email} created a new vendor for ${vendor.name} on Revyse via Vendor Intelligence.</p>
<p>Now it's your turn to review it.</p> 
<p>Click here to <a href="${env.REVYSE_UI_ORIGIN}/admin/vendors/${vendor.id}">review and approve</a>.</p>`
            );

            return vendor.id;
          });
    return await this.db.$transaction(
      async tx => {
        const loadedContract =
          id === "new"
            ? null
            : await tx.contract.findFirst({
                where: {
                  id: id,
                },
                include: {
                  document_files: true,
                  manager_account_vendor: { include: { vendor: true } },
                  contract_line_items: {
                    include: {
                      contract_line_item_locations: true,
                    },
                  },
                },
              });

        let managerVendor = await tx.managerAccountVendor.findFirst({
          where: {
            manager_account_id: managerAccountId,
            vendor_id: vendorId,
          },
        });

        if (!managerVendor) {
          managerVendor = await tx.managerAccountVendor.create({
            data: {
              manager_account_id: managerAccountId,
              vendor_id: vendorId,
            },
          });
        }

        if (id === "new") {
          const {
            document_files,
            new_vendor,
            vendor_name,
            description,
            location_id,
            ...formattedData
          } = data;

          const formData = {
            ...formattedData,
            vendor_id: undefined,
            task_owner_id: undefined,
            ...(location_id !== undefined && location_id !== null
              ? {
                  location: {
                    connect: {
                      id: location_id,
                    },
                  },
                }
              : {}),
          };

          const dbData = data.task_owner_id
            ? {
                ...formData,
                manager_account_vendor: {
                  connect: { id: managerVendor.id },
                },
                task_owner: {
                  connect: {
                    id: data.task_owner_id,
                  },
                },
              }
            : {
                ...formData,
                manager_account_vendor: {
                  connect: { id: managerVendor.id },
                },
              };
          const createdContract = await tx.contract.create({
            data: dbData,
          });

          if (
            managerVendor?.status === ManagerAccountVendorStatus.Inactive &&
            data.status === ContractStatus.Active
          ) {
            await this.db.managerAccountVendor.updateMany({
              where: {
                manager_account_id: managerAccountId,
                vendor_id: vendorId,
              },
              data: {
                status: ManagerAccountVendorStatus.Active,
              },
            });
          }

          for (const file of data.document_files) {
            await tx.contractFile.create({
              data: {
                contract_id: createdContract.id,
                file_id: file.file,
                name: file.name,
              },
            });

            if (this.featureFlagService.isEnabled(FeatureFlag.Clippy)) {
              this.ragService.addFileToIndex({
                file_id: file.file,
                contract_id: createdContract.id,
                account_id: managerAccountId,
              });
            }
          }

          return createdContract;
        } else {
          if (isNil(loadedContract)) {
            throw new Error(`Contract not found: ${id}`);
          }

          const {
            document_files,
            new_vendor,
            vendor_name,
            description,
            ...formattedData
          } = data;

          logger.debug("document_files", document_files);

          const dbData = data.task_owner_id
            ? {
                ...formattedData,
                vendor_id: undefined,
                manager_account_vendor_id: managerVendor.id,
                task_owner_id: data.task_owner_id,
              }
            : {
                ...formattedData,
                vendor_id: undefined,
                manager_account_vendor_id: managerVendor.id,
              };

          const updatedContract = await tx.contract.update({
            where: {
              id: id,
            },
            data: dbData,
          });

          for (const file of document_files) {
            // "--" indicates that the file is not new
            if (
              file.file !== "--" &&
              this.featureFlagService.isEnabled(FeatureFlag.Clippy)
            ) {
              // Do not await this because it will cause the response/transaction to timeout
              this.ragService.addFileToIndex({
                file_id: file.file,
                contract_id: updatedContract.id,
                account_id: managerAccountId,
              });
            }
          }

          // If the contract is set to a location, assign that location to the contract line items
          if (formattedData.location_id) {
            const locationId = formattedData.location_id;
            await Promise.all(
              loadedContract.contract_line_items.map(async contractLineItem => {
                // If the location is already assigned, skip
                if (
                  contractLineItem.contract_line_item_locations.find(
                    l => l.location_id === locationId
                  )
                ) {
                  return;
                }
                await tx.contractLineItemLocation.create({
                  data: {
                    contract_line_item_id: contractLineItem.id,
                    location_id: locationId,
                    status: ContractLineItemLocationStatus.Active,
                  },
                });
              })
            );
          }

          // Check if the current term end date has changed if that's true let's update the contract contractLineItem locations expires at field too
          if (
            data.current_term_end_date?.toString() !==
            loadedContract.current_term_end_date?.toString()
          ) {
            await tx.contractLineItemLocation.updateMany({
              where: {
                contract_line_item: {
                  contract_id: updatedContract.id,
                },
                expires_at: {
                  equals: loadedContract.current_term_end_date,
                },
              },
              data: {
                expires_at: data.current_term_end_date,
              },
            });
          }
          return updatedContract;
        }
      },
      // Extend this because we're doing document indexing synchronously.
      { timeout: 20000 }
    );
  }

  async getContractWithAiExtracts(id: string) {
    return this.db.contract.findUniqueOrThrow({
      where: { id },
      include: {
        document_files: {
          include: {
            file: true,
          },
        },
        manager_account_vendor: {
          select: {
            vendor: {
              select: {
                name: true,
                id: true,
                logo_file_id: true,
                description: true,
              },
            },
            manager_account_id: true,
          },
        },
        contract_ai_extracts: {
          take: 1,
          orderBy: {
            created_at: "desc",
          },
          include: { fields: { orderBy: { field_name: "asc" } } },
        },
      },
    });
  }
}
