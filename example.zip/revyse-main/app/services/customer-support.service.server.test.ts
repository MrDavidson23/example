import { TestDIContainer } from "../di-containers/test.di-container.server";
import { getEnv } from "./env.service.server";

describe("CustomerSupportService", () => {
  describe("sendCSEmail", () => {
    it("sends an email to the customer support email list", async () => {
      const { mailService, customerSupportService } = TestDIContainer();
      const env = getEnv();

      const mailServiceSendSpy = jest.spyOn(mailService, "send");

      const subject = "Test subject";
      const body = "Test body";
      await customerSupportService.sendCSEmail(subject, body);

      expect(mailServiceSendSpy).toHaveBeenCalledWith({
        to: env.CUSTOMER_SUPPORT_EMAIL_LIST,
        subject,
        body,
      });
    });
  });
});
