export const FeatureFlag = {
  AllowRobots: "FF_ALLOW_ROBOTS",
  ShowVendorFilters: "FF_SHOW_VENDOR_FILTERS",
  Clippy: "FF_CLIPPY",
  IntelligenceShowEntitiesSelector: "FF_INTELLIGENCE_SHOW_ENTITIES_SELECTOR",
  IntelligenceShowContractingParty: "FF_INTELLIGENCE_SHOW_CONTRACTING_PARTY",
} as const;

export class FeatureFlagService {
  public isEnabled(
    flag: (typeof FeatureFlag)[keyof typeof FeatureFlag]
  ): boolean {
    return process.env[flag] === "true";
  }
}
