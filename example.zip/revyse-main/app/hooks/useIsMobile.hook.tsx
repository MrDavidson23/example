import { useEffect, useState } from "react";

const useIsMobile = () => {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    const setMobile = () => {
      setIsMobile(window.innerWidth < 768);
    };

    setMobile();
    window.addEventListener("resize", setMobile);

    return () => window.removeEventListener("resize", setMobile);
  }, []);

  return isMobile;
};

export default useIsMobile;
