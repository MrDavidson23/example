import { ArrowsPointingOutIcon } from "@heroicons/react/24/outline";

export function StorylaneDemo({ demoUrl }: { demoUrl?: string }) {
  return (
    <div>
      <script src="https://js.storylane.io/js/v1/storylane.js"></script>
      <div
        className="sl-embed"
        style={{
          position: "relative",
          paddingBottom: "56.25%",
          width: "100%",
          height: 0,
          transform: "scale(1)",
        }}
      >
        <button
          className="bg-white/70 p-1 rounded-full absolute right-2 top-2 z-10"
          onClick={() => {
            document.getElementById("storylane-demo")?.requestFullscreen();
          }}
        >
          <ArrowsPointingOutIcon className="h-6 " />
        </button>
        <iframe
          id="storylane-demo"
          title="Storylane Demo"
          className="sl-demo"
          src={demoUrl}
          name="sl-embed"
          allow="fullscreen; camera; microphone"
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            width: "100%",
            height: "100%",
            border: "none",
          }}
          onClick={e => {}}
        ></iframe>
      </div>
    </div>
  );
}
