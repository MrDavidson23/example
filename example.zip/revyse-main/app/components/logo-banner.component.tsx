import { CameraIcon } from "@heroicons/react/24/outline";
import { isEmpty } from "lodash";
import { useEffect, useState } from "react";
import { MB } from "~/utils/constants.utils";
import { Toast } from "./toast.component";
import type { File } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { XCircleIcon } from "@heroicons/react/20/solid";
import { useFetcher, useResolvedPath } from "@remix-run/react";

export function LogoBanner({
  showBanner,
  logo,
  banner,
  logoError,
  bannerError,
}: {
  showBanner: boolean;
  logo: SerializeFrom<File> | null;
  banner: SerializeFrom<File> | null;
  logoError: string[];
  bannerError: string[];
}) {
  const [logoErrors, setLogoErrors] = useState(logoError);
  const [logoFile, setLogoFile] = useState(null);

  const [bannerErrors, setBannerErrors] = useState(bannerError);
  const [bannerFile, setBannerFile] = useState(null);
  const BYTE_LIMIT = 0.5 * MB;

  useEffect(() => {
    setLogoErrors(logoError);
  }, [logoError]);

  useEffect(() => {
    setBannerErrors(bannerError);
  }, [bannerError]);

  const handleFileChange = (
    e: React.ChangeEvent<HTMLInputElement>,
    setError: (errors: string[]) => void,
    setFile: (file: any) => void
  ) => {
    let okFiles = null;
    let hasError = false;
    for (const file of e.target.files ?? []) {
      if (file.size <= BYTE_LIMIT) {
        okFiles = file;
      } else {
        hasError = true;
      }
    }
    if (hasError) {
      setError([...logoErrors, "One or more files are too large"]);
      e.target.value = "";
      setFile(null);
    } else {
      setError([]);
      setFile(okFiles);
    }
  };
  const fetcher = useFetcher();

  const handleLogoFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFileChange(e, setLogoErrors, setLogoFile);
  };

  const handleBannerFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    handleFileChange(e, setBannerErrors, setBannerFile);
  };
  const { pathname: action } = useResolvedPath("/remove-file");

  return (
    <>
      {!isEmpty(logoErrors) && (
        <Toast variant="error" message={logoErrors.join(" ")} />
      )}
      {!isEmpty(bannerErrors) && (
        <Toast variant="error" message={bannerErrors.join(" ")} />
      )}
      <div className="relative w-full mb-8">
        {showBanner ? (
          <>
            <div className="h-32 w-full rounded-md absolute  bg-black bg-opacity-50 flex justify-center items-center flex-col text-white opacity-0 hover:opacity-100 transition-opacity duration-300">
              <CameraIcon className="h-6" />
              <div>1232 x 192</div>
              <input
                name="banner_file_id"
                type="file"
                accept="image/*"
                defaultValue={bannerFile ? bannerFile : undefined}
                className="h-32 w-full absolute opacity-0 cursor-pointer"
                onChange={handleBannerFile}
              />
            </div>
            <img
              src={
                bannerFile
                  ? URL.createObjectURL(bannerFile)
                  : banner
                  ? `/images/${banner.id}`
                  : "/assets/default-banner.png"
              }
              alt="Banner"
              className="w-full h-32 rounded-md object-cover cursor-pointer"
            />
            {banner && (
              <div className="absolute -top-2 -right-2 h-5">
                <button
                  type="button"
                  onClick={() => {
                    fetcher.submit(
                      {
                        file_id: banner.id,
                      },
                      {
                        method: "post",
                        action,
                        encType: "multipart/form-data",
                      }
                    );
                    return false;
                  }}
                >
                  <XCircleIcon className="h-5 bg-white rounded-full" />
                </button>
              </div>
            )}
          </>
        ) : (
          <div className="bg-sky-600 md:h-32 rounded-md"></div>
        )}

        <div className="cursor-pointer absolute bottom-0 left-0 -mb-8 ml-4">
          <div className="w-full h-32 absolute rounded-md  bg-black bg-opacity-50 flex justify-center items-center flex-col text-white opacity-0 hover:opacity-100 transition-opacity duration-300">
            <CameraIcon className="h-6" />
            <div>192 x 192</div>
            <input
              name="logo_file_id"
              defaultValue={logoFile ? logoFile : undefined}
              type="file"
              accept="image/*"
              className="h-32 w-full absolute opacity-0 cursor-pointer"
              onChange={handleLogoFile}
            />
          </div>
          <img
            src={
              logoFile
                ? URL.createObjectURL(logoFile)
                : logo
                ? `/images/${logo.id}`
                : "/assets/default-logo.png"
            }
            alt="Avatar"
            className="h-32 w-32 rounded-md object-cover cursor-pointer"
          />
          {logo && (
            <div className="absolute -top-2 -right-2 h-5">
              <button
                type="button"
                onClick={() => {
                  fetcher.submit(
                    {
                      file_id: logo.id,
                    },
                    {
                      method: "post",
                      action,
                      encType: "multipart/form-data",
                    }
                  );
                  return false;
                }}
              >
                <XCircleIcon className="h-5 bg-white rounded-full" />
              </button>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
