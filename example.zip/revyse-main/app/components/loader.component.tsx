export function Loader() {
  const circleCommonClasses =
    "bg-primary-200 opacity-50 h-3 w-3 bg-current rounded-full";
  return (
    <div className="h-full w-full flex justify-center items-center">
      <div className={`${circleCommonClasses} mr-2 animate-bounce`}></div>
      <div
        className={`${circleCommonClasses} mr-2 animate-[bounce_1s_infinite_200ms]`}
      ></div>
      <div
        className={`${circleCommonClasses} animate-[bounce_1s_infinite_400ms]`}
      ></div>
    </div>
  );
}
