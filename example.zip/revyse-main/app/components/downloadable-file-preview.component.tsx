import { ArrowDownTrayIcon } from "@heroicons/react/20/solid";
import { DocumentIcon } from "@heroicons/react/24/outline";
import { VideoPlayer } from "./video-player.component";
import { PdfPreview } from "./pdf-preview.component";

export function DownloadableFilePreview({
  id,
  type,
  title,
  uri,
}: {
  id: string;
  type: string;
  title: string;
  uri: string;
}) {
  return (
    <div className="bg-gray-50 border h-36 w-full lg:w-full border-gray-200 rounded relative group overflow-hidden mx-auto">
      {type.startsWith("image/") ? (
        <img
          src={`/images/${id}`}
          alt={title}
          className="h-full w-full object-cover"
        />
      ) : type === "application/pdf" ? (
        <PdfPreview pdfUrl={`/images/${id}`} className="w-full min-h-full" />
      ) : type.startsWith("audio/") ? (
        <div className="w-full h-full flex justify-center items-center">
          <audio src={`/images/${id}`} controls className="w-11/12" />
        </div>
      ) : type.startsWith("video/") ? (
        <VideoPlayer fileId={id} />
      ) : (
        <div className="p-2 flex justify-center items-center h-full">
          <DocumentIcon className="w-16 min-w-16" aria-hidden="true" />
          <span className="[text-wrap:pretty]">
            {title || uri.split("/").pop()}
          </span>
        </div>
      )}
      {!type.startsWith("video/") ? (
        <a
          download={type.startsWith("image/") ?? `/images/${id}`}
          href={`/images/${id}`}
          target="_blank"
          rel="noopener noreferrer"
          className="absolute top-0 left-0 w-full h-full bg-primary-900 bg-opacity-70 flex items-center justify-center opacity-0 transition-opacity duration-200 cursor-pointer group-hover:opacity-100"
        >
          <div className="flex flex-col text-white w-11/12 text-center">
            <p className="truncate text-sm">{title ?? uri}</p>
            <ArrowDownTrayIcon className="h-12"></ArrowDownTrayIcon>
          </div>
        </a>
      ) : null}
    </div>
  );
}
