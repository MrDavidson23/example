import { Dialog, Transition } from "@headlessui/react";
import { XMarkIcon } from "@heroicons/react/20/solid";
import type { ReactNode } from "react";
import { Fragment, useCallback, useEffect, useState } from "react";
import { tv } from "tailwind-variants";

const tvDialogPanel = tv({
  base: "relative transform overflow-hidden rounded-lg bg-white px-4 pb-4 pt-5 text-left shadow-xl transition-all sm:my-8 w-full sm:p-6",
  variants: {
    size: {
      small: "sm:max-w-lg",
      "medium-small": "sm:max-w-2xl",
      medium: "sm:max-w-4xl z-40",
      full: "sm:mx-8",
    },
  },
});

export function Modal({
  isOpen,
  onClose,
  children,
  size = "small",
  manager = false,
}: {
  isOpen: boolean;
  onClose: (closed: boolean) => void;
  children: ReactNode;
  size?: keyof typeof tvDialogPanel.variants.size;
  manager?: boolean;
}) {
  const [open, setOpen] = useState(isOpen);
  useEffect(() => {
    setOpen(isOpen);
  }, [isOpen]);

  const close = useCallback(() => {
    setOpen(false);
    onClose(false);
  }, [onClose]);

  return (
    <Transition.Root show={open} as={Fragment}>
      <Dialog
        as="div"
        className={`relative ${manager ? "z-50" : "z-10"}`}
        onClose={val => {
          onClose(val);
        }}
      >
        <Transition.Child
          as={Fragment}
          enter="ease-out duration-300"
          enterFrom="opacity-0"
          enterTo="opacity-100"
          leave="ease-in duration-200"
          leaveFrom="opacity-100"
          leaveTo="opacity-0"
        >
          <div className="fixed inset-0 bg-gray-500 bg-opacity-75 transition-opacity" />
        </Transition.Child>
        <style type="text/css">
          {`
            h1 {
              font-size: 2rem;
              font-weight: 600;
              margin-bottom: 1.25rem;
            }
            p {
              margin: 1rem 0;
            }
            a {
              color: rgb(2 132 199); /* sky-600 */
            }
          `}
        </style>
        <div className="fixed inset-0 z-10 overflow-y-auto">
          <div className="flex min-h-full justify-center pt-4 md:p-4 text-center items-center p-1">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <Dialog.Panel className={tvDialogPanel({ size })}>
                <div className="absolute right-0 top-0 pr-4 pt-4 sm:block">
                  <button
                    type="button"
                    className="rounded-md bg-white text-gray-400 hover:text-gray-500 focus:outline-none"
                    onClick={close}
                  >
                    <span className="sr-only">Close</span>
                    <XMarkIcon className="h-6 w-6" aria-hidden="true" />
                  </button>
                </div>
                {children}
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </div>
      </Dialog>
    </Transition.Root>
  );
}
