import { useRef, useState, Suspense, useEffect } from "react";
import "quill-emoji/dist/quill-emoji.css";
import "react-quill/dist/quill.snow.css";
import "quill-mention/dist/quill.mention.css";
import { Loader } from "../loader.component";
export interface EditorContentChanged {
  html: string;
}

export interface EditorProps {
  value?: string;
  className?: string;
  placeholder?: string;
  onChange?: (changes: EditorContentChanged) => void;
  errors?: string[];
  toolBarOptions: any;
  forwardedRef?: (ref: any) => void;
}

export function Editor(props: EditorProps) {
  const [value, setValue] = useState<string>(props.value || "");
  const reactQuillRef = useRef<any | null>(null);
  const [ReactQuill, setReactQuill] = useState<any>(null);

  useEffect(() => {
    const loadQuill = async () => {
      const module = await import("react-quill");
      const Quill = module.default.Quill;
      // Register Emoji module and Mention module with Quill
      const Emoji = await import("quill-emoji");
      const QuillMention = await import("quill-mention");

      Quill.register("modules/emoji", Emoji);
      Quill.register("modules/mentions", QuillMention);
      setReactQuill(() => module.default);
    };
    loadQuill();
  }, []);

  useEffect(() => {
    if (props.forwardedRef) {
      props.forwardedRef(reactQuillRef.current);
    }
  }, [props, props.forwardedRef]);

  useEffect(() => {
    setValue(props.value || "");
  }, [props.value]);

  const onChange = (content: string) => {
    setValue(content);

    if (props.onChange) {
      props.onChange({
        html: content,
      });
    }
  };

  if (!ReactQuill) {
    return <Loader />;
  }

  return (
    <Suspense fallback={<Loader />}>
      <ReactQuill
        className={props.className}
        ref={reactQuillRef}
        theme="snow"
        placeholder={props.placeholder}
        modules={props.toolBarOptions}
        value={value}
        onChange={onChange}
      />
      <p className="mt-3 text-sm leading-6 text-red-600">
        {props.errors?.join(" ")}
      </p>
    </Suspense>
  );
}
