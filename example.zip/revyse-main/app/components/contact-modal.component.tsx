import { useFetcher } from "@remix-run/react";
import { Modal } from "./modal.component";
import type { action as buyerContactAction } from "../routes/_api.buyer-contact";
import type { Product, Tier, Vendor } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { Button } from "./button.component";
import { CrudTextAreaField } from "./form/textarea.component";
import { tierHasPermission } from "~/utils/permission.utils";

export function BuyerContactModal({
  isOpen,
  onClose,
  product,
  activePlan,
  descriptionText = `Let ${product.vendor?.name} know you're interested in ${product.title}`,
}: {
  isOpen: boolean;
  onClose: () => void;
  product: SerializeFrom<Product & { vendor: SerializeFrom<Vendor> | null }>;
  activePlan: { name: string; tier: Tier } | undefined;
  descriptionText?: string;
}) {
  const fetcher = useFetcher<typeof buyerContactAction>();

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <fetcher.Form
        method="post"
        action="/buyer-contact"
        id="contact-modal-form"
      >
        {fetcher.state === "idle" && fetcher.data?.success ? (
          <>
            <h2 className="text-2xl font-bold mb-4">Nice!</h2>
            <p>
              Your request for more info about {product.title} has been sent.
            </p>
            <div className="flex justify-end mt-4">
              <Button onClick={onClose} id="ok-button">
                Ok
              </Button>
            </div>
          </>
        ) : (
          <>
            <h2 className="text-2xl font-bold mb-4">
              {tierHasPermission(activePlan?.tier, "contact_vendor")
                ? `Contact ${product.vendor?.name}`
                : "Contact a Revyse Advisor"}
            </h2>
            <code>{fetcher.data?.errors?.description}</code>
            <CrudTextAreaField
              field={{
                name: "description",
                type: "textarea",
                errors: fetcher.data?.errors?.description ?? [],
                label: descriptionText,
                defaultValue: "",
              }}
            />
            <input type="hidden" name="product_id" value={product.id} />
            <div className="flex justify-end mt-4">
              <Button
                disabled={fetcher.state === "loading"}
                type="submit"
                id="contact-modal-submit"
              >
                Submit
              </Button>
            </div>
          </>
        )}
      </fetcher.Form>
    </Modal>
  );
}
