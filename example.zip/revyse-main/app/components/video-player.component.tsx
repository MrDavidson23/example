import { useState, useEffect } from "react";
import { Loader } from "./loader.component";
import { ExclamationTriangleIcon } from "@heroicons/react/24/outline";

interface VideoPlayerProps {
  fileId: string;
}

export function VideoPlayer({ fileId }: VideoPlayerProps) {
  const [signedUrl, setSignedUrl] = useState<string | null>(null);
  const [error, setError] = useState<boolean>(false);

  useEffect(() => {
    fetch(`/videos/${fileId}`)
      .then(response => response.text())
      .then(data => {
        setSignedUrl(data);
      })
      .catch(error => {
        setError(true);
        console.error("Error fetching signed URL:", error);
      });
  }, [fileId]);

  return signedUrl ? (
    <video className="w-full" controls src={signedUrl} />
  ) : !error ? (
    <Loader></Loader>
  ) : (
    <div className="flex-col text-themeYellow w-full h-full text-center flex justify-center items-center">
      <ExclamationTriangleIcon className="h-8"></ExclamationTriangleIcon>
      <p className="truncate text-md font-light">Video not found</p>
    </div>
  );
}
