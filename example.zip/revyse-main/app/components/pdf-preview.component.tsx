import { useEffect, useMemo } from "react";
import { Document, pdfjs, Thumbnail } from "react-pdf";
import { Loader } from "./loader.component";

export function PdfPreview({
  pdfUrl,
  className,
  page = 1,
}: {
  pdfUrl: string;
  className?: string;
  page?: number;
}) {
  useEffect(() => {
    // CDN
    // pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;
    // Local
    pdfjs.GlobalWorkerOptions.workerSrc = `/lib/pdf.worker.min.js`;
  }, []);

  const file = useMemo(() => {
    return {
      url: pdfUrl,
    };
  }, [pdfUrl]);

  const renderLoader = () => (
    <div className="absolute w-full h-full">
      <Loader></Loader>
    </div>
  );

  return (
    <div className={`pdf-preview relative ${className}`}>
      <Document file={file} loading={renderLoader()}>
        <Thumbnail
          pageNumber={page}
          renderMode="canvas"
          loading={renderLoader()}
        />
      </Document>
    </div>
  );
}
