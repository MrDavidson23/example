import { useNavigate } from "@remix-run/react";
import { CTA } from "./cta.component";
import { Modal } from "./modal.component";

export function UnclaimedListingModal({
  isOpen,
  onClose,
  product,
}: {
  isOpen: boolean;
  onClose: () => void;
  product: { slug: string };
}) {
  const navigate = useNavigate();
  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <h1 className="text-2xl">Unclaimed Listing</h1>
      <p>
        Revyse curates product listings from across the proptech industry.
        Vendors can manage the content of their product listings by claiming
        them. Request to claim this listing by clicking the button below.
      </p>
      <CTA
        id="claim-listing-button"
        onClick={() => {
          onClose();
          navigate(`/products/${product.slug}?claim=true`);
        }}
        className="mt-4"
      >
        Claim Listing
      </CTA>
    </Modal>
  );
}
