import {
  ContractLineItemLocationStatus,
  ContractLineItemStatus,
  ContractStatus,
  IntelligenceVendorIntegrationStatus,
  LocationStatus,
  ManagerAccountVendorStatus,
  TaskCompletionStatus,
  TaskScheduleStatus,
} from "@prisma/client";
import { tv } from "tailwind-variants";

const statusColorMapping = {
  ContractStatus: {
    [ContractStatus.Active]: "green",
    [ContractStatus.Canceled]: "red",
    [ContractStatus.Pending]: "yellow",
  },
  ContractLineItemLocationStatus: {
    [ContractLineItemLocationStatus.Active]: "green",
    [ContractLineItemLocationStatus.Canceled]: "red",
    [ContractLineItemLocationStatus.Pending]: "yellow",
  },
  ContractLineItemStatus: {
    [ContractLineItemStatus.Active]: "green",
    [ContractLineItemStatus.Canceled]: "red",
  },
  LocationStatus: {
    [LocationStatus.Active]: "green",
    [LocationStatus.Disposed]: "red",
    [LocationStatus.Pending]: "yellow",
  },
  ManagerAccountVendorStatus: {
    [ManagerAccountVendorStatus.Inactive]: "red",
    [ManagerAccountVendorStatus.Piloting]: "yellow",
    [ManagerAccountVendorStatus.Active]: "green",
  },
  TaskCompletionStatus: {
    [TaskCompletionStatus.Canceled]: "red",
    [TaskCompletionStatus.Incomplete]: "yellow",
    [TaskCompletionStatus.Completed]: "green",
  },
  TaskScheduleStatus: {
    [TaskScheduleStatus.Overdue]: "red",
    [TaskScheduleStatus.ReadyToDo]: "yellow",
    [TaskScheduleStatus.Upcoming]: "sky",
    [TaskScheduleStatus.Archived]: "gray",
  },
  IntelligenceVendorIntegrationStatus: {
    [IntelligenceVendorIntegrationStatus.Active]: "green",
    [IntelligenceVendorIntegrationStatus.Inactive]: "red",
    [IntelligenceVendorIntegrationStatus.Pending]: "yellow",
  },
} as const;

const tvStatusChip = tv({
  base: "rounded-3xl px-3 py-1 md:px-4 md:py-1.5 border w-min font-semibold capitalize text-center whitespace-nowrap",
  variants: {
    color: {
      green: "bg-green-50 text-green-500 border-green-500",
      red: "bg-red-50 text-red-500 border-red-500",
      yellow: "bg-yellow-50 text-yellow-500 border-yellow-500",
      lime: "bg-lime-50 text-lime-500 border-lime-500",
      amber: "bg-amber-50 text-amber-500 border-amber-500",
      orange: "bg-orange-50 text-orange-500 border-orange-500",
      gray: "bg-gray-50 text-gray-500 border-gray-500",
      sky: "bg-sky-50 text-sky-500 border-sky-500",
      black: "bg-white text-black border-black",
    },
  },
});
function StatusChip({
  label,
  color,
  className,
  model,
  status,
  prefix,
  suffix,
}: {
  label: string;
  color?: keyof typeof tvStatusChip.variants.color;
  model?: keyof typeof statusColorMapping;
  status?:
    | ContractStatus
    | ContractLineItemLocationStatus
    | ContractLineItemStatus
    | LocationStatus
    | ManagerAccountVendorStatus
    | TaskCompletionStatus
    | TaskScheduleStatus
    | IntelligenceVendorIntegrationStatus;
  className?: string;
  prefix?: string;
  suffix?: string;
}) {
  const colorVariant =
    model && status
      ? statusColorMapping[model][
          status as keyof (typeof statusColorMapping)[keyof typeof statusColorMapping]
        ]
      : color;
  let text = label;
  if (prefix) text = `${prefix} ${text}`;
  if (suffix) text = `${text} ${suffix}`;
  return (
    <div
      id="status-chip"
      className={tvStatusChip({ color: colorVariant, className })}
    >
      {text}
    </div>
  );
}

export default StatusChip;
