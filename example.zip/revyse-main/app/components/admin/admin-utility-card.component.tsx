import type { ReactNode } from "react";

export function AdminUtilityCard({
  title,
  subtitle,
  cta,
}: {
  title: string;
  subtitle?: string;
  cta: ReactNode;
}) {
  return (
    <div className="-space-y-px rounded-md shadow-sm border border-gray-100 bg-white p-6 grid md:grid-cols-2 gap-6 mt-6">
      <div className="my-auto">
        <h5 className="font-bold">{title}</h5>
        <div>{subtitle}</div>
      </div>
      <div className="w-full flex justify-end items-center">{cta}</div>
    </div>
  );
}
