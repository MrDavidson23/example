import { ArrowRightIcon, CheckCircleIcon } from "@heroicons/react/20/solid";
import { CTA } from "./cta.component";
import type { SerializeFrom } from "@remix-run/node";
import type { Product, StripePrice, StripeProduct } from "@prisma/client";
import { useState } from "react";

function FeatureRow({
  title,
  has: [has1, has2, has3, has4],
}: {
  title: string | JSX.Element;
  has: [boolean | string, boolean | string, boolean | string, boolean | string];
}) {
  return (
    <>
      <div className="col-span-2 border-b border-gray-400 py-3 pl-2">
        {title}
      </div>
      <div className="border-b border-gray-400 py-3">
        {has1 === true && (
          <CheckCircleIcon className="text-green-500 h-6 ml-2" />
        )}
        {typeof has1 == "string" && has1}
      </div>
      <div className="border-b border-gray-400 py-3 flex items-center">
        {has2 === true && (
          <CheckCircleIcon className="text-green-500 h-6 ml-3" />
        )}
        {typeof has2 == "string" && has2}
      </div>
      <div className="border-b border-gray-400 py-3 flex items-center">
        {has3 === true && (
          <CheckCircleIcon className="text-green-500 h-6 ml-4" />
        )}
        {typeof has3 == "string" && has3}
      </div>
      <div className="border-b border-gray-400 py-3 flex items-center">
        {has4 === true && (
          <CheckCircleIcon className="text-green-500 h-6 ml-5" />
        )}
        {typeof has4 == "string" && has4}
      </div>
    </>
  );
}

function FeatureTable() {
  return (
    <>
      <div className="grid grid-cols-6 mt-6">
        {/* Product Listing table */}
        <FeatureRow
          title="Claimed listing badge"
          has={[true, true, true, true]}
        />
        <FeatureRow
          title="Edit logo + description + main category"
          has={[true, true, true, true]}
        />

        <FeatureRow
          title="Add secondary + tertiary categories"
          has={[false, true, true, true]}
        />
        <FeatureRow
          title="Upload a custom banner image"
          has={[false, true, true, true]}
        />
        <FeatureRow
          title="Add competitive product positioning"
          has={[false, true, true, true]}
        />
        <FeatureRow
          title="Highlight key product features"
          has={[false, true, true, true]}
        />
        <FeatureRow
          title="Add pricing + packaging details*"
          has={[false, true, true, true]}
        />
        <FeatureRow
          title="Post official responses to user reviews"
          has={[false, true, true, true]}
        />
        <FeatureRow
          title="Direct contact form to generate in-market leads"
          has={[false, true, true, true]}
        />

        <FeatureRow
          title="Add searchable 'good-for' use case tags"
          has={[false, false, true, true]}
        />
        <FeatureRow
          title="Add product images + screenshots*"
          has={[false, false, true, true]}
        />
        <FeatureRow
          title="Add video content*"
          has={[false, false, true, true]}
        />
        <FeatureRow
          title="Add downloadable case studies + PDFs*"
          has={[false, false, true, true]}
        />

        <FeatureRow
          title="Featured promo banner on category page"
          has={[false, false, false, true]}
        />
        <FeatureRow
          title="Featured promo banner on product page"
          has={[false, false, false, true]}
        />
        <FeatureRow
          title="Add a direct calendar scheduling link"
          has={[false, false, false, true]}
        />
        <FeatureRow
          title="Embed self-guided product demos*"
          has={[false, false, false, true]}
        />
        <FeatureRow
          title="Best-in-class demo automation software included"
          has={[false, false, false, true]}
        />
        <FeatureRow
          title={
            <>
              <span className="font-semibold text-coral">
                Available Add-On:{" "}
              </span>
              <span>Review generation campaigns</span>
            </>
          }
          has={[false, "$2,000", "$1,500", "$1,000"]}
        />
      </div>
      <div className="w-full flex justify-center italic mt-10">
        *Content accessible by approved buyers only
      </div>
    </>
  );
}

// export type PlanChoice = "free" | "community" | "brand" | "market";
export type PlanCadence = "monthly" | "yearly";

export function PlanChooser({
  title,
  onChoose,
  product,
  stripeProducts,
}: {
  title: string;
  onChoose: (
    stripeProduct: SerializeFrom<
      StripeProduct & { prices: SerializeFrom<StripePrice>[] }
    >,
    price: SerializeFrom<StripePrice>
  ) => void;
  product?: SerializeFrom<Product>;
  stripeProducts: SerializeFrom<
    StripeProduct & { prices: SerializeFrom<StripePrice>[] }
  >[];
}) {
  const [cadence, setCadence] = useState<PlanCadence>("monthly");
  return (
    <div className="max-w-7xl md:px-8 w-full">
      <div className="flex flex-col md:flex-row items-start justify-between md:items-center">
        <h3 className="font-medium mb-4">{title}</h3>
        <select
          className="rounded-3xl pl-4 pr-8 border-sky-600 text-sky-600"
          onChange={evt => {
            setCadence(evt.target.value as PlanCadence);
          }}
          defaultValue={cadence}
        >
          <option value="yearly">Annual Price</option>
          <option value="monthly">Monthly Price</option>
        </select>
      </div>
      <div className="grid grid-cols-6 gap-4 mt-10">
        {/* Headers */}
        <div className="col-span-2 font-medium">Plan</div>

        {stripeProducts.map((product, idx) => (
          <div key={idx} className="font-medium text-xs md:text-lg truncate">
            {product.name}
          </div>
        ))}

        {/* descriptions */}
        <div className="col-span-2"></div>
        {stripeProducts.map((product, idx) => (
          <div key={idx} className="text-sm">
            <div className="hidden md:block">{product.description}</div>
          </div>
        ))}

        {/* pricing */}
        <div className="col-span-2 font-medium">Pricing</div>

        {stripeProducts.map((stripeProduct, idx) => (
          <div key={idx}>
            {stripeProduct.prices
              .filter(p => p.cadence === cadence)
              .map((price, idx) => (
                <div key={idx}>
                  <div className="font-medium mb-4 text-xs md:text-lg">
                    {price.price === 0
                      ? "Free"
                      : `$${(price.price / 100.0).toLocaleString(undefined, {
                          maximumFractionDigits: 2,
                        })}`}
                    {price.price === 0
                      ? ""
                      : cadence === "monthly"
                      ? "/mo"
                      : "/yr"}
                  </div>
                  <CTA
                    id={`select-pricing-${stripeProduct.id}`}
                    className="hidden md:block"
                    onClick={() => {
                      onChoose(stripeProduct, price);
                    }}
                  >
                    {product ? "Select" : "Let's Go!"}
                  </CTA>
                  <CTA
                    className="md:hidden"
                    onClick={() => {
                      onChoose(stripeProduct, price);
                    }}
                  >
                    <ArrowRightIcon className="h-6 w-6" />
                  </CTA>
                </div>
              ))}
          </div>
        ))}
      </div>

      <FeatureTable />
    </div>
  );
}
