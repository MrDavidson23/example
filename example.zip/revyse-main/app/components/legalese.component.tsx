import type { ReactNode } from "react";

export function Legalese({
  title,
  children,
}: {
  title: string;
  children: ReactNode;
}) {
  return (
    <>
      <style type="text/css">
        {`
        p {
          margin: 2rem 0;
        }
        h2 {
          margin: 2rem 0;
          font-size: 1.5rem;
          font-weight: 500;
        }
        h3 {
          margin: 2rem 0;
          font-size: 1rem;
          font-weight: 600;
        }
        ul {
          list-style: disc;
          margin-left: 1.5rem;
        }
        
        li {
          margin: 0.5rem 0;
          font-size: 14px;
        }
        `}
      </style>
      <div className="py-4 flex justify-center">
        <div className="max-w-7xl flex-1 px-6 lg:px-7">
          <h1 className="text-3xl font-bold my-4">{title}</h1>
          {children}
        </div>
      </div>
    </>
  );
}
