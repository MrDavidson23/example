import type { ReactNode } from "react";
import type { Breadcrumb } from "./breadcrumbs.component";
import { Breadcrumbs } from "./breadcrumbs.component";

export function PortalPage({
  crumbs,
  children,
  buttonsSlot,
}: {
  crumbs: Breadcrumb[];
  children: ReactNode;
  buttonsSlot?: ReactNode;
}) {
  return (
    <div className="flex justify-center">
      <div className="md:max-w-7xl w-full px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex flex-wrap mb-6 gap-6">
          <Breadcrumbs className="grow" crumbs={crumbs} />
          {buttonsSlot}
        </div>
        {children}
      </div>
    </div>
  );
}
