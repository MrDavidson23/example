import { MagnifyingGlassIcon } from "@heroicons/react/24/outline";
import { useLocation } from "@remix-run/react";
import { useState } from "react";

export function BlogSearch() {
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const query = params.get("query") || "";
  const [inputValue, setInputValue] = useState(query);
  return (
    <div className="flex flex-row lg:space-x-2 justify-center items-center">
      <form method="get" className="flex flex-row">
        <input
          name="query"
          type="text"
          className="rounded-3xl p-3 px-4 lg:w-96 h-min my-auto flex-grow mr-4 text-black border-0 focus:border-0 focus:ring-0"
          placeholder="Search by post title"
          id="keyword-search"
          value={inputValue}
          onChange={e => setInputValue(e.target.value)}
        />
        <button
          id="search-button"
          className="rounded-3xl hidden lg:block w-fit p-3 px-8 border border-white bg-sky-500"
          type="submit"
        >
          Search
        </button>
        <button
          id="search-button"
          className="rounded-3xl block lg:hidden w-fit p-3 m-1 border border-white bg-sky-500"
          type="submit"
        >
          <MagnifyingGlassIcon className="h-6 text-white" />
        </button>
      </form>
    </div>
  );
}
