import { useNavigate } from "@remix-run/react";
import { Link } from "react-router-dom";
import StarRating from "./star-rating.component";
import { CTA } from "./cta.component";
import type { ProductCategory, Tier } from "@prisma/client";
import { tierHasPermission } from "~/utils/permission.utils";
import { Tag } from "./tag.component";
import { Tooltip } from "./tooltip.component";
import { isEmpty } from "lodash";
import type { SerializeFrom } from "@remix-run/node";

export function VendorProductCard({
  product,
  buttonLabel = "View Details",
  tags,
}: {
  product: {
    id: string;
    logo_file_id: string | null;
    slug: string;
    title: string;
    vendor_name: string;
    vendor_slug?: string | null;
    avg_score: number;
    vendor_logo_file_id?: string | null;
    cnt: number;
    description: string;
    good_for_tags?: { id: string; name: string }[];
    subCount: number;
    promo_text: string | null;
    tier: Tier;
    primary_category: SerializeFrom<ProductCategory>;
  };
  buttonLabel?: string;
  tags?: { label: string; icon: JSX.ElementType }[];
}) {
  const navigate = useNavigate();
  return (
    <div
      className="border border-gray-100 shadow-md rounded-lg md:p-6 p-4 cursor-pointer"
      onClick={() => {
        navigate(`/products/${product.slug}`);
      }}
    >
      <div className="flex gap-3 md:gap-6">
        <div className="relative">
          <div
            className="w-24 h-24 bg-white border border-gray-100 bg-center bg-contain bg-no-repeat"
            style={{
              backgroundImage: product.logo_file_id
                ? `url(/images/${product.logo_file_id})`
                : product.vendor_logo_file_id
                ? `url(/images/${product.vendor_logo_file_id})`
                : "url(/assets/default-logo.png)",
            }}
          ></div>
          {product.promo_text &&
            !tags &&
            tierHasPermission(product.tier, "show_promo") && (
              <div className="relative -ml-7 mt-4 bg-themeYellow text-darkGray rounded-r-3xl rounded-l-md text-xs py-2 pl-8 pr-4 font-semibold truncate">
                {product.promo_text}
              </div>
            )}
        </div>
        <div className="w-full flex-shrink">
          <div className="flex justify-between items-start flex-wrap lg:flex-nowrap gap-y-2">
            <div>
              <div className="truncate whitespace-normal hyphens-auto break-words text-md lg:text-xl font-medium">
                <Link to={`/products/${product.slug}`}>{product.title}</Link>
              </div>
              <div
                className="hidden md:block mt-0.5 text-sm text-gray-500 font-light"
                onClick={e => e.stopPropagation()}
              >
                <Link to={`/categories/${product.primary_category.slug}`}>
                  <span className="border-b hover:border-b-gray-200 border-b-gray-100 transition-colors duration-300">
                    {product.primary_category.name}
                  </span>
                </Link>
              </div>
              <div className="flex gap-3 mt-2">
                <StarRating rating={product.avg_score} />
                <span>{product.avg_score.toFixed(1)}</span>
                <span className="text-gray-400">({product.cnt})</span>
              </div>
            </div>
            <CTA
              to={`/products/${product.slug}`}
              variant="sky-shadow"
              id="view-product-button"
            >
              {buttonLabel}
            </CTA>
          </div>
          <div className="mt-6 hidden md:block">
            <p
              className={`whitespace-normal ${
                !isEmpty(tags) ? "line-clamp-2 " : "line-clamp-4"
              } truncate`}
            >
              {product.description}
            </p>
          </div>
        </div>
      </div>
      <div className="mt-6 md:hidden">
        <div className="overflow-hidden leading-tight">
          <p
            className={`whitespace-normal ${
              !isEmpty(tags) ? "line-clamp-2 " : "line-clamp-4"
            } truncate`}
          >
            {product.description}
          </p>
        </div>
      </div>
      <div className="flex space-x-3 items-center">
        {product.promo_text && (
          <div className="relative -ml-7 mt-4 bg-themeYellow text-darkGray rounded-r-3xl rounded-l-md text-xs py-2 pl-8 pr-4 font-semibold truncate">
            {product.promo_text}
          </div>
        )}
        {tags && (
          <div className="flex gap-6 mt-5">
            <div className="flex-grow flex flex-wrap gap-2">
              {tags.map(
                (
                  tag: { label: string; icon: JSX.ElementType },
                  index: number
                ) =>
                  tags.length < 3 ? (
                    <div key={index}>
                      <Tag
                        color="sky"
                        label={tag.label}
                        icon={tag.icon}
                        className="text-xs"
                      />
                    </div>
                  ) : (
                    <div key={index}>
                      <Tooltip size="small" position="top" text={tag.label}>
                        <div key={index}>
                          <Tag color="sky" label="" icon={tag.icon} />
                        </div>
                      </Tooltip>
                    </div>
                  )
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
