import { ChevronDownIcon, ChevronUpIcon } from "@heroicons/react/24/outline";
import { useNavigate, useSearchParams } from "@remix-run/react";
import dayjs from "dayjs";
import { get } from "lodash";
import { useState, type ReactNode, useCallback, useMemo } from "react";
import { Pagination } from "./intelligence/pagination.component";
import { FilterBar } from "./filter-bar.component";
import { Empty } from "./empty.component";

export type TableStateConfig = {
  pagination?: {
    useSearchParams: boolean;
    onChange?: (value: { page: number; pageSize: number }) => unknown;
    total: number;
    keys?: {
      page?: string;
      pageSize?: string;
    };
    defaults?: {
      page?: number;
      pageSize?: number;
    };
  };
  orderBy?: {
    useSearchParams: boolean;
    onChange?: (value: Record<string, string>) => unknown;
    keys?: {
      orderBy?: string;
    };
  };
  search?: {
    useSearchParams: boolean;
    onChange?: (value: string) => unknown;
    resetPageOnSearch?: boolean;
    inputPlaceholder?: string;
    keys?: {
      search?: string;
    };
  };
};

export type CrudTableColumn<T> = {
  name?: (keyof T & string) | string;
  label: string;
  type?: "date";
  renderer?: (value: T) => ReactNode;
  sortable?: boolean;
};

export function CrudTable<T extends { id: string }>({
  cols,
  data,
  onClickRow,
  showAddButton = true,
  tableStateConfig: stateConf,
}: {
  cols: CrudTableColumn<T>[];
  data: T[];
  onClickRow?: (value: T) => void;
  showAddButton?: boolean;
  tableStateConfig?: TableStateConfig;
}) {
  const navigate = useNavigate();
  onClickRow = onClickRow ?? ((row: T) => navigate(`./${row.id}`));
  const [searchParams, setSearchParams] = useSearchParams();

  // Sort logic (asc, desc, none)
  const [orderBy, setOrderBy] = useState<Record<string, string>>({});

  const handleOrderBy = (colName: string) => {
    const newOrderBy = { ...orderBy };
    if (!newOrderBy[colName]) {
      newOrderBy[colName] = "asc";
    } else if (newOrderBy[colName] === "asc") {
      newOrderBy[colName] = "desc";
    } else {
      delete newOrderBy[colName];
    }
    setOrderBy(newOrderBy);

    const orderByQuery = Object.entries(newOrderBy).map(
      ([key, value]) => `${key}:${value}`
    );
    if (stateConf?.orderBy?.useSearchParams) {
      setSearchParams(oldSearchParams => ({
        ...Object.fromEntries(oldSearchParams),
        [stateConf?.orderBy?.keys?.orderBy ?? "orderBy"]: orderByQuery,
      }));
    }
    if (stateConf?.orderBy?.onChange) {
      stateConf.orderBy.onChange(newOrderBy);
    }
  };

  const handleFilterTrigger = useCallback(
    (newSearchQuery?: string) => {
      if (stateConf?.search?.useSearchParams) {
        setSearchParams(oldSearchParams => ({
          ...Object.fromEntries(oldSearchParams),
          [stateConf?.search?.keys?.search ?? "search"]: newSearchQuery ?? "",
          page: stateConf?.search?.resetPageOnSearch
            ? "1"
            : oldSearchParams.get("page") ?? "1",
        }));
      }
      if (stateConf?.search?.onChange) {
        stateConf.search.onChange(newSearchQuery ?? "");
      }
    },
    [stateConf?.search, setSearchParams]
  );

  const page = useMemo(
    () =>
      Number(
        searchParams.get("page") ?? stateConf?.pagination?.defaults?.page ?? 1
      ),
    [searchParams, stateConf?.pagination?.defaults?.page]
  );

  const pageSize = useMemo(
    () =>
      Number(
        searchParams.get("pageSize") ??
          stateConf?.pagination?.defaults?.pageSize ??
          20
      ),
    [searchParams, stateConf?.pagination?.defaults?.pageSize]
  );

  const onPagination = useCallback(
    (newPage: number) => {
      if (stateConf?.pagination?.useSearchParams) {
        setSearchParams(oldSearchParams => ({
          ...Object.fromEntries(oldSearchParams),
          [stateConf?.pagination?.keys?.page ?? "page"]: String(
            newPage ?? page
          ),
          [stateConf?.pagination?.keys?.pageSize ?? "pageSize"]: String(
            oldSearchParams.get("pageSize") ?? pageSize
          ),
        }));
      }
      if (stateConf?.pagination?.onChange) {
        stateConf.pagination.onChange({ page, pageSize: Number(pageSize) });
      }
    },
    [page, pageSize, stateConf?.pagination, setSearchParams]
  );

  // Pagination logic
  const totalPages = useMemo(
    () =>
      stateConf?.pagination
        ? Math.ceil(stateConf.pagination.total / pageSize)
        : 0,
    [stateConf?.pagination, pageSize]
  );
  const pageNumbers = useMemo(
    () => Array.from({ length: totalPages }, (_, i) => i + 1),
    [totalPages]
  );
  const resultsText = useMemo(() => {
    if (!stateConf?.pagination) return "";
    // results will be the minimum between the pageSize and the remaining results
    const pageResults = Math.min(
      pageSize,
      stateConf.pagination.total + pageSize - page * pageSize
    );
    return `${pageResults} out of ${stateConf.pagination.total} results`;
  }, [stateConf?.pagination, pageSize, page]);

  return (
    <div className="mt-8 flow-root">
      <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
        {stateConf?.search !== undefined && (
          <FilterBar
            className="sm:px-6 lg:px-8 mb-2"
            inputPlaceholder={stateConf?.search?.inputPlaceholder}
            onFilter={handleFilterTrigger}
          />
        )}
        <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
          {data.length > 0 ? (
            <>
              <div className="overflow-hidden shadow ring-1 ring-black ring-opacity-5 sm:rounded-lg">
                <table className="min-w-full divide-y divide-gray-300">
                  <thead className="bg-gray-50">
                    <tr>
                      {cols.map(col => (
                        <th
                          scope="col"
                          className={`py-3.5 pl-4 pr-3 text-left text-sm font-semibold text-gray-900 sm:pl-6 ${
                            col.sortable ? "hover:cursor-pointer" : ""
                          }`}
                          key={col.label}
                          onClick={() =>
                            col.sortable && handleOrderBy(col.name!)
                          }
                        >
                          <div className="flex">
                            {col.label}
                            {col.sortable &&
                              orderBy.hasOwnProperty(col.name!) && (
                                <span className="ml-1">
                                  {orderBy[col.name!] === "asc" ? (
                                    <ChevronUpIcon className="h-5" />
                                  ) : (
                                    <ChevronDownIcon className="h-5" />
                                  )}
                                </span>
                              )}
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200 bg-white">
                    {data.map(d => (
                      <tr
                        key={d.id}
                        id={`row-${d.id}`}
                        onClick={() => {
                          onClickRow!(d);
                        }}
                        className="hover:cursor-pointer group"
                      >
                        {cols.map(col => {
                          let value: any = "";
                          if (col.renderer) value = col.renderer(d);
                          else if (col.name && col.type === "date") {
                            const date = get(d, col.name) as string;
                            value = date
                              ? dayjs(date).format("YYYY-MM-DD")
                              : "--";
                          } else {
                            value = col.name && (get(d, col.name) as any);
                          }
                          return (
                            <td
                              key={d.id + col.label}
                              id={`${d.id}-${col.label}`}
                              className="whitespace-nowrap py-4 pl-4 pr-3 text-sm font-medium text-gray-900 sm:pl-6 group-hover:bg-slate-50 truncate max-w-sm"
                            >
                              {value}
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {stateConf?.pagination && (
                <div className="flex justify-end mr-5">
                  <Pagination
                    resultsText={resultsText}
                    pageNumbers={pageNumbers}
                    currentPage={page}
                    totalPages={totalPages}
                    handleCallback={onPagination}
                  />
                </div>
              )}
            </>
          ) : (
            <Empty
              onClick={() => showAddButton && navigate(`./new`)}
              showIcon={true}
              label={`Nothing here yet${showAddButton ? ", click to add" : ""}`}
            />
          )}
        </div>
      </div>
    </div>
  );
}
