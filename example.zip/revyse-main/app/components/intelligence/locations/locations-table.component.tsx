import React, { useMemo } from "react";
import { Table } from "../table.component";
import {
  LocationPropertyType,
  type Location,
  LocationPropertyStage,
} from "@prisma/client";
import { map } from "lodash";
import { Link } from "@remix-run/react";

type TableItem = Location;

const columnRenders = {
  pmsId: {
    label: "PMS ID",
    name: "pms_id",
  },
  name: {
    label: "Location Name",
    name: "name",
  },
  city: {
    label: "City",
    name: "city",
  },
  state: {
    label: "State",
    name: "state",
  },
  region: {
    label: "Region",
    name: "region",
    renderer: (location: TableItem) => location.region ?? "--",
  },
  ownerName: {
    label: "Owner Name",
    name: "owner_name",
  },
  status: {
    label: "Status",
    name: "status",
  },
  uniCount: {
    label: "Unit Count",
    name: "unit_count",
  },
  propertyClass: {
    label: "Property Class",
    name: "class",
  },
  contractLineItems: {
    label: "Line Items",
    renderer: (
      location: TableItem & { _count: { contract_line_item_locations: number } }
    ) => (
      <div className="flex items-center space-x-2">
        <div className="font-light">
          {location._count.contract_line_item_locations}
        </div>
        <Link
          to={`/intelligence/${location.manager_account_id}/locations/${location.id}/assigned-vendors/`}
          onClick={e => e.stopPropagation()}
          className="font-medium underline text-sky-600"
        >
          {"See Full List"}
        </Link>
      </div>
    ),
  },
  address: {
    label: "Address",
    renderer: (location: TableItem) => (
      <div className="flex items-center space-x-2">
        <div className="whitespace-normal line-clamp-3 truncate">
          {[
            location.street_1,
            location.street_2,
            location.city,
            location.state,
            location.zip,
          ]
            .filter(Boolean)
            .join(", ")}
        </div>
      </div>
    ),
  },
  propertyType: {
    label: "Property Type",
    renderer: (location: TableItem) => (
      <div className="flex items-center space-x-2">
        <div className="whitespace-normal line-clamp-3 truncate">
          {(() => {
            switch (location.property_type) {
              case LocationPropertyType.ConventionalMultifamily:
                return "Conventional Multifamily";
              case LocationPropertyType.SelfStorage:
                return "Self Storage";
              case LocationPropertyType.OfficeCommercial:
                return "Office/Commercial";
              case LocationPropertyType.BuildToRent:
                return "Build-to-Rent";
              case LocationPropertyType.SingleFamily:
                return "Single Family";
              default:
                return location.property_type;
            }
          })()}
        </div>
      </div>
    ),
  },
  propertyStage: {
    label: "Property Stage",
    renderer: (location: TableItem) => (
      <div className="flex items-center space-x-2">
        <div className="whitespace-normal line-clamp-3 truncate">
          {location.property_stage === LocationPropertyStage.LeaseUp
            ? "Lease-Up"
            : location.property_stage}
        </div>
      </div>
    ),
  },
};

type TableColumn = keyof typeof columnRenders;

export function LocationsTable({
  items,
  onClickRow,
  showSelectBox = false,
  columnsToShow,
  disabledRows,
  onSelectRows,
}: {
  items: any[];
  onClickRow?: (value: TableItem) => any | void;
  showSelectBox?: boolean;
  columnsToShow: TableColumn[];
  disabledRows?: {
    id: string;
  }[];
  onSelectRows?: (selectedRows: string[]) => void;
}) {
  const cols = useMemo(() => {
    return columnsToShow.map(column => columnRenders[column]);
  }, [columnsToShow]);

  return (
    <Table
      cols={cols}
      data={items}
      showAddButton={false}
      showSelectBox={showSelectBox}
      onClickRow={onClickRow ?? (() => {})}
      disabledRows={disabledRows}
      onSelectRows={rows =>
        onSelectRows !== undefined && onSelectRows(map(rows, "id"))
      }
    />
  );
}
