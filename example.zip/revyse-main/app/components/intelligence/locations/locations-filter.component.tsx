import { LocationClass, LocationPropertyType } from "@prisma/client";
import React, { useCallback, useMemo, useState } from "react";
import { CTA } from "~/components/cta.component";
import { CrudCheckboxField } from "~/components/form/crud-form.component";
import { Modal } from "~/components/modal.component";
import { AutocompleteFilter } from "../autocomplete-filter.component";
import { difference } from "lodash";
import { type LocationsFilterType } from "~/services/location.service.server";
import { FilterTag } from "~/components/filter-tag.component";
import { Button } from "~/components/button.component";
import { FilterBar } from "~/components/filter-bar.component";

const unitCountFilter = [
  { value: "1-50", name: "1-50" },
  { value: "50-100", name: "50-100" },
  { value: "100-200", name: "100-200" },
  { value: "200-500", name: "200-500" },
  { value: "500", name: "500+" },
] as const;

const propertyClassFilter = [
  { name: "A+", value: LocationClass.APlus },
  { name: LocationClass.A, value: LocationClass.A },
  { name: LocationClass.B, value: LocationClass.B },
  { name: LocationClass.C, value: LocationClass.C },
  { name: LocationClass.D, value: LocationClass.D },
] as const;

const propertyTypeFilter = [
  {
    name: "Conventional Multifamily",
    value: LocationPropertyType.ConventionalMultifamily,
  },
  {
    name: LocationPropertyType.Affordable,
    value: LocationPropertyType.Affordable,
  },
  {
    name: LocationPropertyType.Student,
    value: LocationPropertyType.Student,
  },
  { name: LocationPropertyType.Senior, value: LocationPropertyType.Senior },
  { name: "Self Storage", value: LocationPropertyType.SelfStorage },
  {
    name: "Office/Commercial",
    value: LocationPropertyType.OfficeCommercial,
  },
  { name: "Build-to-Rent", value: LocationPropertyType.BuildToRent },
  { name: "Single Family", value: LocationPropertyType.SingleFamily },
  { name: LocationPropertyType.Other, value: LocationPropertyType.Other },
] as const;

const defaultSearchParams: LocationsFilterType = {
  query: "",
  unitCount: [],
  propertyClass: [],
  region: [],
  propertyType: [],
  owner: [],
};

export function LocationsFilter({
  initialSearchParams,
  onFilter,
  regionOptions,
  ownerOptions,
}: {
  initialSearchParams?: LocationsFilterType;
  onFilter: (searchParams: LocationsFilterType) => any;
  regionOptions: string[];
  ownerOptions: string[];
}) {
  const [searchParams, setSearchParams] = useState<LocationsFilterType>(
    initialSearchParams || defaultSearchParams
  );

  const [openFilteringModal, setOpenFilteringModal] = useState(false);

  const [regionInputValue, setRegionInputValue] = useState("");
  const [ownerInputValue, setOwnerInputValue] = useState("");

  const regionFilteredOptions = useMemo(() => {
    const filteredOptions = regionOptions.filter(option =>
      option.toLowerCase().includes(regionInputValue.toLowerCase())
    );
    return difference(filteredOptions, searchParams.region || []);
  }, [regionOptions, searchParams.region, regionInputValue]);

  const ownerFilteredOptions = useMemo(() => {
    const filteredOptions = ownerOptions.filter(option =>
      option.toLowerCase().includes(ownerInputValue.toLowerCase())
    );
    return difference(filteredOptions, searchParams.owner || []);
  }, [ownerOptions, searchParams.owner, ownerInputValue]);

  const filtersCount = useMemo(() => {
    return (
      (searchParams.unitCount ?? []).length +
      (searchParams.propertyClass ?? []).length +
      (searchParams.region ?? []).length +
      (searchParams.propertyType ?? []).length +
      (searchParams.owner ?? []).length
    );
  }, [searchParams]);

  const clearFilters = useCallback(() => {
    setSearchParams(defaultSearchParams);
    setOpenFilteringModal(false);
    onFilter(defaultSearchParams);
  }, [onFilter]);

  const renderSelectedFilters = useCallback(() => {
    const tags = [];
    for (const filterType in searchParams) {
      const typedFilterType = filterType as keyof LocationsFilterType;
      if (typedFilterType === "query") continue;

      const filterValues = searchParams[typedFilterType];
      if (!filterValues) continue;
      for (const filterValue of filterValues) {
        tags.push(
          <FilterTag
            key={`${typedFilterType}-${filterValue}`}
            text={filterValue}
            onRemove={() => {
              setSearchParams(old => ({
                ...old,
                [typedFilterType]: (old[typedFilterType] ?? []).filter(
                  v => v !== filterValue
                ),
              }));
              onFilter({
                ...searchParams,
                [typedFilterType]: searchParams[typedFilterType]?.filter(
                  value => value !== filterValue
                ),
              });
            }}
          />
        );
      }
    }

    return tags;
  }, [searchParams, onFilter]);

  return (
    <>
      <Modal
        isOpen={openFilteringModal}
        onClose={() => setOpenFilteringModal(false)}
        size="medium"
        manager={true}
      >
        <div className="p-2 lg:p-6">
          <h4 className="font-bold">Filter By</h4>
          <div className="divide divide-y divide-2">
            <div>
              <div className="my-4 font-semibold">Unit Count</div>
              <div className="flex justify-around">
                {unitCountFilter.map(option => (
                  <CrudCheckboxField
                    key={option.value}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: searchParams.unitCount?.includes(
                        option.value
                      ),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setSearchParams({
                          ...searchParams,
                          unitCount: [
                            ...(searchParams.unitCount || []),
                            option.value,
                          ],
                        });
                      } else {
                        setSearchParams({
                          ...searchParams,
                          unitCount: searchParams.unitCount?.filter(
                            value => value !== option.value
                          ),
                        });
                      }
                    }}
                  />
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Property Class</div>
              <div className="flex justify-around">
                {propertyClassFilter.map(option => (
                  <CrudCheckboxField
                    key={option.value}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: searchParams.propertyClass?.includes(
                        option.value
                      ),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setSearchParams({
                          ...searchParams,
                          propertyClass: [
                            ...(searchParams.propertyClass || []),
                            option.value,
                          ],
                        });
                      } else {
                        setSearchParams({
                          ...searchParams,
                          propertyClass: searchParams.propertyClass?.filter(
                            value => value !== option.value
                          ),
                        });
                      }
                    }}
                  />
                ))}
              </div>
            </div>

            <div>
              <div className="my-4 font-semibold">Regions</div>
              <AutocompleteFilter
                initialValue={regionInputValue}
                options={regionFilteredOptions}
                onFilterChange={setRegionInputValue}
                onAddTag={region => {
                  setSearchParams({
                    ...searchParams,
                    region: [...(searchParams.region ?? []), region],
                  });
                  setRegionInputValue("");
                }}
                onRemoveTag={region => {
                  setSearchParams({
                    ...searchParams,
                    region: searchParams.region?.filter(
                      value => value !== region
                    ),
                  });
                  setRegionInputValue("");
                }}
                selectedTags={searchParams.region || []}
                errorMessage={""}
                renderOption={region => region}
              />
            </div>
            <div>
              <div className="my-4 font-semibold">Property Type</div>
              <div className="grid grid-cols-3">
                {propertyTypeFilter.map(option => (
                  <CrudCheckboxField
                    key={option.value}
                    field={{
                      name: "filter_by",
                      value: option.value,
                      label: option.name,
                      errors: [],
                      description: "",
                      defaultChecked: searchParams.propertyType?.includes(
                        option.value
                      ),
                      type: "checkbox",
                    }}
                    onChange={evt => {
                      const checked = evt.target.checked;
                      if (checked) {
                        setSearchParams({
                          ...searchParams,
                          propertyType: [
                            ...(searchParams.propertyType || []),
                            option.value,
                          ],
                        });
                      } else {
                        setSearchParams({
                          ...searchParams,
                          propertyType: searchParams.propertyType?.filter(
                            value => value !== option.value
                          ),
                        });
                      }
                    }}
                  />
                ))}
              </div>
            </div>
            <div>
              <div className="my-4 font-semibold">Owner Name</div>
              <AutocompleteFilter
                initialValue={ownerInputValue}
                options={ownerFilteredOptions}
                onFilterChange={setOwnerInputValue}
                onAddTag={owner =>
                  setSearchParams({
                    ...searchParams,
                    owner: [...(searchParams.owner || []), owner],
                  })
                }
                onRemoveTag={owner =>
                  setSearchParams({
                    ...searchParams,
                    owner: searchParams.owner?.filter(value => value !== owner),
                  })
                }
                selectedTags={searchParams.owner || []}
                errorMessage={""}
                renderOption={owner => owner}
              />
            </div>
          </div>
          <div className="flex justify-end mt-8 items-center space-x-3">
            <button
              className="text-sky-500"
              onClick={() => {
                clearFilters();
              }}
            >
              Clear filters
            </button>
            <CTA
              variant="coral-shadow"
              onClick={() => {
                setOpenFilteringModal(false);
                onFilter(searchParams);
              }}
            >
              Show results
            </CTA>
          </div>
        </div>
      </Modal>
      <FilterBar
        inputPlaceholder="Search locations"
        onFilter={searchQuery => {
          setSearchParams({ ...searchParams, query: searchQuery });
          onFilter({ ...searchParams, query: searchQuery });
        }}
        filters={{
          onOpenFilteringModal: setOpenFilteringModal,
          filtersCount: filtersCount,
        }}
      />
      {filtersCount > 0 && (
        <div className="grid grid-cols-8 gap-2 my-6">
          {renderSelectedFilters()}
          <Button color="transparent" onClick={clearFilters}>
            Clear all filters
          </Button>
        </div>
      )}
    </>
  );
}
