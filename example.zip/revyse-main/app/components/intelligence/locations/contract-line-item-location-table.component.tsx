import React, { useMemo } from "react";
import type { TableColumn } from "../table.component";
import { Table } from "../table.component";
import {
  ContractLineItemLocationStatus,
  ContractStatus,
  LocationStatus,
  ContractLineItemStatus,
} from "@prisma/client";
import type {
  ContractLineItem,
  ContractLineItemFee,
  ContractLineItemLocation,
  ContractLineItemProduct,
  Product,
  Contract,
  Vendor,
  Fee,
  ManagerAccountVendor,
  Location,
  ManagerAccount,
} from "@prisma/client";
import dayjs from "dayjs";
import { isNil, map } from "lodash";
import type { SerializeFrom } from "@remix-run/node";
import {
  ContractLineItemPriceCadenceLabels,
  ContractPricingTypeLabels,
  LocationPropertyTypeLabels,
} from "~/utils/constants.utils";
import StatusChip from "~/components/status-chip.component";
import { RevysePencilIcon } from "~/components/revyse-pencil-icon.component";
import { Button } from "~/components/button.component";
import { canDoOnLocation } from "~/utils/location-permission.utils";
import {
  Permission,
  type PermissionUser,
} from "~/utils/intelligence-permission.utils";
import { Tooltip } from "~/components/tooltip.component";

type TableItem = SerializeFrom<
  ContractLineItemLocation & {
    contract_line_item: Omit<ContractLineItem, "price"> & {
      contract_line_item_products: (ContractLineItemProduct & {
        product: Product;
      })[];
      contract_line_item_fees: (ContractLineItemFee & {
        fee: Fee | null;
      })[];
      contract: Contract & {
        manager_account_vendor: ManagerAccountVendor & {
          vendor: Vendor;
        };
      };
      price_display?: string;
      price: number | null;
    };
    location: Location;
  }
>;

// When a contract is set to the status of “Canceled”,
// display the “Canceled” chip in the table in the line item status column, and gray out the line item row.
const shouldShowContractLineItemAsActive = (row: TableItem) => {
  return (
    row.status === ContractLineItemLocationStatus.Active &&
    row.contract_line_item.contract.status !== ContractStatus.Canceled &&
    row.location.status !== LocationStatus.Disposed
  );
};

const shouldShowContractLineItemAsPending = (row: TableItem) => {
  return (
    row.status === ContractLineItemLocationStatus.Pending &&
    row.contract_line_item.contract.status !== ContractStatus.Canceled &&
    row.location.status !== LocationStatus.Disposed
  );
};

const shouldShowEditButton = (
  row: TableItem,
  user?: PermissionUser,
  account?: SerializeFrom<ManagerAccount>
) => {
  const showEditButton =
    row.contract_line_item.contract.status !== ContractStatus.Canceled &&
    row.contract_line_item.status !== ContractLineItemStatus.Canceled &&
    row.location.status !== LocationStatus.Disposed;

  // If the user and account are provided and the line item is managed by the Company Account
  // then check for ManageCompanyLevelContractLineItemStatus permission,
  // otherwise don't check it and perform logic based only in the status
  if (user && account && !row.contract_line_item.contract.location_id) {
    const userCanChangeLineItemStatus = canDoOnLocation(
      user,
      account,
      { id: row.location_id },
      Permission.ManageCompanyLevelContractLineItemStatus
    );
    return userCanChangeLineItemStatus && showEditButton;
  }
  return showEditButton;
};

const columnRenders: Record<string, TableColumn<TableItem>> = {
  vendorName: {
    label: "Vendor",
    name: "contract_line_item.contract.vendor.name",
  },
  contractLineItemName: {
    label: "Line Item",
    renderer: (contractLineItemLocation: TableItem) => (
      <span className="font-normal block truncate [max-width:28ch]">
        {contractLineItemLocation.contract_line_item.name}
      </span>
    ),
  },
  contractStatus: {
    label: "Contract Status",
    name: "contract_line_item.contract.status",
  },
  contractLineItemStatus: {
    label: "Status",
    renderer: (contractLineItemLocation: TableItem) => (
      <div className="flex flex-col justify-center items-center w-min">
        {shouldShowContractLineItemAsPending(contractLineItemLocation) ? (
          <Tooltip
            position="top"
            text="This location’s services are pending cancellation."
          >
            <StatusChip color="yellow" label="Pending" />
          </Tooltip>
        ) : (
          <StatusChip
            color={
              shouldShowContractLineItemAsActive(contractLineItemLocation)
                ? "green"
                : "red"
            }
            label={
              shouldShowContractLineItemAsActive(contractLineItemLocation)
                ? "Active"
                : "Canceled"
            }
          />
        )}
        {(contractLineItemLocation.status ===
          ContractLineItemLocationStatus.Canceled ||
          contractLineItemLocation.contract_line_item.contract.status ===
            ContractStatus.Canceled) &&
          (contractLineItemLocation.canceled_at ||
            contractLineItemLocation.contract_line_item.contract
              .canceled_at) && (
            <div className="text-xs mt-2">
              {contractLineItemLocation.canceled_at
                ? dayjs
                    .utc(contractLineItemLocation.canceled_at)
                    .format("MMM D, YYYY")
                : dayjs
                    .utc(
                      contractLineItemLocation.contract_line_item.contract
                        .canceled_at
                    )
                    .format("MMM D, YYYY")}
            </div>
          )}
      </div>
    ),
  },
  vendorNameWithContractName: {
    label: "Vendor (Contract)",
    renderer: (contractLineItemLocation: TableItem) => (
      <span>
        {
          contractLineItemLocation.contract_line_item.contract
            .manager_account_vendor.vendor.name
        }{" "}
        <br />
        <span className="font-normal block truncate [max-width:28ch]">
          ({contractLineItemLocation.contract_line_item.contract.name})
        </span>
      </span>
    ),
  },
  productsAndFees: {
    label: "Products or Fees",
    renderer: (contractLineItemLocation: TableItem) => (
      <div className="flex flex-col">
        <div>
          {contractLineItemLocation?.contract_line_item
            .contract_line_item_products.length > 0 ? (
            <>
              <div>Products:</div>
              {contractLineItemLocation?.contract_line_item.contract_line_item_products.map(
                product => (
                  <div className="font-light" key={product.id}>
                    {product.product.title}
                  </div>
                )
              )}
            </>
          ) : null}
          {contractLineItemLocation?.contract_line_item.contract_line_item_fees
            .length > 0 ? (
            <>
              <div>Fees and other charges:</div>
              {contractLineItemLocation?.contract_line_item.contract_line_item_fees.map(
                fee => (
                  <div className="font-light" key={fee.id}>
                    {fee.fee?.name}
                  </div>
                )
              )}
            </>
          ) : null}
        </div>
      </div>
    ),
  },
  price: {
    label: "Price Value",
    renderer: (contractLineItemLocation: TableItem) => (
      <div className="flex items-center space-x-2">
        <div className="font-light">
          {!isNil(contractLineItemLocation?.contract_line_item.price) ? (
            contractLineItemLocation?.contract_line_item
              ?.contract_line_item_products.length > 0 ||
            contractLineItemLocation?.contract_line_item
              ?.contract_line_item_fees.length > 0 ? (
              <div>
                <div className="text-md font-semibold">
                  ${contractLineItemLocation?.contract_line_item?.price} /{" "}
                  {contractLineItemLocation?.contract_line_item?.cadence
                    ? ContractLineItemPriceCadenceLabels[
                        contractLineItemLocation?.contract_line_item?.cadence
                      ]
                    : ""}{" "}
                  /{" "}
                  {contractLineItemLocation?.contract_line_item?.pricing_type
                    ? ContractPricingTypeLabels[
                        contractLineItemLocation.contract_line_item.pricing_type
                      ]
                    : ""}
                </div>
                {contractLineItemLocation?.contract_line_item
                  ?.contract_line_item_products.length +
                  contractLineItemLocation?.contract_line_item
                    ?.contract_line_item_fees.length >
                  1 && (
                  <div>
                    {contractLineItemLocation?.contract_line_item?.contract_line_item_products.map(
                      product => (
                        <div key={product.id}>
                          {product.product.title}: <b>${product.price}</b>{" "}
                        </div>
                      )
                    )}
                    {contractLineItemLocation?.contract_line_item?.contract_line_item_fees.map(
                      fee => (
                        <div key={fee.id}>
                          {fee.fee?.name}: <b>${fee.price}</b>{" "}
                        </div>
                      )
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div>$0</div>
            )
          ) : (
            <div>
              {contractLineItemLocation?.contract_line_item?.price_display}
            </div>
          )}
        </div>
      </div>
    ),
  },
  currentTermEnds: {
    name: "current_term_end_date",
    label: "Current Term Ends",
    renderer: (contractLineItemLocation: TableItem) => {
      if (
        !shouldShowContractLineItemAsActive(contractLineItemLocation) &&
        !shouldShowContractLineItemAsPending(contractLineItemLocation)
      ) {
        return <></>;
      }
      const displayedDate =
        contractLineItemLocation.expires_at ??
        contractLineItemLocation?.contract_line_item.contract
          .current_term_end_date ??
        undefined;

      return (
        <div
          className={
            dayjs.utc(displayedDate).toDate() < new Date() ? "text-red-500" : ""
          }
        >
          {displayedDate
            ? dayjs.utc(displayedDate).format("MMM D, YYYY")
            : "No Data"}
        </div>
      );
    },
    sortable: true,
  },
  locationName: {
    label: "Location Name",
    name: "location.name",
  },
  locationAddress: {
    label: "Address",
    columnClassName: "font-normal",
    renderer: (contractLineItemLocation: TableItem) => (
      <div>
        {[
          contractLineItemLocation.location.city,
          contractLineItemLocation.location.state,
        ].join(", ")}
      </div>
    ),
  },
  locationUnitCount: {
    label: "Unit Count",
    name: "location.unit_count",
    columnClassName: "font-normal",
  },
  locationPropertyType: {
    label: "Property Type",
    name: "location.property_type",
    columnClassName: "font-normal",
    renderer: (contractLineItemLocation: TableItem) => (
      <div>
        {
          LocationPropertyTypeLabels[
            contractLineItemLocation.location.property_type
          ]
        }
      </div>
    ),
  },
};

type LocationContractLineItemsTableColumn = keyof typeof columnRenders;

export function LocationContractLineItemsTable({
  items,
  onClickRow,
  onClickEdit,
  showSelectBox = false,
  columnsToShow,
  onSelectRows,
  onOrderBy,
  user,
  account,
}: {
  items: TableItem[];
  onClickEdit?: (id: string) => unknown;
  onClickRow?: (value: TableItem) => any | void;
  showSelectBox?: boolean;
  columnsToShow: LocationContractLineItemsTableColumn[];
  onSelectRows?: (selectedRows: string[]) => void;
  onOrderBy?: (value: Record<string, string>) => void;
  user?: PermissionUser;
  account?: SerializeFrom<ManagerAccount>;
}) {
  const cols = useMemo(() => {
    let result = columnsToShow.map(column => columnRenders[column]);
    if (onClickEdit) {
      result.push({
        label: "",
        renderer: (contractLineItemLocation: TableItem) =>
          shouldShowEditButton(contractLineItemLocation, user, account) ? (
            <div className="flex items-center h-full">
              <Button
                id={`editLocation-${contractLineItemLocation.id}`}
                color="transparent"
                onClick={e => {
                  e.stopPropagation();
                  onClickEdit(contractLineItemLocation.id);
                }}
              >
                <RevysePencilIcon className="h-5" />
              </Button>
            </div>
          ) : (
            <></>
          ),
      });
    }
    return result;
  }, [columnsToShow, onClickEdit, account, user]);

  const disabledRows = useMemo(() => {
    return items.filter(
      item =>
        !shouldShowContractLineItemAsActive(item) &&
        !shouldShowContractLineItemAsPending(item)
    );
  }, [items]);

  return (
    <Table
      cols={cols}
      data={items}
      showAddButton={false}
      showSelectBox={showSelectBox}
      onClickRow={onClickRow ?? undefined}
      disabledRows={disabledRows}
      onSelectRows={rows =>
        onSelectRows !== undefined && onSelectRows(map(rows, "id"))
      }
      alignment="middle"
      onOrderBy={onOrderBy}
      rowIdPrefix="contract-line-item-location"
    />
  );
}
