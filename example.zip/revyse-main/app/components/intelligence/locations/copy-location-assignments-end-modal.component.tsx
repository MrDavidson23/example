import React from "react";
import { Modal } from "~/components/modal.component";
import { CTA } from "~/components/cta.component";
import { CheckCircleIcon } from "@heroicons/react/24/outline";

export function CopyLocationAssignmentsEndModal({
  copiedItemsCount,
  toLocationsCount,
  locationName,
  isOpen,
  onClose,
  onGoBack,
}: {
  copiedItemsCount: number;
  toLocationsCount: number;
  locationName: string;
  isOpen: boolean;
  onClose: (closed: boolean) => void;
  onGoBack: () => void;
}) {
  return (
    <Modal isOpen={isOpen} onClose={onClose} manager={true} size="medium-small">
      <div className="w-full p-5">
        <h3 className="font-bold">Success!</h3>
        <div className="flex items-center mt-5">
          <CheckCircleIcon className="text-green-600 h-10 mr-3" />
          <span className="font-bold">{copiedItemsCount}</span>
          &nbsp;line items copied to
          <span className="font-bold">&nbsp;{toLocationsCount}</span>
          &nbsp;locations
        </div>
        <div className="flex justify-center mt-5 w-full flex-wrap-reverse md:flex-nowrap gap-y-2">
          <CTA onClick={onGoBack} variant="sky" className="mx-2">
            Back to {locationName}
          </CTA>
          <CTA onClick={onClose as any} className="mx-2">
            Copy to More Locations
          </CTA>
        </div>
      </div>
    </Modal>
  );
}
