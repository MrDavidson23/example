import React, { useEffect, useMemo } from "react";
import { Modal } from "~/components/modal.component";
import { CTA } from "~/components/cta.component";
import type {
  Contract,
  ContractLineItem,
  ContractLineItemLocation,
  Location,
} from "@prisma/client";
import { ContractLineItemLocationStatus } from "@prisma/client";
import { useFetcher } from "@remix-run/react";
import type { SerializeFrom } from "@remix-run/node";
import { Button } from "~/components/button.component";
import { ArrowLeftIcon } from "@heroicons/react/24/outline";
import {
  CrudDateField,
  CrudSelectField,
} from "~/components/form/crud-form.component";
import type { action } from "~/routes/intelligence.$id.line-item.$contract_line_item_id.location.$location_id.status";
import dayjs from "dayjs";

type ModalResource = SerializeFrom<
  ContractLineItemLocation & {
    contract_line_item: Omit<ContractLineItem, "price"> & {
      contract: Contract;
      price: number | null;
    };
  }
>;

export function LocationContractLineItemEditStatusModal({
  contractLineItemLocation,
  location,
  isOpen,
  onClose,
}: {
  contractLineItemLocation: ModalResource;
  location: SerializeFrom<Location>;
  isOpen: boolean;
  onClose: (closed: boolean) => void;
}) {
  const [newStatus, setNewStatus] =
    React.useState<ContractLineItemLocationStatus>(
      contractLineItemLocation.status
    );

  const fetcher = useFetcher<typeof action>();

  useEffect(() => {
    if (fetcher.data?.success) {
      onClose(true);
    }
  }, [fetcher, onClose]);

  const actionRoute = `/intelligence/${location.manager_account_id}/line-item/${contractLineItemLocation.contract_line_item_id}/location/${location.id}/status`;

  const dateActiveDefaultValue = useMemo(() => {
    const dateToUse =
      fetcher.data?.fields.date ??
      contractLineItemLocation.expires_at ??
      contractLineItemLocation.contract_line_item.contract
        .current_term_end_date ??
      undefined;

    if (dateToUse) {
      return dayjs.utc(dateToUse).format("YYYY-MM-DD");
    }
    return dateToUse;
  }, [fetcher.data, contractLineItemLocation]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} manager={true} size="medium-small">
      <div className="px-2 lg:px-6 py-2 lg:pt-4">
        <h1 className="text-2xl [text-wrap:pretty]">
          Change the status of this line item for {location.name}
        </h1>
        <div className="[text-wrap:pretty] mb-4">
          To mark the <b>{contractLineItemLocation.contract_line_item.name}</b>{" "}
          line item as canceled for <b>{location.name}</b>, set the status to
          Canceled. If the line item is active, set the status to Active.
        </div>
        <fetcher.Form method="POST" action={actionRoute}>
          <CrudSelectField
            field={{
              name: "status",
              label: "Status",
              type: "select",
              options: [ContractLineItemLocationStatus.Active, ContractLineItemLocationStatus.Canceled].map(
                status => ({
                  label: status,
                  value: status,
                })
              ),
              errors: [],
              defaultValue:
                fetcher.data?.fields.status ?? contractLineItemLocation.status,
            }}
            onChange={e =>
              setNewStatus(e.target.value as ContractLineItemLocationStatus)
            }
          />
          {newStatus === ContractLineItemLocationStatus.Canceled && (
            <CrudDateField
              field={{
                name: "date",
                label: "Cancellation date (optional)",
                type: "text",
                errors: [],
                defaultValue:
                  fetcher.data?.fields.date ?? dayjs.utc().format("YYYY-MM-DD"),
              }}
            />
          )}
          {newStatus === ContractLineItemLocationStatus.Active && (
            <CrudDateField
              field={{
                name: "date",
                label: "Current Term End date",
                type: "text",
                errors: [],
                defaultValue: dateActiveDefaultValue,
              }}
            />
          )}
          <div className="flex justify-between mt-5 w-full">
            <Button onClick={() => onClose(true)} color="transparent">
              <ArrowLeftIcon className="h-5 mr-2" /> Back
            </Button>
            <CTA
              id="save-contract-lineItem-location"
              className="m-2"
              type="submit"
            >
              Submit
            </CTA>
          </div>
        </fetcher.Form>
      </div>
    </Modal>
  );
}
