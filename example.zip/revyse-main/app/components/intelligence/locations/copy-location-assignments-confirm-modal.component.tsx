import React from "react";
import { Modal } from "~/components/modal.component";
import { CTA } from "~/components/cta.component";
import { Button } from "~/components/button.component";
import { LocationContractLineItemsTable } from "./contract-line-item-location-table.component";

export function CopyLocationAssignmentsConfirmModal({
  itemsToCopy,
  isOpen,
  onClose,
  onConfirm,
}: {
  itemsToCopy: any[];
  isOpen: boolean;
  onClose: (closed: boolean) => void;
  onConfirm: () => void;
}) {
  return (
    <Modal isOpen={isOpen} onClose={onClose} manager={true} size="medium">
      <div className="p-2 lg:p-6">
        <h4 className="font-bold">
          Do you want the selected line items copied to another location(s)?
        </h4>
        <div className="mt-5">
          <span>
            If the selected line items and products look correct, click “Yes,
            continue”. In the next step, you’ll select the location(s) to assign
            this configuration to.
          </span>
        </div>
        <div className="mt-5">
          <div className="mb-3">
            <span className="font-semibold">
              Selected products and line items:
            </span>
          </div>
          <LocationContractLineItemsTable
            items={itemsToCopy}
            columnsToShow={[
              "vendorNameWithContractName",
              "productsAndFees",
              "contractLineItemName",
            ]}
          />
        </div>
        <div className="flex justify-end mt-5">
          <Button
            onClick={() => onClose(true)}
            color="transparent"
            className="text-gray-600"
            id="cancel"
          >
            No, thanks
          </Button>
          <CTA onClick={onConfirm} className="ml-3" id="continue">
            Yes, continue
          </CTA>
        </div>
      </div>
    </Modal>
  );
}
