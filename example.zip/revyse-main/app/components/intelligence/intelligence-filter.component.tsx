import React, { useCallback, useMemo } from "react";
import { FilterBar, type FilterBarProps } from "../filter-bar.component";
import {
  FiltersModal,
  type ModalFieldFilter,
  type ModalFilters,
} from "./filters-modal.component";
import { isEmpty, pick } from "lodash";
import { useSearchParams } from "@remix-run/react";
import { updateSearchParams } from "~/utils/filtering.utils";

export function IntelligenceFilter({
  modalFilters,
  currentFilters: currentFiltersProp,
  filterBar,
  handleOnSearchParams,
  extraFiltersOnFilter,
  onFilter,
}: {
  modalFilters?: ModalFieldFilter[];
  currentFilters?: ModalFilters;
  handleOnSearchParams?: boolean;
  extraFiltersOnFilter?: ModalFilters;
  filterBar?: Partial<FilterBarProps>;
  onFilter?: ({
    searchQuery,
    filters,
  }: {
    searchQuery?: string;
    filters?: ModalFilters;
  }) => void;
}) {
  const [filterModalOpen, setFilterModalOpen] = React.useState(false);

  const [searchParams, setSearchParams] = useSearchParams();

  const currentFilters = useMemo(
    () =>
      pick(
        currentFiltersProp ?? Object.fromEntries(searchParams.entries()),
        modalFilters?.map(f => f.name) ?? []
      ),
    [currentFiltersProp, searchParams, modalFilters]
  );

  const filtersCount = useMemo(
    () =>
      Object.values(currentFilters)
        .flat()
        .filter(v => !isEmpty(v)).length,
    [currentFilters]
  );

  const handleFilterSetSearchParams = useCallback(
    ({
      filters,
      searchQuery,
    }: {
      filters?: ModalFilters;
      searchQuery?: string;
    }) => {
      setSearchParams(oldSearchParams => {
        if (searchQuery !== undefined) {
          updateSearchParams(oldSearchParams, {
            searchQuery,
            ...extraFiltersOnFilter,
          });
        }

        if (filters !== undefined) {
          updateSearchParams(oldSearchParams, {
            ...filters,
            ...extraFiltersOnFilter,
          });
        }

        return oldSearchParams;
      });
    },
    [setSearchParams, extraFiltersOnFilter]
  );

  const handleModalFilter = useCallback(
    (filters: ModalFilters) => {
      onFilter?.({ filters });
      if (handleOnSearchParams) {
        handleFilterSetSearchParams({ filters });
      }
    },
    [onFilter, handleOnSearchParams, handleFilterSetSearchParams]
  );

  const handleSearchBarFilter = useCallback(
    (searchQuery: string) => {
      onFilter?.({ searchQuery });
      if (handleOnSearchParams) {
        handleFilterSetSearchParams({ searchQuery });
      }
    },
    [onFilter, handleFilterSetSearchParams, handleOnSearchParams]
  );

  return (
    <>
      {filterModalOpen && modalFilters && (
        <FiltersModal
          fieldFilters={modalFilters}
          onFilter={handleModalFilter}
          open={filterModalOpen}
          onClose={() => setFilterModalOpen(false)}
          currentFilters={currentFilters}
        />
      )}
      {filterBar && (
        <FilterBar
          {...filterBar}
          defaultSearchQuery={currentFilters?.searchQuery ?? ""}
          onFilter={handleSearchBarFilter}
          filters={
            modalFilters
              ? {
                  onOpenFilteringModal: () => setFilterModalOpen(true),
                  filtersCount,
                }
              : undefined
          }
        />
      )}
    </>
  );
}
