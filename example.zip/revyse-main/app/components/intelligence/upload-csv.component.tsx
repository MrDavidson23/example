import { useFetcher } from "@remix-run/react";
import { CTA } from "../cta.component";
import { useState } from "react";
import csvToJson from "csvtojson";
import { ArrowDownTrayIcon } from "@heroicons/react/24/outline";
import type { action as utilitiesAction } from "../../routes/admin.utilities";
import type { action as locationsAction } from "../../routes/intelligence.$id.locations";

export function UploadCSVForm({
  actionUrl,
  template,
  requiredHeaders,
  optionalHeaders,
}: {
  actionUrl: string;
  template: string;
  requiredHeaders?: string;
  optionalHeaders?: string;
}) {
  const [importFile, setImportFile] = useState<File>();
  const fetcher = useFetcher<typeof utilitiesAction | typeof locationsAction>();

  const onFileChange = (e: React.FormEvent<HTMLInputElement>) => {
    if (e?.currentTarget?.files && e.currentTarget.files.length > 0) {
      setImportFile(e.currentTarget.files[0]);
    }
  };

  const readFileData = async () => {
    if (!importFile) {
      return "";
    }
    let formData = "";

    const readerPromise = new Promise(resolve => {
      const reader = new FileReader();

      reader.onload = async (e: ProgressEvent<FileReader>) => {
        const csvData = e.target?.result;

        if (!csvData || typeof csvData !== "string") {
          return;
        }

        const jsonData = await csvToJson().fromString(csvData);
        formData = JSON.stringify(jsonData);
        resolve(null);
      };
      reader.readAsText(importFile);
    });

    await readerPromise;
    return formData;
  };

  const onDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    if (e?.dataTransfer?.files && e.dataTransfer.files.length > 0) {
      setImportFile(e.dataTransfer.files[0]);
    }
  };

  return (
    <fetcher.Form
      method="post"
      action={actionUrl}
      encType="multipart/form-data"
    >
      <h1 className="text-xl font-bold text-blue md:text-2xl">Upload CSV</h1>
      <p className="text-base lg:text-lg font-light text-gray-500">
        Select file:
      </p>
      <div
        className="flex items-center justify-center w-full"
        onDrop={onDrop}
        onDragOver={e => e.preventDefault()}
      >
        <label
          htmlFor="dropzone-file"
          className="flex flex-col items-center justify-center w-full h-64 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50"
        >
          <div className="flex flex-col items-center justify-center pt-5 pb-6">
            <svg
              aria-hidden="true"
              className="w-10 h-10 mb-3 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
              ></path>
            </svg>
            {importFile ? (
              <div className="mb-2 text-sm text-gray-500">
                {importFile.name}
              </div>
            ) : (
              <p className="mb-2 text-sm text-gray-500">
                <span className="font-semibold">Click to upload</span> or drag
                and drop
              </p>
            )}
            <p className="text-xs text-gray-500">CSV</p>
          </div>
          <input
            onChange={onFileChange}
            name="csv_locations"
            id="dropzone-file"
            type="file"
            accept=".csv"
            className="hidden"
          />
        </label>
      </div>
      <p className="text-sm lg:text-md font-light text-gray-500 my-5">
        <>
          <b className="text-red-500">*</b> File headers:
          <ul className="ml-5">
            {requiredHeaders && (
              <li>
                <b className="text-red-500">Required</b>: {requiredHeaders}
              </li>
            )}
            {optionalHeaders && (
              <li>
                <b>Optional</b>: {optionalHeaders}
              </li>
            )}
          </ul>
        </>
      </p>
      <div className="flex justify-end space-x-8 items-center mt-4">
        <a
          href={template}
          target="_blank"
          rel="noreferrer"
          download={true}
          className="text-sky-500"
        >
          <div className="flex">
            <ArrowDownTrayIcon className="h-5 mr-1" />
            Download Template
          </div>
        </a>
        <CTA
          className={`${
            fetcher.state === "submitting" ? "animate-bounce" : ""
          }`}
          variant="sky-shadow"
          onClick={async () => {
            if (importFile) {
              const formData = await readFileData();
              fetcher.submit(
                {
                  intent: "uploadCSV",
                  formData,
                },
                {
                  method: "post",
                  action: actionUrl,
                  encType: "multipart/form-data",
                }
              );
            }
          }}
          disabled={fetcher.state === "submitting"}
        >
          {fetcher.state === "submitting" ? "Uploading..." : "Upload File"}
        </CTA>
      </div>
    </fetcher.Form>
  );
}
