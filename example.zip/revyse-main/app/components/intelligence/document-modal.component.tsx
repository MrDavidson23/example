import type {
  File as PrismaFile,
  ManagerAccountVendorDocumentType,
} from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { useCallback, useEffect, useMemo, useState } from "react";
import { CTA } from "~/components/cta.component";
import FileUploadZone from "~/components/file-upload-zone.component";
import {
  CrudSelectField,
  CrudTextField,
} from "~/components/form/crud-form.component";
import { Modal } from "~/components/modal.component";
import { ManagerAccountVendorDocumentTypeLabels } from "~/utils/constants.utils";

const MB = 1024 * 1024;
const MAX_BYTE_LIMIT = 60 * MB;

function DocumentModal({
  isOpen,
  onClose,
  onChange,
  document,
  modalType = "vendor",
  title,
  buttonLabel,
  description,
}: {
  isOpen: boolean;
  document?: {
    id?: string;
    name?: string | null;
    type?: ManagerAccountVendorDocumentType | null;
    created_at?: string | Date;
    file?: SerializeFrom<PrismaFile> | null;
    new_file?: File;
  };
  onClose: (closed: boolean) => void;
  onChange: ({
    id,
    name,
    type,
    file,
  }: {
    id: string | undefined;
    name?: string;
    type?: ManagerAccountVendorDocumentType;
    file?: File;
  }) => void;
  modalType?: "contract" | "vendor" | "location";
  title: string;
  buttonLabel: string;
  description?: string;
}) {
  const [name, setName] = useState<string | undefined>(
    document?.name ?? undefined
  );

  const [type, setType] = useState<
    ManagerAccountVendorDocumentType | undefined
  >(document?.type ?? undefined);
  const [file, setFile] = useState<File | undefined>(
    document?.new_file ?? undefined
  );
  const [errors, setErrors] = useState<string[]>([]);

  const currentFileName = useMemo(
    () => file?.name ?? document?.new_file?.name ?? document?.file?.title,
    [document, file]
  );

  const handleOnClose = useCallback(() => {
    setName(undefined);
    setType(undefined);
    setFile(undefined);
    setErrors([]);
    onClose(false);
  }, [onClose]);

  const handleOnSave = useCallback(() => {
    setErrors([]);
    if (file || currentFileName) {
      onChange({
        id: document?.id,
        name: name || currentFileName,
        type,
        file,
      });

      handleOnClose();
    } else {
      setErrors(["Please upload a file"]);
    }
  }, [
    name,
    type,
    file,
    onChange,
    document?.id,
    currentFileName,
    handleOnClose,
  ]);

  useEffect(() => {
    setName(document?.name ?? undefined);
    setType(document?.type ?? undefined);
    setFile(document?.new_file ?? undefined);
  }, [document]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} manager={true}>
      <div className="p-3">
        <h1 className="text-xl">{title}</h1>
        {description && <div>{description}</div>}
        <div className="mt-5">
          <CrudTextField
            field={{
              name: "file_name",
              label:
                modalType == "contract" ? "Contract Name" : "Document Name",
              type: "text",
              placeholder: `File Name`,
              defaultValue: document?.name || undefined,
              onChange: e => {
                setName(e.target.value);
              },
              errors: [],
              maxCharacters: 50,
            }}
          />
        </div>
        {modalType == "vendor" && (
          <div className="mt-5">
            <CrudSelectField
              field={{
                name: "file_type",
                label: "Document Type",
                type: "select",
                options: Object.entries(
                  ManagerAccountVendorDocumentTypeLabels
                ).map(([key, value]) => ({ value: key, label: value })),
                defaultValue: document?.type || undefined,
                errors: [],
              }}
              onChange={e => {
                setType(e.target.value as ManagerAccountVendorDocumentType);
              }}
            />
          </div>
        )}
        <div className="mt-5">
          <label className="block text-sm font-medium leading-6 text-gray-900 mb-2">
            Upload File
          </label>
          <FileUploadZone
            onFileChange={setFile}
            currentFileName={currentFileName}
            errors={errors}
            maxFileSize={MAX_BYTE_LIMIT}
            multiple={false}
          />
        </div>
        <div className="flex justify-end mt-8 items-center space-x-3">
          <button className="text-sky-500" onClick={handleOnClose}>
            Cancel
          </button>
          <CTA variant="coral-shadow" onClick={handleOnSave} id="save-document">
            {buttonLabel}
          </CTA>
        </div>
      </div>
    </Modal>
  );
}

export default DocumentModal;
