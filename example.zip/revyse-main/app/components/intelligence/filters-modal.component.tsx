import type { ChangeEvent } from "react";
import React, { useCallback, useMemo, useState } from "react";
import { CTA } from "~/components/cta.component";
import {
  CrudCheckboxField,
  CrudDateField,
  CrudSelectField,
  CrudTextField,
} from "~/components/form/crud-form.component";
import { Modal } from "~/components/modal.component";
import { isEmpty } from "lodash";
import { XMarkIcon } from "@heroicons/react/24/outline";

// Separator when multiple values are selected
// e.g. for multi-select the value will be "value1,value2,value3"
export const MULTIPLE_FILTER_SEPARATOR = ",";

// Fields definition for the filter modal
export type ModalFieldFilter = {
  name: string;
  label: string;
  defaultValue?: string;
} & (
  | {
      type: "Text" | "Number" | "Date";
    }
  | {
      type: "DateRange";
    }
  | {
      type: "NumberRange";
      startLabel?: string;
      endLabel?: string;
    }
  | {
      type: "Toggle";
    }
  | {
      type: "MultiAutocomplete" | "MultiSelect" | "Autocomplete" | "Select";
      options: { value: string; label: string }[];
    }
);

export type ModalFieldFilterValue = ModalFieldFilter["defaultValue"];

export type ModalFilters = Record<string, ModalFieldFilterValue>;

export type FiltersModalProps = {
  fieldFilters: ModalFieldFilter[];
  currentFilters?: ModalFilters;
  onFilter: (values: ModalFilters) => unknown;
  open: boolean;
  onClose: () => unknown;
};

export function FiltersModal({
  fieldFilters,
  currentFilters = {},
  onFilter,
  open,
  onClose,
}: FiltersModalProps) {
  const [filterValues, setFilterValues] = useState<ModalFilters>(
    fieldFilters.reduce((acc, field) => {
      if (currentFilters && currentFilters[field.name]) {
        acc[field.name] = currentFilters[field.name];
      } else if (field.defaultValue) {
        acc[field.name] = field.defaultValue;
      } else {
        acc[field.name] = undefined;
      }
      return acc;
    }, {} as ModalFilters)
  );

  const clearFilters = useCallback(() => {
    onClose();
    onFilter(
      fieldFilters.reduce((acc, field) => {
        acc[field.name] = undefined;
        return acc;
      }, {} as ModalFilters)
    );
  }, [onFilter, fieldFilters, onClose]);

  const onFilterChange = useCallback(
    (field: ModalFieldFilter, newValue: ModalFieldFilterValue) => {
      setFilterValues(oldValues => ({
        ...oldValues,
        [field.name]: !isEmpty(newValue) ? newValue : undefined,
      }));
    },
    []
  );

  return (
    <>
      <Modal isOpen={open} onClose={onClose} size="medium" manager={true}>
        <div className="p-2 lg:p-6">
          <h4 className="font-bold">Filter By</h4>
          <div className="divide divide-y divide-2 gap-y-3 mt-3">
            {fieldFilters.map(field => (
              <FieldFilterRenderer
                key={field.name}
                field={field}
                onChange={onFilterChange}
                value={filterValues[field.name]}
              />
            ))}
          </div>
        </div>
        <div className="flex justify-end mt-8 items-center gap-x-3">
          <button className="text-sky-500" onClick={clearFilters}>
            Clear filters
          </button>
          <CTA
            variant="coral-shadow"
            onClick={() => {
              onClose();
              onFilter(filterValues);
            }}
          >
            Show results
          </CTA>
        </div>
      </Modal>
    </>
  );
}

const FieldFilterRenderer = ({
  field,
  value,
  onChange,
}: {
  field: ModalFieldFilter;
  value: ModalFieldFilterValue;
  onChange: (field: ModalFieldFilter, newValue: ModalFieldFilterValue) => void;
}) => {
  return (
    <div className="pt-3">
      <div className="font-semibold">{field.label}</div>
      <div className="mt-2">
        {FieldFilterComponents[field.type]({ field, value, onChange })}
      </div>
    </div>
  );
};

type FieldFilterRendererProps = {
  field: ModalFieldFilter;
  value: ModalFieldFilterValue;
  onChange: (field: ModalFieldFilter, newValue: ModalFieldFilterValue) => void;
};

// Components for each field type, this will dynamically render the correct field
const FieldFilterComponents = {
  Text: ({ field, value, onChange }: FieldFilterRendererProps) => <>TODO</>,
  Date: ({ field, value, onChange }: FieldFilterRendererProps) => <>TODO</>,
  Number: ({ field, value, onChange }: FieldFilterRendererProps) => <>TODO</>,
  Select: ({ field, value, onChange }: FieldFilterRendererProps) => {
    return (
      <CrudSelectField
        field={{
          type: "select",
          name: field.name,
          label: "",
          errors: [],
          options: field.type === "Select" ? field.options : [],
          defaultValue: value as string,
          allowNull: true,
        }}
        onChange={e =>
          onChange(
            field,
            e.target.value !== "null" ? e.target.value : undefined
          )
        }
      />
    );
  },
  MultiSelect: ({ field, value, onChange }: FieldFilterRendererProps) => {
    const arrayValue = value?.split(MULTIPLE_FILTER_SEPARATOR) || [];

    const handleSingleItemChange = (
      evt: React.ChangeEvent<HTMLInputElement>
    ) => {
      const newValue = evt.target.checked
        ? [...(arrayValue || []), evt.target.value]
        : (arrayValue || []).filter(v => v !== evt.target.value);

      onChange(field, newValue.join(MULTIPLE_FILTER_SEPARATOR));
    };

    return (
      <div className="flex gap-x-6 flex-wrap">
        {field.type == "MultiSelect" &&
          field.options.map((option, index) => (
            <CrudCheckboxField
              key={index}
              field={{
                name: field.name,
                value: option.value,
                label: option.label,
                errors: [],
                description: "",
                defaultChecked: arrayValue?.includes(option.value),
                type: "checkbox",
              }}
              onChange={handleSingleItemChange}
            />
          ))}
      </div>
    );
  },
  Autocomplete: ({ field, value, onChange }: FieldFilterRendererProps) => (
    <>TODO</>
  ),
  MultiAutocomplete: ({ field, value, onChange }: FieldFilterRendererProps) => {
    if (field.type !== "MultiAutocomplete")
      throw new Error("Invalid field type");

    const [autocompleteValue, setAutocompleteValue] = useState("");

    const selectedValues = useMemo(
      () => value?.split(MULTIPLE_FILTER_SEPARATOR) || [],
      [value]
    );

    const filteredOptions = useMemo(
      () =>
        field.options.filter(
          option =>
            !selectedValues.includes(option.value) &&
            option.label
              .toLocaleLowerCase()
              .includes(autocompleteValue.toLocaleLowerCase())
        ),
      [field.options, selectedValues, autocompleteValue]
    );

    const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
      const { value } = e.target;
      setAutocompleteValue(value);
    };

    const onRemoveValue = (value: string) => {
      onChange(
        field,
        selectedValues
          .filter(selectedValue => selectedValue !== value)
          .join(",")
      );
    };

    const onAddValue = (value: string) => {
      onChange(
        field,
        [...selectedValues, value].join(MULTIPLE_FILTER_SEPARATOR)
      );
      setAutocompleteValue("");
    };

    const renderOption = (value: string) => {
      const option = field.options.find(option => option.value === value);
      return option?.label || value;
    };

    return (
      <div>
        <div className={`relative w-full h-fit`}>
          <CrudTextField
            className="peer"
            field={{
              name: "",
              label: "",
              errors: [],
              type: "text",
              placeholder: "Search your filter",
              defaultValue: autocompleteValue,
              onChange: handleInputChange,
            }}
          />
          {autocompleteValue && (
            <div
              className={`hidden peer-focus-within:block hover:block absolute z-50 w-3/6 max-h-60 h-min overflow-auto -mt-3 mb-6 p-2 rounded-lg bg-sky-50 shadow-lg`}
            >
              <div className="divide-y divide-solid divide-gray-200">
                {filteredOptions.map((option, index) => (
                  <div
                    key={index}
                    onClick={() => onAddValue(option.value)}
                    className="flex items-center p-2 hover:bg-sky-100 rounded-md transition ease-in-out duration-100"
                  >
                    {option.label}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
        <div className="flex flex-wrap gap-x-2 mb-6">
          {selectedValues.map((value, index) => (
            <div className="flex justify-center items-center w-max" key={index}>
              <div className="gap-x-2 w-full bg-transparent border-2 border-sky-500 rounded-full px-3 py-1.5 flex items-center text-sm">
                <button
                  className="font-light"
                  onClick={() => onRemoveValue(value)}
                >
                  <XMarkIcon className="h-5 text-sky-500" />
                </button>
                <div className="text-center w-full">{renderOption(value)}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  },
  DateRange: ({ field, value, onChange }: FieldFilterRendererProps) => {
    const [startDate, endDate] = value?.split(MULTIPLE_FILTER_SEPARATOR) || [
      "",
      "",
    ];

    return (
      <div className="flex gap-x-6">
        <div className="w-full">
          <CrudDateField
            field={{
              type: "text",
              name: `${field.name}_start_date`,
              errors: [],
              label: "Start Date",
              placeholder: "From Date",
              defaultValue: startDate,
              onChange: e =>
                onChange(
                  field,
                  [e.target.value, endDate].join(MULTIPLE_FILTER_SEPARATOR)
                ),
            }}
          />
        </div>
        <div className="w-full">
          <CrudDateField
            field={{
              type: "text",
              name: `${field.name}_end_date`,
              errors: [],
              label: "End Date",
              placeholder: "To Date",
              defaultValue: endDate,
              onChange: e =>
                onChange(
                  field,
                  [startDate, e.target.value].join(MULTIPLE_FILTER_SEPARATOR)
                ),
            }}
          />
        </div>
      </div>
    );
  },
  NumberRange: ({ field, value, onChange }: FieldFilterRendererProps) => {
    if (field.type !== "NumberRange") throw new Error("Invalid field type");

    const [startNumber, endNumber] = value?.split(
      MULTIPLE_FILTER_SEPARATOR
    ) || ["", ""];

    return (
      <div className="flex gap-x-6">
        <div className="w-full">
          <CrudTextField
            field={{
              type: "text",
              name: `${field.name}_start`,
              errors: [],
              label: field.startLabel ?? "Start",
              placeholder: "From Value",
              defaultValue: startNumber,
              onChange: e =>
                onChange(
                  field,
                  [e.target.value, endNumber].join(MULTIPLE_FILTER_SEPARATOR)
                ),
            }}
          />
        </div>
        <div className="w-full">
          <CrudTextField
            field={{
              type: "text",
              name: `${field.name}_end`,
              errors: [],
              label: field.endLabel ?? "End",
              placeholder: "To Value",
              defaultValue: endNumber,
              onChange: e =>
                onChange(
                  field,
                  [startNumber, e.target.value].join(MULTIPLE_FILTER_SEPARATOR)
                ),
            }}
          />
        </div>
      </div>
    );
  },
  Toggle: ({ field, value, onChange }: FieldFilterRendererProps) => <>TODO</>,
};
