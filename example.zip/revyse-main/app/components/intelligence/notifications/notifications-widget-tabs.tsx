import { tv } from "tailwind-variants";

const tvNotificationWidgetTab = tv({
  base: "-mb-[2px] font-medium text-base cursor-pointer flex space-x-2 items-center transition-all ease-in-out duration-200 pb-1.5",
  variants: {
    selected: {
      true: "border-b-2 border-black text-gray-900",
      false: "text-gray-500",
    },
  },
});

const tvNotificationWidgetTabBadge = tv({
  base: "rounded-full aspect-square text-sm w-6 h-6 font-normal flex items-center justify-center ",
  variants: {
    selected: {
      true: "bg-gray-900 text-white",
      false: "border border-gray-400 text-gray-400",
    },
  },
});

export default function NotificationWidgetTabs({
  tabs,
  selected,
  onSelect,
}: {
  tabs: {
    label: string;
    count?: number;
  }[];
  selected: number;
  onSelect: (index: number) => void;
}) {
  return (
    <ol className="w-full flex justify-start space-x-6">
      {tabs.map((tab, i) => (
        <li
          key={tab.label}
          className={tvNotificationWidgetTab({ selected: selected === i })}
          onClick={() => onSelect(i)}
        >
          <div>{tab.label}</div>
          {tab.count && tab.count > 0 ? (
            <div
              className={tvNotificationWidgetTabBadge({
                selected: selected === i,
              })}
            >
              {tab.count}
            </div>
          ) : null}
        </li>
      ))}
    </ol>
  );
}
