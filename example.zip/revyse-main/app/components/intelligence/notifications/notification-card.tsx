import type { SerializeFrom } from "@remix-run/node";
import { tv } from "tailwind-variants";
import type { IntelligenceNotificationMetadataIncludes } from "~/utils/intelligence-notification.utils";
import {
  IntelligenceNotificationTypeEnum,
  getNotificationLink,
  getNotificationMessage,
} from "~/utils/intelligence-notification.utils";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import { Avatar } from "~/components/avatar.component";
import { TaskType } from "~/utils/tasks.utils";
import { IconCircle } from "~/components/circle-icon.component";
import {
  ArchiveBoxIcon,
  ArchiveBoxXMarkIcon,
  BuildingOffice2Icon,
  CheckCircleIcon,
  DocumentTextIcon,
  XCircleIcon,
} from "@heroicons/react/24/outline";
import { useNavigate } from "@remix-run/react";
import { Button } from "~/components/button.component";
import { Tooltip } from "~/components/tooltip.component";
import HTMLReactParser from "html-react-parser";
dayjs.extend(relativeTime);

const tvNotificationCard = tv({
  base: "group relative p-5 flex items-start text-base hover:bg-gray-100 cursor-pointer transition-all ease-in-out duration-200",
  variants: {
    read: {
      false: "bg-yellow-50 hover:bg-yellow-100/70",
    },
  },
});

export default function NotificationCard({
  notification,
  managerAccountId,
  onWidgetClose,
  onNotificationArchivedChange,
  onNotificationReadChange,
  submitAction,
}: {
  notification: SerializeFrom<IntelligenceNotificationMetadataIncludes>;
  managerAccountId: string;
  onWidgetClose: () => void;
  onNotificationArchivedChange: (
    notification: SerializeFrom<IntelligenceNotificationMetadataIncludes>,
    archived: boolean
  ) => void;
  onNotificationReadChange: (
    notification: SerializeFrom<IntelligenceNotificationMetadataIncludes>,
    read: boolean
  ) => void;
  submitAction: (intent: string, notificationId?: string) => void;
}) {
  const navigate = useNavigate();

  const markAsRead = () => {
    onNotificationReadChange(notification, true);
    submitAction("markAsRead", notification.id);
  };

  const archive = () => {
    onNotificationArchivedChange(notification, true);
    onNotificationReadChange(notification, true);
    submitAction("archive", notification.id);
  };

  const unarchive = () => {
    onNotificationArchivedChange(notification, false);
    submitAction("unarchive", notification.id);
  };

  const markAsUnread = () => {
    onNotificationReadChange(notification, false);
    submitAction("markAsUnread", notification.id);
  };

  const onCardClick = () => {
    if (!notification.read) {
      markAsRead();
    }
    navigate(getNotificationLink(notification, managerAccountId));
    onWidgetClose();
  };

  return (
    <div
      className={tvNotificationCard({ read: notification.read })}
      onClick={onCardClick}
    >
      <div className="h-10 w-10 min-h-10 min-w-10">
        <NotificationIcon notification={notification} />
      </div>
      <div className="ml-4 col-span-5 mr-10">
        <p className="text-sm font-medium text-gray-900 [text-wrap:pretty]">
          {HTMLReactParser(getNotificationMessage(notification) || "")}
        </p>
        <span className="text-xs text-gray-500">
          {dayjs(notification.created_at).fromNow()}
        </span>
      </div>
      {!notification.read && (
        <div className="absolute right-5 top-1/2 transform -translate-y-1/2 h-3 w-3 rounded-full bg-yellow-400" />
      )}
      <div className="absolute top-2.5 right-2 flex p-1 space-x-1 opacity-0 group-hover:opacity-100 transition duration-100 border border-gray-300 rounded-md shadow-sm bg-white">
        {notification.archived ? (
          <NotificationAction
            tooltip="Unarchive notification"
            onClick={unarchive}
          >
            <ArchiveBoxXMarkIcon className="h-6" />
          </NotificationAction>
        ) : (
          <>
            {notification.read ? (
              <NotificationAction
                tooltip="Mark as unread"
                onClick={markAsUnread}
              >
                <XCircleIcon className="h-6" />
              </NotificationAction>
            ) : (
              <NotificationAction tooltip="Mark as read" onClick={markAsRead}>
                <CheckCircleIcon className="h-6" />
              </NotificationAction>
            )}
            <NotificationAction
              tooltip="Archive notification"
              onClick={archive}
            >
              <ArchiveBoxIcon className="h-6" />
            </NotificationAction>
          </>
        )}
      </div>
    </div>
  );
}

export const NotificationIcon = ({
  notification,
}: {
  notification: SerializeFrom<IntelligenceNotificationMetadataIncludes>;
}) => {
  const { task_type } = notification.metadata;

  if (
    notification.type === IntelligenceNotificationTypeEnum.TaskMessageMention
  ) {
    const { sender } = notification.metadata;
    return (
      <Avatar
        first_name={sender?.first_name || ""}
        last_name={sender?.last_name || ""}
        img_url={sender?.avatar_url}
      />
    );
  } else if (
    notification.type === IntelligenceNotificationTypeEnum.TaskMessageOwner
  ) {
    const { sender } = notification.metadata;
    return (
      <Avatar
        first_name={sender?.first_name || ""}
        last_name={sender?.last_name || ""}
        img_url={sender?.avatar_url}
      />
    );
  }

  // ... other cases
  let icon = DocumentTextIcon; // default icon (for TaskType.TaskContractRenewal)
  if (task_type == TaskType.TaskLocationDisposition) {
    icon = BuildingOffice2Icon;
  }

  return <IconCircle Icon={icon} color="yellow" size="6" className="p-1.5" />;
};

function NotificationAction({
  children,
  tooltip,
  onClick,
}: {
  children: JSX.Element | string | Array<JSX.Element | string>;
  tooltip: string;
  onClick: () => void;
}) {
  return (
    <Tooltip
      text={tooltip}
      position="leftTop"
      className="[line-height:5px] text-[10px] [text-wrap:nowrap]"
      size="auto"
    >
      <Button
        color="transparent"
        className="px-0.5 py-0.5 text-gray-500 hover:text-gray-500 rounded hover:bg-gray-200/70 transition ease-in-out duration-200"
        onClick={e => {
          e.preventDefault();
          e.stopPropagation();
          onClick();
        }}
      >
        {children}
      </Button>
    </Tooltip>
  );
}
