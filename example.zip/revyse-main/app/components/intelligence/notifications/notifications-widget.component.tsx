import { Dialog, Transition } from "@headlessui/react";
import type { IntelligenceNotificationType } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import React, {
  Fragment,
  useCallback,
  useEffect,
  useMemo,
  useState,
} from "react";
import { Button } from "~/components/button.component";
import type { IntelligenceNotificationMetadataIncludes } from "~/utils/intelligence-notification.utils";
import { IntelligenceNotificationTypeEnum } from "~/utils/intelligence-notification.utils";
import NotificationWidgetTabs from "./notifications-widget-tabs";
import NotificationCard from "./notification-card";
import { isEmpty } from "lodash";
dayjs.extend(relativeTime);

const DEFAULT_NOTIFICATIONS_SHOWED = 4;
const REFRESH_INTERVAL = 60000; // 1 min

function NotificationsWidget({
  children,
  managerAccountId,
}: {
  children: React.ReactNode;
  managerAccountId: string;
}) {
  const [notifications, setNotifications] = useState<
    SerializeFrom<IntelligenceNotificationMetadataIncludes>[]
  >([]);
  const [notificationCounts, setNotificationCounts] =
    useState<Partial<Record<"all" | IntelligenceNotificationType, number>>>();

  const [, setRefreshTimeout] = useState<NodeJS.Timeout | null>(null);

  const [open, setOpen] = useState(false);
  const [viewAll, setViewAll] = useState(false);
  const [selectedTab, setSelectedTab] = useState(0);

  const actionUrl = useMemo(
    () => `/intelligence/notifications/${managerAccountId}`,
    [managerAccountId]
  );

  const getNotifications = useCallback(async () => {
    setRefreshTimeout(timeout => {
      timeout && clearTimeout(timeout);
      return null;
    });
    const params = new URLSearchParams();
    if (selectedTab === 1) {
      params.set("type", IntelligenceNotificationTypeEnum.TaskMessageMention);
    } else if (selectedTab === 2) {
      params.set("archived", "true");
    }

    if (!viewAll) {
      params.set("take", String(DEFAULT_NOTIFICATIONS_SHOWED));
    }

    const response = await fetch(`${actionUrl}?${params.toString()}`);

    const { notifications, notificationCounts } = await response.json();

    setNotifications(notifications);
    setNotificationCounts(notificationCounts);
    setRefreshTimeout(setTimeout(getNotifications, REFRESH_INTERVAL));
  }, [selectedTab, viewAll, actionUrl]);

  useEffect(() => {
    getNotifications();
  }, [getNotifications, selectedTab, managerAccountId, viewAll, open]);

  const submitAction = (intent: string, notificationId?: string) => {
    const formData = new URLSearchParams();
    formData.append("intent", intent);
    if (notificationId) {
      formData.append("notificationId", notificationId);
    }

    fetch(actionUrl, {
      method: "POST",
      body: formData.toString(),
      headers: {
        "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
      },
    });
  };

  const markAllAsRead = () => {
    submitAction("markAllAsRead");
    setNotificationCounts(notificationCounts => {
      if (!notificationCounts) {
        return notificationCounts;
      }

      return Object.assign(
        {},
        ...Array.from(Object.keys(notificationCounts), k => ({ [k]: 0 }))
      );
    });
    setNotifications(notifications =>
      notifications.map(notification => ({ ...notification, read: true }))
    );
  };

  const onNotificationArchivedChange = (
    notification: SerializeFrom<IntelligenceNotificationMetadataIncludes>,
    archived: boolean
  ) => {
    setNotifications(notifications => {
      return notifications.filter(notificationX => {
        return notificationX.id !== notification.id;
      });
    });

    if (!viewAll && notifications.length === DEFAULT_NOTIFICATIONS_SHOWED) {
      getNotifications();
    }
  };

  const onNotificationReadChange = (
    notification: SerializeFrom<IntelligenceNotificationMetadataIncludes>,
    read: boolean
  ) => {
    setNotificationCounts(notificationCounts => {
      if (!notificationCounts) {
        return notificationCounts;
      }

      return {
        ...notificationCounts,
        all: (notificationCounts.all ?? 0) + (read ? -1 : 1),
        [notification.type]:
          (notificationCounts[notification.type] ?? 0) + (read ? -1 : 1),
      };
    });
    setNotifications(notifications => {
      return notifications.map(notificationX => {
        if (notificationX.id === notification.id) {
          return { ...notificationX, read };
        }
        return notificationX;
      });
    });
  };

  const showBellDot = notificationCounts?.all && notificationCounts?.all > 0;

  return (
    <>
      <div>
        {!showBellDot && <span></span>}
        <div onClick={() => setOpen(true)} className="group/bell">
          {children}
        </div>
      </div>
      <Transition.Root show={open} as={Fragment}>
        <Dialog
          className={"relative z-50"}
          onClose={val => {
            setOpen(false);
          }}
        >
          <div className="fixed z-50 overflow-hidden min-w-full min-h-screen max-h-screen">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <Dialog.Panel className="absolute w-11/12 md:max-w-[450px] top-24 sm:right-10 right-[4.166%] rounded-md bg-white text-left shadow-md transition-all ring-1 ring-gray-100">
                <div className="relative w-full">
                  <svg
                    height="20"
                    width="20"
                    xmlns="http://www.w3.org/2000/svg"
                    className="absolute bottom-full 2xl:right-[102px] lg:right-[70px] md:right-[114px] sm:right-[99px] right-[114px] text-gray-100"
                  >
                    <polygon
                      points="-5,25 10,2 25,25"
                      fill="#fff"
                      className="shadow-md"
                      stroke="currentColor"
                      strokeLinejoin="round"
                    />
                  </svg>
                </div>
                <div>
                  <header className="flex justify-between items-center p-5">
                    <h3 className="text-base font-semibold text-gray-900">
                      Notifications
                    </h3>
                    <Button
                      className="text-gray-500 text-sm py-0 font-normal"
                      color="transparent"
                      onClick={markAllAsRead}
                    >
                      Mark all as read
                    </Button>
                  </header>
                  <nav className="px-5">
                    <NotificationWidgetTabs
                      tabs={[
                        { label: "All", count: notificationCounts?.all || 0 },
                        {
                          label: "Mentions",
                          count:
                            notificationCounts?.[
                              IntelligenceNotificationTypeEnum
                                .TaskMessageMention
                            ] || 0,
                        },
                        { label: "Archived" },
                      ]}
                      selected={selectedTab}
                      onSelect={setSelectedTab}
                    />
                  </nav>
                  <hr />
                  <div className="divide-y max-h-[calc(100vh-15rem)] overflow-y-auto overflow-x-visible">
                    {!isEmpty(notifications) ? (
                      <>
                        {notifications.map((notification, i) => (
                          <NotificationCard
                            key={notification.id}
                            notification={notification}
                            managerAccountId={managerAccountId}
                            onWidgetClose={() => setOpen(false)}
                            onNotificationArchivedChange={
                              onNotificationArchivedChange
                            }
                            onNotificationReadChange={onNotificationReadChange}
                            submitAction={submitAction}
                          />
                        ))}
                        <hr />
                        <footer>
                          <Button
                            className="w-full text-center py-5 text-sm"
                            color="transparent"
                            onClick={() => setViewAll(!viewAll)}
                          >
                            {viewAll
                              ? "View less notifications"
                              : "View all notifications"}
                          </Button>
                        </footer>
                      </>
                    ) : (
                      <div className="text-sm text-gray-500 text-center py-7">
                        You're up to date!
                      </div>
                    )}
                  </div>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </Dialog>
      </Transition.Root>
    </>
  );
}

export default NotificationsWidget;
