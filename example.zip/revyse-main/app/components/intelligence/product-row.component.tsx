import type { ContractLineItemProduct } from "@prisma/client";
import { useRef, useState } from "react";
import { isEmpty } from "lodash";
import { useActionData, useFetcher } from "@remix-run/react";
import type { SerializeFrom } from "@remix-run/node";
import { CurrencyField } from "../form/currency-field.component";
import type { action as setPriceAction } from "../../routes/intelligence.$id.contract.$contract_id.line-item_.$contract_line_item_id_.set-price";
import { tvField } from "~/utils/global-tailwind-variants.utils";

interface ProductRowProps {
  product: {
    id: string;
    title: string;
  };
  handleCallback?: (index: number, value: string) => void;
  handleDepartmentSelection?: (department: string, id: string) => void;
  contractLineItemProducts: SerializeFrom<ContractLineItemProduct>[];
  actionUrl: string;
  contractLineItemId: string;
  contractLineItemProduct: SerializeFrom<ContractLineItemProduct>;
  index: number;
}
export function ProductRow({
  product,
  handleCallback = (index, value) => {},
  contractLineItemProducts,
  actionUrl,
  contractLineItemId,
  contractLineItemProduct,
  index,
}: ProductRowProps) {
  const actionData = useActionData<typeof setPriceAction>();

  const productContractLineItem = contractLineItemProducts.find(
    contractLineItemProduct => contractLineItemProduct.product_id === product.id
  );
  const [currentDepartment, setCurrentDepartment] = useState<
    string | null | undefined
  >(
    !isEmpty(productContractLineItem?.department)
      ? productContractLineItem?.department
      : null
  );
  const [searchTerm, setSearchTerm] = useState("");

  const departmentInputRef = useRef<HTMLInputElement | null>(null);
  const fetcher = useFetcher<typeof setPriceAction>();

  const handleInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const searchTerm = e.target.value;
    setSearchTerm(searchTerm);
    if (departmentInputRef?.current) departmentInputRef.current.value = "";

    fetcher.submit(
      {
        intent: "searchDepartment",
        term: searchTerm,
      },
      {
        action: actionUrl,
        method: "post",
        encType: "multipart/form-data",
      }
    );
  };

  const handleBackspace = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace") {
      setCurrentDepartment(null);
    }
  };

  return (
    <div className="grid md:grid-cols-3 items-center gap-x-3 my-3 md:my-0">
      <div>{product?.title}</div>
      <input
        type="hidden"
        name={`contract_line_item.${contractLineItemId}.contract_line_item_products.id`}
        value={contractLineItemProduct.id}
      />
      <input
        type="hidden"
        name={`contract_line_item.${contractLineItemId}.contract_line_item_products.contract_line_item_product_id`}
        value={product.id}
      />
      <input
        type="hidden"
        name={`contract_line_item.${contractLineItemId}.contract_line_item_products.department`}
        value={currentDepartment ?? searchTerm}
      />
      <div>
        <CurrencyField
          name={`contract_line_item.${contractLineItemId}.contract_line_item_products.price`}
          label=""
          defaultValue={contractLineItemProduct.price ?? 0}
          onChange={e => {
            handleCallback(index, e.target.value);
          }}
          errors={
            actionData?.errors
              ? actionData?.errors[
                  `contract_line_item.contract_line_item_products.${index}.price`
                ] ?? []
              : []
          }
        />
      </div>
      <div>
        <input
          className={tvField({ className: "z-50 my-2" })}
          name="selectedDepartment"
          value={currentDepartment ?? searchTerm}
          placeholder="Type a department"
          onChange={e => handleInputChange(e)}
          onKeyDown={e => handleBackspace(e)}
          ref={departmentInputRef}
          onClick={e => e.stopPropagation()}
        />
        {fetcher.state === "idle" &&
          fetcher?.data &&
          "success" in fetcher?.data &&
          "departments" in fetcher?.data &&
          !isEmpty(fetcher?.data?.departments) && (
            <div className="-my-2 rounded-lg p-3 h-72 overflow-auto absolute bg-sky-50 w-72 shadow-lg mb-6 z-50">
              <div className="divide-y divide-solid divide-gray-200">
                {fetcher?.data?.departments &&
                  fetcher?.data?.departments.map(
                    (department: any, index: number) => (
                      <div
                        className="flex items-center p-3 hover:bg-sky-100 rounded-md transition ease-in-out duration-100"
                        key={index}
                        onClick={e => {
                          fetcher.submit(
                            {
                              intent: "searchDepartment",
                              term: "",
                            },
                            {
                              action: actionUrl,
                              method: "post",
                              encType: "multipart/form-data",
                            }
                          );

                          if (departmentInputRef?.current)
                            departmentInputRef.current.value = searchTerm;
                          setCurrentDepartment(department.department);
                        }}
                      >
                        <div>{department.department}</div>
                      </div>
                    )
                  )}
              </div>
            </div>
          )}
      </div>
    </div>
  );
}
