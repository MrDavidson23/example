import { ChevronLeftIcon, ChevronRightIcon } from "@heroicons/react/24/outline";
import { useMemo } from "react";

export function Pagination({
  resultsText,
  pageNumbers,
  currentPage,
  totalPages,
  handleCallback,
}: {
  resultsText: string;
  pageNumbers: number[];
  currentPage: number;
  totalPages: number;
  handleCallback: (page: number) => void;
}) {
  const pageNumbersToRender = useMemo(() => {
    // If less/equal 7, render the 7
    if (pageNumbers.length <= 7) {
      return pageNumbers;
    }

    // If current page less/equal 4, render the first 5 and the last
    if (currentPage <= 4) {
      return [...pageNumbers.slice(0, 5), 0, totalPages];
    }

    // If current page is any of the last 4, render the first and the last 5
    if (currentPage >= totalPages - 3) {
      return [1, 0, ...pageNumbers.slice(-5)];
    }

    // Otherwise, render the current page, the one before and after, and the first and last
    return [
      1,
      0,
      ...pageNumbers.slice(currentPage - 2, currentPage + 1),
      0,
      totalPages,
    ];
  }, [pageNumbers, currentPage, totalPages]);

  return (
    <div className="flex justify-start items-center space-x-8 pt-4 lg:mt-0 text-xs lg:text-sm">
      <span className="font-light">{resultsText}</span>
      <div className="flex items-end">
        {pageNumbersToRender.map((pageNumber, i) =>
          pageNumber === 0 ? (
            <span className="px-4 py-2" key={i + "..."}>
              ...
            </span>
          ) : (
            <button
              key={pageNumber}
              onClick={() => handleCallback(pageNumber)}
              className={`px-4 py-2 ${
                pageNumber === currentPage
                  ? "font-medium text-sky-600"
                  : "font-light"
              }`}
            >
              {pageNumber}
            </button>
          )
        )}
      </div>
      <div className="flex items-center space-x-4">
        <button
          onClick={() => handleCallback(currentPage - 1)}
          disabled={currentPage === 1}
          className="flex items-center text-sky-600 font-medium"
        >
          <ChevronLeftIcon className="h-4 mr-1" />
          Previous
        </button>

        <button
          onClick={() => handleCallback(currentPage + 1)}
          disabled={currentPage == totalPages}
          className="flex items-center text-sky-600 font-medium"
        >
          Next
          <ChevronRightIcon className="h-4 ml-1" />
        </button>
      </div>
    </div>
  );
}
