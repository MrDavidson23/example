import { useNavigate } from "@remix-run/react";
import type { ReactNode } from "react";
import { useEffect, useState } from "react";
import { get } from "lodash";
import dayjs from "dayjs";
import {
  ChevronDownIcon,
  ChevronUpIcon,
  PlusIcon,
} from "@heroicons/react/24/outline";
import utc from "dayjs/plugin/utc";
import { tv } from "tailwind-variants";
dayjs.extend(utc);

const tvTable = tv({
  variants: {
    variant: {
      default: "bg-sky-500 text-white",
      white: "border-b-2 border-gray-200 text-black",
    },
  },
  defaultVariants: {
    variant: "default",
  },
});

const tvIcon = tv({
  variants: {
    orderByIcon: {
      default: "h-4 text-white",
      white: "h-4 text-sky-500",
    },
  },
  defaultVariants: {
    orderByIcon: "default",
  },
});

const tvTableCell = tv({
  base: "whitespace-nowrap py-6 pl-4 pr-3 text-xs lg:text-sm font-medium max-w-sm overflow-visible",
  variants: {
    hideSmallScreen: {
      true: "hidden md:table-cell",
    },
    disabled: {
      true: "text-gray-500",
      false: "text-gray-900",
    },
    alignment: {
      top: "align-top",
      middle: "align-middle",
      bottom: "align-bottom",
    },
  },
});

export type TableColumn<T> = {
  name?: (keyof T & string) | string;
  label: string | ReactNode;
  type?: "date" | "formatted_date";
  renderer?: (value: T, index: number) => ReactNode;
  hideSmallScreen?: boolean;
  columnClassName?: string;
  headerClassName?: string;
  sortable?: boolean;
};

export function Table<
  T extends {
    id: string;
  }
>({
  cols,
  data,
  onClickRow,
  handleCallback,
  addButtonLabel,
  showAddButton = true,
  alwaysShowAdd = false,
  addButtonHeading,
  showSelectBox = true,
  selectColumnPosition = "end",
  selectAllInColumn = false,
  variant = "default",
  onSelectRows,
  selectedData,
  initialSelectedRows,
  disabledRows,
  disabledRowClassName = "bg-gray-200",
  parentHandleRow,
  alignment = "top",
  onOrderBy,
  defaultOrderBy = {},
  allowSorting = true,
  rowIdPrefix = "row",
}: {
  cols: TableColumn<T>[];
  data: T[];
  onClickRow?: (value: T) => void;
  handleCallback?: () => void;
  addButtonLabel?: string;
  showAddButton?: boolean;
  alwaysShowAdd?: boolean;
  addButtonHeading?: ReactNode;
  showSelectBox?: boolean;
  selectColumnPosition?: "start" | "end";
  selectAllInColumn?: boolean;
  parentHandleRow?: string;
  variant?: "default" | "white";
  onSelectRows?: (selectedRows: T[]) => void;
  selectedData?: T[];
  initialSelectedRows?: T[];
  disabledRowClassName?: string;
  disabledRows?: {
    id: string;
  }[];
  alignment?: keyof typeof tvTableCell.variants.alignment;
  onOrderBy?: (value: Record<string, string>) => void;
  defaultOrderBy?: Record<string, string>;
  allowSorting?: boolean;
  rowIdPrefix?: string;
}) {
  const [selectedRows, setSelectedRows] = useState<T[]>(
    initialSelectedRows || []
  );

  const [selectAll, setSelectAll] = useState(false);

  const navigate = useNavigate();
  onClickRow = showSelectBox
    ? (row: T) => handleRowCheckboxClick(row)
    : onClickRow ?? ((row: T) => navigate(`./${row.id}`));

  const handleRowCheckboxClick = (item: T) => {
    setSelectedRows(prevSelectedRows => {
      if (prevSelectedRows.some(row => row.id === item.id)) {
        return prevSelectedRows.filter(row => row.id !== item.id);
      } else {
        return [...prevSelectedRows, item];
      }
    });
  };

  const handleSelectAll = () => {
    setSelectedRows(() => {
      if (selectAll) {
        return [];
      } else {
        return data;
      }
    });
    setSelectAll(!selectAll);
  };

  const [orderBy, setOrderBy] =
    useState<Record<string, string>>(defaultOrderBy);

  const handleOrderBy = (colName: string) => {
    const newOrderBy = { ...orderBy };
    if (!newOrderBy[colName]) {
      newOrderBy[colName] = "asc";
    } else if (newOrderBy[colName] === "asc") {
      newOrderBy[colName] = "desc";
    } else {
      delete newOrderBy[colName];
    }

    setOrderBy(newOrderBy);
    onOrderBy?.(newOrderBy);
  };

  useEffect(() => {
    if (parentHandleRow) {
      setSelectedRows(prevSelectedRows => {
        if (prevSelectedRows.some(row => row.id === parentHandleRow)) {
          return prevSelectedRows.filter(row => row.id !== parentHandleRow);
        } else {
          return [...prevSelectedRows, { id: parentHandleRow } as T];
        }
      });
    }
  }, [parentHandleRow]);

  useEffect(() => {
    if (onSelectRows) {
      onSelectRows(selectedRows);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedRows]);

  useEffect(() => {
    if (selectedData) setSelectedRows(selectedData);
  }, [selectedData]);

  const renderSelectCell = (d: T) => (
    <td className="whitespace-nowrap py-6 pl-4 pr-3 text-xs lg:text-sm font-medium text-gray-900 sm:pl-6 truncate max-w-sm">
      <input
        checked={selectedRows.some(row => row.id === d.id)}
        onChange={() => handleRowCheckboxClick(d)}
        onClick={e => e.stopPropagation()}
        id={`${rowIdPrefix}_${d.id}_checkbox`}
        type="checkbox"
        value=""
        className="w-4 h-4 text-sky-500 bg-gray-100 border-gray-300 rounded focus:ring-sky-500 focus:ring-2"
      />
    </td>
  );

  const renderSelectHeader = () => (
    <th className="py-2 lg:py-5 pl-4 pr-2 text-start sm:pl-6">
      {selectAllInColumn ? (
        <input
          checked={selectAll}
          onChange={handleSelectAll}
          id="select-all-checkbox"
          type="checkbox"
          value=""
          className="w-4 h-4 text-sky-500 bg-gray-100 border-gray-300 rounded focus:ring-sky-500 focus:ring-2"
        />
      ) : (
        "Select"
      )}
    </th>
  );

  return (
    <div className="flow-root max-w-full overflow-x-auto">
      {showSelectBox && data.length > 0 && !selectAllInColumn && (
        <div className="text-sky-500 text-xs lg:text-sm mb-4 flex justify-end items-center space-x-2">
          <label
            htmlFor="default-checkbox"
            className="ml-2 text-xs lg:text-sm text-gray-700"
          >
            Select all
          </label>
          <input
            checked={selectAll}
            onChange={handleSelectAll}
            id="select-all-checkbox"
            type="checkbox"
            value=""
            className="w-4 h-4 text-sky-500 bg-gray-100 border-gray-300 rounded focus:ring-sky-500 focus:ring-2"
          />
        </div>
      )}
      <div>
        <div className="inline-block min-w-full align-middle">
          <div className="rounded-lg shadow-lg shadow-gray-200/50 bg-white border border-gray-100">
            <table className="w-full text-xs lg:text-sm text-left">
              <thead className={tvTable({ variant })}>
                <tr>
                  {showSelectBox &&
                    selectColumnPosition == "start" &&
                    renderSelectHeader()}
                  {cols.map((col, i) => (
                    <th
                      scope="col"
                      className={`py-2 lg:py-5 pl-4 pr-2 text-left text-xs lg:text-sm font-semibold  ${
                        col.hideSmallScreen ? "hidden md:table-cell" : ""
                      } ${
                        allowSorting && col.sortable
                          ? "hover:cursor-pointer"
                          : ""
                      } ${col.headerClassName}`}
                      key={`${col.label?.toString()}-${i}`}
                      onClick={() =>
                        allowSorting && col.sortable && handleOrderBy(col.name!)
                      }
                    >
                      <div
                        className={`flex items-center ${
                          col.name === "manager_account_vendor_name" &&
                          "lg:pl-10"
                        }`}
                      >
                        {col.label}
                        {allowSorting &&
                        col.sortable &&
                        orderBy.hasOwnProperty(col.name!) ? (
                          <span className="ml-1">
                            {orderBy[col.name!] === "asc" ? (
                              <ChevronUpIcon
                                className={`${tvIcon({
                                  orderByIcon: variant,
                                })}`}
                              />
                            ) : (
                              <ChevronDownIcon
                                className={`${tvIcon({
                                  orderByIcon: variant,
                                })}`}
                              />
                            )}
                          </span>
                        ) : allowSorting &&
                          col.sortable &&
                          !orderBy.hasOwnProperty(col.name!) ? (
                          <div className="ml-1 -space-y-2">
                            <ChevronUpIcon
                              className={`${tvIcon({ orderByIcon: variant })}`}
                            />
                            <ChevronDownIcon
                              className={`${tvIcon({ orderByIcon: variant })}`}
                            />
                          </div>
                        ) : null}
                      </div>
                    </th>
                  ))}
                  {showSelectBox &&
                    selectColumnPosition == "end" &&
                    renderSelectHeader()}
                </tr>
              </thead>
              {data.length === 0 ? (
                <tbody>
                  <tr>
                    <td colSpan={showSelectBox ? cols.length + 1 : cols.length}>
                      <div className="flex justify-center py-6 gap-6">
                        <span className="block text-md text-gray-900">
                          Nothing here yet
                        </span>
                        {showAddButton && (
                          <button
                            type="button"
                            className="flex flex-row justify-center items-center text-sky-600"
                            onClick={() =>
                              handleCallback
                                ? handleCallback()
                                : navigate(`./new`)
                            }
                          >
                            <PlusIcon className="h-5 w-5"></PlusIcon>
                            {addButtonLabel}
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                </tbody>
              ) : (
                <tbody className="divide-y divide-gray-200 bg-white">
                  {alwaysShowAdd && (
                    <tr>
                      <td colSpan={cols.length} className="pl-4 pr-3 py-8">
                        <div className="flex justify-start gap-6 text-md">
                          <button
                            id="table-add-button"
                            type="button"
                            className="flex flex-row justify-center items-center text-sky-600 space-x-4"
                            onClick={() =>
                              handleCallback
                                ? handleCallback()
                                : navigate(`./new`)
                            }
                          >
                            {addButtonHeading}
                            <div className="flex items-center">
                              <PlusIcon className="h-5 w-5"></PlusIcon>
                              {addButtonLabel}
                            </div>
                          </button>
                        </div>
                      </td>
                    </tr>
                  )}
                  {data.map((d, index) => (
                    <tr
                      key={d.id}
                      id={`${rowIdPrefix}_${d.id}`}
                      onClick={event => {
                        event.stopPropagation();
                        onClickRow!(d);
                      }}
                      className={`${
                        selectedRows.some(row => row.id === d.id)
                          ? "bg-sky-50 hover:bg-sky-50"
                          : ""
                      } ${
                        disabledRows &&
                        disabledRows.some(row => row.id === d.id)
                          ? disabledRowClassName
                          : "hover:bg-gray-50 cursor-pointer group"
                      }`}
                    >
                      {showSelectBox &&
                        selectColumnPosition == "start" &&
                        renderSelectCell(d)}
                      {cols.map((col, i) => {
                        let value: any = "";
                        if (col.renderer) value = col.renderer(d, index);
                        else if (col.name && col.type === "date") {
                          const date = get(d, col.name) as string;
                          value = date ? dayjs(date).format("M/D/YYYY") : "--";
                        } else if (col.name && col.type === "formatted_date") {
                          const date = get(d, col.name) as string;
                          value = date
                            ? dayjs.utc(date).format("MMM D, YYYY")
                            : "--";
                        } else {
                          value = col.name && (get(d, col.name) as any);
                        }
                        return (
                          <td
                            key={d.id + col.label + i}
                            className={tvTableCell({
                              hideSmallScreen: col.hideSmallScreen,
                              disabled: disabledRows?.some(
                                row => row.id === d.id
                              ),
                              alignment,
                              className: col.columnClassName,
                            })}
                          >
                            {value}
                          </td>
                        );
                      })}
                      {showSelectBox &&
                        selectColumnPosition == "end" &&
                        renderSelectCell(d)}
                    </tr>
                  ))}
                </tbody>
              )}
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
