import { FeeCard } from "./fee-card.component";
import { ProductCard } from "./product-card.component";
import { CurrencyDollarIcon, PlusIcon } from "@heroicons/react/24/outline";
interface ProductFeesListProps {
  products: any;
  fees?: any;
  handleCallback?: (id: string) => void;
  handleFeeCallback?: (id: string) => void;
  handleEditModal?: (value: boolean) => void;
  handleFee?: (fee: { id: string; name: string; category_id: string }) => void;
  handleAddNewFee?: () => void;
  selectedProducts: string[];
  selectedFees?: string[];
  confirmEditOpen?: Boolean;
}

export function ProductFeesList({
  products,
  fees,
  handleCallback,
  handleFeeCallback,
  handleEditModal,
  handleFee,
  handleAddNewFee,
  selectedProducts,
  selectedFees,
  confirmEditOpen,
}: ProductFeesListProps) {
  const mergedList = [...products, ...fees];

  const sortedList = mergedList.sort((a, b) =>
    (a.name || a.title).localeCompare(b.name || b.title)
  );

  return (
    <div className="grid lg:grid-cols-4 gap-6">
      <div
        className="max-w-sm bg-white shadow-lg shadow-gray-200/50 rounded-lg h-full hover:scale-105 cursor-pointer transition ease-in-out duration-300"
        onClick={handleAddNewFee}
      >
        <div className="p-5 space-y-2 flex flex-col items-center justify-center h-full">
          <CurrencyDollarIcon className="h-20 w-20 text-emerald-500"></CurrencyDollarIcon>
          <h5 className="text-2xl font-bold tracking-tight text-gray-900 text-center">
            Fees or other charges
          </h5>
          <div className="flex items-center space-x-2">
            <PlusIcon className="h-4 w-4"></PlusIcon>
            <button className="block text-md" type="button">
              Add new fee
            </button>
          </div>
        </div>
      </div>
      {sortedList.map((item: any) => {
        if ("slug" in item) {
          const p = {
            ...item,
            vendor_name: item.vendor!.name,
            vendor_logo_file_id: item.vendor!.logo_file_id,
            avg_score: item.avgReview,
            cnt: item.totalReviews,
          };
          return (
            <ProductCard
              key={item.id}
              product={p}
              handleCallback={handleCallback}
              selectedProducts={selectedProducts}
            />
          );
        } else {
          const f = {
            ...item,
            vendor_name: item.vendor!.name,
            vendor_logo: item.vendor!.logo_file_id,
          };
          return (
            <FeeCard
              key={item.id}
              fee={f}
              handleCallback={handleFeeCallback}
              selectedFees={selectedFees}
              handleEditModal={handleEditModal}
              handleFee={handleFee}
              confirmEditOpen={confirmEditOpen}
            />
          );
        }
      })}
    </div>
  );
}
