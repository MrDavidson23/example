import { tv } from "tailwind-variants";

const tvIntelligenceDetailsSection = tv({
  base: "flex flex-col gap-y-4 md:gap-y-8 pb-10",
});

export function IntelligenceDetailsSection({
  title,
  children,
  className,
}: {
  title: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div className={`${tvIntelligenceDetailsSection({ className })}`}>
      <h2 className="text-lg font-semibold leading-tight">{title}</h2>
      {children}
    </div>
  );
}
