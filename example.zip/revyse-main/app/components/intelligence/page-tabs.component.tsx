import { Link, useLocation } from "@remix-run/react";
import { tv } from "tailwind-variants";
import { equalPathnames } from "~/utils/string.utils";

const tvOptions = tv({
  slots: {
    container:
      "min-w-full flex gap-4 justify-between md:grid overflow-x-auto no-scrollbar py-2 -mx-4 px-4 md:mx-0 md:px-0",
    option:
      "text-center space-y-2 text-sm flex-grow whitespace-nowrap text-gray-400",
    optionBorder: "h-1 bg-gray-300",
  },
  variants: {
    active: {
      true: {
        option: "text-sky-600",
        optionBorder: "h-1 bg-sky-400",
      },
    },
  },
});

// This component allows to add tabs for the page which can work as filter switchers or simply navigate to a different page
// Validation to show a tab as selected can be done by validating the params provided in the url or the words included in it
export default function PageTabs({
  validationType = "urlIncludes",
  options,
  columns,
}: {
  validationType?: "urlParams" | "urlIncludes" | "exactMatch";
  options: {
    currentUrl?: string | null;
    currentParam?: string | null;
    expectedResult: string;
    navigateTo?: string;
    onNavigate?: () => void;
    label: string;
    badgeCount?: number;
    id?: string;
  }[];
  columns: number;
}) {
  const { pathname } = useLocation();

  const match = (option: (typeof options)[number]) => {
    if (validationType == "urlParams") {
      return option.currentParam == option.expectedResult;
    }

    if (validationType == "urlIncludes") {
      return option.currentUrl?.includes(option.expectedResult);
    }

    if (validationType == "exactMatch") {
      return equalPathnames(pathname, option.navigateTo || "");
    }
  };

  const {
    container: tvContainer,
    option: tvOption,
    optionBorder: tvOptionBorder,
  } = tvOptions();

  return validationType == "urlParams" ? (
    <div className={tvContainer({ className: `grid-cols-${columns}` })}>
      {options.map((option, index) => (
        <Link
          to={option.navigateTo || ""}
          key={index}
          className={tvOption({ active: match(option) })}
          onClick={e => {
            if (option.onNavigate) {
              e.preventDefault();
              option.onNavigate();
            }
          }}
          id={option.id}
        >
          <div>
            {option.label}
            {option.badgeCount !== undefined && option.badgeCount > 0 && (
              <span className="w-min ml-3 rounded-2xl px-3 py-1 border capitalize text-center bg-yellow-50 text-gray-900 border-yellow-500 text-sm">
                {option.badgeCount}
              </span>
            )}
          </div>
          <div className={tvOptionBorder({ active: match(option) })}></div>
        </Link>
      ))}
    </div>
  ) : (
    <div className={tvContainer({ className: `grid-cols-${columns}` })}>
      {options.map((option, index) => (
        <Link
          to={option.navigateTo || ""}
          key={index}
          className={tvOption({ active: match(option) })}
          id={option.id}
        >
          <div>{option.label}</div>
          <div className={tvOptionBorder({ active: match(option) })}></div>
        </Link>
      ))}
    </div>
  );
}
