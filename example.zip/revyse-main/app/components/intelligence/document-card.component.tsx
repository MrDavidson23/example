import React from "react";
import type {
  ManagerAccountVendorDocumentType,
  File as PrismaFile,
} from "@prisma/client";
import {
  DocumentArrowUpIcon,
  DocumentCheckIcon,
  PaperClipIcon,
  TrashIcon,
} from "@heroicons/react/24/outline";
import { ManagerAccountVendorDocumentTypeLabels } from "~/utils/constants.utils";
import dayjs from "dayjs";
import { Button } from "~/components/button.component";
import { RevysePencilIcon } from "~/components/revyse-pencil-icon.component";
import type { SerializeFrom } from "@remix-run/node";

function DocumentCard({
  document,
  className = "",
  onCardClick,
  onEditClick,
  onDeleteClick,
  isContract = false,
}: {
  document: {
    id?: string;
    name?: string | null;
    type?: ManagerAccountVendorDocumentType | null;
    created_at?: string | Date;
    file?: Partial<SerializeFrom<PrismaFile>> | null;
    new_file?: File;
    status?: "uploading" | "uploaded" | "success";
  };
  className?: string;
  onCardClick?: React.MouseEventHandler<HTMLElement> | undefined;
  onEditClick?: React.MouseEventHandler<HTMLElement> | undefined;
  onDeleteClick?: React.MouseEventHandler<HTMLElement> | undefined;
  isContract?: boolean;
}) {
  return (
    <div
      id="vendor-document-card"
      className={`border rounded-lg ${className} p-2 flex justify-between border-gray-300 ${
        onCardClick ? "cursor-pointer hover:bg-gray-100" : ""
      }`}
      onClick={onCardClick}
    >
      <div className="flex items-start p-4">
        <PaperClipIcon className="w-6 h-6 text-gray-400" />
        <div className="ml-3 flex flex-col h-full space-y-3">
          <div className="font-semibold text-normal w-96 line-clamp-2 whitespace-normal truncate hyphens-auto break-words">
            {document.name ?? document.new_file?.name ?? document.file?.title}
          </div>
          {!isContract && (
            <div className="text-gray-500">
              Document Type:{" "}
              {document?.type
                ? ManagerAccountVendorDocumentTypeLabels[document?.type]
                : "--"}
            </div>
          )}
          <div className="text-gray-500">
            Uploaded Date: {dayjs(document?.created_at).format("MMM D, YYYY")}
          </div>
        </div>
      </div>
      {document.status === "uploading" && (
        <div className="flex flex-col items-center mt-4 animate-pulse text-sky-400">
          <DocumentArrowUpIcon className="w-8 h-8 animate-bounce mb-2" />
          <span className="text-xs">Uploading</span>
        </div>
      )}
      {document.status === "success" && (
        <div className="flex flex-col items-center mt-4 text-green-400">
          <DocumentCheckIcon className="w-8 h-8 mb-2" />
          <span className="text-xs">Uploaded</span>
        </div>
      )}
      {document.status === "uploaded" && (
        <div className="flex items-start">
          {onEditClick && (
            <Button color="transparent" onClick={onEditClick}>
              <RevysePencilIcon className="h-5 w-5" />
            </Button>
          )}
          {onDeleteClick && (
            <Button color="transparent" onClick={onDeleteClick}>
              <TrashIcon className="h-6 w-6" />
            </Button>
          )}
        </div>
      )}
    </div>
  );
}

export default DocumentCard;
