import { Form } from "@remix-run/react";
import { Tooltip } from "../tooltip.component";
import { InformationCircleIcon } from "@heroicons/react/24/outline";
import { Toast } from "../toast.component";
import { CTA } from "../cta.component";
import {
  CrudDateField,
  CrudRadioButtonField,
  CrudSelectField,
  CrudTextField,
  CrudFileUpload,
} from "../form/crud-form.component";

const MB = 1024 * 1024;
const CONTRACT_BYTE_LIMIT = 0.5 * MB;

export function ContractDetailsForm({
  actionData,
  contract,
  ftu = false,
}: {
  actionData: any;
  contract?: any;
  ftu?: boolean;
}) {
  return (
    <>
      <Form method="post" encType="multipart/form-data">
        {actionData?.success !== undefined && (
          <Toast
            variant={actionData?.success ? "success" : "error"}
            message={
              actionData?.success
                ? "Success!"
                : "There were problems submitting your form. Please try again."
            }
          />
        )}
        <div
          className={`grid grid-flow-row grid-cols-2 grid-rows-none gap-4 ${
            ftu && "bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min"
          }`}
        >
          <div>
            <CrudSelectField
              field={{
                name: "contract_terms",
                type: "select",
                options: [],
                errors: actionData?.errors.contract_terms ?? [],
                label: "Contract Terms*",
                defaultValue: actionData
                  ? actionData?.fields.contract_terms ?? undefined
                  : contract?.contractDetails.contract_terms,
              }}
            />
          </div>
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div>Is this a MSA?*</div>
              <Tooltip text="Information">
                <div className="flex flex-row items-center cursor-pointer">
                  <InformationCircleIcon className="h-5" />
                </div>
              </Tooltip>
            </div>
            <div className="flex space-x-3">
              {[0, 1].map(i => (
                <div key={i}>
                  <CrudRadioButtonField
                    field={{
                      label: `${i === 0 ? "No" : "Yes"}`,
                      value: i,
                      errors: [],
                      name: "is_msa",
                      defaultChecked: actionData
                        ? actionData?.fields.is_msa ?? undefined
                        : contract?.contractDetails.is_msa,
                      type: "radio",
                      description: "",
                    }}
                  />
                </div>
              ))}
            </div>
          </div>
          <div>
            <CrudSelectField
              field={{
                name: "contract_length",
                type: "select",
                options: [],
                errors: actionData?.errors.contract_length ?? [],
                label: "Contract Length*",
                defaultValue: actionData
                  ? actionData?.fields.contract_length ?? undefined
                  : contract?.contractDetails.contract_length,
              }}
            />
          </div>
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <div>Does this contract auto renew?*</div>
              <Tooltip text="Information">
                <div className="flex flex-row items-center cursor-pointer">
                  <InformationCircleIcon className="h-5" />
                </div>
              </Tooltip>
            </div>
            <div className="flex space-x-3">
              {[0, 1].map(i => (
                <div key={i}>
                  <CrudRadioButtonField
                    field={{
                      label: `${i === 0 ? "No" : "Yes"}`,
                      value: i,
                      errors: [],
                      name: "auto_renews",
                      defaultChecked: actionData
                        ? actionData?.fields.auto_renews ?? undefined
                        : contract?.contractDetails.auto_renews,
                      type: "radio",
                      description: "",
                    }}
                  />
                </div>
              ))}
            </div>
          </div>
          <div>
            <CrudSelectField
              field={{
                name: "contract_status",
                type: "select",
                options: [],
                errors: actionData?.errors.contract_status ?? [],
                label: "Contract Status*",
                defaultValue: actionData
                  ? actionData?.fields.contract_status ?? undefined
                  : contract?.contractDetails.contract_status,
              }}
            />
          </div>
          <div>
            <CrudSelectField
              field={{
                name: "auto_renew_term",
                type: "select",
                options: [],
                errors: actionData?.errors.auto_renew_term ?? [],
                label: "If yes, what is the auto renew term?",
                defaultValue: actionData
                  ? actionData?.fields.auto_renew_term ?? undefined
                  : contract?.contractDetails.auto_renew_term,
              }}
            />
          </div>
          <div>
            <CrudDateField
              field={{
                name: "expiration_date",
                type: "text",
                errors: actionData?.errors.expiration_date ?? [],
                label: "Expiration Date*",
                defaultValue: actionData
                  ? actionData?.fields.expiration_date ?? undefined
                  : contract?.contractDetails.expiration_date,
              }}
            />
          </div>
          <div>
            <CrudSelectField
              field={{
                name: "renewal_reminder_months",
                type: "select",
                options: [],
                errors: actionData?.errors.renewal_reminder_months ?? [],
                label:
                  "How many months in advance do you want a renewal reminder?",
                defaultValue: actionData
                  ? actionData?.fields.renewal_reminder_months ?? undefined
                  : contract?.contractDetails.renewal_reminder_months,
              }}
            />
          </div>
          <div>
            <CrudTextField
              field={{
                name: "contract_owner",
                type: "text",
                errors: actionData?.errors.contract_owner ?? [],
                label: "Contract Owner*",
                placeholder: "Type a name",
                defaultValue: actionData
                  ? actionData?.fields.contract_owner ?? undefined
                  : contract?.contractDetails.contract_owner,
              }}
            />
          </div>
          <div className="row-span-2">
            {/* <EmailList
              name="renewal_reminder_emails"
              label="Which email address will receive this renewal reminder?*"
            ></EmailList> */}
          </div>
          <div>
            <CrudTextField
              field={{
                name: "contract_approver",
                type: "text",
                errors: actionData?.errors.contract_approver ?? [],
                label: "Contract Approver*",
                placeholder: "Type a name",
                defaultValue: actionData
                  ? actionData?.fields.contract_approver ?? undefined
                  : contract?.contractDetails.contract_approver,
              }}
            />
          </div>
          <div>
            <CrudSelectField
              field={{
                name: "department",
                type: "select",
                options: [],
                errors: actionData?.errors.department ?? [],
                label: "Department*",
                defaultValue: actionData
                  ? actionData?.fields.department ?? undefined
                  : contract?.contractDetails.department,
              }}
            />
          </div>
          <div>
            <CrudFileUpload
              field={{
                name: "contract_file",
                label: "Upload contract file",
                buttonLabel: "",
                type: "file-upload",
                defaultValue: actionData
                  ? actionData?.fields.contract_file ?? undefined
                  : contract?.contractDetails.contract_file,
                errors: actionData?.errors?.contract_file ?? [],
                maxFileSize: CONTRACT_BYTE_LIMIT,
              }}
            />
          </div>
        </div>
        {ftu ? (
          <div className="flex justify-end mt-8">
            <CTA type="submit">Continue</CTA>
          </div>
        ) : (
          <div className="flex justify-end mt-8">
            <CTA className="flex" variant="sky-shadow" type="submit">
              Save
            </CTA>
          </div>
        )}
      </Form>
    </>
  );
}
