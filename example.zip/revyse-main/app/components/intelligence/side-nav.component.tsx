import {
  ChevronDoubleLeftIcon,
  ChevronDoubleRightIcon,
} from "@heroicons/react/24/outline";
import type { IntelligenceModuleLink } from "~/routes/intelligence.$id";
import { ModuleNavLink } from "./module-nav-link.component";

export function SideNav({
  links,
  isCollapsed,
  toggleCollapse,
}: {
  links: IntelligenceModuleLink[];
  isCollapsed: boolean;
  toggleCollapse: () => void;
}) {
  return (
    <aside
      id="logo-sidebar"
      className={`hidden lg:block fixed top-0 left-0 z-40 pt-20 ${
        isCollapsed ? "w-24" : "w-2/12"
      } h-screen bg-white border-r border-gray-200 sm:translate-x-0 transition-all duration-300`}
      aria-label="Sidebar"
    >
      <div className="h-full overflow-y-auto bg-white flex flex-col items-center justify-between">
        <div className="w-full flow-root">
          <div className={`space-y-2 py-6 ${!isCollapsed && "2xl:pl-12 pl-5"}`}>
            {links.map(link => (
              <ModuleNavLink
                key={link.id}
                link={link}
                collapsed={isCollapsed}
                isActive={link.isActive}
                toggleCollapse={toggleCollapse}
              />
            ))}
          </div>
        </div>
        <button
          onClick={toggleCollapse}
          className="my-24 w-full flex justify-center text-sky-500"
        >
          <div className="flex space-x-3 items-center">
            {isCollapsed ? (
              <ChevronDoubleRightIcon className="h-5 w-5" />
            ) : (
              <ChevronDoubleLeftIcon className="h-5 w-5" />
            )}
            {!isCollapsed && <span>Collapse sidebar</span>}
          </div>
        </button>
      </div>
    </aside>
  );
}
