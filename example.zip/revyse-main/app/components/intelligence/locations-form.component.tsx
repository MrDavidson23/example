import type { Location } from "@prisma/client";
import {
  LocationClass,
  LocationCountry,
  LocationPropertyStage,
  LocationPropertyType,
  LocationStatus,
} from "@prisma/client";
import {
  CrudAutocompleteField,
  CrudSelectField,
  CrudTextField,
} from "../form/crud-form.component";
import type { SerializeFrom } from "@remix-run/node";
import { Form } from "@remix-run/react";
import { CTA } from "../cta.component";
import { useCallback, useEffect, useState } from "react";
import { usaStates, caStates } from "~/utils/state.enum";
import { find } from "lodash";
import { XMarkIcon } from "@heroicons/react/24/outline";

export function LocationForm({
  actionData,
  location,
  account_id,
  regionOptions,
  ownerOptions,
}: {
  actionData: any;
  location?: SerializeFrom<Location>;
  account_id: string;
  regionOptions?: {
    region: string;
  }[];
  ownerOptions?: string[];
}) {
  const [currentRegion, setCurrentRegion] = useState<string | null | undefined>(
    location?.region
  );
  const [currentOwnerName, setCurrentOwnerName] = useState<
    string | null | undefined
  >(location?.owner_name);
  const [selectedState, setSelectedState] = useState(
    actionData ? actionData.fields.state ?? undefined : location?.state
  );
  const countryOptions = Object.values(LocationCountry).map(country => ({
    label: country,
    value: country,
  }));

  const [country, setCountry] = useState(
    actionData ? actionData.fields.country ?? undefined : location?.country
  );

  const statesOptions = [
    {
      group: "USA",
      options: usaStates,
    },
    {
      group: "Canada",
      options: caStates,
    },
  ];

  const propertyClassOptions = [
    { label: "A+", value: LocationClass.APlus },
    { label: LocationClass.A, value: LocationClass.A },
    { label: LocationClass.B, value: LocationClass.B },
    { label: LocationClass.C, value: LocationClass.C },
    { label: LocationClass.D, value: LocationClass.D },
  ];

  const propertyStageOptions = [
    { label: "Lease-Up", value: LocationPropertyStage.LeaseUp },
    {
      label: LocationPropertyStage.Stabilized,
      value: LocationPropertyStage.Stabilized,
    },
    {
      label: LocationPropertyStage.Renovation,
      value: LocationPropertyStage.Renovation,
    },
    { label: LocationPropertyStage.Other, value: LocationPropertyStage.Other },
  ];

  const propertyTypeOptions = [
    {
      label: "Conventional Multifamily",
      value: LocationPropertyType.ConventionalMultifamily,
    },
    {
      label: LocationPropertyType.Affordable,
      value: LocationPropertyType.Affordable,
    },
    {
      label: LocationPropertyType.Student,
      value: LocationPropertyType.Student,
    },
    { label: LocationPropertyType.Senior, value: LocationPropertyType.Senior },
    { label: "Self Storage", value: LocationPropertyType.SelfStorage },
    {
      label: "Office/Commercial",
      value: LocationPropertyType.OfficeCommercial,
    },
    { label: "Build-to-Rent", value: LocationPropertyType.BuildToRent },
    { label: "Single Family", value: LocationPropertyType.SingleFamily },
    { label: LocationPropertyType.Other, value: LocationPropertyType.Other },
  ];

  const handleBackspace = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace") {
      setCurrentRegion(null);
    }
  };

  const onSelectRegion = useCallback(
    (value: string) => {
      setCurrentRegion(find(regionOptions, ["region", value])?.region);
    },
    [regionOptions]
  );

  useEffect(() => {
    if (selectedState && usaStates.find(s => s.value === selectedState)) {
      setCountry(LocationCountry.USA);
    } else if (selectedState && caStates.find(s => s.value === selectedState)) {
      setCountry(LocationCountry.Canada);
    }
  }, [selectedState]);

  return (
    <div className="space-y-6">
      <h2 className="text-lg lg:text-3xl font-semibold leading-7 text-gray-900">
        {location ? "Edit your location" : "Create a new location"}
      </h2>
      <Form method="post" encType="multipart/form-data">
        <CrudTextField
          field={{
            name: "name",
            label: "Location Name*",
            placeholder: "Location Name",
            type: "text",
            defaultValue: actionData
              ? actionData.fields.name ?? undefined
              : location?.name,
            errors: actionData?.errors.name ?? [],
          }}
        />
        <CrudTextField
          field={{
            name: "pms_id",
            label: "Property Management System ID",
            placeholder: "Property Management System ID",
            type: "text",
            defaultValue: actionData
              ? actionData.fields.pms_id ?? undefined
              : location?.pms_id,
            errors: actionData?.errors.pms_id ?? [],
          }}
        />
        <div className="grid grid-cols-2 gap-x-4">
          <div>
            <CrudTextField
              field={{
                name: "street_1",
                label: "Street 1*",
                placeholder: "Street 1",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.street_1 ?? undefined
                  : location?.street_1,
                errors: actionData?.errors.street_1 ?? [],
              }}
            />
          </div>
          <div>
            <CrudTextField
              field={{
                name: "street_2",
                label: "Street 2",
                placeholder: "Street 2",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.street_2 ?? undefined
                  : location?.street_2,
                errors: actionData?.errors.street_2 ?? [],
              }}
            />
          </div>

          <div>
            <CrudTextField
              field={{
                name: "city",
                label: "City*",
                placeholder: "City",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.city ?? undefined
                  : location?.city,
                errors: actionData?.errors.city ?? [],
              }}
            />
          </div>
          <div>
            <CrudSelectField
              field={{
                name: "state",
                label: "State*",
                type: "select",
                options: statesOptions,
                defaultValue: selectedState,
                errors: actionData?.errors.state ?? [],
              }}
              onChange={(e: any) => setSelectedState(e.target.value)}
            />
          </div>
          <div>
            <CrudSelectField
              field={{
                name: "country",
                label: "Country",
                type: "select",
                allowNull: true,
                options: countryOptions,
                defaultValue: country,
                errors: actionData?.errors.country ?? [],
                reactiveDefaultValue: true,
              }}
            />
          </div>
          <div>
            <CrudTextField
              field={{
                name: "zip",
                label: "Zip*",
                placeholder: "Zip",
                type: "text",
                defaultValue: actionData
                  ? actionData.fields.zip ?? undefined
                  : location?.zip,
                errors: actionData?.errors.zip ?? [],
              }}
            />
          </div>
        </div>
        <div>
          {!currentRegion ? (
            <div>
              <CrudAutocompleteField
                field={{
                  name: "region",
                  label: "Region",
                  type: "autocomplete" as const,
                  defaultValue: currentRegion ?? undefined,
                  errors: actionData?.errors.region ?? [],
                  options: regionOptions
                    ? regionOptions.map(region => ({
                        label: region.region,
                        value: region.region,
                      }))
                    : [],
                  placeholder: "Type a region",
                  onKeyDown: e => handleBackspace(e),
                  onChange: e => setCurrentRegion(e.target.value),
                  onSelect: onSelectRegion,
                }}
              />
            </div>
          ) : (
            <div className="relative col-span-full">
              <CrudTextField
                field={{
                  name: "selectedRegion",
                  label: "Region",
                  type: "text" as const,
                  defaultValue: currentRegion ?? undefined,
                  errors: [],
                  disabled: true,
                }}
              />
              <button
                id="clear-region"
                className="absolute right-2 top-10 text-sky-500"
                onClick={() => setCurrentRegion(undefined)}
              >
                <XMarkIcon className="h-5 w-5" />
              </button>

              <input
                type="hidden"
                name="region"
                value={currentRegion ?? undefined}
              />
            </div>
          )}
        </div>
        <CrudTextField
          field={{
            name: "unit_count",
            label: "Unit Count*",
            placeholder: "1",
            type: "text",
            defaultValue: actionData
              ? actionData.fields.unit_count ?? undefined
              : location?.unit_count,
            errors: actionData?.errors.unit_count ?? [],
          }}
        />
        <CrudSelectField
          field={{
            name: "class",
            label: "Property Class*",
            type: "select",
            options: propertyClassOptions,
            defaultValue: actionData
              ? actionData.fields.class ?? undefined
              : location?.class,
            errors: actionData?.errors.class ?? [],
          }}
        />
        <CrudSelectField
          field={{
            name: "property_type",
            label: "Property Type*",
            type: "select",
            options: propertyTypeOptions,
            defaultValue: actionData
              ? actionData.fields.property_type ?? undefined
              : location?.property_type,
            errors: actionData?.errors.property_type ?? [],
          }}
        />
        <CrudSelectField
          field={{
            name: "property_stage",
            label: "Property Stage",
            type: "select",
            options: propertyStageOptions,
            defaultValue: actionData
              ? actionData.fields.property_stage ?? undefined
              : location?.property_stage,
            errors: actionData?.errors.property_stage ?? [],
          }}
        />
        <div>
          {!currentOwnerName ? (
            <div>
              <CrudAutocompleteField
                field={{
                  name: "owner_name",
                  label: "Owner Name",
                  type: "autocomplete" as const,
                  defaultValue: currentOwnerName ?? undefined,
                  errors: actionData?.errors.owner ?? [],
                  options: ownerOptions
                    ? ownerOptions.map(owner => ({
                        label: owner,
                        value: owner,
                      }))
                    : [],
                  placeholder: "Type an owner name",
                  onChange: e => setCurrentOwnerName(e.target.value),
                  onSelect: setCurrentOwnerName,
                }}
              />
            </div>
          ) : (
            <div className="relative col-span-full">
              <CrudTextField
                field={{
                  name: "selectedOwnerName",
                  label: "Owner Name",
                  type: "text" as const,
                  defaultValue: currentOwnerName ?? undefined,
                  errors: actionData?.errors.owner ?? [],
                  disabled: true,
                }}
              />
              <button
                id="clear-owner-name"
                className="absolute right-2 top-10 text-sky-500"
                onClick={() => setCurrentOwnerName(undefined)}
              >
                <XMarkIcon className="h-5 w-5" />
              </button>

              <input
                type="hidden"
                name="owner_name"
                value={currentOwnerName ?? undefined}
              />
            </div>
          )}
        </div>
        {location && (
          <CrudSelectField
            field={{
              name: "status",
              label: "Status*",
              type: "select",
              options: Object.values(LocationStatus).map(status => ({
                label: status,
                value: status,
              })),
              defaultValue: actionData
                ? actionData.fields.status ?? undefined
                : location?.status,
              errors: actionData?.errors.status ?? [],
            }}
          />
        )}
        <div className="flex items-center justify-end py-4">
          <CTA
            variant="sky-shadow"
            className="flex"
            type="submit"
            id="save-button"
          >
            Save
          </CTA>
        </div>
      </Form>
    </div>
  );
}
