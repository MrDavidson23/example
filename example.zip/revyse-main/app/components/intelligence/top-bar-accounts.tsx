import { Dialog, Transition } from "@headlessui/react";
import type { ManagerAccount } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { Fragment, useMemo, useState } from "react";
import { tv } from "tailwind-variants";
import { CTA } from "../cta.component";
import { Link, useNavigate } from "@remix-run/react";
import { ArrowLeftOnRectangleIcon } from "@heroicons/react/24/outline";

const tvAccountOption = tv({
  base: "relative px-5 py-4 flex items-center text-base hover:bg-gray-100 cursor-pointer transition-all ease-in-out duration-200 max-h-[100px]",
  variants: {
    active: {
      true: "bg-yellow-50 hover:bg-yellow-100/70",
    },
  },
});

export function TopBarAccounts({
  children,
  accounts,
  activeAccountId,
  setActiveAccount,
}: {
  children: React.ReactNode;
  accounts: SerializeFrom<ManagerAccount>[];
  activeAccountId: string;
  setActiveAccount: (id: string) => void;
}) {
  const navigate = useNavigate();

  const [open, setOpen] = useState(false);

  const activeAccount = useMemo(
    () => accounts.find(account => account.id === activeAccountId),
    [accounts, activeAccountId]
  );

  const accountsWithoutActive = useMemo(
    () => accounts.filter(account => account.id !== activeAccountId),
    [accounts, activeAccountId]
  );

  const handleAccountClick = (id: string) => {
    setActiveAccount(id);
    setOpen(false);
  };

  return (
    <>
      <div onClick={() => setOpen(true)}>{children}</div>
      <Transition.Root show={open} as={Fragment}>
        <Dialog
          className={"relative z-50"}
          onClose={val => {
            setOpen(false);
          }}
        >
          <div className="fixed z-50 overflow-hidden min-w-full min-h-screen max-h-screen">
            <Transition.Child
              as={Fragment}
              enter="ease-out duration-300"
              enterFrom="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
              enterTo="opacity-100 translate-y-0 sm:scale-100"
              leave="ease-in duration-200"
              leaveFrom="opacity-100 translate-y-0 sm:scale-100"
              leaveTo="opacity-0 translate-y-4 sm:translate-y-0 sm:scale-95"
            >
              <Dialog.Panel className="absolute w-11/12 md:max-w-[350px] top-24 sm:right-10 right-[4.166%] rounded-md bg-white text-left shadow-md transition-all ring-1 ring-gray-100">
                <div>
                  <header className="flex flex-col justify-center items-center gap-y-3 p-5 my-2">
                    <img
                      src={
                        activeAccount?.avatar_id
                          ? `/images/${activeAccount?.avatar_id}`
                          : "/assets/defaultAvatar.png"
                      }
                      alt=""
                      className="h-16 w-16 rounded-full object-cover"
                    />
                    <h2 className="text-xl font-semibold text-gray-900 text-center">
                      {activeAccount?.name}
                    </h2>
                    <CTA
                      onClick={() => {
                        setOpen(false);
                        navigate(`/intelligence/${activeAccountId}/account`);
                      }}
                    >
                      View Account Details
                    </CTA>
                  </header>
                  {accountsWithoutActive.length > 0 && (
                    <>
                      <div className="flex justify-between items-center px-5 my-4">
                        <h3 className="text-base font-semibold text-gray-900">
                          Switch Account
                        </h3>
                      </div>
                      <hr />
                      <div className="divide-y max-h-[calc(100vh-35rem)] overflow-y-auto overflow-x-visible">
                        {accountsWithoutActive.map((account, i) => (
                          <div
                            key={account.id}
                            className={tvAccountOption({
                              active: account.id === activeAccountId,
                            })}
                            onClick={() => handleAccountClick(account.id)}
                          >
                            <img
                              src={
                                account?.avatar_id
                                  ? `/images/${account?.avatar_id}`
                                  : "/assets/defaultAvatar.png"
                              }
                              alt={`${account.name} avatar`}
                              className="h-10 w-10 rounded-full mr-4 object-cover"
                            />
                            <span className="text-sm text-gray-900 [text-wrap:pretty]">
                              {account.name}
                            </span>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                  <hr />
                  <Link
                    to={`/logout`}
                    className="flex justify-center items-center py-5 text-sm text-gray-900 w-full hover:bg-gray-100 cursor-pointer transition-all ease-in-out duration-200"
                  >
                    <ArrowLeftOnRectangleIcon className="h-5 mr-1" />
                    Log out
                  </Link>
                </div>
              </Dialog.Panel>
            </Transition.Child>
          </div>
        </Dialog>
      </Transition.Root>
    </>
  );
}
