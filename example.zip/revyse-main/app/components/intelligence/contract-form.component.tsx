import { find, isEmpty } from "lodash";
import {
  CubeTransparentIcon,
  ExclamationCircleIcon,
  InformationCircleIcon,
  PlusIcon,
  XMarkIcon,
} from "@heroicons/react/24/outline";
import { Fragment, useCallback, useEffect, useMemo, useState } from "react";
import { useFetcher, useRevalidator } from "@remix-run/react";
import { CTA } from "../cta.component";

import type {
  Contract,
  ContractAIExtract,
  ContractAIExtractField,
  File as PrismaFile,
} from "@prisma/client";
import {
  ContractAIExtractFieldStatus,
  ContractAIExtractStatus,
  ContractStatus,
} from "@prisma/client";
import type { CrudFormFieldSelect } from "../form/crud-form.component";
import {
  CrudDateField,
  CrudRadioButtonField,
  CrudSelectField,
  CrudTextField,
  CrudAutocompleteField,
  FormSection,
} from "../form/crud-form.component";
import type { action as contractDocumentsAction } from "../../routes/intelligence.$id.contract.$contract_id_.documents";
import type { action as contractAction } from "../../routes/intelligence.$id.contract.$contract_id_._index";
import { EmailList } from "../email-list.component";
import { Tooltip } from "../tooltip.component";
import type { SerializeFrom } from "@remix-run/node";
import { CrudTextAreaField } from "../form/textarea.component";
import { calculateNextExpirationDate } from "~/utils/contracts.utils";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import relativeTime from "dayjs/plugin/relativeTime";
import { Button } from "../button.component";
import DocumentCard from "./document-card.component";
import DocumentModal from "./document-modal.component";
import { Modal } from "../modal.component";
import { Editor } from "../reactquill/richtext-editor.component";
import { useInterval } from "usehooks-ts";
import { ConfirmDeleteModal } from "../modals/confirm-delete-modal.component";
import { IntelligenceScreenHeader } from "./intelligence-screen-header.component";
import { CanDo } from "./can-do.component";
import { Permission } from "~/utils/intelligence-permission.utils";
import { encodeFilename } from "~/utils/file.utils";
import { ChevronDownIcon, ChevronUpIcon } from "@heroicons/react/20/solid";
dayjs.extend(utc);
dayjs.extend(relativeTime);

export type ContractFile = {
  id?: string;
  name?: string | null;
  created_at?: string;
  file?: SerializeFrom<PrismaFile> | null;
  new_file?: File;
  status?: "uploading" | "uploaded" | "success";
};

export function ContractForm({
  vendor,
  vendorOptions,
  accountUsers,
  contract,
  actionUrl,
  show_ai_assistant = false,
  last_ai_extract,
  locationOptions,
  show_contracting_party = false,
}: {
  vendor?: {
    id: string;
    name: string;
    description: string | null;
    logo_file_id: string | null;
  } | null;
  vendorOptions: {
    id: string;
    name: string;
    description: string | null;
    logo_file_id: string | null;
  }[];
  accountUsers: {
    id: string;
    first_name: string;
    last_name: string;
    email: string;
  }[];
  contract: SerializeFrom<
    Contract & {
      document_files: ContractFile[];
      manager_account_vendor: SerializeFrom<{
        manager_account_id: string;
      }>;
    }
  >;
  actionUrl: string;
  show_ai_assistant: boolean;
  last_ai_extract?: SerializeFrom<
    ContractAIExtract & { fields: SerializeFrom<ContractAIExtractField>[] }
  >;
  locationOptions: CrudFormFieldSelect["options"];
  show_contracting_party: boolean;
}) {
  const fetcher = useFetcher<typeof contractAction>();
  const uploadFetcher =
    useFetcher<SerializeFrom<typeof contractDocumentsAction>>();
  const deleteFetcher =
    useFetcher<SerializeFrom<typeof contractDocumentsAction>>();
  const analyzeContractFetcher = useFetcher();
  const revalidator = useRevalidator();

  // Starts/stops the polling
  const [pollingDelay, setPollingDelay] = useState<number | null>(null);

  // Poll for AI Extract status
  useInterval(() => {
    revalidator.revalidate();
  }, pollingDelay);

  useEffect(() => {
    if (
      last_ai_extract &&
      last_ai_extract.status === ContractAIExtractStatus.STARTED
    ) {
      setPollingDelay(2000); // start/continue polling
    } else {
      setPollingDelay(null); // Stop polling
    }
  }, [last_ai_extract]);

  const [selectedVendor, setSelectedVendor] = useState<
    (typeof vendorOptions)[number] | undefined
  >(vendor || undefined);

  const [newVendorNameInput, setNewVendorNameInput] = useState<
    string | undefined
  >(undefined);

  const defaultFields = useMemo(
    () =>
      !fetcher.data?.fields
        ? {
            ...contract,
          }
        : fetcher.data.fields,
    [fetcher.data, contract]
  );

  const [isMsa, setIsMsa] = useState<boolean>(Boolean(defaultFields.is_msa));

  const [contractStatus, setContractStatus] = useState(defaultFields.status);

  const [isMonthToMonth, setIsMonthToMonth] = useState<boolean>(
    Boolean(defaultFields.is_month_to_month)
  );

  const [autoRenews, setAutoRenews] = useState<boolean>(
    Boolean(defaultFields.will_auto_renew)
  );

  const [autoRenewLength, setAutoRenewLength] = useState<number | undefined>(
    defaultFields.auto_renew_term_length as number
  );

  const [currentTermEndDate, setCurrentTermEndDate] = useState<
    string | undefined
  >(
    defaultFields.current_term_end_date
      ? dayjs.utc(defaultFields.current_term_end_date).format("YYYY-MM-DD")
      : undefined
  );

  const [expiresAt, setExpiresAt] = useState(
    defaultFields.expires_at
      ? dayjs.utc(defaultFields.expires_at).format("YYYY-MM-DD")
      : undefined
  );

  const [documents, setDocuments] = useState<ContractFile[]>(
    contract.document_files?.map((doc: any) => ({
      ...doc,
      status: "uploaded",
    })) || []
  );

  const [documentModal, setDocumentModal] = useState<{
    open: boolean;
    document?: ContractFile;
  }>({ open: false, document: undefined });

  const [documentToDelete, setDocumentToDelete] = useState<string | undefined>(
    undefined
  );

  const [notes, setNotes] = useState(defaultFields.notes as string);
  const [noticeDetails, setNoticeDetails] = useState(
    defaultFields.termination_notice_details as string
  );
  const [aiAssistantOpen, setAiAssistantOpen] = useState(false);
  const [fallbackContractName, setFallbackContractName] = useState<
    string | undefined
  >(undefined);
  const [fallbackContractLength, setFallbackContractLength] =
    useState<string>("");
  const [fallbackEffectiveDate, setFallbackEffectiveDate] =
    useState<string>("");
  const [fallbackContractNoticePeriod, setFallbackContractNoticePeriod] =
    useState<string>("");
  const [fallbackInitialTermEndDate, setFallbackInitialTermEndDate] =
    useState<string>("");
  const [fallbackCurrentTermEndDate, setFallbackCurrentTermEndDate] =
    useState<string>("");
  const [fallbackContractOwner, setFallbackContractOwner] =
    useState<string>("");

  const [termLength, setTermLength] = useState<number | string | undefined>(
    defaultFields.term_length_months as number
  );

  const [showAdvancedSettings, setShowAdvancedSettings] = useState(false);

  const onSelectVendor = useCallback(
    (vendorId: string) => {
      setSelectedVendor(find(vendorOptions, ["id", vendorId]));
    },
    [vendorOptions]
  );

  const showError = useMemo(
    () => selectedVendor?.id == fetcher?.data?.fields?.vendor_id,
    [fetcher.data, selectedVendor]
  );

  const newVendor = useMemo(
    () => ({
      id: "new",
      name: "",
      description: "",
      logo_file_id: "",
    }),
    []
  );

  const vendorWithSameName = useMemo(
    () =>
      vendorOptions.find(
        vendor =>
          vendor.name.toLowerCase() === newVendorNameInput?.toLocaleLowerCase()
      ),
    [vendorOptions, newVendorNameInput]
  );

  const contractStatuses = [
    { label: ContractStatus.Active, value: ContractStatus.Active },
    { label: ContractStatus.Canceled, value: ContractStatus.Canceled },
    { label: ContractStatus.Pending, value: ContractStatus.Pending },
  ];

  const userOptions = accountUsers.map(user => ({
    label: `${user.first_name} ${user.last_name} - ${user.email}`,
    value: user.id,
  }));

  const handleOnDocumentChange = useCallback(
    ({
      id,
      name,
      file,
    }: {
      id: string | undefined;
      name?: string;
      file?: File;
    }) => {
      const newId = `new_${new Date().getTime()}`;

      setDocuments(docs => {
        if (id) {
          return docs?.map(doc => {
            if (doc.id === id) {
              return {
                ...doc,
                name,
                new_file: file,
                status: "uploading",
              };
            }
            return doc;
          });
        }
        return [
          ...docs,
          {
            id: newId,
            name,
            new_file: file,
            created_at: new Date().toISOString(),
            status: contract.id !== "new" ? "uploading" : "uploaded",
          },
        ];
      });

      const formData = new FormData();

      formData.append("id", id ?? newId);
      if (name) formData.append("name", name);
      if (file) formData.append("file", file, encodeFilename(file?.name));

      if (contract.id !== "new") {
        uploadFetcher.submit(formData, {
          action: `${actionUrl}/documents`,
          method: "post",
          encType: "multipart/form-data",
        });
      }
    },
    [uploadFetcher, actionUrl, contract]
  );

  useEffect(() => {
    if (uploadFetcher.data?.success) {
      setDocuments(docs => {
        return docs.map(doc => {
          if (
            doc.status === "uploading" &&
            doc.id === uploadFetcher.data?.fields?.id
          ) {
            return {
              ...doc,
              ...uploadFetcher.data?.contractFile,
              status: "success",
            };
          }
          return doc;
        });
      });

      setTimeout(() => {
        setDocuments(docs => {
          return docs.map(doc => {
            if (
              doc.status === "success" &&
              doc.id === uploadFetcher.data?.contractFile?.id
            ) {
              return {
                ...doc,
                status: "uploaded",
              };
            }
            return doc;
          });
        });
      }, 3000);
    }
  }, [uploadFetcher]);

  const handleDocumentDelete = useCallback(() => {
    if (!documentToDelete) return;

    const formData = new FormData();

    formData.append("id", documentToDelete);
    formData.append("intent", "delete");

    deleteFetcher.submit(formData, {
      action: `${actionUrl}/documents`,
      method: "post",
      encType: "multipart/form-data",
    });

    setDocuments(docs => docs.filter(doc => doc.id !== documentToDelete));
    setDocumentToDelete(undefined);
  }, [documentToDelete, deleteFetcher, actionUrl]);

  const handleDocumentClick = useCallback((doc: ContractFile) => {
    if (doc.new_file) {
      window.open(URL.createObjectURL(doc.new_file), "_blank");
    } else if (doc.file) {
      window.open(`/images/${doc.file.id}`, "_blank");
    }
  }, []);

  useEffect(() => {
    if (!expiresAt) return;
    const nextExpiresAt = calculateNextExpirationDate(
      autoRenews,
      autoRenewLength,
      new Date(expiresAt)
    );

    if (!nextExpiresAt) return;

    const nextExpiresAtDate = dayjs.utc(nextExpiresAt).format("YYYY-MM-DD");
    setCurrentTermEndDate(nextExpiresAtDate);
  }, [autoRenews, autoRenewLength, expiresAt]);

  const handleMonthToMonthChange = useCallback(
    (isMonthToMonth: boolean) => {
      setIsMonthToMonth(isMonthToMonth);
      if (isMonthToMonth) {
        setAutoRenewLength(1);
        setTermLength(1);
        setAutoRenews(true);
      } else {
        setAutoRenewLength(defaultFields.auto_renew_term_length as number);
        setTermLength(defaultFields.term_length_months as number);
      }
    },
    [defaultFields]
  );

  useEffect(() => {
    if (selectedVendor != newVendor && newVendorNameInput) {
      setNewVendorNameInput(undefined);
    }
  }, [selectedVendor, newVendor, newVendorNameInput]);

  return (
    <>
      <ConfirmDeleteModal
        isOpen={!!documentToDelete}
        onClose={() => setDocumentToDelete(undefined)}
        onConfirm={handleDocumentDelete}
        title="Delete this file"
        message="Are you sure you want to permanently delete this file forever?"
      />
      <Modal
        isOpen={!!aiAssistantOpen}
        onClose={() => setAiAssistantOpen(false)}
        manager={true}
        size="medium-small"
      >
        <div className="font-bold text-xl">AI Assistant</div>
        <div className="text-sm">
          AI Assistant can help you fill out the form and analyze documents.
        </div>

        {contract.id !== "new" ? (
          <div>
            <div className="flex justify-between items-start gap-2 mt-4">
              <div>
                Analyze Documents
                <div className="text-xs text-gray-400">
                  Last Analysis: {last_ai_extract?.status ?? "--"} -{" "}
                  {last_ai_extract &&
                    last_ai_extract.status === "COMPLETE" &&
                    dayjs(last_ai_extract.completed_at).fromNow()}
                </div>
              </div>
              {analyzeContractFetcher.state === "idle" ? (
                last_ai_extract &&
                last_ai_extract.status === ContractAIExtractStatus.STARTED ? (
                  <div className="text-sky-500">Analysis in progress...</div>
                ) : (
                  <CTA
                    onClick={() => {
                      analyzeContractFetcher.submit(
                        { something: "something" },
                        {
                          action: `/intelligence/${contract.manager_account_vendor.manager_account_id}/contract/${contract.id}/contract-extract`,
                          method: "post",
                          encType: "multipart/form-data",
                        }
                      );

                      return false;
                    }}
                  >
                    Analyze!
                  </CTA>
                )
              ) : (
                <div className="text-sky-500">Starting Analysis...</div>
              )}
            </div>

            {last_ai_extract && (
              <>
                <div className="grid grid-cols-3 gap-x-4 gap-y-2 mt-4">
                  <div className="font-medium">Field</div>
                  <div className="font-medium">Value</div>
                  <div className="font-medium">Source</div>
                  {last_ai_extract.fields.map(
                    (field, i) =>
                      field.status ===
                        ContractAIExtractFieldStatus.COMPLETE && (
                        <Fragment key={i}>
                          <div className="font-medium">{field.field_name}</div>
                          <code>{field.field_value}</code>
                          <div className="text-xs text-gray-600">
                            {field.reference}
                          </div>
                        </Fragment>
                      )
                  )}
                </div>
              </>
            )}
          </div>
        ) : (
          <div className="flex justify-between items-start gap-2 mt-4">
            <div>
              <div className="font-semibold">Fill form with defaults.</div>
              <div className="text-sm">
                We need the contract files in order to do analysis. This will
                help you get to uploading files faster.
              </div>
            </div>
            <CTA
              onClick={() => {
                setFallbackContractName("<CHANGE ME>");
                setFallbackContractLength("0");
                setFallbackContractNoticePeriod("0");
                setFallbackInitialTermEndDate("2021-01-30");
                setFallbackCurrentTermEndDate("2021-01-30");
                setFallbackEffectiveDate("2021-01-30");
                setFallbackContractOwner("<CHANGE ME>");
                setAiAssistantOpen(false);
              }}
            >
              Fill
            </CTA>
          </div>
        )}
      </Modal>
      <div>
        <fetcher.Form
          method="post"
          encType="multipart/form-data"
          className="space-y-6"
        >
          <IntelligenceScreenHeader
            title={
              contract.id !== "new" ? (
                <>
                  Edit contract:
                  <br /> {contract.name}
                </>
              ) : (
                "Add a new contract"
              )
            }
            description="Configure the key details of this contract, including 
              contract  owner and approver, term end dates, and auto-renewals, 
              and schedule future contract renewal reminders."
            buttonsSlot={
              <CTA type="submit" id="save-button">
                {fetcher.state === "submitting"
                  ? "Submitting..."
                  : "Save Contract"}
              </CTA>
            }
          />
          <div className="space-y-8">
            <div className="font-bold text-lg lg:text-2xl flex justify-between">
              <span>Select your vendor</span>
              {show_ai_assistant && (
                <span>
                  <CubeTransparentIcon
                    className="w-8 text-red-700"
                    onClick={() => setAiAssistantOpen(true)}
                  />
                </span>
              )}
            </div>
            <div className="lg:grid lg:grid-cols-2 gap-6 space-y-3 lg:space-y-0">
              <div className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min">
                {(!selectedVendor || selectedVendor == newVendor) && (
                  <div className="relative col-span-full">
                    <CrudAutocompleteField
                      field={{
                        name: "selectedVendor",
                        label: "Select Vendor",
                        type: "autocomplete" as const,
                        defaultValue: undefined,
                        errors:
                          (showError && fetcher?.data?.errors?.vendor_id) || [],
                        options: vendorOptions.map(vendor => ({
                          label: vendor.name,
                          value: vendor.id,
                        })),
                        onSelect: onSelectVendor,
                      }}
                    />
                  </div>
                )}
                {selectedVendor && selectedVendor != newVendor && (
                  <div className="relative col-span-full">
                    <CrudTextField
                      field={{
                        name: "selectedVendor",
                        label: "Select Vendor",
                        type: "text" as const,
                        defaultValue: selectedVendor.name,
                        errors:
                          (showError && fetcher?.data?.errors?.vendor_id) || [],
                        disabled: true,
                      }}
                    />
                    <button
                      id="clear-vendor"
                      className="absolute right-2 top-10 text-sky-500"
                      onClick={() => setSelectedVendor(undefined)}
                    >
                      <XMarkIcon className="h-5 w-5" />
                    </button>
                  </div>
                )}
                <Button
                  color="transparent"
                  onClick={() => setSelectedVendor(newVendor)}
                  className="text-xs"
                >
                  <PlusIcon className="h-4 w-4" />
                  &nbsp;Can’t find your vendor? Create one
                </Button>
              </div>
              {selectedVendor === newVendor && (
                <div className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg">
                  <input type="hidden" name="new_vendor" value="true" />
                  <div className="space-y-4 mb-3">
                    <CrudTextField
                      field={{
                        name: "vendor_name",
                        label: "Vendor Name",
                        type: "text" as const,
                        placeholder: "Type vendor name",
                        defaultValue: undefined,
                        errors: fetcher.data?.errors?.vendor_name ?? [],
                        maxCharacters: 55,
                        showMaxCharacters: !vendorWithSameName,
                        onChange: e => {
                          setNewVendorNameInput(e.target.value);
                        },
                      }}
                    />
                    {vendorWithSameName && (
                      <div className="text-sm text-amber-500 col-span-full -mt-8 flex">
                        <ExclamationCircleIcon className="h-6 mr-2 my-auto" />
                        <span className="my-auto">
                          There is already a vendor with this name.{" "}
                          <b
                            className="cursor-pointer hover:underline"
                            onClick={() => {
                              setSelectedVendor(vendorWithSameName);
                            }}
                          >
                            Select it here
                          </b>{" "}
                          or continue creating a new one.
                        </span>
                      </div>
                    )}
                  </div>
                  <CrudTextAreaField
                    className="w-full"
                    field={{
                      name: "description",
                      label:
                        "Describe the products or services this vendor provides",
                      type: "textarea" as const,
                      placeholder: "Type here",
                      defaultValue: undefined,
                      errors: fetcher.data?.errors?.description ?? [],
                      maxCharacters: 350,
                      rows: 4,
                    }}
                  />
                </div>
              )}
              {selectedVendor && selectedVendor != newVendor && (
                <div className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg space-y-4">
                  <div className="font-bold text-xl">
                    Selected vendor: {selectedVendor.name ?? vendor?.name}
                  </div>
                  <div className="flex space-x-4">
                    {selectedVendor.logo_file_id || vendor?.logo_file_id ? (
                      <img
                        className="w-16 h-16 rounded-lg"
                        src={`/images/${
                          selectedVendor.logo_file_id || vendor?.logo_file_id
                        }`}
                        alt="Vendor Logo"
                        width="64"
                        height="64"
                      />
                    ) : (
                      <img
                        className="w-16 h-16 rounded-lg"
                        src="/assets/default-logo.png"
                        alt="Vendor Logo"
                        width="64"
                        height="64"
                      />
                    )}
                    <div className="w-10/12">
                      <div className="whitespace-normal text-sm font-light truncate line-clamp-2">
                        {selectedVendor.description ?? vendor?.description}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>
            <div>
              <div className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min gap-y-40">
                {selectedVendor && (
                  <>
                    <input
                      name="vendor_id"
                      value={selectedVendor.id}
                      type="hidden"
                    />
                    <input type="hidden" name="new_vendor" value="false" />
                  </>
                )}
                <FormSection
                  border={false}
                  title="Primary Contract Information"
                  subtitle="Configure the high-level information for this contract."
                  spacing="compact"
                >
                  <CrudTextField
                    field={{
                      name: "name",
                      type: "text",
                      errors: fetcher?.data?.errors?.name ?? [],
                      label: "Contract Name",
                      placeholder: "Give your contract a name",
                      // defaultValue: fetcher.data
                      //   ? fetcher?.data?.fields?.name ?? undefined
                      //   : contract.name ?? fallbackContractName,
                      defaultValue: fetcher.data
                        ? fetcher?.data?.fields?.name ?? undefined
                        : fallbackContractName ?? contract.name,
                    }}
                  />
                  <CrudSelectField
                    field={{
                      name: "status",
                      type: "select",
                      options: contractStatuses,
                      errors: fetcher?.data?.errors?.status ?? [],
                      label: "Contract Status",
                      defaultValue: contractStatus ?? ContractStatus.Active,
                    }}
                    onChange={(e: any) => setContractStatus(e.target.value)}
                  />
                  {contractStatus === ContractStatus.Canceled && (
                    <CrudDateField
                      field={{
                        name: "canceled_at",
                        label: (
                          <div className="text-sm font-medium text-gray-900 mb-2">
                            Contract Cancellation Date{" "}
                            <span className="text-md font-normal text-gray-400 text-sm">
                              (Optional)
                            </span>{" "}
                          </div>
                        ),
                        type: "text",
                        errors: fetcher?.data?.errors?.canceled_at ?? [],
                        defaultValue: dayjs.utc().format("YYYY-MM-DD"),
                      }}
                    />
                  )}
                  <div className="my-3">
                    <button
                      className="font-light text-sky-500 flex items-center text-nowrap gap-x-2"
                      onClick={e => {
                        e.stopPropagation();
                        setShowAdvancedSettings(prev => !prev);
                      }}
                      type="button"
                    >
                      Advanced Settings
                      {showAdvancedSettings ? (
                        <ChevronUpIcon className="h-5" />
                      ) : (
                        <ChevronDownIcon className="h-5" />
                      )}
                    </button>
                  </div>
                  {showAdvancedSettings && (
                    <>
                      <CrudTextField
                        field={{
                          name: "contract_owner_name",
                          type: "text",
                          errors:
                            fetcher?.data?.errors?.contract_owner_name ?? [],
                          label: "Contract Owner",
                          placeholder: "Type a name",
                          defaultValue:
                            contract.contract_owner_name ??
                            fetcher?.data?.fields?.contract_owner_name ??
                            fallbackContractOwner,
                          showOptional: true,
                        }}
                      />
                      <CrudTextField
                        field={{
                          name: "approver",
                          type: "text",
                          errors: fetcher?.data?.errors?.approver ?? [],
                          label: "Contract Approver",
                          placeholder: "Type a name",
                          defaultValue:
                            fetcher?.data?.fields?.approver ??
                            contract.approver ??
                            undefined,
                          showOptional: true,
                        }}
                      />
                      {show_contracting_party && (
                        <CrudSelectField
                          field={{
                            name: "location_id",
                            label: "Mark Contract as Location-Level",
                            type: "select",
                            tooltipText: `If this is a location-level contract that is managed by corporate, select the location from the dropdown menu. 
																This action will restrict which locations can be assigned to line items on this contract, and will allow this 
																contract’s uploaded contract files to show in the location-level documents tab.`,
                            options: locationOptions,
                            errors: fetcher?.data?.errors?.location_id ?? [],
                            defaultValue:
                              fetcher?.data?.fields?.location_id ??
                              contract.location_id ??
                              undefined,
                            allowNull: true,
                            showOptional: true,
                            nullLabel: "Not Set",
                          }}
                        />
                      )}
                      <CanDo permission={Permission.ManageSensitiveContracts}>
                        <div className="col-span-full space-y-4">
                          <div className="flex items-center gap-x-2">
                            <p>Mark Contract as Sensitive</p>
                            <Tooltip
                              position="left"
                              text="By marking a contract as ‘sensitive’, the contract and its corresponding data will only be visible to users assigned the Company Owner role. All data for this contract will be hidden, even in reporting, for users without the Company Owner role."
                            >
                              <InformationCircleIcon className="h-5 text-gray-400 cursor-pointer" />
                            </Tooltip>
                          </div>
                          <div className="flex gap-x-3">
                            <CrudRadioButtonField
                              field={{
                                label: "No",
                                value: "false",
                                name: "is_sensitive",
                                defaultChecked: !contract.is_sensitive,
                                type: "radio",
                                errors:
                                  fetcher?.data?.errors?.is_sensitive ?? [],
                                description: "",
                              }}
                            />
                            <CrudRadioButtonField
                              field={{
                                label: "Yes",
                                value: "true",
                                name: "is_sensitive",
                                defaultChecked: contract.is_sensitive,
                                type: "radio",
                                errors:
                                  fetcher?.data?.errors?.is_sensitive ?? [],
                                description: "",
                              }}
                            />
                          </div>
                        </div>
                      </CanDo>
                    </>
                  )}
                </FormSection>
                <hr />
                <FormSection
                  border={false}
                  title="Upload Contract"
                  subtitle="Upload the contract document and other relevant files related to this contract."
                  spacing="compact"
                >
                  <div className="col-span-full">
                    {!isEmpty(documents) && (
                      <div className="space-y-4 mt-4">
                        {[...documents].reverse().map(doc => (
                          <DocumentCard
                            key={`${doc.id}-${doc.created_at}`}
                            document={doc}
                            onEditClick={e => {
                              e.stopPropagation();
                              setDocumentModal({
                                open: true,
                                document: doc,
                              });
                            }}
                            onDeleteClick={e => {
                              e.stopPropagation();
                              setDocumentToDelete(doc.id);
                            }}
                            onCardClick={() => handleDocumentClick(doc)}
                            isContract={true}
                          />
                        ))}
                      </div>
                    )}
                    <CTA
                      id="add-document-button"
                      fillStyle="outline"
                      variant="sky"
                      className={`col-span-full flex items-center ${
                        isEmpty(documents) ? "" : "mt-5"
                      }`}
                      onClick={() =>
                        setDocumentModal({
                          open: true,
                          document: undefined,
                        })
                      }
                    >
                      <PlusIcon className="mr-2 h-5" /> Add files
                    </CTA>
                    <DocumentModal
                      title={
                        documentModal.document
                          ? "Edit Contract"
                          : "Add New Contract"
                      }
                      buttonLabel={
                        documentModal.document
                          ? "Save Contract"
                          : "Add Contract"
                      }
                      isOpen={documentModal.open}
                      document={documentModal.document}
                      onClose={() =>
                        setDocumentModal({ open: false, document: undefined })
                      }
                      modalType="contract"
                      onChange={handleOnDocumentChange}
                    />
                  </div>
                </FormSection>
                <hr />
                <FormSection
                  border={false}
                  title="Contract Terms"
                  subtitle="Configure the specific terms of this contract, including term length and auto-renewal terms."
                  spacing="compact"
                >
                  <div className="col-span-full space-y-4">
                    <div className="col-span-full flex items-center space-x-2">
                      <div>Is this an MSA?</div>{" "}
                      <span className="text-md font-normal text-gray-400 text-sm">
                        (Optional)
                      </span>
                      <Tooltip
                        position="left"
                        text="An MSA is a master service agreement. An MSA typically governs current and future activities between two parties."
                      >
                        <div className="flex flex-row items-center cursor-pointer">
                          <InformationCircleIcon className="h-5 text-gray-400" />
                        </div>
                      </Tooltip>
                    </div>
                    <div className="flex space-x-3">
                      <CrudRadioButtonField
                        field={{
                          label: "No",
                          value: "false",
                          checked: !isMsa,
                          name: "is_msa",
                          type: "radio",
                          errors: fetcher?.data?.errors?.is_msa ?? [],
                          description: "",
                          onChange: e => setIsMsa(!e.target.value),
                        }}
                      />
                      <CrudRadioButtonField
                        field={{
                          label: "Yes",
                          value: "true",
                          checked: isMsa,
                          name: "is_msa",
                          type: "radio",
                          errors: fetcher?.data?.errors?.is_msa ?? [],
                          description: "",
                          onChange: e => setIsMsa(Boolean(e.target.value)),
                        }}
                      />
                    </div>
                  </div>
                  <div className="col-span-full space-y-4">
                    <div className="col-span-full flex items-center space-x-2">
                      <div>Is this a month-to-month contract?</div>
                      <Tooltip
                        position="left"
                        text="A month-to-month contract is typically a monthly contract with a renewable term of one month."
                      >
                        <div className="flex flex-row items-center cursor-pointer">
                          <InformationCircleIcon className="h-5 text-gray-400" />
                        </div>
                      </Tooltip>
                    </div>
                    <div className="flex space-x-3">
                      <CrudRadioButtonField
                        field={{
                          label: "No",
                          value: "false",
                          checked: !isMonthToMonth,
                          name: "is_month_to_month",
                          type: "radio",
                          errors:
                            fetcher?.data?.errors?.is_month_to_month ?? [],
                          description: "",
                          onChange: e => handleMonthToMonthChange(false),
                        }}
                      />
                      <CrudRadioButtonField
                        field={{
                          label: "Yes",
                          value: "true",
                          checked: isMonthToMonth,
                          name: "is_month_to_month",
                          type: "radio",
                          errors:
                            fetcher?.data?.errors?.is_month_to_month ?? [],
                          description: "",
                          onChange: e => handleMonthToMonthChange(true),
                        }}
                      />
                    </div>
                  </div>
                  <CrudTextField
                    field={{
                      name: "term_length_months",
                      type: "number",
                      errors: fetcher?.data?.errors?.term_length_months ?? [],
                      label:
                        "What is the length of the contract term (in months)?",
                      placeholder: "Type number of months",
                      defaultValue: termLength ?? fallbackContractLength,
                      onChange: e => setTermLength(parseInt(e.target.value)),
                    }}
                  />
                  <div className="col-span-full space-y-4">
                    <div className="col-span-full flex items-center space-x-2">
                      <div>Does this contract auto renew?</div>
                      <Tooltip
                        position="left"
                        text="Auto-renewal typically refers to a contract that automatically renews at the end of each term until the agreement is terminated."
                      >
                        <div className="flex flex-row items-center cursor-pointer">
                          <InformationCircleIcon className="h-5 text-gray-400" />
                        </div>
                      </Tooltip>
                    </div>
                    <div className="flex space-x-3">
                      <CrudRadioButtonField
                        field={{
                          label: "No",
                          value: "false",
                          checked: !autoRenews,
                          name: "will_auto_renew",
                          type: "radio",
                          errors: fetcher?.data?.errors?.will_auto_renew ?? [],
                          description: "",
                          onChange: e => setAutoRenews(!e.target.value),
                        }}
                      />
                      <CrudRadioButtonField
                        field={{
                          label: "Yes",
                          value: "true",
                          checked: autoRenews,
                          name: "will_auto_renew",
                          type: "radio",
                          errors: fetcher?.data?.errors?.will_auto_renew ?? [],
                          description: "",
                          onChange: e => setAutoRenews(Boolean(e.target.value)),
                        }}
                      />
                    </div>
                  </div>
                  <CrudTextField
                    field={{
                      name: "auto_renew_term_length",
                      type: "number",
                      errors:
                        fetcher?.data?.errors?.auto_renew_term_length ?? [],
                      label:
                        "If yes, what is the length of the auto-renew term (in months)?",
                      placeholder: "Type number of months",
                      defaultValue: autoRenewLength,
                      reactiveDefaultValue: true,
                      onChange: e =>
                        setAutoRenewLength(parseInt(e.target.value)),
                    }}
                  />
                  <div className="col-span-full">
                    <div className="flex justify-between items-center space-x-3">
                      <div className="flex items-center space-x-2">
                        <label
                          htmlFor="effective_date"
                          className="block text-sm font-medium leading-6 text-gray-900"
                        >
                          <div className="text-sm font-medium text-gray-900 mb-2">
                            Contract Effective Date{" "}
                            <span className="text-md font-normal text-gray-400 text-sm">
                              (Optional)
                            </span>{" "}
                          </div>
                        </label>
                      </div>
                    </div>
                    <CrudDateField
                      field={{
                        name: "effective_date",
                        type: "text",
                        errors: fetcher?.data?.errors?.effective_date ?? [],
                        label: "",
                        defaultValue:
                          dayjs
                            .utc(contract.effective_date)
                            .format("YYYY-MM-DD") ??
                          dayjs
                            .utc(fetcher.data?.fields?.effective_date)
                            .format("YYYY-MM-DD") ??
                          fallbackEffectiveDate ??
                          undefined,
                      }}
                    />
                  </div>
                  <div className="col-span-full">
                    <div className="flex justify-between items-center space-x-3">
                      <div className="flex items-center space-x-2">
                        <label
                          htmlFor="expires_at"
                          className="block text-sm font-medium leading-6 text-gray-900"
                        >
                          <div className="text-sm font-medium text-gray-900 mb-2">
                            Initial Term End Date{" "}
                            <span className="text-md font-normal text-gray-400 text-sm">
                              (Optional)
                            </span>{" "}
                          </div>
                        </label>
                        <Tooltip
                          position="right"
                          text="The initial term end date is the end date of the contract’s first initial term following execution."
                        >
                          <div className="flex flex-row items-center space-x-1 cursor-pointer">
                            <InformationCircleIcon className="h-5 text-gray-400" />
                          </div>
                        </Tooltip>
                      </div>
                    </div>
                    <CrudDateField
                      field={{
                        name: "expires_at",
                        type: "text",
                        errors: fetcher?.data?.errors?.expires_at ?? [],
                        label: "",
                        defaultValue: expiresAt ?? fallbackInitialTermEndDate,
                        onChange: e => setExpiresAt(e.target.value),
                      }}
                    />
                  </div>
                  <div className="col-span-full">
                    <div className="flex justify-between items-center space-x-3">
                      <div className="flex items-center space-x-2">
                        <label
                          htmlFor="current_term_end_date"
                          className="block text-sm font-medium leading-6 text-gray-900"
                        >
                          Current Term End Date
                        </label>
                        <Tooltip
                          position="right"
                          text="If the contract is still in its initial term, the current term end date is the same as the initial term end date. If the contract has renewed since execution, the current term end date would be the end of the current renewal term."
                        >
                          <div className="flex flex-row items-center space-x-1 cursor-pointer">
                            <InformationCircleIcon className="h-5 text-gray-400" />
                          </div>
                        </Tooltip>
                      </div>
                    </div>
                    <CrudDateField
                      field={{
                        name: "current_term_end_date",
                        type: "text",
                        errors:
                          fetcher?.data?.errors?.current_term_end_date ?? [],
                        label: "",
                        defaultValue:
                          currentTermEndDate ?? fallbackCurrentTermEndDate,
                        onChange: e => setCurrentTermEndDate(e.target.value),
                      }}
                    />
                  </div>
                  <CrudTextField
                    field={{
                      name: "termination_notice_period",
                      type: "number",
                      errors:
                        fetcher?.data?.errors?.termination_notice_period ?? [],
                      label: (
                        <div className="text-sm font-medium text-gray-900 mb-2">
                          What is the termination notice period (in days)?{" "}
                          <span className="text-md font-normal text-gray-400 text-sm">
                            (Optional)
                          </span>{" "}
                        </div>
                      ),
                      placeholder: "Type number of days",
                      defaultValue:
                        contract.id !== "new"
                          ? contract.termination_notice_period ?? undefined
                          : fetcher?.data?.fields?.termination_notice_period ??
                            fallbackContractNoticePeriod,
                    }}
                  />
                  <div className="col-span-full h-full mb-8">
                    <div className="text-sm font-medium text-gray-900 mb-2">
                      Termination Notice Details{" "}
                      <span className="text-md font-normal text-gray-400 text-sm">
                        (Optional)
                      </span>{" "}
                    </div>
                    <Editor
                      onChange={e => setNoticeDetails(e.html)}
                      placeholder="Type here"
                      value={noticeDetails}
                      className="h-24"
                      errors={
                        fetcher?.data?.errors?.termination_notice_details ?? []
                      }
                      toolBarOptions={{
                        toolbar: [["bold", "italic", "underline"], ["clean"]],
                      }}
                    />
                    <input
                      type="hidden"
                      name="termination_notice_details"
                      value={noticeDetails}
                    />
                  </div>
                </FormSection>
                <hr />
                <FormSection
                  border={false}
                  title="Set Up a Renewal Reminder"
                  subtitle="Get notified when the contract’s term end date is approaching, and schedule an automatic reminder to keep contract info up to date."
                  spacing="compact"
                >
                  {!isMonthToMonth ? (
                    <CrudTextField
                      field={{
                        name: "renewal_reminder_lead_time_months",
                        type: "number",
                        errors:
                          fetcher?.data?.errors
                            ?.renewal_reminder_lead_time_months ?? [],
                        label: (
                          <div className="text-sm font-medium text-gray-900 mb-2">
                            How many months in advance do you want a renewal
                            reminder?{" "}
                            <span className="text-md font-normal text-gray-400 text-sm">
                              (Optional)
                            </span>{" "}
                          </div>
                        ),
                        placeholder: "Number of months",
                        defaultValue:
                          contract.renewal_reminder_lead_time_months ??
                          (fetcher?.data?.fields
                            ?.renewal_reminder_lead_time_months as number) ??
                          undefined,
                      }}
                    />
                  ) : (
                    <CrudDateField
                      field={{
                        name: "renewal_reminder_date",
                        type: "text",
                        errors:
                          fetcher?.data?.errors?.renewal_reminder_date ?? [],
                        label: (
                          <div className="text-sm font-medium text-gray-900 mb-2">
                            When would you like a renewal reminder?{" "}
                            <span className="text-md font-normal text-gray-400 text-sm">
                              (Optional)
                            </span>{" "}
                          </div>
                        ),
                        defaultValue: defaultFields.renewal_reminder_date
                          ? dayjs
                              .utc(defaultFields.renewal_reminder_date)
                              .format("YYYY-MM-DD")
                          : undefined,
                      }}
                      minDate={new Date().toISOString().split("T")[0]}
                    />
                  )}
                  <div className="col-span-full">
                    <EmailList
                      name="renewal_reminder_emails"
                      label="Which email address should receive the renewal reminder?"
                      emails={
                        fetcher?.data?.fields?.renewal_reminder_emails
                          ? [
                              fetcher?.data?.fields
                                ?.renewal_reminder_emails as string,
                            ]
                          : contract.renewal_reminder_emails
                      }
                    ></EmailList>
                  </div>
                  <CrudSelectField
                    field={{
                      name: "task_owner_id",
                      type: "select",
                      allowNull: true,
                      options: userOptions,
                      errors: fetcher?.data?.errors?.task_owner_id ?? [],
                      label: (
                        <div className="text-sm font-medium text-gray-900 mb-2">
                          Assign the user responsible for updating the contract
                          info at renewal{" "}
                          <Tooltip
                            position="left"
                            text="Select the user that will be responsible for completing any action-items in Revyse when the contract renews."
                          >
                            <div className="flex flex-row items-center cursor-pointer">
                              <InformationCircleIcon className="h-5 text-gray-400" />
                            </div>
                          </Tooltip>
                        </div>
                      ),
                      defaultValue:
                        contract.id !== "new"
                          ? contract.task_owner_id ?? undefined
                          : fetcher?.data?.fields?.task_owner_id ?? undefined,
                    }}
                  />
                </FormSection>
                <hr />
                <FormSection
                  border={false}
                  title="Notes"
                  subtitle="Use the notes field to call out important contract terms or highlight specific details in the agreement."
                  spacing="compact"
                >
                  <div className="col-span-full h-full mb-8">
                    <div className="text-sm font-medium text-gray-900 mb-2">
                      Notes{" "}
                      <span className="text-md font-normal text-gray-400 text-sm">
                        (Optional)
                      </span>{" "}
                    </div>
                    <Editor
                      onChange={e => setNotes(e.html)}
                      placeholder="Type here"
                      value={notes}
                      className="h-24"
                      errors={fetcher?.data?.errors?.notes ?? []}
                      toolBarOptions={{
                        toolbar: [["bold", "italic", "underline"], ["clean"]],
                      }}
                    />
                    <input type="hidden" name="notes" value={notes} />
                  </div>
                </FormSection>
              </div>
              <div className="flex justify-end py-8">
                <CTA type="submit">
                  <>
                    {fetcher.state === "submitting"
                      ? "Submitting..."
                      : "Save Contract"}
                  </>
                </CTA>
              </div>
            </div>
          </div>
        </fetcher.Form>
      </div>
    </>
  );
}
