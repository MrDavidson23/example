import { useCallback, useMemo } from "react";
import { Table } from "../table.component";
import type { ManagerAccountRole, User } from "@prisma/client";
import dayjs from "dayjs";
import type { SerializeFrom } from "@remix-run/node";
import { TaskScheduleStatusLabels } from "~/utils/constants.utils";
import StatusChip from "~/components/status-chip.component";
import type { Task } from "~/utils/tasks.utils";
import { TaskType, generateTaskName, getTaskType } from "~/utils/tasks.utils";
import { Avatar } from "~/components/avatar.component";
import { ChatBubbleOvalLeftEllipsisIcon } from "@heroicons/react/24/outline";
import { getRemainingTimeString } from "~/utils/date.utils";
import { useNavigate } from "@remix-run/react";
import type { TableColumn } from "../table.component";
import { Button } from "~/components/button.component";

export type TasksTableItem = SerializeFrom<
  Task & {
    task_owner: ManagerAccountRole & {
      user: User;
    };
    group_chat: {
      _count: {
        messages: number;
      };
    };
  }
>;

export function TasksTable({
  items,
  onClickRow,
  columnsToShow,
  onOrderBy,
  accountId,
}: {
  items: TasksTableItem[];
  onClickRow?: (value: TasksTableItem) => any | void;
  columnsToShow: string[];
  onOrderBy?: (orderBy: string) => void;
  accountId: string;
}) {
  const navigate = useNavigate();
  const columnRenders: Record<
    string,
    TableColumn<TasksTableItem>
  > = useMemo(() => {
    return {
      taskName: {
        name: "task_name",
        label: "Task Name",
        sortable: true,
        renderer: (task: TasksTableItem) => {
          const taskName = generateTaskName(task);
          return <span>{taskName}</span>;
        },
      },
      dueDate: {
        name: "due_date",
        label: "Due Date",
        sortable: true,
        renderer: (task: TasksTableItem) =>
          task.due_date
            ? dayjs.utc(task.due_date).format("MMM D, YYYY")
            : "No Data",
      },
      taskOwner: {
        name: "task_owner",
        label: "Owner",
        sortable: true,
        renderer: (task: TasksTableItem) => (
          <div className="flex items-center gap-x-1">
            <Avatar
              first_name={task.task_owner.user.first_name}
              last_name={task.task_owner.user.last_name}
              img_url={task.task_owner.user.avatar_url}
              className="h-8 w-8 text-sm"
            />
            {task.task_owner.user.first_name} {task.task_owner.user.last_name}
          </div>
        ),
      },
      scheduleStatus: {
        name: "schedule_status",
        label: "Status",
        sortable: true,
        renderer: (task: TasksTableItem) => (
          <div className="flex items-center">
            <StatusChip
              model="TaskScheduleStatus"
              status={task.schedule_status}
              label={TaskScheduleStatusLabels[task.schedule_status]}
              className="text-sm w-32"
            />
            {task.group_chat._count.messages > 0 && (
              <Button
                color="transparent"
                onClick={e => {
                  e.stopPropagation();
                  e.preventDefault();
                  navigate(
                    getTaskType(task) === TaskType.TaskContractRenewal
                      ? `/intelligence/${accountId}/tasks/contract-renewal/${task.id}?chat=true`
                      : `/intelligence/${accountId}/tasks/location-disposition/${task.id}?chat=true`
                  );
                }}
              >
                <div className="relative h-8 w-8 ml-2 cursor-pointer hover:scale-110 cursor-pointer transition ease-in-out duration-300">
                  <ChatBubbleOvalLeftEllipsisIcon className="h-8 text-sky-500" />
                  <div className="absolute top-0.5 right-0.5 w-2.5 h-2.5 rounded-full bg-yellow-400 border border-white"></div>
                </div>
              </Button>
            )}
          </div>
        ),
      },
      completionStatus: {
        name: "completion_status",
        label: "Status",
        sortable: true,
        renderer: (task: TasksTableItem) => (
          <StatusChip
            model="TaskCompletionStatus"
            status={task.completion_status}
            label={task.completion_status}
            className="text-sm"
          />
        ),
      },
      startDateAway: {
        name: "start_date",
        label: "Start Date",
        sortable: true,
        renderer: (task: TasksTableItem) =>
          getRemainingTimeString(task.start_date),
      },
    };
  }, [accountId, navigate]);

  const cols = columnsToShow.map(column => columnRenders[column]);

  const handleOrderBy = useCallback(
    (orderBy: Record<string, string>) => {
      const orderByString = Object.entries(orderBy)
        .map(([key, value]) => `${value == "desc" ? "-" : ""}${key}`)
        .join(",");
      if (onOrderBy) {
        onOrderBy(orderByString);
      }
    },
    [onOrderBy]
  );

  return (
    <Table
      cols={cols}
      data={items}
      onClickRow={onClickRow ?? (() => {})}
      alignment="middle"
      showSelectBox={false}
      variant="white"
      showAddButton={false}
      allowSorting={true}
      onOrderBy={handleOrderBy}
    />
  );
}
