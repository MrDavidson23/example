import {
  ClockIcon,
  InformationCircleIcon,
  XCircleIcon,
} from "@heroicons/react/24/outline";
import type {
  Contract,
  ManagerAccountVendor,
  TaskContractRenewal,
} from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { useFetcher } from "@remix-run/react";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { useMemo, useState } from "react";
import FileUploadZone from "~/components/file-upload-zone.component";
import {
  CrudDateField,
  CrudRadioButtonField,
  CrudSelectField,
  CrudTextField,
} from "~/components/form/crud-form.component";
import { GridSelect } from "~/components/form/grid-select.component";
import type { WizardStep } from "~/components/modals/wizard-modal.component";
import { WizardModal } from "~/components/modals/wizard-modal.component";
import { Tooltip } from "~/components/tooltip.component";
import { type action } from "~/routes/_api.intelligence.wizard-task-contract-renewal.$intent";
dayjs.extend(utc);

const MB = 1024 * 1024;
const MAX_BYTE_LIMIT = 60 * MB;

export enum WizardTaskContractRenewalStep {
  Status = "status",
  RenewedTermsAndPricing = "renewed-terms-and-pricing",
  RenewedNewReminder = "renewed-new-reminder",
  RenewedSuccess = "renewed-success",
  PendingDueDate = "pending-due-date",
  PendingSuccess = "pending-success",
  CanceledConfirmation = "canceled-confirmation",
  CanceledSuccess = "canceled-success",
}

export function ContractRenewalWizard({
  isOpen,
  onClose,
  task,
  taskOwnerOptions,
}: {
  isOpen: boolean;
  onClose: () => void;
  task: SerializeFrom<
    TaskContractRenewal & {
      contract: Contract & {
        manager_account_vendor: ManagerAccountVendor & {
          vendor: { name: string };
        };
      };
    }
  >;
  taskOwnerOptions: { value: string; label: string }[];
}) {
  // This is the state that will be used to store the form values as the user progresses through the wizard.
  const [formValues, setFormValues] = useState<
    Record<string, FormDataEntryValue>
  >({});

  const fetcher = useFetcher<typeof action>();

  const errors = useMemo(
    () => (fetcher.data && "errors" in fetcher.data ? fetcher.data.errors : {}),
    [fetcher.data]
  );

  const steps: WizardStep[] = useMemo(
    () =>
      generateWizardSteps(
        task,
        task.contract,
        formValues,
        taskOwnerOptions,
        errors
      ),
    [task, formValues, taskOwnerOptions, errors]
  );

  return (
    <WizardModal
      isOpen={isOpen}
      onClose={onClose}
      steps={steps}
      size="medium"
      initialStepId="status-selector"
      onFormValuesChange={setFormValues}
      submitUrl="/intelligence/wizard-task-contract-renewal"
      extraFormDataOnSubmit={{
        task_id: task.id,
        manager_account_id:
          task.contract.manager_account_vendor.manager_account_id,
      }}
      fetcher={fetcher}
    />
  );
}

const generateWizardSteps = (
  task: SerializeFrom<TaskContractRenewal>,
  contract: SerializeFrom<
    Contract & {
      manager_account_vendor: ManagerAccountVendor & {
        vendor: { name: string };
      };
    }
  >,
  formValues: Record<string, FormDataEntryValue>,
  taskOwnerOptions: { value: string; label: string }[],
  actionErrors: Record<string, string[] | null>
): WizardStep[] => [
  {
    id: WizardTaskContractRenewalStep.Status,
    title: "Alright, let’s update your contract info.",
    subtitle: `What is the new status of ${contract.name}?`,
    body: (
      <>
        <div>
          If your contract has renewed, select “It was renewed.” If it is still
          pending, select “It is still pending.” If your contract was canceled
          and is no longer active, select “It was canceled.”
        </div>
        <div className="h-36 mt-8">
          <GridSelect
            name="status"
            options={[
              {
                label: "It was renewed",
                value: "renewed",
                icon: <PartyIcon className="text-green-500 h-[60px] w-12" />,
              },
              {
                label: "It is still pending",
                value: "pending",
                icon: (
                  <ClockIcon className="text-yellow-400 h-[60px] w-[60px]" />
                ),
              },
              {
                label: "It was canceled",
                value: "canceled",
                icon: (
                  <XCircleIcon className="text-red-500 h-[60px] w-[60px]" />
                ),
              },
            ]}
          />
        </div>
      </>
    ),
    ctas: {
      primary: {
        label: "Continue",
        onClick: values => {
          const statusStep = {
            renewed: WizardTaskContractRenewalStep.RenewedTermsAndPricing,
            pending: WizardTaskContractRenewalStep.PendingDueDate,
            canceled: WizardTaskContractRenewalStep.CanceledConfirmation,
          };
          const to = statusStep[values.status as keyof typeof statusStep];
          return { to };
        },
        resetFormValues: true,
      },
      secondary: {
        label: "Return to task details",
      },
    },
  },
  {
    id: WizardTaskContractRenewalStep.RenewedTermsAndPricing,
    title: "Nice work!",
    subtitle: `Let’s review any changes to your terms or pricing.`,
    body: (
      <>
        <CrudDateField
          field={{
            defaultValue: formValues.current_term_end_date
              ? dayjs
                  .utc(formValues.current_term_end_date as string)
                  .format("YYYY-MM-DD")
              : contract.current_term_end_date
              ? dayjs.utc(contract.current_term_end_date).format("YYYY-MM-DD")
              : undefined,
            name: "current_term_end_date",
            label: (
              <div>
                What is the end date of the contract's renewed term?
                <Tooltip
                  text="The current term end date is the end date of the current renewal term. 
                  This is typically the date that the contract will either renew once again or terminate."
                >
                  <div className="flex items-center cursor-pointer ml-2">
                    <InformationCircleIcon className="h-5 text-gray-400" />
                  </div>
                </Tooltip>
              </div>
            ),
            type: "text",
            errors: actionErrors.current_term_end_date ?? [],
          }}
        />
        <div className="mt-4">
          <label
            className="flex items-center space-x-2 text-sm font-medium leading-6 text-gray-900"
            htmlFor="pricing_change"
          >
            Did your pricing or products and services change?
            <Tooltip
              text="Keeping your pricing information up-to-date at the line item level will allow 
                you to more accurately track contracted spend by vendor, product, category, and department."
            >
              <div className="flex items-center cursor-pointer ml-2">
                <InformationCircleIcon className="h-5 text-gray-400" />
              </div>
            </Tooltip>
          </label>
          <div className="flex space-x-3 mt-2">
            <CrudRadioButtonField
              field={{
                label: "Yes",
                value: "true",
                name: "pricing_change",
                type: "radio",
                defaultChecked: formValues.pricing_change
                  ? formValues.pricing_change === "true"
                  : true,
                errors: [],
                description: "",
              }}
            />
            <CrudRadioButtonField
              field={{
                label: "No",
                value: "false",
                name: "pricing_change",
                type: "radio",
                errors: [],
                defaultChecked: formValues.pricing_change === "false",
                description: "",
              }}
            />
          </div>
        </div>
        <div className="space-y-2">
          <label
            className="flex items-center space-x-2 text-sm font-medium leading-6 text-gray-900"
            htmlFor="contract_file"
          >
            Upload new contract
            <span className="text-md font-normal text-gray-400 text-sm ml-2">
              (Optional)
            </span>{" "}
          </label>
          <CrudTextField
            field={{
              defaultValue: formValues.contract_file_name as string | undefined,
              name: "contract_file_name",
              label: "",
              placeholder: "Contract file name",
              type: "text",
              errors: actionErrors.contract_file_name ?? [],
            }}
          />
          <FileUploadZone
            name="contract_file"
            currentFileName={
              formValues.contract_file
                ? (formValues.contract_file as File).name
                : undefined
            }
            errors={actionErrors.contract_file ?? []}
            maxFileSize={MAX_BYTE_LIMIT}
            multiple={false}
          />
        </div>
      </>
    ),
    ctas: {
      primary: {
        label: "Continue",
        to: WizardTaskContractRenewalStep.RenewedNewReminder,
        checkForm: true,
      },
      secondary: {
        label: "Return to task details",
      },
      back: {
        to: WizardTaskContractRenewalStep.Status,
      },
    },
  },
  {
    id: WizardTaskContractRenewalStep.RenewedNewReminder,
    title: "You're almost done.",
    subtitle: `Let’s schedule your next renewal reminder.`,
    body: (
      <div className="space-y-4">
        <h5 className="text-base">
          Confirm your reminder cadence and assigned task owner below.
        </h5>
        {!contract.is_month_to_month ? (
          <CrudTextField
            field={{
              name: "renewal_reminder_lead_time_months",
              type: "number",
              errors: actionErrors.renewal_reminder_lead_time_months ?? [],
              label: (
                <div className="text-sm font-medium text-gray-900 mb-2">
                  How many months in advance do you want a renewal reminder?{" "}
                  <span className="text-md font-normal text-gray-400 text-sm">
                    (Optional)
                  </span>{" "}
                  <Tooltip text="Type the number of months in advance of the contract’s new term end date that you’d like to receive a renewal reminder.">
                    <div className="flex flex-row items-center cursor-pointer">
                      <InformationCircleIcon className="h-5 text-gray-400" />
                    </div>
                  </Tooltip>
                </div>
              ),
              placeholder: "Number of months",
              defaultValue:
                contract.renewal_reminder_lead_time_months ?? undefined,
            }}
          />
        ) : (
          <CrudDateField
            field={{
              name: "renewal_reminder_date",
              type: "text",
              errors: actionErrors.renewal_reminder_date ?? [],
              label: (
                <div className="mb-2">
                  When would you like a renewal reminder?{" "}
                  <span className="text-md font-normal text-gray-400 text-sm">
                    (Optional)
                  </span>{" "}
                  <Tooltip text="Select the date that you would like your next contract renewal reminder.">
                    <div className="flex flex-row items-center cursor-pointer">
                      <InformationCircleIcon className="h-5 text-gray-400" />
                    </div>
                  </Tooltip>
                </div>
              ),
              defaultValue: contract.renewal_reminder_date ?? undefined,
            }}
            minDate={new Date().toISOString().split("T")[0]}
          />
        )}
        <CrudSelectField
          field={{
            name: "task_owner_id",
            type: "select",
            options: taskOwnerOptions,
            errors: actionErrors.task_owner_id ?? [],
            label: (
              <div className="text-sm font-medium text-gray-900 mb-2">
                Assign the user responsible for updating the contract info at
                renewal{" "}
                <Tooltip text="Select the user that will be responsible for completing any action-items in Revyse when the contract comes up for renewal again.">
                  <div className="flex flex-row items-center cursor-pointer">
                    <InformationCircleIcon className="h-5 text-gray-400" />
                  </div>
                </Tooltip>
              </div>
            ),
            defaultValue: contract.task_owner_id ?? undefined,
          }}
        />
      </div>
    ),
    ctas: {
      primary: {
        label: "Submit",
        submit: true,
        to: WizardTaskContractRenewalStep.RenewedSuccess,
      },
      secondary: {
        label: "Return to task details",
      },
      back: {
        to: WizardTaskContractRenewalStep.RenewedTermsAndPricing,
      },
    },
  },
  {
    id: WizardTaskContractRenewalStep.RenewedSuccess,
    icon: "success",
    title: "Congrats! Your contract has been updated.",
    subtitle: `This task is now complete.`,
    body: (
      <>
        Your contract renewal information for {contract.name} has been saved and
        this task has been archived.
        {formValues.pricing_change === "true" && (
          <div className="mt-4">
            Click “Update Pricing” below to enter new pricing information for
            each line item that was renegotiated on your renewed contract.
          </div>
        )}
      </>
    ),
    ctas: {
      primary:
        formValues.pricing_change === "true"
          ? {
              label: "Update Pricing",
              toLink: `/intelligence/${contract.manager_account_vendor.manager_account_id}/contract/${contract.id}/line-item`,
            }
          : undefined,
      secondary: {
        label: "Return to Tasks",
        toLink: `/intelligence/${contract.manager_account_vendor.manager_account_id}/tasks`,
      },
    },
  },
  {
    id: WizardTaskContractRenewalStep.PendingDueDate,
    title: "Contract renewal is still pending.",
    subtitle: `Let’s review and update the due date for this task.`,
    body: (
      <>
        While you’re still negotiating the terms of your renewal, you can push
        the due date for this task to a later date.
        <CrudDateField
          className="mt-4"
          field={{
            name: "due_date",
            type: "text",
            errors: actionErrors.due_date ?? [],
            label: "Select a new task due date",
            defaultValue:
              (formValues.due_date as string | undefined) ??
              task.due_date ??
              undefined,
          }}
          minDate={new Date().toISOString().split("T")[0]}
        />
      </>
    ),
    ctas: {
      primary: {
        label: "Submit",
        submit: true,
        to: WizardTaskContractRenewalStep.PendingSuccess,
      },
      secondary: {
        label: "Return to task details",
      },
      back: {
        to: WizardTaskContractRenewalStep.Status,
      },
    },
  },
  {
    id: WizardTaskContractRenewalStep.PendingSuccess,
    icon: "pending",
    title: "Your task due date has been updated.",
    body: (
      <div className="text-base [text-wrap:pretty]">
        Good luck renegotiating your contract with{" "}
        {contract.manager_account_vendor.vendor.name}.
        <div className="mt-4">You got this! 🙌</div>
      </div>
    ),
    ctas: {
      primary: {
        label: "Return to Tasks",
        toLink: `/intelligence/${contract.manager_account_vendor.manager_account_id}/tasks`,
      },
    },
  },
  {
    id: WizardTaskContractRenewalStep.CanceledConfirmation,
    icon: "warningRed",
    title: "Roger that.",
    subtitle: "Let's cancel this contract and move it to the archive.",
    body: (
      <div className="text-base [text-wrap:pretty]">
        Click “Cancel & Archive” to set {contract.name}’s status to canceled and
        move it to the archived tab. You can always access it again later.
      </div>
    ),
    ctas: {
      primary: {
        label: "Cancel & Archive",
        submit: true,
        to: WizardTaskContractRenewalStep.CanceledSuccess,
      },
      secondary: {
        label: "Return to task details",
      },
      back: {
        to: WizardTaskContractRenewalStep.Status,
      },
    },
  },
  {
    id: WizardTaskContractRenewalStep.CanceledSuccess,
    icon: "success",
    title: "All set! Your contract has been updated.",
    subtitle: "This task is now complete.",
    body: (
      <div className="text-base [text-wrap:pretty]">
        {contract.name} has been set to canceled and moved to the archive, and
        this task has been marked as complete.
      </div>
    ),
    ctas: {
      primary: {
        label: "Return to Tasks",
        toLink: `/intelligence/${contract.manager_account_vendor.manager_account_id}/tasks`,
      },
    },
  },
];

function PartyIcon({ className }: { className?: string }) {
  return (
    <div className={className}>
      <svg viewBox="0 0 56 59" fill="none" xmlns="http://www.w3.org/2000/svg">
        <path
          fillRule="evenodd"
          clipRule="evenodd"
          d="M17.4872 15.5132L17.7722 15.7622L43.2302 41.2172C43.5639 41.5505 43.8142 41.9578 43.961 42.406C44.1078 42.8543 44.1468 43.3308 44.0749 43.7969C44.003 44.263 43.8222 44.7056 43.5472 45.0888C43.2723 45.472 42.9108 45.7849 42.4922 46.0022L42.1442 46.1522L10.9892 57.6332C5.1332 59.7932 -0.569801 54.2882 1.2092 48.4412L1.3592 48.0032L12.8372 16.8482C12.9889 16.4355 13.2296 16.0612 13.542 15.7518C13.8544 15.4424 14.2311 15.2055 14.6452 15.0578C15.0594 14.9101 15.501 14.8553 15.9387 14.8971C16.3764 14.939 16.7996 15.0766 17.1782 15.3002L17.4872 15.5132ZM16.8452 23.3192L6.9902 50.0792C6.89858 50.3282 6.87462 50.597 6.92078 50.8582C6.96694 51.1195 7.08156 51.3638 7.25295 51.5663C7.42435 51.7688 7.64638 51.9222 7.89641 52.0109C8.14643 52.0996 8.41551 52.1204 8.6762 52.0712L8.9162 52.0022L35.6702 42.1442L16.8452 23.3192ZM44.5802 28.5452C47.3132 28.6892 51.0602 29.2652 54.3182 31.2212C54.9787 31.6128 55.4639 32.2427 55.6739 32.9812C55.8839 33.7198 55.8027 34.5108 55.4471 35.1913C55.0915 35.8718 54.4884 36.39 53.7622 36.6393C53.036 36.8886 52.2418 36.8499 51.5432 36.5312L51.2312 36.3662C49.1852 35.1362 46.5692 34.6562 44.2652 34.5362C43.3159 34.4813 42.364 34.4853 41.4152 34.5482L40.4672 34.6412C39.6846 34.7422 38.8937 34.5308 38.2659 34.0528C37.6381 33.5748 37.2239 32.8687 37.113 32.0874C37.0021 31.3062 37.2035 30.5127 37.6736 29.8789C38.1436 29.245 38.8444 28.8219 39.6242 28.7012C41.2672 28.489 42.9269 28.4357 44.5802 28.5422M50.6552 20.1842C51.4196 20.1858 52.1545 20.4791 52.71 21.0043C53.2654 21.5294 53.5994 22.2468 53.6438 23.0099C53.6883 23.773 53.4397 24.5242 52.949 25.1103C52.4582 25.6963 51.7622 26.0729 51.0032 26.1632L50.6552 26.1842H48.5312C47.7668 26.1826 47.0319 25.8893 46.4764 25.3641C45.921 24.839 45.587 24.1216 45.5426 23.3585C45.4981 22.5954 45.7467 21.8442 46.2374 21.2581C46.7282 20.6721 47.4242 20.2955 48.1832 20.2052L48.5312 20.1842H50.6552ZM41.1092 17.8832C41.6257 18.3998 41.936 19.0871 41.9819 19.8162C42.0277 20.5452 41.806 21.266 41.3582 21.8432L41.1092 22.1252L37.9292 25.3082C37.3906 25.852 36.6645 26.1693 35.8996 26.1952C35.1346 26.2212 34.3887 25.9538 33.8145 25.4478C33.2402 24.9418 32.8811 24.2354 32.8106 23.4733C32.7401 22.7112 32.9635 21.951 33.4352 21.3482L33.6842 21.0662L36.8642 17.8862C37.1428 17.6073 37.4737 17.386 37.8379 17.235C38.2021 17.084 38.5925 17.0063 38.9867 17.0063C39.3809 17.0063 39.7713 17.084 40.1355 17.235C40.4997 17.386 40.8306 17.6043 41.1092 17.8832ZM33.3482 2.0882C34.6922 6.1262 33.9722 10.5482 33.1322 13.6382C32.6274 15.5646 31.934 17.4367 31.0622 19.2272C30.7069 19.9393 30.0834 20.4811 29.3286 20.7335C28.5739 20.9858 27.7498 20.928 27.0377 20.5727C26.3256 20.2174 25.7838 19.5939 25.5314 18.8391C25.2791 18.0844 25.3369 17.2603 25.6922 16.5482C26.3879 15.1099 26.9405 13.6066 27.3422 12.0602C28.0232 9.5642 28.3652 6.8552 27.8402 4.6352L27.6572 3.9872C27.5265 3.61202 27.4715 3.2146 27.4956 2.81802C27.5197 2.42144 27.6224 2.0336 27.7976 1.67701C27.9728 1.32042 28.2171 1.00219 28.5163 0.740785C28.8155 0.479379 29.1637 0.28001 29.5405 0.15425C29.9174 0.0284908 30.3155 -0.0211539 30.7118 0.0081981C31.108 0.0375501 31.4944 0.145314 31.8487 0.325235C32.2029 0.505155 32.5179 0.753648 32.7753 1.05629C33.0327 1.35893 33.2274 1.70969 33.3482 2.0882ZM49.5932 9.4022C50.1556 9.96478 50.4716 10.7277 50.4716 11.5232C50.4716 12.3187 50.1556 13.0816 49.5932 13.6442L47.4722 15.7652C47.1955 16.0517 46.8644 16.2803 46.4984 16.4375C46.1324 16.5947 45.7387 16.6775 45.3404 16.681C44.9421 16.6844 44.547 16.6085 44.1783 16.4577C43.8096 16.3068 43.4747 16.0841 43.193 15.8024C42.9113 15.5207 42.6886 15.1858 42.5377 14.8171C42.3869 14.4484 42.311 14.0533 42.3144 13.655C42.3179 13.2567 42.4007 12.863 42.5579 12.497C42.7151 12.131 42.9437 11.7999 43.2302 11.5232L45.3512 9.4022C45.9138 8.83979 46.6767 8.52384 47.4722 8.52384C48.2677 8.52384 49.0306 8.83979 49.5932 9.4022Z"
          fill="#54CD2A"
        />
      </svg>
    </div>
  );
}
