import { Transition } from "@headlessui/react";
import { PaperAirplaneIcon, XMarkIcon } from "@heroicons/react/20/solid";
import { Fragment, useCallback, useEffect, useState, useRef } from "react";
import { Editor } from "../../reactquill/richtext-editor.component";
import { CTA } from "../../cta.component";
import { Button } from "../../button.component";
import { AtSymbolIcon, PaperClipIcon } from "@heroicons/react/24/outline";
import { Modal } from "../../modal.component";
import FileUploadZone from "../../file-upload-zone.component";
import { type Message } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { ChatMessages } from "./chat-messages.component";
import { encodeFilename } from "~/utils/file.utils";
import { tv } from "tailwind-variants";

const MB = 1024 * 1024;
const MAX_BYTE_LIMIT = 60 * MB;

const AlwaysScrollToBottom = () => {
  const chatRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (chatRef.current) chatRef.current.scrollIntoView();
  }, []);
  return <div ref={chatRef} />;
};

const tvChatContainer = tv({
  slots: {
    container:
      "w-full float-right mt-20 h-full max-h-full bg-white overflow-hidden",
    header:
      "flex items-center justify-between border-b border-gray-200 p-4 h-[60px]",
    body: "px-2 py-4 w-full overflow-x-hidden overflow-y-auto h-full",
    footer:
      "w-full h-[250px] bottom-0 p-4 py-6 border-t border-gray-200 bg-white",
  },
  variants: {
    allowSend: {
      true: {
        body: "h-[calc(100%-390px)]",
      },
      false: {
        body: "h-[calc(100%-140px)]",
      },
    },
  },
});

export function ChatBubble({
  isOpen,
  users,
  onClose,
  sendMessage,
  actionUrl,
  messages,
  fetcher,
  senderId,
  allowSend,
}: {
  isOpen: boolean;
  users: { id: string; value: string }[];
  onClose: (closed: boolean) => void;
  sendMessage: (formData: FormData) => void;
  actionUrl: string;
  messages: SerializeFrom<Message>[];
  fetcher: any;
  senderId: string;
  allowSend?: boolean;
}) {
  const [open, setOpen] = useState(isOpen);
  const [messageContent, setMessageContent] = useState("");
  const [modalMessageContent, setModalMessageContent] = useState("");
  const [uploadFilesModal, setUploadFilesModal] = useState(false);

  const [files, setFiles] = useState<File[] | undefined>(undefined);
  const [prevMessagesLength, setPrevMessagesLength] = useState(
    messages?.length ?? 0
  );
  const chatRef = useRef<HTMLDivElement>(null);

  const reactQuillRef = useRef<any | null>(null);

  const handleEditorChange = (content: { html: string }) => {
    const { html } = content;
    setMessageContent(html);
  };

  const handleModalEditorChange = (content: { html: string }) => {
    const { html } = content;
    setModalMessageContent(html);
  };

  const close = useCallback(() => {
    setOpen(false);
    onClose(false);
  }, [onClose]);

  const handleSubmit = () => {
    const formData = new FormData();
    formData.append("content", messageContent);
    sendMessage(formData);
    setMessageContent("");
  };

  const handleSubmitWithImages = () => {
    const formData = new FormData();
    formData.append("content", modalMessageContent);

    files &&
      files.forEach((file, index) => {
        formData.append(`message_files.id`, `image${index}`);
        formData.append(`message_files.name`, file.name ?? "");
        formData.append(`message_files.file`, file, encodeFilename(file.name));
      });
    sendMessage(formData);
    setMessageContent("");
  };

  const source = useCallback(
    (
      searchTerm: string,
      renderItem: (
        arg0: { id: string; value: string }[] | undefined,
        arg1: any
      ) => void,
      mentionChar: string
    ) => {
      let values;

      if (mentionChar === "@") {
        values = users;
      }
      if (searchTerm.length === 0) {
        renderItem(values, searchTerm);
      } else if (values) {
        const matches = [];
        for (let i = 0; i < values.length; i += 1) {
          if (
            values[i].value.toLowerCase().includes(searchTerm.toLowerCase())
          ) {
            matches.push(values[i]);
          }
        }
        renderItem(matches, searchTerm);
      }
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    []
  );

  const setEditorRef = useCallback((ref: any) => {
    reactQuillRef.current = ref;
  }, []);

  useEffect(() => {
    if (fetcher.data?.success) {
      setUploadFilesModal(false);
    }
  }, [fetcher.data]);

  useEffect(() => {
    setOpen(isOpen);
  }, [isOpen]);

  useEffect(() => {
    if (messages.length > prevMessagesLength) {
      setPrevMessagesLength(messages.length);
    }
  }, [messages, prevMessagesLength]);

  useEffect(() => {
    if (chatRef.current && messages.length > prevMessagesLength) {
      chatRef.current.scrollIntoView({
        behavior: "smooth",
        block: "end",
      });
    }
  }, [messages, prevMessagesLength]);

  return (
    <>
      {uploadFilesModal && (
        <Modal
          isOpen={uploadFilesModal}
          onClose={() => {
            setUploadFilesModal(false);
            fetcher.load(actionUrl);
          }}
          size="medium"
          manager={true}
        >
          <div className="flex flex-col h-full space-y-4">
            <h1 className="text-2xl">Upload your files</h1>
            <FileUploadZone
              onFileChange={setFiles}
              multiple={true}
              errors={[]}
              maxFileSize={MAX_BYTE_LIMIT}
              showPreviews={true}
              name="message_files"
            />
            <div className="block text-base font-medium leading-6 text-gray-900">
              Your message
            </div>
            <div className="pb-6">
              <Editor
                className="h-24"
                placeholder="Message latest updates on this task"
                toolBarOptions={{
                  toolbar: [
                    ["bold", "italic", "underline"],
                    [{ list: "ordered" }, { list: "bullet" }],
                    [{ indent: "-1" }, { indent: "+1" }],
                    ["emoji"],
                    ["clean"],
                    ["link"],
                  ],
                  "emoji-toolbar": true,
                  "emoji-textarea": false,
                  "emoji-shortname": true,
                  mention: {
                    allowedChars: /^[A-Za-z\s]*$/,
                    mentionDenotationChars: ["@"],
                    source: source,
                  },
                }}
                value={modalMessageContent}
                onChange={handleModalEditorChange}
                forwardedRef={setEditorRef}
              />
            </div>
            <div className="flex justify-end mt-6">
              <CTA
                type="button"
                onClick={handleSubmitWithImages}
                variant="coral"
                className={`mt-2 flex gap-x-2 items-center ${
                  fetcher.state === "submitting" ? "animate-bounce" : ""
                }`}
              >
                <>{fetcher.state === "submitting" ? "Sending..." : "Send"}</>
                <PaperAirplaneIcon className="h-5" />
              </CTA>
            </div>
          </div>
        </Modal>
      )}
      <Transition.Root show={open} as={Fragment}>
        <div className="w-full">
          <div className="z-30 fixed right-0 top-0 bottom-0 w-full lg:w-1/3 lg:pl-8 2xl:pl-12 h-screen">
            <Transition.Child
              as={Fragment}
              enter="transform transition ease-in-out duration-300"
              enterFrom="translate-x-full"
              enterTo="translate-x-0"
              leave="transform transition ease-in-out duration-300"
              leaveFrom="translate-x-0"
              leaveTo="translate-x-full"
            >
              <div className={tvChatContainer().container()}>
                <div className={tvChatContainer().header()}>
                  <div className="font-semibold">Group Chat</div>
                  <button
                    type="button"
                    className="rounded-md bg-white text-gray-400 hover:text-gray-500 focus:outline-none "
                    onClick={close}
                  >
                    <span className="sr-only">Close</span>
                    <XMarkIcon className="h-6 w-6" aria-hidden="true" />
                  </button>
                </div>
                <div
                  className={tvChatContainer().body({ allowSend })}
                >
                  {messages && (
                    <ChatMessages
                      actionUrl={actionUrl}
                      messages={messages}
                      senderId={senderId}
                      allowReactions={allowSend}
                    ></ChatMessages>
                  )}
                  <AlwaysScrollToBottom />
                  <div ref={chatRef}></div>
                </div>
                {allowSend && (
                  <div className={tvChatContainer().footer()}>
                    <div className="pb-12">
                      <Editor
                        className="h-24"
                        placeholder="Message latest updates on this task"
                        toolBarOptions={{
                          toolbar: [
                            ["bold", "italic", "underline"],
                            [{ list: "ordered" }, { list: "bullet" }],
                            [{ indent: "-1" }, { indent: "+1" }],
                            ["emoji"],
                            ["clean"],
                            ["link"],
                          ],
                          "emoji-toolbar": true,
                          "emoji-textarea": false,
                          "emoji-shortname": true,
                          clipboard: {
                            matchVisual: false,
                          },
                          mention: {
                            allowedChars: /^[A-Za-z\s]*$/,
                            mentionDenotationChars: ["@"],
                            source: source,
                          },
                        }}
                        value={messageContent}
                        onChange={handleEditorChange}
                        forwardedRef={setEditorRef}
                      />
                    </div>
                    <div className="flex justify-between">
                      <div className="flex items-center space-x-2">
                        <Button
                          type="button"
                          onClick={() => {
                            const editor = reactQuillRef.current?.getEditor();
                            if (editor) {
                              editor.focus();
                              const selection = editor.getSelection();
                              editor.insertText(selection.index, "@");
                              editor.blur();
                              editor.focus();
                            }
                          }}
                          color="transparent"
                          className="px-0 text-gray-400 transition ease-in-out duration-300"
                        >
                          <AtSymbolIcon className="h-5" />
                        </Button>
                        <Button
                          type="button"
                          onClick={() => {
                            setUploadFilesModal(true);
                          }}
                          color="transparent"
                          className="px-0 text-gray-400 transition ease-in-out duration-300"
                        >
                          <PaperClipIcon className="h-5" />
                        </Button>
                      </div>
                      <CTA
                        type="button"
                        onClick={handleSubmit}
                        variant="coral"
                        className="mt-2 flex gap-x-2 items-center"
                      >
                        Send <PaperAirplaneIcon className="h-5" />
                      </CTA>
                    </div>
                  </div>
                )}
              </div>
            </Transition.Child>
          </div>
        </div>
      </Transition.Root>
    </>
  );
}
