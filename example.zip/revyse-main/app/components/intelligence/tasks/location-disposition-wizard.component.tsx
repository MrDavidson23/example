import { BuildingOffice2Icon, ClockIcon } from "@heroicons/react/24/outline";
import type { Location, TaskLocationDisposition } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { useFetcher } from "@remix-run/react";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import { useMemo, useState } from "react";
import {
  CrudDateField,
  CrudRadioButtonField,
} from "~/components/form/crud-form.component";
import { GridSelect } from "~/components/form/grid-select.component";
import { AgreeIcon } from "~/components/icons/agree-icon";
import type { WizardStep } from "~/components/modals/wizard-modal.component";
import { WizardModal } from "~/components/modals/wizard-modal.component";
import {
  WizardTaskLocationDispositionStatus,
  type action,
} from "~/routes/_api.intelligence.wizard-task-location-disposition.$intent";
dayjs.extend(utc);

export enum WizardTaskLocationDispositionRenewalStep {
  Status = "status",
  DisposedConfirmation = "disposed-confirmation",
  DisposedSuccess = "disposed-success",
  PendingDueDate = "pending-due-date",
  PendingSuccess = "pending-success",
  KeepConfirmation = "canceled-confirmation",
  KeepSuccess = "canceled-success",
}

export function LocationDispositionWizard({
  isOpen,
  onClose,
  task,
}: {
  isOpen: boolean;
  onClose: () => void;
  task: SerializeFrom<
    TaskLocationDisposition & {
      location: Location;
    }
  >;
}) {
  // This is the state that will be used to store the form values as the user progresses through the wizard.
  const [formValues, setFormValues] = useState<
    Record<string, FormDataEntryValue>
  >({});

  const fetcher = useFetcher<typeof action>();

  const errors = useMemo(
    () => (fetcher.data && "errors" in fetcher.data ? fetcher.data.errors : {}),
    [fetcher.data]
  );

  const steps: WizardStep[] = useMemo(
    () => generateWizardSteps(task, task.location, formValues, errors),
    [task, formValues, errors]
  );

  return (
    <WizardModal
      isOpen={isOpen}
      onClose={onClose}
      steps={steps}
      size="medium"
      initialStepId="status-selector"
      onFormValuesChange={setFormValues}
      submitUrl="/intelligence/wizard-task-location-disposition"
      extraFormDataOnSubmit={{
        task_id: task.id,
        manager_account_id: task.location.manager_account_id,
      }}
      fetcher={fetcher}
    />
  );
}

const generateWizardSteps = (
  task: SerializeFrom<TaskLocationDisposition>,
  location: SerializeFrom<Location>,
  formValues: Record<string, FormDataEntryValue>,
  actionErrors: Record<string, string[] | null>
): WizardStep[] => [
  {
    id: WizardTaskLocationDispositionRenewalStep.Status,
    title: "Alright, let’s update your location status.",
    subtitle: `What is the new status of ${location.name}?`,
    body: (
      <>
        <div>
          If the location has officially transitioned, select “It has been
          disposed.” If it is still pending, select “It is still pending.” If
          the transition was canceled, select “We are keeping it.”
        </div>
        <div className="h-36 mt-8">
          <GridSelect
            name="status"
            options={[
              {
                label: "It has been disposed",
                value: WizardTaskLocationDispositionStatus.Disposed,
                icon: (
                  <AgreeIcon className="text-green-500 h-[60px] w-[60px] flex item-center" />
                ),
              },
              {
                label: "It is still pending",
                value: WizardTaskLocationDispositionStatus.Pending,
                icon: (
                  <ClockIcon className="text-yellow-400 h-[60px] w-[60px]" />
                ),
              },
              {
                label: "We are keeping it",
                value: WizardTaskLocationDispositionStatus.Keep,
                icon: (
                  <BuildingOffice2Icon className="text-sky-600 h-[60px] w-[60px]" />
                ),
              },
            ]}
          />
        </div>
      </>
    ),
    ctas: {
      primary: {
        label: "Continue",
        onClick: values => {
          const statusStep = {
            [WizardTaskLocationDispositionStatus.Disposed]:
              WizardTaskLocationDispositionRenewalStep.DisposedConfirmation,
            [WizardTaskLocationDispositionStatus.Pending]:
              WizardTaskLocationDispositionRenewalStep.PendingDueDate,
            [WizardTaskLocationDispositionStatus.Keep]:
              WizardTaskLocationDispositionRenewalStep.KeepConfirmation,
          };
          const to = statusStep[values.status as keyof typeof statusStep];
          return { to };
        },
        resetFormValues: true,
      },
      secondary: {
        label: "Return to task details",
      },
    },
  },
  {
    id: WizardTaskLocationDispositionRenewalStep.DisposedConfirmation,
    icon: "warningRed",
    title: "Roger that.",
    subtitle: `Let's set ${location.name}'s status to disposed.`,
    body: (
      <div className="text-base [text-wrap:pretty]">
        Click “Set Status to Disposed” to set {location.name}'s status to
        disposed and move it to the archived tab. You can always access it again
        later.
      </div>
    ),
    ctas: {
      primary: {
        label: "Set Status to Disposed",
        submit: true,
        to: WizardTaskLocationDispositionRenewalStep.DisposedSuccess,
      },
      secondary: {
        label: "Return to task details",
      },
      back: {
        to: WizardTaskLocationDispositionRenewalStep.Status,
      },
    },
  },
  {
    id: WizardTaskLocationDispositionRenewalStep.DisposedSuccess,
    icon: "success",
    title: "All set! Your location has been updated.",
    subtitle: `This task is now complete.`,
    body: (
      <>
        {location.name} has been set to disposed and moved to the archive, and
        this task has been marked as complete. Line items have been marked as
        canceled, keeping your contract assignments up-to-date. Nice work!
      </>
    ),
    ctas: {
      primary: {
        label: "Return to Tasks",
        toLink: `/intelligence/${location.manager_account_id}/tasks`,
      },
    },
  },
  {
    id: WizardTaskLocationDispositionRenewalStep.PendingDueDate,
    title: "Disposition is still pending.",
    subtitle: `Let’s review and update the due date for this task.`,
    body: (
      <>
        While you’re waiting for {location.name} to fully transition out of your
        portfolio, you can push the due date for this task to a later date.
        <CrudDateField
          className="mt-4"
          field={{
            name: "due_date",
            type: "text",
            errors: actionErrors.due_date ?? [],
            label: "Select a new task due date",
            defaultValue:
              (formValues.due_date as string | undefined) ??
              task.due_date ??
              undefined,
          }}
          minDate={new Date().toISOString().split("T")[0]}
        />
      </>
    ),
    ctas: {
      primary: {
        label: "Submit",
        submit: true,
        to: WizardTaskLocationDispositionRenewalStep.PendingSuccess,
      },
      secondary: {
        label: "Return to task details",
      },
      back: {
        to: WizardTaskLocationDispositionRenewalStep.Status,
      },
    },
  },
  {
    id: WizardTaskLocationDispositionRenewalStep.PendingSuccess,
    icon: "pending",
    title: "Your task due date has been updated.",
    body: (
      <div className="text-base [text-wrap:pretty]">
        This reminder task will remain in your Active Tasks queue, and you can
        come back to it at any time.
        <div className="mt-4">Nice work! 🙌</div>
      </div>
    ),
    ctas: {
      primary: {
        label: "Return to Tasks",
        toLink: `/intelligence/${location.manager_account_id}/tasks`,
      },
    },
  },
  {
    id: WizardTaskLocationDispositionRenewalStep.KeepConfirmation,
    title: "Great news! You’re keeping this location.",
    subtitle: "Let's cancel this contract and move it to the archive.",
    body: (
      <div className="text-base [text-wrap:pretty]">
        Did any of {location.name}’s contracted products or services change
        during the process?
        <div className="flex space-x-3 mt-3">
          <CrudRadioButtonField
            field={{
              label: "Yes",
              value: "true",
              name: "has_changed",
              type: "radio",
              defaultChecked: formValues.has_changed
                ? formValues.has_changed === "true"
                : true,
              errors: [],
              description: "",
            }}
          />
          <CrudRadioButtonField
            field={{
              label: "No",
              value: "false",
              name: "has_changed",
              type: "radio",
              errors: [],
              defaultChecked: formValues.has_changed === "false",
              description: "",
            }}
          />
        </div>
      </div>
    ),
    ctas: {
      primary: {
        label: "Submit",
        submit: true,
        to: WizardTaskLocationDispositionRenewalStep.KeepSuccess,
      },
      secondary: {
        label: "Return to task details",
      },
      back: {
        to: WizardTaskLocationDispositionRenewalStep.Status,
      },
    },
  },
  {
    id: WizardTaskLocationDispositionRenewalStep.KeepSuccess,
    icon: "success",
    title: "All set! This task is now complete.",
    subtitle: "This task has been moved to the archived queue.",
    body:
      formValues.has_changed === "true" ? (
        <div className="text-base [text-wrap:pretty]">
          Click on “Update Products to make changes to the assigned contracts
          and line items for {location.name}.
        </div>
      ) : undefined,
    ctas: {
      primary:
        formValues.has_changed === "true"
          ? {
              label: "Update Products",
              toLink: `/intelligence/${location.manager_account_id}/locations/${location.id}/assigned-vendors`,
            }
          : {
              label: "Return to Tasks",
              toLink: `/intelligence/${location.manager_account_id}/tasks`,
            },
      secondary:
        formValues.has_changed === "true"
          ? {
              label: "Return to Tasks",
              toLink: `/intelligence/${location.manager_account_id}/tasks`,
            }
          : undefined,
    },
  },
];
