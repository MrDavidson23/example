import {
  ArrowTopRightOnSquareIcon,
  DocumentIcon,
} from "@heroicons/react/24/outline";
import { VideoPlayer } from "~/components/video-player.component";

export function ChatFile({
  id,
  type,
  title,
}: {
  id: string;
  type: string;
  title: string;
}) {
  return (
    <div className="w-11/12 lg:w-full rounded-lg relative group overflow-clip">
      {type.startsWith("image/") ? (
        <img
          src={`/images/${id}`}
          alt={title}
          className="h-full w-full object-cover"
        />
      ) : type === "application/pdf" ? (
        <embed
          src={`/images/${id}`}
          type="application/pdf"
          width="100%"
          height="100%"
        />
      ) : type.startsWith("audio/") ? (
        <audio src={`/images/${id}`} controls />
      ) : type.startsWith("video/") ? (
        <VideoPlayer fileId={id} />
      ) : (
        <div className="flex justify-center items-center  border border-gray-200">
          <DocumentIcon className="h-20 w-12 text-sky-600" aria-hidden="true" />{" "}
        </div>
      )}
      {!type.startsWith("video/") ? (
        <a
          href={`/images/${id}`}
          target="_blank"
          rel="noopener noreferrer"
          className="absolute top-0 left-0 w-full h-full bg-primary-900 bg-opacity-70 flex items-center justify-center opacity-0 transition-opacity duration-200 cursor-pointer group-hover:opacity-100"
        >
          <div className="flex flex-col text-white w-11/12 text-center">
            <ArrowTopRightOnSquareIcon className="h-8"></ArrowTopRightOnSquareIcon>
          </div>
        </a>
      ) : null}
    </div>
  );
}
