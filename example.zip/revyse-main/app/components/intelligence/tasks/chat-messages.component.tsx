import { EmojiType, type Message } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import type { action } from "../../../routes/intelligence.$id.tasks_.contract-renewal_.$task_id";
import { useFetcher } from "@remix-run/react";
import { useState } from "react";
import { Avatar } from "~/components/avatar.component";
import HTMLReactParser from "html-react-parser";
import { ChatFile } from "./chat-file.component";
import { EmojiTypeValues } from "~/utils/constants.utils";

export function ChatMessages({
  actionUrl,
  messages,
  senderId,
  allowReactions,
}: {
  actionUrl: string;
  messages: SerializeFrom<Message>[];
  senderId: string;
  allowReactions?: boolean;
}) {
  const reactionFetcher = useFetcher<typeof action>();

  const [hoveredMessageId, setHoveredMessageId] = useState<string | null>(null);
  const [hoveredReactionId, setHoveredReactionId] = useState<string | null>(
    null
  );

  const handleMouseEnterMessage = (messageId: string) => {
    setHoveredMessageId(messageId);
  };

  const handleMouseLeaveMessage = () => {
    setHoveredMessageId(null);
  };

  const handleMouseEnterReaction = (reactionId: string) => {
    setHoveredReactionId(reactionId);
  };

  const handleMouseLeaveReaction = () => {
    setHoveredReactionId(null);
  };

  const handleReaction = (messageId: string, emoji: string) => {
    reactionFetcher.submit(
      {
        intent: "reactMessage",
        message_id: messageId,
        type: emoji,
      },
      {
        action: actionUrl,
        method: "post",
        encType: "multipart/form-data",
      }
    );
  };

  return messages.map((message: any, index: any) => {
    const isSameDay =
      index > 0 &&
      new Date(message.created_at).toDateString() ===
        new Date(messages[index - 1].created_at).toDateString();
    const messageDate = new Date(message.created_at);
    const formattedMessageDate =
      isSameDay && index > 0
        ? ""
        : messageDate.toDateString() === new Date().toDateString()
        ? "Today"
        : messageDate.toDateString() ===
          new Date(Date.now() - 86400000).toDateString()
        ? "Yesterday"
        : messageDate.toLocaleDateString(undefined, {
            weekday: "long",
            year: "numeric",
            month: "long",
            day: "numeric",
          });

    return (
      <div key={index} className="space-y-2">
        {!isSameDay && (
          <div className="text-center my-2 text-sm font-light">
            {formattedMessageDate}
          </div>
        )}
        <div className="flex items-start space-x-2 my-3">
          <div className="flex justify-center w-14">
            {message.sender.user.avatar_url ? (
              <img
                src={message.sender.user.avatar_url}
                alt={`${message.sender.user.first_name} ${message.sender.user.last_name}`}
                className="w-8 h-8 rounded-full"
                width="32"
                height="32"
              />
            ) : (
              <Avatar
                first_name={message.sender.user.first_name!}
                last_name={message.sender.user.last_name!}
                className="w-8 h-8 text-sm"
              />
            )}
          </div>

          <div className="flex flex-col space-y-2">
            <span className="font-medium text-gray-600 text-sm">
              {`${message.sender.user.first_name} ${message.sender.user.last_name}`}
            </span>
            <div
              className="relative message-bubble bg-gray-100 rounded-lg p-2 text-sm 2xl:text-base"
              onMouseEnter={() => handleMouseEnterMessage(message.id)}
              onMouseLeave={handleMouseLeaveMessage}
            >
              <div className="whitespace-pre-wrap">
                {HTMLReactParser(message.content)}
                <div className="grid grid-cols-3 gap-x-2">
                  {message.message_files &&
                    message.message_files.map((file: any) => (
                      <div key={file.id}>
                        <ChatFile
                          id={file.file.id}
                          type={file.file.mime_type}
                          title={file.file.title}
                        />
                      </div>
                    ))}
                </div>
              </div>
              {allowReactions && hoveredMessageId === message.id && (
                <div className="absolute top-0 right-0 -mt-8 flex items-center space-x-2 bg-white border border-gray-200 p-1 rounded-lg">
                  {Object.entries(EmojiTypeValues).map(([key, value]) => {
                    return (
                      <button
                        key={key}
                        onClick={() => handleReaction(message.id, key)}
                        aria-label="Thumbs Up"
                        className="reaction-button"
                      >
                        {value}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
            {message.reactions && message.reactions.length > 0 && (
              <div className="flex justify-start items-center space-x-2 h-8">
                {Object.values(EmojiType).map(
                  (emoji: string, index: number) => {
                    const reactionsOfType = message.reactions.filter(
                      (reaction: any) => reaction.type === emoji
                    );
                    if (reactionsOfType.length > 1) {
                      const senderNames = reactionsOfType
                        .map((reaction: any) =>
                          reaction.sender_id === senderId
                            ? "You"
                            : `${reaction.sender.user.first_name} ${reaction.sender.user.last_name}`
                        )
                        .join(", ");
                      return (
                        <div
                          key={index}
                          className="h-8 w-8 flex justify-center items-center relative border-0 hover:border hover:border-gray-300 hover:cursor-pointer hover:bg-gray-100 py-1 px-2 rounded-full bg-gray-50"
                          onMouseEnter={() =>
                            handleMouseEnterReaction(reactionsOfType[0].id)
                          }
                          onMouseLeave={handleMouseLeaveReaction}
                          onClick={() => handleReaction(message.id, emoji)}
                        >
                          {hoveredReactionId === reactionsOfType[0].id && (
                            <div className="w-max absolute top-0 left-0 -mt-8 -ml-8 z-50 flex items-center bg-white border border-gray-200 p-1 rounded-lg">
                              <div className="text-xs text-center">
                                <b>{senderNames}</b> reacted with{" "}
                                {EmojiTypeValues[emoji as EmojiType]}
                              </div>
                            </div>
                          )}
                          <span key={index} role="img" aria-label="Reaction">
                            {EmojiTypeValues[emoji as EmojiType]}
                          </span>
                        </div>
                      );
                    } else {
                      return reactionsOfType.map(
                        (reaction: any, index: any) => (
                          <div
                            key={index}
                            className="h-8 w-8 flex justify-center items-center relative border-0 hover:border hover:border-gray-300 hover:cursor-pointer hover:bg-gray-100 py-1 px-2 rounded-full bg-gray-50"
                            onMouseEnter={() =>
                              handleMouseEnterReaction(reaction.id)
                            }
                            onMouseLeave={handleMouseLeaveReaction}
                            onClick={() =>
                              handleReaction(reaction.message_id, reaction.type)
                            }
                          >
                            {hoveredReactionId === reaction.id && (
                              <div className="w-max absolute top-0 left-0 -mt-8 -ml-8 z-50 flex items-center bg-white border border-gray-200 p-1 rounded-lg">
                                <div className="text-xs text-center">
                                  <b>
                                    {reaction.sender_id === senderId
                                      ? "You"
                                      : `${reaction.sender.user.first_name} ${reaction.sender.user.last_name}`}
                                  </b>{" "}
                                  reacted with{" "}
                                  {EmojiTypeValues[reaction.type as EmojiType]}
                                </div>
                              </div>
                            )}
                            <span key={index} role="img" aria-label="Reaction">
                              {EmojiTypeValues[reaction.type as EmojiType]}
                            </span>
                          </div>
                        )
                      );
                    }
                  }
                )}
              </div>
            )}
            <span className="text-xs text-gray-400">
              {messageDate.toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </span>
          </div>
        </div>
      </div>
    );
  });
}
