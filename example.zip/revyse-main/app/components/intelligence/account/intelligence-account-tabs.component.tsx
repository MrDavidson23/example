import React from "react";
import PageTabs from "../page-tabs.component";
import { type PermissionType } from "~/utils/intelligence-permission.utils";

type IntelligenceAccountTabsProps = {
  options: {
    navigateTo: string;
    label: string;
    expectedResult: string;
    permissions: PermissionType[];
  }[];
};

export function IntelligenceAccountTabs({
  options,
}: IntelligenceAccountTabsProps) {
  return (
    options.length > 1 && ( // Render only when user can access more than 1 option
      <PageTabs
        validationType="exactMatch"
        options={options}
        columns={options.length}
      />
    )
  );
}
