import type { ProductCategory } from "@prisma/client";
import { Button } from "../button.component";
import { RevysePencilIcon } from "../revyse-pencil-icon.component";
interface FeeCardProps {
  fee: {
    id: string;
    name: string;
    vendor_name: string;
    category: ProductCategory;
    vendor_logo: string;
  };
  handleCallback?: (id: string) => void;
  handleEditModal?: (value: boolean) => void;
  handleFee?: (fee: { id: string; name: string; category_id: string }) => void;
  selectedFees?: string[];
  confirmEditOpen?: Boolean;
}
export function FeeCard({
  fee,
  handleCallback = id => {},
  handleEditModal = value => {},
  handleFee = id => {},
  selectedFees,
  confirmEditOpen,
}: FeeCardProps) {
  const isFeeSelected = selectedFees && selectedFees.includes(fee.id);

  const cardClassName = `max-w-sm bg-white shadow-lg shadow-gray-200/50 rounded-lg h-full cursor-pointer hover:scale-105 cursor-pointer transition ease-in-out duration-300 ${
    isFeeSelected
      ? "ring ring-sky-500 cursor-pointer hover:scale-105 cursor-pointer transition ease-in-out duration-300"
      : ""
  }`;

  return (
    <div
      className={cardClassName}
      onClick={() => {
        handleCallback(fee.id);
      }}
    >
      <img
        className="rounded-t-lg object-cover w-full h-48"
        src={
          fee.vendor_logo
            ? `/images/${fee?.vendor_logo}`
            : "/assets/default-logo.png"
        }
        alt=""
        width="192"
        height="192"
      />
      <div className="lg:space-y-5 lg:pb-4">
        <div className="p-5 space-y-2">
          <div>
            <h5 className="text-xl lg:text-2xl font-bold tracking-tight text-gray-900">
              {fee?.name}
            </h5>
            <div className="text-md lg:text-lg font-light tracking-tight text-gray-900">
              {fee?.vendor_name}
            </div>
          </div>
          <div className="gap-x-2 w-fit bg-transparent border-2 border-sky-500 rounded-full px-3 py-1.5 flex items-center text-sm">
            <div className="text-center w-full">{fee?.category?.name}</div>
          </div>
        </div>
        <div className="flex justify-end m-4">
          <Button
            onClick={e => {
              e.preventDefault();
              e.stopPropagation();
              handleFee({
                id: fee.id,
                name: fee.name,
                category_id: fee.category?.id,
              });
              handleEditModal(!confirmEditOpen);
            }}
            color="transparent"
          >
            <RevysePencilIcon className="h-5" />
          </Button>
        </div>
      </div>
    </div>
  );
}
