import { Menu, Transition } from "@headlessui/react";
import type { Location, ManagerAccount } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { tv } from "tailwind-variants";

const tvOptionsGroup = tv({
  slots: {
    container: "",
    header: "text-sm text-gray-400 px-2 pt-2 pb-1",
    optionsContainer: "flex flex-col divide-y divide-gray-100",
    option:
      "flex items-start gap-x-2 p-3 pl-5 hover:bg-gray-100 cursor-pointer transition-all ease-in-out duration-200",
  },
  variants: {
    active: {
      true: {
        option: "bg-sky-100/70",
      },
    },
  },
});

export function EntitiesSelector({
  children,
  account,
  locations,
  activeOptionId,
  setActiveOption,
}: {
  children: React.ReactNode;
  account: SerializeFrom<ManagerAccount>;
  locations: SerializeFrom<Location>[];
  activeOptionId: string;
  setActiveOption: (id: string, isLocation: boolean) => void;
}) {
  return (
    <div className="relative">
      <Menu>
        <Menu.Button>{children}</Menu.Button>
        <Transition
          enter="transition duration-100 ease-out"
          enterFrom="transform scale-95 opacity-0"
          enterTo="transform scale-100 opacity-100"
          leave="transition duration-75 ease-out"
          leaveFrom="transform scale-100 opacity-100"
          leaveTo="transform scale-95 opacity-0"
        >
          <Menu.Items className="absolute min-w-60 w-max max-h-[calc(100vh-25rem)] overflow-x-auto md:right-0 mt-2 divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black/5 focus:outline-none">
            <div className={tvOptionsGroup().container()}>
              <div className={tvOptionsGroup().header()}>Account</div>
              <div className={tvOptionsGroup().optionsContainer()}>
                <Menu.Item>
                  <div
                    className={tvOptionsGroup().option({
                      active: activeOptionId === account.id,
                    })}
                    onClick={() => setActiveOption(account.id, false)}
                  >
                    {account.name}
                  </div>
                </Menu.Item>
              </div>
            </div>
            <div className={tvOptionsGroup().container()}>
              <div className={tvOptionsGroup().header()}>Locations</div>
              <div className={tvOptionsGroup().optionsContainer()}>
                {locations.map(location => (
                  <Menu.Item key={location.id}>
                    <div
                      className={tvOptionsGroup().option({
                        active: activeOptionId === location.id,
                      })}
                      onClick={() => setActiveOption(location.id, true)}
                    >
                      {location.name}
                    </div>
                  </Menu.Item>
                ))}
              </div>
            </div>
          </Menu.Items>
        </Transition>
      </Menu>
    </div>
  );
}
