import { useRouteLoaderData } from "@remix-run/react";
import { useMemo } from "react";
import type {
  PermissionType,
  PermissionUser,
} from "~/utils/intelligence-permission.utils";
import { canDoOnAccount } from "~/utils/intelligence-permission.utils";
import { canDoOnLocation } from "~/utils/location-permission.utils";

export function CanDo({
  permission,
  children,
  locationId,
}: {
  permission: PermissionType;
  children: React.ReactNode;
  locationId?: string;
}) {
  const data = useRouteLoaderData<{
    managerAccount: {
      id: string;
      name: string;
      created_at: Date;
      updated_at: Date;
      avatar_id: string | null;
    };
    user: PermissionUser;
  }>(`routes/intelligence.$id`);

  const authorized = useMemo(() => {
    if (!data) return false;

    // If locationId is provided, check if the user has permission on the location
    if (locationId) {
      return canDoOnLocation(
        data.user,
        data.managerAccount,
        {
          id: locationId,
        },
        permission
      );
    }

    return canDoOnAccount(data.user, data.managerAccount, permission);
  }, [data, permission, locationId]);

  return <>{authorized ? children : null}</>;
}
