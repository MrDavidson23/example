import React from "react";
import type { CTAProps } from "../cta.component";
import { CTA } from "../cta.component";
import type { ButtonProps } from "../button.component";
import { Button } from "../button.component";
import { tv } from "tailwind-variants";

const tvBannerIcon = tv({
  base: "w-20 h-20 p-3 border-2 flex-shrink-0 flex items-center justify-center rounded-full",
  variants: {
    color: {
      amber: "bg-amber-100/70 border-amber-400 text-amber-400",
      green: "bg-green-100/70 border-green-400 text-green-400",
    },
  },
});

export function Banner({
  title,
  description,
  icon,
  color,
  actions: { primary, secondary } = {},
}: {
  title: string;
  description: string | React.ReactNode;
  icon: React.ReactNode;
  color: keyof typeof tvBannerIcon.variants.color;
  actions?: {
    primary?: CTAProps;
    secondary?: ButtonProps;
  };
}) {
  return (
    <div
      className={`bg-white shadow-lg shadow-gray-200/50 p-8 rounded-lg w-full h-min flex items-center gap-x-8`}
    >
      <div className={tvBannerIcon({ color })}>{icon}</div>
      <div className="flex flex-col gap-y-2 justify-start">
        <h2 className="text-lg font-semibold">{title}</h2>
        <h3 className="text-sm">{description}</h3>
        {secondary && (
          <Button
            {...secondary}
            className={`${secondary.className} px-0 font-medium justify-start`}
          />
        )}
      </div>
      {primary && (
        <div className="ml-auto">
          <CTA {...primary} />
        </div>
      )}
    </div>
  );
}
