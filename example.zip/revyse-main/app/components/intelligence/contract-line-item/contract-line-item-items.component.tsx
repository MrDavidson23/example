import { Bars2Icon, XMarkIcon } from "@heroicons/react/24/outline";
import { useMemo } from "react";

export type ContractLineItemItem = {
  item_name: string;
  quantity: number;
  price: number;
};

export function ContractLineItemItems({
  items,
}: {
  items: ContractLineItemItem[];
}) {
  const totalValue = useMemo(() => {
    return items.reduce(
      (acc, item) => acc + (item.price ?? 0) * (item.quantity ?? 0),
      0
    );
  }, [items]);

  return items.length === 0 ? (
    <div>
      $0 <em className="text-gray-500">(No items added)</em>
    </div>
  ) : (
    <div className="grid grid-cols-6 items-center my-3 md:gap-4 gap-2 min-w-max text-sm md:text-base">
      <div className="font-semibold col-span-2">Item name</div>
      <div className="font-semibold">Quantity</div>
      <div className="font-semibold">Cost</div>
      <div className="font-semibold col-span-2">Total</div>
      {items.map((item, j) => (
        <>
          <div className="md:text-md col-span-2 [text-wrap:pretty]">
            {item.item_name}
          </div>
          <div className="md:text-md flex justify-between items-center">
            {item.quantity}
            <XMarkIcon className="h-4 text-gray-600 ml-3" />
          </div>
          <div className="md:text-md flex justify-between items-center">
            {item.price.toLocaleString(undefined, {
              style: "currency",
              currency: "USD",
            })}
            <Bars2Icon className="h-4 text-gray-600 ml-3" />
          </div>
          <div className="md:text-md col-span-2">
            {(item.price * item.quantity).toLocaleString(undefined, {
              style: "currency",
              currency: "USD",
            })}
          </div>
        </>
      ))}
      <div className="col-span-4 flex justify-end">
        <Bars2Icon className="h-4 text-gray-600 ml-3" />
      </div>
      <div className="md:text-md col-span-2 font-semibold">
        {totalValue.toLocaleString(undefined, {
          style: "currency",
          currency: "USD",
        })}
      </div>
    </div>
  );
}
