import {
  Bars2Icon,
  PlusIcon,
  TrashIcon,
  XMarkIcon,
} from "@heroicons/react/24/outline";
import { isEmpty } from "lodash";
import { useEffect, useMemo, useState } from "react";
import { Button } from "~/components/button.component";
import { CurrencyField } from "~/components/form/currency-field.component";
import { tvField } from "~/utils/global-tailwind-variants.utils";
import { money } from "~/utils/number.utils";

export type ContractLineItemItem = {
  item_name: string;
  quantity: number;
  price: number;
};

export function ContractLineItemItemsManager({
  items,
  actionErrors,
  onPriceChange,
}: {
  items: ContractLineItemItem[];
  actionErrors: Record<string, string[] | null>;
  onPriceChange: (price: number) => void;
}) {
  const [lineItemItems, setLineItemItems] = useState<ContractLineItemItem[]>(
    !isEmpty(items)
      ? items
      : [
          {
            item_name: "",
            quantity: 0,
            price: 0,
          },
        ]
  );

  const totalValue = useMemo(() => {
    return lineItemItems.reduce(
      (acc, item) => acc + (item.price ?? 0) * (item.quantity ?? 0),
      0
    );
  }, [lineItemItems]);

  useEffect(() => {
    onPriceChange(totalValue);
  }, [onPriceChange, totalValue]);

  return (
    <>
      <input type="hidden" name="contract_line_item.price" value={totalValue} />
      <div className="grid grid-cols-[repeat(13,minmax(0,1fr))] items-center gap-x-3 mb-3 text-sm font-medium">
        <div className="col-span-3">Item Name</div>
        <div className="col-span-3">Quantity</div>
        <div className="col-span-3">Cost</div>
        <div className="col-span-3">Total</div>
      </div>
      <div className="grid grid-cols-[repeat(13,minmax(0,1fr))] items-center gap-x-3 mb-3 text-sm font-medium">
        {lineItemItems.map((item, i) => (
          <>
            <div className="col-span-3">
              <input
                className={tvField({
                  error:
                    !!actionErrors[`contract_line_item_items.${i}.item_name`]
                      ?.length,
                })}
                name={`contract_line_item.contract_line_item_items.item_name`}
                placeholder="Item Name"
                type="text"
                defaultValue={item.item_name ?? ""}
                onChange={e =>
                  setLineItemItems(prev =>
                    prev.map((prevItem, index) => {
                      if (index === i) {
                        return {
                          ...prevItem,
                          item_name: e.target.value,
                        };
                      }
                      return prevItem;
                    })
                  )
                }
              />
              <p className="mt-3 text-sm leading-6 text-red-600">
                {actionErrors[`contract_line_item_items.${i}.item_name`]?.join(
                  " "
                )}
              </p>
            </div>
            <div className="col-span-3 flex items-center">
              <div>
                <input
                  className={tvField({
                    error:
                      !!actionErrors[`contract_line_item_items.${i}.quantity`]
                        ?.length,
                  })}
                  name={`contract_line_item.contract_line_item_items.quantity`}
                  placeholder="#"
                  type="number"
                  defaultValue={item.quantity ?? undefined}
                  onChange={e =>
                    setLineItemItems(prev =>
                      prev.map((prevItem, index) => {
                        if (index === i) {
                          return {
                            ...prevItem,
                            quantity: Number(e.target.value),
                          };
                        }
                        return prevItem;
                      })
                    )
                  }
                />
                <p className="mt-3 text-sm leading-6 text-red-600">
                  {actionErrors[`contract_line_item_items.${i}.quantity`]?.join(
                    " "
                  )}
                </p>
              </div>
              <XMarkIcon className="h-5 text-gray-600 ml-3" />
            </div>
            <div className="col-span-3 flex items-center">
              <div>
                <CurrencyField
                  name={`contract_line_item.contract_line_item_items.price`}
                  label=""
                  defaultValue={item.price ?? undefined}
                  errors={
                    actionErrors[`contract_line_item_items.${i}.price`] ?? []
                  }
                  onChange={e =>
                    setLineItemItems(prev =>
                      prev.map((prevItem, index) => {
                        if (index === i) {
                          return {
                            ...prevItem,
                            price: Number(e.target.value.replace(/[$,]/g, "")),
                          };
                        }
                        return prevItem;
                      })
                    )
                  }
                />
              </div>
              <Bars2Icon className="h-5 text-gray-600 ml-3" />
            </div>
            <div className="col-span-3">
              <div className="font-normal text-base">
                {money((item.price ?? 0) * (item.quantity ?? 0))}
              </div>
            </div>
            <div>
              <Button
                className="text-red-600 hover:text-red-700"
                onClick={() =>
                  setLineItemItems(prev =>
                    prev.filter((_, index) => index !== i)
                  )
                }
                color="cancel"
              >
                <TrashIcon className="h-5 mr-2" />
              </Button>
            </div>
          </>
        ))}
        <div className="col-span-6 mt-2">
          <Button
            className="text-gray-600 col-span-2"
            onClick={() =>
              setLineItemItems([
                ...lineItemItems,
                {
                  item_name: "",
                  quantity: 0,
                  price: 0,
                },
              ])
            }
            color="cancel"
          >
            <PlusIcon className="h-5 mr-2" />
            Add another row
          </Button>
        </div>
        {lineItemItems.length > 1 && (
          <>
            <div className="col-span-3 flex justify-end mt-2">
              <Bars2Icon className="h-5 text-gray-600" />
            </div>
            <div className="col-span-3 text-lg mt-2">{money(totalValue)}</div>
          </>
        )}
      </div>
      <div className="flex justify-end w-full"></div>
    </>
  );
}
