import { tv } from "tailwind-variants";
import type { Breadcrumb } from "../breadcrumbs.component";
import { Breadcrumbs } from "../breadcrumbs.component";
import type { DropdownItem } from "../dropdown.component";
import Dropdown from "../dropdown.component";
import { Button } from "../button.component";
import { EllipsisVerticalIcon } from "@heroicons/react/20/solid";

const tvIntelligenceScreen = tv({
  slots: {
    container: "space-y-4 lg:space-y-8",
    title: "font-bold text-2xl lg:text-4xl lg:leading-snug",
    description: "text-sm lg:text-base mt-4",
    buttons: "flex gap-x-4 items-center",
    chip: "flex mb-3 justify-center lg:justify-start",
  },
});

export function IntelligenceScreenHeader({
  title,
  description,
  buttonsSlot,
  classNames = {},
  crumbs,
  chip,
  ellipsisItems,
}: {
  title: React.ReactNode;
  description?: React.ReactNode;
  buttonsSlot?: React.ReactNode;
  classNames?: {
    container?: string;
    title?: string;
    description?: string;
    buttons?: string;
    chip?: string;
  };
  crumbs?: Breadcrumb[];
  chip?: React.ReactNode;
  ellipsisItems?: DropdownItem[];
}) {
  const {
    container: containerClass,
    title: titleClass,
    description: descriptionClass,
    buttons: buttonsClass,
    chip: chipClass,
  } = tvIntelligenceScreen();

  return (
    <div className={containerClass({ className: classNames.container })}>
      {crumbs && <Breadcrumbs crumbs={crumbs} className="grow" />}
      <div className="flex flex-col lg:flex-row items-start lg:justify-between gap-y-4">
        <div className="flex-0">
          {chip && (
            <div className={chipClass({ className: classNames.chip })}>
              {chip}
            </div>
          )}
          <h1
            className={titleClass({ className: classNames.title })}
            id="intelligence-header-title"
          >
            {title}
          </h1>
          {description && (
            <h2
              className={descriptionClass({
                className: classNames.description,
              })}
            >
              {description}
            </h2>
          )}
        </div>
        {(buttonsSlot || ellipsisItems) && (
          <div className="flex w-full lg:w-auto">
            {buttonsSlot && (
              <div className={buttonsClass({ className: classNames.buttons })}>
                {buttonsSlot}
              </div>
            )}
            {ellipsisItems && (
              <div className="ml-auto">
                <Dropdown items={ellipsisItems} id="ellipsis-menu">
                  <Button color="transparent" type="div">
                    <EllipsisVerticalIcon className="h-8" />
                  </Button>
                </Dropdown>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
