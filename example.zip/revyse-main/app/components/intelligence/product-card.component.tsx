import type { ProductCategory, Tier } from "@prisma/client";
import StarRating from "../star-rating.component";

interface ProductCardProps {
  product: {
    id: string;
    logo_file_id: string | null;
    slug: string;
    title: string;
    vendor_name: string;
    vendor_logo_file_id: string | null;
    avg_score: number;
    cnt: number;
    description: string;
    good_for_tags?: { id: string; name: string }[];
    subCount: number;
    promo_text: string | null;
    primary_category: ProductCategory;
    tier: Tier;
  };
  handleCallback?: (id: string) => void;
  selectedProducts: string[];
}
export function ProductCard({
  product,
  handleCallback = id => {},
  selectedProducts,
}: ProductCardProps) {
  const isProductSelected = selectedProducts.includes(product.id);

  const cardClassName = `max-w-sm bg-white shadow-lg shadow-gray-200/50 rounded-lg h-full cursor-pointer hover:scale-105 cursor-pointer transition ease-in-out duration-300 ${
    isProductSelected
      ? "ring ring-sky-500 cursor-pointer hover:scale-105 cursor-pointer transition ease-in-out duration-300"
      : ""
  }`;

  return (
    <div
      className={`product-card ${cardClassName}`}
      onClick={() => {
        handleCallback(product.id);
      }}
    >
      <img
        className="rounded-t-lg object-cover w-full h-48"
        src={
          product.logo_file_id
            ? ` /images/${product.logo_file_id} `
            : product.vendor_logo_file_id
            ? ` /images/${product.vendor_logo_file_id} `
            : "/assets/default-logo.png"
        }
        alt=""
        width="192"
        height="192"
      />
      <div className="p-5 space-y-2">
        <div>
          <h5 className="text-xl lg:text-2xl font-bold tracking-tight text-gray-900">
            {product?.title}
          </h5>
          <div className="text-md lg:text-lg font-light tracking-tight text-gray-900">
            {product?.vendor_name}
          </div>
        </div>
        <div className="flex gap-3">
          <StarRating rating={product.avg_score} />
          <span>{product.avg_score.toFixed(1)}</span>
          <span className="text-gray-400">({product.cnt})</span>
        </div>
        <div className="gap-x-2 w-fit bg-transparent border-2 border-sky-500 rounded-full px-3 py-1.5 flex items-center text-sm">
          <div className="text-center w-full">
            {product.primary_category.name}
          </div>
        </div>
      </div>
    </div>
  );
}
