import React, { useMemo } from "react";
import { Table } from "../table.component";
import type {
  Contract,
  ContractLineItem,
  ManagerAccountVendor,
} from "@prisma/client";
import { map } from "lodash";
import dayjs from "dayjs";
import { money } from "~/utils/number.utils";
import StatusChip from "~/components/status-chip.component";
import { Button } from "~/components/button.component";
import {
  ArrowRightIcon,
  InformationCircleIcon,
} from "@heroicons/react/24/outline";
import { type SerializeFrom } from "@remix-run/node";
import { Tooltip } from "~/components/tooltip.component";

type TableItem = SerializeFrom<Contract> & {
  locations_count: string;
  annual_value: number | null;
  contract_line_items: SerializeFrom<ContractLineItem>[];
  manager_account_vendor: SerializeFrom<ManagerAccountVendor>;
};

const columnRenders = {
  name: {
    label: "Contract Name",
    name: "name",
    sortable: true,
  },
  contractLineItemsCount: {
    label: "Line Items",
    name: "_count.contract_line_items",
    columnClassName: "font-normal",
  },
  locationsAssigned: {
    label: "Contracted Locations",
    name: "locations_count",
    columnClassName: "font-normal",
  },
  currentTermEnds: {
    label: "Current Term Ends",
    name: "current_term_end_date",
    sortable: true,
    renderer: (contract: TableItem) => {
      return (
        <div
          className={
            dayjs.utc(contract.current_term_end_date).toDate() < new Date()
              ? "text-red-500"
              : ""
          }
        >
          {contract.current_term_end_date
            ? dayjs.utc(contract.current_term_end_date).format("MMM D, YYYY")
            : "No Data"}
        </div>
      );
    },
  },
  annualValue: {
    label: (
      <span>
        Annual Contract Value
        <Tooltip
          position="bottom"
          text="The current estimated annual value of the contract as configured today."
          size="small"
        >
          <InformationCircleIcon className="h-5 ml-1 text-gray-400" />
        </Tooltip>
      </span>
    ),
    columnClassName: "font-normal",
    renderer: (contract: TableItem) => money(contract.annual_value ?? 0, false),
  },
  status: {
    label: "Status",
    name: "status",
    sortable: true,
    renderer: (contract: TableItem) => (
      <StatusChip
        model="ContractStatus"
        status={contract.status}
        label={contract.status ?? "Canceled"}
      />
    ),
  },
  contractLineItems: {
    label: "Line Items",
    columnClassName: "font-normal",
    renderer: (contract: TableItem) => {
      return (
        <div className="flex flex-col gap-y-2">
          {(contract.contract_line_items || [])
            .slice(0, 3)
            .map(contractLineItem => (
              <div key={contractLineItem.id}>{contractLineItem.name}</div>
            ))}
          {(contract.contract_line_items?.length || 0) > 3 && (
            <Button
              to={`/intelligence/${contract.manager_account_vendor?.manager_account_id}/contract/${contract.id}/line-item`}
              color="transparent"
              className="p-0 justify-start [font-size:inherit]"
            >
              See more
            </Button>
          )}
        </div>
      );
    },
  },
  arrowRight: {
    label: "",
    renderer: (contract: TableItem) => (
      <div className="flex justify-center items-center h-full">
        <ArrowRightIcon className="w-6 h-6 text-sky-400" />
      </div>
    ),
  },
};

type TableColumn = keyof typeof columnRenders;

export function ContractsTable({
  items,
  onClickRow,
  showSelectBox = false,
  columnsToShow,
  disabledRows,
  onSelectRows,
  onOrderBy,
  defaultOrderBy,
  allowSorting = true,
}: {
  items: TableItem[];
  onClickRow?: (value: TableItem) => void;
  showSelectBox?: boolean;
  columnsToShow: TableColumn[];
  disabledRows?: {
    id: string;
  }[];
  onSelectRows?: (selectedRows: string[]) => void;
  onOrderBy?: (value: Record<string, string>) => void;
  defaultOrderBy?: Record<string, string>;
  allowSorting?: boolean;
}) {
  const cols = useMemo(() => {
    return columnsToShow.map(column => columnRenders[column]);
  }, [columnsToShow]);

  return (
    <Table
      cols={cols}
      data={items}
      showAddButton={false}
      showSelectBox={showSelectBox}
      onClickRow={onClickRow ?? (() => {})}
      disabledRows={disabledRows}
      variant="white"
      onSelectRows={rows =>
        onSelectRows !== undefined && onSelectRows(map(rows, "id"))
      }
      onOrderBy={onOrderBy}
      defaultOrderBy={defaultOrderBy}
      allowSorting={allowSorting}
      alignment="middle"
      rowIdPrefix="contract"
    />
  );
}
