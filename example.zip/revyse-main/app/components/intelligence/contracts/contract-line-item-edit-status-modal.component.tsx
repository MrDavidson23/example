import React, { useEffect } from "react";
import { Modal } from "~/components/modal.component";
import { CTA } from "~/components/cta.component";
import type {
  Contract,
  ContractLineItem,
  ManagerAccountVendor,
  Vendor,
} from "@prisma/client";
import { ContractLineItemStatus } from "@prisma/client";
import { useFetcher } from "@remix-run/react";
import type { SerializeFrom } from "@remix-run/node";
import { Button } from "~/components/button.component";
import { ArrowLeftIcon } from "@heroicons/react/24/outline";
import {
  CrudDateField,
  CrudSelectField,
} from "~/components/form/crud-form.component";
import type { action } from "~/routes/intelligence.$id.contract.$contract_id.line-item_.$contract_line_item_id_.status";
import dayjs from "dayjs";

type ModalResource = SerializeFrom<
  ContractLineItem & {
    contract: Contract & {
      manager_account_vendor: ManagerAccountVendor & {
        vendor: Vendor;
      };
    };
  }
>;

export function ContractLineItemEditStatusModal({
  contractLineItem,
  accountId,
  isOpen,
  onClose,
}: {
  contractLineItem: ModalResource;
  accountId: string;
  isOpen: boolean;
  onClose: (closed: boolean) => void;
}) {
  const fetcher = useFetcher<typeof action>();
  const [newStatus, setNewStatus] = React.useState<ContractLineItemStatus>(
    contractLineItem.status === ContractLineItemStatus.Active
      ? ContractLineItemStatus.Canceled
      : ContractLineItemStatus.Active
  );

  useEffect(() => {
    if (fetcher.data?.success) {
      onClose(true);
    }
  }, [fetcher, onClose]);

  const actionRoute = `/intelligence/${accountId}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/status`;

  return (
    <Modal isOpen={isOpen} onClose={onClose} manager={true} size="medium-small">
      <div className="px-2 lg:px-6 py-2 lg:pt-4">
        <h1 className="text-2xl [text-wrap:pretty]">
          Change the status of this line item
        </h1>
        <div className="[text-wrap:pretty] mb-4">
          To mark the <b>{contractLineItem.name}</b> line item as canceled for
          the entire{" "}
          <b>{contractLineItem.contract.manager_account_vendor.vendor.name}</b>{" "}
          contract, set the status to Canceled. If the line item is active, set
          the status to Active.
        </div>
        <fetcher.Form method="POST" action={actionRoute}>
          <CrudSelectField
            field={{
              name: "status",
              label: "Status",
              type: "select",
              options: Object.keys(ContractLineItemStatus).map(status => ({
                label: status,
                value: status,
              })),
              errors: [],
              defaultValue:
                fetcher.data?.fields.status ??
                contractLineItem.status === ContractLineItemStatus.Active
                  ? ContractLineItemStatus.Canceled
                  : ContractLineItemStatus.Active,
            }}
            onChange={e =>
              setNewStatus(e.target.value as ContractLineItemStatus)
            }
          />
          {newStatus === ContractLineItemStatus.Canceled && (
            <CrudDateField
              field={{
                name: "canceled_at",
                label: "Cancellation date (optional)",
                type: "text",
                errors: [],
                defaultValue:
                  fetcher.data?.fields.canceled_at ??
                  dayjs.utc().format("YYYY-MM-DD"),
              }}
            />
          )}
          <div className="flex justify-between mt-5 w-full">
            <Button onClick={() => onClose(true)} color="transparent">
              <ArrowLeftIcon className="h-5 mr-2" /> Back
            </Button>
            <CTA id="save-line-item-status" className="m-2" type="submit">
              Submit
            </CTA>
          </div>
        </fetcher.Form>
      </div>
    </Modal>
  );
}
