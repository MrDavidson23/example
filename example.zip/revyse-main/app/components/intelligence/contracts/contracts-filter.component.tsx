import { ContractStatus } from "@prisma/client";
import { useCallback, useMemo, useState } from "react";
import { CTA } from "~/components/cta.component";
import { FilterBar } from "~/components/filter-bar.component";
import {
  CrudCheckboxField,
  CrudDateField,
  CrudTextField,
} from "~/components/form/crud-form.component";
import { Modal } from "~/components/modal.component";
import { AutocompleteFilter } from "../autocomplete-filter.component";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
dayjs.extend(utc);

type Vendor = { id: string; name: string };

export type AllContractsFilters = {
  query?: string;
  vendors?: string[];
  owners_or_approvers?: string[];
  location_count_ranges?: string[];
  current_term_end_date_start?: string;
  current_term_end_date_end?: string;
};

type VendorContractFilters = {
  query?: string;
  status?: ContractStatus[];
  annual_value_start?: string;
  annual_value_end?: string;
  current_term_end_date_start?: string;
  current_term_end_date_end?: string;
};

const locationsAssignedFilter = [
  { value: "1-50", name: "1-50" },
  { value: "50-100", name: "50-100" },
  { value: "100-200", name: "100-200" },
  { value: "200-500", name: "200-500" },
  { value: "500", name: "500+" },
] as const;

export function ContractsFilter({
  isAllContracts,
  initialSearchParams,
  onFilter,
  vendorOptions,
  ownersApproversOptions,
}: {
  isAllContracts?: boolean;
} & (
  | {
      isAllContracts?: false | undefined;
      vendorOptions?: Vendor[];
      ownersApproversOptions?: (string | null)[];
      initialSearchParams?: VendorContractFilters;
      onFilter: (searchParams: VendorContractFilters) => void;
    }
  | {
      isAllContracts: true;
      vendorOptions: Vendor[];
      ownersApproversOptions: (string | null)[];
      initialSearchParams?: AllContractsFilters;
      onFilter: (searchParams: AllContractsFilters) => void;
    }
)) {
  const [searchParams, setSearchParams] = useState<
    VendorContractFilters & AllContractsFilters
  >(initialSearchParams ?? {});

  const [openFilteringModal, setOpenFilteringModal] = useState(false);
  const [vendorInputValue, setVendorInputValue] = useState("");
  const [ownerApproverInputValue, setOwnerApproverInputValue] = useState("");

  const filteredVendors = vendorOptions?.filter(vendor =>
    vendor?.name.toLowerCase().includes(vendorInputValue.toLowerCase())
  );

  const filteredOwnersAndApprovers = ownersApproversOptions?.filter(name =>
    name?.toLowerCase().includes(ownerApproverInputValue.toLowerCase())
  );

  const filtersCount = useMemo(() => {
    return (
      (searchParams.status ? searchParams.status.length : 0) +
      (searchParams.annual_value_start ? 1 : 0) +
      (searchParams.annual_value_end ? 1 : 0) +
      (searchParams.location_count_ranges
        ? searchParams.location_count_ranges.length
        : 0) +
      (searchParams.vendors ? searchParams.vendors.length : 0) +
      (searchParams.owners_or_approvers
        ? searchParams.owners_or_approvers.length
        : 0) +
      (searchParams.current_term_end_date_start ? 1 : 0) +
      (searchParams.current_term_end_date_end ? 1 : 0)
    );
  }, [searchParams]);

  const clearFilters = useCallback(() => {
    setSearchParams({});
    setOpenFilteringModal(false);
    onFilter({});
  }, [onFilter]);

  const annualSpendError = useMemo(() => {
    if (searchParams.annual_value_start && searchParams.annual_value_end) {
      if (
        Number(searchParams.annual_value_start) >
        Number(searchParams.annual_value_end)
      ) {
        return "Starting value must be less than ending value";
      }
    }
    return "";
  }, [searchParams]);

  const currentTermEndDateError = useMemo(() => {
    if (
      searchParams.current_term_end_date_start &&
      searchParams.current_term_end_date_end
    ) {
      if (
        new Date(searchParams.current_term_end_date_start) >
        new Date(searchParams.current_term_end_date_end)
      ) {
        return "Starting date must be before ending date";
      }
    }
    return "";
  }, [searchParams]);

  return (
    <>
      <Modal
        isOpen={openFilteringModal}
        onClose={() => setOpenFilteringModal(false)}
        size="medium"
        manager={true}
      >
        <div className="p-2 lg:p-6">
          <h4 className="font-bold">Filter By</h4>
          <div className="divide divide-y divide-2 ">
            {isAllContracts ? (
              <>
                <div>
                  <div className="my-4 font-semibold"># Locations Assigned</div>
                  <div className="flex justify-around">
                    {locationsAssignedFilter.map(option => (
                      <CrudCheckboxField
                        key={option.value}
                        field={{
                          name: "filter_by",
                          value: option.value,
                          label: option.name,
                          errors: [],
                          description: "",
                          defaultChecked: searchParams.location_count_ranges
                            ?.join(",")
                            .includes(option.value),
                          type: "checkbox",
                        }}
                        onChange={evt => {
                          const checked = evt.target.checked;
                          if (checked) {
                            setSearchParams({
                              ...searchParams,
                              location_count_ranges: [
                                ...(searchParams.location_count_ranges || []),
                                option.value,
                              ],
                            });
                          } else {
                            setSearchParams({
                              ...searchParams,
                              location_count_ranges:
                                searchParams.location_count_ranges?.filter(
                                  value => value !== option.value
                                ),
                            });
                          }
                        }}
                      />
                    ))}
                  </div>
                </div>
                <div>
                  <div className="my-4 font-semibold">Vendors</div>
                  <AutocompleteFilter
                    initialValue={vendorInputValue}
                    options={filteredVendors || []}
                    onFilterChange={setVendorInputValue}
                    onAddTag={vendor => {
                      setSearchParams({
                        ...searchParams,
                        vendors: [...(searchParams.vendors || []), vendor.id],
                      });
                      setVendorInputValue("");
                    }}
                    onRemoveTag={vendor =>
                      setSearchParams({
                        ...searchParams,
                        vendors: searchParams.vendors?.filter(
                          value => value !== vendor.id
                        ),
                      })
                    }
                    selectedTags={
                      vendorOptions?.filter(vendor =>
                        searchParams.vendors?.includes(vendor.id)
                      ) ?? []
                    }
                    errorMessage={""}
                    renderOption={vendor => vendor.name}
                  />
                </div>
                <div>
                  <div className="my-4 font-semibold">
                    Contract Owner or Contract Approver
                  </div>
                  <AutocompleteFilter
                    initialValue={ownerApproverInputValue}
                    options={filteredOwnersAndApprovers || []}
                    onFilterChange={setOwnerApproverInputValue}
                    onAddTag={name => {
                      setSearchParams({
                        ...searchParams,
                        owners_or_approvers: [
                          ...(searchParams.owners_or_approvers || []),
                          name ?? "",
                        ],
                      });
                      setOwnerApproverInputValue("");
                    }}
                    onRemoveTag={name =>
                      setSearchParams({
                        ...searchParams,
                        owners_or_approvers:
                          searchParams.owners_or_approvers?.filter(
                            value => value !== name
                          ),
                      })
                    }
                    selectedTags={searchParams.owners_or_approvers ?? []}
                    errorMessage={""}
                    renderOption={name => name}
                  />
                </div>
              </>
            ) : (
              <>
                <div>
                  <div className="my-4 font-semibold">Status</div>
                  <div className="flex justify-start space-x-7">
                    {Object.values(ContractStatus).map(option => (
                      <CrudCheckboxField
                        key={option}
                        field={{
                          name: "filter_by",
                          value: option,
                          label: option,
                          errors: [],
                          description: "",
                          defaultChecked: searchParams.status?.includes(option),
                          type: "checkbox",
                        }}
                        onChange={evt => {
                          const checked = evt.target.checked;
                          if (checked) {
                            setSearchParams({
                              ...searchParams,
                              status: [...(searchParams.status || []), option],
                            });
                          } else {
                            setSearchParams({
                              ...searchParams,
                              status: searchParams.status?.filter(
                                value => value !== option
                              ),
                            });
                          }
                        }}
                      />
                    ))}
                  </div>
                </div>
                <div>
                  <div className="my-4 font-semibold">
                    Annual Contract Value Range
                  </div>
                  <div className="grid grid-cols-2 gap-x-6">
                    <div>
                      <CrudTextField
                        field={{
                          name: "",
                          label: "Starting Value",
                          errors: annualSpendError ? [annualSpendError] : [],
                          description: "",
                          defaultValue: searchParams.annual_value_start,
                          type: "number",
                          placeholder: "From value",
                          onChange: evt => {
                            setSearchParams({
                              ...searchParams,
                              annual_value_start: evt.target.value,
                            });
                          },
                        }}
                      />
                    </div>
                    <div>
                      <CrudTextField
                        field={{
                          name: "",
                          label: "Ending Value",
                          errors: [],
                          description: "",
                          defaultValue: searchParams.annual_value_end,
                          type: "text",
                          placeholder: "To value",
                          onChange: evt => {
                            setSearchParams({
                              ...searchParams,
                              annual_value_end: evt.target.value,
                            });
                          },
                        }}
                      />
                    </div>
                  </div>
                </div>
              </>
            )}
            <div>
              <div className="my-4 font-semibold">
                Current Term End Date Range
              </div>
              <div className="grid grid-cols-2 gap-x-6">
                <div>
                  <CrudDateField
                    field={{
                      name: "",
                      label: "Start Date",
                      errors: currentTermEndDateError
                        ? [currentTermEndDateError]
                        : [],
                      description: "",
                      defaultValue: searchParams.current_term_end_date_start
                        ? dayjs
                            .utc(
                              searchParams.current_term_end_date_start as string
                            )
                            .format("YYYY-MM-DD")
                        : undefined,
                      type: "text",
                      placeholder: "From date",
                      onChange: evt => {
                        setSearchParams({
                          ...searchParams,
                          current_term_end_date_start: evt.target.value,
                        });
                      },
                    }}
                  />
                </div>
                <div>
                  <CrudDateField
                    field={{
                      name: "",
                      label: "End Date",
                      errors: [],
                      description: "",
                      defaultValue: searchParams.current_term_end_date_end
                        ? dayjs
                            .utc(
                              searchParams.current_term_end_date_end as string
                            )
                            .format("YYYY-MM-DD")
                        : undefined,
                      type: "text",
                      placeholder: "To date",
                      onChange: evt => {
                        setSearchParams({
                          ...searchParams,
                          current_term_end_date_end: evt.target.value,
                        });
                      },
                    }}
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="flex justify-end mt-8 items-center space-x-3">
            <button
              className="text-sky-500"
              onClick={() => {
                clearFilters();
              }}
            >
              Clear filters
            </button>
            <CTA
              variant="coral-shadow"
              onClick={() => {
                setOpenFilteringModal(false);
                onFilter(searchParams);
              }}
            >
              Show results
            </CTA>
          </div>
        </div>
      </Modal>
      <FilterBar
        defaultSearchQuery={searchParams.query}
        onFilter={searchQuery => {
          const newSearchParams: AllContractsFilters | VendorContractFilters = {
            ...searchParams,
            query: searchQuery,
          };
          setSearchParams(newSearchParams);
          if (searchQuery === "") {
            delete newSearchParams.query;
          }
          onFilter(newSearchParams);
        }}
        filters={{
          onOpenFilteringModal: setOpenFilteringModal,
          filtersCount,
        }}
      />
    </>
  );
}
