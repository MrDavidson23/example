import { useMemo } from "react";
import { Table } from "../table.component";
import type { ProductCategory, Vendor } from "@prisma/client";
import StatusChip from "~/components/status-chip.component";
import { Button } from "~/components/button.component";
import { RevysePencilIcon } from "~/components/revyse-pencil-icon.component";
import { CurrencyDollarIcon } from "@heroicons/react/20/solid";

type ProductOrFee = {
  id: string;
  title?: string;
  name?: string;
  logo_file_id?: string;
  primary_category?: ProductCategory;
  category?: ProductCategory;
  new?: boolean;
  vendor?: Vendor;
};

type TableColumn = "title" | "category" | "new";

export function ProductsAndFeesTable({
  items,
  columnsToShow,
  handleSelection,
  handleFee,
  selectedRows,
  handleEditModal,
  confirmEditOpen,
  handleAddButton,
}: {
  items: ProductOrFee[];
  columnsToShow: TableColumn[];
  handleSelection: (id: string) => void;
  handleFee?: (fee: {
    id: string;
    name: string | undefined;
    category_id: string | undefined;
  }) => void;
  selectedRows: ProductOrFee[];
  handleEditModal?: (value: boolean) => void;
  confirmEditOpen?: Boolean;
  handleAddButton: () => void;
}) {
  const columnRenders = {
    title: {
      label: "Selected Product, Service, or Fee",
      renderer: (item: ProductOrFee) => {
        return (
          <div className="flex items-center space-x-5">
            <input
              checked={selectedRows.some(
                (row: ProductOrFee) => row.id === item.id
              )}
              onChange={() => handleSelection(item.id)}
              onClick={e => e.stopPropagation()}
              id="default-checkbox"
              type="checkbox"
              value=""
              className="w-4 h-4 text-sky-500 bg-gray-100 border-gray-300 rounded focus:ring-sky-500 focus:ring-2"
            />
            <div className="bg-white rounded-md border border-gray-200 overflow-hidden hidden lg:block">
              {item.logo_file_id ? (
                <img
                  className="w-12 h-12"
                  src={`/images/${item.logo_file_id}`}
                  alt="Product Logo"
                  width="48"
                  height="48"
                />
              ) : item.vendor?.logo_file_id ? (
                <img
                  className="w-12 h-12"
                  src={`/images/${item.vendor?.logo_file_id}`}
                  alt="Vendor Logo"
                  width="48"
                  height="48"
                />
              ) : (
                <img
                  className="w-12 h-12"
                  src="/assets/default-logo.png"
                  alt="Default Vendor Logo"
                  width="600"
                  height="600"
                />
              )}
            </div>
            <div>{item.title ?? item.name}</div>
          </div>
        );
      },
    },
    category: {
      label: "Product Category",
      renderer: (item: ProductOrFee) => {
        return (
          <>
            {item.primary_category?.name && (
              <StatusChip color="sky" label={item.primary_category?.name} />
            )}
            {item.category?.name && (
              <StatusChip color="sky" label={item.category?.name} />
            )}
          </>
        );
      },
    },
    new: {
      label: "New Fee",
      renderer: (item: ProductOrFee) => {
        return (
          <div>{item.new && <StatusChip color="green" label="New Fee" />}</div>
        );
      },
    },
  };

  const cols = useMemo(() => {
    let result = columnsToShow.map(column => columnRenders[column]);
    if (handleFee && handleEditModal) {
      result.push({
        label: "",
        renderer: (item: ProductOrFee) =>
          item.category?.id ? (
            <div className="flex items-center h-full">
              <Button
                color="transparent"
                className="gap-x-1"
                onClick={e => {
                  e.preventDefault();
                  e.stopPropagation();
                  handleFee({
                    id: item.id.replace(/^fee_/, ""),
                    name: item.name,
                    category_id: item.category?.id,
                  });
                  handleEditModal(!confirmEditOpen);
                }}
              >
                <RevysePencilIcon className="h-5" />
                Edit
              </Button>
            </div>
          ) : (
            <></>
          ),
      });
    }
    return result;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [handleFee, handleEditModal, columnsToShow, confirmEditOpen]);

  return (
    <Table
      cols={cols}
      data={items}
      showAddButton={true}
      showSelectBox={false}
      variant="white"
      alignment="middle"
      onClickRow={row => {
        handleSelection && handleSelection(row.id);
      }}
      handleCallback={handleAddButton}
      alwaysShowAdd={true}
      addButtonLabel="Add new fee"
      selectedData={selectedRows}
      addButtonHeading={
        <div className="flex items-center space-x-3">
          <CurrencyDollarIcon className="h-7 w-7 text-emerald-500"></CurrencyDollarIcon>
          <div className="tracking-tight text-gray-900 text-center">
            Fees or other charges
          </div>
        </div>
      }
    />
  );
}
