import type { ChangeEvent } from "react";
import { useEffect, useState } from "react";
import { XMarkIcon } from "@heroicons/react/24/outline";
import { CrudTextField } from "../form/crud-form.component";

interface AutocompleteFilterProps<T> {
  initialValue: string;
  options: T[];
  onFilterChange: (filter: string) => void;
  onAddTag: (tag: T) => void;
  onRemoveTag: (tag: T) => void;
  selectedTags: T[];
  errorMessage: string;
  renderOption: (option: T) => React.ReactNode;
}

export function AutocompleteFilter<T>({
  initialValue,
  options,
  onFilterChange,
  onAddTag,
  onRemoveTag,
  selectedTags,
  errorMessage,
  renderOption,
}: AutocompleteFilterProps<T>) {
  const [autocompleteValue, setAutocompleteValue] = useState(initialValue);
  const [, setError] = useState("");

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    setAutocompleteValue(value);
    onFilterChange(value);
    setError("");
  };

  useEffect(() => {
    setAutocompleteValue(initialValue);
  }, [initialValue]);

  return (
    <div>
      <div className="relative w-full h-fit">
        <CrudTextField
          field={{
            name: "",
            label: "",
            errors: errorMessage ? [errorMessage] : [],
            type: "text",
            placeholder: "Search your filter",
            defaultValue: autocompleteValue,
            onChange: handleInputChange,
          }}
        />
        {autocompleteValue && (
          <div className="-mt-4 rounded-lg p-2 h-min overflow-auto bg-sky-50 w-3/6 shadow-lg mb-6">
            <div className="divide-y divide-solid divide-gray-200">
              {options.map((option, index) => (
                <div
                  key={index}
                  onClick={() => onAddTag(option)}
                  className="flex items-center p-2 hover:bg-sky-100 rounded-md transition ease-in-out duration-100"
                >
                  {renderOption(option)}
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
      <div className="flex flex-wrap space-x-2 mb-6">
        {selectedTags.map((tag, index) => (
          <div className="flex justify-center items-center w-max" key={index}>
            <div className="gap-x-2 w-full bg-transparent border-2 border-sky-500 rounded-full px-3 py-1.5 flex items-center text-sm">
              <button className="font-light" onClick={() => onRemoveTag(tag)}>
                <XMarkIcon className="h-5 text-sky-500" />
              </button>
              <div className="text-center w-full">{renderOption(tag)}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
