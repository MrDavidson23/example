import { Disclosure, Transition } from "@headlessui/react";
import { Link } from "@remix-run/react";
import { tv } from "tailwind-variants";
import type { IntelligenceModuleLink } from "~/routes/intelligence.$id";

const tvModuleNavLink = tv({
  base: "text-base flex items-center text-gray-900 font-normal cursor-pointer p-3 hover:bg-gray-50 hover:text-sky-500 rounded-lg ease-in duration-300",
  variants: {
    collapsed: {
      true: "justify-center mx-auto w-min",
      false: "justify-start w-10/12",
    },
    isActive: {
      true: "bg-gray-50",
    },
  },
});

export function ModuleNavLink({
  link,
  collapsed,
  className,
  toggleCollapse,
  onClick,
  isActive,
}: {
  link: IntelligenceModuleLink;
  collapsed?: boolean;
  className?: string;
  toggleCollapse?: () => void;
  onClick?: React.MouseEventHandler<HTMLAnchorElement> | undefined;
  isActive?: boolean;
}) {
  if (link.options || link.to === undefined) {
    return (
      <ModuleNavLinkWithOptions
        link={link}
        collapsed={collapsed}
        toggleCollapse={toggleCollapse}
        isActive={isActive}
        onClick={onClick}
      />
    );
  }

  return (
    <Link
      id={link.id}
      to={link.to}
      className={tvModuleNavLink({ collapsed, className, isActive })}
      onClick={onClick}
    >
      <link.iconComponent className="h-5 w-5 lg:h-6" />
      {!collapsed && (
        <div className="flex justify-between items-center w-full">
          <span className="ml-3">{link.label}</span>
          {link.badgeCount !== undefined && (
            <span className="w-min 2xl:ml-8 md:ml-4 ml-1 mr-auto rounded-2xl px-3 py-1 border capitalize text-center bg-yellow-50 text-gray-900 border-yellow-500 text-sm">
              {link.badgeCount}
            </span>
          )}
        </div>
      )}
      {collapsed && (
        <span className="z-40 w-max hover:opacity-100 opacity-0 ease-in duration-300 absolute left-0 hover:pl-20">
          <div className="bg-white text-sky-500 p-2 rounded-md shadow-md z-40 text-sm text-left px-4 font-medium">
            {link.label}
            {link.badgeCount !== undefined && (
              <span className="w-min ml-3 mr-auto rounded-2xl px-3 py-1 border capitalize text-center bg-yellow-50 text-gray-900 border-yellow-500 text-sm">
                {link.badgeCount}
              </span>
            )}
          </div>
        </span>
      )}
    </Link>
  );
}

function ModuleNavLinkWithOptions({
  link,
  collapsed,
  toggleCollapse,
  isActive,
  onClick,
}: {
  link: IntelligenceModuleLink;
  collapsed?: boolean;
  toggleCollapse?: () => void;
  isActive?: boolean;
  onClick: React.MouseEventHandler<HTMLAnchorElement> | undefined;
}) {
  const Icon = link.iconComponent;
  return (
    <div>
      <Disclosure>
        {({ open }) => (
          <>
            <Disclosure.Button
              as="div"
              onClick={() => collapsed && toggleCollapse?.()}
              className={tvModuleNavLink({ collapsed, isActive })}
            >
              <Icon className="h-5 w-5 lg:h-6 lg:w-6" />
              {!collapsed && (
                <div className="flex justify-between items-center w-full">
                  <span className="ml-3">{link.label}</span>
                  {link.badgeCount !== undefined && (
                    <span className="w-min 2xl:ml-8 md:ml-4 ml-1 mr-auto rounded-2xl px-3 py-1 border capitalize text-center bg-yellow-50 text-gray-900 border-yellow-500 text-sm">
                      {link.badgeCount}
                    </span>
                  )}
                </div>
              )}
              {collapsed && (
                <span className="z-40 w-auto hover:opacity-100 opacity-0 ease-in duration-300 absolute left-0 hover:pl-20">
                  <div className="bg-white w-fit text-sky-500 p-2 rounded-md shadow-md z-40 text-sm text-left px-4 font-medium">
                    {link.label}
                    {link.badgeCount !== undefined && (
                      <span className="w-min ml-3 mr-auto rounded-2xl px-3 py-1 border capitalize text-center bg-yellow-50 text-gray-900 border-yellow-500 text-sm">
                        {link.badgeCount}
                      </span>
                    )}
                  </div>
                </span>
              )}
            </Disclosure.Button>

            <Transition
              enter="transition duration-100 ease-out"
              enterFrom="transform scale-95 opacity-0"
              enterTo="transform scale-100 opacity-100"
              leave="transition duration-75 ease-out"
              leaveFrom="transform scale-100 opacity-100"
              leaveTo="transform scale-95 opacity-0"
            >
              <Disclosure.Panel
                className={`relative ${collapsed ? "hidden" : ""}`}
              >
                <div className="absolute h-full w-0.5 bg-sky-200 top-0 left-3 rounded-md"></div>
                <div className="ml-3">
                  {link.options?.map((link, i) => {
                    const Icon = link.iconComponent as
                      | JSX.ElementType
                      | undefined;
                    return (
                      <div key={i} className="w-full text-gray-900">
                        <Link
                          id={link.id}
                          to={link.to}
                          className={tvModuleNavLink({
                            collapsed,
                            className: "text-sm",
                          })}
                          onClick={onClick}
                        >
                          {Icon && <Icon className="h-5 w-5 lg:h-6" />}
                          {!collapsed && (
                            <div className="flex justify-between items-center w-full">
                              <span className="ml-1 [text-wrap:pretty]">
                                {link.label}
                              </span>
                            </div>
                          )}
                          {collapsed && (
                            <span className="z-40 w-auto hover:opacity-100 opacity-0 ease-in duration-300 absolute left-0 hover:pl-20">
                              <div className="bg-white w-fit text-sky-500 p-2 rounded-md shadow-md z-40 text-sm text-left px-4 font-medium [text-wrap:pretty]">
                                {link.label}
                              </div>
                            </span>
                          )}
                        </Link>
                      </div>
                    );
                  })}
                </div>
              </Disclosure.Panel>
            </Transition>
          </>
        )}
      </Disclosure>
    </div>
  );
}
