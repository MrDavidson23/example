import { InformationCircleIcon, TrashIcon } from "@heroicons/react/24/outline";
import { useCallback, useMemo, useRef, useState } from "react";
import {
  Form,
  Link,
  useActionData,
  useFetcher,
  useNavigation,
} from "@remix-run/react";
import type {
  Contract,
  ContractLineItem,
  ContractLineItemFee,
  ContractLineItemProduct,
  Fee,
  ManagerAccount,
  ManagerAccountVendor,
  Product,
  Vendor,
} from "@prisma/client";
import type { action as priceConfigAction } from "../../routes/intelligence.$id.contract.$contract_id.line-item_.$contract_line_item_id_.set-price";
import {
  ContractPricingType,
  ContractLineItemPriceIncreaseCadence,
} from "@prisma/client";
import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
import relativeTime from "dayjs/plugin/relativeTime";
import {
  CrudRadioButtonField,
  CrudSelectField,
  CrudTextField,
  FormSection,
} from "~/components/form/crud-form.component";
import { Button, DangerButton } from "~/components/button.component";
import { Tooltip } from "~/components/tooltip.component";
import type { SerializeFrom } from "@remix-run/node";
import { CurrencyField } from "../form/currency-field.component";
import { PercentField } from "../form/percent-field.component";
import { isEmpty, isNil } from "lodash";
import { type PermissionUser } from "~/utils/intelligence-permission.utils";
import { ProductRow } from "./product-row.component";
import { FeeRow } from "./fee-row.component";
import {
  ContractLineItemPriceCadenceLabels,
  ContractPricingTypeLabels,
} from "~/utils/constants.utils";
import { tvField } from "~/utils/global-tailwind-variants.utils";
import { ArrowLeftIcon } from "@heroicons/react/20/solid";
import { CTA } from "../cta.component";
import { Editor } from "../reactquill/richtext-editor.component";
import type { ContractLineItemItem } from "./contract-line-item/contract-line-item-items-manager.component";
import { ContractLineItemItemsManager } from "./contract-line-item/contract-line-item-items-manager.component";
dayjs.extend(utc);
dayjs.extend(relativeTime);

export type FormContractLineItem = SerializeFrom<
  ContractLineItem & {
    contract: SerializeFrom<
      Contract & {
        manager_account_vendor: SerializeFrom<
          ManagerAccountVendor & {
            vendor: SerializeFrom<Vendor>;
          }
        >;
      }
    >;
  } & {
    contract_line_item_products: SerializeFrom<
      ContractLineItemProduct & {
        product: SerializeFrom<Product>;
      }
    >[];
  } & {
    contract_line_item_fees: SerializeFrom<
      ContractLineItemFee & {
        fee: Fee | null;
      }
    >[];
  }
>;
export function SetPriceForm({
  user,
  contractLineItem,
  account,
}: {
  user: PermissionUser;
  contractLineItem: FormContractLineItem;
  account: SerializeFrom<ManagerAccount>;
}) {
  const actionData = useActionData<typeof priceConfigAction>();
  const navigation = useNavigation();

  const singleItem =
    contractLineItem.contract_line_item_products.length +
      contractLineItem.contract_line_item_fees.length ===
    1;

  const lineItemName = singleItem
    ? contractLineItem.contract_line_item_products?.[0]?.product?.title ||
      contractLineItem.contract_line_item_fees?.[0]?.fee?.name
    : undefined;

  const productContractLineItem =
    contractLineItem.contract_line_item_products[0];
  const feeContractLineItem = contractLineItem.contract_line_item_fees[0];

  const [currentDepartment, setCurrentDepartment] = useState<
    string | null | undefined
  >(
    !isEmpty(productContractLineItem?.department)
      ? productContractLineItem?.department
      : !isEmpty(feeContractLineItem?.department)
      ? feeContractLineItem?.department
      : null
  );
  const [searchTerm, setSearchTerm] = useState("");

  const departmentInputRef = useRef<HTMLInputElement | null>(null);
  const fetcher = useFetcher<typeof priceConfigAction>();

  const defaultIsCorporate = fetcher.data?.fields
    ? fetcher.data.fields.is_corporate_only === "false"
      ? false
      : true
    : contractLineItem?.is_corporate_only ?? false;

  const handleInputChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const searchTerm = e.target.value;
    setSearchTerm(searchTerm);
    if (departmentInputRef?.current) departmentInputRef.current.value = "";

    fetcher.submit(
      {
        intent: "searchDepartment",
        term: searchTerm,
      },
      {
        action: `/intelligence/${account.id}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/set-price`,
        method: "post",
        encType: "multipart/form-data",
      }
    );
  };

  const handleBackspace = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Backspace") {
      setCurrentDepartment(null);
    }
  };
  const priceIncreaseOptions = [
    {
      label: "Increase At Renewal",
      value: ContractLineItemPriceIncreaseCadence.IncreaseAtRenewal,
    },
    {
      label: "Annual Increase",
      value: ContractLineItemPriceIncreaseCadence.AnnualIncrease,
    },
  ];

  const pricingTypeOptions = useMemo(
    () =>
      Object.entries(ContractPricingTypeLabels)
        .filter(([key]) => key !== ContractPricingType.Itemized || singleItem)
        .map(([key, value]) => ({
          label: value,
          value: key,
        })),
    [singleItem]
  );

  const [lineItem, setLineItem] = useState<
    Pick<
      typeof contractLineItem,
      | "id"
      | "name"
      | "cadence"
      | "pricing_type"
      | "seats_number"
      | "price"
      | "setup_fee"
      | "discount"
      | "price_increase_percent"
      | "price_increase_cadence"
      | "contract_line_item_products"
      | "contract_line_item_fees"
    >
  >(contractLineItem ?? []);
  const [pricingType, setPricingType] = useState<
    ContractPricingType | undefined
  >(
    (actionData?.fields?.pricing_type as ContractPricingType) ??
      contractLineItem?.pricing_type ??
      undefined
  );
  const [pricingCadence, setPricingCadence] = useState(
    actionData?.fields
      ? actionData?.fields?.cadence
      : contractLineItem
      ? (contractLineItem.cadence as string)
      : undefined
  );
  const [notes, setNotes] = useState(
    actionData?.fields
      ? actionData?.fields?.notes
      : contractLineItem.notes
      ? (contractLineItem.notes as string)
      : undefined
  );

  const [lineItemProducts] = useState(
    contractLineItem.contract_line_item_products
  );
  const [lineItemFees] = useState(contractLineItem.contract_line_item_fees);
  const [totalProductPrice, setTotalPrice] = useState(calculateTotalPrice());

  const [confirmDeleteOpen, setConfirmDeleteOpen] = useState(false);

  function calculateTotalPrice() {
    const productTotal =
      lineItemProducts &&
      lineItemProducts.reduce((sum, product) => sum + (product.price || 0), 0);
    const feeTotal =
      lineItemFees &&
      lineItemFees.reduce((sum, fee) => sum + (fee.price || 0), 0);
    return productTotal + feeTotal;
  }

  async function handleProductPriceChange(index: number, newPrice: string) {
    const priceAsNumber = Number(newPrice.replace(/[^\d.]/g, ""));

    const updatedProducts = [...lineItemProducts];
    updatedProducts[index].price = priceAsNumber;
    setLineItem({
      ...lineItem,
      contract_line_item_products: updatedProducts,
    });
    setTotalPrice(calculateTotalPrice());
  }

  async function handleFeePriceChange(index: number, newPrice: string) {
    const priceAsNumber = Number(newPrice.replace(/[^\d.]/g, ""));

    const updatedFees = [...lineItemFees];
    updatedFees[index].price = priceAsNumber;
    setLineItem({
      ...lineItem,
      contract_line_item_fees: updatedFees,
    });
    setTotalPrice(calculateTotalPrice());
  }

  const handleOnPriceChange = useCallback(
    (newPrice: number) =>
      setLineItem(prev => ({
        ...prev,
        price: newPrice,
      })),
    []
  );

  return (
    <div className="space-y-8">
      <div
        className={`bg-white shadow-lg shadow-gray-200/50 p-3 md:p-8 rounded-lg h-min`}
      >
        <FormSection
          title="Line Item Details"
          subtitle="Enter the primary information for your line item."
          spacing="compact"
        >
          <div className="grid md:grid-cols-2 col-span-full items-start gap-2 ">
            <CrudTextField
              field={{
                name: "name",
                type: "text",
                errors: actionData?.errors?.name ?? [],
                label: "Line Item Name",
                placeholder: "Give your line item a name",
                defaultValue: lineItemName
                  ? lineItemName
                  : actionData?.fields?.name
                  ? actionData?.fields?.name
                  : contractLineItem.name ?? undefined,
                maxCharacters: 55,
              }}
            />

            {!contractLineItem.contract.location_id && (
              <div className="space-y-2">
                <div className="flex items-center space-x-1">
                  <div className="block text-sm font-medium leading-6 text-gray-900">
                    Is this line item corporate-only?
                  </div>
                  <Tooltip
                    position="right"
                    text="A corporate-only line item is a product, service, or fee that is assigned only to corporate, and will not be assigned to individual locations."
                  >
                    <div className="flex flex-row items-center cursor-pointer">
                      <InformationCircleIcon className="h-5 text-gray-400" />
                    </div>
                  </Tooltip>
                </div>
                <div className="flex items-center space-x-2">
                  <CrudRadioButtonField
                    field={{
                      label: "No",
                      value: "false",
                      defaultChecked: !defaultIsCorporate,
                      name: "is_corporate_only",
                      type: "radio",
                      errors: actionData?.errors?.is_corporate_only ?? [],
                      description: "",
                    }}
                  />
                  <CrudRadioButtonField
                    field={{
                      label: "Yes",
                      value: "true",
                      defaultChecked: defaultIsCorporate,
                      name: "is_corporate_only",
                      type: "radio",
                      errors: actionData?.errors?.is_corporate_only ?? [],
                      description: "",
                    }}
                  />
                </div>
              </div>
            )}
            {singleItem && (
              <div className="col-span-full">
                <input
                  type="hidden"
                  name={`contract_line_item.${contractLineItem.id}.${
                    contractLineItem.contract_line_item_products.length === 1
                      ? "contract_line_item_products.id"
                      : "contract_line_item_fees.id"
                  }`}
                  value={
                    contractLineItem?.contract_line_item_products.length === 1
                      ? contractLineItem?.contract_line_item_products[0].id
                      : contractLineItem?.contract_line_item_fees[0].id
                  }
                />
                {contractLineItem.contract_line_item_products.length === 1 && (
                  <input
                    type="hidden"
                    name={`contract_line_item.${contractLineItem.id}.contract_line_item_products.contract_line_item_product_id`}
                    value={
                      contractLineItem?.contract_line_item_products[0]
                        .product_id
                    }
                  />
                )}
                <input
                  type="hidden"
                  name={`contract_line_item.${contractLineItem.id}.${
                    contractLineItem.contract_line_item_products.length === 1
                      ? "contract_line_item_products.price"
                      : "contract_line_item_fees.price"
                  }`}
                  value={lineItem.price ?? 0}
                />
                <input
                  type="hidden"
                  name={`contract_line_item.${contractLineItem.id}.${
                    contractLineItem.contract_line_item_products.length === 1
                      ? "contract_line_item_products.department"
                      : "contract_line_item_fees.department"
                  }`}
                  value={currentDepartment ?? searchTerm}
                />
                <div className="flex items-center space-x-2">
                  <label
                    htmlFor="selectedDepartment"
                    className="block text-sm font-medium leading-6 text-gray-900"
                  >
                    Department Assignment{" "}
                    <span className="font-light text-gray-400">(Optional)</span>{" "}
                  </label>
                  <Tooltip text="By assigning this line item to a department, you’ll be able to view spend by department on the dashboard reports.">
                    <div className="flex flex-row items-center cursor-pointer">
                      <InformationCircleIcon className="h-5 text-gray-400" />
                    </div>
                  </Tooltip>
                </div>
                <input
                  className={tvField({ className: "z-50 my-2" })}
                  name="selectedDepartment"
                  id="department"
                  value={currentDepartment ?? searchTerm}
                  placeholder="Type a department"
                  onChange={e => handleInputChange(e)}
                  onKeyDown={e => handleBackspace(e)}
                  ref={departmentInputRef}
                  onClick={e => e.stopPropagation()}
                />
                {fetcher.state === "idle" &&
                  fetcher.data?.success &&
                  fetcher?.data?.departments &&
                  !isEmpty(fetcher?.data?.departments) && (
                    <div className="-my-2 rounded-lg p-3 h-72 overflow-auto absolute bg-sky-50 w-72 shadow-lg mb-6 z-50">
                      <div className="divide-y divide-solid divide-gray-200">
                        {fetcher?.data?.departments?.map(
                          (
                            department: { department: string },
                            index: number
                          ) => (
                            <div
                              className="flex items-center p-3 hover:bg-sky-100 rounded-md transition ease-in-out duration-100"
                              key={index}
                              onClick={e => {
                                fetcher.submit(
                                  {
                                    intent: "searchDepartment",
                                    term: "",
                                  },
                                  {
                                    action: `/intelligence/${account.id}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/set-price`,
                                    method: "post",
                                    encType: "multipart/form-data",
                                  }
                                );

                                if (departmentInputRef?.current)
                                  departmentInputRef.current.value = searchTerm;
                                setCurrentDepartment(department.department);
                              }}
                            >
                              <div>{department.department}</div>
                            </div>
                          )
                        )}
                      </div>
                    </div>
                  )}
              </div>
            )}
          </div>
        </FormSection>
        <FormSection
          title={` ${
            singleItem ? "Line Item Pricing" : "Bundled Line Item Pricing"
          } `}
          subtitle={` ${
            singleItem &&
            !isEmpty(contractLineItem?.contract_line_item_products)
              ? `Selected product: ${contractLineItem?.contract_line_item_products[0].product.title}`
              : singleItem &&
                !isEmpty(contractLineItem?.contract_line_item_fees)
              ? `Selected fee: ${contractLineItem?.contract_line_item_fees[0].fee?.name}`
              : "Itemize the pricing for each product, service, or fee included in your line item, and record the department assignments at a granular level."
          }`}
        >
          <div className="grid md:grid-cols-2 col-span-full items-start gap-2 pb-4">
            <input
              type="hidden"
              name="contract_line_item.id"
              value={contractLineItem.id}
            />
            <input type="hidden" name="intent" value="updateContractLineItem" />
            <CrudSelectField
              field={{
                name: "contract_line_item.cadence",
                label: "Pricing Cadence",
                type: "select",
                options: Object.entries(ContractLineItemPriceCadenceLabels).map(
                  ([key, label]) => ({
                    label,
                    value: key,
                  })
                ),
                defaultValue: pricingCadence,
                errors: actionData?.errors?.cadence ?? [],
              }}
              onChange={(e: any) => setPricingCadence(e.target.value)}
            />
            <CrudSelectField
              field={{
                name: "contract_line_item.pricing_type",
                label: "Pricing Type",
                type: "select",
                options: pricingTypeOptions,
                defaultValue: pricingType,
                errors: actionData?.errors?.pricing_type ?? [],
              }}
              onChange={(e: any) => setPricingType(e.target.value)}
            />
            {pricingType === ContractPricingType.PerSeat && (
              <div className="col-span-full">
                <CrudTextField
                  field={{
                    name: "contract_line_item.seats_number",
                    label: "Number of Seats Purchased",
                    type: "number",
                    defaultValue: !isNil(actionData?.fields?.seats_number)
                      ? actionData?.fields?.seats_number
                      : contractLineItem.seats_number ?? 0,
                    errors: actionData?.errors?.seats_number ?? [],
                  }}
                />
              </div>
            )}
            <div className="col-span-full">
              {!singleItem && (
                <>
                  <div>
                    <div className="md:grid grid-cols-3 flex items-center gap-x-3 ">
                      <div></div>
                      <div className="text-sm font-medium">Price</div>
                      <div className="flex items-center space-x-2">
                        <div className="text-sm font-medium">Department</div>
                        <Tooltip text="By assigning this product to a department, you’ll be able to view spend by department on the dashboard reports.">
                          <div className="flex flex-row items-center cursor-pointer">
                            <InformationCircleIcon className="h-5 text-gray-400" />
                          </div>
                        </Tooltip>
                      </div>
                    </div>
                    {contractLineItem.contract_line_item_products.map(
                      (product, j) => (
                        <ProductRow
                          key={j}
                          product={product.product}
                          contractLineItemId={contractLineItem.id}
                          contractLineItemProduct={product}
                          index={j}
                          handleCallback={handleProductPriceChange}
                          contractLineItemProducts={
                            contractLineItem.contract_line_item_products
                          }
                          actionUrl={`/intelligence/${account.id}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/set-price`}
                        ></ProductRow>
                      )
                    )}
                    {contractLineItem.contract_line_item_fees.map((fee, j) => (
                      <FeeRow
                        key={j}
                        contractLineItemId={contractLineItem.id}
                        contractLineItemFee={fee}
                        index={j}
                        handleCallback={handleFeePriceChange}
                        actionUrl={`/intelligence/${account.id}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/set-price`}
                      ></FeeRow>
                    ))}
                    <div className="flex justify-end my-3">
                      <div></div>
                      <div className="font-light flex gap-x-1">
                        Total:
                        <div className="font-semibold">
                          ${totalProductPrice}
                        </div>
                      </div>
                      <div></div>
                    </div>
                  </div>
                  <input
                    type="hidden"
                    name="contract_line_item.price"
                    value={totalProductPrice}
                  />
                </>
              )}
              {singleItem && pricingType !== ContractPricingType.Itemized && (
                <div>
                  <CurrencyField
                    name="contract_line_item.price"
                    label="Price"
                    defaultValue={contractLineItem.price ?? 0}
                    errors={actionData?.errors?.price ?? []}
                    onChange={e =>
                      setLineItem({
                        ...lineItem,
                        price: Number(e.target.value.replace(/[$,]/g, "")),
                      })
                    }
                  />
                </div>
              )}
              {singleItem && pricingType === ContractPricingType.Itemized && (
                <div className="my-5">
                  <ContractLineItemItemsManager
                    items={
                      contractLineItem.contract_line_item_items as ContractLineItemItem[]
                    }
                    actionErrors={actionData?.errors ?? {}}
                    onPriceChange={handleOnPriceChange}
                  />
                </div>
              )}
            </div>
            {pricingType === ContractPricingType.UsageBased && (
              <div className="col-span-full">
                <CurrencyField
                  name={`contract_line_item.estimated_cost`}
                  label={`Estimated Total ${pricingCadence} Cost*`}
                  defaultValue={contractLineItem.estimated_cost ?? 0}
                  errors={actionData?.errors?.estimated_cost ?? []}
                />
              </div>
            )}
            {pricingType === ContractPricingType.PerLease && (
              <div className="col-span-full">
                <CurrencyField
                  name={`contract_line_item.estimated_cost`}
                  label={`Estimated Total ${pricingCadence} Cost Per Location*`}
                  defaultValue={contractLineItem.estimated_cost ?? 0}
                  errors={actionData?.errors?.estimated_cost ?? []}
                />
              </div>
            )}
            <CurrencyField
              name={`contract_line_item.setup_fee`}
              label={
                <div className="text-sm font-medium text-gray-900 mb-2">
                  One-Time Setup Fees{" "}
                  <span className="font-light text-gray-400">(Optional)</span>{" "}
                </div>
              }
              defaultValue={contractLineItem.setup_fee ?? 0}
              errors={actionData?.errors?.setup_fee ?? []}
            />
            <CurrencyField
              name={`contract_line_item.discount`}
              label={
                <div className="text-sm font-medium text-gray-900 mb-2">
                  Discount Value{" "}
                  <span className="font-light text-gray-400">(Optional)</span>{" "}
                </div>
              }
              defaultValue={lineItem.discount ?? 0}
              errors={actionData?.errors?.discount ?? []}
            />
            <PercentField
              name="contract_line_item.price_increase_percent"
              label={
                <div className="text-sm font-medium text-gray-900 mb-2">
                  Contracted Price Increase Percentage{" "}
                  <span className="font-light text-gray-400">(Optional)</span>{" "}
                </div>
              }
              defaultValue={
                !isNil(actionData?.fields?.price_increase_percent)
                  ? (actionData?.fields?.price_increase_percent as number)
                  : contractLineItem.price_increase_percent ?? 0
              }
              errors={actionData?.errors?.price_increase_percent ?? []}
            />
            <CrudSelectField
              field={{
                name: "contract_line_item.price_increase_cadence",
                type: "select",
                options: priceIncreaseOptions,
                errors: actionData?.errors?.price_increase_cadence ?? [],
                label: (
                  <div className="text-sm font-medium text-gray-900 mb-2">
                    Contracted Price Increase Cadence{" "}
                    <span className="font-light text-gray-400">(Optional)</span>{" "}
                  </div>
                ),
                allowNull: true,
                defaultValue:
                  (actionData?.fields?.price_increase_cadence as string) ??
                  contractLineItem.price_increase_cadence,
              }}
            />
            <div className="col-span-full h-full mb-8">
              <div className="text-sm font-medium text-gray-900 mb-2">
                Notes{" "}
                <span className="font-light text-gray-400">(Optional)</span>{" "}
              </div>
              <Editor
                onChange={e => setNotes(e.html)}
                placeholder=""
                value={notes}
                className="h-24"
                errors={actionData?.errors?.notes ?? []}
                toolBarOptions={{
                  toolbar: [["bold", "italic", "underline"], ["clean"]],
                }}
              />
              <input type="hidden" name="notes" value={notes} />
            </div>
          </div>
        </FormSection>
      </div>
      <div className="mt-10 flex justify-around md:justify-between md:flex-nowrap flex-wrap-reverse gap-3">
        <Link
          to={`/intelligence/${account.id}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}`}
          className="text-sky-500 flex items-center"
        >
          <ArrowLeftIcon className="h-5 mr-2" /> Back to selecting products
        </Link>
        <div className="flex gap-x-3 items-center">
          <div className="col-span-full flex justify-end">
            {confirmDeleteOpen ? (
              <Form
                className="flex justify-between  items-center"
                method="post"
              >
                Are you sure you want to delete this line item?
                <input type="hidden" name="intent" value="delete" />
                <Button
                  onClick={() => setConfirmDeleteOpen(false)}
                  className="ml-2 rounded-full"
                >
                  Cancel
                </Button>
                <DangerButton type="submit" className="ml-2 rounded-full">
                  Yep!
                </DangerButton>
              </Form>
            ) : (
              <button
                onClick={() => {
                  setConfirmDeleteOpen(!confirmDeleteOpen);
                }}
                className="text-sky-500"
                id="delete-contract-button"
              >
                <div className="flex">
                  <TrashIcon className="h-5 mr-1" />
                  Discard line item
                </div>
              </button>
            )}
          </div>
          {!confirmDeleteOpen && (
            <CTA type="submit" id="save-button">
              {navigation.state === "submitting"
                ? "Submitting..."
                : "Save Line Item"}
            </CTA>
          )}
        </div>
      </div>
    </div>
  );
}
