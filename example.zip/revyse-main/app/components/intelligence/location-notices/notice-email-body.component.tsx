import { ListBulletIcon, PaperClipIcon } from "@heroicons/react/24/outline";
import type { File as PrismaFile } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { useState } from "react";
import { CTA } from "~/components/cta.component";
import FileUploadZone from "~/components/file-upload-zone.component";
import { Modal } from "~/components/modal.component";
import { Editor } from "~/components/reactquill/richtext-editor.component";
import { MB } from "~/utils/constants.utils";

const MAX_BYTE_LIMIT = 60 * MB;

export function NoticeEmailBody({
  defaultBody,
  defaultAttachments,
  alreadyUploadedFiles,
  onRemoveAlreadyUploadedFile,
  onChange,
}: {
  defaultBody?: string;
  defaultAttachments?: File[];
  alreadyUploadedFiles?: SerializeFrom<PrismaFile>[];
  onRemoveAlreadyUploadedFile?: (id: string) => void;
  onChange?: (body: string, attachments: File[]) => void;
}) {
  const [body, setBody] = useState(defaultBody || "");

  const [attachmentsModalOpen, setAttachmentsModalOpen] = useState(false);

  const handleBodyChange = (e: { html: string }) => {
    setBody(e.html);
    onChange?.(e.html, defaultAttachments ?? []);
  };

  return (
    <>
      <Modal
        isOpen={attachmentsModalOpen}
        onClose={() => setAttachmentsModalOpen(false)}
        manager={true}
      >
        <div className="flex flex-col gap-y-3">
          <h3>Email Attachments</h3>
          <FileUploadZone
            onFileChange={files => onChange?.(body, files ?? [])}
            multiple={true}
            errors={[]}
            maxFileSize={MAX_BYTE_LIMIT}
            showPreviews={true}
            name="attachments"
            defaultFiles={defaultAttachments}
            alreadyUploadedFiles={alreadyUploadedFiles}
            onRemoveAlreadyUploadedFile={onRemoveAlreadyUploadedFile}
          ></FileUploadZone>
          <div className="mt-5 w-full flex justify-end">
            <CTA onClick={() => setAttachmentsModalOpen(false)}>Done</CTA>
          </div>
        </div>
      </Modal>
      <Editor
        onChange={handleBodyChange}
        placeholder="Type here"
        value={body}
        className="h-auto"
        errors={[]}
        toolBarOptions={{
          toolbar: "#editor-toolbar",
        }}
      />
      <div className="ql-toolbar ql-snow" id="editor-toolbar">
        <div className="ql-formats">
          <button className="ql-bold" aria-label="Bold" type="button"></button>
          <button
            className="ql-italic"
            aria-label="Italic"
            type="button"
          ></button>
          <button
            className="ql-strike"
            aria-label="Strike"
            type="button"
          ></button>
          <button className="ql-link" aria-label="Link" type="button"></button>
          <button className="ql-list" aria-label="List" type="button">
            <ListBulletIcon className="h-5" />
          </button>
          <button
            className="ql-attachment"
            aria-label="Attachment"
            type="button"
            onClick={() => setAttachmentsModalOpen(true)}
          >
            <PaperClipIcon className="h-5" />
          </button>
        </div>
      </div>
    </>
  );
}
