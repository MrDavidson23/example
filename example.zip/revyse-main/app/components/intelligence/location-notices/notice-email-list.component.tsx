import { XMarkIcon } from "@heroicons/react/24/outline";
import React from "react";
import { z } from "zod";
import { tvField } from "~/utils/global-tailwind-variants.utils";

export function NoticeEmailList({
  name,
  initialEmails,
  onChange,
}: {
  name?: string;
  initialEmails?: string[];
  onChange?: (emails: string[]) => void;
}) {
  const [emails, setEmails] = React.useState(initialEmails ?? []);

  const handleAddEmail = (email: string) => {
    if (!email) return;
    if (z.string().email().safeParse(email).success === false) {
      setInvalidEmailError(true);
      return false;
    }
    setInvalidEmailError(false);
    setEmails(emails => [...emails, email]);
    onChange?.([...emails, email]);
    return true;
  };

  const handleRemoveEmail = (email: string) => {
    setEmails(emails => emails.filter(e => e !== email));
    onChange?.(emails.filter(e => e !== email));
  };

  const [invalidEmailError, setInvalidEmailError] =
    React.useState<boolean>(false);

  return (
    <div className="w-full flex gap-x-2 gap-y-2 flex-wrap items-center">
      {emails.map(email => (
        <div
          key={email}
          className="py-1 px-2 flex flex-row items-center gap-x-2 rounded-lg border border-sky-400 bg-sky-50"
        >
          <span>{email}</span>
          <button
            className="text-sky-500"
            onClick={() => handleRemoveEmail(email)}
          >
            <XMarkIcon className="h-4" />
          </button>
        </div>
      ))}
      <input
        type="email"
        name="email"
        id="email"
        className={tvField({
          className: "py-1 px-2 w-72 text-sm shadow-none",
          error: invalidEmailError,
        })}
        onKeyDown={e => {
          if (e.key === "Enter") {
            e.preventDefault();
            if (handleAddEmail(e.currentTarget.value)) {
              e.currentTarget.value = "";
            }
          } else {
            setInvalidEmailError(false);
          }
        }}
      />
      {invalidEmailError && (
        <span className="text-red-500 text-sm">Invalid email</span>
      )}
      {name && <input type="hidden" name={name} value={emails.join(",")} />}
    </div>
  );
}
