import type {
  LocationNoticeDisposition,
  LocationNoticeDispositionRecipient,
  ManagerAccountRole,
  User,
} from "@prisma/client";
import { LocationNoticeStatus } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { Banner } from "../banner.component";
import { useMemo } from "react";
import { HandThumbUpIcon } from "@heroicons/react/24/outline";
import {
  ArrowRightIcon,
  ExclamationTriangleIcon,
} from "@heroicons/react/20/solid";
import dayjs from "dayjs";

export function LocationNoticeDispositionBanner({
  locationNoticeDisposition,
  completeLocationNoticeDispositionLink,
  resendNoticeLink,
}: {
  locationNoticeDisposition: SerializeFrom<
    LocationNoticeDisposition & {
      manager_account_role: ManagerAccountRole & {
        user: User;
      };
      location_notice_recipients: LocationNoticeDispositionRecipient[];
    }
  >;
  completeLocationNoticeDispositionLink?: string;
  resendNoticeLink?: string;
}) {
  const isUpdatedDispositionNotice = useMemo(() => {
    return locationNoticeDisposition.original_location_notice_id !== null;
  }, [locationNoticeDisposition]);

  return (
    <>
      {locationNoticeDisposition.status === LocationNoticeStatus.Sent ? (
        <Banner
          color="green"
          title={
            isUpdatedDispositionNotice
              ? "Your updated disposition notice was sent."
              : "Your disposition notice was sent."
          }
          description={
            <>
              This notice was sent by{" "}
              {locationNoticeDisposition.manager_account_role.user.first_name}{" "}
              {locationNoticeDisposition.manager_account_role.user.last_name} on{" "}
              {dayjs
                .utc(locationNoticeDisposition.status_updated_at)
                .format("MMM, DD, YYYY")}{" "}
              to {locationNoticeDisposition.location_notice_recipients.length}{" "}
              vendors. The expected disposition date is{" "}
              <b className="font-semibold">
                {dayjs
                  .utc(locationNoticeDisposition.disposition_date)
                  .format("MMM, DD, YYYY")}
              </b>
              .
            </>
          }
          icon={<HandThumbUpIcon className="w-full h-full text-gray-900" />}
          actions={{
            secondary: resendNoticeLink
              ? {
                  children: (
                    <>
                      Resend Notice
                      <ArrowRightIcon className="h-5 w-5 ml-1.5" />
                    </>
                  ),
                  color: "transparent",
                  to: resendNoticeLink,
                }
              : undefined,
          }}
        />
      ) : (
        <Banner
          color="amber"
          title="This notice has not been sent yet."
          description={`This notice was saved by ${
            locationNoticeDisposition.manager_account_role.user.first_name
          } ${
            locationNoticeDisposition.manager_account_role.user.last_name
          } on ${dayjs
            .utc(locationNoticeDisposition.status_updated_at)
            .format("MMM, DD, YYYY")}.`}
          icon={<ExclamationTriangleIcon className="h-full w-full" />}
          actions={{
            secondary: completeLocationNoticeDispositionLink
              ? {
                  children: (
                    <>
                      Complete Notice Now
                      <ArrowRightIcon className="h-5 w-5 ml-1.5" />
                    </>
                  ),
                  color: "transparent",
                  to: completeLocationNoticeDispositionLink,
                }
              : undefined,
          }}
        />
      )}
    </>
  );
}
