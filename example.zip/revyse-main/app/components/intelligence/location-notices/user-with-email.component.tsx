export function UserWithEmail({
  email,
  name,
}: {
  email: string;
  name?: string;
}) {
  return (
    <div className="flex items-center">
      {name && <div className="mr-3">{name}</div>}
      <div className="flex-shrink-0 rounded-full bg-sky-100/70 text-gray-900 px-3 py-1">
        <span className="text-sm">{email}</span>
      </div>
    </div>
  );
}
