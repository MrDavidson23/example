import { type ManagerAccount, type Location } from "@prisma/client";
import { useMemo } from "react";
import { NoticeEmailList } from "./notice-email-list.component";
import {
  type LocationNotice,
  getLocationNoticeEmailDefaultBody,
  LocationNoticeType,
} from "~/utils/location-notice.utils";
import type { SerializeFrom } from "@remix-run/node";
import { tvField } from "~/utils/global-tailwind-variants.utils";
import { NoticeEmailBody } from "./notice-email-body.component";

export function EmailDraftComponent({
  location,
  locationNotice,
  account,
  formErrors,
  uploadedAttachmentsToRemove,
  onAttachmentsChange,
  onRemoveAttachments,
  onBodyChange,
}: {
  location: SerializeFrom<Location>;
  locationNotice: SerializeFrom<LocationNotice>;
  account: SerializeFrom<ManagerAccount>;
  formErrors: Record<string, string[] | null>;
  uploadedAttachmentsToRemove: string[];
  onAttachmentsChange: (files: File[]) => void | undefined;
  onRemoveAttachments: (files: string[]) => void | undefined;
  onBodyChange: (body: string) => void | undefined;
}) {
  const alreadyUploadedAttachments = useMemo(() => {
    return locationNotice.email_attachments?.filter(
      attachment => !uploadedAttachmentsToRemove.includes(attachment.id)
    );
  }, [locationNotice.email_attachments, uploadedAttachmentsToRemove]);

  const isUpdatedLocationNotice = useMemo(() => {
    return locationNotice.original_location_notice_id !== null;
  }, [locationNotice]);

  const handleEmailBodyChange = (body: string, attachments: File[]) => {
    onBodyChange(body);
    onAttachmentsChange(attachments);
  };

  const getDefaultSubject = () => {
    if (locationNotice.type === LocationNoticeType.LocationNoticeDisposition) {
      return isUpdatedLocationNotice
        ? `Update: Change to Disposition Instructions for ${location.name} - ${account.name}`
        : `Important Notice of Upcoming Disposition - ${account.name}, ${location.name}`;
    } else if (
      locationNotice.type === LocationNoticeType.LocationServiceTermination
    ) {
      return isUpdatedLocationNotice
        ? `Update: Change to Service Termination Request for ${location.name} - ${account.name}`
        : `Important Notice: Service Termination Request - ${account.name}, ${location.name}`;
    }
    return "";
  };

  return (
    <>
      <main className="bg-white shadow-lg shadow-gray-200/50 p-6 rounded-lg h-min gap-y-40">
        <section className="rounded-lg border border-gray-300 divide-y divide-gray-300">
          <article className="p-4">
            To:
            <span className="ml-3">
              {locationNotice.type ===
              LocationNoticeType.LocationNoticeDisposition
                ? `${locationNotice.location_notice_recipients?.length} vendors`
                : `${locationNotice.contact_email}`}
            </span>
          </article>
          <article className="p-4">
            From:
            <span className="ml-3">
              {locationNotice.task_owner?.user.first_name}{" "}
              {locationNotice.task_owner?.user.last_name}
            </span>
          </article>
          <article className="p-4 flex items-center gap-x-3">
            CC:
            <NoticeEmailList
              name="cc_emails"
              initialEmails={locationNotice.email_cc_emails}
            />
          </article>
          <article className="p-4 flex items-center gap-x-2">
            Subject:{" "}
            <textarea
              rows={1}
              name="subject"
              className={tvField({
                className: "shadow-none border-none ring-0 px-1",
                error: !!formErrors.subject?.length,
              })}
              defaultValue={getDefaultSubject()}
            ></textarea>
          </article>
          <article className="px-0 pt-4">
            <NoticeEmailBody
              onChange={handleEmailBodyChange}
              defaultBody={
                locationNotice.email_body ??
                getLocationNoticeEmailDefaultBody(
                  locationNotice,
                  location,
                  account
                )
              }
              alreadyUploadedFiles={alreadyUploadedAttachments}
              onRemoveAlreadyUploadedFile={id => {
                onRemoveAttachments([...uploadedAttachmentsToRemove, id]);
              }}
            />
          </article>
        </section>
      </main>
    </>
  );
}
