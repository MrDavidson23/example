import type {
  LocationServiceTerminationNotice,
  ManagerAccountRole,
  ManagerAccountVendor,
  User,
  Vendor,
} from "@prisma/client";
import { LocationNoticeStatus } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { Banner } from "../banner.component";
import { useMemo } from "react";
import { HandThumbUpIcon } from "@heroicons/react/24/outline";
import {
  ArrowRightIcon,
  ExclamationTriangleIcon,
} from "@heroicons/react/20/solid";
import dayjs from "dayjs";

export function LocationNoticeServiceTerminationBanner({
  locationNoticeServiceTermination,
  completeLocationNoticeServiceTerminationLink,
  resendNoticeLink,
}: {
  locationNoticeServiceTermination: SerializeFrom<
    LocationServiceTerminationNotice & {
      manager_account_role: ManagerAccountRole & {
        user: User;
      };
      manager_account_vendor: ManagerAccountVendor & {
        vendor: Vendor;
      };
    }
  >;
  completeLocationNoticeServiceTerminationLink?: string;
  resendNoticeLink?: string;
}) {
  const isUpdatedServiceTerminationNotice = useMemo(() => {
    return (
      locationNoticeServiceTermination.original_location_notice_id !== null
    );
  }, [locationNoticeServiceTermination]);

  return (
    <>
      {locationNoticeServiceTermination.status === LocationNoticeStatus.Sent ? (
        <Banner
          color="green"
          title={
            isUpdatedServiceTerminationNotice
              ? "Your updated service termination notice was sent."
              : "Your service termination notice was sent."
          }
          description={
            <>
              This notice was sent by{" "}
              {
                locationNoticeServiceTermination.manager_account_role.user
                  .first_name
              }{" "}
              {
                locationNoticeServiceTermination.manager_account_role.user
                  .last_name
              }{" "}
              on{" "}
              {dayjs
                .utc(locationNoticeServiceTermination.status_updated_at)
                .format("MMM DD, YYYY")}
              . The requested service termination date is{" "}
              <b className="font-semibold">
                {dayjs
                  .utc(locationNoticeServiceTermination.termination_date)
                  .format("MMM DD, YYYY")}
              </b>
              .
            </>
          }
          icon={<HandThumbUpIcon className="w-full h-full text-gray-900" />}
          actions={{
            secondary: resendNoticeLink
              ? {
                  children: (
                    <>
                      Resend Notice
                      <ArrowRightIcon className="h-5 w-5 ml-1.5" />
                    </>
                  ),
                  color: "transparent",
                  to: resendNoticeLink,
                }
              : undefined,
          }}
        />
      ) : (
        <Banner
          color="amber"
          title="This notice has not been sent yet."
          description={`This notice was started by ${
            locationNoticeServiceTermination.manager_account_role.user
              .first_name
          } ${
            locationNoticeServiceTermination.manager_account_role.user.last_name
          } on ${dayjs
            .utc(locationNoticeServiceTermination.status_updated_at)
            .format("MMM, DD, YYYY")}.`}
          icon={<ExclamationTriangleIcon className="h-full w-full" />}
          actions={{
            secondary: completeLocationNoticeServiceTerminationLink
              ? {
                  children: (
                    <>
                      Complete Notice Now
                      <ArrowRightIcon className="h-5 w-5 ml-1.5" />
                    </>
                  ),
                  color: "transparent",
                  to: completeLocationNoticeServiceTerminationLink,
                }
              : undefined,
          }}
        />
      )}
    </>
  );
}
