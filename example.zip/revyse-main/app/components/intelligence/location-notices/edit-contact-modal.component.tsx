import { useFetcher } from "@remix-run/react";
import React, { useMemo } from "react";
import { CrudTextField } from "~/components/form/crud-form.component";
import { WizardModal } from "~/components/modals/wizard-modal.component";

export function EditContactModal({
  open,
  onClose,
  contract,
  vendorName,
  managerAccountVendorId,
}: {
  open: boolean;
  onClose: () => void;
  contract: {
    name: string | null;
    email: string | null;
  };
  vendorName: string;
  managerAccountVendorId: string;
}) {
  const fetcher = useFetcher<{
    success: boolean;
    errors: Record<string, string[]>;
  }>();

  const errors = useMemo(() => fetcher.data?.errors || {}, [fetcher.data]);

  return (
    <WizardModal
      isOpen={open}
      onClose={onClose}
      extraFormDataOnSubmit={{
        managerAccountVendorId,
        intent: "update-contact",
      }}
      fetcher={fetcher}
      steps={[
        {
          id: "edit-contact",
          title: `Edit contact information for ${vendorName}`,
          body: (
            <>
              <CrudTextField
                field={{
                  label: "Cancellation Notice Contact Name",
                  type: "text",
                  name: "name",
                  defaultValue: contract.name || "",
                  errors: errors.name || [],
                  placeholder: "Jane Doe",
                }}
              />
              <CrudTextField
                field={{
                  label: "Cancellation Notice Contact Email",
                  type: "text",
                  name: "email",
                  defaultValue: contract.email || "",
                  errors: errors.email || [],
                  placeholder: "jane@doe.com",
                }}
              />
            </>
          ),
          ctas: {
            primary: {
              label: "Save",
              submit: true,
            },
            secondary: {
              label: "Return to select recipients",
            },
          },
        },
      ]}
    />
  );
}
