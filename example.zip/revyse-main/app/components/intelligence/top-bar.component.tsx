import { XMarkIcon } from "@heroicons/react/24/outline";
import { Link, useNavigate } from "@remix-run/react";
import { useMemo, useState } from "react";
import { Dialog } from "@headlessui/react";
import { Avatar } from "../avatar.component";
import { type SerializeFrom } from "@remix-run/node";
import type { Location, ManagerAccount, User, UserRole } from "@prisma/client";
import type { IntelligenceModuleLink } from "~/routes/intelligence.$id";
import NotificationsWidget from "./notifications/notifications-widget.component";
import { NotificationBell } from "../icons/notification-bell.icon";
import { ModuleNavLink } from "./module-nav-link.component";
import { TopBarAccounts } from "./top-bar-accounts";
import { EntitiesSelector } from "./entities-selector";
import { ChevronDownIcon } from "@heroicons/react/20/solid";

export function TopBar({
  user,
  activeManagerAccount,
  managerAccountOptions,
  links,
  locationOptions,
  activeEntityId,
  setActiveEntityId,
  showEntitiesSelector,
}: {
  user: SerializeFrom<User & { user_roles: SerializeFrom<UserRole>[] }>;
  activeManagerAccount: SerializeFrom<ManagerAccount>;
  managerAccountOptions: SerializeFrom<ManagerAccount>[];
  links: IntelligenceModuleLink[];
  locationOptions: SerializeFrom<Location>[];
  activeEntityId: string;
  setActiveEntityId: (id: string, isLocation: boolean) => void;
  showEntitiesSelector: boolean;
}) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const navigate = useNavigate();

  const activeEntityName = useMemo(
    () =>
      activeEntityId === activeManagerAccount.id
        ? activeManagerAccount.name
        : locationOptions.find(location => location.id === activeEntityId)
            ?.name,
    [activeEntityId, activeManagerAccount, locationOptions]
  );

  return (
    <nav className="fixed top-0 z-50 w-full bg-white border-b border-gray-100">
      <div className="px-3 py-5 lg:px-5 lg:pl-3 flex flex-row items-center h-20">
        <div className="flex items-center w-full 2xl:mx-12 md:mx-4 justify-between">
          <Link to="/" className="-m-1.5 p-1.5 flex items-center">
            <span className="sr-only">Revyse</span>
            <img
              className="lg:h-8 h-6 w-auto"
              src="/assets/revyse-logo-color-black.png"
              alt=""
              width="320"
              height="112"
            />
            <span className="sm:block text-white bg-coral flex items-center px-1 lg:px-2 font-light text-sm lg:text-lg mx-0 lg:mx-2">
              intelligence
            </span>
          </Link>
          <div className="flex flex-row justify-end items-center space-x-5">
            {showEntitiesSelector && (
              <div className="hidden md:block ">
                <EntitiesSelector
                  account={activeManagerAccount}
                  locations={locationOptions}
                  activeOptionId={activeEntityId}
                  setActiveOption={setActiveEntityId}
                >
                  <div className="flex flex-col items-start gap-y-0.5">
                    <div className="text-xs text-gray-400">Managing</div>
                    <div className="flex items-center gap-x-2">
                      {activeEntityName}
                      <ChevronDownIcon className="h-5 w-5" />
                    </div>
                  </div>
                </EntitiesSelector>
              </div>
            )}
            <NotificationsWidget managerAccountId={activeManagerAccount.id}>
              <button
                type="button"
                className="p-2 text-gray-500 rounded-lg hover:bg-gray-100 focus:outline-none"
              >
                <NotificationBell className="h-7 w-7" />
              </button>
            </NotificationsWidget>
            <TopBarAccounts
              accounts={managerAccountOptions}
              activeAccountId={activeManagerAccount.id}
              setActiveAccount={id => navigate(`/intelligence/${id}`)}
            >
              <Avatar
                first_name={user?.first_name}
                last_name={user?.last_name}
                img_url={`${
                  activeManagerAccount?.avatar_id
                    ? `/images/${activeManagerAccount?.avatar_id}`
                    : "/assets/defaultAvatar.png"
                }`}
                className="cursor-pointer"
              />
            </TopBarAccounts>
            <button
              onClick={() => setMobileMenuOpen(true)}
              data-drawer-target="logo-sidebar"
              data-drawer-toggle="logo-sidebar"
              aria-controls="logo-sidebar"
              type="button"
              className="inline-flex items-center p-2 text-sm text-gray-500 rounded-lg lg:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200"
            >
              <span className="sr-only">Open sidebar</span>
              {!mobileMenuOpen ? (
                <svg
                  className="w-6 h-6 text-gray-800"
                  aria-hidden="true"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                  xmlns="http://www.w3.org/2000/svg"
                >
                  <path
                    clipRule="evenodd"
                    fillRule="evenodd"
                    d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"
                  ></path>
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="w-6 h-6 text-gray-800"
                  viewBox="0 0 20 20"
                  fill="currentColor"
                >
                  <path
                    fillRule="evenodd"
                    d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z"
                    clipRule="evenodd"
                  />
                </svg>
              )}
            </button>
          </div>
          <Dialog
            as="div"
            className="lg:hidden"
            open={mobileMenuOpen}
            onClose={setMobileMenuOpen}
          >
            <div className="fixed inset-0 z-40" />
            <Dialog.Panel className="fixed inset-y-0 right-0 z-40 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-gray-900/10">
              <div className="flex items-center justify-between">
                {/* eslint-disable-next-line jsx-a11y/anchor-is-valid */}
                <a href="#" className="-m-1.5 p-1.5">
                  <span className="sr-only">Revyse Manager</span>
                  <img
                    className="h-8 w-auto"
                    src="assets/Revyse-Logo-Black.png"
                    alt=""
                    width="300"
                    height="105"
                  />
                </a>
                <button
                  type="button"
                  className="-m-2.5 rounded-md p-2.5 text-gray-700"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  <span className="sr-only">Close menu</span>
                  <XMarkIcon className="h-6 w-6" aria-hidden="true" />
                </button>
              </div>
              <div className="mt-12 flow-root">
                <div className="-my-6 divide-y divide-gray-500/10">
                  {showEntitiesSelector && (
                    <div className="md:hidden p-3">
                      <EntitiesSelector
                        account={activeManagerAccount}
                        locations={locationOptions}
                        activeOptionId={activeEntityId}
                        setActiveOption={setActiveEntityId}
                      >
                        <div className="flex flex-col items-start gap-y-0.5">
                          <div className="text-xs text-gray-400">Managing</div>
                          <div className="flex items-center gap-x-2">
                            {activeEntityName}
                            <ChevronDownIcon className="h-5 w-5" />
                          </div>
                        </div>
                      </EntitiesSelector>
                    </div>
                  )}
                  <div className="space-y-2 py-6">
                    {links.map((link, i) => (
                      <ModuleNavLink
                        key={link.id}
                        link={link}
                        onClick={() => setMobileMenuOpen(false)}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </Dialog.Panel>
          </Dialog>
        </div>
      </div>
    </nav>
  );
}
