import {
  ArrowRightIcon,
  BriefcaseIcon,
  ShoppingBagIcon,
} from "@heroicons/react/24/outline";
import type { ResidentLifecyclePhase } from "@prisma/client";
import { Link } from "@remix-run/react";
import type { ReactNode } from "react";
import { Card } from "~/components/card.component";
import { IconCircle } from "~/components/circle-icon.component";
import { money } from "~/utils/number.utils";

export function ResidentLifecycleCard({
  children,
  phase,
  annualSpend,
  totalProducts,
  renderViewLink,
  account_id,
}: {
  children?: ReactNode;
  phase: ResidentLifecyclePhase;
  annualSpend: number;
  totalProducts: number;
  renderViewLink: boolean;
  account_id: string;
}) {
  const title = phase.replace("Move", "Move ");
  return (
    <Card className="p-0 relative">
      <div className="text-center font-semibold bg-sky-50 py-6 border-b border-sky-500">
        {title}
      </div>
      <div className="p-5 flex flex-col gap-5">
        <div className="flex gap-4 items-center">
          <IconCircle Icon={BriefcaseIcon} color="gray" size="6" />

          <div>
            <div>Annual Spend</div>
            <div className="font-semibold">{money(annualSpend)}</div>
          </div>
        </div>
        <div className="flex gap-4 items-center">
          <IconCircle Icon={ShoppingBagIcon} color="gray" size="6" />
          <div>
            <div>Total Products</div>
            <div className="font-semibold">{totalProducts}</div>
          </div>
        </div>
        {renderViewLink && (
          <div>
            <Link
              to={`/intelligence/${account_id}/spend-by-resident-phase?phase=${phase}`}
              className="text-sky-600 flex gap-1 items-center text-sm"
            >
              View {title.toLowerCase()} insights{" "}
              <ArrowRightIcon className="h-4"></ArrowRightIcon>
            </Link>
          </div>
        )}
      </div>
      {children}
    </Card>
  );
}
