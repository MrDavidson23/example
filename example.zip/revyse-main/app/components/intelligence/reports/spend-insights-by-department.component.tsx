import { ResponsivePie } from "@nivo/pie";
import useIsMobile from "~/hooks/useIsMobile.hook";
import { money } from "~/utils/number.utils";

export function SpendInsightsByDepartment({
  data,
}: {
  data: { id: string; label: string; value: number; color?: string }[];
}) {
  const isMobile = useIsMobile();

  const colors = [
    "hsl(171, 70%, 50%)",
    "#FADA5E",
    "#83E99F",
    "#FEA959",
    "#FF6959",
    "#37A2E8",
    "#E837A2",
    "#FE6A88",
    "#A2E8E6",
    "#E8A2E8",
    "#E8A2A2",
  ];

  // sort the data by value
  const sortedData = data.sort((a, b) => b.value - a.value);

  // show only the first 10 departments and the rest will be grouped into "Others"
  const dataToShow = sortedData.slice(0, 10);

  dataToShow.sort((a, b) => b.value - a.value);

  if (data.length > 10) {
    const otherDepartments = sortedData.slice(10);
    const otherValue = otherDepartments.reduce((acc, d) => acc + d.value, 0);
    dataToShow.push({
      id: "Others",
      label: "Others",
      value: otherValue,
    });
  }

  return (
    <div className="h-64 md:h-96">
      <ResponsivePie
        data={dataToShow}
        colors={colors}
        valueFormat={money}
        margin={{ top: 20, right: 80, bottom: 20, left: 80 }}
        innerRadius={0.5}
        padAngle={0.7}
        cornerRadius={3}
        activeOuterRadiusOffset={8}
        borderWidth={1}
        borderColor={{
          from: "color",
          modifiers: [["darker", 0.2]],
        }}
        arcLinkLabelsSkipAngle={10}
        arcLinkLabelsTextColor="#333333"
        arcLinkLabelsThickness={2}
        arcLinkLabelsColor={{ from: "color" }}
        arcLabelsSkipAngle={10}
        arcLabelsTextColor={{
          from: "color",
          modifiers: [["darker", 2]],
        }}
        theme={{
          legends: {
            text: {
              fontSize: 14,
              fontFamily: '"Montserrat", "Lato"',
            },
          },
        }}
        legends={
          !isMobile
            ? [
                {
                  anchor: "left",
                  direction: "column",
                  justify: false,
                  translateX: -40,
                  translateY: 0,
                  itemsSpacing: 5,
                  itemWidth: 100,
                  itemHeight: 28,
                  itemTextColor: "#999",
                  itemDirection: "left-to-right",
                  itemOpacity: 1,
                  symbolSize: 20,
                  symbolShape: "circle",
                  effects: [
                    {
                      on: "hover",
                      style: {
                        itemTextColor: "#000",
                      },
                    },
                  ],
                },
              ]
            : []
        }
      />
    </div>
  );
}
