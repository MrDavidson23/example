import {
  ArrowRightIcon,
  BriefcaseIcon,
  BuildingStorefrontIcon,
  DocumentTextIcon,
  ShoppingBagIcon,
} from "@heroicons/react/24/outline";
import { Link, useNavigate } from "@remix-run/react";
import { isEmpty } from "lodash";
import { Card } from "~/components/card.component";
import { IconCircle } from "~/components/circle-icon.component";
import { money } from "~/utils/number.utils";

export function DepartmentCard({
  name,
  accountId,
  description,
  annualSpend,
  contractLineItemsCount,
  contractCount,
  vendorsCount,
  account,
}: {
  name: string;
  accountId: string;
  description: string;
  annualSpend: number;
  contractLineItemsCount: number;
  contractCount: number;
  vendorsCount: number;
  account: { id: string };
}) {
  const navigate = useNavigate();
  const nameToDisplay = isEmpty(name) ? "Uncategorized" : name;
  return (
    <div
      className="cursor-pointer"
      onClick={() => {
        navigate(
          `/intelligence/${accountId}/spend-by-department/${nameToDisplay}`
        );
      }}
    >
      <Card className="py-6 px-8">
        <h3 className="font-semibold">{nameToDisplay}</h3>
        <p className="mt-1">{description}</p>
        <div className="grid grid-cols-2 gap-8 mt-6">
          <div className="flex gap-2 items-center">
            <IconCircle
              Icon={BriefcaseIcon}
              color="yellow"
              size="8"
            ></IconCircle>
            <div>
              <div className="text-gray-500">Annual Value</div>
              <div className="font-semibold">{money(annualSpend)}</div>
            </div>
          </div>
          <div className="flex gap-2 items-center">
            <IconCircle
              Icon={BuildingStorefrontIcon}
              color="yellow"
              size="8"
            ></IconCircle>
            <div>
              <div className="text-gray-500">Vendors</div>
              <div className="font-semibold">{vendorsCount}</div>
            </div>
          </div>
          <div className="flex gap-2 items-center">
            <IconCircle
              Icon={DocumentTextIcon}
              color="yellow"
              size="8"
            ></IconCircle>
            <div>
              <div className="text-gray-500">Contracts</div>
              <div className="font-semibold">{contractCount}</div>
            </div>
          </div>
          <div className="flex gap-2 items-center">
            <IconCircle
              Icon={ShoppingBagIcon}
              color="yellow"
              size="8"
            ></IconCircle>
            <div>
              <div className="text-gray-500">Line Items</div>
              <div className="font-semibold">{contractLineItemsCount}</div>
            </div>
          </div>
        </div>
        <div className="flex lg:justify-end mt-3">
          <Link
            to={`/intelligence/${account.id}/spend-by-department/${nameToDisplay}`}
            className="flex items-center text-sm lg:text-base text-sky-600 w-auto"
            id="spend-by-department-view-all-details"
          >
            View all details{" "}
            <ArrowRightIcon className="inline h-4 ml-1"></ArrowRightIcon>
          </Link>
        </div>
      </Card>
    </div>
  );
}
