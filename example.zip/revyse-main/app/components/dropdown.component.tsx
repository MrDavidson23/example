import { Menu, Transition } from "@headlessui/react";
import { type ReactNode } from "react";
import { Button } from "./button.component";
import { useNavigate } from "@remix-run/react";

export type DropdownItem = {
  to?: string;
  onClick?: () => void;
  label: string;
  icon?: JSX.ElementType;
  disabled?: boolean;
  id?: string;
};

export default function Dropdown({
  children,
  items,
  id,
}: {
  children?: ReactNode;
  items: DropdownItem[];
  id?: string;
}) {
  const navigate = useNavigate();
  return (
    <div className="relative">
      <Menu>
        <Menu.Button id={id}>{children}</Menu.Button>
        <Transition
          enter="transition duration-100 ease-out"
          enterFrom="transform scale-95 opacity-0"
          enterTo="transform scale-100 opacity-100"
          leave="transition duration-75 ease-out"
          leaveFrom="transform scale-100 opacity-100"
          leaveTo="transform scale-95 opacity-0"
        >
          <Menu.Items className="absolute w-max right-0 mt-2 origin-top-right divide-y divide-gray-100 rounded-md bg-white shadow-lg ring-1 ring-black/5 focus:outline-none">
            <div className="px-2 py-2 w-max">
              {items.map(item => (
                <Menu.Item key={item.label} disabled={item.disabled}>
                  <div>
                    <Button
                      id={item.id}
                      color="transparent"
                      className="w-full text-center hover:bg-gray-100"
                      onClick={
                        item.to !== undefined
                          ? () => navigate(item.to!)
                          : item.onClick
                      }
                    >
                      {item.icon ? (
                        <item.icon className="h-5 mr-2"></item.icon>
                      ) : (
                        ""
                      )}
                      {item.label}
                    </Button>
                  </div>
                </Menu.Item>
              ))}
            </div>
          </Menu.Items>
        </Transition>
      </Menu>
    </div>
  );
}
