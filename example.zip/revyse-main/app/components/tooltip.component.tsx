import type { ReactNode } from "react";
import { useState } from "react";
import { tv } from "tailwind-variants";

const tvTooltip = tv({
  base: "absolute bg-slate-600 text-slate-50 p-2 rounded-md shadow-md z-50 text-center text-xs font-normal [text-wrap:pretty] whitespace-normal",
  variants: {
    position: {
      left: "lg:right-full top-1/2 transform -translate-y-1/2",
      right: "left-full top-1/2 transform -translate-y-1/2",
      top: "bottom-full left-1/2 transform -translate-x-1/2",
      bottom: "top-full left-1/2 transform -translate-x-1/2",
      rightTop: "left-3/4 bottom-3/4",
      rightBottom: "left-3/4 top-3/4",
      leftTop: "right-3/4 bottom-3/4",
      leftBottom: "right-3/4 top-3/4",
    },
    size: {
      small: "w-36 lg:w-48",
      medium: "w-48 lg:w-60",
      large: "w-72 lg:w-96",
      auto: "w-auto",
    },
  },
  defaultVariants: {
    size: "large",
  },
});

interface TooltipProps {
  text: string | ReactNode;
  children: ReactNode;
  position?: keyof typeof tvTooltip.variants.position;
  size?: keyof typeof tvTooltip.variants.size;
  className?: string;
}

export function Tooltip({
  text,
  children,
  position = "left",
  size,
  className,
}: TooltipProps) {
  const [showTooltip, setShowTooltip] = useState(false);
  return (
    <div
      className="relative inline-block align-middle"
      onMouseEnter={() => {
        setShowTooltip(true);
      }}
      onMouseLeave={() => {
        setShowTooltip(false);
      }}
      onClick={() => {
        setShowTooltip(true);
      }}
    >
      {children}
      {showTooltip && (
        <div className={tvTooltip({ position, size, className })}>
          <span>{text}</span>
        </div>
      )}
    </div>
  );
}
