import { tv } from "tailwind-variants";

const tvRevysePencilIcon = tv({
  base: "w-5 aspect-square",
});

export function RevysePencilIcon({ className }: { className?: string }) {
  return (
    <div className={tvRevysePencilIcon({ className })}>
      <svg
        width="100%"
        height="100%"
        viewBox="0 0 27 26"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        <path
          d="M2.84932 23.1507H4.84384L17.1315 10.863L15.137 8.86849L2.84932 21.1562V23.1507ZM23.2219 8.79726L17.1671 2.8137L19.1616 0.819178C19.7078 0.273059 20.3788 0 21.1747 0C21.9706 0 22.6411 0.273059 23.1863 0.819178L25.1808 2.8137C25.7269 3.35982 26.0119 4.01896 26.0356 4.79112C26.0594 5.56329 25.7982 6.22195 25.2521 6.76712L23.2219 8.79726ZM21.1562 10.8986L6.05479 26H0V19.9452L15.1014 4.84384L21.1562 10.8986ZM16.1342 9.86575L15.137 8.86849L17.1315 10.863L16.1342 9.86575Z"
          fill="currentColor"
        />
      </svg>
    </div>
  );
}
