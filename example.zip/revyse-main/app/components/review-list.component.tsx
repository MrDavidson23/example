import { Link } from "@remix-run/react";
import { CTARedirect } from "./cta.component";
import StarRating from "./star-rating.component";
import type { ProductInput, ReviewsInput } from "./review-component";
import { Review } from "./review-component";

export function ReviewListComponent({
  user,
  product,
  reviews,
  className = "",
}: {
  user: { id: string } | null;
  product: ProductInput;
  reviews: ReviewsInput;
  className?: string;
}) {
  const numReviews = reviews.total_count;
  const avgCompatibilityScore = reviews.averages.compatibility_score ?? 0;
  const avgCustomerSupportScore = reviews.averages.customer_service_score ?? 0;
  const avgValueScore = reviews.averages.value_score ?? 0;
  const avgOnboardingScore = reviews.averages.onboarding_score ?? 0;

  const overallRating =
    (avgCompatibilityScore +
      avgCustomerSupportScore +
      avgValueScore +
      avgOnboardingScore) /
    4.0;

  return (
    <div className={`flex flex-col w-full ${className}`}>
      <h3
        id="reviews"
        className="border-b border-b-gray-100 pb-4 mb-6 font-medium flex flex-wrap justify-between flex-col lg:flex-row"
      >
        <div className="flex  items-center">
          {numReviews} Review{numReviews !== 1 ? "s" : ""}{" "}
          <StarRating rating={overallRating} className="ml-4" />{" "}
          <p className="text-sm text-gray-600 ml-4">
            {overallRating.toFixed(1)}
          </p>
        </div>
        <CTARedirect
          to={`/products/${product.slug}/reviews/new`}
          className="text-sm w-max lg:my-0 my-3"
          loginOrSignUp="sign-up"
          userLoggedIn={!!user}
          id="write-review-button"
        >
          Write a Review
        </CTARedirect>
      </h3>
      <div className="flex flex-wrap flex-col lg:flex-row">
        <div className="flex lg:w-1/2 mb-3 items-center">
          <StarRating rating={avgCustomerSupportScore} />
          <p className="mx-5">{avgCustomerSupportScore.toFixed(1)}</p>
          <p>Customer Support</p>
        </div>
        <div className="flex lg:w-1/2 mb-3 items-center">
          <StarRating rating={avgValueScore} />
          <p className="mx-5">{avgValueScore.toFixed(1)}</p>
          <p>Value</p>
        </div>
        <div className="flex lg:w-1/2 mb-3 items-center">
          <StarRating rating={avgOnboardingScore} />
          <p className="mx-5">{avgOnboardingScore.toFixed(1)}</p>
          <p>Onboarding Experience</p>
        </div>
        <div className="flex lg:w-1/2 mb-3 items-center">
          <StarRating rating={avgCompatibilityScore} />
          <p className="mx-5">{avgCompatibilityScore.toFixed(1)}</p>
          <p>Compatibility</p>
        </div>
      </div>

      {reviews.reviews.map(review => (
        <Review
          product={product}
          review={review}
          user={user}
          key={review.id}
          aggRating={overallRating}
          reviewCount={numReviews}
        />
      ))}

      <Link
        to={`/products/${product.slug}/reviews`}
        className="text-sky-600 mt-8 inline-block"
      >
        See All Reviews
      </Link>
    </div>
  );
}
