import { Form } from "@remix-run/react";
import { CTA } from "../cta.component";
import { Modal } from "../modal.component";
import { CrudDateField } from "../form/crud-form.component";
import dayjs from "dayjs";
import { ArrowLeftIcon } from "@heroicons/react/24/outline";
import { Button } from "../button.component";

export function ConfirmDeleteModal({
  isOpen,
  onClose,
  onConfirm,
  title = "Delete",
  message = "Are you sure you want to delete?",
  confirmText = "Yep!",
  cancelText = "Cancel",
  submitOnConfirm = false,
  intent = "delete",
}: {
  isOpen: boolean;
  onClose: (closed: boolean) => void;
  onConfirm?: () => void;
  title?: string;
  message?: string;
  confirmText?: string;
  cancelText?: string;
  submitOnConfirm?: boolean;
  intent?: string;
}) {
  return (
    <Modal isOpen={isOpen} onClose={onClose} manager={true} size="medium">
      <div className="p-3 space-y-7">
        <h1 className="text-2xl">{title}</h1>
        <div>{message}</div>
        <Form method="post">
          <input type="hidden" name="intent" value={intent} />
          {intent === "archive" ? (
            <div>
              <CrudDateField
                field={{
                  name: "canceled_at",
                  label: (
                    <div className="text-sm font-medium text-gray-900 mb-2">
                      Contract Cancellation Date{" "}
                      <span className="text-md font-normal text-gray-400 text-sm">
                        (Optional)
                      </span>{" "}
                    </div>
                  ),
                  type: "text",
                  errors: [],
                  defaultValue: dayjs.utc().format("YYYY-MM-DD"),
                }}
              />
              <div className="flex justify-between mt-8">
                <Button
                  color="transparent"
                  onClick={() => onClose(false)}
                  className="text-sky-600 flex items-center"
                >
                  <ArrowLeftIcon className="h-5 mr-2" /> Go Back
                </Button>
                <CTA
                  id="confirm-delete-modal-confirm-button"
                  className="ml-2"
                  type={submitOnConfirm ? "submit" : "button"}
                  onClick={
                    !submitOnConfirm
                      ? () => {
                          onClose(true);
                          onConfirm?.();
                        }
                      : undefined
                  }
                >
                  {confirmText}
                </CTA>
              </div>
            </div>
          ) : (
            <div className="flex justify-end space-x-2">
              <CTA variant="sky-shadow" onClick={() => onClose(false)}>
                {cancelText}
              </CTA>
              <CTA
                id="confirm-delete-modal-confirm-button"
                className="ml-2"
                type={submitOnConfirm ? "submit" : "button"}
                onClick={
                  !submitOnConfirm
                    ? () => {
                        onClose(true);
                        onConfirm?.();
                      }
                    : undefined
                }
              >
                {confirmText}
              </CTA>
            </div>
          )}
        </Form>
      </div>
    </Modal>
  );
}
