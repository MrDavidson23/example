import { Modal } from "../modal.component";
import { useCallback, useEffect, useState } from "react";
import type { useFetcher } from "@remix-run/react";
import { Form, useNavigate } from "@remix-run/react";
import { Button } from "../button.component";
import { CTA } from "../cta.component";
import {
  CheckCircleIcon,
  ExclamationTriangleIcon,
} from "@heroicons/react/24/solid";
import { ClockIcon } from "@heroicons/react/24/outline";
import { ArrowLeftIcon } from "@heroicons/react/20/solid";
import { encodeFileFields } from "~/utils/file.utils";

export type WizardStep = {
  id: string;
  progress?: number;
  title?: string | React.ReactNode;
  subtitle?: string | React.ReactNode;
  icon?: keyof typeof iconOptions;
  body?: React.ReactNode;
  ctas?: {
    primary?: WizardCTA;
    secondary?: WizardCTA;
    back?: WizardCTA;
  };
};

type WizardCTA = {
  label?: string;
  onClick?: WizardCTAOnClick;
  to?: string;
  resetFormValues?: boolean;
  toLink?: string;
  submit?: boolean;
  checkForm?: boolean;
};

type WizardCTAOnClick = (
  formValues: FormValues,
  cumulativeFormValues: FormValues
) => {
  to?: string;
  formValues?: FormValues;
  toLink?: string;
} | void;

type FormValues = {
  [key: string]: FormDataEntryValue;
};

const iconOptions = {
  success: {
    icon: CheckCircleIcon,
    colorClass: "text-green-500",
  },
  pending: {
    icon: ClockIcon,
    colorClass: "text-yellow-400",
  },
  warningRed: {
    icon: ExclamationTriangleIcon,
    colorClass: "text-red-500",
  },
};

export function WizardModal({
  isOpen,
  onClose,
  size = "medium-small",
  steps,
  initialStepId,
  restartOnClose,
  onFinish,
  onFormValuesChange,
  submitUrl,
  extraFormDataOnSubmit = {},
  fetcher,
}: {
  isOpen: boolean;
  onClose: () => void;
  size?: "small" | "medium-small" | "medium" | "full";
  steps: WizardStep[];
  initialStepId?: string;
  restartOnClose?: boolean;
  onFinish?: (formValues: FormValues) => void;
  onFormValuesChange?: (formValues: FormValues) => void;
  submitUrl?: string;
  extraFormDataOnSubmit?: FormValues;
  fetcher?: ReturnType<typeof useFetcher<{ success: boolean }>>;
}) {
  const navigate = useNavigate();

  const [currentStep, setCurrentStep] = useState<WizardStep | undefined>(
    steps.find(step => step.id === initialStepId) || steps[0]
  );

  const [submitInfo, setSubmitInfo] = useState<
    | {
        nextStepId: string | undefined;
        ctaId?: string;
        navigateTo?: string;
      }
    | undefined
  >();

  const [cumulativeFormValues, setCumulativeFormValues] = useState<FormValues>(
    {}
  );

  const handleClose = useCallback(() => {
    onClose();
    if (isOpen && restartOnClose) {
      setCurrentStep(steps.find(step => step.id === initialStepId) || steps[0]);
      setCumulativeFormValues({});
    }
  }, [isOpen, restartOnClose, initialStepId, steps, onClose]);

  const handleStepChange = useCallback(
    (stepId?: string) => {
      if (stepId) {
        setCurrentStep(steps.find(step => step.id === stepId));
      }
      if (stepId === undefined) {
        onFinish?.(cumulativeFormValues);
        handleClose();
      }
      setSubmitInfo(undefined);
    },
    [steps, onFinish, handleClose, cumulativeFormValues]
  );

  const handleCTAClick = useCallback(
    (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      // Get form values
      const formData = new FormData(e.target as HTMLFormElement);
      const formValues: FormValues = Object.fromEntries(formData.entries());

      // Get button CTA id
      const buttonCtaId = (e.nativeEvent as SubmitEvent).submitter?.id;
      const ctaId = buttonCtaId?.replace("-cta", "") as
        | "primary"
        | "secondary"
        | "back"
        | "";

      // Get CTA
      const cta = ctaId ? currentStep?.ctas?.[ctaId] : undefined;

      if (cta) {
        // Call CTA onClick
        const result = cta.onClick?.(formValues, cumulativeFormValues);

        const stepFormValues = { ...result?.formValues, ...formValues };
        const to = result?.to || cta.to;
        const toLink = result?.toLink || cta.toLink;

        let newConsolidatedFormValues = {
          ...cumulativeFormValues,
          ...stepFormValues,
        };

        // If resetFormValues is true, reset form values to step form values
        if (cta.resetFormValues) {
          newConsolidatedFormValues = stepFormValues;
        }

        onFormValuesChange?.(newConsolidatedFormValues);
        setCumulativeFormValues(newConsolidatedFormValues);

        // If submit or checkForm is true, submit form
        if (cta.submit || cta.checkForm) {
          // Create form data to submit
          const formData = new FormData();
          formData.append("step_id", currentStep?.id ?? "");

          // Add form values to form data
          const formDataFields = {
            ...(cta.submit ? newConsolidatedFormValues : stepFormValues),
            ...extraFormDataOnSubmit,
          };
          for (const key in formDataFields) {
            formData.append(key, formDataFields[key]);
          }

          encodeFileFields(formData);

          // Set submit intent
          const submitUrlIntent = cta.submit
            ? "submit"
            : cta.checkForm
            ? "check-errors"
            : "invalid-intent";

          const actionUrl = submitUrl
            ? `${submitUrl}/${submitUrlIntent}`
            : undefined;

          fetcher?.submit(formData, {
            action: actionUrl,
            method: "post",
            encType: "multipart/form-data",
          });

          setSubmitInfo({ nextStepId: to, navigateTo: toLink });
        } else {
          setSubmitInfo(undefined);
          if (toLink) {
            navigate(toLink);
          }
          handleStepChange(to);
        }
      }
    },
    [
      currentStep?.ctas,
      currentStep?.id,
      cumulativeFormValues,
      onFormValuesChange,
      fetcher,
      handleStepChange,
      submitUrl,
      extraFormDataOnSubmit,
      navigate,
    ]
  );

  useEffect(() => {
    if (initialStepId) {
      const initialStep = steps.find(step => step.id === initialStepId);
      if (initialStep) {
        setCurrentStep(initialStep);
      }
    }
  }, [initialStepId, steps]);

  useEffect(() => {
    setCurrentStep(prevStep => steps.find(step => step.id === prevStep?.id));
  }, [steps]);

  useEffect(() => {
    if (
      fetcher &&
      fetcher.state === "idle" &&
      submitInfo &&
      fetcher.data?.success
    ) {
      handleStepChange(submitInfo.nextStepId);
    }
  }, [fetcher, fetcher?.state, submitInfo, handleStepChange, fetcher?.data]);

  return (
    <Modal isOpen={isOpen} onClose={handleClose} manager={true} size={size}>
      <Form onSubmit={handleCTAClick}>
        {currentStep && (
          <WizardStepComponent
            {...currentStep}
            submitting={fetcher?.state === "submitting"}
          />
        )}
      </Form>
    </Modal>
  );
}

function WizardStepComponent({
  icon,
  title,
  subtitle,
  body,
  ctas,
  submitting,
}: WizardStep & { submitting?: boolean }) {
  const IconComponent = icon && iconOptions[icon].icon;
  const iconColorClass = icon && iconOptions[icon].colorClass;

  return (
    <div className="p-4">
      <header>
        {IconComponent && (
          <IconComponent className={`w-16 h-16 mb-3 ${iconColorClass}`} />
        )}
        {title && <h3 className="mb-5 text-2xl font-medium">{title}</h3>}
      </header>
      <section>
        {subtitle && <p className="mb-2 text-xl text-gray-900">{subtitle}</p>}
        {body && (
          <div className="mt-4 text-base [text-wrap:pretty]">{body}</div>
        )}
      </section>
      {ctas && (
        <footer className="mt-8 flex justify-between items-center">
          {ctas.back && (
            <Button
              id="back-cta"
              type="submit"
              color="transparent"
              to={ctas.back.toLink}
              disabled={submitting}
              className="px-0 sm:px-3"
            >
              <ArrowLeftIcon className="w-5 h-5 mr-1" />
              {ctas.back.label ?? "Back"}
            </Button>
          )}
          <div className="flex items-center space-x-2 ml-auto">
            {ctas.secondary && (
              <Button
                id="secondary-cta"
                type="submit"
                color="transparent"
                to={ctas.secondary.toLink}
                disabled={submitting}
              >
                {ctas.secondary.label ?? "Cancel"}
              </Button>
            )}
            {ctas.primary && (
              <CTA
                id="primary-cta"
                type="submit"
                to={ctas.primary.toLink}
                className={submitting ? "animate-bounce" : ""}
                disabled={submitting}
              >
                {ctas.primary.label ?? "Continue"}
              </CTA>
            )}
          </div>
        </footer>
      )}
    </div>
  );
}
