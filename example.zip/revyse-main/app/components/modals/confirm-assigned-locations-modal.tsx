import { CTA } from "../cta.component";
import { Modal } from "../modal.component";
import type { ContractLineItem } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { Button } from "../button.component";
import { Table } from "../intelligence/table.component";
import { Link } from "@remix-run/react";

export function ConfirmAssignedLocationsModal({
  isOpen,
  onClose,
  onConfirm,
  contractLineItem,
  originalItems,
  updatedItems,
  managerAccountId,
}: {
  isOpen: boolean;
  onClose: (closed: boolean) => void;
  onConfirm?: () => void;
  contractLineItem: SerializeFrom<ContractLineItem>;
  originalItems: string[];
  updatedItems: string[];
  managerAccountId: string;
}) {
  const unassignedLocations = originalItems.filter(
    item => !updatedItems.includes(item)
  ).length;
  const newAssignedLocations = updatedItems.filter(
    item => !originalItems.includes(item)
  ).length;

  return (
    <Modal isOpen={isOpen} onClose={onClose} manager={true} size="medium-small">
      <div className="p-3 space-y-7">
        <h1 className="text-2xl">
          Confirm location assignments for {contractLineItem.name}
        </h1>
        <div>
          If the selected location assignments look correct, click "Submit".
        </div>
        <Table
          data={[
            {
              id: "assigning",
              label: "Assigning",
              value: newAssignedLocations,
            },
            {
              id: "unassigning",
              label: "Unassigning",
              value: unassignedLocations,
            },
          ]}
          cols={[
            {
              name: "label",
              label: "Location Assignments:",
            },
            {
              name: "value",
              label: "",
              headerClassName: "w-1/2",
            },
          ]}
          showSelectBox={false}
          onClickRow={() => {}}
        />

        {unassignedLocations > 0 && (
          <div className="text-red-500 mt-2">
            Are you sure you want to unassign locations from this line item?
            You’ll lose all historical location data. This data cannot be
            recovered.
            <br />
            <br />
            To cancel a line item for one or more locations, we recommend
            setting the{" "}
            <Link
              className="text-red-500 font-semibold underline"
              to={`/intelligence/${managerAccountId}/contract/${contractLineItem.contract_id}/line-item/${contractLineItem.id}/summary#locations`}
            >
              line item status
            </Link>{" "}
            to “Canceled.”
          </div>
        )}
        <div className="w-full flex justify-end">
          <Button color="transparent" onClick={() => onClose(false)}>
            Go back
          </Button>
          <CTA
            id="confirm-assigned-locations-modal-confirm-button"
            className="ml-2"
            type="button"
            onClick={() => {
              onClose(true);
              onConfirm?.();
            }}
          >
            Submit
          </CTA>
        </div>
      </div>
    </Modal>
  );
}
