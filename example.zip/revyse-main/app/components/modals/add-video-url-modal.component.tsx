import React, { useCallback, useEffect, useState } from "react";
import { CrudTextField } from "../form/crud-form.component";
import { Modal } from "../modal.component";
import { CTA } from "../cta.component";

const type = "youtube";

const YOUTUBE_OEMBED_API = "https://www.youtube.com/oembed";

export function AddVideoUrlModal({
  isOpen,
  onClose,
  onAddVideo,
}: {
  isOpen: boolean;
  onClose: (closed: boolean) => void;
  onAddVideo: ({
    title,
    url,
    type,
    embedUrl,
  }: {
    title: string;
    url: string;
    type: "youtube";
    embedUrl: string;
  }) => void;
}) {
  const [url, setUrl] = useState("");
  const [title, setTitle] = useState("");
  const [loading, setLoading] = useState(false);
  const [errors, setErrors] = useState<string[]>([]);

  const loadEmbedUrl = useCallback(async () => {
    setErrors([]);
    if (type == "youtube") {
      const response = await fetch(
        `${YOUTUBE_OEMBED_API}?${new URLSearchParams({ url, format: "json" })}`
      );
      if (response.ok) {
        const data = await response.json();

        const newEmbedUrl = data?.html
          ?.split(" ")
          .find((attribute: string) => attribute.includes("src="))
          .slice(5, -1);

        return newEmbedUrl;
      } else if (response.status == 400) {
        // Video doesn't exist
        setErrors([
          "Seems like this video doesn't exist. Please check the URL.",
        ]);
      } else {
        // Invalid link
        setErrors(["Seems like the URL is not a valid YouTube video URL."]);
      }
    }
  }, [url]);

  const handleAddVideo = useCallback(async () => {
    setLoading(true);
    const embedUrl = await loadEmbedUrl();
    if (embedUrl) {
      onAddVideo({ title, url, type, embedUrl });
    }
    setLoading(false);
  }, [loadEmbedUrl, onAddVideo, title, url]);

  useEffect(() => {
    if (isOpen) {
      setUrl("");
      setTitle("");
      setErrors([]);
    }
  }, [isOpen]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} manager={true}>
      <div className="p-3">
        <h3>Add new YouTube URL</h3>
        <div className="mt-5">
          <CrudTextField
            className=""
            field={{
              name: "newVideoUrl",
              label: "YouTube URL",
              type: "text",
              placeholder: `https://www.youtube.com...`,
              defaultValue: "",
              onChange: e => {
                setUrl(e.target.value);
              },
              errors,
            }}
          />
        </div>
        <div className="mt-5">
          <CrudTextField
            className=""
            field={{
              name: "newVideoTitle",
              label: "Video Title",
              type: "text",
              placeholder: `Title`,
              defaultValue: "",
              onChange: e => {
                setTitle(e.target.value);
              },
              errors: [],
              maxCharacters: 30,
            }}
          />
        </div>
        <div className="flex justify-end mt-8 items-center space-x-3">
          <button
            className="text-sky-500"
            onClick={onClose as any}
            disabled={!url || loading}
          >
            Cancel
          </button>
          <CTA
            variant="coral-shadow"
            onClick={() => url && !loading && handleAddVideo()}
          >
            {loading ? "Checking video" : "Add Video"}
          </CTA>
        </div>
      </div>
    </Modal>
  );
}

export default AddVideoUrlModal;
