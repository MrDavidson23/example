import { tv } from "tailwind-variants";

const tvAvatar = tv({
  base: "h-8 w-8 lg:h-10 lg:w-10 rounded-full overflow-hidden uppercase flex items-center justify-center lg:text-lg text-base",
});

export function Avatar({
  first_name,
  last_name,
  img_url,
  className,
}: {
  first_name: string | null;
  last_name: string | null;
  img_url?: string | null;
  className?: string;
}) {
  return img_url ? (
    <div className={tvAvatar({ className })}>
      <img
        src={img_url}
        alt=""
        className="w-full h-full object-cover aspect-square"
        width="40"
        height="40"
      />
    </div>
  ) : (
    <div
      className={tvAvatar({ className: `${className} bg-sky-800 text-white` })}
    >
      {first_name ? first_name[0] : "R"}
      {last_name ? last_name[0] : "E"}
    </div>
  );
}
