import React, { useRef, useState } from "react";
import { XMarkIcon } from "@heroicons/react/24/outline";
import { CrudTextField } from "./form/crud-form.component";

export function EmailList({
  name,
  label,
  emails = [],
}: {
  name: string;
  label: string;
  emails: string[];
}) {
  const [recipient, setRecipient] = useState("");
  const [recipients, setRecipients] = useState<string[]>(emails);
  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const [errorMessage, setErrorMessage] = useState<string>("");

  const handleAddRecipient = () => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (recipient && !recipients.includes(recipient)) {
      if (emailRegex.test(recipient)) {
        setRecipients([...recipients, recipient]);
        setRecipient("");
        setErrorMessage("");
      } else {
        setErrorMessage("Invalid email address format");
      }
    } else {
      setErrorMessage("Email address is already added");
    }
  };

  const handleRemoveRecipient = (email: string) => {
    const updatedRecipients = recipients.filter(e => e !== email);
    setRecipients(updatedRecipients);
  };

  const handleInputKeyPress = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key == "Enter") {
      e.preventDefault();
      buttonRef.current?.click();
    }
  };

  return (
    <div>
      <label
        htmlFor=""
        className="block text-sm font-medium leading-6 text-gray-900"
      >
        {label}
      </label>
      <div className="flex flex-row items-center justify-between space-x-3">
        <CrudTextField
          field={{
            name: "email-list",
            label: "",
            errors: errorMessage ? [errorMessage] : [],
            type: "text",
            placeholder: "Add email...",
            defaultValue: recipient,
            onChange: e => setRecipient(e.target.value),
            onKeyDown: handleInputKeyPress,
          }}
          className="w-full"
        />
        <button
          type="button"
          className="flex items-center rounded-full bg-white border-2 border-sky-500 px-3 py-1.5 text-sm font-semibold text-sky-500"
          onClick={handleAddRecipient}
          ref={buttonRef}
        >
          Add
        </button>
      </div>
      {recipients.length > 0 ? (
        <div className="grid grid-flow-col auto-cols-max grid-rows-2 overflow-x-auto gap-1.5">
          {recipients.map((email, index) => (
            <div
              key={email}
              className="bg-sky-50 rounded-full px-2 py-1.5 flex items-center text-xs gap-2"
            >
              <input type="hidden" name={`${name}.id`} value={index} />
              <input type="hidden" name={`${name}.email`} value={email} />
              <button
                className="font-light"
                onClick={() => handleRemoveRecipient(email)}
              >
                <XMarkIcon className="h-5" />
              </button>
              <div>{email}</div>
            </div>
          ))}
        </div>
      ) : (
        <div className="font-light text-gray-400 text-sm">
          No email recipients added yet.
        </div>
      )}
    </div>
  );
}
