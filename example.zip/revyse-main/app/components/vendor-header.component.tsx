import type { Vendor } from "@prisma/client";
import { CTA } from "./cta.component";
import StarRating from "./star-rating.component";
import { Tag } from "./tag.component";
import type { PRODUCT_PERKS_KEYS } from "~/utils/constants.utils";
import {
  ProductPerksIcons,
  ProductPerksLabels,
  VendorValueIcons,
  VendorValueTagsLabels,
} from "~/utils/constants.utils";
import type { SerializeFrom } from "@remix-run/node";

export function VendorHeader({
  vendor,
  vendorRating,
  showCTA = false,
}: {
  vendor: SerializeFrom<
    Vendor & {
      product_perks?: (keyof typeof PRODUCT_PERKS_KEYS)[];
    }
  >;
  vendorRating: {
    rating: number;
    totalReviews: number;
  };
  showCTA?: boolean;
}) {
  return (
    <div className="bg-sky-50 md:h-auto px-8 lg:px-12 py-8 flex justify-between flex-col lg:flex-row gap-y-5">
      <div className="flex lg:flex-row flex-col items-start lg:items-center lg:space-x-10">
        <img
          className="w-20 lg:w-44 rounded-md aspect-square h-auto"
          src={
            vendor.logo_file_id
              ? `/images/${vendor.logo_file_id}`
              : "/assets/default-logo.png"
          }
          width="176"
          height="176"
          alt="Vendor Logo"
        />
        <div className="space-y-2">
          <h1 className="text-2xl font-bold pt-3 lg:pt-0">{vendor.name}</h1>
          <div className="flex gap-3">
            <StarRating rating={vendorRating.rating} size={6} />
            <span>{vendorRating.rating.toFixed(1)}</span>
            <span className="text-gray-400">({vendorRating.totalReviews})</span>
          </div>
          {showCTA && (
            <div className="flex items-start lg:hidden pt-2">
              <CTA variant="coral" to={`/vendors/${vendor.slug}/products`}>
                View All Products
              </CTA>
            </div>
          )}
          <div className="flex flex-wrap items-center pt-4">
            {vendor.value_tags.map((tag, index) => (
              <div key={index}>
                <Tag
                  className="mr-2 mb-2 text-xs lg:text-sm"
                  label={VendorValueTagsLabels[tag]}
                  color="sky"
                  icon={VendorValueIcons[tag]}
                />
              </div>
            ))}
            {vendor.product_perks?.map((perk, index) => (
              <div key={perk}>
                <Tag
                  className="mr-2 mb-2 text-xs lg:text-sm"
                  label={ProductPerksLabels[perk]}
                  color="sky"
                  icon={ProductPerksIcons[perk]}
                />
              </div>
            ))}
          </div>
        </div>
      </div>
      {showCTA && (
        <div className="hidden lg:block">
          <CTA
            id="view-all-products-primary"
            variant="coral"
            to={`/vendors/${vendor.slug}/products`}
          >
            View All Products
          </CTA>
        </div>
      )}
    </div>
  );
}
