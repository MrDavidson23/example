import type { Breadcrumb } from "./breadcrumbs.component";
import type { CrudTableColumn, TableStateConfig } from "./crud-table.component";
import { CrudTable } from "./crud-table.component";
import { PortalPage } from "./portal-page.component";
import { Button } from "./button.component";

export function CrudListPage<T extends { id: string }>({
  crumbs,
  cols,
  data,
  title,
  subtitle,
  showAddButton = true,
  onClickRow,
  tableStateConfig,
}: {
  crumbs: Breadcrumb[];
  cols: CrudTableColumn<T>[];
  data: T[];
  title: string;
  subtitle: string;
  showAddButton?: boolean;
  onClickRow?: (row: T) => void;
  tableStateConfig?: TableStateConfig;
}) {
  return (
    <PortalPage crumbs={crumbs}>
      <>
        <div className="sm:flex sm:items-center">
          <div className="sm:flex-auto">
            <h1 className="text-base font-semibold leading-6 text-gray-900">
              {title}
            </h1>
            <p className="mt-2 text-sm text-gray-700">{subtitle}</p>
          </div>
          {showAddButton && (
            <div className="mt-4 sm:ml-16 sm:mt-0 sm:flex-none">
              <Button id="add-button" to="./new">
                Add
              </Button>
            </div>
          )}
        </div>
        <CrudTable
          cols={cols}
          data={data}
          onClickRow={onClickRow}
          showAddButton={showAddButton}
          tableStateConfig={tableStateConfig}
        ></CrudTable>
      </>
    </PortalPage>
  );
}
