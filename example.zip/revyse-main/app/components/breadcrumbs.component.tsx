import { ChevronRightIcon } from "@heroicons/react/20/solid";
import { Link } from "@remix-run/react";

export type Breadcrumb = {
  name: string;
  to: string;
  active?: boolean;
  id?: string;
};

export function Breadcrumbs({
  crumbs,
  className,
}: {
  crumbs: Breadcrumb[];
  className?: string;
}) {
  return (
    <nav className={`flex ${className}`} aria-label="Breadcrumb">
      <ol className="flex items-center gap-x-2 flex-wrap md:flex-no-wrap">
        {crumbs.map((page, i) => (
          <li key={page.name}>
            <div className="flex items-center">
              {i > 0 && (
                <ChevronRightIcon
                  className="h-5 w-5 flex-shrink-0 text-gray-400 mr-2"
                  aria-hidden="true"
                />
              )}
              <Link
                id={page.id}
                to={page.to}
                className={`text-sm text-gray-500 hover:text-gray-700 ${
                  page.active ? "font-semibold" : "font-medium"
                }`}
                aria-current={page.active ? "page" : undefined}
              >
                {page.name}
              </Link>
            </div>
          </li>
        ))}
      </ol>
    </nav>
  );
}
