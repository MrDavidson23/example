import { tv } from "tailwind-variants";

const tvListingCard = tv({
  base: "rounded md:border border-gray-100 p-0 md:p-6 mt-7 md:mt-4",
});

export function ListingCard({
  children,
  className,
}: {
  children: JSX.Element;
  className?: string;
}) {
  return <div className={tvListingCard({ className })}>{children}</div>;
}
