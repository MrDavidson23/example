import { ArrowRightIcon } from "@heroicons/react/24/outline";
import { useNavigate } from "@remix-run/react";
import type { ReactNode } from "react";
import { tv } from "tailwind-variants";

const tvFeatureLocked = tv({
  base: "w-full h-full rounded-lg md:px-56",
  variants: {
    size: {
      small: "md:py-6",
      big: "md:py-24",
    },
  },
});

export function FeatureLocked({
  variant = "big",
  bgImage,
  text,
  linkText,
  to,
  onClick,
}: {
  variant?: "big" | "small";
  bgImage: string;
  text: ReactNode;
  linkText?: string;
  to?: string;
  onClick?: () => void;
}) {
  const navigate = useNavigate();
  // eslint-disable-next-line @typescript-eslint/no-empty-function
  onClick = onClick ?? (to ? () => navigate(to) : () => {});
  return (
    <div
      className={`rounded-lg bg-center bg-contain bg-no-repeat`}
      style={{ backgroundImage: `url(${bgImage})` }}
    >
      <div className={tvFeatureLocked({ size: variant })}>
        <div className="bg-white/95 p-6 rounded flex flex-col justify-center shadow-sm border border-gray-100">
          <div className="text-center text-lg">{text}</div>
          {linkText && (
            <button
              onClick={onClick}
              type="button"
              className="flex items-center text-center mx-auto mt-4 text-coral"
            >
              {linkText} <ArrowRightIcon className="ml-4 h-6 inline" />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
