import type { ReactNode } from "react";
import { tv } from "tailwind-variants";

const bgColorVariant = tv({
  base: "flex justify-center md:py-12 py-8",
  variants: {
    background: {
      white: "bg-white",
      blue: "bg-sky-50",
    },
  },
});

export function ContentStripe({
  color,
  tag,
  heading,
  children,
  imageUrl,
  layout = "left",
  imageWidth,
  imageHeight,
}: {
  color: "white" | "blue";
  tag?: string;
  heading: string;
  children: ReactNode;
  imageUrl: string;
  layout: "left" | "right";
  imageWidth: string;
  imageHeight: string;
}) {
  return (
    <div className={bgColorVariant({ background: color })}>
      <div className="max-w-5xl flex-grow md:px-8 px-4 grid md:grid-cols-5 grid-cols-1">
        {layout === "right" && (
          <div className="col-span-2 flex items-center justify-start">
            <img
              src={imageUrl}
              alt="illustration"
              className="w-full h-auto"
              width={imageWidth}
              height={imageHeight}
            />
          </div>
        )}
        <div className="col-span-3">
          <p className="uppercase font-bold text-sm mb-4">{tag}</p>
          <h2 className="text-3xl font-bold mb-8">{heading}</h2>
          <div>{children}</div>
        </div>
        {layout === "left" && (
          <div className="col-span-2 flex items-center justify-end">
            <img
              src={imageUrl}
              alt="illustration"
              className="w-full h-auto"
              width={imageWidth}
              height={imageHeight}
            />
          </div>
        )}
      </div>
    </div>
  );
}
