import type { Product } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";

export function ProductSectorBlock({
  title,
  products,
}: {
  title: string;
  products: SerializeFrom<Product>[];
}) {
  return (
    <div className="grid grid-cols-2 rounded overflow-hidden shadow-md border border-gray-100">
      {products.map(p => (
        <div
          key={p.id}
          className="bg-white h-24 bg-center bg-cover"
          style={{ backgroundImage: `url(/images/${p.logo_file_id})` }}
        ></div>
      ))}
      <div className="col-span-2 py-3 text-center text-sm font-medium border-t border-gray-100">
        {title}
      </div>
    </div>
  );
}
