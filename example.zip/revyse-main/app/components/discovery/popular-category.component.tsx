import { ArrowRightIcon } from "@heroicons/react/24/outline";
import type { ProductCategory } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { Link } from "@remix-run/react";

export function PopularCategory({
  cat,
  borderTop = false,
}: {
  cat: SerializeFrom<ProductCategory>;
  borderTop?: boolean;
}) {
  return (
    <div
      key={cat.id}
      className={`py-6 ${borderTop ? "border-t border-gray-200" : ""}`}
      id={`popular-category-${cat.id}`}
    >
      <Link
        to={`/categories/${cat.slug}`}
        className="flex items-center text-sky-600 font-medium"
        id="popular-category-name"
      >
        {cat.name}
      </Link>
      <p
        className="text-gray-500 font-light my-2"
        id="popular-category-description"
      >
        {cat.description.substring(0, 230)}...
      </p>
      <Link
        to={`/categories/${cat.slug}`}
        className="flex items-center text-sky-600 text-sm"
        id="popular-category-view-link"
      >
        View category <ArrowRightIcon className="ml-2 h-4" />
      </Link>
    </div>
  );
}
