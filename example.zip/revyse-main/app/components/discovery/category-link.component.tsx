import type { ProductCategory } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { Link } from "@remix-run/react";

export function CategoryLink({ cat }: { cat: SerializeFrom<ProductCategory> }) {
  return (
    <Link
      to={`/categories/${cat.slug}`}
      className="text-sky-600"
      id={`category-${cat.id}`}
    >
      {cat.name}
    </Link>
  );
}
