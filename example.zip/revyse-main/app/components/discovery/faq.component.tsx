import { ChevronDownIcon, ChevronUpIcon } from "@heroicons/react/24/outline";
import { useState } from "react";

export function FAQ({
  question,
  answer,
  defaultOpen,
}: {
  question: string;
  answer: string;
  defaultOpen?: boolean;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <div className="border-b border-gray-200 py-6">
      <div
        className="flex justify-between cursor-pointer text-sky-600 items-center"
        onClick={() => setOpen(!open)}
      >
        <h4>{question}</h4>
        {open ? (
          <ChevronUpIcon className="md:h-5 h-12" />
        ) : (
          <ChevronDownIcon className="md:h-5 h-12" />
        )}
      </div>
      {open && <p className="mt-4 text-gray-900">{answer}</p>}
    </div>
  );
}
