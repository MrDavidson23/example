import { ChevronRightIcon } from "@heroicons/react/20/solid";
import { Link } from "@remix-run/react";
import React from "react";

export function DiscoveryHeader({
  title,
  description,
  crumbs,
  showImage = true,
}: {
  title: string;
  description?: string;
  crumbs: {
    label: string;
    link: string;
    active: boolean;
    id?: string;
  }[];
  showImage?: boolean;
}) {
  return (
    <div className="bg-sky-500 flex justify-center md:py-6 py-3">
      <div className="max-w-7xl flex-grow text-white px-8 relative">
        <div className="flex flex-wrap items-center uppercase text-sm mb-6 px-2 md:px-0">
          {crumbs.map((crumb, index) => (
            <React.Fragment key={index}>
              <Link
                to={crumb.link}
                className={crumb.active ? "font-bold" : ""}
                id={crumb.id}
              >
                {crumb.label}
              </Link>
              {index < crumbs.length - 1 && (
                <ChevronRightIcon className="h-4" />
              )}
            </React.Fragment>
          ))}
        </div>
        <h1 className="text-4xl font-bold mt-8">{title}</h1>
        {description && (
          <p className="my-3 text-lg text-white/80 md:pr-48">{description}</p>
        )}

        {showImage && (
          <>
            <img
              src="/assets/cloud-1.png"
              className="absolute top-2 right-28 h-16 w-auto hidden md:block"
              alt="cloud"
              height="206"
              width="414"
            />
            <img
              src="/assets/cloud-2.png"
              className="absolute top-12 right-10 md:-bottom-28 h-10 w-auto hidden md:block"
              alt="cloud"
              height="70"
              width="169"
            />
          </>
        )}
      </div>
    </div>
  );
}
