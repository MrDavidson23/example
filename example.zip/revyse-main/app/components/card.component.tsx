import type { ReactNode } from "react";

export function Card({
  children,
  className = "p-4",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div className={`${className} bg-white shadow rounded `}>{children}</div>
  );
}
