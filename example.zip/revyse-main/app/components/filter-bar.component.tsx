import {
  EllipsisVerticalIcon,
  FunnelIcon,
  MagnifyingGlassIcon,
} from "@heroicons/react/24/outline";
import React, { useEffect } from "react";
import { tv } from "tailwind-variants";
import { CTA } from "./cta.component";
import type { DropdownItem } from "./dropdown.component";
import Dropdown from "./dropdown.component";
import { Button } from "./button.component";

export type FilterBarProps = {
  className?: string;
  inputPlaceholder?: string;
  defaultSearchQuery?: string;
  onFilter: (searchQuery: string) => void;
  filters?: {
    onOpenFilteringModal: (open: boolean) => void;
    filtersCount: number;
  };
  dropdownItems?: DropdownItem[];
};

const tvFilterBar = tv({
  base: "md:flex items-center justify-between gap-x-4",
});

const tvFilterBarInputContainer = tv({
  base: "border-gray-300 border bg-white shadow-lg py-0.5 shadow-gray-200/50 md:w-10/12 rounded-full px-4 flex items-center",
  variants: {
    width: {
      "10/12": "md:w-10/12",
      "11/12": "md:w-11/12",
    },
  },
});

export function FilterBar({
  className,
  inputPlaceholder = "Search",
  defaultSearchQuery = "",
  onFilter,
  filters,
  dropdownItems,
}: FilterBarProps) {
  const [searchQuery, setSearchQuery] = React.useState(defaultSearchQuery);

  useEffect(() => {
    setSearchQuery(defaultSearchQuery);
  }, [defaultSearchQuery]);

  const handleInputKeyPress = (evt: React.KeyboardEvent<HTMLInputElement>) => {
    if (evt.key === "Enter") {
      onFilter(searchQuery);
    }
  };

  const handleFilterButtonClick = () => {
    onFilter(searchQuery);
  };

  return (
    <div className={tvFilterBar({ className })}>
      <div
        className={tvFilterBarInputContainer({
          width: filters ? "10/12" : "11/12",
        })}
      >
        <MagnifyingGlassIcon className="hidden md:block h-5 text-sky-500" />
        <input
          type="text"
          id="search-bar"
          placeholder={inputPlaceholder}
          className="text-sm bg-transparent border-0 focus:border-0 focus:ring-0 w-full"
          value={searchQuery}
          onChange={evt => {
            setSearchQuery(evt.target.value as string);
          }}
          onKeyDown={handleInputKeyPress}
        />
        <div className="justify-end block md:hidden">
          <button
            className="bg-sky-600 p-1.5 rounded-full"
            onClick={() => onFilter(searchQuery)}
          >
            <MagnifyingGlassIcon className="h-4 text-white" />
          </button>
        </div>
      </div>
      <CTA
        className="md:block hidden w-max"
        fillStyle="outline"
        variant="sky"
        onClick={handleFilterButtonClick}
      >
        Search
      </CTA>
      {filters && (
        <button
          className="flex font-light items-center justify-start w-full md:w-fit mt-4 md:mt-0 space-x-1"
          onClick={() => filters?.onOpenFilteringModal(true)}
        >
          <FunnelIcon className="h-6 text-sky-500" />
          <span className="text-sm">
            {filters && filters.filtersCount > 0 ? filters.filtersCount : ""}{" "}
            Filter{!filters.filtersCount || filters.filtersCount > 1 ? "s" : ""}
          </span>
        </button>
      )}
      {dropdownItems && (
        <Dropdown items={dropdownItems} id="dropdown">
          <Button color="transparent" type="div">
            <EllipsisVerticalIcon className="h-8" />
          </Button>
        </Dropdown>
      )}
    </div>
  );
}
