import { Link } from "react-router-dom";
import StarRating from "./star-rating.component";
import { CTA } from "./cta.component";
import { Tag } from "./tag.component";
import type { VendorValueTags } from "@prisma/client";
import { Tooltip } from "./tooltip.component";
import { isEmpty } from "lodash";

export function VendorCard({
  vendor,
  tags,
}: {
  vendor: {
    vendor_rating: {
      rating: number;
      totalReviews: number;
    };
    slug: string | null;
    id: string;
    name: string;
    description: string | null;
    logo_file_id: string | null;
    value_tags: VendorValueTags[];
  };
  tags?: { value: VendorValueTags; label: string; icon: JSX.ElementType }[];
}) {
  return (
    <>
      <div
        className="rounded border border-gray-100 shadow-md rounded-lg md:p-6 p-2  cursor-pointer"
        id={`vendor-card-${vendor.id}`}
      >
        <div className="flex gap-3 md:gap-6">
          <div className="relative">
            <div
              className="w-36 h-36 bg-white border border-gray-100 bg-center bg-contain bg-no-repeat"
              style={{
                backgroundImage: vendor.logo_file_id
                  ? `url(/images/${vendor.logo_file_id})`
                  : "url(/assets/default-logo.png)",
              }}
            ></div>
          </div>
          <div className="w-full flex-shink">
            <div className="flex justify-between items-start flex-wrap">
              <div>
                <h3 className="font-medium" id="vendor-name">
                  <Link to={`/vendors/${vendor.slug}`}>{vendor.name}</Link>
                </h3>
                <div className="flex gap-3" id="vendor-rating">
                  <StarRating rating={vendor.vendor_rating.rating} size={6} />
                  <span>{vendor.vendor_rating.rating.toFixed(1)}</span>
                  <span className="text-gray-400">
                    ({vendor.vendor_rating.totalReviews})
                  </span>
                </div>
              </div>
              <div className="space-x-3">
                <CTA
                  to={`/vendors/${vendor.slug}/products`}
                  variant="coral-shadow"
                  className="mt-4"
                  id="view-vendor-products-button"
                >
                  View All Products
                </CTA>
                <CTA
                  to={`/vendors/${vendor.slug}`}
                  variant="sky-shadow"
                  className="mt-4"
                  id="view-vendor-button"
                >
                  View Details
                </CTA>
              </div>
            </div>
            <div className="mt-6 hidden md:block">
              <p
                className={`whitespace-normal ${
                  !isEmpty(tags) ? "line-clamp-2 " : "line-clamp-3"
                } truncate`}
                id="vendor-description"
              >
                {vendor.description}
              </p>
              {tags && (
                <div className="flex gap-6 mt-5">
                  <div className="flex-grow flex flex-wrap gap-2">
                    {tags.map(tag => (
                      <div key={tag.value} id={`vendor-value-tag-${tag.value}`}>
                        {tags.length < 3 ? (
                          <Tag
                            color="sky"
                            label={tag.label}
                            icon={tag.icon}
                            className="text-xs"
                          />
                        ) : (
                          <Tooltip size="small" position="top" text={tag.label}>
                            <Tag color="sky" label="" icon={tag.icon} />
                          </Tooltip>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
        <div className="mt-6 md:hidden">
          <div className="overflow-hidden leading-tight">
            <p
              className={`whitespace-normal ${
                !isEmpty(tags) ? "line-clamp-2 " : "line-clamp-3"
              } truncate`}
              id="vendor-description"
            >
              {vendor.description}
            </p>
            {tags && (
              <div className="flex gap-6 mt-5">
                <div className="flex-grow flex flex-wrap gap-2">
                  {tags.map(tag => (
                    <div key={tag.value} id={`vendor-value-tag-${tag.value}`}>
                      {tags.length < 3 ? (
                        <Tag
                          color="sky"
                          label={tag.label}
                          icon={tag.icon}
                          className="text-xs"
                        />
                      ) : (
                        <Tag color="sky" label="" icon={tag.icon} />
                      )}
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
