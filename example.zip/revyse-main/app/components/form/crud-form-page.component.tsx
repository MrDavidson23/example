import type { Breadcrumb } from "../breadcrumbs.component";
import type { CrudFormConfig } from "./crud-form.component";
import { CrudForm } from "./crud-form.component";
import { PortalPage } from "../portal-page.component";

export function CrudFormPage({
  crumbs,
  config,
  buttonsSlot,
}: {
  crumbs: Breadcrumb[];
  config: CrudFormConfig;
  buttonsSlot?: JSX.Element;
}) {
  return (
    <PortalPage crumbs={crumbs} buttonsSlot={buttonsSlot}>
      <CrudForm config={config}></CrudForm>
    </PortalPage>
  );
}
