import { useState } from "react";
import { tv } from "tailwind-variants";

const tvGridSelectItem = tv({
  base: "bg-white hover:bg-gray-100/50 py-5 px-3 flex flex-col items-center justify-center rounded-lg cursor-pointer border border-gray-300",
  variants: {
    selected: {
      true: "ring-2 ring-sky-500 bg-sky-500/10 hover:bg-sky-500/10",
    },
  },
});

export function GridSelect({
  name,
  options,
  defaultValue,
  onChange,
  columns = 3,
  gap = 4,
}: {
  name: string;
  options: { label: string; value: string; icon: React.ReactNode }[];
  defaultValue?: string;
  onChange?: (selected: string) => void;
  columns?: number;
  gap?: number;
}) {
  const [value, setValue] = useState(defaultValue);

  const handleOnChange = (value: string) => {
    setValue(value);
    onChange?.(value);
  };

  return (
    <>
      <div className={`h-full w-full grid grid-cols-${columns} gap-${gap}`}>
        {options.map(option => (
          <div
            key={option.label}
            onClick={handleOnChange.bind(null, option.value)}
            className={tvGridSelectItem({ selected: option.value === value })}
          >
            <div>{option.icon}</div>
            <div className="mt-3 font-semibold text-center">{option.label}</div>
          </div>
        ))}
      </div>
      <input type="hidden" value={value ?? ""} name={name} />
    </>
  );
}
