import { Form, useSubmit } from "@remix-run/react";
import { useCallback } from "react";
import { encodeFileFields } from "~/utils/file.utils";

export function FormWithUploads({
  children,
  onSubmit,
  className,
}: {
  children: React.ReactNode;
  onSubmit?: (e: React.FormEvent<HTMLFormElement>) => boolean | void;
  className?: string;
}) {
  const submit = useSubmit();
  const handleSubmit = useCallback(
    (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      const formData = new FormData(e.currentTarget);

      // Encode uploads filenames
      encodeFileFields(formData);

      // if onSubmit returns false, don't submit the form
      const shouldSubmit = !onSubmit || onSubmit(e);
      if (shouldSubmit) {
        submit(formData, {
          method: "post",
          encType: "multipart/form-data",
        });
      }
    },
    [submit, onSubmit]
  );

  return (
    <Form
      onSubmit={handleSubmit}
      encType="multipart/form-data"
      className={className}
      method="post"
    >
      {children}
    </Form>
  );
}
