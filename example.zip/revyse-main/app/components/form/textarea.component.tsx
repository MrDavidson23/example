import { type ChangeEvent, useState } from "react";
import type { CrudFormFieldTextArea } from "./crud-form.component";
import { tvField } from "~/utils/global-tailwind-variants.utils";

export function CrudTextAreaField({
  field,
  className,
  onChange,
  textareaRef,
}: {
  field: CrudFormFieldTextArea;
  className?: string;
  onChange?: (event: ChangeEvent<HTMLTextAreaElement>) => void;
  textareaRef?: React.RefObject<HTMLTextAreaElement>;
}) {
  // Handle the character limit if maxCharacters is present
  const [characterCount, setCharacterCount] = useState(
    field.defaultValue?.toString().length ?? 0
  );

  const handleCharacterChange = (
    event: React.ChangeEvent<HTMLTextAreaElement>
  ) => {
    const inputValue = event.target.value;
    setCharacterCount(inputValue.length);

    if (onChange) onChange(event);
  };

  return (
    <div className={`col-span-full ${className}`}>
      <label
        htmlFor={field.name}
        className="text-sm font-medium leading-6 text-gray-900 flex"
      >
        {field.label}{" "}
        {field.showOptional && (
          <span className="text-md font-normal text-gray-400 text-sm ml-1.5">
            (Optional)
          </span>
        )}
        <span className="text-gray-600 font-light">{field.description}</span>
      </label>
      <div className="mt-2">
        <textarea
          ref={textareaRef}
          name={field.name}
          id={field.name}
          defaultValue={field.defaultValue}
          rows={field.rows ?? 10}
          placeholder={field.placeholder}
          className={tvField({
            className: "py-0 sm:py-1.5",
            error: field.errors.length > 0,
          })}
          disabled={field.disabled}
          onChange={handleCharacterChange}
          maxLength={field.maxCharacters}
        />
      </div>
      <p className="mt-3 text-sm leading-6 text-red-600">
        {field.errors?.join(" ")}
      </p>
      {field.maxCharacters ? (
        <p
          id={`${field.name}-characterCount`}
          className="mt-1 text-xs text-gray-500"
        >
          {characterCount}/{field.maxCharacters} characters
        </p>
      ) : null}
    </div>
  );
}
