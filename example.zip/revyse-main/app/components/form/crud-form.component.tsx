import { useFetcher, useResolvedPath } from "@remix-run/react";
import { Button } from "../button.component";
import { PhotoIcon, XCircleIcon } from "@heroicons/react/20/solid";
import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import type {
  ChangeEvent,
  ChangeEventHandler,
  KeyboardEvent,
  ReactNode,
} from "react";
import {
  DocumentIcon,
  InformationCircleIcon,
} from "@heroicons/react/24/outline";
import type { File } from "@prisma/client";
import { CrudTextAreaField } from "./textarea.component";
import { Toast } from "../toast.component";
import { CTA } from "../cta.component";
import AddVideoUrlModal from "../modals/add-video-url-modal.component";
import { tv } from "tailwind-variants";
import { get, isEmpty } from "lodash";
import { tvField } from "~/utils/global-tailwind-variants.utils";
import { IMAGE_EXTENSIONS, VIDEO_EXTENSIONS } from "~/utils/constants.utils";
import { Tooltip } from "../tooltip.component";
import { PdfPreview } from "../pdf-preview.component";
import { FormWithUploads } from "./form-with-uploads.component";

type CrudFormFieldBase = {
  name: string;
  label: ReactNode;
  showOptional?: boolean;
  tooltipText?: string;
  errors: string[];
  disabled?: boolean;
  onChange?: (event: ChangeEvent<HTMLInputElement>) => void;
  onKeyDown?: (event: KeyboardEvent<HTMLInputElement>) => void;
};

export type CrudFormFieldText = CrudFormFieldBase & {
  type: "text" | "number";
  description?: string;
  defaultValue: string | number | undefined;
  placeholder?: string;
  maxCharacters?: number;
  showMaxCharacters?: boolean;
  reactiveDefaultValue?: boolean;
};

export type CrudFormFieldWebsite = CrudFormFieldBase & {
  type: "website";
  placeholder: string;
  defaultValue: string | number | undefined;
};

export type CrudFormFieldTextArea = CrudFormFieldBase & {
  type: "textarea";
  defaultValue: string | number | undefined;
  description?: string;
  placeholder?: string;
  rows?: number;
  maxCharacters?: number;
};

export type CrudFormFieldSelect = CrudFormFieldBase & {
  type: "select";
  defaultValue: string | number | undefined | string[];
  options: (
    | { label: string; value: string | number }
    | { group: string; options: { label: string; value: string }[] }
  )[];
  allowNull?: boolean;
  nullLabel?: string;
  multiple?: boolean;
  description?: string;
  reactiveDefaultValue?: boolean;
};

export type CrudFormFieldAutocomplete = CrudFormFieldBase & {
  type: "autocomplete";
  options:
    | { label: string; value: string }[]
    | { group: string; options: { label: string; value: string }[] }[];
  allowNull?: boolean;
  multiple?: boolean;
  description?: string;
  onSelect?: (value: string) => void;
  placeholder?: string;
  optionsContainerClass?: string;
  position?: "top" | "bottom";
} & (
    | {
        defaultValue: string | undefined;
        multiple?: false | undefined;
      }
    | {
        defaultValue: string[];
        multiple: true;
      }
  );

export type CrudFormFieldCheckbox = CrudFormFieldBase & {
  type: "checkbox";
  description?: string;
  defaultChecked: boolean | undefined;
  value?: string | number | undefined;
  reactiveDefaultChecked?: boolean;
};

export type CrudFormFieldRadioButton = CrudFormFieldBase & {
  type: "radio";
  description: string;
  defaultChecked?: boolean | undefined;
  checked?: boolean;
  value?: string | number | undefined;
};

export type CrudFormFieldFileUploadDefaultValue = Pick<
  File,
  "id" | "title" | "uri"
>;

interface VideoTitle {
  id: string;
  title: string;
}

export type CrudFormFieldFileUpload = CrudFormFieldBase & {
  type: "file-upload" | "image-upload";
  description?: string;
  buttonLabel: string;
  maxFileSize: number;
  accept?: string;
  handleCallback?: any;
  videoTitles?: VideoTitle[];
  limit?: number;
  currentCount?: number;
  showMaxError?: boolean;
  defaultNoValue?: ReactNode;
  square?: boolean;
} & (
    | {
        defaultValue: CrudFormFieldFileUploadDefaultValue | undefined;
        multiple?: false | undefined;
        allowRemoval?: boolean;
      }
    | {
        defaultValue: CrudFormFieldFileUploadDefaultValue[];
        multiple: true;
        allowRemoval?: true;
      }
  );

type CloudVideo = {
  title: string;
  url: string;
  type: "youtube";
  embedUrl: string;
};

export type CrudFormFieldYoutubeUrls = CrudFormFieldBase & {
  buttonLabel: string;
  onChange: (videos: CloudVideo[]) => void;
  defaultValue: CloudVideo[];
  limit?: number;
  currentCount?: number;
  showMaxError?: boolean;
};

export type CrudCustomField = {
  name: string;
  type: "custom";
  render: () => ReactNode;
};

export type AtomicCrudFormField =
  | CrudFormFieldText
  | CrudFormFieldTextArea
  | CrudFormFieldWebsite
  | CrudFormFieldSelect
  | CrudFormFieldCheckbox
  | CrudFormFieldRadioButton
  | CrudFormFieldFileUpload
  | CrudFormFieldAutocomplete
  | CrudCustomField;

export type CrudFormFieldGroup = {
  type: "group";
  name: string;
  fields: AtomicCrudFormField[];
};

export type CrudFormField = AtomicCrudFormField | CrudFormFieldGroup;

export type CrudFormSection = {
  title: string;
  subtitle: ReactNode;
  fields: CrudFormField[];
};

export type CrudFormConfig = {
  submitSuccess?: boolean;
  sections: CrudFormSection[];
  manager?: boolean;
  customToastMessage?: string;
  showToast?: boolean;
};

export function CrudWebsiteField({ field }: { field: CrudFormFieldWebsite }) {
  return (
    <div key={field.name} className="sm:col-span-4">
      <label
        htmlFor={field.name}
        className="block text-sm font-medium leading-6 text-gray-900"
      >
        {field.label}
        {field.showOptional && (
          <span className="text-md font-normal text-gray-400 text-sm ml-1.5">
            (Optional)
          </span>
        )}
        {field.tooltipText && (
          <Tooltip text={field.tooltipText} position="top">
            <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
          </Tooltip>
        )}
      </label>
      <div className="mt-2">
        <div className="flex rounded-md shadow-sm ring-1 ring-inset ring-gray-300 focus-within:ring-2 focus-within:ring-inset focus-within:ring-sky-600 sm:max-w-md">
          <span className="flex select-none items-center pl-3 text-gray-500 sm:text-sm">
            https://
          </span>
          <input
            type="text"
            name={field.name}
            id={field.name}
            className="block flex-1 border-0 bg-transparent py-1.5 pl-1 text-gray-900 placeholder:text-gray-400 focus:ring-0 sm:text-sm sm:leading-6"
            placeholder={field.placeholder}
            disabled={field.disabled}
          />
        </div>
        <p
          className="mt-3 text-sm leading-6 text-red-600"
          id={`errors-${field.name}`}
        >
          {field.errors?.join(" ")}
        </p>
      </div>
    </div>
  );
}

export function CrudTextField({
  field,
  className,
}: {
  field: CrudFormFieldText;
  className?: string;
}) {
  // Handle the character limit if maxCharacters is present
  const [characterCount, setCharacterCount] = useState(
    field.defaultValue?.toString().length ?? 0
  );

  const handleCharacterChange = (
    event: React.ChangeEvent<HTMLInputElement>
  ) => {
    const inputValue = event.target.value;
    setCharacterCount(inputValue.length);

    if (field.onChange) field.onChange(event);
  };

  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (
      field.reactiveDefaultValue &&
      inputRef.current &&
      field.defaultValue !== undefined
    ) {
      inputRef.current.value = field.defaultValue as string;
    }
  }, [field.defaultValue, field.reactiveDefaultValue]);

  return (
    <div className={`col-span-full ${className}`}>
      <label
        htmlFor={field.name}
        className="block text-sm font-medium leading-6 text-gray-900"
      >
        {field.label}
        {field.showOptional && (
          <span className="text-md font-normal text-gray-400 text-sm ml-1.5">
            (Optional)
          </span>
        )}
        {field.tooltipText && (
          <Tooltip text={field.tooltipText} position="top">
            <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
          </Tooltip>
        )}
      </label>
      <div className="mt-2">
        <input
          type={field.type}
          name={field.name}
          id={field.name}
          defaultValue={field.defaultValue}
          placeholder={field.placeholder}
          className={tvField({ error: field.errors.length > 0 })}
          disabled={field.disabled}
          onChange={
            field.maxCharacters ? handleCharacterChange : field.onChange
          }
          onKeyDown={field.onKeyDown}
          maxLength={field.maxCharacters}
          ref={inputRef}
        />
      </div>
      <p className="mt-1 text-xs text-gray-500 px-2">{field.description}</p>
      <p
        className="mt-3 text-sm leading-6 text-red-600"
        id={`errors-${field.name}`}
      >
        {field.errors?.join(" ")}
      </p>
      {field.maxCharacters && field.showMaxCharacters !== false ? (
        <p
          id={`${field.name}-characterCount`}
          className="mt-1 text-xs text-gray-500"
        >
          {characterCount}/{field.maxCharacters} characters
        </p>
      ) : null}
    </div>
  );
}

export function CrudSelectField({
  field,
  onChange,
}: {
  field: CrudFormFieldSelect;
  onChange?: ChangeEventHandler<HTMLSelectElement>;
}) {
  const inputRef = useRef<HTMLSelectElement | null>(null);

  useEffect(() => {
    if (field.reactiveDefaultValue && inputRef.current && field.defaultValue) {
      inputRef.current.value = field.defaultValue as string;
    }
  }, [field.defaultValue, field.reactiveDefaultValue]);

  return (
    <div className="col-span-full">
      <label
        htmlFor={field.name}
        className="block text-sm font-medium leading-6 text-gray-900"
      >
        {field.label}
        {field.showOptional && (
          <span className="text-md font-normal text-gray-400 text-sm ml-1.5">
            (Optional)
          </span>
        )}
        {field.tooltipText && (
          <Tooltip text={field.tooltipText} position="top">
            <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
          </Tooltip>
        )}
      </label>
      <div className="mt-2">
        <select
          ref={inputRef}
          id={field.name}
          name={field.name}
          className={tvField({ error: field.errors.length > 0 })}
          defaultValue={field.defaultValue ?? "null"}
          disabled={field.disabled}
          multiple={field.multiple}
          onChange={onChange}
        >
          <option value="null" disabled={!field.allowNull}>
            {field.allowNull ? field.nullLabel ?? "None" : "Please Select"}
          </option>
          {field.options.map(option =>
            "group" in option ? (
              <optgroup key={option.group} label={option.group}>
                {option.options.map(option => (
                  <option key={option.value} value={option.value}>
                    {option.label}
                  </option>
                ))}
              </optgroup>
            ) : (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            )
          )}
        </select>
        {field.description && (
          <p className="text-xs text-gray-500 leading-6 py-2">
            {field.description}
          </p>
        )}
        <p
          className="mt-3 text-sm leading-6 text-red-600"
          id={`errors-${field.name}`}
        >
          {field.errors?.join(" ")}
        </p>
      </div>
    </div>
  );
}

export function CrudAutocompleteField({
  field,
  onChange,
}: {
  field: CrudFormFieldAutocomplete;
  onChange?: ChangeEventHandler<HTMLSelectElement>;
}) {
  const [autocompleteValue, setAutocompleteValue] = useState("");

  const [focused, setFocused] = useState(false);

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    const { value } = e.target;
    setAutocompleteValue(value);
  };

  useEffect(() => {
    setAutocompleteValue("");
  }, [field.defaultValue, field.multiple]);

  const options = useMemo(() => {
    if (field.options.length === 0) return [];

    if (autocompleteValue) {
      if ("group" in field.options[0]) {
        return field.options
          .map(group => {
            const groupOptions =
              get(group, "options") ||
              ([] as { label: string; value: string }[]);

            return {
              ...group,
              options: groupOptions.filter(option =>
                autocompleteValue
                  ? option.label
                      .toLowerCase()
                      .includes(autocompleteValue?.toLowerCase())
                  : true
              ),
            };
          })
          .filter(group => group.options.length > 0);
      }
      return field.options.filter(option =>
        (option as { label: string; value: string }).label
          .toLowerCase()
          .includes(autocompleteValue?.toLowerCase())
      );
    }
    return field.options;
  }, [field.options, autocompleteValue]);

  const onSelect = useCallback(
    (value: string) => {
      if (field.multiple) {
        // TODO
      } else {
        field.onSelect?.(value);
      }
    },
    [field]
  );

  return (
    <div
      className="col-span-full"
      onFocus={() => setFocused(true)}
      onBlur={() => setFocused(false)}
    >
      <label
        htmlFor={field.name}
        className="block text-sm font-medium leading-6 text-gray-900"
      >
        {field.label}
        {field.showOptional && (
          <span className="text-md font-normal text-gray-400 text-sm ml-1.5">
            (Optional)
          </span>
        )}
        {field.tooltipText && (
          <Tooltip text={field.tooltipText} position="top">
            <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
          </Tooltip>
        )}
      </label>
      <div className="relative w-full h-fit">
        <CrudTextField
          field={{
            name: field.name,
            label: "",
            errors: field.errors,
            type: "text",
            placeholder: field.placeholder,
            defaultValue: autocompleteValue,
            onChange: handleInputChange,
          }}
        />
        {autocompleteValue && options.length > 0 && (
          <div
            className={`
            ${focused ? "" : "hidden"}
            ${field.position == "top" ? "bottom-4 shadow" : "top-8 shadow-lg"} 
            rounded-lg p-2 overflow-hidden bg-sky-50 w-3/6 mb-6 absolute overflow-y-auto max-h-48 
            ${field.optionsContainerClass}`}
          >
            <div
              className="divide-y divide-solid divide-gray-200"
              onMouseDown={e => e.preventDefault()}
            >
              {!isEmpty(options) &&
                options.map((option, index) => {
                  if ("group" in option) {
                    return (
                      <div key={option.group} className="py-2">
                        <div className="text-xs text-gray-500 mb-2">
                          {option.group}
                        </div>
                        {option.options.map((option, index) => {
                          return (
                            <div
                              key={index}
                              id={`${field.name}-option-${option.value}`}
                              onClick={() => onSelect(option.value)}
                              className="flex items-center p-2 hover:bg-sky-100 rounded-md transition ease-in-out duration-100"
                            >
                              {option.label}
                            </div>
                          );
                        })}
                      </div>
                    );
                  } else {
                    return (
                      <div
                        key={index}
                        id={`${field.name}-option-${option.value}`}
                        onClick={() => onSelect(option.value)}
                        className="flex items-center p-2 hover:bg-sky-100 rounded-md transition ease-in-out duration-100"
                      >
                        {option.label}
                      </div>
                    );
                  }
                })}
            </div>
          </div>
        )}
      </div>
      <div className="mt-2">
        {field.description && (
          <p className="text-xs text-gray-500 leading-6 py-2">
            {field.description}
          </p>
        )}
      </div>
    </div>
  );
}

const tvUploadPreview = tv({
  base: "object-contain max-w-full h-auto flex",
});

export function CrudFileUpload({
  field,
  videoTitles,
  showPreviews = true,
}: {
  field: CrudFormFieldFileUpload;
  videoTitles?: VideoTitle[];
  showPreviews?: Boolean;
}) {
  field.multiple = field.multiple ?? false;
  const [files, setFiles] = useState<string[]>([]);
  const [errors, setErrors] = useState(field.errors);
  // Recalculate the images that need to be displayed when the value of field.defaultValue changes
  const defaultFiles = useMemo(
    () =>
      field.multiple
        ? field.defaultValue
        : field.defaultValue
        ? [field.defaultValue]
        : [],
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [field.multiple, JSON.stringify(field.defaultValue)]
  );

  const fetcher = useFetcher();
  const { pathname: action } = useResolvedPath("/remove-file");
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Reset the input value when `images` changes
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.value = "";
      setFiles([]);
    }
  }, [defaultFiles]);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const okFiles = [];
    let hasError = false;
    for (const file of e.target.files ?? []) {
      if (file.size <= field.maxFileSize) {
        okFiles.push(file);
      } else {
        hasError = true;
      }
    }
    if (hasError) {
      setErrors([...field.errors, "One or more files are too large"]);
      e.target.value = "";
      setFiles([]);
    } else {
      setErrors([...field.errors]);
      setFiles(okFiles.map(f => f.name));
    }

    if (field.onChange) field.onChange(e);
  };

  const handleFileRemoval = (idToRemove: string) => {
    setFiles(prevFiles => prevFiles.filter(file => file !== idToRemove));
  };

  const canUploadMore = useMemo(() => {
    return field.limit && field.currentCount
      ? field.currentCount < field.limit
      : true;
  }, [field.limit, field.currentCount]);

  return (
    <div className="col-span-full">
      <label
        htmlFor={field.name}
        className={`block text-sm font-medium leading-6 text-gray-900 ${
          !showPreviews && "flex items-center gap-x-2"
        }`}
      >
        <span>
          {field.label}
          {field.showOptional && (
            <span className="text-md font-normal text-gray-400 text-sm ml-1.5">
              (Optional)
            </span>
          )}
          {field.tooltipText && (
            <Tooltip text={field.tooltipText} position="top">
              <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
            </Tooltip>
          )}
        </span>
        <p className="text-gray-500 text-xs">{field.description}</p>
        <p className="text-gray-500 text-xs">
          Max File Size: {field.maxFileSize / 1024 / 1024} MB
        </p>
      </label>
      <div className="mt-2 flex flex-col items-start gap-x-3">
        <div className="flex flex-wrap w-full">
          {showPreviews &&
            (defaultFiles.length > 0 ? (
              defaultFiles.map((file, index) => {
                const ext = file.uri.split(".").pop() ?? "";
                return (
                  <div key={file.id} className="relative m-2 h-auto w-56">
                    <a
                      href={`/images/${file.id}`}
                      target="_blank"
                      rel="noreferrer"
                      className="flex h-56 w-56 overflow-hidden rounded-md border-2 border-gray-200"
                    >
                      <div className="flex w-full h-auto hover:brightness-75 transition duration-300 justify-center">
                        {IMAGE_EXTENSIONS.includes(ext) ||
                        field.type == "image-upload" ? (
                          <img
                            src={`/images/${file.id}`}
                            className={tvUploadPreview()}
                            alt="banner"
                          />
                        ) : VIDEO_EXTENSIONS.includes(ext) ? (
                          <video
                            src={`/images/${file.id}`}
                            className={tvUploadPreview()}
                          />
                        ) : ext === "pdf" ? (
                          <PdfPreview
                            pdfUrl={`/images/${file.id}`}
                            className={tvUploadPreview()}
                          />
                        ) : ext === "mp3" ? (
                          <div
                            className={tvUploadPreview({
                              className: "justify-center items-center px-2",
                            })}
                          >
                            <audio src={`/images/${file.id}`} controls />
                          </div>
                        ) : (
                          <div
                            className={tvUploadPreview({
                              className:
                                "text-gray-700 flex justify-start items-center p-3",
                            })}
                          >
                            <DocumentIcon
                              className="w-16 min-w-16"
                              aria-hidden="true"
                            />
                            <span className="[text-wrap:pretty]">
                              {file.title || file.uri.split("/").pop()}
                            </span>
                          </div>
                        )}
                      </div>
                    </a>
                    {(field.multiple || field.allowRemoval) && (
                      <button
                        type="button"
                        onClick={() => {
                          fetcher.submit(
                            {
                              file_id: file.id,
                            },
                            {
                              method: "post",
                              action,
                              encType: "multipart/form-data",
                            }
                          );
                          handleFileRemoval(file.id);
                          return false;
                        }}
                      >
                        <XCircleIcon className="h-5 absolute -top-2 -right-2 bg-white rounded-full" />
                      </button>
                    )}
                    {videoTitles && (
                      <>
                        <input
                          type="hidden"
                          name="brand_video_titles.id"
                          value={videoTitles[index].id}
                        />
                        <CrudTextField
                          field={{
                            name: "brand_video_titles.title",
                            label: "",
                            type: "text",
                            placeholder: `Title for video ${index + 1}`,
                            defaultValue: videoTitles[index]
                              ? videoTitles[index].title
                              : "",
                            onChange: e => {
                              field.handleCallback(index, e.target.value);
                            },
                            errors: [],
                            maxCharacters: 30,
                          }}
                        />
                      </>
                    )}
                  </div>
                );
              })
            ) : field.defaultNoValue ? (
              field.defaultNoValue
            ) : (
              <PhotoIcon
                className="h-12 w-12 text-gray-300"
                aria-hidden="true"
              />
            ))}
        </div>
        <div className="flex space-x-3">
          <button
            type="button"
            className="mt-2 rounded-md bg-white px-2.5 py-1.5 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50"
            onClick={() => {
              const fileInput = document.getElementById(field.name);
              fileInput?.click();
            }}
            disabled={!canUploadMore}
          >
            Choose File{field.multiple ? "s" : ""}
          </button>
          {field.limit !== undefined && field.currentCount !== undefined && (
            <span
              className={`text-sm mt-auto mb-1 ${
                field.showMaxError ? "text-red-600 font-bold" : ""
              }`}
            >
              {`${field.currentCount} / ${field.limit}`} max videos
              <span className="text-xs font-extralight">
                {" "}
                (uploads & YouTube URLs)
              </span>
            </span>
          )}
        </div>
        <input
          ref={inputRef}
          id={field.name}
          name={field.name}
          type="file"
          className="sr-only"
          onChange={handleFile}
          multiple={field.multiple}
          accept={field.accept ? `${field.accept}/*` : "/*"}
        />
        <div>
          {files.map(file => (
            <div key={file}>{file}</div>
          ))}
        </div>
        <div className="text-red-600 text-sm py-2" id={`errors-${field.name}`}>
          {errors}
        </div>
      </div>
    </div>
  );
}

export function CrudVideoUrlsField({
  field,
  showPreviews = true,
}: {
  field: CrudFormFieldYoutubeUrls;
  showPreviews?: Boolean;
}) {
  const videos = field.defaultValue;

  const [openAddNewUrlModal, setOpenAddNewUrlModal] = useState(false);

  const handleRemoval = useCallback(
    (toRemove: CloudVideo) => {
      const newVideosList = field.defaultValue.filter(
        video => video !== toRemove
      );
      field.onChange([...newVideosList]);
    },
    [field]
  );

  const handleAdd = useCallback(
    (video: CloudVideo) => {
      setOpenAddNewUrlModal(false);
      const newVideosList = [...field.defaultValue, video];
      field.onChange([...newVideosList]);
    },
    [field]
  );

  const handleTitleChange = useCallback(
    (index: number, title: string) => {
      const newVideosList = [...field.defaultValue];
      newVideosList[index].title = title;
      field.onChange([...newVideosList]);
    },
    [field]
  );

  const canUploadMore = useMemo(() => {
    return field.limit && field.currentCount
      ? field.currentCount < field.limit
      : true;
  }, [field.limit, field.currentCount]);

  return (
    <>
      <AddVideoUrlModal
        isOpen={openAddNewUrlModal}
        onClose={() => setOpenAddNewUrlModal(false)}
        onAddVideo={handleAdd}
      ></AddVideoUrlModal>
      <div className="col-span-full">
        <label
          htmlFor={field.name}
          className={`block text-sm font-medium leading-6 text-gray-900 ${
            !showPreviews && "flex items-center gap-x-2"
          }`}
        >
          {field.label}
          {field.showOptional && (
            <span className="text-md font-normal text-gray-400 text-sm ml-1.5">
              (Optional)
            </span>
          )}
          {field.tooltipText && (
            <Tooltip text={field.tooltipText} position="top">
              <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
            </Tooltip>
          )}
        </label>
        <div className="mt-2 flex flex-col items-start gap-x-3">
          <div className="grid grid-cols-1 lg:grid-cols-3 w-max">
            {showPreviews &&
              (videos.length > 0 ? (
                videos.map((video, index) => {
                  return (
                    <div key={video.url} className="relative m-2">
                      <a href={video.url} target="_blank" rel="noreferrer">
                        <iframe
                          className="h-28 aspect-video p-2"
                          src={video.embedUrl}
                          title="YouTube video player"
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                          allowFullScreen
                        ></iframe>
                      </a>
                      <button
                        type="button"
                        onClick={() => {
                          handleRemoval(video);
                        }}
                      >
                        <XCircleIcon className="h-5 absolute -top-2 -right-2" />
                      </button>
                      <CrudTextField
                        field={{
                          name: "",
                          label: "",
                          type: "text",
                          placeholder: `Title for video ${index + 1}`,
                          defaultValue: video.title,
                          onChange: e => {
                            handleTitleChange(index, e.target.value);
                          },
                          errors: [],
                          maxCharacters: 30,
                        }}
                      />
                    </div>
                  );
                })
              ) : (
                <PhotoIcon
                  className="h-12 w-12 text-gray-300"
                  aria-hidden="true"
                />
              ))}
          </div>
          <div className="flex space-x-3">
            <button
              type="button"
              className="mt-2 rounded-md bg-white px-2.5 py-1.5 text-sm font-semibold text-gray-900 shadow-sm ring-1 ring-inset ring-gray-300 hover:bg-gray-50"
              onClick={() => {
                setOpenAddNewUrlModal(true);
              }}
              disabled={!canUploadMore}
            >
              {field.buttonLabel}
            </button>
            {field.limit !== undefined && field.currentCount !== undefined && (
              <span
                className={`text-sm mt-auto mb-1 ${
                  field.showMaxError ? "text-red-600 font-bold" : ""
                }`}
              >
                {`${field.currentCount} / ${field.limit}`} max videos
                <span className="text-xs font-extralight">
                  {" "}
                  (uploads & YouTube URLs)
                </span>
              </span>
            )}
          </div>
          <input
            type="hidden"
            name={field.name}
            value={JSON.stringify(videos)}
          />
        </div>
        <div className="text-red-600 text-sm py-2" id={`errors-${field.name}`}>
          {field.errors}
        </div>
      </div>
    </>
  );
}

export function CrudGroupField({
  field: group,
}: {
  field: CrudFormFieldGroup;
}) {
  return (
    <div className="flex sm:col-span-6">
      {group.fields.map(field => {
        const name = `${group.name}.${field.name}`;
        const formField =
          field.type === "textarea" ? (
            <CrudTextAreaField
              key={field.name}
              field={{ ...field, name, rows: 4 }}
            />
          ) : field.type === "text" ? (
            <CrudTextField key={field.name} field={{ ...field, name }} />
          ) : (
            <div>Field type: {group.type} not supported in group</div>
          );
        return (
          <div className="flex-grow mr-2 mb-2" key={field.name}>
            {formField}
          </div>
        );
      })}
    </div>
  );
}

export function CrudCheckboxField({
  field,
  className,
  onChange,
}: {
  field: CrudFormFieldCheckbox;
  className?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}) {
  field.value = field.value ?? "true";

  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (field.reactiveDefaultChecked && inputRef.current) {
      inputRef.current.checked = !!field.defaultChecked;
    }
  }, [field.defaultChecked, field.reactiveDefaultChecked]);

  return (
    <div className={`flex gap-x-3 sm:col-span-4 ${className}`}>
      <div className="flex h-6 items-center">
        <input
          id={field.name}
          name={field.name}
          type="checkbox"
          className="h-4 w-4 rounded border-gray-30 focus:ring-sky-600 accent-sky-600 text-sky-600"
          value={field.value}
          defaultChecked={field.defaultChecked}
          onChange={onChange}
          ref={inputRef}
        />
      </div>
      <div className="text-sm leading-6">
        <label htmlFor="comments" className="font-medium text-gray-900">
          {field.label}
        </label>
        {field.tooltipText && (
          <Tooltip text={field.tooltipText} position="top">
            <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
          </Tooltip>
        )}
        {field.description && (
          <p className="text-gray-500">{field.description}</p>
        )}
        <p
          className="mt-3 text-sm leading-6 text-red-600"
          id={`errors-${field.name}`}
        >
          {field.errors?.join(" ")}
        </p>
      </div>
    </div>
  );
}

export function CrudRadioButtonField({
  field,
  className,
}: {
  field: CrudFormFieldRadioButton;
  className?: string;
}) {
  return (
    <div className={`flex gap-x-3 sm:col-span-4 ${className}`}>
      <div className="flex h-6 items-center">
        <input
          id={field.name}
          type="radio"
          className="h-4 w-4 border-gray-30 focus:ring-sky-600 accent-sky-600 text-sky-600"
          name={field.name}
          value={field.value}
          onChange={field.onChange}
          defaultChecked={field.defaultChecked}
          checked={field.checked}
        />
      </div>
      <div className="text-sm">
        <label htmlFor="comments" className="font-medium text-gray-900">
          {field.label}
        </label>
        <p className="text-gray-500">{field.description}</p>
        <p
          className="mt-3 text-sm leading-6 text-red-600"
          id={`errors-${field.name}`}
        >
          {field.errors?.join(" ")}
        </p>
      </div>
    </div>
  );
}

export function CrudDateField({
  field,
  className,
  minDate,
}: {
  field: CrudFormFieldText;
  className?: string;
  minDate?: string;
}) {
  const inputRef = useRef<HTMLInputElement | null>(null);

  useEffect(() => {
    if (field.reactiveDefaultValue && inputRef.current && field.defaultValue) {
      inputRef.current.value = field.defaultValue as string;
    }
  }, [field.defaultValue, field.reactiveDefaultValue]);

  return (
    <div className={`col-span-full ${className}`}>
      <label
        htmlFor={field.name}
        className="block text-sm font-medium leading-6 text-gray-900"
      >
        {field.label}
        {field.showOptional && (
          <span className="text-md font-normal text-gray-400 text-sm ml-1.5">
            (Optional)
          </span>
        )}
        {field.tooltipText && (
          <Tooltip text={field.tooltipText} position="top">
            <InformationCircleIcon className="h-5 text-gray-400 ml-1.5" />
          </Tooltip>
        )}
      </label>
      <div className="mt-2">
        <input
          type="date"
          name={field.name}
          id={field.name}
          defaultValue={field.defaultValue}
          placeholder={field.placeholder}
          min={minDate}
          className={tvField({ error: field.errors.length > 0 })}
          disabled={field.disabled}
          onChange={field.onChange}
          onKeyDown={field.onKeyDown}
          maxLength={field.maxCharacters}
          ref={inputRef}
        />
      </div>
      <p className="mt-1 text-xs text-gray-500 px-2">{field.description}</p>
      <p
        className="mt-3 text-sm leading-6 text-red-600"
        id={`errors-${field.name}`}
      >
        {field.errors?.join(" ")}
      </p>
    </div>
  );
}

const tvFormSection = tv({
  base: "grid grid-cols-1 gap-y-2 sm:grid-cols-6",
  variants: {
    spacing: {
      comfortable: "gap-y-8",
      compact: "gap-y-2",
    },
  },
  defaultVariants: {
    spacing: "comfortable",
  },
});

export function FormSection({
  title,
  subtitle,
  children,
  manager = false,
  spacing = "comfortable",
  border = true,
}: {
  title: string | ReactNode;
  children: ReactNode;
  subtitle?: ReactNode;
  manager?: boolean;
  spacing?: "comfortable" | "compact";
  border?: boolean;
}) {
  return manager ? (
    <div className="space-y-8">
      <div className="px-4 sm:px-0">
        <h2 className="text-lg lg:text-3xl font-semibold leading-7 text-gray-900">
          {title}
        </h2>
        <div className="mt-1 text-base leading-6 text-gray-600">{subtitle}</div>
      </div>
      <div className="grid grid-cols-1 gap-y-6 sm:grid-cols-6">{children}</div>
    </div>
  ) : (
    <div className="space-y-10 divide-y divide-gray-900/10">
      <div className="grid grid-cols-1 gap-x-8 gap-y-8 md:grid-cols-3 mb-6">
        <div className="px-4 pt-6 sm:px-0">
          <h2 className="text-base font-semibold leading-7 text-gray-900">
            {title}
          </h2>
          <div className="mt-1 text-sm leading-6 text-gray-600">{subtitle}</div>
        </div>

        <div
          className={`bg-white sm:rounded-xl md:col-span-2 ${
            border ? "ring-1 ring-gray-900/5 shadow-sm" : ""
          }`}
        >
          <div className="px-4 py-6 sm:p-8">
            <div className={tvFormSection({ spacing })}>{children}</div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function CrudForm({ config }: { config: CrudFormConfig }) {
  return (
    <FormWithUploads>
      {config.showToast && config.submitSuccess !== undefined && (
        <Toast
          variant={config.submitSuccess ? "success" : "error"}
          message={
            config.customToastMessage ??
            (config.submitSuccess
              ? "Success!"
              : "There were problems submitting your form. Please try again.")
          }
        />
      )}
      {config.sections.map((section, i) => (
        <FormSection
          key={section.title}
          title={section.title}
          subtitle={section.subtitle}
          manager={config.manager}
        >
          {section.fields.map((field, j) => {
            const key = `${i}-${j}-${field.name}`;
            switch (field.type) {
              case "website":
                return <CrudWebsiteField key={key} field={field} />;
              case "textarea":
                return <CrudTextAreaField key={key} field={field} />;
              case "select":
                return <CrudSelectField key={key} field={field} />;
              case "checkbox":
                return <CrudCheckboxField key={key} field={field} />;
              case "radio":
                return <CrudRadioButtonField key={key} field={field} />;
              case "file-upload":
              case "image-upload":
                return <CrudFileUpload key={key} field={field} />;
              case "group":
                return <CrudGroupField key={key} field={field} />;
              case "autocomplete":
                return <CrudAutocompleteField key={key} field={field} />;
              case "custom":
                return (
                  <React.Fragment key={key}> {field.render()} </React.Fragment>
                );
              default:
                return <CrudTextField key={key} field={field} />;
            }
          })}
        </FormSection>
      ))}
      {config.manager ? (
        <div className="flex items-center justify-end py-4">
          <CTA variant="sky-shadow" className="flex" type="submit">
            <>Save</>
          </CTA>
        </div>
      ) : (
        <div className="flex items-center justify-end gap-x-6 px-4 py-4 sm:px-8">
          <Button className="flex" type="submit" id="save-button">
            <>Save</>
          </Button>
        </div>
      )}
    </FormWithUploads>
  );
}
