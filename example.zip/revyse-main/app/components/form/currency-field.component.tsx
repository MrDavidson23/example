import type { ReactNode } from "react";
import MaskedInput from "react-text-mask";
import createNumberMask from "text-mask-addons/dist/createNumberMask";
import { tvField } from "~/utils/global-tailwind-variants.utils";

const defaultMaskOptions = {
  prefix: "$",
  suffix: "",
  includeThousandsSeparator: true,
  thousandsSeparatorSymbol: ",",
  allowDecimal: true,
  decimalSymbol: ".",
  decimalLimit: 2, // how many digits allowed after the decimal
  integerLimit: 11, // limit length of integer numbers
  allowNegative: false,
  allowLeadingZeroes: false,
};

export function CurrencyField({
  label,
  name,
  defaultValue,
  errors = [],
  className = "",
  disabled = false,
  onChange = () => {},
  description = "",
}: {
  label: string | ReactNode;
  name: string;
  defaultValue: number;
  errors?: string[];
  className?: string;
  disabled?: boolean;
  onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
  description?: string;
}) {
  const currencyMask = createNumberMask(defaultMaskOptions);
  return (
    <div className={`col-span-full ${className}`}>
      <label
        htmlFor={name}
        className="block text-sm font-medium leading-6 text-gray-900"
      >
        {label}
      </label>
      <div className="mt-2">
        <MaskedInput
          type="text"
          inputMode="numeric"
          mask={currencyMask}
          name={name}
          id={name}
          defaultValue={defaultValue}
          className={tvField({ className: "px-2", error: errors.length > 0 })}
          disabled={disabled}
          onChange={onChange}
        />
      </div>
      <p className="mt-1 text-xs text-gray-500 px-2">{description}</p>
      <p className="mt-3 text-sm leading-6 text-red-600">{errors?.join(" ")}</p>
    </div>
  );
}
