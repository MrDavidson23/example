import { Link } from "@remix-run/react";
import { tv } from "tailwind-variants";

const tvStatusChip = tv({
  base: "flex items-center gap-x-1 rounded-3xl px-3 py-1 border w-min font-normal capitalize text-center whitespace-nowrap",
  variants: {
    color: {
      green:
        "text-green-600 rounded-3xl border border-green-600 py-2 px-3 text-sm",
      red: "text-red-600 rounded-3xl border border-red-600 py-2 px-3 text-sm",
      sky: "text-sky-600 rounded-3xl border border-sky-600 py-2 px-3 text-sm",
    },
  },
});

export function Tag({
  label,
  color,
  className,
  icon,
  isLink = false,
  linkTo,
}: {
  label: string;
  color?: keyof typeof tvStatusChip.variants.color;
  className?: string;
  icon?: JSX.ElementType;
  isLink?: boolean;
  linkTo?: string;
}) {
  const Icon = icon as JSX.ElementType | undefined;

  return isLink && linkTo ? (
    <Link
      id="tag-link"
      to={linkTo}
      className={tvStatusChip({ color: color, className })}
    >
      {label}
    </Link>
  ) : (
    <div id="tag-div" className={tvStatusChip({ color: color, className })}>
      {Icon && <Icon className="h-4 w-4 lg:h-5 lg:w-5" />}
      {label}
    </div>
  );
}
