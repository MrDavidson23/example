import type {
  Product,
  ProductCategory,
  ProductReview,
  Vendor,
} from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { useFetcher, useNavigate } from "@remix-run/react";
import { useState } from "react";
import { Avatar } from "./avatar.component";
import { isNil } from "lodash";
import {
  HandThumbUpIcon,
  QuestionMarkCircleIcon,
} from "@heroicons/react/24/outline";
import StarRating from "./star-rating.component";
import dayjs from "dayjs";
import { StarIcon } from "@heroicons/react/20/solid";
import relativeTime from "dayjs/plugin/relativeTime";
import { Tooltip } from "./tooltip.component";
import { JsonLd } from "react-schemaorg";
import type { Review } from "schema-dts";
dayjs.extend(relativeTime);

export type ProductInput = SerializeFrom<
  Product & {
    vendor: SerializeFrom<Vendor> | null;
    primary_category: SerializeFrom<ProductCategory>;
  }
>;

export type ReviewsInput = {
  reviews: SerializeFrom<
    ProductReview & {
      user: {
        first_name: string | null;
        last_name: string | null;
        title: string | null;
        company_name: string | null;
      };
      responded_by: {
        first_name: string | null;
        last_name: string | null;
        title: string | null;
      } | null;
      _count: { helpfuls: number };
    }
  >[];
  averages: {
    value_score: number | null;
    compatibility_score: number | null;
    customer_service_score: number | null;
    onboarding_score: number | null;
  };
  total_count: number;
};

function ReviewQuestion({
  question,
  answer,
  className,
}: {
  question: string;
  answer: string;
  className?: string;
}) {
  return (
    <div className={className}>
      <p className="mb-4">{question}</p>
      <div className="text-sm">{answer}</div>
    </div>
  );
}

export function Review({
  product,
  review,
  user,
  defaultExpanded = false,
  aggRating,
  reviewCount,
}: {
  product: ProductInput;
  review: ReviewsInput["reviews"][number];
  user: { id: string } | null;
  defaultExpanded?: boolean;
  aggRating?: number;
  reviewCount?: number;
}) {
  const [isExpanded, setIsExpanded] = useState(defaultExpanded);
  const avgRating =
    (review.value_score +
      review.compatibility_score +
      review.customer_service_score +
      review.onboarding_score) /
    4.0;
  const fetcher = useFetcher();
  const navigate = useNavigate();

  return (
    <div
      key={review.id}
      className="rounded-lg shadow-lg pl-20 lg:pl-24 p-4 lg:p-6 relative mt-10"
    >
      <JsonLd<Review>
        item={{
          "@context": "https://schema.org",
          "@type": "Review",
          itemReviewed: {
            "@type": "Product",
            name: product.title,
            manufacturer: product.vendor!.name,
            description: product.description,
            category: product.primary_category.name,
            aggregateRating:
              aggRating && reviewCount
                ? {
                    "@type": "AggregateRating",
                    ratingValue: aggRating,
                    reviewCount: reviewCount,
                  }
                : undefined,
          },
          reviewRating: {
            "@type": "Rating",
            ratingValue: avgRating.toFixed(1),
          },
          datePublished: dayjs(review.created_at).format("YYYY-MM-DD"),
          reviewBody: `What do you like most about ${product.title}? ${review.like_most}`,
          author: {
            "@type": "Person",
            name:
              review.user.first_name! + review.show_last_name
                ? review.user.last_name!
                : `${review.user.last_name?.substring(0, 1)}.`,
          },
        }}
      ></JsonLd>
      <Avatar
        first_name={review.user.first_name!}
        last_name={review.user.last_name!}
        className="absolute left-4 lg:left-8"
      />
      <div className="flex justify-between">
        <div>
          <div className="font-medium text-lg" itemProp="author">
            {review.user.first_name}{" "}
            {review.show_last_name
              ? review.user.last_name
              : `${review.user.last_name?.substring(0, 1)}.`}
          </div>
          <div className="text-sm text-gray-500 font-light">
            {review.show_job_title && review.user.title}
            {review.show_job_title && review.show_company && ", "}
            {review.show_company && review.user.company_name}
          </div>
        </div>
        <button
          id={`mark-helpful-${review.id}`}
          onClick={() => {
            if (isNil(user)) {
              navigate(
                `/login?redirectTo=${encodeURIComponent(
                  `/reviews/${review.id}/helpful`
                )}`
              );
            } else {
              fetcher.submit(
                {
                  helpful: "true",
                },
                {
                  action: `/reviews/${review.id}/helpful`,
                  method: "post",
                  encType: "multipart/form-data",
                }
              );
            }
            return false;
          }}
          className="flex items-center text-lato text-sm text-sky-600"
        >
          <HandThumbUpIcon className="h-6 mr-1" /> Mark as Helpful (
          {review._count.helpfuls})
        </button>
      </div>
      <div className="flex items-center text-xs mt-2">
        <StarRating rating={avgRating} className="mr-2" />{" "}
        <p>
          {avgRating.toFixed(1)} - {dayjs(review.created_at).fromNow()}
        </p>
      </div>
      <div className="flex flex-row space-x-3 text-neutral-400 font-light text-sm mt-3">
        {review.vendor_invited && (
          <Tooltip
            position="right"
            text="Reviewer was invited by Revyse on the Vendor’s behalf, and given a nominal incentive for their time and honest feedback."
          >
            <div className="flex flex-row items-center space-x-1 cursor-pointer">
              <span>Vendor Invite</span>
              <QuestionMarkCircleIcon className="h-5" />
            </div>
          </Tooltip>
        )}
        {review.incentivized && (
          <Tooltip
            position="right"
            text="Reviewer was given a nominal incentive for their time and honest feedback."
          >
            <div className="flex flex-row items-center space-x-1 cursor-pointer">
              <span>Incentivized</span>
              <QuestionMarkCircleIcon className="h-5" />
            </div>
          </Tooltip>
        )}
      </div>
      <div className="my-6">
        <div
          className={`grid grid-cols-1 gap-4 relative overflow-hidden ${
            isExpanded ? "max-h-auto" : "max-h-52"
          }`}
        >
          <h3>{review.title}</h3>
          <ReviewQuestion
            question={`What was your company’s primary use case for ${product.title}?`}
            answer={review.primary_use_case}
            className=""
          />
          <ReviewQuestion
            question={`What do you like most about ${product.title}?`}
            answer={review.like_most}
          />
          <ReviewQuestion
            question={`What could ${product.title} do better?`}
            answer={review.dislike_most}
          />
          {review.recommend_to && (
            <ReviewQuestion
              question={`Who would you recommend ${product.title} to?`}
              answer={review.recommend_to}
            />
          )}
          <div className="grid grid-cols-2 gap-4 py-4">
            <p>Customer support and service</p>
            <div>
              <StarRating rating={review.customer_service_score} />{" "}
            </div>
            <div className="col-span-2 text-sm">
              {review.customer_service_desc}
            </div>

            <p>Value for money</p>
            <div>
              <StarRating rating={review.value_score} />{" "}
            </div>
            <div className="col-span-2 text-sm">{review.value_desc}</div>

            <p>Ease of onboarding</p>
            <div>
              <StarRating rating={review.onboarding_score} />{" "}
            </div>
            <div className="col-span-2 text-sm">{review.onboarding_desc}</div>

            <p>Compatibility with your existing solutions</p>
            <div>
              <StarRating rating={review.compatibility_score} />{" "}
            </div>
            <div className="col-span-2 text-sm">
              {review.compatibility_desc}
            </div>
          </div>
          {!isExpanded && (
            <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-white h-16"></div>
          )}
        </div>
        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className="text-sm text-sky-600 mt-6 inline-block"
        >
          Read {isExpanded ? "less" : "more"}
        </button>
        {!isNil(review.responded_by) && (
          <div className="border-l border-grey-50 p-1 lg:p-4 mt-4">
            <div className="flex">
              <Avatar
                first_name={review.responded_by.first_name!}
                last_name={review.responded_by.last_name!}
                className="mr-4 hidden lg:flex"
              />
              <div>
                <div className="flex items-center">
                  {review.responded_by.first_name}{" "}
                  {review.responded_by.last_name![0]}.
                  <StarIcon className="text-yellow-400 h-4 ml-4 mr-2" />{" "}
                  <div className="text-xs">Official Vendor Response</div>
                </div>
                <div className="text-sm text-gray-400">
                  {review.responded_by.title ?? "Company Representative"},{" "}
                  {product.vendor?.name}
                </div>
              </div>
            </div>
            <p className="mt-4 text-sm">{review.response}</p>
          </div>
        )}
      </div>
    </div>
  );
}
