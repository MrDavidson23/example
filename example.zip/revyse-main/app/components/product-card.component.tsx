import { useNavigate } from "@remix-run/react";
import { Link } from "react-router-dom";
import StarRating from "./star-rating.component";
import { CTA } from "./cta.component";
import { CheckIcon } from "@heroicons/react/20/solid";
import { QuestionMarkCircleIcon } from "@heroicons/react/24/outline";
import { useState } from "react";
import { UnclaimedListingModal } from "./unclaimed-listing-modal.component";
import type { Tier } from "@prisma/client";
import { tierHasPermission } from "~/utils/permission.utils";
import { Tag } from "./tag.component";

export function ProductCard({
  product,
}: {
  product: {
    id: string;
    logo_file_id: string | null;
    slug: string;
    title: string;
    vendor_name: string;
    vendor_slug?: string | null;
    avg_score: number;
    vendor_logo_file_id?: string | null;
    cnt: number;
    description: string;
    good_for_tags?: { id: string; name: string }[];
    subCount: number;
    promo_text: string | null;
    tier: Tier;
  };
}) {
  const navigate = useNavigate();
  const [claimListingModalOpen, setClaimListingModalOpen] = useState(false);

  return (
    <>
      <UnclaimedListingModal
        isOpen={claimListingModalOpen}
        onClose={() => setClaimListingModalOpen(false)}
        product={product}
      />

      <div
        className="rounded border border-gray-100 shadow-md rounded-lg md:p-6 p-2  cursor-pointer"
        onClick={() => {
          navigate(`/products/${product.slug}`);
        }}
        id={`product-card-${product.id}`}
      >
        <div className="flex gap-3 md:gap-6">
          <div className="relative">
            <div
              className="w-36 h-36 bg-white border border-gray-100 bg-center bg-contain bg-no-repeat"
              style={{
                backgroundImage: product.logo_file_id
                  ? `url(/images/${product.logo_file_id})`
                  : product.vendor_logo_file_id
                  ? `url(/images/${product.vendor_logo_file_id})`
                  : "url(/assets/default-logo.png)",
              }}
            ></div>
            {product.subCount > 0 ? (
              <div
                className="text-green-600 text-xs flex my-2 gap-2"
                id="product-claimed-text"
              >
                <CheckIcon className="h-4" /> Claimed Listing
              </div>
            ) : (
              <button
                onClick={e => {
                  e.stopPropagation();
                  setClaimListingModalOpen(true);
                }}
                id={`claim-listing-button-${product.id}`}
                className="text-sky-600 text-xs flex my-2 gap-2"
              >
                <QuestionMarkCircleIcon className="h-4" /> Unclaimed Listing
              </button>
            )}
            {product.promo_text &&
              tierHasPermission(product.tier, "show_promo") && (
                <div
                  className="relative -ml-7 mt-4 bg-themeYellow text-darkGray rounded-r-3xl rounded-l-md text-xs py-2 pl-8 pr-4 font-semibold truncate"
                  id="product-promo-banner"
                >
                  {product.promo_text}
                </div>
              )}
          </div>
          <div className="w-full flex-shrink">
            <div className="flex justify-between items-start flex-wrap gap-y-2">
              <div>
                <h3 className="font-medium" id="product-name">
                  <Link to={`/products/${product.slug}`}>{product.title}</Link>
                </h3>
                <span className="text-gray-500 font-light">
                  by{" "}
                  <Link
                    to={`/vendors/${product.vendor_slug}`}
                    className="border-b border-b-gray-200"
                    id="product-vendor-name-link"
                  >
                    {product.vendor_name}
                  </Link>
                </span>
                <div className="flex gap-3 mt-2" id="product-rating">
                  <StarRating rating={product.avg_score} />
                  <span>{product.avg_score.toFixed(1)}</span>
                  <span className="text-gray-400">({product.cnt})</span>
                </div>
              </div>
              <CTA
                to={`/products/${product.slug}`}
                variant="sky-shadow"
                id={`view-product-button-${product.id}`}
              >
                View Details
              </CTA>
            </div>
            <div className="mt-6 hidden md:block">
              <p
                className="whitespace-normal line-clamp-3 truncate"
                id="product-description"
              >
                {product.description}
              </p>
              {tierHasPermission(product.tier, "show_good_for_tags") &&
                product.good_for_tags &&
                product.good_for_tags?.length > 0 && (
                  <div className="flex gap-6 mt-5">
                    <p className="w-20 text-md font-semibold">Good for</p>
                    <div className="flex-grow flex flex-wrap gap-2">
                      {product.good_for_tags.map(
                        (tag: { id: string; name: string }) => (
                          <div
                            key={tag.id}
                            id={`product-good-for-tag-${tag.id}`}
                          >
                            <Tag
                              isLink={true}
                              linkTo={`/search?query=${tag.name}`}
                              color="sky"
                              label={tag.name}
                              className="text-xs"
                            />
                          </div>
                        )
                      )}
                    </div>
                  </div>
                )}
            </div>
          </div>
        </div>
        <div className="mt-6 md:hidden">
          <div className="overflow-hidden leading-tight">
            <p className="whitespace-normal line-clamp-3 truncate">
              {product.description}
            </p>
          </div>
          {tierHasPermission(product.tier, "show_good_for_tags") &&
            product.good_for_tags &&
            product.good_for_tags?.length > 0 && (
              <div className="space-y-4 mt-4">
                <p className="w-20 text-md font-semibold">Good for</p>
                <div className="flex-grow flex flex-wrap gap-2">
                  {product.good_for_tags.map((tag: any) => (
                    <div key={tag.id} id={`product-good-for-tag-${tag.id}`}>
                      <Tag
                        isLink={true}
                        linkTo={`/search?query=${tag.name}`}
                        color="sky"
                        label={tag.name}
                        className="text-xs"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}
        </div>
      </div>
    </>
  );
}
