import type { ReactNode } from "react";
import { tv } from "tailwind-variants";

const tvCircleIcon = tv({
  base: "rounded-full border p-5",
  variants: {
    color: {
      yellow: "bg-yellow-50 border-yellow-500",
      gray: "bg-white border-gray-200",
    },
    size: {
      "6": "p-2",
      "8": "p-3",
      "16": "p-5",
    },
  },
  defaultVariants: {
    color: "yellow",
  },
});

export function IconCircle({
  Icon,
  color,
  size,
  className,
}: {
  Icon: (props: { className: string }) => ReactNode;
  color: "yellow" | "gray";
  size: "6" | "8" | "16";
  className?: string;
}) {
  return (
    <div className={tvCircleIcon({ size, color, className })}>
      <Icon className={`h-${size} w-${size}`} />
    </div>
  );
}
