import type { SerializeFrom } from "@remix-run/node";
import { Modal } from "./modal.component";
import { PlanChooser } from "./plan-chooser.component";
import type { Product, StripePrice, StripeProduct } from "@prisma/client";

export function PlanChooserModal({
  isOpen,
  onClose,
  product,
  onChoose,
  stripeProducts,
}: {
  isOpen: boolean;
  onClose: (closed: boolean) => void;
  onChoose: (
    stripeProduct: SerializeFrom<
      StripeProduct & { prices: SerializeFrom<StripePrice>[] }
    >,
    price: SerializeFrom<StripePrice>
  ) => void;
  product?: SerializeFrom<Product>;
  stripeProducts: SerializeFrom<
    StripeProduct & { prices: SerializeFrom<StripePrice>[] }
  >[];
}) {
  return (
    <Modal isOpen={isOpen} onClose={onClose} size="full">
      <PlanChooser
        onChoose={onChoose}
        title="Choose your plan"
        product={product}
        stripeProducts={stripeProducts}
      />
    </Modal>
  );
}
