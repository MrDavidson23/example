import { tv } from "tailwind-variants";

const tvToast = tv({
  base: "rounded-lg border p-4 my-4",
  variants: {
    color: {
      success: "bg-green-50  border-green-500  text-green-500",
      error: "bg-red-50 border-red-500 text-red-500",
    },
  },
});

export function Toast({
  variant,
  message,
}: {
  variant: keyof typeof tvToast.variants.color;
  message: string;
}) {
  return (
    <div className={tvToast({ color: variant })} id="toast">
      {message}
    </div>
  );
}
