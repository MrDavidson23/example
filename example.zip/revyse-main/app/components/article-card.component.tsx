import { ArrowUpRightIcon, CalendarIcon } from "@heroicons/react/24/outline";
import { Link } from "@remix-run/react";
import dayjs from "dayjs";
import relativeTime from "dayjs/plugin/relativeTime";
import { removeHtmlTags } from "../utils/string.utils";
import type { Post } from "@prisma/client";
dayjs.extend(relativeTime);

export function ArticleCard({ post }: { post: Post }) {
  return (
    <Link
      key={post.id}
      rel="noopener noreferrer"
      to={`/articles/${post.slug}`}
      className="max-w-lg h-min hover:no-underline focus:no-underline"
      id="article-card"
    >
      <div className="w-full rounded-xl relative group overflow-hidden h-36">
        <img
          role="presentation"
          className="object-cover w-full rounded-xl h-full"
          src={
            post.cover_image_url || "/assets/article-software-survival-kit.png"
          }
          alt="article cover"
          width="840"
          height="300"
        />
        <div className="absolute top-0 left-0 w-full h-full bg-sky-700 bg-opacity-70 flex items-center justify-center opacity-0 transition-opacity duration-200 cursor-pointer group-hover:opacity-100">
          <div className="flex flex-col text-white bg-coral p-3 rounded-full text-center">
            <ArrowUpRightIcon className="h-8"></ArrowUpRightIcon>
          </div>
        </div>
      </div>
      <div className="p-2 space-y-3">
        <h2 className="text-xl lg:text-2xl font-bold">{post.name}</h2>
        <div className="font-lg whitespace-normal line-clamp-3 truncate font-light">
          {removeHtmlTags(post.body || "...")}
        </div>
        <div className="flex flex-row space-x-6">
          <div className="flex flex-row space-x-2 items-center">
            <CalendarIcon className="h-6 text-gray-600" />
            <p className="text-sm lg:text-md font-light">
              {dayjs(post.published_at).fromNow()}
            </p>
          </div>
          {/* <div className='flex flex-row space-x-2'>
            <ChatBubbleBottomCenterTextIcon className='h-6 text-gray-600' />
            <p className='text-md font-light'>{post.comments_count}</p>
          </div> */}
        </div>
        <div className="flex flex-row space-x-3 items-center">
          <img
            className="object-cover w-8 h-8 rounded-full"
            src={post.user_avatar_url || "/assets/defaultAvatar.png"}
            alt="Avatar"
            height="32"
            width="32"
          />
          <p className="font-light text-gray-800">{post.user_name}</p>
        </div>
      </div>
    </Link>
  );
}
