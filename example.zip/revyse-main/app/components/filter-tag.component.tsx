import { XMarkIcon } from "@heroicons/react/24/outline";

export function FilterTag({ text, onRemove }: { text: any; onRemove: any }) {
  return (
    <div className="flex justify-center items-center w-full">
      <div className="gap-x-2 w-full bg-transparent border border-sky-500 rounded-full px-3 py-1.5 flex items-center text-sm">
        <button className="font-light" onClick={onRemove}>
          <XMarkIcon className="h-5 text-sky-500" />
        </button>
        <div className="text-center w-full truncate hyphens-auto break-words">
          {text}
        </div>
      </div>
    </div>
  );
}
