import { tv } from "tailwind-variants";
import { Tooltip } from "../tooltip.component";
import { isEmpty } from "lodash";

const tvWarningIcon = tv({
  base: "w-6 aspect-square inline",
});

export function WarningIcon({
  className,
  tooltip,
}: {
  className?: string;
  tooltip?: string;
}) {
  const image = (
    <img
      src="/assets/icon-warning.png"
      alt="Warning Icon"
      className={tvWarningIcon({ className })}
      height="72"
      width="72"
    />
  );

  return isEmpty(tooltip) ? (
    image
  ) : (
    <Tooltip text={tooltip} position="top" size="medium">
      {image}
    </Tooltip>
  );
}
