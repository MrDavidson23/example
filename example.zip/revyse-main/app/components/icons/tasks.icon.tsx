export function TasksIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="30"
      height="30"
      viewBox="0 0 30 30"
      fill="none"
      className={`aspect-square ${className}`}
    >
      <path
        d="M10.3457 4.3H28M2 3.97143L3.28395 5.28571L6.49383 2M2 13.8286L3.28395 15.1429L6.49383 11.8571M2 23.6857L3.28395 25L6.49383 21.7143M10.3457 14.1571H28M10.3457 24.0143H28"
        stroke="currentColor"
        strokeWidth="2.25"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}
