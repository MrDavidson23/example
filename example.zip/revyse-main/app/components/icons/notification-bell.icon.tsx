export function NotificationBell({ className }: { className?: string }) {
  return (
    <div className="relative">
      <svg
        viewBox="0 0 32 32"
        xmlns="http://www.w3.org/2000/svg"
        className={className}
      >
        {/* <defs>
          <style>
            .cls-1{fill:none;stroke:#000;stroke-linecap:round;stroke-linejoin:round;stroke-width:2px;}
          </style>
        </defs> */}
        <g
          fill="none"
          stroke="currentColor"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth="2.5"
        >
          <path d="M28,27l-3-3V12A9,9,0,0,0,7,12V24L4,27Z" />
          <path d="M12,27a4,4,0,0,0,8,0" />
          <line x1="16" x2="16" y1="3" y2="1" />
        </g>
      </svg>
      <div className="absolute hidden group-first/bell:block top-0.5 right-0.5 w-2.5 h-2.5 rounded-full bg-yellow-400 border border-white"></div>
    </div>
  );
}
