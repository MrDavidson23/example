import { DocumentIcon, XMarkIcon } from "@heroicons/react/24/outline";
import type { File as PrismaFile } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { isEmpty } from "lodash";
import React, { useCallback, useEffect, useState } from "react";
import { IMAGE_EXTENSIONS, VIDEO_EXTENSIONS } from "~/utils/constants.utils";

function FileUploadZone({
  onFileChange,
  currentFileName,
  errors,
  name,
  multiple,
  showPreviews,
  maxFileSize,
  accept,
  defaultFiles,
  alreadyUploadedFiles,
  onRemoveAlreadyUploadedFile,
}: {
  currentFileName?: string;
  errors: string[];
  name?: string;
  showPreviews?: boolean;
  maxFileSize: number;
  accept?: string;
  defaultFiles?: File[];
  alreadyUploadedFiles?: SerializeFrom<PrismaFile>[];
  onRemoveAlreadyUploadedFile?: (id: string) => void;
} & (
  | {
      multiple?: false;
      onFileChange?: (file: File | undefined) => void | undefined;
    }
  | {
      multiple: true;
      onFileChange?: (file: File[] | undefined) => void;
    }
)) {
  const [files, setFiles] = useState<File[]>(defaultFiles ?? []);
  const [fieldErrors, setFieldErrors] = useState(errors);
  const [file, setFile] = useState<File | undefined>();

  const onDrop = useCallback(
    (e: React.DragEvent<HTMLDivElement>) => {
      e.preventDefault();
      e.stopPropagation();
      if (e?.dataTransfer?.files && e.dataTransfer.files.length > 0) {
        const okFiles: File[] = [];
        let hasError = false;
        for (const file of e.dataTransfer.files ?? []) {
          if (file.size <= maxFileSize) {
            okFiles.push(file);
          } else {
            hasError = true;
          }
        }
        if (hasError) {
          setFieldErrors([...fieldErrors, "One or more files are too large"]);
          if (multiple) setFiles([]);
        } else {
          setFieldErrors([...fieldErrors]);
          if (multiple) setFiles(prevFiles => [...prevFiles, ...okFiles]);
          else setFile(e.dataTransfer.files[0]);
        }

        if (onFileChange) {
          multiple
            ? onFileChange([...files, ...okFiles])
            : onFileChange(okFiles[0]);
        }
      }
    },
    [onFileChange, fieldErrors, maxFileSize, multiple, files]
  );

  const onFileInput = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      e.preventDefault();
      e.stopPropagation();
      if (e?.target?.files && e.target.files.length > 0) {
        const okFiles: File[] = [];
        let hasError = false;
        for (const file of e.target.files ?? []) {
          if (file.size <= maxFileSize) {
            okFiles.push(file);
          } else {
            hasError = true;
          }
        }
        if (hasError) {
          setFieldErrors([...fieldErrors, "One or more files are too large"]);
          if (multiple) setFiles([]);
        } else {
          setFieldErrors([...fieldErrors]);
          if (multiple) setFiles(prevFiles => [...prevFiles, ...okFiles]);
          else setFile(e.target.files[0]);
        }
        if (onFileChange) {
          multiple
            ? onFileChange([...files, ...okFiles])
            : onFileChange(okFiles[0]);
        }
      }
    },
    [onFileChange, fieldErrors, maxFileSize, multiple, files]
  );

  const removeFile = useCallback((index: number) => {
    setFiles(prevFiles => prevFiles.filter((_, i) => i !== index));
  }, []);

  useEffect(() => {
    setFiles(defaultFiles ?? []);
  }, [defaultFiles]);

  return (
    <>
      <div className="grid grid-cols-3 lg:grid-cols-6">
        {showPreviews &&
          alreadyUploadedFiles &&
          alreadyUploadedFiles.map((file, index) => {
            const type = file.mime_type;
            const src = `/images/${file.id}`;
            return (
              <div key={index} className="relative m-2">
                <a href={src} target="_blank" rel="noreferrer">
                  {type.startsWith("image/") ? (
                    <img
                      src={src}
                      className="w-full h-24 rounded-md border border-gray-200 object-cover"
                      alt="banner"
                    />
                  ) : type === "application/pdf" ? (
                    <embed
                      src={src}
                      className="w-full h-24 rounded-md border border-gray-200 object-cover"
                      width="100%"
                      height="100%"
                    />
                  ) : type.startsWith("audio/") ? (
                    <div className="w-full h-24 flex justify-center items-center">
                      <audio src={src} controls className="w-11/12" />
                    </div>
                  ) : type.startsWith("video/") ? (
                    <video
                      src={src}
                      className="w-full h-24 rounded-md border border-gray-200 object-cover"
                    />
                  ) : (
                    <div className="flex justify-center items-center  border border-gray-200">
                      <DocumentIcon
                        className="h-20 w-12 text-sky-600"
                        aria-hidden="true"
                      />
                    </div>
                  )}
                </a>
                <button
                  type="button"
                  onClick={() => onRemoveAlreadyUploadedFile?.(file.id)}
                >
                  <div className="h-5 w-5 bg-red-500 flex items-center justify-center rounded-full absolute -top-2 -right-2">
                    <XMarkIcon className="h-4 text-white" />
                  </div>
                </button>
              </div>
            );
          })}
        {showPreviews &&
          files.map((file, index) => {
            const ext = file.name.split(".").pop() ?? "";
            return (
              <div key={index} className="relative m-2">
                <a
                  href={URL.createObjectURL(file)}
                  target="_blank"
                  rel="noreferrer"
                >
                  {IMAGE_EXTENSIONS.includes(ext) ? (
                    <img
                      src={URL.createObjectURL(file)}
                      className="w-full h-24 rounded-md border border-gray-200 object-cover"
                      alt="banner"
                    />
                  ) : VIDEO_EXTENSIONS.includes(ext) ? (
                    <video
                      src={URL.createObjectURL(file)}
                      className="w-full h-24 rounded-md border border-gray-200 object-cover"
                    />
                  ) : ext === "pdf" || ext === "mp3" ? (
                    <embed
                      src={URL.createObjectURL(file)}
                      className="w-full h-24 rounded-md border border-gray-200 object-cover"
                      width="100%"
                      height="100%"
                    />
                  ) : (
                    <div className="flex justify-center items-center  border border-gray-200">
                      <DocumentIcon
                        className="h-20 w-12 text-sky-600"
                        aria-hidden="true"
                      />
                    </div>
                  )}
                </a>
                {multiple && (
                  <button type="button" onClick={() => removeFile(index)}>
                    <div className="h-5 w-5 bg-red-500 flex items-center justify-center rounded-full absolute -top-2 -right-2">
                      <XMarkIcon className="h-4 text-white" />
                    </div>
                  </button>
                )}
              </div>
            );
          })}
      </div>
      <div
        className="flex items-center justify-center w-full"
        onDrop={onDrop}
        onDragOver={e => e.preventDefault()}
      >
        <label
          htmlFor="dropzone-file"
          className="flex flex-col items-center justify-center w-full h-44 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50"
        >
          <div className="flex flex-col items-center justify-center pt-5 pb-6">
            <svg
              aria-hidden="true"
              className="w-10 h-10 mb-3 text-gray-400"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
              xmlns="http://www.w3.org/2000/svg"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth="2"
                d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"
              ></path>
            </svg>
            {(file || currentFileName) && (
              <div className="text-normal text-gray-500">
                {file?.name || currentFileName}
              </div>
            )}
            <p className="my-1 text-sm text-gray-400">
              <span className="font-semibold">Click to upload</span> or drag and
              drop
            </p>
          </div>
          <input
            onChange={onFileInput}
            name={name}
            id="dropzone-file"
            type="file"
            className="hidden"
            multiple={multiple}
            accept={accept}
          />
          {!multiple && (
            <div>
              {files.map((file, index) => (
                <div key={index}>{file.name}</div>
              ))}
            </div>
          )}
        </label>
      </div>
      {!isEmpty(errors) && (
        <p className="mt-3 text-sm leading-6 text-red-600">
          {errors?.join(" ")}
        </p>
      )}
    </>
  );
}

export default FileUploadZone;
