import type {
  Contract,
  Location,
  ManagerAccountVendor,
  TaskContractRenewal,
  TaskLocationDisposition,
  Vendor,
} from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import { get } from "lodash";
import type { OrderByField } from "./filtering.utils";

export enum TaskType {
  TaskContractRenewal = "TaskContractRenewal",
  TaskLocationDisposition = "TaskLocationDisposition",
}

export const TaskTypeLabels = {
  [TaskType.TaskContractRenewal]: "Contract Renewal",
  [TaskType.TaskLocationDisposition]: "Location Disposition",
} as const;

export const TaskNamePrefixes = {
  TaskContractRenewal: "Contract renewal",
  TaskLocationDisposition: "Update disposition status",
} as const;

export const TaskLinkPrefixes = {
  TaskContractRenewal: "contract-renewal",
  TaskLocationDisposition: "location-disposition",
} as const;

export type Task = (
  | (TaskContractRenewal & {
      contract: Contract & {
        manager_account_vendor?: ManagerAccountVendor & { vendor?: Vendor };
      };
    })
  | (TaskLocationDisposition & { location: Location })
) & { task_owner: { user: { first_name: string; last_name: string } } };

export function getTaskType(
  task: Task | SerializeFrom<Task> | null
): TaskType | undefined {
  if (!task) {
    return undefined;
  }
  if ("contract_id" in task) {
    return TaskType.TaskContractRenewal;
  } else if ("location_id" in task) {
    return TaskType.TaskLocationDisposition;
  }
}

export function generateTaskName(task: Task | SerializeFrom<Task>) {
  const taskType = getTaskType(task);
  if (taskType == TaskType.TaskContractRenewal && "contract" in task) {
    return `${TaskNamePrefixes[taskType]} - ${task.contract?.name}`;
  } else if (
    taskType == TaskType.TaskLocationDisposition &&
    "location" in task
  ) {
    return `${TaskNamePrefixes[taskType]} - ${task.location?.name}`;
  }
}

export const getTaskResourceName = (
  task: SerializeFrom<Task> | Task | null
) => {
  if (!task) {
    return "";
  }
  if ("contract_id" in task) {
    return (
      task.contract.manager_account_vendor?.vendor?.name ?? task.contract.name
    );
  } else if ("location_id" in task) {
    return task.location?.name;
  }
};

const TaskCustomOrderByFunctions = {
  task_name: (task: Task) => generateTaskName(task) ?? "",
  task_owner: (task: Task) =>
    `${task.task_owner.user.first_name} ${task.task_owner.user.last_name}`,
} as const;

export function orderTasks(tasks: Task[], orderBy?: OrderByField[]) {
  if (!orderBy) {
    return tasks;
  }

  [...orderBy].reverse().forEach(order => {
    const key = Object.keys(order)[0];
    const direction = order[key];

    tasks.sort((a, b) => {
      const customValue = get(TaskCustomOrderByFunctions, key);
      const aValue = customValue ? customValue(a) : a[key as keyof Task];
      const bValue = customValue ? customValue(b) : b[key as keyof Task];

      if (aValue > bValue) {
        return direction === "asc" ? 1 : -1;
      }
      if (aValue < bValue) {
        return direction === "asc" ? -1 : 1;
      }
      return 0;
    });
  });

  return tasks;
}
