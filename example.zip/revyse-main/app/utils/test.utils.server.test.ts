import { withFixtureFactory } from "./test.utils.server";

describe("withFixtureFactory", () => {
  test("withFixtures is a function and test is a function", () => {
    const withFixtures = withFixtureFactory({
      setup: async tx => {
        return {
          a: "a",
          b: 2,
          c: false,
          d: await Promise.resolve("beep"),
        };
      },
    });
    expect(typeof withFixtures).toBe("function");

    const test = withFixtures(async ({ a, b, c, d }, tx) => {
      expect(a).toBe("a");
      expect(b).toBe(2);
      expect(c).toBe(false);
      expect(d).toBe("beep");
    });

    expect(typeof test).toBe("function");

    return test();
  });

  describe("withFixtureFactory can use an async setup function", () => {
    const withFixtures = withFixtureFactory({
      setup: async tx => {
        return {
          a: "a",
          b: 2,
          c: false,
          d: await Promise.resolve("beep"),
        };
      },
    });

    test(
      'a = "a"',
      withFixtures(({ a }, tx) => {
        expect(a).toBe("a");
      })
    );
    test(
      "b = 2",
      withFixtures(({ b }, tx) => {
        expect(b).toBe(2);
      })
    );
    test(
      "c = false",
      withFixtures(({ c }, tx) => {
        expect(c).toBe(false);
      })
    );
    test(
      'd = "beep"',
      withFixtures(({ d }, tx) => {
        expect(d).toBe("beep");
      })
    );
  });

  describe("withFixtureFactory can use an sync setup function", () => {
    const withFixtures = withFixtureFactory({
      setup: tx => {
        return {
          a: "a",
          b: 2,
          c: false,
          d: "beep",
        };
      },
    });

    test(
      'a = "a"',
      withFixtures(({ a }, tx) => {
        expect(a).toBe("a");
      })
    );
    test(
      "b = 2",
      withFixtures(({ b }, tx) => {
        expect(b).toBe(2);
      })
    );
    test(
      "c = false",
      withFixtures(({ c }, tx) => {
        expect(c).toBe(false);
      })
    );
    test(
      'd = "beep"',
      withFixtures(({ d }, tx) => {
        expect(d).toBe("beep");
      })
    );
  });

  describe("withFixtures can use an sync test functions", () => {
    const withFixtures = withFixtureFactory({
      setup: async tx => {
        return {
          a: "a",
          b: 2,
          c: false,
          d: await Promise.resolve("beep"),
        };
      },
    });

    test(
      'a = "a"',
      withFixtures(async ({ a }, tx) => {
        expect(a).toBe("a");
      })
    );
    test(
      "b = 2",
      withFixtures(async ({ b }, tx) => {
        expect(b).toBe(2);
      })
    );
    test(
      "c = false",
      withFixtures(async ({ c }, tx) => {
        expect(c).toBe(false);
      })
    );
    test(
      'd = "beep"',
      withFixtures(async ({ d }, tx) => {
        expect(d).toBe("beep");
      })
    );
  });
});
