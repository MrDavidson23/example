import { z } from "zod";
import { slugify } from "./string.utils";

export const NonEmptyString = z
  .string({ invalid_type_error: "Required" })
  .min(1, "Required");

export const Score = z.preprocess(
  v => (v ? parseInt(v as string) : null),
  z.number({ invalid_type_error: "Required" }).lte(5).gte(0)
);

export const Boolean = z
  .string({ invalid_type_error: "Required" })
  .nullable()
  .transform(v => v === "true");

export const Currency = z.preprocess(
  (v: any) => (v ? v.replace(/[^\d.]/g, "") : null),
  z.coerce.number()
);

export const Slug = z.preprocess(
  (v: any) => (v ? slugify(v) : null),
  z.string().min(1, "Slug is required")
);
