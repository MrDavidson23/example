export function encodeFilename(filename: string | null | undefined) {
  if (!filename) return "";
  return encodeURIComponent(filename);
}

export function decodeFilename(encodedFilename: string | null | undefined) {
  if (!encodedFilename) return "";
  return decodeURIComponent(encodedFilename);
}

export function encodeFileFields(formData: FormData) {
  const entries = Array.from(formData.entries());
  for (const [key, value] of entries) {
    if (value instanceof File) {
      formData.set(key, value, encodeFilename(value.name));
    }
  }
}
