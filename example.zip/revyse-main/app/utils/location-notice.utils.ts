import type {
  ContractLineItem,
  File,
  Location,
  LocationNoticeDisposition,
  LocationNoticeDispositionRecipient,
  LocationServiceTerminationNotice,
  ManagerAccount,
  ManagerAccountRole,
  ManagerAccountVendor,
  ManagerAccountVendorContact,
  User,
  Vendor,
} from "@prisma/client";
import { LocationNoticeStatus } from "@prisma/client";
import type { SerializeFrom } from "@remix-run/node";
import dayjs from "dayjs";
import { isEmpty } from "lodash";

type Disposition = LocationNoticeDisposition & {
  type: LocationNoticeType.LocationNoticeDisposition;
  location_notice_recipients?: LocationNoticeDispositionRecipient[];
};

type ServiceTermination = LocationServiceTerminationNotice & {
  type: LocationNoticeType.LocationServiceTermination;
  manager_account_vendor?: ManagerAccountVendor & {
    vendor: Vendor;
    manager_account_vendor_contacts: ManagerAccountVendorContact[];
  };
  services_to_terminate?: ContractLineItem[];
};

type Notice = Disposition | ServiceTermination;
export type LocationNotice = Notice & {
  manager_account_role: {
    user: {
      first_name: string;
      last_name: string;
    };
  };
  task_owner?: ManagerAccountRole & {
    user: User;
  };
  email_attachments?: File[];
  type: LocationNoticeType;
};

export enum LocationNoticeType {
  LocationNoticeDisposition = "LocationNoticeDisposition",
  LocationServiceTermination = "LocationServiceTermination",
}

export const LocationNoticeLinkPrefixes = {
  LocationNoticeDisposition: "location-disposition",
  LocationServiceTermination: "service-termination",
} as const;

export const LocationNoticeActionNamesMap = {
  [LocationNoticeStatus.Saved]: "started",
  [LocationNoticeStatus.Sent]: "sent",
  [LocationNoticeStatus.InProgress]: "",
};

export const LocationNoticeTypeMap = {
  [LocationNoticeType.LocationNoticeDisposition]: "disposition notice",
  [LocationNoticeType.LocationServiceTermination]: "service termination notice",
};

export const LOCATION_NOTICE_EMAIL_DATE_FORMAT = "MMMM D, YYYY";

export function getLocationNoticeName(locationNotice: LocationNotice) {
  const userName = `${locationNotice.manager_account_role.user.first_name} ${locationNotice.manager_account_role.user.last_name}`;
  const locationNoticeTypeName = LocationNoticeTypeMap[locationNotice.type];
  const actionName = LocationNoticeActionNamesMap[locationNotice.status];
  const newOrUpdated = locationNotice.original_location_notice_id
    ? "an updated"
    : "a new";

  const activityName = `${userName} ${actionName} ${newOrUpdated} ${locationNoticeTypeName}`;

  return activityName;
}

export function getLocationNoticeEmailDefaultBody(
  locationNotice: SerializeFrom<LocationNotice>,
  location: SerializeFrom<Location>,
  account: SerializeFrom<ManagerAccount>
) {
  const isUpdated = locationNotice.original_location_notice_id !== null;

  if (locationNotice.type === LocationNoticeType.LocationNoticeDisposition) {
    if (isUpdated) {
      return `
      <p>Hello,</p>

      <p>There has been a change regarding the planned disposition of ${location.name
        }, at ${[
          location.street_1,
          location.street_2,
          location.city,
          location.state,
          location.zip,
        ]
          .filter(Boolean)
          .join(
            ", "
          )}. As a result, critical information regarding the property’s transition timeline has been updated below.</p>

        <p><b>Expected Disposition Date:</b> ${dayjs
          .utc(locationNotice.disposition_date)
          .format(LOCATION_NOTICE_EMAIL_DATE_FORMAT)}</p>

        <p><b>Requested Service Termination Date:</b> ${dayjs
          .utc(locationNotice.termination_date)
          .format(LOCATION_NOTICE_EMAIL_DATE_FORMAT)}</p>
        
        <p><b>Instructions for Final Invoices:</b> ${!isEmpty(locationNotice.termination_instructions)
          ? locationNotice.termination_instructions
          : "No instructions provided."
        }</p>

      <p>We kindly request that you make the necessary adjustments to your schedule and ensure that all services are canceled by the requested date.</p>

      <p>For outstanding questions or further clarification, reach out to ${locationNotice.task_owner?.user.email
        }.</p>

      <p>We appreciate your flexibility in accommodating this change.</p>
      <br />
      <p>${locationNotice.task_owner?.user.first_name} ${locationNotice.task_owner?.user.last_name
        }
      </p>
      <p>${locationNotice.task_owner?.user.title}</p>
      <p>${account.name}</p>
    `;
    } else {
      return `
      <p>Hello,</p>
      <p>We are reaching out today with important news regarding upcoming changes to our property portfolio.</p>
      <p>${location.name}, at ${[
          location.street_1,
          location.street_2,
          location.city,
          location.state,
          location.zip,
        ]
          .filter(Boolean)
          .join(
            ", "
          )}, is undergoing a planned disposition, with an expected transition date of ${dayjs
            .utc(locationNotice.disposition_date)
            .format(LOCATION_NOTICE_EMAIL_DATE_FORMAT)}. 
      </p>
      <p>As a result, we are requesting termination of all contracted services on ${dayjs
          .utc(locationNotice.termination_date)
          .format(LOCATION_NOTICE_EMAIL_DATE_FORMAT)}.
      </p>
      <p><b>Instructions for Final Invoices:</b></p>
      <p>${!isEmpty(locationNotice.termination_instructions)
          ? locationNotice.termination_instructions
          : "No instructions provided."
        }</p>
      
      <p>We appreciate your contributions to ${location.name
        }. For outstanding questions, reach out to ${locationNotice.task_owner?.user.email
        }.
      </p>
      <p>Thank you for your partnership.</p>
      <br />
      <p>${locationNotice.task_owner?.user.first_name} ${locationNotice.task_owner?.user.last_name
        }
      </p>
      <p>${locationNotice.task_owner?.user.title}</p>
      <p>${account.name}</p>
    `;
    }
  } else {
    if (isUpdated) {
      return `
      <p>${locationNotice.manager_account_vendor?.vendor.name},</p>
      <p>There has been a change regarding the requested service termination for ${location.name
        }, at ${[
          location.street_1,
          location.street_2,
          location.city,
          location.state,
          location.zip,
        ]
          .filter(Boolean)
          .join(
            ", "
          )}. As a result, critical information regarding the property’s cancellation request has been updated below.</p>
      <p><b>Requested Service Termination Date:</b></p>
      <p>${dayjs
          .utc(locationNotice.termination_date)
          .format(LOCATION_NOTICE_EMAIL_DATE_FORMAT)}</p>
      <p><b>Services to Be Terminated:</b></p>
      ${locationNotice.services_to_terminate?.length
          ? locationNotice.services_to_terminate
            .map(service => `<p>${service.name}</p>`)
            .join("")
          : "<p>No services selected.</p>"
        }
      <p><b>Instructions for Final Invoices:</b></p>
      <p>
        ${!isEmpty(locationNotice.termination_instructions)
          ? locationNotice.termination_instructions
          : "No instructions provided."
        }
      </p>
      <br />
      <p>We kindly request that you make the necessary adjustments to your schedule and ensure that all services are canceled by the requested date.</p>
      <br />
      <p>For outstanding questions or further clarification, reach out to ${locationNotice.task_owner?.user.email} - ${locationNotice.task_owner?.user.first_name} ${locationNotice.task_owner?.user.last_name
        }. We appreciate your flexibility in accommodating this change.</p>
      <br />
      <p>${locationNotice.task_owner?.user.first_name} ${locationNotice.task_owner?.user.last_name
        }
      </p>
      <p>${locationNotice.task_owner?.user.title}</p>
      <p>${account.name}</p>
      `;
    } else {
      return `
        <p>${locationNotice.manager_account_vendor?.vendor.name},</p>
        <p>We are writing to inform you that ${location.name}, located at ${[
          location.street_1,
          location.street_2,
          location.city,
          location.state,
          location.zip,
        ]
          .filter(Boolean)
          .join(
            ", "
          )}, is officially requesting the termination of the services listed below, effective on ${dayjs
            .utc(locationNotice.termination_date)
            .format(LOCATION_NOTICE_EMAIL_DATE_FORMAT)}.</p>
        <p><b>Services to Be Terminated:</b></p>
        ${locationNotice.services_to_terminate?.length
          ? locationNotice.services_to_terminate
            .map(service => `<p>${service.name}</p>`)
            .join("")
          : "<p>No services selected.</p>"
        }
        <p><b>Instructions for Final Invoices:</b></p>
        <p>
          ${!isEmpty(locationNotice.termination_instructions)
          ? locationNotice.termination_instructions
          : "No instructions provided."
        }
        </p>
        <br />
        <p>We appreciate your contributions to ${location.name} and the ${account.name
        } portfolio. Should you have any outstanding questions, please reach out to ${locationNotice.task_owner?.user.email
        }.</p>
        <br />
        <p>${locationNotice.task_owner?.user.first_name} ${locationNotice.task_owner?.user.last_name
        }</p>
        <p>${locationNotice.task_owner?.user.title}</p>
        <p>${account.name}</p>
      `;
    }
  }
}
