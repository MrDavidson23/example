import { faker } from "@faker-js/faker";
import {
  LocationClass,
  LocationRoleType,
  LocationStatus,
  ManagerAccountRoleType,
  Role,
  UserRoleType,
} from "@prisma/client";
import { withFixtureFactory } from "./test.utils.server";
import { Permission } from "./intelligence-permission.utils";
import {
  canDoOnLocation,
  canDoOnLocationOrThrow,
  canDoSomeOnLocation,
  canDoSomeOnLocationOrThrow,
} from "./location-permission.utils";

const withFixtures = withFixtureFactory({
  setup: async tx => {
    const managerAccount = await tx.managerAccount.create({
      data: {
        name: faker.company.name(),
      },
    });

    const location = await tx.location.create({
      data: {
        name: `${faker.company.name()} ${faker.string.alphanumeric(5)}`,
        pms_id: faker.string.alphanumeric(6),
        owner_name: faker.person.fullName(),
        street_1: faker.location.streetAddress(),
        street_2: faker.location.secondaryAddress(),
        city: faker.location.city(),
        state: faker.location.state(),
        zip: faker.location.zipCode(),
        region: faker.location.state(),
        unit_count: faker.number.int({ min: 1, max: 1000 }),
        class: faker.helpers.enumValue(LocationClass),
        status: faker.helpers.enumValue(LocationStatus),
        manager_account_id: managerAccount.id,
      },
    });

    const godUser = await tx.user.create({
      data: {
        email: faker.internet.email(),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
        user_roles: {
          create: {
            type: UserRoleType.GLOBAL,
            role: Role.GOD_MODE,
          },
        },
      },
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
          include: {
            location_roles: true,
          },
        },
        user_roles: true,
      },
    });

    const ownerUser = await tx.user.create({
      data: {
        email: faker.internet.email(),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
        manager_account_roles: {
          create: {
            manager_account: {
              connect: {
                id: managerAccount.id,
              },
            },
            role: ManagerAccountRoleType.Owner,
          },
        },
      },
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
          include: {
            location_roles: true,
          },
        },
        user_roles: true,
      },
    });

    const locationViewerUser = await tx.user.create({
      data: {
        email: faker.internet.email(),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
        manager_account_roles: {
          create: {
            manager_account: {
              connect: {
                id: managerAccount.id,
              },
            },
            role: ManagerAccountRoleType.Member,
            location_roles: {
              create: {
                location: {
                  connect: {
                    id: location.id,
                  },
                },
                type: LocationRoleType.Viewer,
              },
            },
          },
        },
      },
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
          include: {
            location_roles: true,
          },
        },
        user_roles: true,
      },
    });

    const locationEditorUser = await tx.user.create({
      data: {
        email: faker.internet.email(),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
        manager_account_roles: {
          create: {
            manager_account: {
              connect: {
                id: managerAccount.id,
              },
            },
            role: ManagerAccountRoleType.Member,
            location_roles: {
              create: {
                location: {
                  connect: {
                    id: location.id,
                  },
                },
                type: LocationRoleType.Editor,
              },
            },
          },
        },
      },
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
          include: {
            location_roles: true,
          },
        },
        user_roles: true,
      },
    });

    const noRoleUser = await tx.user.create({
      data: {
        email: faker.internet.email(),
        first_name: faker.person.firstName(),
        last_name: faker.person.lastName(),
      },
      include: {
        manager_account_roles: {
          where: {
            deleted_at: null,
          },
          include: {
            location_roles: true,
          },
        },
        user_roles: true,
      },
    });

    return {
      managerAccount,
      location,
      godUser,
      ownerUser,
      locationViewerUser,
      locationEditorUser,
      noRoleUser,
    };
  },
});

describe("LocationPermissionUtils", () => {
  describe("canDoOnLocation", () => {
    test(
      "should return true if the user has the correct role for the location",
      withFixtures(
        async ({
          managerAccount,
          location,
          godUser,
          ownerUser,
          locationViewerUser,
          locationEditorUser,
          noRoleUser,
        }) => {
          const expectTrueUsers = [godUser, ownerUser, locationEditorUser];

          for (const user of expectTrueUsers) {
            const authorized = canDoOnLocation(
              user,
              managerAccount,
              location,
              Permission.ManageLocations
            );

            expect(authorized).toBe(true);
          }

          const expectFalseUsers = [locationViewerUser, noRoleUser];

          for (const user of expectFalseUsers) {
            const authorized = canDoOnLocation(
              user,
              managerAccount,
              location,
              Permission.ManageLocations
            );

            expect(authorized).toBe(false);
          }
        }
      )
    );
  });

  describe("canDoOnLocationOrThrow", () => {
    test(
      "should throw if the user doesn't have permission for the location",
      withFixtures(
        async ({
          managerAccount,
          location,
          godUser,
          ownerUser,
          locationViewerUser,
          locationEditorUser,
          noRoleUser,
        }) => {
          const expectTrueUsers = [
            godUser,
            ownerUser,
            locationEditorUser,
            locationViewerUser,
          ];

          for (const user of expectTrueUsers) {
            const tempFunc = () =>
              canDoOnLocationOrThrow(
                user,
                managerAccount,
                location,
                Permission.ViewLocationDetails
              );

            expect(tempFunc).not.toThrow();
          }

          const expectFalseUsers = [noRoleUser];

          for (const user of expectFalseUsers) {
            const tempFunc = () =>
              canDoOnLocationOrThrow(
                user,
                managerAccount,
                location,
                Permission.ViewLocationDetails
              );

            expect(tempFunc).toThrow();
          }
        }
      )
    );
  });

  describe("canDoSomeOnLocation", () => {
    test(
      "should return true if the user has the correct role for the location",
      withFixtures(
        async ({
          managerAccount,
          location,
          godUser,
          ownerUser,
          locationViewerUser,
          locationEditorUser,
          noRoleUser,
        }) => {
          const expectTrueUsers = [godUser, ownerUser, locationEditorUser];

          for (const user of expectTrueUsers) {
            const authorized = canDoSomeOnLocation(
              user,
              managerAccount,
              location,
              [Permission.ManageAccountUsers, Permission.ManageLocations]
            );

            expect(authorized).toBe(true);
          }

          const expectFalseUsers = [locationViewerUser, noRoleUser];

          for (const user of expectFalseUsers) {
            const authorized = canDoSomeOnLocation(
              user,
              managerAccount,
              location,
              [Permission.ManageAccountUsers, Permission.ManageLocations]
            );

            expect(authorized).toBe(false);
          }
        }
      )
    );
  });

  describe("canDoSomeOnLocationOrThrow", () => {
    test(
      "should throw if the user doesn't have any permission for the location",
      withFixtures(
        async ({
          managerAccount,
          location,
          godUser,
          ownerUser,
          locationViewerUser,
          locationEditorUser,
          noRoleUser,
        }) => {
          const expectTrueUsers = [
            godUser,
            ownerUser,
            locationEditorUser,
            locationViewerUser,
          ];

          for (const user of expectTrueUsers) {
            const tempFunc = () =>
              canDoSomeOnLocationOrThrow(user, managerAccount, location, [
                Permission.ManageAccountUsers,
                Permission.ViewLocationDetails,
              ]);

            expect(tempFunc).not.toThrow();
          }

          const expectFalseUsers = [noRoleUser];

          for (const user of expectFalseUsers) {
            const tempFunc = () =>
              canDoSomeOnLocationOrThrow(user, managerAccount, location, [
                Permission.ManageAccountUsers,
                Permission.ViewLocationDetails,
              ]);

            expect(tempFunc).toThrow();
          }
        }
      )
    );
  });
});
