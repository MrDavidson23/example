// Structured Data Schema Types for SEO from https://schema.org
export const StructuredDataSchemaTypes = {
  Review: "https://schema.org/Review",
  Product: "https://schema.org/Product",
  AggregateRating: "https://schema.org/AggregateRating",
  Organization: "https://schema.org/Organization",
  Rating: "https://schema.org/Rating",
  QuantitativeValue: "https://schema.org/QuantitativeValue",
} as const;
