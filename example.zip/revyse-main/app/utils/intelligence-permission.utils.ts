import {
  Role,
  type ManagerAccount,
  type ManagerAccountRole,
  type UserRole,
  UserRoleType,
  type LocationRole,
} from "@prisma/client";
import { assertAuthorized } from "./assert.utils.server";
import type { SerializeFrom } from "@remix-run/node";

export const Roles = {
  Owner: "Owner",
  Editor: "Editor",
  Viewer: "Viewer",
  Member: "Member",
} as const;

type RolesKeys = keyof typeof Roles;
export type RoleType = (typeof Roles)[RolesKeys];

export const Permission = {
  // Dashboard
  ViewDashboard: "View Dashboard",

  // Reports
  ViewReports: "View Reports",
  ViewSpendByResidentPhase: "View Spend By Resident Phase",
  ViewSpendByDepartment: "View Spend By Department",
  ViewSpendByEnterpriseCategory: "View Spend By Enterprise Category",
  ViewSpendByLocation: "View Spend By Location",

  // Locations
  ViewLocationsTable: "View Locations Table",
  ViewLocationDetails: "View Location Details",
  ManageLocations: "Manage Locations",
  ViewLocationNotices: "View Location Notices",
  ManageLocationNotices: "Manage Location Notices",
  ExportLocationDocuments: "Export Location Documents",
  DeleteLocations: "Delete Locations",

  // Vendors
  ViewVendorsTable: "View Vendors Table",
  ManageVendors: "Manage Vendors",
  ViewVendorDetails: "View Vendor Details",

  // Tasks
  ManageTasks: "Manage Tasks",
  ViewTasks: "View Tasks",
  ViewTaskDetails: "View Task Details",
  SendTaskChatMessage: "Send Task Chat Message",

  // Contracts
  ViewContractsTable: "View Contracts Table",
  ViewContractDetails: "View Contract Details",
  ViewCompanyLevelContractDetails: "View Company Level Contract Details",
  ManageContracts: "Manage Contracts",
  ViewContractLocations: "View Contract Locations",
  ManageContractLocationsDocuments: "Manage Contract Locations Documents",

  // Contract Line Items
  ViewContractProductsAndContractLineItemsTable:
    "View Contract Products And Line Items Table",
  ViewContractLineItem: "View Contract Line Item",
  ManageContractLineItem: "Manage Contract Line Item",
  ViewCompanyLevelContractLineItemPricing: "View Contract Line Item Pricing on Assigned Line Items table",
  ManageCompanyLevelContractLineItemStatus: "Change Contract Line Item Status thru Blue Pencil CTA",
  ViewCompanyLevelContractLineItem: "View Contract Line Item thru Assigned Line Items table",
  CopyContractLineItemsToLocations: "Copy Contract Line Items to Locations",

  // Contract Line Item Locations
  ManageContractLineItemLocations: "Manage Contract Line Item Locations",
  ViewLocationVendorsAndProducts: "View Location Vendors And Products",

  // Sensitive Contracts
  ViewSensitiveContracts: "View Sensitive Contracts",
  ManageSensitiveContracts: "Manage Sensitive Contracts",

  // AI Assist
  UseAIAssist: "Use AI Assist",

  // Account
  ViewAccountInformation: "View Account Information",
  ManageAccountInformation: "Manage Account Information",
  ViewAccountUsers: "View Account Users",
  ManageAccountUsers: "Manage Account Users",
} as const;

type PermissionKeys = keyof typeof Permission;
export type PermissionType = (typeof Permission)[PermissionKeys];

const rolePermissionMap: Record<RoleType, Readonly<PermissionType[]>> = {
  [Roles.Owner]: [
    Permission.ViewDashboard,
    Permission.ViewReports,
    Permission.ViewSpendByResidentPhase,
    Permission.ViewSpendByDepartment,
    Permission.ViewSpendByEnterpriseCategory,
    Permission.ViewSpendByLocation,
    Permission.ViewLocationsTable,
    Permission.ViewLocationDetails,
    Permission.ManageLocations,
    Permission.ExportLocationDocuments,
    Permission.DeleteLocations,
    Permission.ViewLocationNotices,
    Permission.ManageLocationNotices,
    Permission.ViewLocationVendorsAndProducts,
    Permission.ViewVendorsTable,
    Permission.ManageVendors,
    Permission.ViewVendorDetails,
    Permission.ViewTaskDetails,
    Permission.ViewContractsTable,
    Permission.ViewContractDetails,
    Permission.ViewCompanyLevelContractDetails,
    Permission.ManageContracts,
    Permission.ManageContractLocationsDocuments,
    Permission.ViewSensitiveContracts,
    Permission.ManageSensitiveContracts,
    Permission.ViewContractProductsAndContractLineItemsTable,
    Permission.ViewContractLineItem,
    Permission.ManageContractLineItem,
    Permission.CopyContractLineItemsToLocations,
    Permission.ViewCompanyLevelContractLineItemPricing,
    Permission.ManageCompanyLevelContractLineItemStatus,
    Permission.ViewCompanyLevelContractLineItem,
    Permission.ManageContractLineItemLocations,
    Permission.ViewContractLocations,
    Permission.ViewAccountInformation,
    Permission.ManageAccountInformation,
    Permission.ViewAccountUsers,
    Permission.ManageAccountUsers,
    Permission.ManageTasks,
    Permission.ViewTasks,
    Permission.ViewTaskDetails,
    Permission.SendTaskChatMessage,
  ],
  [Roles.Editor]: [
    Permission.ViewDashboard,
    Permission.ViewReports,
    Permission.ViewSpendByResidentPhase,
    Permission.ViewSpendByDepartment,
    Permission.ViewSpendByEnterpriseCategory,
    Permission.ViewSpendByLocation,
    Permission.ViewLocationsTable,
    Permission.ViewLocationDetails,
    Permission.ManageLocations,
    Permission.ExportLocationDocuments,
    Permission.DeleteLocations,
    Permission.ViewLocationNotices,
    Permission.ManageLocationNotices,
    Permission.ViewLocationVendorsAndProducts,
    Permission.ViewVendorsTable,
    Permission.ManageVendors,
    Permission.ViewVendorDetails,
    Permission.ViewTaskDetails,
    Permission.ViewContractsTable,
    Permission.ViewContractDetails,
    Permission.ViewCompanyLevelContractDetails,
    Permission.ManageContracts,
    Permission.ManageContractLocationsDocuments,
    Permission.ViewContractProductsAndContractLineItemsTable,
    Permission.ViewContractLineItem,
    Permission.ManageContractLineItem,
    Permission.CopyContractLineItemsToLocations,
    Permission.ViewCompanyLevelContractLineItemPricing,
    Permission.ManageCompanyLevelContractLineItemStatus,
    Permission.ViewCompanyLevelContractLineItem,
    Permission.ManageContractLineItemLocations,
    Permission.ViewContractLocations,
    Permission.ViewAccountInformation,
    Permission.ManageTasks,
    Permission.ViewTasks,
    Permission.ViewTaskDetails,
    Permission.SendTaskChatMessage,
  ],
  [Roles.Viewer]: [
    Permission.ViewDashboard,
    Permission.ViewReports,
    Permission.ViewSpendByResidentPhase,
    Permission.ViewSpendByDepartment,
    Permission.ViewSpendByEnterpriseCategory,
    Permission.ViewSpendByLocation,
    Permission.ViewLocationsTable,
    Permission.ViewLocationDetails,
    Permission.ViewLocationNotices,
    Permission.ViewLocationVendorsAndProducts,
    Permission.ViewVendorsTable,
    Permission.ViewVendorDetails,
    Permission.ViewLocationVendorsAndProducts,
    Permission.ViewContractsTable,
    Permission.ViewContractDetails,
    Permission.ViewCompanyLevelContractDetails,
    Permission.ViewContractProductsAndContractLineItemsTable,
    Permission.ViewContractLineItem,
    Permission.ViewCompanyLevelContractLineItemPricing,
    Permission.ViewCompanyLevelContractLineItem,
    Permission.ViewContractLocations,
    Permission.ViewAccountInformation,
    Permission.ViewTasks,
    Permission.ViewTaskDetails,
  ],
  [Roles.Member]: [
    Permission.ViewLocationsTable,
    Permission.ViewVendorsTable,
    Permission.ViewTasks,
    Permission.ViewContractsTable,
    Permission.ViewContractLineItem,
    Permission.ViewLocationNotices,
  ],
} as const;

type ManagerAccountRoleWithLocationRoles = ManagerAccountRole & {
  location_roles: LocationRole[];
};

export type PermissionUser = {
  manager_account_roles:
    | ManagerAccountRoleWithLocationRoles[]
    | SerializeFrom<ManagerAccountRoleWithLocationRoles>[];
  user_roles: UserRole[] | SerializeFrom<UserRole>[];
};

export function canDo(
  user: PermissionUser,
  permission: PermissionType
): boolean {
  if (user.user_roles.some(role => role.role === Role.GOD_MODE)) return true;
  const permissions = user.user_roles
    .filter(role => role.type === UserRoleType.GLOBAL)
    .flatMap(role => rolePermissionMap[role.role as keyof typeof Roles]);

  return permissions.includes(permission);
}

export function canDoOnAccount(
  user: PermissionUser,
  account: { id: string } | null,
  permission: PermissionType | PermissionType[]
): boolean {
  if (!account) return false;
  if (user.user_roles.some(role => role.role === Role.GOD_MODE)) return true;

  const managerAccountRole = user.manager_account_roles.find(
    role => role.manager_account_id === account.id
  );

  // If no role for this account, return false
  if (!managerAccountRole) return false;

  const permissions =
    rolePermissionMap[managerAccountRole.role as keyof typeof Roles];
  return permission instanceof Array
    ? permission.every(p => permissions.includes(p))
    : permissions.includes(permission);
}

export function canDoOnAccountOrThrow(
  user: PermissionUser,
  account: ManagerAccount | null,
  permission: PermissionType | PermissionType[]
): void {
  const authorized = canDoOnAccount(user, account, permission);

  if (authorized) return;

  const message = `You are not authorized to ${permission} in this Intelligence Account`;

  assertAuthorized(authorized, message);
}

export function canDoSomeOnAccount(
  user: PermissionUser,
  account: { id: string } | null,
  permissions: PermissionType[]
): boolean {
  return permissions.some(permission =>
    canDoOnAccount(user, account, permission)
  );
}

export function canDoSomeOnAccountOrThrow(
  user: PermissionUser,
  account: { id: string } | null,
  permissions: PermissionType[]
): void {
  const authorized = canDoSomeOnAccount(user, account, permissions);

  if (authorized) return;

  const message = `You are not authorized to go into this Intelligence Account's section`;

  assertAuthorized(authorized, message);
}
