import { redirect } from "@remix-run/node";

export function assert(condition: unknown, msg: string): asserts condition {
  if (condition === false) {
    console.error(msg);
    throw new Response(msg, { status: 500 });
  }
}

export function assertAuthorized(
  condition: unknown,
  msg: string = "Unauthorized"
): asserts condition {
  if (condition === false) throw new Response(msg, { status: 403 });
}

export function assertAuthorizedOrRedirect(
  condition: unknown,
  redirectUrl = "/login"
): asserts condition {
  if (condition === false) throw redirect(redirectUrl);
}

export function assertUserInput(
  condition: unknown,
  msg: string
): asserts condition {
  if (condition === false) throw new Response(msg, { status: 400 });
}
