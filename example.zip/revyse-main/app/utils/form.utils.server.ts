import type { ZodIssue } from "zod";

export function issuesForPath(issues: ZodIssue[], key: string) {
  return issues.filter(e => e.path[0] === key).map(e => e.message);
}

export function issuesByKey(
  issues: { path: (string | number)[]; message: string }[]
): Record<string, string[] | null> {
  const result: any = {};
  for (const issue of issues) {
    result[issue.path.join(".")] = [issue.message];
  }

  return result;
}
