import {
  BuildingOffice2Icon,
  CurrencyDollarIcon,
  TagIcon,
  TvIcon,
  VideoCameraIcon,
} from "@heroicons/react/24/outline";
import type {
  ContractPricingType,
  EmojiType,
  LocationPropertyType,
  ManagerAccountVendorBusinessCriticalityRating,
  ManagerAccountVendorCybersecurityOptions,
  ManagerAccountVendorContactType,
  ManagerAccountVendorDocumentType,
  ManagerAccountVendorIncidentImpact,
  ManagerAccountVendorIncidentStatus,
  ManagerAccountVendorRiskScore,
  TaskCompletionStatus,
  TaskScheduleStatus,
  ContractLineItemPriceCadence,
} from "@prisma/client";
import {
  VendorValueTags,
  VendorCompanyStatus,
  VendorLastFundingRound,
} from "@prisma/client";
import { HandShakeIcon } from "~/components/icons/hand-shake-icon";
import { StartUpsIcon } from "~/components/icons/startups-icon";
import type { LocationNoticeType } from "./location-notice.utils";

export const MB = 1024 * 1024;

export const DEFAULT_FORM_ERROR_MESSAGE =
  "There were problems submitting your form. Please try again";

export const PAID_PLANS = [
  "Community Builder",
  "Brand Builder",
  "Market Builder",
];

export const IMAGE_EXTENSIONS = ["jpg", "jpeg", "gif", "png", "webp"];
export const VIDEO_EXTENSIONS = [
  "webm",
  "mpg",
  "mp2",
  "mpeg",
  "mpe",
  "mpv",
  "ogg",
  "mp4",
  "m4p",
  "m4v",
  "avi",
  "wmv",
  "mov",
  "qt",
  "flv",
  "swf",
  "avchd",
];

export const ManagerAccountVendorContactTypeLabels: Record<
  ManagerAccountVendorContactType,
  string
> = {
  Main: "Main Contact",
  Support: "Support Contact",
  Billing: "Billing Contact",
  Internal: "Internal Relationship",
  Disposition: "Cancellation Notice Contact",
} as const;

export const ManagerAccountVendorCybersecurityLabels: Record<
  ManagerAccountVendorCybersecurityOptions,
  string
> = {
  NotSet: "Not Set",
  NistCybersecurityFramework: "NIST Cybersecurity Framework",
  Iso27000Series: "ISO 27000 Series",
  Soc2Type1: "SOC 2 Type 1",
  Soc2Type2: "SOC 2 Type 2",
  PciDss: "PCI-DSS",
  NercCip: "NERC CIP",
  Cobit: "COBIT",
  Fisma: "FISMA",
  Ofdss: "OFDSS",
  Other: "Other",
  NA: "N/A",
} as const;

export const ManagerAccountVendorRiskScoreLabels: Record<
  ManagerAccountVendorRiskScore,
  string
> = {
  NotSet: "Not Set",
  Zero: "Zero",
  Low: "Low",
  Medium: "Medium",
  High: "High",
  VeryHigh: "Very High",
};

export const ManagerAccountVendorBusinessCriticalityRatingLabels: Record<
  ManagerAccountVendorBusinessCriticalityRating,
  string
> = {
  NotSet: "Not Set",
  Zero: "Zero: No Consequential Impact",
  Low: "Low: Administrative or Desirable",
  Medium: "Medium: Operational or Necessary",
  High: "High: Business Critical or Essential",
  VeryHigh: "Very High: Mission Critical",
} as const;

export const ManagerAccountVendorDocumentTypeLabels: Record<
  ManagerAccountVendorDocumentType,
  string
> = {
  CybersecurityReport: "Cybersecurity Report",
  DataPrivacyAgreement: "Data Privacy Agreement",
  Insurance: "Insurance",
  ITQuestionnaire: "IT Questionnaire",
  PrivacyPolicy: "Privacy Policy",
  SalesAndMarketingMaterials: "Sales & Marketing Materials",
  ScopeOfWork: "Scope of Work",
  TermsofService: "Terms of Service",
  W9: "W9",
  Other: "Other",
} as const;

export const ContractPricingTypeLabels: Record<ContractPricingType, string> = {
  FlatRate: "Flat Rate",
  Itemized: "Itemized",
  PerLease: "Per Lease (per location)",
  PerLocation: "Per Location",
  PerSeat: "Per Seat",
  PerUnit: "Per Unit",
  UsageBased: "Usage Based",
};

export const ManagerAccountVendorIncidentStatusLabels: Record<
  ManagerAccountVendorIncidentStatus,
  string
> = {
  New: "New",
  InProgress: "In Progress",
  UnderInvestigation: "Under Investigation",
  Resolved: "Resolved",
};

export const ManagerAccountVendorIncidentImpactLabels: Record<
  ManagerAccountVendorIncidentImpact,
  string
> = {
  NotSet: "Not Set",
  Zero: "Zero",
  Low: "Low",
  Medium: "Medium",
  High: "High",
  VeryHigh: "Very High",
};

export const LocationPropertyTypeLabels: Record<LocationPropertyType, string> =
  {
    Affordable: "Affordable",
    BuildToRent: "Build to Rent",
    ConventionalMultifamily: "Conventional Multifamily",
    OfficeCommercial: "Office Commercial",
    Other: "Other",
    Student: "Student",
    Senior: "Senior",
    SelfStorage: "Self Storage",
    SingleFamily: "Single Family",
  } as const;

export const TaskScheduleStatusLabels: Record<TaskScheduleStatus, string> = {
  Upcoming: "Upcoming",
  ReadyToDo: "Ready to Do",
  Overdue: "Overdue",
  Archived: "Archived",
};

export const TaskCompletionStatusLabels: Record<TaskCompletionStatus, string> =
  {
    Incomplete: "Incomplete",
    Completed: "Completed",
    Canceled: "Canceled",
  };

export const EmojiTypeValues: Record<EmojiType, string> = {
  Thumbsup: "👍",
  Heart: "❤️",
  Joy: "😂",
  WhiteCheckMark: "✅",
  Tada: "🎉",
};

export const VendorCompanyStatusLabels: Record<VendorCompanyStatus, string> = {
  [VendorCompanyStatus.Private]: "Private",
  [VendorCompanyStatus.Public]: "Public",
  [VendorCompanyStatus.Other]: "Other",
} as const;

export const VendorLastFundingRoundLabels: Record<
  VendorLastFundingRound,
  string
> = {
  [VendorLastFundingRound.NotSet]: "Not Set",
  [VendorLastFundingRound.None]: "None",
  [VendorLastFundingRound.PreSeed]: "Pre-Seed",
  [VendorLastFundingRound.Seed]: "Seed",
  [VendorLastFundingRound.SeriesA]: "Series A",
  [VendorLastFundingRound.SeriesB]: "Series B",
  [VendorLastFundingRound.SeriesC]: "Series C",
  [VendorLastFundingRound.SeriesDPlus]: "Series D+",
  [VendorLastFundingRound.VentureRound]: "Venture Round",
  [VendorLastFundingRound.PrivateEquityRound]: "Private Equity Round",
  [VendorLastFundingRound.DebtFinancing]: "Debt Financing",
  [VendorLastFundingRound.SecondaryMarket]: "Secondary Market",
  [VendorLastFundingRound.IPO]: "IPO",
  [VendorLastFundingRound.PostIPOEquity]: "Post-IPO Equity",
  [VendorLastFundingRound.PostIPODebt]: "Post-IPO Debt",
  [VendorLastFundingRound.Other]: "Other",
} as const;

export const VendorTotalRoundsLabels: Record<number, string> = {
  0: "None",
  1: "1",
  2: "2",
  3: "3",
  4: "4",
  5: "5",
  6: "6",
  7: "7",
  8: "8",
  9: "9",
  10: "10",
  11: "11",
  12: "12",
  13: "13",
  14: "14",
  15: "15",
  16: "16",
  17: "17",
  18: "18",
  19: "19",
  20: "20",
} as const;

export const VendorValueTagsLabels: Record<VendorValueTags, string> = {
  [VendorValueTags.MinorityWomenOwned]: "Minority/Women-Owned",
  [VendorValueTags.RevyseForStartups]: "Revyse for Startups",
  [VendorValueTags.FoundationsForRentalHousing]:
    "Foundations for Rental Housing",
} as const;

export const VendorValueIcons: Record<VendorValueTags, JSX.ElementType> = {
  MinorityWomenOwned: HandShakeIcon,
  FoundationsForRentalHousing: BuildingOffice2Icon,
  RevyseForStartups: StartUpsIcon,
};

export const enum PRODUCT_PERKS_KEYS {
  promos = "promos",
  demos = "demos",
  pricing = "pricing",
  videos = "videos",
}

export const ProductPerksLabels: Record<
  keyof typeof PRODUCT_PERKS_KEYS,
  string
> = {
  promos: "Promos and discounts",
  demos: "Product demos",
  pricing: "Published pricing",
  videos: "Videos",
};

export const ProductPerksIcons: Record<
  keyof typeof PRODUCT_PERKS_KEYS,
  JSX.ElementType
> = {
  promos: TagIcon,
  demos: TvIcon,
  pricing: CurrencyDollarIcon,
  videos: VideoCameraIcon,
};

export const ContractLineItemPriceCadenceLabels: Record<
  ContractLineItemPriceCadence,
  string
> = {
  Monthly: "Monthly",
  Quarterly: "Quarterly",
  Annual: "Annual",
  OneTime: "One Time",
};

export const LocationNoticeTypeLabels: Record<LocationNoticeType, string> = {
  LocationNoticeDisposition: "Disposition Notice",
  LocationServiceTermination: "Service Termination Notice",
};
