import dayjs from "dayjs";
import utc from "dayjs/plugin/utc";
dayjs.extend(utc);

export function calculateNextExpirationDate(
  willAutoRenew: boolean,
  autoRenewTermLength: number | null | undefined,
  expiresAt: Date
) {
  const currentDate = new Date();
  if (
    willAutoRenew &&
    autoRenewTermLength &&
    expiresAt &&
    currentDate > expiresAt
  ) {
    const currentExpiresAt = new Date(expiresAt);
    const newExpiresAt = dayjs
      .utc(currentExpiresAt)
      .add(autoRenewTermLength, "month");

    return newExpiresAt.toDate();
  } else if (expiresAt) {
    return expiresAt;
  } else {
    return null;
  }
}

export function calculateRenewalReminderDate(
  leadTimeMonths: number | null,
  currentTermEndDate: Date
) {
  const currentDate = new Date();
  if (
    leadTimeMonths &&
    currentTermEndDate &&
    currentTermEndDate > currentDate
  ) {
    const currentExpiresAt = new Date(currentTermEndDate);
    const newAutoRenewalReminderDate = dayjs
      .utc(currentExpiresAt)
      .subtract(leadTimeMonths, "month");

    return newAutoRenewalReminderDate.toDate();
  } else {
    return null;
  }
}
