export type TableState = {
  pagination: {
    page: number;
    pageSize: number;
    take: number;
    skip: number;
  };
  orderBy: {
    [key: string]: "asc" | "desc";
  }[];
  search: string | undefined;
};

export function getTableState({
  request,
  keys,
  defaults,
}: {
  request: Request;
  keys?: {
    search?: string;
    page?: string;
    pageSize?: string;
    orderBy?: string;
  };
  defaults?: {
    search?: string;
    page?: number;
    pageSize?: number;
    orderBy?: string;
  };
}) {
  const url = new URL(request.url);
  const search = new URLSearchParams(url.search);

  const queryOrderBy = search.getAll(keys?.orderBy ?? "orderBy");

  if (queryOrderBy.length === 0 && defaults?.orderBy) {
    queryOrderBy.push(defaults?.orderBy);
  }

  const orderBy = queryOrderBy.map(value => {
    const [key, direction] = value.split(":");

    if (key.includes(".")) {
      const keys = key.split(".");
      return keys.reduceRight((acc, key, index) => {
        return {
          [key]:
            index === keys.length - 1 ? (direction as "asc" | "desc") : acc,
        };
      }, {});
    }

    return { [key]: direction as "asc" | "desc" };
  });

  const page = Number(search.get(keys?.page ?? "page")) || defaults?.page || 1;
  const pageSize =
    Number(search.get(keys?.pageSize ?? "pageSize")) ||
    defaults?.pageSize ||
    20;
  const skip = (page - 1) * pageSize;

  const props: TableState = {
    pagination: {
      page: Number(search.get(keys?.page ?? "page")) || defaults?.page || 1,
      pageSize:
        Number(search.get(keys?.pageSize ?? "pageSize")) ||
        defaults?.pageSize ||
        20,
      take: pageSize,
      skip,
    },
    orderBy,
    search:
      search.get(keys?.search ?? "search") || defaults?.search || undefined,
  };

  return props;
}
