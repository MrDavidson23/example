import { MULTIPLE_FILTER_SEPARATOR } from "~/components/intelligence/filters-modal.component";

/**
 * Update the search params with the new params
 * If the value is undefined, null or empty, it will be removed from the search params
 * @param searchParams search params to update
 * @param newParams object with the new params
 */
export const updateSearchParams = (
  searchParams: URLSearchParams,
  newParams: Record<string, string | null | undefined>
) => {
  Object.entries(newParams).forEach(([key, value]) => {
    if (value === undefined || value === "" || value === null) {
      searchParams.delete(key);
    } else {
      searchParams.set(key, value);
    }
  });
};

/**
 * Get the filters from the search params. Returns an object with the filters
 * @param searchParams search params to get the filters from
 * @param arrayFields fields that are arrays so they should be split by the MULTIPLE_FILTER_SEPARATOR
 */
export const getFiltersFromSearchParams = (
  searchParams: URLSearchParams,
  arrayFields?: string[]
) => {
  const filters = Object.fromEntries(searchParams.entries());

  const formattedFilters: Record<string, string | string[]> = Object.entries(
    filters
  ).reduce((acc, [key, value]) => {
    acc[key] = arrayFields?.includes(key)
      ? value.split(MULTIPLE_FILTER_SEPARATOR)
      : value;
    return acc;
  }, {} as Record<string, string | string[]>);

  return formattedFilters;
};

/**
 * Get the pagination from the search params. Returns an object with page and perPage keys
 * @param searchParams search params to get the pagination from
 * @param defaults default values for the pagination
 */
export const getPaginationFromSearchParams = (
  searchParams: URLSearchParams,
  defaults?: { page?: number; perPage?: number }
) => {
  const page = searchParams.get("page") ?? defaults?.page ?? "1";
  const perPage = searchParams.get("perPage") ?? defaults?.perPage ?? "10";

  return {
    page: Number(page),
    perPage: Number(perPage),
  };
};

export type OrderByField = {
  [key: string]: "asc" | "desc" | OrderByField;
};

/**
 * Get the order by from the search params. Returns an array of objects with the order by keys and their direction
 * e.g. if the search params has `orderBy=task_name,-due_date`, it will return `[{task_name: "asc"}, {due_date: "desc"}]`
 * @param searchParams search params to get the order by from
 * @param defaultOrderBy default order by string
 */
export const getOrderByFromSearchParams = (
  searchParams: URLSearchParams,
  defaultOrderBy?: string
): OrderByField[] => {
  const orderByString = searchParams.get("orderBy") ?? defaultOrderBy;

  if (!orderByString) {
    return [];
  }

  return orderByString.split(",").map(orderBy => {
    const direction = (orderBy.startsWith("-") ? "desc" : "asc") as
      | "asc"
      | "desc";
    const key = orderBy.replace(/^-/, "");
    const keys = key.split(".");
    return keys.reduceRight((acc, key, index) => {
      return {
        [key]: index === keys.length - 1 ? (direction as "asc" | "desc") : acc,
      };
    }, {});
  });
};
