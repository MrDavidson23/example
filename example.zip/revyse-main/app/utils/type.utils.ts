export type Without<T, U> = { [P in Exclude<keyof T, keyof U>]?: never };

export type XOR<T, U> = T | U extends object
  ? (Without<T, U> & U) | (Without<U, T> & T)
  : T | U;

export type Result<T> =
  | {
      ok: true;
      value: T;
    }
  | {
      ok: false;
      error: string;
    };

export type MapTo<Original, ToReplace, ReplaceWith> = {
  [P in keyof Original]: Original[P] extends ToReplace
    ? ReplaceWith
    : Original[P];
};

export type RemapAll<Original, FieldType> = {
  [P in keyof Original]: FieldType;
};

export type Serialized<T> = MapTo<T, Date, string>;

export function castFormFields(fields: Record<string, any>) {
  return fields as MapTo<
    typeof fields,
    FormDataEntryValue | null,
    string | null
  >;
}
