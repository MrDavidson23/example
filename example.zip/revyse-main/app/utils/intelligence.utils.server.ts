import { WebDIContainer } from "~/di-containers/web.di-container.server";
import { assertAuthorizedOrRedirect } from "./assert.utils.server";
import type {
  PermissionType,
  PermissionUser,
} from "./intelligence-permission.utils";
import { canDoOnAccountOrThrow } from "./intelligence-permission.utils";
import { getUser } from "./session.server";
import type { ManagerAccount } from "@prisma/client";
import {
  createCookieSessionStorage,
  redirect,
  type SerializeFrom,
} from "@remix-run/node";
import { z } from "zod";
import {
  canDoOnLocationOrThrow,
  getLocationIdsForUser,
} from "./location-permission.utils";

export type IntelligenceOutletContext = {
  toggleCollapse: () => void;
  isCollapsed: boolean;
  user: PermissionUser;
  managerAccount: SerializeFrom<ManagerAccount>;
};

export async function verifyIntelligenceRequest(
  { params, request }: { params: { id?: string }; request: Request },
  {
    permissions,
    locationId,
  }: {
    permissions?: PermissionType[];
    locationId?: string;
  }
) {
  const user = await getUser(request);
  assertAuthorizedOrRedirect(user);

  const { managerAccountService } = await WebDIContainer();
  const managerAccountId = z.string().uuid().safeParse(params.id);
  if (!managerAccountId.success) {
    throw redirect("/vendor-intelligence", 303);
  }

  const account = await managerAccountService.getManagerAccount(
    managerAccountId.data
  );

  if (!account) {
    throw redirect("/vendor-intelligence", 303);
  }

  if (permissions && permissions.length > 0) {
    // If locationId is provided and no permissions to the location, we'll throw
    if (locationId) {
      canDoOnLocationOrThrow(user, account, { id: locationId }, permissions);
    }
    // If no locationId, we'll check if the user has the permission given to the entire account
    else {
      canDoOnAccountOrThrow(user, account, permissions);
    }
  }

  // Location ids where the user has the permission given
  const locationIds = permissions
    ? getLocationIdsForUser(user, account, permissions)
    : [];

  const activeLocationId = await getActiveEntityId(request);

  return { user, account: account!, activeLocationId, locationIds };
}

const storage = createCookieSessionStorage({
  cookie: {
    name: "active-location-id",
    secure: process.env.NODE_ENV === "production" && !process.env.CI,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
    httpOnly: true,
  },
});

export const setActiveEntityId = async (
  id: string,
  isLocation: boolean,
  request: Request
) => {
  const session = await storage.getSession(request.headers.get("Cookie"));
  // If its a location, set active-location-id cookie
  if (isLocation) {
    session.set("active-location-id", id);
    return redirect(request.url, {
      headers: {
        "Set-Cookie": await storage.commitSession(session),
      },
    });
  }
  // Else, is the account id so destroy active-location-id cookie
  else {
    return redirect(request.url, {
      headers: {
        "Set-Cookie": await storage.destroySession(session),
      },
    });
  }
};

export const getActiveEntityId = async (request: Request) => {
  const session = await storage.getSession(request.headers.get("Cookie"));
  return session.get("active-location-id");
};
