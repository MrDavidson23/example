export function money(val: number, abbreviate = true) {
  const divisor = val > 1_000_000 ? 1_000_000 : val > 10000 ? 1000 : 1;
  const unit = val > 1_000_000 ? "M" : val > 10000 ? "k" : "";
  return (
    (abbreviate ? val / divisor : val).toLocaleString(undefined, {
      style: "currency",
      currency: "USD",
      maximumFractionDigits: 2,
    }) + (abbreviate ? unit : "")
  );
}
