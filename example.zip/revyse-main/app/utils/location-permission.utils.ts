import type { LocationRoleType } from "@prisma/client";
import { Role } from "@prisma/client";
import { assertAuthorized } from "./assert.utils.server";
import type {
  PermissionType,
  PermissionUser,
} from "./intelligence-permission.utils";
import { canDoOnAccount, Permission } from "./intelligence-permission.utils";

const rolePermissionMap: Record<
  LocationRoleType,
  Readonly<PermissionType[]>
> = {
  Editor: [
    Permission.ViewLocationDetails,
    Permission.ManageLocations,
    Permission.ViewLocationVendorsAndProducts,
    Permission.ManageContractLineItemLocations,
  ],
  Viewer: [
    Permission.ViewLocationDetails,
    Permission.ViewLocationVendorsAndProducts,
  ],
} as const;

export function canDoOnLocation(
  user: PermissionUser,
  account: { id: string },
  location: { id: string },
  permission: PermissionType | PermissionType[]
): boolean {
  if (!account) return false;
  if (!location) return false;
  if (user.user_roles.some(role => role.role === Role.GOD_MODE)) return true;

  const managerAccountRole = user.manager_account_roles.find(
    role => role.manager_account_id === account.id
  );

  // If no role for this account, return false
  if (!managerAccountRole) return false;

  const locationRole = managerAccountRole.location_roles.find(
    role => role.location_id === location.id
  );

  // If no role for this location, check on account
  if (!locationRole) return canDoOnAccount(user, account, permission);

  const permissions = rolePermissionMap[locationRole.type];
  const authorized =
    permission instanceof Array
      ? permission.every(p => permissions.includes(p))
      : permissions.includes(permission);

  // If the permission is not authorized on the location role, check on account
  return authorized || canDoOnAccount(user, account, permission);
}

export function canDoOnLocationOrThrow(
  user: PermissionUser,
  account: { id: string },
  location: { id: string },
  permission: PermissionType | PermissionType[]
): void {
  const authorized = canDoOnLocation(user, account, location, permission);

  if (authorized) return;

  const message = `You are not authorized to ${permission} in this location`;

  assertAuthorized(authorized, message);
}

export function canDoSomeOnLocation(
  user: PermissionUser,
  account: { id: string },
  location: { id: string },
  permissions: PermissionType[]
): boolean {
  return permissions.some(permission =>
    canDoOnLocation(user, account, location, permission)
  );
}

export function canDoSomeOnLocationOrThrow(
  user: PermissionUser,
  account: { id: string },
  location: { id: string },
  permissions: PermissionType[]
): void {
  const authorized = canDoSomeOnLocation(user, account, location, permissions);

  if (authorized) return;

  const message = `You are not authorized to go into this location's section`;

  assertAuthorized(authorized, message);
}

/**
 * Returns the list of locations where the user can do the given permission on
 * @returns "all" if the user can do the permission on the account, otherwise an array of location ids
 */
export function getLocationIdsForUser(
  user: PermissionUser,
  account: { id: string },
  permissions: PermissionType[]
): string[] | "all" {
  if (canDoOnAccount(user, account, permissions)) {
    return "all";
  }

  const managerAccountRole = user.manager_account_roles.find(
    role => role.manager_account_id === account.id
  );

  // If no role for this account, return no locations
  if (!managerAccountRole) return [];

  const locationIds = managerAccountRole.location_roles
    .filter(role =>
      permissions.every(permission =>
        rolePermissionMap[role.type].includes(permission)
      )
    )
    .map(role => role.location_id);

  return locationIds;
}
