import type { ProxyPrismaClient } from "../services/db.server";
import { getDb } from "../services/db.server";

/**
 * Higher Order Helper Functions to make testing simpler
 */
type SetupFunction<TFixtures> = (
  tx: ProxyPrismaClient
) => TFixtures | Promise<TFixtures>;

type CleanupFunction<TFixtures> = (
  fixtures: TFixtures,
  tx: ProxyPrismaClient
) => any | Promise<any>;

type TestFunction<TFixtures> = (
  fixtures: TFixtures,
  tx: ProxyPrismaClient
) => any;

type WithFixtureFunction<TFixtures> = (
  test: TestFunction<TFixtures>
) => () => any;

/**
 * Will provide fixtures and a database transaction to your test
 * function and will rollback the transaction when the test completes
 * @param setup
 * @returns
 */
export function withFixtureFactory<TFixtures>({
  setup,
  cleanup = () => {},
}: {
  setup: SetupFunction<TFixtures>;
  cleanup?: CleanupFunction<TFixtures>;
}): WithFixtureFunction<TFixtures> {
  return (test: TestFunction<TFixtures>) => {
    return async () => {
      const db = getDb();
      let fixtures: TFixtures | null = null;
      try {
        await db.$transaction(async tx => {
          fixtures = await setup(tx);
          await test(fixtures, tx);
          throw "rollback";
        });
      } catch (e) {
        if (e !== "rollback") {
          throw e;
        }
      } finally {
        if (cleanup && fixtures) {
          await cleanup(fixtures, db);
        }
      }
    };
  };
}
