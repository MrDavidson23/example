import dayjs from "dayjs";

/**
 * Get the remaining time string. Returns the remaining time string in the format of `x units away`.
 * Units can be `day`, `week`, or `month`
 * If the remaining time is more than 30 days, unit is `month`. If more than 7 days, unit is `week`. Otherwise, unit is `day`.
 * @param date date string to compare with the current date
 * @returns the remaining time string in the format of `x units away`.
 */
export function getRemainingTimeString(date: string) {
  const diff = dayjs(date).diff(dayjs(), "day");

  let remaining = diff;
  let unit = "day";

  if (diff > 30) {
    remaining = Math.floor(diff / 30);
    unit = "month";
  } else if (diff > 13) {
    remaining = Math.floor(diff / 7);
    unit = "week";
  }

  return `${remaining} ${unit}${remaining > 1 ? "s" : ""} away`;
}
