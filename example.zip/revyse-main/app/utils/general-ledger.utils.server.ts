export function mapGeneralLedgerRows(rows: any[]) {
  return rows
    .filter(
      row =>
        row["Posted Dt."] && !(row["Posted Dt."] as string).startsWith("Totals")
    )
    .map(mapGeneralLedgerRow)
    .filter(row => row.parsed_vendor_name);
}

export function mapGeneralLedgerRow(row: any) {
  return {
    posted_date: new Date(row["Posted Dt."]),
    doc_date: new Date(row["Doc Dt."]),
    doc: row["Doc"],
    memo: row["Memo / Description"],
    department: row["Department"],
    property: row["Property"],
    unit: row["Unit"],
    journal: row["JNL"],
    // replace parentheses with negative sign
    debit: parseFloat(row["Debit"].replace(/\((.*)\)/, "-$1")),
    // replace parentheses with negative sign
    credit: parseFloat(row["Credit"].replace(/\((.*)\)/, "-$1")),
    // replace parentheses with negative sign
    total: parseFloat(row["Total"].replace(/\((.*)\)/, "-$1")),
    parsed_vendor_name: row["Memo / Description"].match(
      /AP Invoice - ([^:]*):?/
    )?.[1] as string,
    parsed_line_item_name: row["Memo / Description"].match(
      /AP Invoice - [^:]*: (.*)/
    )?.[1] as string,
  };
}
