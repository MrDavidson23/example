import { assertAuthorizedOrRedirect } from "../utils/assert.utils.server";
import { isEmpty, isNil } from "lodash";
import { getUser } from "./session.server";
import { Role } from "@prisma/client";

export async function assertAuthenticatedOrRedirect(
  request: Request,
  intent = "VENDOR"
) {
  const user = await getUser(request);
  const url = new URL(request.url);
  const encodedUrl = encodeURIComponent(url.pathname + url.search);
  const redirectUrl = `/sign-up?intent=${intent}&redirectTo=${encodedUrl}`;
  assertAuthorizedOrRedirect(!isNil(user), redirectUrl);
  return user;
}

export async function hasGodMode(request: Request) {
  const user = await getUser(request);
  assertAuthorizedOrRedirect(!isNil(user));
  const godModeRole = user.user_roles.find(r => r.role === Role.GOD_MODE);
  return godModeRole ? user : undefined;
}

export async function hasManagerAccount(request: Request) {
  const user = await getUser(request);
  assertAuthorizedOrRedirect(!isNil(user));
  const managerAccountRole = !isEmpty(user?.manager_account_roles);
  return managerAccountRole;
}

export async function assertGodModeOrRedirect(request: Request) {
  const user = await hasGodMode(request);
  assertAuthorizedOrRedirect(!isNil(user));
  return user;
}

export async function assertManagerRoleOrRedirect(request: Request) {
  const user = await hasManagerAccount(request);
  assertAuthorizedOrRedirect(!isNil(user));
  return user;
}
