import type { PermissionUser } from "./intelligence-permission.utils";
import { canDoOnAccount, Permission } from "./intelligence-permission.utils";

export function generateContractsRawPermissionsQuery({
  user,
  managerAccount,
  alias,
  queryConfig = {},
}: {
  user: PermissionUser;
  managerAccount: { id: string } | null;
  alias: {
    contract: string;
  };
  queryConfig?: {
    prefix?: string;
  };
}) {
  const queries = [];

  if (
    !canDoOnAccount(user, managerAccount, Permission.ViewSensitiveContracts)
  ) {
    queries.push(`${alias.contract}.is_sensitive = false`);
  }

  if (!queries.length) return ``;

  let query = queries.join(" AND ");

  if (queryConfig.prefix) {
    query = `${queryConfig.prefix} ${query}`;
  }

  return query;
}

export function generateManagerAccountVendorRawPermissionQuery({
  user,
  managerAccount,
  alias,
  queryConfig = {},
}: {
  user: PermissionUser;
  managerAccount: { id: string } | null;
  alias: {
    managerAccountVendor: string;
  };
  queryConfig?: {
    prefix?: string;
  };
}) {
  const queries = [];

  if (
    !canDoOnAccount(user, managerAccount, Permission.ViewSensitiveContracts)
  ) {
    // Query to move out those manager account vendor where all contracts are sensitive
    queries.push(
      `(NOT EXISTS (SELECT * FROM contract WHERE contract.manager_account_vendor_id = ${alias.managerAccountVendor}.id)
      OR
      (SELECT EVERY(contract.is_sensitive = true) FROM contract WHERE contract.manager_account_vendor_id = ${alias.managerAccountVendor}.id) = false)`
    );
  }

  if (!queries.length) return ``;

  let query = queries.join(" AND ");

  if (queryConfig.prefix) {
    query = `${queryConfig.prefix} ${query}`;
  }

  return query;
}
