import { SubscriptionStatus } from "@prisma/client";

export const ProductSubscriptionActiveStatuses: SubscriptionStatus[] = [
  SubscriptionStatus.active,
  SubscriptionStatus.past_due,
  SubscriptionStatus.unpaid,
];
