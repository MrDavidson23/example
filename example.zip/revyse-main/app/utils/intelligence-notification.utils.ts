import type {
  IntelligenceNotification,
  TaskCompletionStatus,
  User,
} from "@prisma/client";
import { TaskScheduleStatus } from "@prisma/client";
import {
  TaskLinkPrefixes,
  TaskTypeLabels,
  getTaskResourceName,
} from "./tasks.utils";
import type { TaskType, Task } from "./tasks.utils";
import type { SerializeFrom } from "@remix-run/node";
import { WebDIContainer } from "../di-containers/web.di-container.server";

export enum IntelligenceNotificationTypeEnum {
  TaskMessageMention = "TaskMessageMention",
  TaskMessageOwner = "TaskMessageOwner",
  TaskScheduleStatusChange = "TaskScheduleStatusChange",
  TaskCompletionStatusChange = "TaskCompletionStatusChange",
  TaskDueDateChange = "TaskDueDateChange",
}

export type IntelligenceNotificationMetadataByType = {
  [IntelligenceNotificationTypeEnum.TaskMessageMention]: {
    task_id: string;
    task_type: TaskType;
    message_id: string;
    sender_id: string;
  };
  [IntelligenceNotificationTypeEnum.TaskMessageOwner]: {
    task_id: string;
    task_type: TaskType;
    message_id: string;
    sender_id: string;
  };
  [IntelligenceNotificationTypeEnum.TaskScheduleStatusChange]: {
    task_id: string;
    task_type: TaskType;
    new_status: TaskScheduleStatus;
  };
  [IntelligenceNotificationTypeEnum.TaskCompletionStatusChange]: {
    task_id: string;
    task_type: TaskType;
    new_status: TaskCompletionStatus;
  };
  [IntelligenceNotificationTypeEnum.TaskDueDateChange]: {
    task_id: string;
    task_type: TaskType;
    new_due_date: string;
  };
};

export type IntelligenceNotificationTaskMessageMention = Omit<
  IntelligenceNotification,
  "type" | "metadata"
> & {
  type: IntelligenceNotificationTypeEnum.TaskMessageMention;
  metadata: IntelligenceNotificationMetadataByType[IntelligenceNotificationTypeEnum.TaskMessageMention] & {
    task: Task | null;
    sender: Pick<User, "id" | "first_name" | "last_name" | "avatar_url"> | null;
  };
};

export type IntelligenceNotificationTaskMessageOwner = Omit<
  IntelligenceNotification,
  "type" | "metadata"
> & {
  type: IntelligenceNotificationTypeEnum.TaskMessageOwner;
  metadata: IntelligenceNotificationMetadataByType[IntelligenceNotificationTypeEnum.TaskMessageOwner] & {
    task: Task | null;
    sender: Pick<User, "id" | "first_name" | "last_name" | "avatar_url"> | null;
  };
};

export type IntelligenceNotificationTaskScheduleStatusChange = Omit<
  IntelligenceNotification,
  "type" | "metadata"
> & {
  type: IntelligenceNotificationTypeEnum.TaskScheduleStatusChange;
  metadata: IntelligenceNotificationMetadataByType[IntelligenceNotificationTypeEnum.TaskScheduleStatusChange] & {
    task: Task | null;
  };
};

export type IntelligenceNotificationTaskCompletionStatusChange = Omit<
  IntelligenceNotification,
  "type" | "metadata"
> & {
  type: IntelligenceNotificationTypeEnum.TaskCompletionStatusChange;
  metadata: IntelligenceNotificationMetadataByType[IntelligenceNotificationTypeEnum.TaskCompletionStatusChange] & {
    task: Task | null;
  };
};

export type IntelligenceNotificationTaskDueDateChange = Omit<
  IntelligenceNotification,
  "type" | "metadata"
> & {
  type: IntelligenceNotificationTypeEnum.TaskDueDateChange;
  metadata: Omit<
    IntelligenceNotificationMetadataByType[IntelligenceNotificationTypeEnum.TaskDueDateChange],
    "new_due_date"
  > & {
    new_due_date: Date;
    task: Task | null;
  };
};

export type IntelligenceNotificationMetadataIncludes =
  | IntelligenceNotificationTaskMessageMention
  | IntelligenceNotificationTaskMessageOwner
  | IntelligenceNotificationTaskScheduleStatusChange
  | IntelligenceNotificationTaskCompletionStatusChange
  | IntelligenceNotificationTaskDueDateChange;

export function getNotificationMessage(
  notification:
    | IntelligenceNotificationMetadataIncludes
    | SerializeFrom<IntelligenceNotificationMetadataIncludes>
) {
  const { task, task_type } = notification.metadata;
  const taskTypeName = TaskTypeLabels[task_type];
  const forTerm = getTaskResourceName(task);
  if (
    notification.type === IntelligenceNotificationTypeEnum.TaskMessageMention
  ) {
    const { sender } = notification.metadata;
    const senderName = `${sender?.first_name} ${sender?.last_name}`;
    return `<b>${senderName}</b> mentioned you in the <b>${taskTypeName}</b> task for <b>${forTerm}</b>.`;
  } else if (
    notification.type === IntelligenceNotificationTypeEnum.TaskMessageOwner
  ) {
    const { sender } = notification.metadata;
    const senderName = `${sender?.first_name} ${sender?.last_name}`;
    return `<b>${senderName}</b> posted a new message in the
            <b>${taskTypeName}</b> task for <b>${forTerm}</b>.`;
  } else if (
    notification.type ===
    IntelligenceNotificationTypeEnum.TaskScheduleStatusChange
  ) {
    const { new_status } = notification.metadata;
    if (new_status === TaskScheduleStatus.ReadyToDo) {
      return `<b>${forTerm}</b> is now ready for renewal. View the details of
              your <b>${taskTypeName}</b> task.`;
    } else if (new_status === TaskScheduleStatus.Overdue) {
      return `Your <b>${taskTypeName}</b> task for <b>${forTerm}</b> is now past its
              scheduled due date.`;
    }
    return `The schedule status for your <b>${taskTypeName}</b> task for <b>${forTerm}</b>
            has been updated.`;
  } else if (
    notification.type ===
    IntelligenceNotificationTypeEnum.TaskCompletionStatusChange
  ) {
    return `Your <b>${taskTypeName}</b> task for <b>${forTerm}</b> has been marked
            as complete.`;
  } else if (
    notification.type === IntelligenceNotificationTypeEnum.TaskDueDateChange
  ) {
    return `The due date for your <b>${forTerm}</b> <b>${taskTypeName}</b> task has been
            updated.`;
  }
}

export async function getNotificationIcon(
  notification:
    | IntelligenceNotificationMetadataIncludes
    | SerializeFrom<IntelligenceNotificationMetadataIncludes>
) {
  const REVYSE_UI_ORIGIN =
    process.env.REVYSE_UI_ORIGIN || "http://localhost:3000";
  const { contractService } = await WebDIContainer();

  const { task } = notification.metadata;

  if (task && "contract_id" in task) {
    const contract = await contractService.getContractById(task?.contract_id);
    return `${REVYSE_UI_ORIGIN}/images/${contract.manager_account_vendor.vendor.logo_file_id}`;
  }
}

export function getNotificationLink(
  notification:
    | IntelligenceNotificationMetadataIncludes
    | SerializeFrom<IntelligenceNotificationMetadataIncludes>,
  managerAccountId: string
) {
  const { task, task_type } = notification.metadata;
  if (!task) return "/intelligence/tasks";
  if (
    notification.type === IntelligenceNotificationTypeEnum.TaskMessageMention ||
    notification.type === IntelligenceNotificationTypeEnum.TaskMessageOwner
  ) {
    return `/intelligence/${managerAccountId}/tasks/${TaskLinkPrefixes[task_type]}/${task.id}/?chat=true`;
  }
  // TaskScheduleStatusChange, TaskCompletionStatusChange, TaskDueDateChange
  return `/intelligence/${managerAccountId}/tasks/${TaskLinkPrefixes[task_type]}/${task.id}`;
}
