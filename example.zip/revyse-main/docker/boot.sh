#!/bin/sh
COMMAND=$1
echo "Booting container with command $COMMAND"
sleep 2
DATABASE_URL="postgresql://${DB_USER}:${DB_PASS}@${DB_HOST}:${DB_PORT}/${DB_NAME}" npx prisma migrate deploy
npm run $COMMAND
